# 🏦 Abay Bank Management System

A complete **enterprise-level banking management system** built with:
- **Frontend:** HTML5, CSS3, Vanilla JavaScript ES6+, Chart.js 4
- **Backend:** PHP 8.1 MVC, PDO
- **Database:** MySQL 8.0+ (24 tables, full schema + seed data)
- **Auth:** JWT Bearer tokens + bcrypt
- **Icons:** Font Awesome 6.5 | **Charts:** Chart.js 4.4

---

## 📁 Project Structure

```
abay-bank-management-system/
├── .env.example              ← Copy to .env and configure
├── .htaccess                 ← Apache root routing
├── .vscode/settings.json     ← VS Code PHP + Live Server config
├── composer.json             ← PHP dependencies
├── database.sql              ← Full MySQL schema + seed data
├── README.md
│
├── frontend/
│   ├── pages/
│   │   ├── index.html                      ← Entry redirect
│   │   ├── authentication/                 ← login, register, forgot, reset
│   │   ├── dashboard/                      ← Main dashboard
│   │   ├── customer/                       ← list, profile, registration, KYC
│   │   ├── accounts/                       ← savings, current, FD, open, close, statement, ATM, cheques
│   │   ├── transactions/                   ← deposit, withdrawal, transfer, history, approvals
│   │   ├── loans/                          ← apply, list, approval, payment
│   │   ├── employee/                       ← employees, attendance, payroll, performance, leave, recruitment, training
│   │   ├── branch/                         ← branches, performance
│   │   ├── reports/                        ← dashboard, financial, customer, loan, attendance
│   │   ├── administration/                 ← users, roles, permissions, audit, backup, settings
│   │   └── support/                        ← complaints, appointments, notifications
│   ├── src/
│   │   ├── assets/css/                     ← variables, style, dashboard, forms, tables, animations, utilities, responsive, dark-mode
│   │   └── assets/js/                      ← app, auth, validation, helpers, dashboard, charts, notifications, customers, accounts, loans, payroll, attendance, reports, search, _navbar
│   └── public/                             ← manifest.json, robots.txt
│
├── backend/
│   ├── index.php                           ← Entry point
│   ├── public/.htaccess                    ← Apache API routing
│   ├── app/
│   │   ├── config/                         ← database.php, bootstrap.php
│   │   ├── core/                           ← Router.php
│   │   ├── controllers/                    ← 20 controllers (all modules)
│   │   ├── models/                         ← Account, Customer, Employee, Loan, Transaction, User
│   │   ├── helpers/                        ← Response, JwtHelper, Validator
│   │   ├── middleware/                     ← AuthMiddleware
│   │   └── routes/                         ← api.php (60+ endpoints)
│   └── storage/                            ← uploads/, reports/, backups/, logs/
│
├── documentation/
│   └── PROJECT-SUMMARY.md                  ← Full module list & setup guide
└── tests/
```

---

## 🚀 Quick Setup

### Requirements
- PHP 8.1+
- MySQL 8.0+
- Apache / Nginx / XAMPP / Laragon
- Composer

### Steps

**1. Database**
```sql
mysql -u root -p
CREATE DATABASE abay_bank;
exit
mysql -u root -p abay_bank < database.sql
```

**2. Environment**
```bash
cp .env.example .env
# Edit .env: set DB_USERNAME, DB_PASSWORD
```

**3. PHP Dependencies**
```bash
composer install
```

**4. Open in browser**
```
http://localhost/abay-bank-management-system/frontend/pages/authentication/login.html
```

Or use **VS Code Live Server** (Right-click `login.html` → Open with Live Server)

---

## 🔑 Default Login Credentials

| Role       | Username   | Password       |
|------------|-----------|----------------|
| Admin      | admin     | Admin@1234     |
| Manager    | manager   | Manager@1234   |
| Teller     | teller    | Teller@1234    |

> Click any row in the demo credentials table on the login page to auto-fill.

---

## ⚠️ PHP Warning in VS Code

The warning **"Cannot validate since a PHP installation could not be found"** is a **VS Code configuration issue only** — not a code error.

**Fix:** Install PHP and add it to your PATH, or set the path in VS Code:
1. Install PHP from [https://windows.php.net/download](https://windows.php.net/download) (Thread Safe, x64)
2. Extract to `C:\php`
3. Add `C:\php` to Windows PATH environment variable
4. Restart VS Code
5. The `.vscode/settings.json` in this project already sets `"php.validate.executablePath": "php"`

Alternatively, if using **XAMPP**: set path to `C:\xampp\php\php.exe` in `.vscode/settings.json`.

---

## 📋 Modules (35 Total)

| # | Module | Status |
|---|--------|--------|
| 1 | Authentication & Security | ✅ |
| 2 | Dashboard | ✅ |
| 3 | Customer Management | ✅ |
| 4 | KYC Verification | ✅ |
| 5 | Savings Accounts | ✅ |
| 6 | Current Accounts | ✅ |
| 7 | Fixed Deposits | ✅ |
| 8 | Account Opening/Closing | ✅ |
| 9 | Account Statement | ✅ |
| 10 | Deposit Management | ✅ |
| 11 | Withdrawal Management | ✅ |
| 12 | Fund Transfer | ✅ |
| 13 | Transaction History | ✅ |
| 14 | Transaction Approvals | ✅ |
| 15 | Loan Application | ✅ |
| 16 | Loan Approval Workflow | ✅ |
| 17 | Loan Repayment + Schedule | ✅ |
| 18 | ATM Card Management | ✅ |
| 19 | Cheque Management | ✅ |
| 20 | Employee Management | ✅ |
| 21 | Attendance Management | ✅ |
| 22 | Leave Management | ✅ |
| 23 | Payroll (ETB Tax) | ✅ |
| 24 | Performance Evaluations | ✅ |
| 25 | Recruitment | ✅ |
| 26 | Training Programs | ✅ |
| 27 | Branch Management | ✅ |
| 28 | Branch Performance | ✅ |
| 29 | Financial Reports | ✅ |
| 30 | Customer/Loan/Attendance Reports | ✅ |
| 31 | User Management | ✅ |
| 32 | Roles & Permissions | ✅ |
| 33 | Audit Log | ✅ |
| 34 | Backup & Recovery | ✅ |
| 35 | System Settings | ✅ |
| 36 | Complaints Management | ✅ |
| 37 | Appointment Scheduling | ✅ |
| 38 | Notifications Center | ✅ |

---

## 🌙 Dark Mode
Click the moon icon in the top navbar to toggle dark/light mode. Preference is saved in localStorage.

---

## 📄 License
MIT — Abay Bank Management System © 2025
