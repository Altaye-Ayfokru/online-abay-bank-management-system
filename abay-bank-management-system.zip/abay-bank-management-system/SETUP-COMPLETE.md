# ዓባይ ባንክ · Abay Bank Management System
## Complete Setup & Usage Guide

---

## Quick Start (3 steps)

```
1. Import database:  database.sql  →  phpMyAdmin
2. Open browser:     http://localhost/abay-bank-management-system/frontend/pages/authentication/login.html
3. Sign in:          admin / Admin@1234
```

> **No backend required to use the system.**  
> If XAMPP MySQL is not running, the system automatically falls back to demo mode with full UI functionality.

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| PHP | 8.0+ | 8.2+ |
| MySQL / MariaDB | 5.7+ | 8.0+ / 10.6+ |
| Web Server | Apache (XAMPP) | Apache 2.4+ |
| Browser | Chrome 90+ | Chrome / Firefox / Edge (latest) |

---

## Installation

### Step 1 — Place the project

The project must be served at:
```
http://localhost/abay-bank-management-system/
```
It should already be in `C:\xampp1\htdocs\abay-bank-management-system\`.  
If not, copy the entire folder there.

---

### Step 2 — Import the database

1. Open **phpMyAdmin**: `http://localhost/phpmyadmin`
2. Click **New** → create database `abay_bank` (charset: `utf8mb4`, collation: `utf8mb4_unicode_ci`)
3. Select the `abay_bank` database → click **Import**
4. Choose `database.sql` from the project root → click **Go**

The schema creates all tables and seeds:
- 9 branches (Addis Ababa + regional)
- 6 staff user accounts
- 10 sample customers with accounts
- 10 sample transactions
- 5 active loans
- Sample employees, attendance, notifications, audit logs, settings

---

### Step 3 — Configure environment (optional)

Edit `.env` in the project root. Defaults work for XAMPP out of the box:

```env
APP_ENV=development
DB_HOST=localhost
DB_DATABASE=abay_bank
DB_USERNAME=root
DB_PASSWORD=           # leave blank for XAMPP default
JWT_SECRET=abaybank-jwt-secret-2026-xk9p!mZ3qR7vL2nW8Tz5Qs
```

If your XAMPP MySQL uses a different port or password, update `DB_PORT` and `DB_PASSWORD`.

---

### Step 4 — Verify Apache mod_rewrite is enabled

The `.htaccess` routes `/api/` requests to the PHP backend.  
In XAMPP: **Apache → httpd.conf** → uncomment `LoadModule rewrite_module`.  
Or in **XAMPP Control Panel** → Apache → Config → httpd.conf → search `rewrite_module`.

---

## Login Credentials

### Staff Portal (Management System)

| Role | Username | Password | Access Level |
|------|----------|----------|--------------|
| **Admin** | `admin` | `Admin@1234` | Full system — all modules |
| **Branch Manager** | `manager` | `Manager@1234` | Branch ops, approvals, reports |
| **Teller** | `teller` | `Teller@1234` | Transactions, customer service |
| **Loan Officer** | `loanofficer` | `Admin@1234` | Loan processing & approvals |
| **Auditor** | `auditor` | `Admin@1234` | Read-only — all modules |
| **HR Officer** | `hrstaff` | `Admin@1234` | Employees, payroll, attendance |

> The login page shows a **Demo Credentials** box — click any row to auto-fill.

---

## How the Auth Flow Works

```
User enters credentials on login.html
        │
        ▼
Try PHP backend (API.auth.login) ──── timeout 6s ─────┐
        │                                              │
    Success                                       Offline/fail
        │                                              │
Save JWT token                               Demo mode fallback
+ user object                              (validates locally)
+ expiry (2h)                                          │
        │                                              │
        └─────────────────┬────────────────────────────┘
                          ▼
               Redirect → dashboard.html
                          │
                    Auth.guard() runs
                          │
               token + expiry valid? → stay
               missing/expired?      → back to login
```

**Session storage keys** (localStorage):
- `abay_token` — JWT string (real) or base64 demo token
- `abay_user` — JSON: `{id, name, role, email, branch_id}`
- `abay_expiry` — Unix timestamp ms (2 hours from login)

---

## URL Structure

```
http://localhost/abay-bank-management-system/
│
├── frontend/pages/
│   ├── home/index.html              ← Public marketing site
│   ├── home/admin-portal.html       ← Staff portal landing
│   ├── authentication/login.html    ← Login page (START HERE)
│   ├── dashboard/dashboard.html     ← Main dashboard
│   ├── customer/                    ← Customer management
│   ├── accounts/                    ← Account management
│   ├── transactions/                ← Deposits, withdrawals, transfers
│   ├── loans/                       ← Loan management
│   ├── employee/                    ← HR & employee management
│   ├── reports/                     ← Financial & operational reports
│   ├── branch/                      ← Branch management
│   ├── support/                     ← Complaints, appointments, notifications
│   └── administration/             ← Users, roles, audit, backup, settings
│
├── backend/
│   ├── index.php                    ← API entry point
│   └── app/
│       ├── controllers/             ← 21 controllers
│       ├── models/                  ← 6 models
│       ├── helpers/                 ← Response, JwtHelper, Validator
│       ├── config/                  ← Database, Bootstrap
│       ├── core/Router.php          ← URL router
│       ├── middleware/              ← AuthMiddleware
│       └── routes/api.php           ← All API routes
│
├── database.sql                     ← Full schema + seed data
├── .env                             ← Environment configuration
└── .htaccess                        ← URL routing rules
```

---

## API Endpoints

All API calls go to:  `http://localhost/abay-bank-management-system/api/`

Test the backend is running:
```
GET http://localhost/abay-bank-management-system/api/health
```
Expected response:
```json
{ "success": true, "message": "Abay Bank API is running.", "php": "8.x.x" }
```

### Authentication
```
POST /api/auth/login              { "username": "admin", "password": "Admin@1234" }
POST /api/auth/logout
POST /api/auth/forgot-password    { "email": "..." }
PUT  /api/auth/change-password    { "current_password": "...", "new_password": "..." }
```

### Core Banking
```
GET  /api/dashboard/stats
GET  /api/customers
POST /api/customers
GET  /api/accounts
POST /api/transactions/deposit    { "account_id": 1, "amount": 5000 }
POST /api/transactions/withdrawal
POST /api/transactions/transfer   { "from_account_id": 1, "to_account_id": 2, "amount": 1000 }
GET  /api/loans
POST /api/loans/calculate-emi     { "amount": 100000, "rate": 12, "term_months": 24 }
```

All protected endpoints require:  `Authorization: Bearer <token>`

---

## Brand Colors

| Name | Hex | Usage |
|------|-----|-------|
| Abay Navy | `#1B3A5C` | Primary — sidebar, headers, buttons |
| Abay Teal | `#007A8A` | Accent — active nav, links, highlights |
| Abay Gold | `#C8A84B` | Secondary — logo bar, badges, CTAs |

---

## Features Implemented

### Banking
- [x] Customer registration & KYC verification
- [x] Account opening (Savings, Current, Fixed Deposit)
- [x] Deposits, withdrawals, fund transfers
- [x] Transaction history & approvals
- [x] Loan application, approval, disbursement & repayment
- [x] EMI calculator
- [x] ATM card issuance & management
- [x] Cheque management
- [x] Account statements

### HR & Payroll
- [x] Employee records management
- [x] Attendance tracking (check-in/out)
- [x] Leave requests & approvals
- [x] Payroll processing & payslips
- [x] Performance evaluations
- [x] Recruitment & training management

### Administration
- [x] Role-based access control (6 roles)
- [x] Branch management (9 branches)
- [x] System settings (interest rates, fees, limits)
- [x] Database backup & restore
- [x] Audit log (all user actions logged)
- [x] User account management

### Reports
- [x] Financial summary reports
- [x] Customer reports
- [x] Loan portfolio reports
- [x] Attendance reports
- [x] Branch performance reports

---

## Troubleshooting

### Login succeeds but dashboard redirects back to login
- Open browser **DevTools → Application → Local Storage**
- Check that `abay_token`, `abay_user`, `abay_expiry` are all present
- If missing, clear all localStorage and try again

### Backend API returns HTML instead of JSON
- XAMPP Apache is not running — start it from XAMPP Control Panel
- mod_rewrite is not enabled — see Step 4 above
- Check `http://localhost/abay-bank-management-system/api/health` in the browser

### Database connection error
- Ensure MySQL is running in XAMPP Control Panel
- Check `.env` — `DB_DATABASE=abay_bank`, `DB_USERNAME=root`, `DB_PASSWORD=` (blank)
- Verify the database was imported: phpMyAdmin → `abay_bank` → should show 24 tables

### "Auth guard failed" or immediate logout
- Check browser console for JavaScript errors
- Ensure no other tab is calling `Auth.logout()` or clearing localStorage
- Try in an incognito/private window to rule out extension interference

### PHP errors showing on API calls
- Set `APP_ENV=development` in `.env` to see full error messages
- Check `backend/storage/logs/` for PHP error logs

---

## Project Info

| Item | Value |
|------|-------|
| Project | Abay Bank Management System |
| Type | Academic / Portfolio Project |
| Stack | PHP 8 · MySQL · Vanilla JS · HTML/CSS |
| Architecture | MVC · REST API · JWT Auth |
| PHP Packages | vlucas/phpdotenv · firebase/php-jwt · phpmailer |
| Bank | Abay Bank S.C. · SWIFT: ABYAETAA · NBE Licensed |
| Branches | 9 (Addis Ababa + Bahir Dar, Hawassa, Dire Dawa) |

---

*Last updated: August 2026*
