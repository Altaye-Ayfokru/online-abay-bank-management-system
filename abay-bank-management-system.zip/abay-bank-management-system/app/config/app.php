<?php

/**
 * Abay Bank — Application Configuration
 */

declare(strict_types=1);

define('APP_NAME',    'Abay Bank Management System');
define('APP_VERSION', '2.0.0');
define('APP_ENV',     $_ENV['APP_ENV'] ?? 'development');
define('APP_URL',     rtrim($_ENV['APP_URL'] ?? 'http://localhost/abay-bank-management-system', '/'));
define('BASE_PATH',   dirname(__DIR__, 2));        // project root (two levels up from app/config/)
define('PUBLIC_PATH', BASE_PATH . '/public');
define('VIEW_PATH',   BASE_PATH . '/app/views');
define('ASSET_URL',   APP_URL  . '/frontend/src/assets');
define('PAGE_URL',    APP_URL  . '/frontend/pages');
define('API_URL',     APP_URL  . '/api');

// Session config
define('SESSION_NAME',    'abay_session');
define('SESSION_TIMEOUT', (int)($_ENV['SESSION_TIMEOUT'] ?? 7200));  // 2 hours

// Auth
define('JWT_SECRET', $_ENV['JWT_SECRET'] ?? 'abaybank-jwt-secret-2026-xk9p!mZ3qR7vL2nW8Tz5Qs');

// Time zone — Ethiopia (EAT = UTC+3)
date_default_timezone_set('Africa/Addis_Ababa');
