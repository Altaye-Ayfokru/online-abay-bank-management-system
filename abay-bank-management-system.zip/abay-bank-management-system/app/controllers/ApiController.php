<?php

/**
 * Abay Bank — API Controller
 *
 * Handles all AJAX/fetch calls from the front-end.
 * Routes registered in web.php under /api/*
 * Returns JSON for every endpoint.
 *
 * Endpoints implemented:
 *   POST /api/transactions/deposit
 *   POST /api/transactions/withdrawal
 *   POST /api/transactions/transfer
 *   GET  /api/accounts
 *   POST /api/customers
 *   POST /api/loans/apply
 *   POST /api/upload/profile-image
 *   POST /api/upload/document
 *   POST /api/auth/change-password
 *   GET  /api/dashboard/stats
 */

declare(strict_types=1);

namespace Web\Controllers;

use Web\Core\Auth;
use Web\Core\Session;
use App\Config\Database;
use PDO;

class ApiController
{
  private ?PDO $db = null;

  public function __construct()
  {
    try {
      $this->db = Database::getInstance()->getConnection();
    } catch (\Throwable) {
      $this->db = null;
    }
  }

  // ─── Helpers ────────────────────────────────────────────────

  private function json(mixed $data, int $code = 200): void
  {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  private function ok(mixed $data = null, string $message = 'OK'): void
  {
    $this->json(['success' => true, 'message' => $message, 'data' => $data]);
  }

  private function fail(string $message = 'Error', int $code = 400): void
  {
    $this->json(['success' => false, 'message' => $message, 'data' => null], $code);
  }

  private function body(): array
  {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
  }

  private function q(string $sql, array $p = []): array
  {
    if (!$this->db) return [];
    try {
      $s = $this->db->prepare($sql);
      $s->execute($p);
      return $s->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable) {
      return [];
    }
  }

  private function qOne(string $sql, array $p = []): ?array
  {
    $r = $this->q($sql, $p);
    return $r[0] ?? null;
  }

  private function exec(string $sql, array $p = []): bool
  {
    if (!$this->db) return false;
    try {
      $s = $this->db->prepare($sql);
      return $s->execute($p);
    } catch (\Throwable) {
      return false;
    }
  }

  private function lastId(): int
  {
    return $this->db ? (int)$this->db->lastInsertId() : 0;
  }

  private function generateRef(string $prefix = 'TXN'): string
  {
    return $prefix . '-' . strtoupper(substr(uniqid('', true), -8));
  }


  private function guardApi(): void
  {
    // ── Ensure session is started so the abay_session cookie is readable ──
    Session::start();

    // ── 1. Admin is omnipotent — always allowed ───────────────────────────
    if (Session::isLoggedIn() && Session::hasRole(['Admin'])) return;

    // ── 2. Any valid staff session ────────────────────────────────────────
    if (Session::isLoggedIn())          return;
    if (!empty($_SESSION['logged_in'])) return;
    if (!empty($_SESSION['user']))      return;   // belt-and-suspenders

    // ── 3. Customer portal session ────────────────────────────────────────
    if (!empty($_SESSION['customer_logged_in'])) return;
    if (!empty($_SESSION['cp_logged_in']))        return;

    // ── 4. Employee portal session ────────────────────────────────────────
    if (!empty($_SESSION['employee_logged_in'])) return;
    if (!empty($_SESSION['ep_logged_in']))        return;

    // ── 5. Bearer token (JS-generated from PHP session data in base.php) ─
    //    Token is base64(JSON{id, php_session:true, exp}), so length > 30.
    $auth = $_SERVER['HTTP_AUTHORIZATION']
      ?? $_SERVER['HTTP_X_AUTHORIZATION']
      ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
      ?? getallheaders()['Authorization']
      ?? getallheaders()['authorization']
      ?? '';
    if ($auth && str_starts_with($auth, 'Bearer ') && strlen($auth) > 20) return;

    // ── 6. X-Requested-With: XMLHttpRequest + any session data present ───
    //    All our fetch() calls send this header. If the session has ANY data
    //    (meaning the browser's session cookie was accepted), let it through.
    if (
      !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
      strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest' &&
      !empty($_SESSION)
    ) return;

    // ── 7. Localhost / XAMPP — development safety net ─────────────────────
    //    Covers all common XAMPP IPv4 and IPv6 loopback variants.
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $localIPs = ['127.0.0.1', '::1', '::ffff:127.0.0.1', '::ffff:0:0:1', '0:0:0:0:0:0:0:1', 'localhost'];
    if (in_array($ip, $localIPs, true)) return;
    // Also catch any 127.x.x.x loopback
    if (substr($ip, 0, 4) === '127.') return;

    $this->fail('Unauthorized. Please sign in at ' . APP_URL . '/login', 401);
  }

  // ─── GET /api/dashboard/stats ───────────────────────────────

  public function dashboardStats(): void
  {
    $this->guardApi();
    if (!$this->db) {
      $this->ok([
        'customers'          => 2450,
        'accounts'           => 3182,
        'today_transactions' => 842,
        'active_loans'       => 124,
        'total_deposits'     => 1250000,
        'total_withdrawals'  => 890000,
        'employees'          => 156,
        'branches'           => 9,
        'demo'               => true,
      ], 'Demo mode');
      return;
    }
    $stats = [
      'customers'          => (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE status='Active'")['c'] ?? 0),
      'accounts'           => (int)($this->qOne("SELECT COUNT(*) AS c FROM accounts WHERE status='Active'")['c'] ?? 0),
      'today_transactions' => (int)($this->qOne("SELECT COUNT(*) AS c FROM transactions WHERE DATE(created_at)=CURDATE()")['c'] ?? 0),
      'active_loans'       => (int)($this->qOne("SELECT COUNT(*) AS c FROM loans WHERE status IN('Active','Disbursed')")['c'] ?? 0),
      'total_deposits'     => (float)($this->qOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Deposit' AND DATE(created_at)=CURDATE()")['s'] ?? 0),
      'total_withdrawals'  => (float)($this->qOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Withdrawal' AND DATE(created_at)=CURDATE()")['s'] ?? 0),
      'employees'          => (int)($this->qOne("SELECT COUNT(*) AS c FROM employees WHERE status='Active'")['c'] ?? 0),
      'branches'           => (int)($this->qOne("SELECT COUNT(*) AS c FROM branches WHERE status='Active'")['c'] ?? 0),
    ];
    $this->ok($stats);
  }

  // ─── GET /api/accounts ──────────────────────────────────────

  public function getAccounts(): void
  {
    $this->guardApi();
    $accountNumber = trim($_GET['account_number'] ?? '');
    $id            = (int)($_GET['id'] ?? 0);

    if ($accountNumber) {
      $acc = $this->qOne(
        "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
         FROM accounts a JOIN customers c ON c.id=a.customer_id
         WHERE a.account_number=? AND a.status='Active'",
        [$accountNumber]
      );
      if (!$acc) {
        $this->fail('Account not found or inactive');
        return;
      }
      $this->ok($acc);
      return;
    }

    if ($id) {
      $acc = $this->qOne(
        "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
         FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.id=?",
        [$id]
      );
      if (!$acc) {
        $this->fail('Account not found', 404);
        return;
      }
      $this->ok($acc);
      return;
    }

    $accounts = $this->q(
      "SELECT a.id, a.account_number, a.account_type, a.balance, a.status,
              CONCAT(c.first_name,' ',c.last_name) AS customer_name
       FROM accounts a JOIN customers c ON c.id=a.customer_id
       WHERE a.status='Active' ORDER BY a.account_number LIMIT 500"
    );
    $this->ok($accounts);
  }

  // ─── POST /api/transactions/deposit ─────────────────────────

  public function deposit(): void
  {
    $this->guardApi();
    $b = $this->body();

    $accountNumber = trim($b['account_number'] ?? '');
    $amount        = (float)($b['amount'] ?? 0);
    $description   = trim($b['description'] ?? 'Cash Deposit');
    $ref           = trim($b['reference'] ?? '') ?: $this->generateRef('DEP');
    $type          = trim($b['type'] ?? 'Cash');

    if (!$accountNumber) {
      $this->fail('Account number is required');
      return;
    }
    if ($amount < 1) {
      $this->fail('Minimum deposit is ETB 1');
      return;
    }
    if ($amount > 5000000) {
      $this->fail('Exceeds single transaction limit (ETB 5,000,000)');
      return;
    }

    if (!$this->db) {
      // Demo mode — no DB
      $this->ok([
        'reference'     => $ref,
        'amount'        => $amount,
        'account'       => $accountNumber,
        'new_balance'   => 84500 + $amount,
        'demo'          => true,
      ], 'Demo: Deposit recorded (database offline)');
      return;
    }

    // Begin transaction
    try {
      $this->db->beginTransaction();

      $acc = $this->qOne(
        "SELECT id, balance, status FROM accounts WHERE account_number=? FOR UPDATE",
        [$accountNumber]
      );
      if (!$acc) {
        $this->db->rollBack();
        $this->fail('Account not found');
        return;
      }
      if ($acc['status'] !== 'Active') {
        $this->db->rollBack();
        $this->fail('Account is not active');
        return;
      }

      $newBal = (float)$acc['balance'] + $amount;
      $u = Session::getUser();

      // Update balance
      $this->exec(
        "UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?",
        [$newBal, $acc['id']]
      );

      // Insert transaction record
      $this->exec(
        "INSERT INTO transactions (account_id, type, amount, balance_after, description, reference, status, created_by, created_at)
         VALUES (?, 'Deposit', ?, ?, ?, ?, 'Completed', ?, NOW())",
        [$acc['id'], $amount, $newBal, $description, $ref, $u['id'] ?? 1]
      );
      $txnId = $this->lastId();

      // Audit log
      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at)
         VALUES (?, 'DEPOSIT', 'Transactions', ?, ?, NOW())",
        [$u['id'] ?? 1, "Deposited ETB {$amount} to account {$accountNumber}. Ref: {$ref}", $_SERVER['REMOTE_ADDR'] ?? '']
      );

      $this->db->commit();

      $this->ok([
        'transaction_id' => $txnId,
        'reference'      => $ref,
        'amount'         => $amount,
        'account'        => $accountNumber,
        'new_balance'    => $newBal,
      ], 'Deposit successful');
    } catch (\Throwable $e) {
      $this->db->rollBack();
      $this->fail('Transaction failed: ' . $e->getMessage(), 500);
    }
  }

  // ─── POST /api/transactions/withdrawal ──────────────────────

  public function withdrawal(): void
  {
    $this->guardApi();
    $b = $this->body();

    $accountNumber = trim($b['account_number'] ?? '');
    $amount        = (float)($b['amount'] ?? 0);
    $description   = trim($b['description'] ?? 'Cash Withdrawal');
    $ref           = trim($b['reference'] ?? '') ?: $this->generateRef('WDR');

    if (!$accountNumber) {
      $this->fail('Account number is required');
      return;
    }
    if ($amount < 1) {
      $this->fail('Minimum withdrawal is ETB 1');
      return;
    }

    if (!$this->db) {
      $this->ok([
        'reference'   => $ref,
        'amount'      => $amount,
        'account'     => $accountNumber,
        'new_balance' => max(0, 84500 - $amount),
        'demo'        => true,
      ], 'Demo: Withdrawal recorded (database offline)');
      return;
    }

    try {
      $this->db->beginTransaction();

      $acc = $this->qOne(
        "SELECT id, balance, status FROM accounts WHERE account_number=? FOR UPDATE",
        [$accountNumber]
      );
      if (!$acc) {
        $this->db->rollBack();
        $this->fail('Account not found');
        return;
      }
      if ($acc['status'] !== 'Active') {
        $this->db->rollBack();
        $this->fail('Account is not active');
        return;
      }
      if ((float)$acc['balance'] < $amount) {
        $this->db->rollBack();
        $this->fail('Insufficient balance');
        return;
      }

      $newBal = (float)$acc['balance'] - $amount;
      $u = Session::getUser();

      $this->exec("UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?", [$newBal, $acc['id']]);
      $this->exec(
        "INSERT INTO transactions (account_id, type, amount, balance_after, description, reference, status, created_by, created_at)
         VALUES (?, 'Withdrawal', ?, ?, ?, ?, 'Completed', ?, NOW())",
        [$acc['id'], $amount, $newBal, $description, $ref, $u['id'] ?? 1]
      );
      $txnId = $this->lastId();

      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'WITHDRAWAL', 'Transactions', ?, ?, NOW())",
        [$u['id'] ?? 1, "Withdrew ETB {$amount} from account {$accountNumber}. Ref: {$ref}", $_SERVER['REMOTE_ADDR'] ?? '']
      );

      $this->db->commit();
      $this->ok([
        'transaction_id' => $txnId,
        'reference'      => $ref,
        'amount'         => $amount,
        'account'        => $accountNumber,
        'new_balance'    => $newBal,
      ], 'Withdrawal successful');
    } catch (\Throwable $e) {
      $this->db->rollBack();
      $this->fail('Transaction failed: ' . $e->getMessage(), 500);
    }
  }

  // ─── POST /api/transactions/transfer ────────────────────────

  public function transfer(): void
  {
    $this->guardApi();
    $b = $this->body();

    $fromAcc  = trim($b['from_account'] ?? '');
    $toAcc    = trim($b['to_account'] ?? '');
    $amount   = (float)($b['amount'] ?? 0);
    $desc     = trim($b['description'] ?? 'Fund Transfer');
    $ref      = trim($b['reference'] ?? '') ?: $this->generateRef('TRF');

    if (!$fromAcc) {
      $this->fail('Source account is required');
      return;
    }
    if (!$toAcc) {
      $this->fail('Destination account is required');
      return;
    }
    if ($fromAcc === $toAcc) {
      $this->fail('Source and destination cannot be the same');
      return;
    }
    if ($amount < 1) {
      $this->fail('Minimum transfer is ETB 1');
      return;
    }

    if (!$this->db) {
      $this->ok([
        'reference'       => $ref,
        'amount'          => $amount,
        'from_account'    => $fromAcc,
        'to_account'      => $toAcc,
        'demo'            => true,
      ], 'Demo: Transfer recorded (database offline)');
      return;
    }

    try {
      $this->db->beginTransaction();

      $srcAcc = $this->qOne("SELECT id, balance, status FROM accounts WHERE account_number=? FOR UPDATE", [$fromAcc]);
      $dstAcc = $this->qOne("SELECT id, balance, status FROM accounts WHERE account_number=? FOR UPDATE", [$toAcc]);

      if (!$srcAcc) {
        $this->db->rollBack();
        $this->fail('Source account not found');
        return;
      }
      if (!$dstAcc) {
        $this->db->rollBack();
        $this->fail('Destination account not found');
        return;
      }
      if ($srcAcc['status'] !== 'Active') {
        $this->db->rollBack();
        $this->fail('Source account is not active');
        return;
      }
      if ((float)$srcAcc['balance'] < $amount) {
        $this->db->rollBack();
        $this->fail('Insufficient balance');
        return;
      }

      $srcNew = (float)$srcAcc['balance'] - $amount;
      $dstNew = (float)$dstAcc['balance'] + $amount;
      $u = Session::getUser();

      $this->exec("UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?", [$srcNew, $srcAcc['id']]);
      $this->exec("UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?", [$dstNew, $dstAcc['id']]);

      $this->exec(
        "INSERT INTO transactions (account_id, type, amount, balance_after, description, reference, status, created_by, created_at)
         VALUES (?, 'Transfer Out', ?, ?, ?, ?, 'Completed', ?, NOW())",
        [$srcAcc['id'], $amount, $srcNew, "Transfer to {$toAcc}: {$desc}", $ref, $u['id'] ?? 1]
      );
      $this->exec(
        "INSERT INTO transactions (account_id, type, amount, balance_after, description, reference, status, created_by, created_at)
         VALUES (?, 'Transfer In', ?, ?, ?, ?, 'Completed', ?, NOW())",
        [$dstAcc['id'], $amount, $dstNew, "Transfer from {$fromAcc}: {$desc}", $ref, $u['id'] ?? 1]
      );

      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'TRANSFER', 'Transactions', ?, ?, NOW())",
        [$u['id'] ?? 1, "Transfer ETB {$amount} from {$fromAcc} to {$toAcc}. Ref: {$ref}", $_SERVER['REMOTE_ADDR'] ?? '']
      );

      $this->db->commit();
      $this->ok([
        'reference'        => $ref,
        'amount'           => $amount,
        'from_account'     => $fromAcc,
        'from_new_balance' => $srcNew,
        'to_account'       => $toAcc,
        'to_new_balance'   => $dstNew,
      ], 'Transfer successful');
    } catch (\Throwable $e) {
      $this->db->rollBack();
      $this->fail('Transfer failed: ' . $e->getMessage(), 500);
    }
  }

  // ─── POST /api/customers ────────────────────────────────────

  public function createCustomer(): void
  {
    $this->guardApi();
    $b = $this->body();

    $firstName  = trim($b['first_name']  ?? '');
    $lastName   = trim($b['last_name']   ?? '');
    $phone      = trim($b['phone']       ?? '');
    $email      = trim($b['email']       ?? '');
    $dob        = trim($b['dob']         ?? '');
    $gender     = trim($b['gender']      ?? 'Other');
    $address    = trim($b['address']     ?? '');
    $branchId   = (int)($b['branch_id']  ?? 1);
    $idType     = trim($b['id_type']     ?? 'National ID');
    $idNumber   = trim($b['id_number']   ?? '');

    if (!$firstName) {
      $this->fail('First name is required');
      return;
    }
    if (!$lastName) {
      $this->fail('Last name is required');
      return;
    }
    if (!$phone) {
      $this->fail('Phone number is required');
      return;
    }

    // Generate customer number
    $custNo = 'CUST-' . strtoupper(substr(uniqid('', true), -7));

    if (!$this->db) {
      $demoCustomerId = rand(1000, 9999);
      $this->ok(['customer_id' => $demoCustomerId, 'customer_number' => $custNo, 'demo' => true], "Demo: {$firstName} {$lastName} registered. No: {$custNo}");
      return;
    }

    // Check phone uniqueness
    $existing = $this->qOne("SELECT id FROM customers WHERE phone=?", [$phone]);
    if ($existing) {
      $this->fail('Phone number already registered');
      return;
    }

    $u = Session::getUser();

    $this->exec(
      "INSERT INTO customers (customer_number, first_name, last_name, phone, email, date_of_birth, gender, address, branch_id, id_type, id_number, kyc_status, status, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Active', ?, NOW())",
      [$custNo, $firstName, $lastName, $phone, $email, $dob ?: null, $gender, $address, $branchId, $idType, $idNumber, $u['id'] ?? 1]
    );
    $custId = $this->lastId();

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'CUSTOMER_CREATED', 'Customers', ?, ?, NOW())",
      [$u['id'] ?? 1, "New customer: {$firstName} {$lastName} ({$custNo})", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok(['customer_id' => $custId, 'customer_number' => $custNo], 'Customer registered successfully');
  }

  // ─── POST /api/loans/apply ───────────────────────────────────

  public function applyLoan(): void
  {
    $this->guardApi();
    $b = $this->body();

    $customerId  = (int)($b['customer_id']  ?? 0);
    $loanType    = trim($b['loan_type']     ?? '');
    $amount      = (float)($b['amount']     ?? 0);
    $interest    = (float)($b['interest']   ?? 12.0);
    $termMonths  = (int)($b['term_months']  ?? 12);
    $purpose     = trim($b['purpose']       ?? '');
    $collateral  = trim($b['collateral']    ?? '');

    if (!$customerId) {
      $this->fail('Customer is required');
      return;
    }
    if (!$loanType) {
      $this->fail('Loan type is required');
      return;
    }
    if ($amount < 500) {
      $this->fail('Minimum loan amount is ETB 500');
      return;
    }
    if ($termMonths < 1) {
      $this->fail('Loan term must be at least 1 month');
      return;
    }
    if (!$purpose) {
      $this->fail('Loan purpose is required');
      return;
    }

    $loanNo = 'LN-' . strtoupper(substr(uniqid('', true), -6));

    if (!$this->db) {
      $this->ok(['loan_number' => $loanNo, 'demo' => true], 'Demo: Loan application submitted (database offline)');
      return;
    }

    $u = Session::getUser();

    $emi = $amount * ($interest / 1200) / (1 - pow(1 + $interest / 1200, -$termMonths));

    $this->exec(
      "INSERT INTO loans (loan_number, customer_id, loan_type, amount, interest_rate, term_months, emi_amount, purpose, collateral, status, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, NOW())",
      [$loanNo, $customerId, $loanType, $amount, $interest, $termMonths, round($emi, 2), $purpose, $collateral, $u['id'] ?? 1]
    );
    $loanId = $this->lastId();

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'LOAN_APPLIED', 'Loans', ?, ?, NOW())",
      [$u['id'] ?? 1, "Loan application {$loanNo} for ETB {$amount}", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok(['loan_id' => $loanId, 'loan_number' => $loanNo, 'emi' => round($emi, 2)], 'Loan application submitted');
  }

  // ─── POST /api/upload/profile-image ─────────────────────────

  public function uploadProfileImage(): void
  {
    $this->guardApi();

    if (empty($_FILES['photo'])) {
      $this->fail('No file uploaded');
      return;
    }

    $file    = $_FILES['photo'];
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5 MB

    if (!in_array($file['type'], $allowed)) {
      $this->fail('Only JPG, PNG, GIF or WebP images are allowed');
      return;
    }
    if ($file['size'] > $maxSize) {
      $this->fail('Image must be under 5 MB');
      return;
    }

    $uploadDir = BASE_PATH . '/public/uploads/profiles/';
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0755, true);
    }

    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'profile_' . Session::getUser()['id'] . '_' . time() . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
      $this->fail('File upload failed — check server permissions');
      return;
    }

    // Save to DB
    $u = Session::getUser();
    $url = APP_URL . '/public/uploads/profiles/' . $filename;

    if ($this->db) {
      $this->exec("UPDATE users SET avatar=? WHERE id=?", [$url, $u['id'] ?? 0]);
      // Update session
      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'PROFILE_IMAGE_UPDATED', 'Profile', ?, ?, NOW())",
        [$u['id'] ?? 1, "Profile image updated: {$filename}", $_SERVER['REMOTE_ADDR'] ?? '']
      );
    }

    $this->ok(['url' => $url, 'filename' => $filename], 'Profile image uploaded');
  }

  // ─── POST /api/upload/document ──────────────────────────────

  public function uploadDocument(): void
  {
    $this->guardApi();

    if (empty($_FILES['document'])) {
      $this->fail('No file uploaded');
      return;
    }

    $file     = $_FILES['document'];
    $allowed  = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
    $maxSize  = 10 * 1024 * 1024; // 10 MB
    $custId   = (int)($_POST['customer_id'] ?? 0);
    $docType  = trim($_POST['doc_type'] ?? 'Other');

    if (!in_array($file['type'], $allowed)) {
      $this->fail('Only PDF, JPG, PNG, or WebP files are allowed');
      return;
    }
    if ($file['size'] > $maxSize) {
      $this->fail('File must be under 10 MB');
      return;
    }

    $uploadDir = BASE_PATH . '/public/uploads/documents/';
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0755, true);
    }

    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'doc_' . $custId . '_' . time() . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
      $this->fail('File upload failed');
      return;
    }

    $url = APP_URL . '/public/uploads/documents/' . $filename;
    $u = Session::getUser();

    if ($this->db && $custId) {
      $this->exec(
        "INSERT INTO customer_documents (customer_id, doc_type, file_name, file_path, uploaded_by, status, uploaded_at)
         VALUES (?, ?, ?, ?, ?, 'Pending', NOW())",
        [$custId, $docType, $file['name'], $url, $u['id'] ?? 1]
      );
    }

    $this->ok(['url' => $url, 'filename' => $filename], 'Document uploaded');
  }

  // ─── POST /api/auth/change-password ─────────────────────────

  public function changePassword(): void
  {
    $this->guardApi();
    $b = $this->body();

    $current   = $b['current_password'] ?? '';
    $newPass   = $b['new_password'] ?? '';
    $confirm   = $b['confirm_password'] ?? '';

    if (!$current || !$newPass || !$confirm) {
      $this->fail('All password fields are required');
      return;
    }
    if ($newPass !== $confirm) {
      $this->fail('New passwords do not match');
      return;
    }
    if (strlen($newPass) < 8) {
      $this->fail('Password must be at least 8 characters');
      return;
    }

    $u = Session::getUser();

    if (!$this->db) {
      $this->ok(null, 'Demo: Password changed (database offline)');
      return;
    }

    $user = $this->qOne("SELECT id, password FROM users WHERE id=?", [$u['id'] ?? 0]);
    if (!$user) {
      $this->fail('User not found', 404);
      return;
    }

    if (!password_verify($current, $user['password'])) {
      $this->fail('Current password is incorrect');
      return;
    }

    $hashed = password_hash($newPass, PASSWORD_DEFAULT);
    $this->exec("UPDATE users SET password=?, updated_at=NOW() WHERE id=?", [$hashed, $user['id']]);

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'PASSWORD_CHANGED', 'Auth', 'User changed their password', ?, NOW())",
      [$user['id'], $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok(null, 'Password changed successfully');
  }

  // ─── POST /api/auth/update-profile ──────────────────────────

  public function updateProfile(): void
  {
    $this->guardApi();
    $b = $this->body();

    $fullName = trim($b['full_name'] ?? '');
    $email    = trim($b['email'] ?? '');
    $phone    = trim($b['phone'] ?? '');

    if (!$fullName) {
      $this->fail('Name is required');
      return;
    }

    $u = Session::getUser();

    if ($this->db) {
      $this->exec(
        "UPDATE users SET full_name=?, email=?, phone=?, updated_at=NOW() WHERE id=?",
        [$fullName, $email, $phone, $u['id'] ?? 0]
      );
      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'PROFILE_UPDATED', 'Profile', ?, ?, NOW())",
        [$u['id'] ?? 1, "Profile updated: {$fullName}", $_SERVER['REMOTE_ADDR'] ?? '']
      );
    }

    $this->ok(['full_name' => $fullName, 'email' => $email], 'Profile updated successfully');
  }

  // ─── POST /api/employees ────────────────────────────────────

  public function createEmployee(): void
  {
    $this->guardApi();
    $b = $this->body();

    $firstName = trim($b['first_name']       ?? '');
    $lastName  = trim($b['last_name']        ?? '');
    $phone     = trim($b['phone']            ?? '');
    $email     = trim($b['email']            ?? '');
    $nationalId = trim($b['national_id']      ?? '');
    $position  = trim($b['position']         ?? '');
    $dept      = trim($b['department']       ?? '');
    $branch    = trim($b['branch']           ?? '');
    $branchId  = (int)($b['branch_id']       ?? 0);
    $deptId    = (int)($b['department_id']   ?? 0);
    $salary    = (float)($b['basic_salary']  ?? 0);
    $joinDate  = trim($b['join_date']        ?? date('Y-m-d'));
    $empType   = trim($b['employment_type']  ?? 'Permanent');
    $gender    = trim($b['gender']           ?? '');

    if (!$firstName) {
      $this->fail('First name is required');
      return;
    }
    if (!$lastName) {
      $this->fail('Last name is required');
      return;
    }
    if (!$phone) {
      $this->fail('Phone number is required');
      return;
    }
    if (!$position) {
      $this->fail('Position is required');
      return;
    }

    // Generate unique employee number
    $year  = date('Y');
    $empNo = 'EMP-' . $year . '-' . str_pad((string)rand(1, 9999), 4, '0', STR_PAD_LEFT);

    // Demo mode — no DB
    if (!$this->db) {
      $demoId = rand(1000, 9999);
      $this->ok([
        'employee_id'     => $demoId,
        'employee_number' => $empNo,
        'first_name'      => $firstName,
        'last_name'       => $lastName,
        'demo'            => true,
      ], "Demo: {$firstName} {$lastName} added (database offline). Employee No: {$empNo}");
      return;
    }

    // Phone uniqueness
    $existing = $this->qOne("SELECT id FROM employees WHERE phone=?", [$phone]);
    if ($existing) {
      $this->fail('Phone number already registered for another employee');
      return;
    }

    // Resolve branch_id — try both column names (branch_name and name)
    if (!$branchId && $branch) {
      $row = $this->qOne("SELECT id FROM branches WHERE branch_name LIKE ? OR name LIKE ? LIMIT 1", ["%{$branch}%", "%{$branch}%"]);
      $branchId = (int)($row['id'] ?? 0);
    }
    if (!$branchId) $branchId = 1; // default to first branch

    // Resolve department_id — try both 'name' and 'dept_name'
    if (!$deptId && $dept) {
      $row = $this->qOne("SELECT id FROM departments WHERE name LIKE ? LIMIT 1", ["%{$dept}%"]);
      $deptId = (int)($row['id'] ?? 0);
    }

    // Ensure employee number is unique (retry up to 5 times)
    $tries = 0;
    while ($this->qOne("SELECT id FROM employees WHERE employee_number=?", [$empNo]) && $tries++ < 5) {
      $empNo = 'EMP-' . $year . '-' . str_pad((string)rand(1, 9999), 4, '0', STR_PAD_LEFT);
    }

    // Make email unique-safe: if empty generate a placeholder, if duplicate add suffix
    if (!$email) {
      $email = strtolower(str_replace(' ', '.', $firstName . '.' . $lastName))
        . '.' . rand(100, 999) . '@abaybank.internal';
    } else {
      $emailExists = $this->qOne("SELECT id FROM employees WHERE email=?", [$email]);
      if ($emailExists) {
        $email = str_replace('@', '.' . rand(10, 99) . '@', $email);
      }
    }

    // Make national_id unique-safe: if empty generate placeholder
    if (!$nationalId) {
      $nationalId = 'TMP-' . strtoupper(substr(uniqid('', true), -8));
    } else {
      $nidExists = $this->qOne("SELECT id FROM employees WHERE national_id=?", [$nationalId]);
      if ($nidExists) {
        $this->fail('National ID already registered');
        return;
      }
    }

    $u = Session::getUser();

    $this->exec(
      "INSERT INTO employees
         (employee_number, first_name, last_name, email, phone, national_id,
          department_id, branch_id, position, employment_type,
          basic_salary, gender, join_date, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', NOW())",
      [
        $empNo,
        $firstName,
        $lastName,
        $email,
        $phone,
        $nationalId,
        $deptId ?: null,
        $branchId,
        $position,
        $empType,
        $salary,
        $gender ?: null,
        $joinDate,
      ]
    );
    $empId = $this->lastId();

    if (!$empId) {
      $this->fail('Failed to save employee — please check all required fields');
      return;
    }

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at)
       VALUES (?, 'EMPLOYEE_CREATED', 'Employees', ?, ?, NOW())",
      [$u['id'] ?? 1, "New employee: {$firstName} {$lastName} ({$empNo})", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok([
      'employee_id'     => $empId,
      'employee_number' => $empNo,
      'first_name'      => $firstName,
      'last_name'       => $lastName,
    ], "Employee {$firstName} {$lastName} added successfully");
  }

  // ─── POST /api/upload/employee-photo ────────────────────────

  public function uploadEmployeePhoto(): void
  {
    $this->guardApi();

    if (empty($_FILES['photo'])) {
      $this->fail('No file uploaded');
      return;
    }

    $file    = $_FILES['photo'];
    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize = 5 * 1024 * 1024;
    $empId   = (int)($_POST['employee_id'] ?? 0);

    if (!in_array($file['type'], $allowed)) {
      $this->fail('Only JPG, PNG, WebP or GIF allowed');
      return;
    }
    if ($file['size'] > $maxSize) {
      $this->fail('Image must be under 5 MB');
      return;
    }

    $uploadDir = BASE_PATH . '/public/uploads/employees/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $ext      = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$file['type']] ?? 'jpg';
    $filename = 'emp_' . ($empId ?: 'new') . '_' . time() . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
      $this->fail('File save failed — check server permissions');
      return;
    }

    $url = APP_URL . '/public/uploads/employees/' . $filename;

    if ($this->db && $empId) {
      $this->exec("UPDATE employees SET photo_path=? WHERE id=?", [$url, $empId]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'EMPLOYEE_PHOTO_UPDATED', 'Employees', ?, ?, NOW())",
        [$u['id'] ?? 1, "Photo updated for employee #{$empId}", $_SERVER['REMOTE_ADDR'] ?? '']
      );
    }

    $this->ok(['url' => $url, 'filename' => $filename], 'Employee photo uploaded');
  }

  // ─── POST /api/branches ─────────────────────────────────────

  public function createBranch(): void
  {
    $this->guardApi();
    $b = $this->body();

    $name    = trim($b['branch_name']    ?? $b['name']    ?? '');
    $code    = strtoupper(trim($b['branch_code'] ?? $b['code'] ?? ''));
    $phone   = trim($b['phone']          ?? '');
    $address = trim($b['address']        ?? '');
    $manager = trim($b['manager']        ?? '');
    $city    = trim($b['city']           ?? 'Addis Ababa');
    $email   = trim($b['email']          ?? '');
    $openDate = trim($b['opened_date']    ?? date('Y-m-d'));

    if (!$name) {
      $this->fail('Branch name is required');
      return;
    }
    if (!$code) {
      $this->fail('Branch code is required');
      return;
    }

    if (!$this->db) {
      $this->ok(['branch_code' => $code, 'branch_name' => $name, 'demo' => true], 'Demo: Branch added (database offline)');
      return;
    }

    // Unique code check
    $exists = $this->qOne("SELECT id FROM branches WHERE code=?", [$code]);
    if ($exists) {
      $this->fail("Branch code '$code' already exists");
      return;
    }

    $u = Session::getUser();

    $this->exec(
      "INSERT INTO branches (code, name, city, address, phone, email, status, opened_date, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'Active', ?, NOW())",
      [$code, $name, $city, $address, $phone, $email, $openDate]
    );
    $branchId = $this->lastId();

    // If manager name given, try to find their employee ID
    if ($manager && $branchId) {
      $parts   = explode(' ', $manager, 2);
      $mgrRow  = $this->qOne(
        "SELECT id FROM employees WHERE first_name=? AND last_name=? LIMIT 1",
        [$parts[0], $parts[1] ?? '']
      );
      if ($mgrRow) {
        $this->exec("UPDATE branches SET manager_id=? WHERE id=?", [$mgrRow['id'], $branchId]);
      }
    }

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'BRANCH_CREATED', 'Branches', ?, ?, NOW())",
      [$u['id'] ?? 1, "New branch: {$name} ({$code})", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok([
      'branch_id'   => $branchId,
      'branch_code' => $code,
      'branch_name' => $name,
    ], "Branch '{$name}' added successfully");
  }

  // ─── PUT /api/branches/{id} ─────────────────────────────────

  public function updateBranch(): void
  {
    $this->guardApi();
    $id = (int)($_GET['id'] ?? 0);
    $b  = $this->body();

    if (!$id) {
      $this->fail('Branch ID required');
      return;
    }

    $name    = trim($b['branch_name'] ?? $b['name']    ?? '');
    $phone   = trim($b['phone']       ?? '');
    $address = trim($b['address']     ?? '');
    $manager = trim($b['manager']     ?? '');
    $status  = trim($b['status']      ?? 'Active');

    if (!$this->db) {
      $this->ok(null, 'Demo: Branch updated');
      return;
    }

    $this->exec(
      "UPDATE branches SET name=?, phone=?, address=?, status=?, updated_at=NOW() WHERE id=?",
      [$name, $phone, $address, $status, $id]
    );
    $u = Session::getUser();
    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'BRANCH_UPDATED', 'Branches', ?, ?, NOW())",
      [$u['id'] ?? 1, "Branch #{$id} updated", $_SERVER['REMOTE_ADDR'] ?? '']
    );
    $this->ok(null, 'Branch updated successfully');
  }

  // ─── POST /api/appointments ─────────────────────────────────

  public function createAppointment(): void
  {
    $this->guardApi();
    $b = $this->body();

    $customerName = trim($b['customer_name']      ?? '');
    $branchName   = trim($b['branch']             ?? '');
    $purpose      = trim($b['purpose']            ?? 'General Inquiry');
    $date         = trim($b['appointment_date']   ?? $b['date'] ?? '');
    $time         = trim($b['appointment_time']   ?? $b['time'] ?? '');
    $officer      = trim($b['officer']            ?? '');
    $notes        = trim($b['notes']              ?? '');
    $customerId   = (int)($b['customer_id']       ?? 0);
    $branchId     = (int)($b['branch_id']         ?? 1);

    if (!$customerName) {
      $this->fail('Customer name is required');
      return;
    }
    if (!$date) {
      $this->fail('Appointment date is required');
      return;
    }
    if (!$time) {
      $this->fail('Appointment time is required');
      return;
    }

    if (!$this->db) {
      $this->ok([
        'appointment_date' => $date,
        'appointment_time' => $time,
        'customer_name'    => $customerName,
        'demo'             => true,
      ], 'Demo: Appointment booked (database offline)');
      return;
    }

    // Resolve branch_id from name if needed
    if (!$branchId && $branchName) {
      $bRow = $this->qOne("SELECT id FROM branches WHERE name LIKE ? LIMIT 1", ["%$branchName%"]);
      $branchId = (int)($bRow['id'] ?? 1);
    }
    if (!$branchId) $branchId = 1;

    // Try to find customer by name if ID not provided
    if (!$customerId && $customerName) {
      $parts = explode(' ', $customerName, 2);
      $cRow  = $this->qOne(
        "SELECT id FROM customers WHERE first_name=? AND last_name=? LIMIT 1",
        [$parts[0], $parts[1] ?? '']
      );
      $customerId = (int)($cRow['id'] ?? 0);
    }

    $u = Session::getUser();

    $this->exec(
      "INSERT INTO appointments (customer_id, branch_id, appointment_date, appointment_time, purpose, officer, notes, status, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?, NOW())",
      [$customerId ?: null, $branchId, $date, $time, $purpose, $officer, $notes, $u['id'] ?? 1]
    );
    $apptId = $this->lastId();

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'APPOINTMENT_CREATED', 'Appointments', ?, ?, NOW())",
      [$u['id'] ?? 1, "Appointment booked: {$customerName} on {$date} at {$time}", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok([
      'appointment_id'   => $apptId,
      'customer_name'    => $customerName,
      'appointment_date' => $date,
      'appointment_time' => $time,
      'status'           => 'Pending',
    ], 'Appointment booked successfully');
  }

  // ─── POST /api/upload/customer-document ─────────────────────

  public function uploadCustomerDocument(): void
  {
    $this->guardApi();

    if (empty($_FILES['document'])) {
      $this->fail('No file uploaded');
      return;
    }

    $file       = $_FILES['document'];
    $allowed    = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
    $maxSize    = 10 * 1024 * 1024;
    $custId     = (int)($_POST['customer_id'] ?? 0);
    $docType    = trim($_POST['doc_type']     ?? 'Other');
    $fieldName  = trim($_POST['field_name']   ?? 'document');

    if (!in_array($file['type'], $allowed)) {
      $this->fail('Only PDF, JPG, PNG or WebP allowed');
      return;
    }
    if ($file['size'] > $maxSize) {
      $this->fail('File must be under 10 MB');
      return;
    }

    $uploadDir = BASE_PATH . '/public/uploads/documents/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $ext      = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$file['type']] ?? 'bin';
    $filename = 'cust_' . ($custId ?: 'new') . '_' . $fieldName . '_' . time() . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
      $this->fail('File save failed — check server permissions');
      return;
    }

    $url = APP_URL . '/public/uploads/documents/' . $filename;

    if ($this->db) {
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO customer_documents (customer_id, doc_type, file_name, file_path, uploaded_by, status, uploaded_at)
         VALUES (?, ?, ?, ?, ?, 'Pending', NOW())",
        [$custId ?: null, $docType, $file['name'], $url, $u['id'] ?? 1]
      );
    }

    $this->ok(['url' => $url, 'filename' => $filename, 'field' => $fieldName], 'Document uploaded successfully');
  }

  // ─── GET /api/branches ──────────────────────────────────────

  public function getBranches(): void
  {
    $this->guardApi();
    $branches = $this->q(
      "SELECT id, COALESCE(branch_name, name) AS branch_name, COALESCE(branch_code, code) AS branch_code
       FROM branches WHERE status='Active' ORDER BY COALESCE(branch_name, name)"
    );
    if (empty($branches)) {
      // fallback — try alternate column names
      $branches = $this->q("SELECT id, name AS branch_name, code AS branch_code FROM branches WHERE status='Active' ORDER BY name");
    }
    if (empty($branches)) {
      $branches = [
        ['id' => 1,  'branch_code' => 'HQ001',  'branch_name' => 'Head Office'],
        ['id' => 2,  'branch_code' => 'BOL001', 'branch_name' => 'Bole Branch'],
        ['id' => 3,  'branch_code' => 'ALEM01', 'branch_name' => 'Alem Ketema Branch'],
        ['id' => 4,  'branch_code' => 'KIR001', 'branch_name' => 'Kirkos Branch'],
        ['id' => 5,  'branch_code' => 'BHD001', 'branch_name' => 'Bahir Dar Branch'],
        ['id' => 6,  'branch_code' => 'HWS001', 'branch_name' => 'Hawassa Branch'],
        ['id' => 7,  'branch_code' => 'DRD001', 'branch_name' => 'Dire Dawa Branch'],
        ['id' => 8,  'branch_code' => 'MKL001', 'branch_name' => 'Mekelle Branch'],
      ];
    }
    $this->ok($branches);
  }

  // ─── GET /api/departments ───────────────────────────────────

  public function getDepartments(): void
  {
    $this->guardApi();
    $depts = $this->q("SELECT id, name FROM departments ORDER BY name");
    if (empty($depts)) {
      $depts = [
        ['id' => 1, 'name' => 'Finance'],
        ['id' => 2, 'name' => 'Operations'],
        ['id' => 3, 'name' => 'IT'],
        ['id' => 4, 'name' => 'HR'],
        ['id' => 5, 'name' => 'Loans'],
        ['id' => 6, 'name' => 'Customer Service'],
        ['id' => 7, 'name' => 'Compliance'],
        ['id' => 8, 'name' => 'Risk Management'],
      ];
    }
    $this->ok($depts);
  }

  // ─── GET /api/employees ─────────────────────────────────────

  public function getEmployees(): void
  {
    $this->guardApi();
    $perPage = min((int)($_GET['per_page'] ?? 200), 500);
    $search  = trim($_GET['q'] ?? '');
    $where   = "e.status != 'Terminated'";
    $params  = [];
    if ($search) {
      $where .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.phone LIKE ?)";
      $s = "%{$search}%";
      $params = [$s, $s, $s];
    }
    $employees = $this->q(
      "SELECT e.id, e.employee_number, e.first_name, e.last_name,
              e.email, e.phone, e.position, e.status,
              e.basic_salary, e.join_date, e.photo_path,
              COALESCE(d.name,'—') AS department,
              COALESCE(b.branch_name, b.name, '—') AS branch_name
       FROM employees e
       LEFT JOIN departments d ON d.id = e.department_id
       LEFT JOIN branches    b ON b.id = e.branch_id
       WHERE {$where}
       ORDER BY e.first_name, e.last_name
       LIMIT {$perPage}",
      $params
    );
    if (empty($employees)) {
      $employees = [
        ['id' => 1, 'employee_number' => 'EMP-2026-0001', 'first_name' => 'Yohannes', 'last_name' => 'Bekele', 'email' => 'y.bekele@abaybank.com', 'phone' => '0911-111-001', 'position' => 'Branch Manager', 'status' => 'Active', 'basic_salary' => 35000, 'department' => 'Operations', 'branch_name' => 'Bole Branch', 'photo_path' => null],
        ['id' => 2, 'employee_number' => 'EMP-2026-0002', 'first_name' => 'Tigist', 'last_name' => 'Haile', 'email' => 't.haile@abaybank.com', 'phone' => '0922-222-002', 'position' => 'Senior Teller', 'status' => 'Active', 'basic_salary' => 18500, 'department' => 'Customer Service', 'branch_name' => 'Kirkos Branch', 'photo_path' => null],
        ['id' => 3, 'employee_number' => 'EMP-2026-0003', 'first_name' => 'Solomon', 'last_name' => 'Girma', 'email' => 's.girma@abaybank.com', 'phone' => '0933-333-003', 'position' => 'Loan Officer', 'status' => 'Active', 'basic_salary' => 22000, 'department' => 'Loans', 'branch_name' => 'Head Office', 'photo_path' => null],
      ];
    }
    $this->ok($employees);
  }

  // GET /api/customers
  public function getCustomers(): void
  {
    $this->guardApi();
    $perPage = min((int)($_GET['per_page'] ?? 200), 500);
    $search  = trim($_GET['q'] ?? '');
    $status  = trim($_GET['status'] ?? '');
    $kyc     = trim($_GET['kyc_status'] ?? '');
    $where   = '1=1';
    $params  = [];
    if ($search) {
      $where .= ' AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.phone LIKE ? OR c.customer_number LIKE ?)';
      $s = "%{$search}%";
      array_push($params, $s, $s, $s, $s);
    }
    if ($status) {
      $where .= ' AND c.status=?';
      $params[] = $status;
    }
    if ($kyc) {
      $where .= ' AND c.kyc_status=?';
      $params[] = $kyc;
    }

    $customers = $this->q(
      "SELECT c.id, c.customer_number, c.first_name, c.last_name,
              c.phone, c.email, c.gender, c.kyc_status, c.status, c.created_at,
              COALESCE(b.name,'--') AS branch_name,
              COALESCE(SUM(a.balance),0) AS balance
       FROM customers c
       LEFT JOIN branches b ON b.id=c.branch_id
       LEFT JOIN accounts a ON a.customer_id=c.id AND a.status='Active'
       WHERE {$where}
       GROUP BY c.id
       ORDER BY c.created_at DESC
       LIMIT {$perPage}",
      $params
    );

    $total  = (int)($this->qOne("SELECT COUNT(*) AS c FROM customers")['c'] ?? 0);
    $active = (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE status='Active'")['c'] ?? 0);
    $pend   = (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status='Pending'")['c'] ?? 0);
    $susp   = (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE status='Suspended'")['c'] ?? 0);

    if (empty($customers)) {
      $customers = [
        ['id' => 1, 'customer_number' => 'CUST-A1B2C3D', 'first_name' => 'Abebe', 'last_name' => 'Bekele', 'phone' => '0911234567', 'email' => 'abebe@email.com', 'gender' => 'Male', 'kyc_status' => 'Verified', 'status' => 'Active', 'created_at' => '2024-01-15', 'branch_name' => 'Bole Branch', 'balance' => 84500],
        ['id' => 2, 'customer_number' => 'CUST-E4F5G6H', 'first_name' => 'Tigist', 'last_name' => 'Haile', 'phone' => '0922345678', 'email' => 'tigist@email.com', 'gender' => 'Female', 'kyc_status' => 'Verified', 'status' => 'Active', 'created_at' => '2024-02-20', 'branch_name' => 'Kirkos Branch', 'balance' => 125000],
        ['id' => 3, 'customer_number' => 'CUST-I7J8K9L', 'first_name' => 'Solomon', 'last_name' => 'Girma', 'phone' => '0933456789', 'email' => 'solomon@email.com', 'gender' => 'Male', 'kyc_status' => 'Pending', 'status' => 'Active', 'created_at' => '2024-03-10', 'branch_name' => 'Bahir Dar', 'balance' => 45000],
        ['id' => 4, 'customer_number' => 'CUST-M1N2O3P', 'first_name' => 'Meron', 'last_name' => 'Alemu', 'phone' => '0944567890', 'email' => 'meron@email.com', 'gender' => 'Female', 'kyc_status' => 'Verified', 'status' => 'Active', 'created_at' => '2024-03-25', 'branch_name' => 'Bole Branch', 'balance' => 220000],
        ['id' => 5, 'customer_number' => 'CUST-Q4R5S6T', 'first_name' => 'Dawit', 'last_name' => 'Mekonnen', 'phone' => '0955678901', 'email' => 'dawit@email.com', 'gender' => 'Male', 'kyc_status' => 'Pending', 'status' => 'Active', 'created_at' => '2024-04-05', 'branch_name' => 'Arada Branch', 'balance' => 15000],
        ['id' => 6, 'customer_number' => 'CUST-U7V8W9X', 'first_name' => 'Hanna', 'last_name' => 'Getnet', 'phone' => '0966789012', 'email' => 'hanna@email.com', 'gender' => 'Female', 'kyc_status' => 'Verified', 'status' => 'Active', 'created_at' => '2024-04-18', 'branch_name' => 'Head Office', 'balance' => 98000],
        ['id' => 7, 'customer_number' => 'CUST-Y1Z2A3B', 'first_name' => 'Daniel', 'last_name' => 'Worku', 'phone' => '0977890123', 'email' => 'daniel@email.com', 'gender' => 'Male', 'kyc_status' => 'Verified', 'status' => 'Active', 'created_at' => '2024-05-02', 'branch_name' => 'Kirkos Branch', 'balance' => 350000],
        ['id' => 8, 'customer_number' => 'CUST-C4D5E6F', 'first_name' => 'Fikirte', 'last_name' => 'Bekele', 'phone' => '0988901234', 'email' => 'fikirte@email.com', 'gender' => 'Female', 'kyc_status' => 'Rejected', 'status' => 'Inactive', 'created_at' => '2024-05-20', 'branch_name' => 'Dire Dawa', 'balance' => 7500],
      ];
      $total = 8;
      $active = 6;
      $pend = 2;
      $susp = 0;
    }

    $this->ok([
      'customers' => $customers,
      'stats'     => ['total' => $total, 'active' => $active, 'kyc_pending' => $pend, 'suspended' => $susp],
    ]);
  }

  public function approveLoan(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['loan_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Loan ID required');
      return;
    }

    if (!$this->db) {
      $this->ok(['loan_id' => $id, 'demo' => true], 'Demo: Loan approved');
      return;
    }

    $loan = $this->qOne("SELECT id, customer_id, amount, status FROM loans WHERE id=?", [$id]);
    if (!$loan) {
      $this->fail('Loan not found', 404);
      return;
    }
    if ($loan['status'] !== 'Pending') {
      $this->fail('Loan is not in Pending status');
      return;
    }

    $u = Session::getUser();
    $this->exec(
      "UPDATE loans SET status='Disbursed', approved_by=?, approved_at=NOW(), updated_at=NOW() WHERE id=?",
      [$u['id'] ?? 1, $id]
    );

    // Credit the customer's primary account
    $acc = $this->qOne(
      "SELECT a.id, a.balance FROM accounts a WHERE a.customer_id=? AND a.status='Active' ORDER BY a.opened_date ASC LIMIT 1",
      [$loan['customer_id']]
    );
    if ($acc) {
      $newBal = (float)$acc['balance'] + (float)$loan['amount'];
      $this->exec("UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?", [$newBal, $acc['id']]);
      $ref = $this->generateRef('LND');
      $this->exec(
        "INSERT INTO transactions (account_id, type, amount, balance_after, description, reference, status, created_by, created_at)
         VALUES (?, 'Loan Disbursement', ?, ?, ?, ?, 'Completed', ?, NOW())",
        [$acc['id'], (float)$loan['amount'], $newBal, "Loan disbursement — Loan #{$id}", $ref, $u['id'] ?? 1]
      );
    }

    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'LOAN_APPROVED', 'Loans', ?, ?, NOW())",
      [$u['id'] ?? 1, "Loan #{$id} approved and disbursed", $_SERVER['REMOTE_ADDR'] ?? '']
    );

    $this->ok(['loan_id' => $id, 'new_status' => 'Disbursed'], 'Loan approved and disbursed successfully');
  }

  // ─── POST /api/loans/reject ─────────────────────────────────

  public function rejectLoan(): void
  {
    $this->guardApi();
    $b      = $this->body();
    $id     = (int)($b['loan_id'] ?? $_GET['id'] ?? 0);
    $reason = trim($b['reason'] ?? '');
    if (!$id) {
      $this->fail('Loan ID required');
      return;
    }

    if (!$this->db) {
      $this->ok(['loan_id' => $id, 'demo' => true], 'Demo: Loan rejected');
      return;
    }

    $u = Session::getUser();
    $this->exec(
      "UPDATE loans SET status='Rejected', reject_reason=?, updated_at=NOW() WHERE id=? AND status='Pending'",
      [$reason, $id]
    );
    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'LOAN_REJECTED', 'Loans', ?, ?, NOW())",
      [$u['id'] ?? 1, "Loan #{$id} rejected. Reason: {$reason}", $_SERVER['REMOTE_ADDR'] ?? '']
    );
    $this->ok(['loan_id' => $id, 'new_status' => 'Rejected'], 'Loan rejected');
  }

  // ─── POST /api/kyc/verify ───────────────────────────────────

  public function verifyKyc(): void
  {
    $this->guardApi();
    $b      = $this->body();
    $custId = (int)($b['customer_id'] ?? $_GET['id'] ?? 0);
    $action = trim($b['action'] ?? 'verify'); // verify | reject
    $note   = trim($b['note'] ?? '');
    if (!$custId) {
      $this->fail('Customer ID required');
      return;
    }

    if (!$this->db) {
      $this->ok(['customer_id' => $custId, 'demo' => true], 'Demo: KYC ' . $action . 'ed');
      return;
    }

    $newStatus = $action === 'reject' ? 'Rejected' : 'Verified';
    $this->exec("UPDATE customers SET kyc_status=? WHERE id=?", [$newStatus, $custId]);

    $u = Session::getUser();
    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, ?, 'KYC', ?, ?, NOW())",
      [
        $u['id'] ?? 1,
        'KYC_' . strtoupper($action) . 'ED',
        "Customer #{$custId} KYC {$newStatus}" . ($note ? ". Note: {$note}" : ''),
        $_SERVER['REMOTE_ADDR'] ?? ''
      ]
    );
    $this->ok(['customer_id' => $custId, 'kyc_status' => $newStatus], "KYC {$newStatus}");
  }

  // ─── POST /api/transactions/approve ─────────────────────────

  public function approveTransaction(): void
  {
    $this->guardApi();
    $b    = $this->body();
    $txnId = (int)($b['transaction_id'] ?? $_GET['id'] ?? 0);
    if (!$txnId) {
      $this->fail('Transaction ID required');
      return;
    }

    if (!$this->db) {
      $this->ok(['transaction_id' => $txnId, 'demo' => true], 'Demo: Transaction approved');
      return;
    }

    $u = Session::getUser();
    $this->exec(
      "UPDATE transactions SET status='Completed', approved_by=?, approved_at=NOW() WHERE id=? AND status='Pending'",
      [$u['id'] ?? 1, $txnId]
    );
    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'TXN_APPROVED', 'Transactions', ?, ?, NOW())",
      [$u['id'] ?? 1, "Transaction #{$txnId} approved", $_SERVER['REMOTE_ADDR'] ?? '']
    );
    $this->ok(['transaction_id' => $txnId], 'Transaction approved');
  }

  // ─── POST /api/complaints/respond ───────────────────────────

  public function respondComplaint(): void
  {
    $this->guardApi();
    $b       = $this->body();
    $id      = (int)($b['complaint_id'] ?? $_GET['id'] ?? 0);
    $response = trim($b['response'] ?? '');
    $status  = trim($b['status']   ?? 'In Progress');
    if (!$id) {
      $this->fail('Complaint ID required');
      return;
    }
    if (!$response) {
      $this->fail('Response text required');
      return;
    }

    if (!$this->db) {
      $this->ok(['complaint_id' => $id, 'demo' => true], 'Demo: Complaint response saved');
      return;
    }

    $u = Session::getUser();
    // Check if complaint_responses table exists, otherwise update complaints table
    $hasTable = $this->qOne("SHOW TABLES LIKE 'complaint_responses'");
    if ($hasTable) {
      $this->exec(
        "INSERT INTO complaint_responses (complaint_id, response_text, responded_by, created_at) VALUES (?,?,?,NOW())",
        [$id, $response, $u['id'] ?? 1]
      );
    }
    $this->exec("UPDATE complaints SET status=?, updated_at=NOW() WHERE id=?", [$status, $id]);
    $this->exec(
      "INSERT INTO audit_logs (user_id, action, module, detail, ip, created_at) VALUES (?, 'COMPLAINT_RESPONDED', 'Complaints', ?, ?, NOW())",
      [$u['id'] ?? 1, "Complaint #{$id} response added. Status: {$status}", $_SERVER['REMOTE_ADDR'] ?? '']
    );
    $this->ok(['complaint_id' => $id, 'status' => $status], 'Response saved successfully');
  }

  // ─── GET /api/activity ───────────────────────────────────────────
  // Returns recent audit_log entries for the dashboard live feed.
  // Also used by the dashboard JS to auto-refresh without page reload.

  public function getActivity(): void
  {
    $this->guardApi();
    $limit = min((int)($_GET['limit'] ?? 20), 50);

    if ($this->db) {
      $rows = $this->q(
        "SELECT a.id, a.action, a.module, a.detail, a.ip, a.created_at,
                COALESCE(u.full_name, u.username, 'System') AS actor
         FROM audit_logs a
         LEFT JOIN users u ON u.id = a.user_id
         ORDER BY a.created_at DESC
         LIMIT ?",
        [$limit]
      );
      $this->ok($rows);
      return;
    }

    // Demo fallback — realistic recent activity
    $now = time();
    $demo = [
      ['id' => 1, 'action' => 'CUSTOMER_CREATED', 'module' => 'Customers', 'detail' => 'New customer: Abebe Bekele (CUST-A1B2C3)', 'actor' => 'Admin User',      'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 120)],
      ['id' => 2, 'action' => 'DEPOSIT',           'module' => 'Transactions', 'detail' => 'Deposit ETB 15,000 → Account 0001-10-100001. Ref: DEP-A1B2', 'actor' => 'Admin User', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 480)],
      ['id' => 3, 'action' => 'EMPLOYEE_CREATED',  'module' => 'Employees',  'detail' => 'New employee: Tigist Haile (EMP-2026-0042)', 'actor' => 'Admin User',     'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 900)],
      ['id' => 4, 'action' => 'LOAN_APPROVED',     'module' => 'Loans',      'detail' => 'Loan LN-2026-0018 approved. ETB 50,000 — Abebe Girma', 'actor' => 'Manager', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 1800)],
      ['id' => 5, 'action' => 'TRANSFER',          'module' => 'Transactions', 'detail' => 'Transfer ETB 8,200 from 0001-10-100001 → 0002-10-100002. Ref: TRF-C3D4', 'actor' => 'Teller', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 3600)],
      ['id' => 6, 'action' => 'KYC_VERIFIED',      'module' => 'KYC',        'detail' => 'KYC verified for customer: Solomon Girma (CUST-I7J8K9)', 'actor' => 'HR Officer', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 5400)],
      ['id' => 7, 'action' => 'BRANCH_CREATED',    'module' => 'Branches',   'detail' => 'New branch: Sarbet Branch (SAR001)', 'actor' => 'Admin User',           'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 7200)],
      ['id' => 8, 'action' => 'WITHDRAWAL',        'module' => 'Transactions', 'detail' => 'Withdrawal ETB 5,000 from Account 0001-20-100002. Ref: WDR-B2C3', 'actor' => 'Teller', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 9000)],
      ['id' => 9, 'action' => 'LOAN_APPLICATION',  'module' => 'Loans',      'detail' => 'Loan application submitted: ETB 100,000 Personal — Meron Alemu', 'actor' => 'Loan Officer', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 10800)],
      ['id' => 10, 'action' => 'ACCOUNT_OPENED',    'module' => 'Accounts',   'detail' => 'Savings account opened for Hanna Getnet. Acc: 0003-10-100007', 'actor' => 'Admin User', 'ip' => '127.0.0.1', 'created_at' => date('Y-m-d H:i:s', $now - 14400)],
    ];
    $this->ok(array_slice($demo, 0, $limit));
  }

  // ─── GET /api/stats/refresh ──────────────────────────────────────
  // Lightweight stats endpoint called by dashboard JS every 30 seconds.
  // Returns live counts that update the KPI cards without page reload.

  public function refreshStats(): void
  {
    $this->guardApi();

    if ($this->db) {
      $stats = [
        'customers'           => (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE status='Active'")['c'] ?? 0),
        'accounts'            => (int)($this->qOne("SELECT COUNT(*) AS c FROM accounts WHERE status='Active'")['c'] ?? 0),
        'today_transactions'  => (int)($this->qOne("SELECT COUNT(*) AS c FROM transactions WHERE DATE(created_at)=CURDATE()")['c'] ?? 0),
        'active_loans'        => (int)($this->qOne("SELECT COUNT(*) AS c FROM loans WHERE status IN('Active','Disbursed')")['c'] ?? 0),
        'total_deposits'      => (float)($this->qOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Deposit' AND DATE(created_at)=CURDATE()")['s'] ?? 0),
        'total_withdrawals'   => (float)($this->qOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Withdrawal' AND DATE(created_at)=CURDATE()")['s'] ?? 0),
        'employees'           => (int)($this->qOne("SELECT COUNT(*) AS c FROM employees WHERE status='Active'")['c'] ?? 0),
        'branches'            => (int)($this->qOne("SELECT COUNT(*) AS c FROM branches WHERE status='Active'")['c'] ?? 0),
        'pending_loans'       => (int)($this->qOne("SELECT COUNT(*) AS c FROM loans WHERE status='Pending'")['c'] ?? 0),
        'pending_kyc'         => (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status IN('Pending','Under_Review')")['c'] ?? 0),
        'recent_transactions' => $this->q(
          "SELECT t.reference, a.account_number, t.type, t.amount, t.status, t.created_at
           FROM transactions t JOIN accounts a ON a.id=t.account_id
           ORDER BY t.created_at DESC LIMIT 8"
        ),
      ];
      $this->ok($stats);
      return;
    }

    // Demo fallback
    $this->ok([
      'customers'          => 2450,
      'accounts'           => 3182,
      'today_transactions' => 842,
      'active_loans'       => 124,
      'total_deposits'     => 1250000,
      'total_withdrawals'  => 890000,
      'employees'          => 156,
      'branches'           => 9,
      'pending_loans'      => 12,
      'pending_kyc'        => 38,
      'recent_transactions' => [
        ['reference' => 'DEP-A1B2C3', 'account_number' => '0001-10-100001', 'type' => 'Deposit',     'amount' => 15000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', time() - 300)],
        ['reference' => 'WDR-B2C3D4', 'account_number' => '0001-20-100002', 'type' => 'Withdrawal',  'amount' => 5000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', time() - 1080)],
        ['reference' => 'TRF-C3D4E5', 'account_number' => '0001-10-100001', 'type' => 'Transfer Out', 'amount' => 8200, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', time() - 1920)],
        ['reference' => 'DEP-D4E5F6', 'account_number' => '0002-10-100003', 'type' => 'Deposit',     'amount' => 22500, 'status' => 'Pending',  'created_at' => date('Y-m-d H:i:s', time() - 3600)],
        ['reference' => 'TRF-E5F6G7', 'account_number' => '0003-20-100004', 'type' => 'Transfer In', 'amount' => 12000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', time() - 7200)],
        ['reference' => 'WDR-F6G7H8', 'account_number' => '0002-20-100005', 'type' => 'Withdrawal',  'amount' => 3200, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', time() - 10800)],
      ],
      'demo' => true,
    ]);
  }

  // ══════════════════════════════════════════════════════════════
  //  ADMIN FULL CRUD — all methods below are Admin-only guarded
  // ══════════════════════════════════════════════════════════════

  // ─── Helper: require Admin role ──────────────────────────────
  private function adminOnly(): void
  {
    $this->guardApi();
    if (!Session::hasRole(['Admin'])) {
      $this->fail('Admin access required.', 403);
    }
  }

  // ═══════════════ EMPLOYEES ═══════════════════════════════════

  public function updateEmployee(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Employee ID required');
      return;
    }

    $fields = [];
    $params = [];
    $map = [
      'first_name' => 'first_name',
      'last_name' => 'last_name',
      'phone' => 'phone',
      'email' => 'email',
      'position' => 'position',
      'department' => 'department',
      'basic_salary' => 'basic_salary',
      'status' => 'status',
      'gender' => 'gender',
      'join_date' => 'join_date',
      'employment_type' => 'employment_type',
    ];
    foreach ($map as $key => $col) {
      if (isset($b[$key])) {
        $fields[] = "$col=?";
        $params[] = $b[$key];
      }
    }
    // Resolve branch_id from branch name
    if (!empty($b['branch'])) {
      $br = $this->qOne("SELECT id FROM branches WHERE branch_name LIKE ? OR name LIKE ? LIMIT 1", ["%{$b['branch']}%", "%{$b['branch']}%"]);
      if ($br) {
        $fields[] = 'branch_id=?';
        $params[] = $br['id'];
      }
    }
    if (empty($fields)) {
      $this->fail('No fields to update');
      return;
    }

    $params[] = $id;
    if ($this->db) {
      $this->exec("UPDATE employees SET " . implode(',', $fields) . ", updated_at=NOW() WHERE id=?", $params);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'EMPLOYEE_UPDATED','Employees',?,?,NOW())",
        [$u['id'] ?? 1, "Employee #$id updated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['employee_id' => $id], 'Employee updated successfully');
    } else {
      $this->ok(['employee_id' => $id, 'demo' => true], 'Demo: Employee updated (database offline)');
    }
  }

  public function deleteEmployee(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['employee_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Employee ID required');
      return;
    }

    if ($this->db) {
      // Soft delete — mark Inactive rather than hard delete
      $this->exec("UPDATE employees SET status='Inactive', updated_at=NOW() WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'EMPLOYEE_DELETED','Employees',?,?,NOW())",
        [$u['id'] ?? 1, "Employee #$id deactivated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['employee_id' => $id], 'Employee deactivated successfully');
    } else {
      $this->ok(['employee_id' => $id, 'demo' => true], 'Demo: Employee deleted (database offline)');
    }
  }

  // ═══════════════ CUSTOMERS ═══════════════════════════════════

  public function updateCustomer(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['customer_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Customer ID required');
      return;
    }

    $fields = [];
    $params = [];
    $map = [
      'first_name' => 'first_name',
      'last_name' => 'last_name',
      'phone' => 'phone',
      'email' => 'email',
      'address' => 'address',
      'gender' => 'gender',
      'date_of_birth' => 'date_of_birth',
      'kyc_status' => 'kyc_status',
      'status' => 'status',
    ];
    foreach ($map as $key => $col) {
      if (isset($b[$key])) {
        $fields[] = "$col=?";
        $params[] = $b[$key];
      }
    }
    if (empty($fields)) {
      $this->fail('No fields to update');
      return;
    }
    $params[] = $id;

    if ($this->db) {
      $this->exec("UPDATE customers SET " . implode(',', $fields) . ", updated_at=NOW() WHERE id=?", $params);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'CUSTOMER_UPDATED','Customers',?,?,NOW())",
        [$u['id'] ?? 1, "Customer #$id updated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['customer_id' => $id], 'Customer updated successfully');
    } else {
      $this->ok(['customer_id' => $id, 'demo' => true], 'Demo: Customer updated (database offline)');
    }
  }

  public function deleteCustomer(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['customer_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Customer ID required');
      return;
    }

    if ($this->db) {
      $this->exec("UPDATE customers SET status='Inactive', updated_at=NOW() WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'CUSTOMER_DELETED','Customers',?,?,NOW())",
        [$u['id'] ?? 1, "Customer #$id deactivated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['customer_id' => $id], 'Customer deactivated successfully');
    } else {
      $this->ok(['customer_id' => $id, 'demo' => true], 'Demo: Customer deleted (database offline)');
    }
  }

  // ═══════════════ BRANCHES ════════════════════════════════════

  public function deleteBranch(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['branch_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Branch ID required');
      return;
    }

    if ($this->db) {
      $this->exec("UPDATE branches SET status='Inactive' WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'BRANCH_DELETED','Branches',?,?,NOW())",
        [$u['id'] ?? 1, "Branch #$id deactivated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['branch_id' => $id], 'Branch deactivated successfully');
    } else {
      $this->ok(['branch_id' => $id, 'demo' => true], 'Demo: Branch deleted (database offline)');
    }
  }

  // ═══════════════ LOANS ═══════════════════════════════════════

  public function getLoans(): void
  {
    $this->guardApi();
    $perPage  = min((int)($_GET['per_page'] ?? 200), 500);
    $search   = trim($_GET['q'] ?? '');
    $status   = trim($_GET['status'] ?? '');

    if ($this->db) {
      $where = '1=1';
      $params = [];
      if ($search) {
        $where .= " AND (CONCAT(c.first_name,' ',c.last_name) LIKE ? OR l.loan_number LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
      }
      if ($status) {
        $where .= ' AND l.status=?';
        $params[] = $status;
      }
      $params[] = $perPage;
      $loans = $this->q("SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
        FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE $where ORDER BY l.created_at DESC LIMIT ?", $params);
      $this->ok($loans);
      return;
    }
    // Demo
    $this->ok([
      ['id' => 1, 'loan_number' => 'LN-2026-0001', 'customer_name' => 'Abebe Bekele', 'loan_type' => 'Personal Loan', 'amount' => 50000, 'outstanding_balance' => 42000, 'interest_rate' => 12, 'term_months' => 36, 'status' => 'Active', 'created_at' => date('Y-m-d', strtotime('-90 days')), 'next_due_date' => date('Y-m-d', strtotime('+5 days'))],
      ['id' => 2, 'loan_number' => 'LN-2026-0002', 'customer_name' => 'Tigist Haile', 'loan_type' => 'Business Loan', 'amount' => 200000, 'outstanding_balance' => 180000, 'interest_rate' => 10.5, 'term_months' => 60, 'status' => 'Active', 'created_at' => date('Y-m-d', strtotime('-30 days')), 'next_due_date' => date('Y-m-d', strtotime('+15 days'))],
      ['id' => 3, 'loan_number' => 'LN-2026-0003', 'customer_name' => 'Solomon Girma', 'loan_type' => 'Agricultural Loan', 'amount' => 30000, 'outstanding_balance' => 30000, 'interest_rate' => 8, 'term_months' => 24, 'status' => 'Pending', 'created_at' => date('Y-m-d', strtotime('-5 days')), 'next_due_date' => null],
    ]);
  }

  public function updateLoan(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['loan_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('Loan ID required');
      return;
    }

    $allowed = ['interest_rate', 'term_months', 'notes', 'status', 'next_due_date'];
    $fields = [];
    $params = [];
    foreach ($allowed as $f) {
      if (isset($b[$f])) {
        $fields[] = "$f=?";
        $params[] = $b[$f];
      }
    }
    if (empty($fields)) {
      $this->fail('No fields to update');
      return;
    }
    $params[] = $id;

    if ($this->db) {
      $this->exec("UPDATE loans SET " . implode(',', $fields) . ", updated_at=NOW() WHERE id=?", $params);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'LOAN_UPDATED','Loans',?,?,NOW())",
        [$u['id'] ?? 1, "Loan #$id updated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['loan_id' => $id], 'Loan updated successfully');
    } else {
      $this->ok(['loan_id' => $id, 'demo' => true], 'Demo: Loan updated');
    }
  }

  public function cancelLoan(): void
  {
    $this->guardApi();
    $b      = $this->body();
    $id     = (int)($b['id'] ?? $b['loan_id'] ?? 0);
    $reason = trim($b['reason'] ?? 'Cancelled by administrator');
    if (!$id) {
      $this->fail('Loan ID required');
      return;
    }

    if ($this->db) {
      $this->exec("UPDATE loans SET status='Cancelled', notes=CONCAT(COALESCE(notes,''),' | Cancelled: $reason'), updated_at=NOW() WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'LOAN_CANCELLED','Loans',?,?,NOW())",
        [$u['id'] ?? 1, "Loan #$id cancelled: $reason", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['loan_id' => $id], 'Loan cancelled');
    } else {
      $this->ok(['loan_id' => $id, 'demo' => true], 'Demo: Loan cancelled');
    }
  }

  // ═══════════════ ACCOUNTS ════════════════════════════════════

  public function openAccount(): void
  {
    $this->guardApi();
    $b = $this->body();

    $customerId  = (int)($b['customer_id']  ?? 0);
    $accountType = trim($b['account_type']  ?? 'Savings');
    $branchId    = (int)($b['branch_id']    ?? 1);
    $currency    = trim($b['currency']      ?? 'ETB');
    $initialDep  = (float)($b['initial_deposit'] ?? 0);
    $openedBy    = (int)(Session::getUser()['id'] ?? 1);

    if (!$customerId) {
      $this->fail('Customer is required');
      return;
    }

    // Generate account number
    $year   = date('Y');
    $accNo  = '100' . date('Ymd') . str_pad((string)rand(1, 9999), 4, '0', STR_PAD_LEFT);

    if ($this->db) {
      // Check customer exists
      $cust = $this->qOne("SELECT id, first_name, last_name FROM customers WHERE id=? AND status='Active'", [$customerId]);
      if (!$cust) {
        $this->fail('Customer not found or inactive');
        return;
      }

      // Ensure unique account number
      $tries = 0;
      while ($this->qOne("SELECT id FROM accounts WHERE account_number=?", [$accNo]) && $tries++ < 5) {
        $accNo = '100' . date('Ymd') . str_pad((string)rand(1, 9999), 4, '0', STR_PAD_LEFT);
      }

      $this->exec(
        "INSERT INTO accounts (customer_id, account_number, account_type, balance, currency, branch_id, status, opened_by, opened_date, created_at)
         VALUES (?,?,?,?,?,?,'Active',?,CURDATE(),NOW())",
        [$customerId, $accNo, $accountType, $initialDep, $currency, $branchId, $openedBy]
      );
      $accId = $this->lastId();
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'ACCOUNT_OPENED','Accounts',?,?,NOW())",
        [$u['id'] ?? 1, "Account $accNo opened for customer #$customerId", $_SERVER['REMOTE_ADDR'] ?? '']
      );

      $this->ok(
        ['account_id' => $accId, 'account_number' => $accNo, 'account_type' => $accountType, 'balance' => $initialDep],
        "$accountType account $accNo opened successfully"
      );
    } else {
      $this->ok(
        ['account_number' => $accNo, 'account_type' => $accountType, 'balance' => $initialDep, 'demo' => true],
        "Demo: $accountType account opened (database offline)"
      );
    }
  }

  // ═══════════════ USERS (Admin) ═══════════════════════════════

  public function getUsers(): void
  {
    $this->adminOnly();
    if ($this->db) {
      $users = $this->q("SELECT u.id, u.username, u.full_name, u.email, u.status, u.last_login_at, u.created_at, r.role_name FROM users u LEFT JOIN roles r ON r.id=u.role_id ORDER BY u.created_at DESC LIMIT 200");
      $this->ok($users);
      return;
    }
    $this->ok([
      ['id' => 1, 'username' => 'admin',       'full_name' => 'Admin User',     'email' => 'admin@abaybank.com',    'role_name' => 'Admin',       'status' => 'Active', 'last_login_at' => date('Y-m-d H:i:s', time() - 3600)],
      ['id' => 2, 'username' => 'manager',     'full_name' => 'Branch Manager',  'email' => 'manager@abaybank.com',  'role_name' => 'Manager',     'status' => 'Active', 'last_login_at' => date('Y-m-d H:i:s', time() - 7200)],
      ['id' => 3, 'username' => 'teller',      'full_name' => 'Teller Officer',  'email' => 'teller@abaybank.com',   'role_name' => 'Teller',      'status' => 'Active', 'last_login_at' => date('Y-m-d H:i:s', time() - 86400)],
      ['id' => 4, 'username' => 'loanofficer', 'full_name' => 'Loan Officer',    'email' => 'loan@abaybank.com',     'role_name' => 'Loan Officer', 'status' => 'Active', 'last_login_at' => null],
      ['id' => 5, 'username' => 'auditor',     'full_name' => 'Audit Officer',   'email' => 'auditor@abaybank.com',  'role_name' => 'Auditor',     'status' => 'Active', 'last_login_at' => null],
      ['id' => 6, 'username' => 'hrstaff',     'full_name' => 'HR Officer',      'email' => 'hr@abaybank.com',       'role_name' => 'HR Officer',  'status' => 'Active', 'last_login_at' => null],
    ]);
  }

  public function createUser(): void
  {
    $this->adminOnly();
    $b = $this->body();
    $username  = trim($b['username']  ?? '');
    $fullName  = trim($b['full_name'] ?? $b['name'] ?? '');
    $email     = trim($b['email']     ?? '');
    $password  = trim($b['password']  ?? 'Abay@' . rand(1000, 9999));
    $roleId    = (int)($b['role_id']  ?? 0);
    $roleName  = trim($b['role']      ?? 'Teller');

    if (!$username || !$fullName) {
      $this->fail('Username and full name are required');
      return;
    }

    if ($this->db) {
      $exists = $this->qOne("SELECT id FROM users WHERE username=? OR email=?", [$username, $email]);
      if ($exists) {
        $this->fail('Username or email already exists');
        return;
      }

      if (!$roleId && $roleName) {
        $role = $this->qOne("SELECT id FROM roles WHERE role_name=? LIMIT 1", [$roleName]);
        $roleId = (int)($role['id'] ?? 1);
      }
      $this->exec(
        "INSERT INTO users (username, full_name, email, password, role_id, status, created_at) VALUES (?,?,?,?,?,'Active',NOW())",
        [$username, $fullName, $email, password_hash($password, PASSWORD_DEFAULT), $roleId]
      );
      $uid = $this->lastId();
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'USER_CREATED','Users',?,?,NOW())",
        [$u['id'] ?? 1, "User $username created", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['user_id' => $uid, 'username' => $username, 'temp_password' => $password], 'User created. Temporary password: ' . $password);
    } else {
      $this->ok(['username' => $username, 'temp_password' => $password, 'demo' => true], 'Demo: User created (database offline). Temp password: ' . $password);
    }
  }

  public function updateUser(): void
  {
    $this->adminOnly();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['user_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('User ID required');
      return;
    }

    $fields = [];
    $params = [];
    if (isset($b['full_name'])) {
      $fields[] = 'full_name=?';
      $params[] = $b['full_name'];
    }
    if (isset($b['email'])) {
      $fields[] = 'email=?';
      $params[] = $b['email'];
    }
    if (isset($b['status'])) {
      $fields[] = 'status=?';
      $params[] = $b['status'];
    }
    if (isset($b['role_id'])) {
      $fields[] = 'role_id=?';
      $params[] = (int)$b['role_id'];
    }
    if (!empty($b['password'])) {
      $fields[] = 'password=?';
      $params[] = password_hash($b['password'], PASSWORD_DEFAULT);
    }
    if (empty($fields)) {
      $this->fail('Nothing to update');
      return;
    }
    $params[] = $id;

    if ($this->db) {
      $this->exec("UPDATE users SET " . implode(',', $fields) . ", updated_at=NOW() WHERE id=?", $params);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'USER_UPDATED','Users',?,?,NOW())",
        [$u['id'] ?? 1, "User #$id updated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['user_id' => $id], 'User updated successfully');
    } else {
      $this->ok(['user_id' => $id, 'demo' => true], 'Demo: User updated');
    }
  }

  public function deleteUser(): void
  {
    $this->adminOnly();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['user_id'] ?? $_GET['id'] ?? 0);
    if (!$id) {
      $this->fail('User ID required');
      return;
    }

    $current = Session::getUser();
    if ((int)($current['id'] ?? 0) === $id) {
      $this->fail('Cannot delete your own account');
      return;
    }

    if ($this->db) {
      $this->exec("UPDATE users SET status='Inactive', updated_at=NOW() WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'USER_DELETED','Users',?,?,NOW())",
        [$u['id'] ?? 1, "User #$id deactivated", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['user_id' => $id], 'User deactivated');
    } else {
      $this->ok(['user_id' => $id, 'demo' => true], 'Demo: User deleted');
    }
  }

  public function resetUserPassword(): void
  {
    $this->adminOnly();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['user_id'] ?? 0);
    if (!$id) {
      $this->fail('User ID required');
      return;
    }

    $newPass = 'Abay@' . rand(10000, 99999);

    if ($this->db) {
      $this->exec("UPDATE users SET password=?, updated_at=NOW() WHERE id=?", [password_hash($newPass, PASSWORD_DEFAULT), $id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'PASSWORD_RESET','Users',?,?,NOW())",
        [$u['id'] ?? 1, "Password reset for user #$id", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['user_id' => $id, 'temp_password' => $newPass], 'Password reset. New temp password: ' . $newPass);
    } else {
      $this->ok(['user_id' => $id, 'temp_password' => $newPass, 'demo' => true], 'Demo: Password reset to: ' . $newPass);
    }
  }

  public function toggleUserLock(): void
  {
    $this->adminOnly();
    $b      = $this->body();
    $id     = (int)($b['id'] ?? $b['user_id'] ?? 0);
    $action = trim($b['action'] ?? 'lock');   // 'lock' or 'unlock'
    if (!$id) {
      $this->fail('User ID required');
      return;
    }

    $newStatus = $action === 'unlock' ? 'Active' : 'Locked';

    if ($this->db) {
      $this->exec("UPDATE users SET status=?, updated_at=NOW() WHERE id=?", [$newStatus, $id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'USER_LOCK_TOGGLE','Users',?,?,NOW())",
        [$u['id'] ?? 1, "User #$id set to $newStatus", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['user_id' => $id, 'status' => $newStatus], "User $newStatus");
    } else {
      $this->ok(['user_id' => $id, 'status' => $newStatus, 'demo' => true], "Demo: User $newStatus");
    }
  }

  // ═══════════════ ATTENDANCE ══════════════════════════════════

  public function getAttendance(): void
  {
    $this->guardApi();
    $date    = trim($_GET['date'] ?? date('Y-m-d'));
    $empId   = (int)($_GET['employee_id'] ?? 0);

    if ($this->db) {
      $where = 'a.date=?';
      $params = [$date];
      if ($empId) {
        $where .= ' AND a.employee_id=?';
        $params[] = $empId;
      }
      $rows = $this->q("SELECT a.*, CONCAT(e.first_name,' ',e.last_name) AS name, e.employee_number FROM attendance a JOIN employees e ON e.id=a.employee_id WHERE $where ORDER BY e.first_name", $params);
      $this->ok($rows);
      return;
    }
    $now = date('Y-m-d H:i:s');
    $this->ok([
      ['id' => 1, 'employee_id' => 1, 'name' => 'Yohannes Bekele', 'employee_number' => 'EMP-2026-0001', 'date' => $date, 'check_in' => '08:05:00', 'check_out' => '17:10:00', 'status' => 'Present', 'working_hours' => 9.08],
      ['id' => 2, 'employee_id' => 2, 'name' => 'Tigist Haile',   'employee_number' => 'EMP-2026-0002', 'date' => $date, 'check_in' => '08:15:00', 'check_out' => null,       'status' => 'Present', 'working_hours' => null],
      ['id' => 3, 'employee_id' => 3, 'name' => 'Solomon Girma',  'employee_number' => 'EMP-2026-0003', 'date' => $date, 'check_in' => null,       'check_out' => null,       'status' => 'Absent', 'working_hours' => null],
    ]);
  }

  public function attendanceCheckin(): void
  {
    $this->guardApi();
    $b    = $this->body();
    $empId = (int)($b['employee_id'] ?? Session::getUser()['id'] ?? 0);
    $note = trim($b['note'] ?? '');
    $date = date('Y-m-d');
    $time = date('H:i:s');

    if ($this->db) {
      $exists = $this->qOne("SELECT id FROM attendance WHERE employee_id=? AND date=?", [$empId, $date]);
      if ($exists) {
        $this->fail('Already checked in today');
        return;
      }
      $this->exec("INSERT INTO attendance (employee_id,date,check_in,status,note,created_at) VALUES (?,?,?,'Present',?,NOW())", [$empId, $date, $time, $note]);
      $this->ok(['employee_id' => $empId, 'check_in' => $time, 'date' => $date], 'Check-in recorded');
    } else {
      $this->ok(['employee_id' => $empId, 'check_in' => $time, 'date' => $date, 'demo' => true], 'Demo: Check-in recorded');
    }
  }

  public function attendanceCheckout(): void
  {
    $this->guardApi();
    $b    = $this->body();
    $empId = (int)($b['employee_id'] ?? Session::getUser()['id'] ?? 0);
    $date = date('Y-m-d');
    $time = date('H:i:s');

    if ($this->db) {
      $rec = $this->qOne("SELECT id,check_in FROM attendance WHERE employee_id=? AND date=? AND check_out IS NULL", [$empId, $date]);
      if (!$rec) {
        $this->fail('No active check-in found for today');
        return;
      }
      // Calculate working hours
      $checkIn  = strtotime($date . ' ' . $rec['check_in']);
      $checkOut = strtotime($date . ' ' . $time);
      $hours    = round(($checkOut - $checkIn) / 3600, 2);
      $this->exec("UPDATE attendance SET check_out=?, working_hours=?, updated_at=NOW() WHERE id=?", [$time, $hours, $rec['id']]);
      $this->ok(['employee_id' => $empId, 'check_out' => $time, 'working_hours' => $hours], 'Check-out recorded');
    } else {
      $this->ok(['employee_id' => $empId, 'check_out' => $time, 'working_hours' => 8.5, 'demo' => true], 'Demo: Check-out recorded');
    }
  }

  public function updateAttendance(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? 0);
    if (!$id) {
      $this->fail('Attendance record ID required');
      return;
    }

    $fields = [];
    $params = [];
    foreach (['check_in', 'check_out', 'status', 'note'] as $f) {
      if (isset($b[$f])) {
        $fields[] = "$f=?";
        $params[] = $b[$f];
      }
    }
    if (empty($fields)) {
      $this->fail('Nothing to update');
      return;
    }
    $params[] = $id;

    if ($this->db) {
      $this->exec("UPDATE attendance SET " . implode(',', $fields) . ", updated_at=NOW() WHERE id=?", $params);
      $this->ok(['attendance_id' => $id], 'Attendance updated');
    } else {
      $this->ok(['attendance_id' => $id, 'demo' => true], 'Demo: Attendance updated');
    }
  }

  // ═══════════════ LEAVES ══════════════════════════════════════

  public function getLeaves(): void
  {
    $this->guardApi();
    if ($this->db) {
      $rows = $this->q("SELECT l.*, CONCAT(e.first_name,' ',e.last_name) AS name FROM leave_requests l JOIN employees e ON e.id=l.employee_id ORDER BY l.created_at DESC LIMIT 200");
      $this->ok($rows);
      return;
    }
    $this->ok([
      ['id' => 1, 'name' => 'Yohannes Bekele', 'leave_type' => 'Annual', 'start_date' => date('Y-m-d', strtotime('+5 days')), 'end_date' => date('Y-m-d', strtotime('+10 days')), 'days' => 5, 'reason' => 'Family trip', 'status' => 'Pending'],
      ['id' => 2, 'name' => 'Tigist Haile',   'leave_type' => 'Sick',  'start_date' => date('Y-m-d', strtotime('-2 days')), 'end_date' => date('Y-m-d', strtotime('-1 day')), 'days' => 2, 'reason' => 'Medical', 'status' => 'Approved'],
    ]);
  }

  public function applyLeave(): void
  {
    $this->guardApi();
    $b = $this->body();
    $empId     = (int)($b['employee_id'] ?? Session::getUser()['id'] ?? 0);
    $leaveType = trim($b['leave_type'] ?? 'Annual');
    $startDate = trim($b['start_date'] ?? '');
    $endDate   = trim($b['end_date']   ?? '');
    $reason    = trim($b['reason']     ?? '');

    if (!$startDate || !$endDate) {
      $this->fail('Start and end date are required');
      return;
    }

    if ($this->db) {
      $days = (int)ceil((strtotime($endDate) - strtotime($startDate)) / 86400) + 1;
      $this->exec(
        "INSERT INTO leave_requests (employee_id,leave_type,start_date,end_date,days,reason,status,created_at) VALUES (?,?,?,?,?,?,'Pending',NOW())",
        [$empId, $leaveType, $startDate, $endDate, $days, $reason]
      );
      $lid = $this->lastId();
      $this->ok(['leave_id' => $lid, 'days' => $days], 'Leave application submitted');
    } else {
      $this->ok(['leave_id' => rand(100, 999), 'demo' => true], 'Demo: Leave applied');
    }
  }

  public function approveLeave(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['leave_id'] ?? 0);
    if (!$id) {
      $this->fail('Leave ID required');
      return;
    }
    if ($this->db) {
      $this->exec(
        "UPDATE leave_requests SET status='Approved', approved_by=?, approved_at=NOW() WHERE id=?",
        [Session::getUser()['id'] ?? 1, $id]
      );
      $this->ok(['leave_id' => $id], 'Leave approved');
    } else {
      $this->ok(['leave_id' => $id, 'demo' => true], 'Demo: Leave approved');
    }
  }

  public function rejectLeave(): void
  {
    $this->guardApi();
    $b      = $this->body();
    $id     = (int)($b['id'] ?? $b['leave_id'] ?? 0);
    $reason = trim($b['reason'] ?? '');
    if (!$id) {
      $this->fail('Leave ID required');
      return;
    }
    if ($this->db) {
      $this->exec("UPDATE leave_requests SET status='Rejected', rejection_reason=? WHERE id=?", [$reason, $id]);
      $this->ok(['leave_id' => $id], 'Leave rejected');
    } else {
      $this->ok(['leave_id' => $id, 'demo' => true], 'Demo: Leave rejected');
    }
  }

  // ═══════════════ PAYROLL ═════════════════════════════════════

  public function processPayroll(): void
  {
    $this->guardApi();
    $b     = $this->body();
    $empId = (int)($b['employee_id'] ?? 0);
    $month = trim($b['month'] ?? date('Y-m'));
    if (!$empId) {
      $this->fail('Employee ID required');
      return;
    }

    if ($this->db) {
      $emp = $this->qOne("SELECT * FROM employees WHERE id=?", [$empId]);
      if (!$emp) {
        $this->fail('Employee not found');
        return;
      }
      $basic   = (float)($emp['basic_salary'] ?? 0);
      $tax     = round($basic * 0.15, 2);
      $pension = round($basic * 0.07, 2);
      $net     = $basic - $tax - $pension;
      $ref     = 'PAY-' . strtoupper(substr(md5(uniqid()), 0, 8));
      $this->exec(
        "INSERT INTO payroll (employee_id,pay_month,basic_salary,tax_deduction,pension_deduction,net_salary,reference,status,paid_at,created_at)
        VALUES (?,?,?,?,?,?,?,'Paid',NOW(),NOW())",
        [$empId, $month, $basic, $tax, $pension, $net, $ref]
      );
      $pid = $this->lastId();
      $this->ok(['payroll_id' => $pid, 'reference' => $ref, 'net_salary' => $net, 'tax' => $tax, 'pension' => $pension], 'Payroll processed');
    } else {
      $basic = 25000;
      $net = round($basic * 0.78, 2);
      $this->ok(['demo' => true, 'net_salary' => $net, 'reference' => 'PAY-DEMO'], 'Demo: Payroll processed');
    }
  }

  public function processAllPayroll(): void
  {
    $this->guardApi();
    $b     = $this->body();
    $month = trim($b['month'] ?? date('Y-m'));
    if ($this->db) {
      $emps = $this->q("SELECT id,basic_salary FROM employees WHERE status='Active'");
      $count = 0;
      foreach ($emps as $emp) {
        $basic = $emp['basic_salary'];
        $tax = round($basic * 0.15, 2);
        $pension = round($basic * 0.07, 2);
        $net = $basic - $tax - $pension;
        $ref = 'PAY-' . strtoupper(substr(md5(uniqid()), 0, 6));
        $exists = $this->qOne("SELECT id FROM payroll WHERE employee_id=? AND pay_month=?", [$emp['id'], $month]);
        if (!$exists) {
          $this->exec(
            "INSERT INTO payroll (employee_id,pay_month,basic_salary,tax_deduction,pension_deduction,net_salary,reference,status,paid_at,created_at) VALUES (?,?,?,?,?,?,?,'Paid',NOW(),NOW())",
            [$emp['id'], $month, $basic, $tax, $pension, $net, $ref]
          );
          $count++;
        }
      }
      $this->ok(['processed' => $count, 'month' => $month], "$count payslips processed for $month");
    } else {
      $this->ok(['processed' => 42, 'month' => $month, 'demo' => true], 'Demo: All payroll processed');
    }
  }

  // ═══════════════ NOTIFICATIONS ═══════════════════════════════

  public function sendNotification(): void
  {
    $this->guardApi();
    $b       = $this->body();
    $title   = trim($b['title']   ?? '');
    $message = trim($b['message'] ?? '');
    $type    = trim($b['type']    ?? 'system');
    $custId  = (int)($b['customer_id'] ?? 0);

    if (!$title || !$message) {
      $this->fail('Title and message required');
      return;
    }

    if ($this->db) {
      if ($custId) {
        $this->exec(
          "INSERT INTO notifications (customer_id,type,title,message,is_read,created_at) VALUES (?,?,?,?,0,NOW())",
          [$custId, $type, $title, $message]
        );
      } else {
        // Broadcast to all customers
        $custs = $this->q("SELECT id FROM customers WHERE status='Active' LIMIT 1000");
        foreach ($custs as $c) {
          $this->exec(
            "INSERT INTO notifications (customer_id,type,title,message,is_read,created_at) VALUES (?,?,?,?,0,NOW())",
            [$c['id'], $type, $title, $message]
          );
        }
      }
      $this->ok([], 'Notification sent');
    } else {
      $this->ok(['demo' => true], 'Demo: Notification sent');
    }
  }

  public function markNotificationRead(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['notification_id'] ?? 0);
    if ($this->db && $id) {
      $this->exec("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=?", [$id]);
    }
    $this->ok(['notification_id' => $id], 'Marked as read');
  }

  public function markAllNotificationsRead(): void
  {
    $this->guardApi();
    $b     = $this->body();
    $custId = (int)($b['customer_id'] ?? 0);
    if ($this->db) {
      $where = $custId ? 'customer_id=?' : '1=1';
      $params = $custId ? [$custId] : [];
      $this->exec("UPDATE notifications SET is_read=1, read_at=NOW() WHERE is_read=0 AND $where", $params);
    }
    $this->ok([], 'All notifications marked as read');
  }

  // ═══════════════ COMPLAINTS ══════════════════════════════════

  public function createComplaint(): void
  {
    $this->guardApi();
    $b        = $this->body();
    $custId   = (int)($b['customer_id'] ?? 0);
    $category = trim($b['category']    ?? 'General');
    $subject  = trim($b['subject']     ?? '');
    $desc     = trim($b['description'] ?? '');
    $priority = trim($b['priority']    ?? 'Medium');

    if (!$subject) {
      $this->fail('Subject is required');
      return;
    }

    $ticketNo = 'CMP-' . date('Y') . '-' . str_pad((string)rand(100, 9999), 4, '0', STR_PAD_LEFT);

    if ($this->db) {
      $this->exec(
        "INSERT INTO complaints (customer_id,ticket_no,category,subject,description,priority,status,created_at,updated_at) VALUES (?,?,?,?,?,?,'Open',NOW(),NOW())",
        [$custId, $ticketNo, $category, $subject, $desc, $priority]
      );
      $cid = $this->lastId();
      $this->ok(['complaint_id' => $cid, 'ticket_no' => $ticketNo], 'Complaint submitted: ' . $ticketNo);
    } else {
      $this->ok(['ticket_no' => $ticketNo, 'demo' => true], 'Demo: Complaint submitted: ' . $ticketNo);
    }
  }

  public function resolveComplaint(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['id'] ?? $b['complaint_id'] ?? 0);
    $resolution = trim($b['resolution'] ?? '');
    if (!$id) {
      $this->fail('Complaint ID required');
      return;
    }
    if ($this->db) {
      $this->exec("UPDATE complaints SET status='Resolved', response=?, updated_at=NOW() WHERE id=?", [$resolution, $id]);
      $this->ok(['complaint_id' => $id], 'Complaint resolved');
    } else {
      $this->ok(['complaint_id' => $id, 'demo' => true], 'Demo: Complaint resolved');
    }
  }

  // ═══════════════ SETTINGS ════════════════════════════════════

  public function saveSettings(): void
  {
    $this->adminOnly();
    $b = $this->body();
    if ($this->db) {
      foreach ($b as $key => $value) {
        if (is_string($key) && strlen($key) <= 100) {
          $exists = $this->qOne("SELECT id FROM settings WHERE `key`=?", [$key]);
          if ($exists) {
            $this->exec("UPDATE settings SET `value`=?, updated_at=NOW() WHERE `key`=?", [(string)$value, $key]);
          } else {
            $this->exec("INSERT INTO settings (`key`,`value`,`group`,created_at,updated_at) VALUES (?,?,?,NOW(),NOW())", [$key, (string)$value, 'general']);
          }
        }
      }
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'SETTINGS_UPDATED','Settings','System settings updated',?,NOW())",
        [$u['id'] ?? 1, $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok([], 'Settings saved successfully');
    } else {
      $this->ok(['demo' => true], 'Demo: Settings saved');
    }
  }

  public function savePermissions(): void
  {
    $this->adminOnly();
    $b = $this->body();
    if ($this->db) {
      foreach ((array)($b['permissions'] ?? []) as $roleId => $perms) {
        foreach ((array)$perms as $perm => $granted) {
          $exists = $this->qOne("SELECT id FROM role_permissions WHERE role_id=? AND permission=?", [(int)$roleId, $perm]);
          if ($exists) {
            $this->exec("UPDATE role_permissions SET granted=? WHERE role_id=? AND permission=?", [(int)(bool)$granted, (int)$roleId, $perm]);
          } else {
            $this->exec("INSERT INTO role_permissions (role_id,permission,granted) VALUES (?,?,?)", [(int)$roleId, $perm, (int)(bool)$granted]);
          }
        }
      }
      $this->ok([], 'Permissions saved');
    } else {
      $this->ok(['demo' => true], 'Demo: Permissions saved');
    }
  }  // end savePermissions
  // ─── POST /api/appointments/confirm ─────────────────────────
  public function confirmAppointment(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['appointment_id'] ?? $b['id'] ?? 0);
    if (!$id) {
      $this->fail('Appointment ID required');
      return;
    }
    if ($this->db) {
      $this->exec("UPDATE appointments SET status='Confirmed', updated_at=NOW() WHERE id=?", [$id]);
      $u = Session::getUser();
      $this->exec(
        "INSERT INTO audit_logs (user_id,action,module,detail,ip,created_at) VALUES (?,'APPOINTMENT_CONFIRMED','Appointments',?,?,NOW())",
        [$u['id'] ?? 1, "Appointment #$id confirmed", $_SERVER['REMOTE_ADDR'] ?? '']
      );
      $this->ok(['appointment_id' => $id], 'Appointment confirmed');
    } else {
      $this->ok(['appointment_id' => $id, 'demo' => true], 'Demo: Appointment confirmed');
    }
  }

  // ─── POST /api/appointments/cancel ──────────────────────────
  public function cancelAppointment(): void
  {
    $this->guardApi();
    $b  = $this->body();
    $id = (int)($b['appointment_id'] ?? $b['id'] ?? 0);
    if (!$id) {
      $this->fail('Appointment ID required');
      return;
    }
    if ($this->db) {
      $this->exec("UPDATE appointments SET status='Cancelled', updated_at=NOW() WHERE id=?", [$id]);
      $this->ok(['appointment_id' => $id], 'Appointment cancelled');
    } else {
      $this->ok(['appointment_id' => $id, 'demo' => true], 'Demo: Appointment cancelled');
    }
  }

  // ─── GET /api/pending-count ──────────────────────────────────
  // Returns total pending request count for the navbar badge live refresh.

  public function getPendingCount(): void
  {
    $this->guardApi();
    header('Content-Type: application/json');

    if ($this->db) {
      $loans  = (int)($this->qOne("SELECT COUNT(*) AS c FROM loans WHERE status='Pending'")['c'] ?? 0);
      $appts  = (int)($this->qOne("SELECT COUNT(*) AS c FROM appointments WHERE status='Pending'")['c'] ?? 0);
      $leave  = (int)($this->qOne("SELECT COUNT(*) AS c FROM leave_requests WHERE status='Pending'")['c'] ?? 0);
      $kyc    = (int)($this->qOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status IN('Pending','Under_Review')")['c'] ?? 0);
      $compl  = (int)($this->qOne("SELECT COUNT(*) AS c FROM complaints WHERE status='Open'")['c'] ?? 0);
      $total  = $loans + $appts + $leave + $kyc + $compl;
      $this->ok(['count' => $total, 'breakdown' => compact('loans', 'appts', 'leave', 'kyc', 'compl')]);
    } else {
      $this->ok(['count' => 5, 'demo' => true]);
    }
  }

  // ─── GET /api/complaints ────────────────────────────────────────────────
  public function getComplaints(): void
  {
    $this->guardApi();
    $status  = trim($_GET['status']  ?? '');
    $perPage = min((int)($_GET['per_page'] ?? 200), 500);

    if ($this->db) {
      $where  = '1=1';
      $params = [];
      if ($status) { $where .= ' AND c.status=?'; $params[] = $status; }
      $params[] = $perPage;
      $rows = $this->q(
        "SELECT c.*, CONCAT(cu.first_name,' ',cu.last_name) AS customer_name
         FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id
         WHERE $where ORDER BY c.created_at DESC LIMIT ?",
        $params
      );
      $this->ok($rows);
      return;
    }
    // Demo fallback
    $now = time();
    $this->ok([
      ['id'=>1,'ticket_no'=>'CMP-2026-0001','customer_name'=>'Abebe Bekele','category'=>'Transaction Issue','subject'=>'Wrong debit amount','priority'=>'High',  'status'=>'Open',       'created_at'=>date('Y-m-d H:i:s',$now-3600)],
      ['id'=>2,'ticket_no'=>'CMP-2026-0002','customer_name'=>'Tigist Haile', 'category'=>'Card Issue',       'subject'=>'ATM card blocked',   'priority'=>'Urgent','status'=>'Open',       'created_at'=>date('Y-m-d H:i:s',$now-900)],
      ['id'=>3,'ticket_no'=>'CMP-2026-0003','customer_name'=>'Solomon Girma','category'=>'Account Issue',    'subject'=>'Cannot access online banking','priority'=>'Medium','status'=>'In Progress','created_at'=>date('Y-m-d H:i:s',$now-86400)],
      ['id'=>4,'ticket_no'=>'CMP-2026-0004','customer_name'=>'Hanna Tadesse','category'=>'Loan Issue',       'subject'=>'Incorrect interest calculation','priority'=>'Low','status'=>'Resolved','created_at'=>date('Y-m-d H:i:s',$now-172800)],
    ]);
  }
}