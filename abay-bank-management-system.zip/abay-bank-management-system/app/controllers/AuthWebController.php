<?php

/**
 * Abay Bank — Auth Web Controller
 * Handles login / logout / register form pages and POST processing.
 */

declare(strict_types=1);

namespace Web\Controllers;

use Web\Core\View;
use Web\Core\Auth;
use Web\Core\Session;

class AuthWebController
{
  /* ── GET /login ── */
  public function loginForm(): void
  {
    if (Session::isLoggedIn()) {
      View::redirect('dashboard');
    }
    $error   = Session::flash('error');
    $info    = Session::flash('info');
    $authMode = 'demo'; // default; updated after successful DB login
    View::render('auth/login', compact('error', 'info', 'authMode'), null);
  }

  /* ── POST /login ── */
  public function loginPost(): void
  {
    // CSRF check
    if (!Session::verifyCsrf($_POST['_csrf'] ?? '')) {
      Session::flash('error', 'Invalid form token. Please try again.');
      View::redirect('login');
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
      Session::flash('error', 'Please enter both username and password.');
      View::redirect('login');
    }

    $result = Auth::login($username, $password);

    if ($result['success']) {
      // Redirect to originally requested page or dashboard
      $redirect = Session::flash('redirect_after_login') ?? 'dashboard';
      View::redirect(ltrim(str_replace(APP_URL, '', $redirect), '/'));
    } else {
      Session::flash('error', $result['message']);
      View::redirect('login');
    }
  }

  /* ── GET /logout ── */
  public function logout(): void
  {
    Auth::logout();
  }

  /* ── GET /customer/login ── */
  public function customerLoginForm(): void
  {
    if (Session::isCustomerLoggedIn()) {
      View::redirect('customer/dashboard');
    }
    $error = Session::flash('error');
    $info  = Session::flash('info');
    View::render('auth/customer-login', compact('error', 'info'), null);
  }

  /* ── POST /customer/login ── */
  public function customerLoginPost(): void
  {
    if (!Session::verifyCsrf($_POST['_csrf'] ?? '')) {
      Session::flash('error', 'Invalid form token.');
      View::redirect('customer/login');
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
      Session::flash('error', 'Please enter username and password.');
      View::redirect('customer/login');
    }

    $result = Auth::customerLogin($username, $password);

    if ($result['success']) {
      View::redirect('customer/dashboard');
    } else {
      Session::flash('error', $result['message']);
      View::redirect('customer/login');
    }
  }

  /* ── GET /customer/logout ── */
  public function customerLogout(): void
  {
    Auth::customerLogout();
  }

  /* ── GET /forgot-password ── */
  public function forgotPasswordForm(): void
  {
    $message = Session::flash('message');
    View::render('auth/forgot-password', compact('message'), null);
  }

  /* ══════════════════════════════════════════════════
       EMPLOYEE PORTAL — Sign In / Sign Up / Logout
    ══════════════════════════════════════════════════ */

  /* ── GET /employee/login ── */
  public function employeeLoginForm(): void
  {
    if (Session::isEmployeeLoggedIn()) {
      View::redirect('employee/portal');
    }
    $error   = Session::flash('error');
    $success = Session::flash('success');
    View::render('auth/employee-login', compact('error', 'success'), null);
  }

  /* ── POST /employee/login ── */
  public function employeeLoginPost(): void
  {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
      Session::flash('error', 'Username and password are required.');
      View::redirect('employee/login');
    }

    // Demo employees
    $demoEmployees = [
      'abebe.girma'   => ['pwd' => 'Employee@1234', 'data' => ['id' => 1, 'employee_number' => 'EMP-000001', 'first_name' => 'Abebe', 'last_name' => 'Girma', 'email' => 'abebe.girma@abaybank.com', 'position' => 'Senior Teller', 'dept_name' => 'Operations', 'branch_name' => 'Head Office', 'basic_salary' => 18500, 'hire_date' => '2019-03-01']],
      'tigist.haile'  => ['pwd' => 'Employee@1234', 'data' => ['id' => 2, 'employee_number' => 'EMP-000002', 'first_name' => 'Tigist', 'last_name' => 'Haile', 'email' => 'tigist.haile@abaybank.com', 'position' => 'Loan Officer', 'dept_name' => 'Loans', 'branch_name' => 'Bole Branch', 'basic_salary' => 22000, 'hire_date' => '2020-07-15']],
      'samuel.bekele' => ['pwd' => 'Employee@1234', 'data' => ['id' => 3, 'employee_number' => 'EMP-000003', 'first_name' => 'Samuel', 'last_name' => 'Bekele', 'email' => 'samuel.bekele@abaybank.com', 'position' => 'IT Technician', 'dept_name' => 'IT', 'branch_name' => 'Head Office', 'basic_salary' => 25000, 'hire_date' => '2021-01-10']],
    ];

    $result = null;

    // Try DB first
    try {
      $db   = \App\Config\Database::getInstance()->getConnection();
      $stmt = $db->prepare(
        "SELECT e.*, eu.password AS emp_password, eu.username,
                        d.name AS dept_name, b.branch_name
                 FROM employee_users eu
                 JOIN employees e ON e.id = eu.employee_id
                 LEFT JOIN departments d ON d.id = e.department_id
                 LEFT JOIN branches b ON b.id = e.branch_id
                 WHERE eu.username = ? OR eu.email = ?
                 LIMIT 1"
      );
      $stmt->execute([$username, $username]);
      $row = $stmt->fetch(\PDO::FETCH_ASSOC);
      if ($row && password_verify($password, $row['emp_password'])) {
        $result = $row;
        unset($result['emp_password']);
      }
    } catch (\Throwable) {
      // DB offline — use demo
    }

    // Demo fallback
    if (!$result) {
      $key = strtolower(trim($username));
      $demo = $demoEmployees[$key] ?? null;
      if ($demo && $demo['pwd'] === $password) {
        $result = $demo['data'];
      }
    }

    if (!$result) {
      Session::flash('error', 'Invalid username or password. Try the demo credentials shown on the form.');
      View::redirect('employee/login');
    }

    Session::setEmployee($result);
    View::redirect('employee/portal');
  }

  /* ── POST /employee/register ── */
  public function employeeRegisterPost(): void
  {
    $firstName  = trim($_POST['first_name']  ?? '');
    $lastName   = trim($_POST['last_name']   ?? '');
    $employeeId = trim($_POST['employee_id'] ?? '');
    $email      = trim($_POST['email']       ?? '');
    $username   = trim($_POST['username']    ?? '');
    $password   = $_POST['password']         ?? '';
    $confirm    = $_POST['confirm_password'] ?? '';

    // Validate
    if (!$firstName || !$lastName || !$employeeId || !$email || !$username || !$password) {
      Session::flash('error', 'All fields are required.');
      View::redirect('employee/login?tab=signup');
    }
    if ($password !== $confirm) {
      Session::flash('error', 'Passwords do not match.');
      View::redirect('employee/login?tab=signup');
    }
    if (strlen($password) < 8) {
      Session::flash('error', 'Password must be at least 8 characters.');
      View::redirect('employee/login?tab=signup');
    }

    // Try to verify Employee ID in DB
    $empRecord = null;
    try {
      $db = \App\Config\Database::getInstance()->getConnection();

      // Check if username already taken
      $chk = $db->prepare("SELECT id FROM employee_users WHERE username=? OR email=? LIMIT 1");
      $chk->execute([$username, $email]);
      if ($chk->fetch()) {
        Session::flash('error', 'Username or email already registered.');
        View::redirect('employee/login?tab=signup');
      }

      // Find employee record
      $stmt = $db->prepare("SELECT id FROM employees WHERE employee_number=? AND status='Active' LIMIT 1");
      $stmt->execute([$employeeId]);
      $empRecord = $stmt->fetch(\PDO::FETCH_ASSOC);

      if ($empRecord) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $db->prepare(
          "INSERT INTO employee_users (employee_id, username, email, password, created_at)
                     VALUES (?, ?, ?, ?, NOW())"
        )->execute([$empRecord['id'], $username, $email, $hashed]);
      }
    } catch (\Throwable) {
      // DB offline — demo mode, allow registration
      $empRecord = ['id' => 99];
    }

    if (!$empRecord) {
      Session::flash('error', 'Employee ID not found in records. Please check your ID badge or contact HR.');
      View::redirect('employee/login?tab=signup');
    }

    Session::flash('success', 'Account created successfully! You can now sign in.');
    View::redirect('employee/login');
  }

  /* ── GET /employee/logout ── */
  public function employeeLogout(): void
  {
    Session::destroyEmployee();
    View::redirect('employee/login');
  }

  /* ── GET /employee/portal ── */
  public function employeePortal(): void
  {
    if (!Session::isEmployeeLoggedIn()) {
      Session::flash('error', 'Please sign in to access your employee portal.');
      View::redirect('employee/login');
    }

    $employee = Session::getEmployee();

    // Try to get fresh data from DB
    try {
      $db = \App\Config\Database::getInstance()->getConnection();
      $fresh = $db->prepare(
        "SELECT e.*, d.name AS dept_name, b.branch_name
                 FROM employees e
                 LEFT JOIN departments d ON d.id = e.department_id
                 LEFT JOIN branches b ON b.id = e.branch_id
                 WHERE e.id = ?
                 LIMIT 1"
      )->execute([$employee['id'] ?? 0]);
      $row = null;
      if ($fresh) {
        // re-query since execute returns bool
        $stmt = $db->prepare("SELECT e.*, d.name AS dept_name, b.branch_name FROM employees e LEFT JOIN departments d ON d.id=e.department_id LEFT JOIN branches b ON b.id=e.branch_id WHERE e.id=? LIMIT 1");
        $stmt->execute([$employee['id'] ?? 0]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
      }
      if ($row) $employee = array_merge($employee, $row);
    } catch (\Throwable) {
      // use session data
    }

    // Render standalone page (no admin layout)
    extract(['employee' => $employee]);
    include VIEW_PATH . '/employee/portal-dashboard.php';
    exit;
  }
}
