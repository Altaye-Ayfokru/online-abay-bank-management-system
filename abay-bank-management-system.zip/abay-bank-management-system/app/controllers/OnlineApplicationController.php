<?php

/**
 * Abay Bank — Online Application Controller
 * Handles public online account opening with Fayda National ID verification,
 * document upload, and admin review workflow.
 */

declare(strict_types=1);

namespace Web\Controllers;

use Web\Core\Auth;
use Web\Core\View;
use Web\Core\Session;
use App\Config\Database;
use PDO;

class OnlineApplicationController
{
  private ?PDO $db = null;

  // Banks available for inter-bank transfers
  public const BANKS = [
    'CBE'       => 'Commercial Bank of Ethiopia',
    'DBE'       => 'Development Bank of Ethiopia',
    'DASHEN'    => 'Dashen Bank',
    'AWASH'     => 'Awash Bank',
    'ABYSSINIA' => 'Bank of Abyssinia',
    'WEGAGEN'   => 'Wegagen Bank',
    'NIBE'      => 'NIB International Bank',
    'OROMIA'    => 'Oromia Bank',
    'ZEMEN'     => 'Zemen Bank',
    'HIBRET'    => 'Hibret Bank (United Bank)',
    'LION'      => 'Lion International Bank',
    'BERHAN'    => 'Berhan Bank',
    'ABAY'      => 'Abay Bank S.C.',
    'ADDIS'     => 'Addis International Bank',
    'ENAT'      => 'Enat Bank',
    'TSEDEY'    => 'Tsedey Bank',
    'TELEBIRR'  => 'Telebirr (Ethio Telecom)',
    'MPESA'     => 'M-Pesa Ethiopia',
  ];

  public function __construct()
  {
    try {
      $this->db = Database::getInstance()->getConnection();
    } catch (\Throwable) {
      $this->db = null;
    }
  }

  // ── Helpers ──────────────────────────────────────────────────
  private function query(string $sql, array $p = []): array
  {
    if (!$this->db) return [];
    try {
      $s = $this->db->prepare($sql);
      $s->execute($p);
      return $s->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable) {
      return [];
    }
  }

  private function queryOne(string $sql, array $p = []): ?array
  {
    $r = $this->query($sql, $p);
    return $r[0] ?? null;
  }

  private function execute(string $sql, array $p = []): bool
  {
    if (!$this->db) return false;
    try {
      return $this->db->prepare($sql)->execute($p);
    } catch (\Throwable) {
      return false;
    }
  }

  private function getBranches(): array
  {
    return $this->query("SELECT id, code, name, city FROM branches WHERE status='Active' ORDER BY name") ?: [
      ['id' => 1, 'code' => 'BR-001', 'name' => 'Addis Ababa Main', 'city' => 'Addis Ababa'],
      ['id' => 2, 'code' => 'BR-002', 'name' => 'Bole Branch', 'city' => 'Addis Ababa'],
      ['id' => 10, 'code' => 'BR-010', 'name' => 'Alem Ketema Branch', 'city' => 'Alem Ketema'],
    ];
  }

  private function generateRef(string $prefix = 'APP'): string
  {
    return $prefix . '-' . strtoupper(substr(md5(uniqid((string)mt_rand(), true)), 0, 8)) . '-' . date('Ymd');
  }

  // ── Public: show online account opening form ─────────────────
  public function showForm(): void
  {
    $branches = $this->getBranches();
    View::render('online/apply', [
      'pageTitle' => 'Open Account Online — ' . APP_NAME,
      'branches'  => $branches,
      'banks'     => self::BANKS,
    ], null); // null = no staff layout — this is a public page
  }

  // ── Public: submit application ────────────────────────────────
  public function submitForm(): void
  {
    // CSRF verification
    $token = $_POST['_csrf'] ?? '';
    if (!Session::verifyCsrf($token)) {
      Session::flash('error', 'Invalid form submission. Please try again.');
      View::redirect('online/apply');
    }

    $errors = $this->validateApplication($_POST);
    if ($errors) {
      View::render('online/apply', [
        'pageTitle' => 'Open Account Online — ' . APP_NAME,
        'branches'  => $this->getBranches(),
        'banks'     => self::BANKS,
        'errors'    => $errors,
        'old'       => $_POST,
      ], null);
      return;
    }

    // Handle file uploads
    $uploadDir   = BASE_PATH . '/backend/storage/kyc_docs/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $selfie   = $this->uploadFile('selfie',   $uploadDir, ['image/jpeg', 'image/png']);
    $idFront  = $this->uploadFile('id_front', $uploadDir, ['image/jpeg', 'image/png', 'application/pdf']);
    $idBack   = $this->uploadFile('id_back',  $uploadDir, ['image/jpeg', 'image/png']);

    $ref = $this->generateRef('APP');

    // Simulate Fayda verification (in production: call Fayda API)
    $faydaResult = $this->verifyFayda(
      $_POST['fayda_id'],
      $_POST['national_id'],
      $_POST['first_name'],
      $_POST['last_name'],
      $_POST['date_of_birth']
    );

    $this->execute(
      "INSERT INTO online_applications
             (ref_number, first_name, last_name, email, phone, national_id, fayda_id,
              date_of_birth, gender, address, city, region, subcity, kebele,
              occupation, monthly_income, account_type, preferred_branch, initial_deposit,
              selfie_path, id_front_path, id_back_path,
              fayda_verified, fayda_verified_at, fayda_response,
              status, ip_address, user_agent)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      [
        $ref,
        trim($_POST['first_name']),
        trim($_POST['last_name']),
        strtolower(trim($_POST['email'])),
        trim($_POST['phone']),
        strtoupper(trim($_POST['national_id'])),
        strtoupper(trim($_POST['fayda_id'])),
        $_POST['date_of_birth'],
        $_POST['gender'],
        trim($_POST['address'] ?? ''),
        trim($_POST['city'] ?? ''),
        trim($_POST['region'] ?? ''),
        trim($_POST['subcity'] ?? ''),
        trim($_POST['kebele'] ?? ''),
        trim($_POST['occupation'] ?? ''),
        !empty($_POST['monthly_income']) ? (float)$_POST['monthly_income'] : null,
        $_POST['account_type'],
        !empty($_POST['preferred_branch']) ? (int)$_POST['preferred_branch'] : null,
        !empty($_POST['initial_deposit']) ? (float)$_POST['initial_deposit'] : 0.00,
        $selfie,
        $idFront,
        $idBack,
        $faydaResult['verified'] ? 1 : 0,
        $faydaResult['verified'] ? date('Y-m-d H:i:s') : null,
        json_encode($faydaResult),
        $faydaResult['verified'] ? 'Pending' : 'Pending',
        $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
        substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
      ]
    );

    // Get the application id for fayda log
    $app = $this->queryOne("SELECT id FROM online_applications WHERE ref_number=?", [$ref]);
    if ($app) {
      $this->execute(
        "INSERT INTO fayda_verifications (application_id, fayda_id, national_id, full_name, dob, face_match_score, id_match_score, result, raw_response, ip_address)
                 VALUES (?,?,?,?,?,?,?,?,?,?)",
        [
          $app['id'],
          strtoupper(trim($_POST['fayda_id'])),
          strtoupper(trim($_POST['national_id'])),
          trim($_POST['first_name']) . ' ' . trim($_POST['last_name']),
          $_POST['date_of_birth'],
          $faydaResult['face_score'],
          $faydaResult['id_score'],
          $faydaResult['verified'] ? 'Verified' : 'Partial',
          json_encode($faydaResult),
          $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
        ]
      );
    }

    View::render('online/success', [
      'pageTitle'    => 'Application Submitted — ' . APP_NAME,
      'ref'          => $ref,
      'fayda_result' => $faydaResult,
    ], null);
  }

    // ── Fayda simulation ─────────────────────────────────────────
  /**
   * In production: call the official Fayda API (api.fayda.et)
   * Here we simulate the response based on ID format.
   */
  private function verifyFayda(string $faydaId, string $nationalId, string $firstName, string $lastName, string $dob): array
  {
    // Simulate: IDs starting with 'FYD' pass verification with high score
    $faceScore = rand(82, 99);
    $idScore   = rand(88, 100);
    $verified  = strlen($faydaId) >= 10 && strlen($nationalId) >= 6;

    return [
      'verified'   => $verified,
      'face_score' => $faceScore,
      'id_score'   => $idScore,
      'fayda_id'   => $faydaId,
      'matched_name' => $firstName . ' ' . $lastName,
      'matched_dob'  => $dob,
      'source'     => 'fayda_sim_v1',
      'timestamp'  => date('c'),
      'message'    => $verified ? 'Identity verified via Fayda system' : 'Fayda ID format invalid',
    ];
  }

  // ── File upload helper ────────────────────────────────────────
  private function uploadFile(string $field, string $dir, array $allowedMimes): ?string
  {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
    $file = $_FILES[$field];
    if (!in_array($file['type'], $allowedMimes, true)) return null;
    if ($file['size'] > 5 * 1024 * 1024) return null; // 5MB max

    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = $field . '_' . uniqid() . '.' . $ext;
    $dest     = $dir . $filename;
    if (move_uploaded_file($file['tmp_name'], $dest)) {
      return 'backend/storage/kyc_docs/' . $filename;
    }
    return null;
  }

  // ── Validation ───────────────────────────────────────────────
  private function validateApplication(array $data): array
  {
    $e = [];
    if (empty($data['first_name']))  $e['first_name']  = 'First name is required.';
    if (empty($data['last_name']))   $e['last_name']   = 'Last name is required.';
    if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL))
      $e['email'] = 'Valid email is required.';
    if (empty($data['phone']))       $e['phone']       = 'Phone number is required.';
    if (empty($data['national_id'])) $e['national_id'] = 'National ID is required.';
    if (empty($data['fayda_id']))    $e['fayda_id']    = 'Fayda ID is required.';
    if (strlen($data['fayda_id'] ?? '') < 10) $e['fayda_id'] = 'Fayda ID must be at least 10 characters.';
    if (empty($data['date_of_birth'])) $e['date_of_birth'] = 'Date of birth is required.';
    if (empty($data['gender']))      $e['gender']      = 'Gender is required.';
    if (empty($data['account_type'])) $e['account_type'] = 'Account type is required.';
    if (isset($data['initial_deposit']) && (float)$data['initial_deposit'] < 100)
      $e['initial_deposit'] = 'Minimum initial deposit is ETB 100.';

    // Check for duplicate email/national_id
    if ($this->db && empty($e['email'])) {
      $exists = $this->queryOne(
        "SELECT id FROM online_applications WHERE email=? AND status NOT IN('Rejected') LIMIT 1",
        [strtolower(trim($data['email']))]
      );
      if ($exists) $e['email'] = 'An application with this email already exists.';
    }
    if ($this->db && empty($e['national_id'])) {
      $exists = $this->queryOne(
        "SELECT id FROM customers WHERE national_id=? LIMIT 1",
        [strtoupper(trim($data['national_id']))]
      );
      if ($exists) $e['national_id'] = 'This National ID is already registered.';
    }
    return $e;
  }

  // ── Admin: list all applications ──────────────────────────────
  public function listApplications(): void
  {
    Auth::guard(['Admin', 'Manager', 'Teller']);
    $status = $_GET['status'] ?? 'all';
    $sql = "SELECT a.*, b.name AS branch_name FROM online_applications a
                LEFT JOIN branches b ON b.id = a.preferred_branch";
    if ($status !== 'all') $sql .= " WHERE a.status = " . $this->db?->quote($status);
    $sql .= " ORDER BY a.created_at DESC LIMIT 300";
    $applications = $this->query($sql);
    $stats = [
      'total'       => (int)($this->queryOne("SELECT COUNT(*) AS c FROM online_applications")['c'] ?? 0),
      'pending'     => (int)($this->queryOne("SELECT COUNT(*) AS c FROM online_applications WHERE status='Pending'")['c'] ?? 0),
      'under_review' => (int)($this->queryOne("SELECT COUNT(*) AS c FROM online_applications WHERE status='Under Review'")['c'] ?? 0),
      'approved'    => (int)($this->queryOne("SELECT COUNT(*) AS c FROM online_applications WHERE status='Approved'")['c'] ?? 0),
      'completed'   => (int)($this->queryOne("SELECT COUNT(*) AS c FROM online_applications WHERE status='Completed'")['c'] ?? 0),
    ];
    View::render('online/admin-list', [
      'pageTitle'    => 'Online Applications — ' . APP_NAME,
      'applications' => $applications,
      'stats'        => $stats,
      'filter'       => $status,
      'user'         => Session::getUser(),
      'dbOnline'     => $this->db !== null,
    ]);
  }

  // ── Admin: review a single application ───────────────────────
  public function reviewApplication(): void
  {
    Auth::guard(['Admin', 'Manager']);
    $id  = (int)($_GET['id'] ?? 0);
    $app = $this->queryOne(
      "SELECT a.*, b.name AS branch_name FROM online_applications a
             LEFT JOIN branches b ON b.id=a.preferred_branch WHERE a.id=?",
      [$id]
    );
    if (!$app) {
      View::redirect('online/applications');
    }

    $faydaLogs = $this->query(
      "SELECT * FROM fayda_verifications WHERE application_id=? ORDER BY created_at DESC",
      [$id]
    );
    View::render('online/admin-review', [
      'pageTitle' => 'Review Application #' . $id . ' — ' . APP_NAME,
      'app'       => $app,
      'fayda'     => $faydaLogs,
      'branches'  => $this->getBranches(),
      'user'      => Session::getUser(),
      'dbOnline'  => $this->db !== null,
    ]);
  }

  // ── Admin: approve application and create customer+account ───
  public function approveApplication(): void
  {
    Auth::guard(['Admin', 'Manager']);
    if (!Session::verifyCsrf($_POST['_csrf'] ?? '')) {
      Session::flash('error', 'CSRF verification failed.');
      View::redirect('online/applications');
    }

    $id         = (int)($_POST['app_id'] ?? 0);
    $branchId   = (int)($_POST['branch_id'] ?? 1);
    $app        = $this->queryOne("SELECT * FROM online_applications WHERE id=? AND status IN('Pending','Under Review')", [$id]);
    if (!$app) {
      Session::flash('error', 'Application not found or already processed.');
      View::redirect('online/applications');
    }

    try {
      $this->db->beginTransaction();

      // Generate customer number
      $custNo = 'CUS' . date('Y') . str_pad((string)($id + 1000), 6, '0', STR_PAD_LEFT);

      // Create customer
      $this->execute(
        "INSERT INTO customers (customer_number, first_name, last_name, email, phone, national_id, date_of_birth, gender, address, city, region, subcity, kebele, occupation, monthly_income, branch_id, status, kyc_status, kyc_verified_at, kyc_verified_by, photo_path, created_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?,?,?)",
        [
          $custNo,
          $app['first_name'],
          $app['last_name'],
          $app['email'],
          $app['phone'],
          $app['national_id'],
          $app['date_of_birth'],
          $app['gender'],
          $app['address'],
          $app['city'],
          $app['region'],
          $app['subcity'],
          $app['kebele'],
          $app['occupation'],
          $app['monthly_income'],
          $branchId,
          'Active',
          $app['fayda_verified'] ? 'Verified' : 'Pending',
          Session::getUser()['id'],
          $app['selfie_path'],
          Session::getUser()['id'],
        ]
      );
      $customerId = (int)$this->db->lastInsertId();

      // Generate account number: branch(4) + type(2) + seq(10)
      $typeCode  = $app['account_type'] === 'Savings' ? '10' : ($app['account_type'] === 'Current' ? '20' : '30');
      $seq       = str_pad((string)($customerId + 10000), 10, '0', STR_PAD_LEFT);
      $acctNo    = str_pad((string)$branchId, 4, '0', STR_PAD_LEFT) . $typeCode . $seq;

      // Create account
      $this->execute(
        "INSERT INTO accounts (customer_id, branch_id, account_number, account_type, balance, interest_rate, status, opened_date, created_by)
                 VALUES (?,?,?,?,?,?,?,CURDATE(),?)",
        [
          $customerId,
          $branchId,
          $acctNo,
          $app['account_type'],
          $app['initial_deposit'],
          $app['account_type'] === 'Savings' ? 3.5 : ($app['account_type'] === 'Fixed Deposit' ? 8.5 : 0.0),
          'Active',
          Session::getUser()['id'],
        ]
      );
      $accountId = (int)$this->db->lastInsertId();

      // Log initial deposit as transaction if > 0
      if ($app['initial_deposit'] > 0) {
        $ref = 'DEP-ONLINE-' . strtoupper(substr(md5(uniqid()), 0, 8));
        $this->execute(
          "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, channel, status, created_by)
                     VALUES (?,?,?,?,?,?,?,?,?,?)",
          [
            $accountId,
            $ref,
            'Deposit',
            $app['initial_deposit'],
            0,
            $app['initial_deposit'],
            'Initial deposit — online account opening',
            'Online',
            'Completed',
            Session::getUser()['id']
          ]
        );
      }

      // Create customer portal login (username = email prefix)
      $username = strtolower(strstr($app['email'], '@', true));
      $pwdHash  = password_hash('Abay@' . substr($acctNo, -4), PASSWORD_BCRYPT, ['cost' => 12]);
      $this->execute(
        "INSERT IGNORE INTO customer_users (customer_id, username, email, password) VALUES (?,?,?,?)",
        [$customerId, $username, $app['email'], $pwdHash]
      );

      // Update application status
      $user = Session::getUser();
      $this->execute(
        "UPDATE online_applications SET status='Completed', customer_id=?, account_id=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?",
        [$customerId, $accountId, $user['id'], $id]
      );

      $this->db->commit();
      Session::flash('success', "Application approved. Customer #{$custNo} and account #{$acctNo} created.");
    } catch (\Throwable $ex) {
      $this->db?->rollBack();
      Session::flash('error', 'Failed to create account: ' . $ex->getMessage());
    }

    View::redirect('online/applications');
  }

  // ── Admin: reject application ─────────────────────────────────
  public function rejectApplication(): void
  {
    Auth::guard(['Admin', 'Manager']);
    if (!Session::verifyCsrf($_POST['_csrf'] ?? '')) {
      Session::flash('error', 'CSRF verification failed.');
      View::redirect('online/applications');
    }
    $id     = (int)($_POST['app_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Application rejected.');
    $user   = Session::getUser();
    $this->execute(
      "UPDATE online_applications SET status='Rejected', reject_reason=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?",
      [$reason, $user['id'], $id]
    );
    Session::flash('success', 'Application rejected.');
    View::redirect('online/applications');
  }

  // ── Inter-bank Transfer page (staff) ──────────────────────────
  public function interbankTransferPage(): void
  {
    Auth::guard(['Admin', 'Manager', 'Teller']);
    $accounts = $this->query(
      "SELECT a.id, a.account_number, a.account_type, a.balance,
                    CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM accounts a JOIN customers c ON c.id=a.customer_id
             WHERE a.status='Active' ORDER BY a.account_number LIMIT 500"
    );
    $recent = $this->query(
      "SELECT t.*, b.name AS dest_bank_name,
                    CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM interbank_transfers t
             JOIN customers c ON c.id=t.source_customer_id
             LEFT JOIN branches b ON b.code=t.dest_bank_code
             ORDER BY t.created_at DESC LIMIT 50"
    );
    View::render('transactions/interbank', [
      'pageTitle' => 'Inter-Bank Transfer — ' . APP_NAME,
      'accounts'  => $accounts,
      'banks'     => self::BANKS,
      'recent'    => $recent,
      'user'      => Session::getUser(),
      'dbOnline'  => $this->db !== null,
    ]);
  }

  // ── Inter-bank Transfer: process POST ────────────────────────
  public function processInterbankTransfer(): void
  {
    Auth::guard(['Admin', 'Manager', 'Teller']);
    if (!Session::verifyCsrf($_POST['_csrf'] ?? '')) {
      $this->jsonError('CSRF verification failed.');
    }

    $sourceAccId   = (int)($_POST['source_account_id'] ?? 0);
    $destBank      = strtoupper(trim($_POST['dest_bank_code'] ?? ''));
    $destAccNumber = trim($_POST['dest_account_number'] ?? '');
    $destAccName   = trim($_POST['dest_account_name'] ?? '');
    $amount        = (float)($_POST['amount'] ?? 0);
    $purpose       = trim($_POST['purpose'] ?? 'Fund Transfer');

    if ($amount < 1 || !$sourceAccId || empty($destBank) || empty($destAccNumber)) {
      $this->jsonError('All fields are required and amount must be positive.');
    }

    $srcAccount = $this->queryOne(
      "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS cust_name, c.id AS cust_id
             FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.id=?",
      [$sourceAccId]
    );
    if (!$srcAccount) {
      $this->jsonError('Source account not found.');
    }
    if ((float)$srcAccount['balance'] < $amount) {
      $this->jsonError('Insufficient balance.');
    }

    // Fee: 0.5% (min 10, max 500)
    $fee      = min(500, max(10, round($amount * 0.005, 2)));
    $total    = $amount + $fee;
    if ((float)$srcAccount['balance'] < $total) {
      $this->jsonError('Insufficient balance to cover fee of ETB ' . number_format($fee, 2));
    }

    $bankName = self::BANKS[$destBank] ?? $destBank;
    $ref      = 'IBT-' . strtoupper(substr(md5(uniqid()), 0, 10)) . '-' . date('Ymd');
    $ethRef   = 'ETH' . date('ymd') . rand(10000, 99999);

    try {
      $this->db->beginTransaction();

      // Debit source account
      $newBal = (float)$srcAccount['balance'] - $total;
      $this->execute("UPDATE accounts SET balance=? WHERE id=?", [$newBal, $sourceAccId]);

      // Transaction record
      $this->execute(
        "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, channel, status, created_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?)",
        [
          $sourceAccId,
          $ref,
          'Transfer Out',
          $total,
          $srcAccount['balance'],
          $newBal,
          "Inter-bank transfer to {$bankName} ({$destAccNumber})",
          'Online',
          'Completed',
          Session::getUser()['id']
        ]
      );
      $txnId = (int)$this->db->lastInsertId();

      // Inter-bank record
      $this->execute(
        "INSERT INTO interbank_transfers
                 (reference, source_account_id, source_customer_id, dest_bank_code, dest_bank_name, dest_account_number, dest_account_name, amount, fee, net_amount, purpose, channel, status, ethswitch_ref, response_code, response_message, processed_at, initiated_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)",
        [
          $ref,
          $sourceAccId,
          $srcAccount['cust_id'],
          $destBank,
          $bankName,
          $destAccNumber,
          $destAccName,
          $amount,
          $fee,
          $amount,
          $purpose,
          'Counter',
          'Completed',
          $ethRef,
          '00',
          'Transfer successful',
          Session::getUser()['id']
        ]
      );

      $this->db->commit();

      header('Content-Type: application/json');
      echo json_encode([
        'success'    => true,
        'reference'  => $ref,
        'ethswitch'  => $ethRef,
        'amount'     => $amount,
        'fee'        => $fee,
        'new_balance' => $newBal,
        'dest_bank'  => $bankName,
        'message'    => "ETB " . number_format($amount, 2) . " transferred to {$bankName} successfully.",
      ]);
    } catch (\Throwable $ex) {
      $this->db?->rollBack();
      $this->jsonError('Transfer failed: ' . $ex->getMessage());
    }
    exit;
  }

  // ── ATM Simulation: landing page ─────────────────────────────
  public function atmPage(): void
  {
    // ATM is a public page (simulates physical ATM screen)
    View::render('atm/terminal', [
      'pageTitle' => 'ATM Terminal — Abay Bank',
      'banks'     => self::BANKS,
    ], null);
  }

  // ── ATM: authenticate (username + account number OR biometric) ─
  public function atmAuth(): void
  {
    header('Content-Type: application/json');
    $method = $_POST['auth_method'] ?? 'username';
    $atmId  = $_POST['atm_id'] ?? 'ATM-ALEM-001';

    // ── Demo customers (used when DB is offline) ──────────────────
    $demoCustomers = [
      'abebe.bekele'  => ['id' => 1, 'first_name' => 'Abebe', 'last_name' => 'Bekele', 'account_number' => '000110010000000001', 'account_type' => 'Savings', 'balance' => 125450.75, 'pin_suffix' => '0001'],
      'tigist.haile'  => ['id' => 2, 'first_name' => 'Tigist', 'last_name' => 'Haile', 'account_number' => '000110010000000002', 'account_type' => 'Savings', 'balance' => 88200.00, 'pin_suffix' => '0002'],
      'solomon.girma' => ['id' => 3, 'first_name' => 'Solomon', 'last_name' => 'Girma', 'account_number' => '000110010000000003', 'account_type' => 'Current', 'balance' => 342000.50, 'pin_suffix' => '0003'],
    ];

    if ($method === 'username') {
      $username  = trim($_POST['username'] ?? '');
      $acctNo    = trim($_POST['account_number'] ?? '');
      $pin       = trim($_POST['pin'] ?? '');

      if (!$username || !$acctNo) {
        echo json_encode(['success' => false, 'message' => 'Username and account number are required.']);
        exit;
      }

      // ── DB path ───────────────────────────────────────────────
      if ($this->db) {
        $cu = $this->queryOne(
          "SELECT cu.*, c.first_name, c.last_name, c.id AS cust_id
                     FROM customer_users cu
                     JOIN customers c ON c.id=cu.customer_id
                     WHERE cu.username=? OR cu.email=? LIMIT 1",
          [$username, $username]
        );

        if (!$cu) {
          $this->logAtmFail($atmId, null, $method, 'User not found');
          echo json_encode(['success' => false, 'message' => 'Invalid username or account number.']);
          exit;
        }

        $account = $this->queryOne(
          "SELECT * FROM accounts WHERE account_number=? AND customer_id=? AND status='Active' LIMIT 1",
          [$acctNo, $cu['cust_id']]
        );

        if (!$account) {
          $this->logAtmFail($atmId, $cu['cust_id'], $method, 'Account mismatch');
          echo json_encode(['success' => false, 'message' => 'Account number does not match this user.']);
          exit;
        }

        // Verify PIN
        $verified = false;
        if ($pin && !empty($cu['pin_hash'])) {
          $verified = password_verify($pin, $cu['pin_hash']);
        } elseif ($pin) {
          $verified = ($pin === substr($acctNo, -4));
        } else {
          $verified = true;
        }

        if (!$verified) {
          $this->execute("UPDATE customer_users SET failed_attempts=failed_attempts+1 WHERE id=?", [$cu['id']]);
          $this->logAtmFail($atmId, $cu['cust_id'], $method, 'Wrong PIN');
          echo json_encode(['success' => false, 'message' => 'Incorrect PIN. Please try again.']);
          exit;
        }

        $this->execute("UPDATE customer_users SET failed_attempts=0 WHERE id=?", [$cu['id']]);
        $sessionToken = 'db_' . bin2hex(random_bytes(20));
        $this->execute(
          "INSERT INTO atm_sessions (session_token, atm_id, atm_location, customer_id, account_id, auth_method, username, account_number, status, ip_address)
                     VALUES (?,?,?,?,?,?,?,?,'Active',?)",
          [
            $sessionToken,
            $atmId,
            $_POST['atm_location'] ?? 'Alem Ketema Branch',
            $cu['cust_id'],
            $account['id'],
            'Username+Account',
            $username,
            $acctNo,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
          ]
        );

        echo json_encode([
          'success'       => true,
          'session_token' => $sessionToken,
          'customer_name' => $cu['first_name'] . ' ' . $cu['last_name'],
          'account_number' => $acctNo,
          'account_type'  => $account['account_type'],
          'balance'       => (float)$account['balance'],
          'message'       => 'Authentication successful.',
        ]);
        exit;
      }

      // ── Demo fallback (DB offline) ────────────────────────────
      $key  = strtolower(trim($username));
      $demo = $demoCustomers[$key] ?? null;

      if (!$demo) {
        echo json_encode(['success' => false, 'message' => 'User not found. (Demo: try abebe.bekele)']);
        exit;
      }
      if ($acctNo !== $demo['account_number']) {
        echo json_encode(['success' => false, 'message' => 'Account number does not match. Demo account: ' . $demo['account_number']]);
        exit;
      }
      if ($pin && $pin !== $demo['pin_suffix'] && $pin !== substr($demo['account_number'], -4)) {
        echo json_encode(['success' => false, 'message' => 'Incorrect PIN. Demo PIN = last 4 of account number (' . substr($demo['account_number'], -4) . ')']);
        exit;
      }

      $sessionToken = 'demo_' . bin2hex(random_bytes(16)) . '_' . $demo['id'];
      echo json_encode([
        'success'        => true,
        'session_token'  => $sessionToken,
        'customer_name'  => $demo['first_name'] . ' ' . $demo['last_name'],
        'account_number' => $demo['account_number'],
        'account_type'   => $demo['account_type'],
        'balance'        => $demo['balance'],
        'message'        => 'Demo authentication successful.',
        'demo'           => true,
      ]);
    } elseif ($method === 'biometric') {
      $biometricType = $_POST['biometric_type'] ?? 'Fingerprint';
      $templateData  = $_POST['template_data'] ?? '';
      $acctNo        = trim($_POST['account_number'] ?? '');

      if (!$templateData || !$acctNo) {
        echo json_encode(['success' => false, 'message' => 'Biometric data and account number are required.']);
        exit;
      }

      // ── DB path ───────────────────────────────────────────────
      if ($this->db) {
        $account = $this->queryOne("SELECT * FROM accounts WHERE account_number=? AND status='Active'", [$acctNo]);
        if (!$account) {
          echo json_encode(['success' => false, 'message' => 'Account not found.']);
          exit;
        }
        $customer = $this->queryOne("SELECT * FROM customers WHERE id=?", [$account['customer_id']]);
        $matchScore = rand(75, 99);
        if ($matchScore < 80) {
          echo json_encode(['success' => false, 'message' => 'Biometric match failed. Please try again.']);
          exit;
        }
        $sessionToken = 'db_' . bin2hex(random_bytes(20));
        $this->execute(
          "INSERT INTO atm_sessions (session_token, atm_id, atm_location, customer_id, account_id, auth_method, account_number, status, ip_address)
                     VALUES (?,?,?,?,?,?,?,'Active',?)",
          [
            $sessionToken,
            $atmId,
            $_POST['atm_location'] ?? 'Alem Ketema Branch',
            $account['customer_id'],
            $account['id'],
            ucfirst($biometricType),
            $acctNo,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
          ]
        );
        echo json_encode([
          'success'        => true,
          'session_token'  => $sessionToken,
          'customer_name'  => ($customer['first_name'] ?? '') . ' ' . ($customer['last_name'] ?? ''),
          'account_number' => $acctNo,
          'account_type'   => $account['account_type'],
          'balance'        => (float)$account['balance'],
          'match_score'    => $matchScore,
          'message'        => ucfirst($biometricType) . ' verified.',
        ]);
        exit;
      }

      // ── Demo biometric fallback ───────────────────────────────
      $demo = null;
      foreach ($demoCustomers as $d) {
        if ($d['account_number'] === $acctNo) {
          $demo = $d;
          break;
        }
      }
      if (!$demo) {
        echo json_encode(['success' => false, 'message' => 'Account not found. Try: ' . $demoCustomers['abebe.bekele']['account_number']]);
        exit;
      }
      $matchScore = rand(82, 99);
      $sessionToken = 'demo_bio_' . bin2hex(random_bytes(12)) . '_' . $demo['id'];
      echo json_encode([
        'success'        => true,
        'session_token'  => $sessionToken,
        'customer_name'  => $demo['first_name'] . ' ' . $demo['last_name'],
        'account_number' => $demo['account_number'],
        'account_type'   => $demo['account_type'],
        'balance'        => $demo['balance'],
        'match_score'    => $matchScore,
        'message'        => ucfirst($biometricType) . ' verified (Demo).',
        'demo'           => true,
      ]);
    }
    exit;
  }

  // ── ATM: deposit ──────────────────────────────────────────────
  public function atmDeposit(): void
  {
    header('Content-Type: application/json');
    $token  = $_POST['session_token'] ?? '';
    $amount = (float)($_POST['amount'] ?? 0);

    $session = $this->getAtmSession($token);
    if (!$session) {
      echo json_encode(['success' => false, 'message' => 'Session expired. Please re-authenticate.']);
      exit;
    }
    if ($amount < 50) {
      echo json_encode(['success' => false, 'message' => 'Minimum deposit is ETB 50.']);
      exit;
    }
    if ($amount > 50000) {
      echo json_encode(['success' => false, 'message' => 'Maximum ATM deposit is ETB 50,000 per transaction.']);
      exit;
    }

    $ref    = 'ATM-DEP-' . strtoupper(substr(md5(uniqid()), 0, 8)) . '-' . date('Ymd');

    // ── Demo mode (no DB) ─────────────────────────────────────────────
    if (!empty($session['demo']) || !$this->db) {
      $newBal = (float)($session['balance'] ?? 125450.75) + $amount;
      echo json_encode([
        'success' => true,
        'reference' => $ref,
        'amount' => $amount,
        'new_balance' => $newBal,
        'message' => 'ETB ' . number_format($amount, 2) . ' deposited successfully. (Demo)',
        'demo' => true
      ]);
      exit;
    }

    // ── Live DB ───────────────────────────────────────────────────────
    $account = $this->queryOne("SELECT * FROM accounts WHERE id=? AND status='Active'", [$session['account_id']]);
    if (!$account) {
      echo json_encode(['success' => false, 'message' => 'Account not found.']);
      exit;
    }

    $newBal = (float)$account['balance'] + $amount;
    try {
      $this->db->beginTransaction();
      $this->execute("UPDATE accounts SET balance=? WHERE id=?", [$newBal, $account['id']]);
      $this->execute(
        "INSERT INTO transactions (account_id,reference,type,amount,balance_before,balance_after,description,channel,status)
         VALUES (?,?,?,?,?,?,?,?,?)",
        [$account['id'], $ref, 'Deposit', $amount, $account['balance'], $newBal, 'ATM Cash Deposit', 'ATM', 'Completed']
      );
      $txnId = (int)$this->db->lastInsertId();
      $this->execute(
        "INSERT INTO atm_transaction_meta (transaction_id,atm_session_id,atm_id,atm_location,auth_method) VALUES (?,?,?,?,?)",
        [$txnId, $session['id'], $session['atm_id'], $session['atm_location'] ?? '', $session['auth_method']]
      );
      $this->db->commit();
    } catch (\Throwable $e) {
      try {
        $this->db->rollBack();
      } catch (\Throwable) {
      }
      echo json_encode(['success' => false, 'message' => 'Transaction failed. Please try again.']);
      exit;
    }

    echo json_encode([
      'success' => true,
      'reference' => $ref,
      'amount' => $amount,
      'new_balance' => $newBal,
      'message' => 'ETB ' . number_format($amount, 2) . ' deposited successfully.'
    ]);
    exit;
  }

  // ── ATM: withdrawal ───────────────────────────────────────────
  public function atmWithdraw(): void
  {
    header('Content-Type: application/json');
    $token  = $_POST['session_token'] ?? '';
    $amount = (float)($_POST['amount'] ?? 0);

    $session = $this->getAtmSession($token);
    if (!$session) {
      echo json_encode(['success' => false, 'message' => 'Session expired.']);
      exit;
    }
    if ($amount < 100) {
      echo json_encode(['success' => false, 'message' => 'Minimum withdrawal is ETB 100.']);
      exit;
    }
    if ($amount > 10000) {
      echo json_encode(['success' => false, 'message' => 'Maximum ATM withdrawal is ETB 10,000 per transaction.']);
      exit;
    }
    if (fmod($amount, 100) !== 0.0) {
      echo json_encode(['success' => false, 'message' => 'Withdrawal amount must be a multiple of ETB 100.']);
      exit;
    }

    $ref    = 'ATM-WDR-' . strtoupper(substr(md5(uniqid()), 0, 8)) . '-' . date('Ymd');

    // ── Demo mode (no DB) ─────────────────────────────────────────────
    if (!empty($session['demo']) || !$this->db) {
      $currentBal = (float)($session['balance'] ?? 125450.75);
      if ($currentBal < $amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance. Available: ETB ' . number_format($currentBal, 2)]);
        exit;
      }
      $newBal = $currentBal - $amount;
      echo json_encode([
        'success' => true,
        'reference' => $ref,
        'amount' => $amount,
        'new_balance' => $newBal,
        'message' => 'ETB ' . number_format($amount, 2) . ' withdrawn. Please collect your cash. (Demo)',
        'demo' => true
      ]);
      exit;
    }

    // ── Live DB ───────────────────────────────────────────────────────
    $account = $this->queryOne("SELECT * FROM accounts WHERE id=? AND status='Active'", [$session['account_id']]);
    if (!$account) {
      echo json_encode(['success' => false, 'message' => 'Account not found.']);
      exit;
    }
    if ((float)$account['balance'] < $amount) {
      echo json_encode(['success' => false, 'message' => 'Insufficient balance. Available: ETB ' . number_format($account['balance'], 2)]);
      exit;
    }

    $newBal = (float)$account['balance'] - $amount;
    try {
      $this->db->beginTransaction();
      $this->execute("UPDATE accounts SET balance=? WHERE id=?", [$newBal, $account['id']]);
      $this->execute(
        "INSERT INTO transactions (account_id,reference,type,amount,balance_before,balance_after,description,channel,status)
         VALUES (?,?,?,?,?,?,?,?,?)",
        [$account['id'], $ref, 'Withdrawal', $amount, $account['balance'], $newBal, 'ATM Cash Withdrawal', 'ATM', 'Completed']
      );
      $txnId = (int)$this->db->lastInsertId();
      $this->execute(
        "INSERT INTO atm_transaction_meta (transaction_id,atm_session_id,atm_id,atm_location,auth_method) VALUES (?,?,?,?,?)",
        [$txnId, $session['id'], $session['atm_id'], $session['atm_location'] ?? '', $session['auth_method']]
      );
      $this->db->commit();
    } catch (\Throwable $e) {
      try {
        $this->db->rollBack();
      } catch (\Throwable) {
      }
      echo json_encode(['success' => false, 'message' => 'Transaction failed. Please try again.']);
      exit;
    }

    echo json_encode([
      'success' => true,
      'reference' => $ref,
      'amount' => $amount,
      'new_balance' => $newBal,
      'message' => 'ETB ' . number_format($amount, 2) . ' withdrawn. Please collect your cash.'
    ]);
    exit;
  }

  // ── ATM: balance enquiry ──────────────────────────────────────
  public function atmBalance(): void
  {
    header('Content-Type: application/json');
    $token   = $_POST['session_token'] ?? '';
    $session = $this->getAtmSession($token);
    if (!$session) {
      echo json_encode(['success' => false, 'message' => 'Session expired.']);
      exit;
    }

    // ── Demo mode ─────────────────────────────────────────────────────
    if (!empty($session['demo']) || !$this->db) {
      echo json_encode([
        'success'        => true,
        'account_number' => $session['account_number'],
        'account_type'   => $session['account_type'],
        'balance'        => (float)$session['balance'],
        'customer_name'  => $session['customer_name'],
        'as_of'          => date('d M Y H:i:s'),
        'demo'           => true,
      ]);
      exit;
    }

    // ── Live DB ───────────────────────────────────────────────────────
    $account = $this->queryOne(
      "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
       FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.id=?",
      [$session['account_id']]
    );
    if (!$account) {
      echo json_encode(['success' => false, 'message' => 'Account not found.']);
      exit;
    }

    echo json_encode([
      'success'        => true,
      'account_number' => $account['account_number'],
      'account_type'   => $account['account_type'],
      'balance'        => (float)$account['balance'],
      'customer_name'  => $account['customer_name'],
      'as_of'          => date('d M Y H:i:s'),
    ]);
    exit;
  }

  // ── ATM: end session ──────────────────────────────────────────
  public function atmEndSession(): void
  {
    header('Content-Type: application/json');
    $token = $_POST['session_token'] ?? '';
    // Demo sessions have no DB row — just ignore gracefully
    if ($token && $this->db && !str_starts_with($token, 'demo_')) {
      $this->execute(
        "UPDATE atm_sessions SET status='Completed', ended_at=NOW() WHERE session_token=?",
        [$token]
      );
    }
    echo json_encode(['success' => true, 'message' => 'Session ended. Thank you for banking with Abay Bank.']);
    exit;
  }

  // ── ATM: mini statement ───────────────────────────────────────
  public function atmMiniStatement(): void
  {
    header('Content-Type: application/json');
    $token   = $_POST['session_token'] ?? '';
    $session = $this->getAtmSession($token);
    if (!$session) {
      echo json_encode(['success' => false, 'message' => 'Session expired.']);
      exit;
    }

    // ── Demo mode ─────────────────────────────────────────────────────
    if (!empty($session['demo']) || !$this->db) {
      $now   = date('Y-m-d H:i:s');
      $bal   = (float)($session['balance'] ?? 125450.75);
      $demo  = [
        ['reference' => 'ATM-DEP-DEMO0001', 'type' => 'Deposit',    'amount' => 5000.00,  'balance_after' => $bal,         'description' => 'ATM Cash Deposit',    'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
        ['reference' => 'ATM-WDR-DEMO0002', 'type' => 'Withdrawal', 'amount' => 1000.00,  'balance_after' => $bal - 5000.00, 'description' => 'ATM Cash Withdrawal',  'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
        ['reference' => 'TXF-DEMO0003',    'type' => 'Transfer In', 'amount' => 12500.00, 'balance_after' => $bal - 4000.00, 'description' => 'Salary Credit',        'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
        ['reference' => 'ATM-WDR-DEMO0004', 'type' => 'Withdrawal', 'amount' => 500.00,   'balance_after' => $bal - 16500.00, 'description' => 'ATM Cash Withdrawal',  'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))],
        ['reference' => 'DEP-DEMO0005',    'type' => 'Deposit',    'amount' => 20000.00, 'balance_after' => $bal - 17000.00, 'description' => 'Branch Cash Deposit',  'created_at' => date('Y-m-d H:i:s', strtotime('-7 days'))],
      ];
      echo json_encode(['success' => true, 'transactions' => $demo, 'demo' => true]);
      exit;
    }

    // ── Live DB ───────────────────────────────────────────────────────
    $txns = $this->query(
      "SELECT reference, type, amount, balance_after, description, created_at
       FROM transactions WHERE account_id=? ORDER BY created_at DESC LIMIT 5",
      [$session['account_id']]
    );
    echo json_encode(['success' => true, 'transactions' => $txns]);
    exit;
  }

  // ── ATM session validator ─────────────────────────────────────
  private function getAtmSession(string $token): ?array
  {
    if (!$token) return null;

    // ── Demo session (DB offline) — token starts with 'demo_' ────────
    if (str_starts_with($token, 'demo_')) {
      $demoSessions = [
        1 => ['id' => 'demo1', 'account_id' => 'demo_acc_1', 'account_number' => '000110010000000001', 'account_type' => 'Savings', 'balance' => 125450.75, 'customer_name' => 'Abebe Bekele', 'atm_id' => 'ATM-ALEM-001', 'atm_location' => 'Alem Ketema Branch', 'auth_method' => 'Username+Account'],
        2 => ['id' => 'demo2', 'account_id' => 'demo_acc_2', 'account_number' => '000110010000000002', 'account_type' => 'Savings', 'balance' => 88200.00, 'customer_name' => 'Tigist Haile', 'atm_id' => 'ATM-ALEM-001', 'atm_location' => 'Alem Ketema Branch', 'auth_method' => 'Username+Account'],
        3 => ['id' => 'demo3', 'account_id' => 'demo_acc_3', 'account_number' => '000110010000000003', 'account_type' => 'Current', 'balance' => 342000.50, 'customer_name' => 'Solomon Girma', 'atm_id' => 'ATM-ALEM-001', 'atm_location' => 'Alem Ketema Branch', 'auth_method' => 'Username+Account'],
      ];
      $parts  = explode('_', $token);
      $custId = (int)end($parts);
      $sess   = $demoSessions[$custId] ?? $demoSessions[1];
      $sess['demo']          = true;
      $sess['session_token'] = $token;
      return $sess;
    }

    // ── Live DB session ───────────────────────────────────────────────
    if (!$this->db) return null;
    $s = $this->queryOne(
      "SELECT * FROM atm_sessions WHERE session_token=? AND status='Active'
             AND started_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
      [$token]
    );
    return $s ?: null;
  }

  private function logAtmFail(string $atmId, ?int $customerId, string $method, string $reason): void
  {
    $this->execute(
      "INSERT INTO atm_sessions (session_token, atm_id, customer_id, auth_method, status, ip_address, ended_at)
             VALUES (?,?,?,?,'Blocked',?,NOW())",
      [bin2hex(random_bytes(8)), $atmId, $customerId, $method, $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']
    );
  }

  private function jsonError(string $msg): never
  {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $msg]);
    exit;
  }

  // ── Customer Portal: dashboard ───────────────────────────────
  public function customerDashboard(): void
  {
    Auth::customerGuard();
    $c = Session::getCustomer();
    $accounts = $this->query(
      "SELECT * FROM accounts WHERE customer_id=? AND status='Active' ORDER BY opened_date",
      [$c['id']]
    ) ?: [];
    $loans = $this->query(
      "SELECT * FROM loans WHERE customer_id=? AND status IN('Active','Pending') ORDER BY created_at DESC LIMIT 5",
      [$c['id']]
    ) ?: [];
    $recentTxns = [];
    foreach ($accounts as $acc) {
      $txns = $this->query(
        "SELECT * FROM transactions WHERE account_id=? ORDER BY created_at DESC LIMIT 5",
        [$acc['id']]
      );
      $recentTxns = array_merge($recentTxns, $txns);
    }
    usort($recentTxns, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
    $recentTxns = array_slice($recentTxns, 0, 10);

    View::render('customer-portal/dashboard', [
      'pageTitle'  => 'My Banking — Abay Bank',
      'customer'   => $c,
      'accounts'   => $accounts,
      'loans'      => $loans,
      'recentTxns' => $recentTxns,
      'dbOnline'   => $this->db !== null,
    ], 'layout/customer-base');
  }

  // ── Customer Portal: accounts ─────────────────────────────────
  public function customerAccounts(): void
  {
    Auth::customerGuard();
    $c = Session::getCustomer();
    $accounts = $this->query("SELECT * FROM accounts WHERE customer_id=? ORDER BY opened_date", [$c['id']]) ?: [];
    View::render('customer-portal/accounts', [
      'pageTitle' => 'My Accounts — Abay Bank',
      'customer'  => $c,
      'accounts'  => $accounts,
      'dbOnline'  => $this->db !== null,
    ], 'layout/customer-base');
  }

  // ── Customer Portal: online transfer ─────────────────────────
  public function customerTransferPage(): void
  {
    Auth::customerGuard();
    $c = Session::getCustomer();
    $accounts = $this->query("SELECT * FROM accounts WHERE customer_id=? AND status='Active'", [$c['id']]) ?: [];
    $beneficiaries = $this->query("SELECT * FROM beneficiaries WHERE customer_id=? AND is_active=1", [$c['id']]) ?: [];
    View::render('customer-portal/transfer', [
      'pageTitle'     => 'Transfer Funds — Abay Bank',
      'customer'      => $c,
      'accounts'      => $accounts,
      'beneficiaries' => $beneficiaries,
      'banks'         => self::BANKS,
      'dbOnline'      => $this->db !== null,
    ], 'layout/customer-base');
  }
}
