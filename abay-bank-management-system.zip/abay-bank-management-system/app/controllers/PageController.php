<?php

/**
 * Abay Bank — Page Controller
 *
 * One controller handles ALL management system pages.
 * Each method:
 *   1. Guards with Auth::guard()
 *   2. Fetches live data from the API (or uses demo data if DB offline)
 *   3. Renders the matching PHP view with layout
 */

declare(strict_types=1);

namespace Web\Controllers;

use Web\Core\Auth;
use Web\Core\View;
use Web\Core\Session;
use App\Config\Database;
use PDO;

class PageController
{
  private ?PDO $db = null;

  public function __construct()
  {
    try {
      $this->db = Database::getInstance()->getConnection();
    } catch (\Throwable) {
      $this->db = null; // demo mode
    }
  }

  // ─── Helper: fetch from DB or return demo ───────────────────
  private function query(string $sql, array $params = []): array
  {
    if (!$this->db) return [];
    try {
      $stmt = $this->db->prepare($sql);
      $stmt->execute($params);
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable) {
      return [];
    }
  }

  private function queryOne(string $sql, array $params = []): ?array
  {
    $rows = $this->query($sql, $params);
    return $rows[0] ?? null;
  }

  private function render(string $view, array $data = []): void
  {
    $data['user']  = Session::getUser();
    $data['dbOnline'] = $this->db !== null;
    View::render($view, $data);
  }

  // ─── Public Home Page ───────────────────────────────────────
  public function home(): void
  {
    // If staff is already logged in, go straight to dashboard
    try {
      if (\Web\Core\Session::isLoggedIn()) {
        \Web\Core\View::redirect('dashboard');
      }
    } catch (\Throwable) {
    }

    // Render the public home page with NO layout (it's self-contained)
    $viewFile = VIEW_PATH . '/home/index.php';
    if (!file_exists($viewFile)) {
      \Web\Core\View::redirect('login');
    }
    include $viewFile;
    exit;
  }

  // ─── Dashboard ──────────────────────────────────────────────
  public function dashboard(): void
  {
    Auth::guard();
    $stats = [
      'customers'          => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers WHERE status='Active'")['c'] ?? 2450),
      'accounts'           => (int)($this->queryOne("SELECT COUNT(*) AS c FROM accounts WHERE status='Active'")['c'] ?? 3182),
      'today_transactions' => (int)($this->queryOne("SELECT COUNT(*) AS c FROM transactions WHERE DATE(created_at)=CURDATE()")['c'] ?? 842),
      'active_loans'       => (int)($this->queryOne("SELECT COUNT(*) AS c FROM loans WHERE status IN('Active','Disbursed')")['c'] ?? 124),
      'total_deposits'     => (float)($this->queryOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Deposit' AND DATE(created_at)=CURDATE()")['s'] ?? 1250000),
      'total_withdrawals'  => (float)($this->queryOne("SELECT COALESCE(SUM(amount),0) AS s FROM transactions WHERE type='Withdrawal' AND DATE(created_at)=CURDATE()")['s'] ?? 890000),
      'employees'          => (int)($this->queryOne("SELECT COUNT(*) AS c FROM employees WHERE status='Active'")['c'] ?? 156),
      'branches'           => (int)($this->queryOne("SELECT COUNT(*) AS c FROM branches WHERE status='Active'")['c'] ?? 9),
      // ── Pending requests from both portals ────────────────
      'pending_loans'        => (int)($this->queryOne("SELECT COUNT(*) AS c FROM loans WHERE status='Pending'")['c'] ?? 3),
      'pending_appointments' => (int)($this->queryOne("SELECT COUNT(*) AS c FROM appointments WHERE status='Pending'")['c'] ?? 5),
      'pending_leave'        => (int)($this->queryOne("SELECT COUNT(*) AS c FROM leave_requests WHERE status='Pending'")['c'] ?? 2),
      'pending_kyc'          => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status IN('Pending','Under_Review')")['c'] ?? 8),
      'pending_complaints'   => (int)($this->queryOne("SELECT COUNT(*) AS c FROM complaints WHERE status='Open'")['c'] ?? 4),
    ];

    // ── Recent pending requests (for inbox feed) ──────────────
    $pendingRequests = array_merge(
      array_map(
        fn($r) => array_merge($r, ['request_type' => 'Loan', 'icon' => 'fa-file-invoice-dollar', 'color' => '#7c3aed', 'link' => APP_URL . '/loans/approval']),
        $this->query("SELECT CONCAT(c.first_name,' ',c.last_name) AS name, l.loan_number AS ref, l.amount, l.loan_type AS detail, l.created_at FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE l.status='Pending' ORDER BY l.created_at DESC LIMIT 4") ?: []
      ),
      array_map(
        fn($r) => array_merge($r, ['request_type' => 'Appointment', 'icon' => 'fa-calendar-days', 'color' => '#0d9488', 'link' => APP_URL . '/support/appointments']),
        $this->query("SELECT CONCAT(c.first_name,' ',c.last_name) AS name, a.id AS ref, 0 AS amount, CONCAT(a.purpose,' — ',a.appointment_date) AS detail, a.created_at FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id WHERE a.status='Pending' ORDER BY a.created_at DESC LIMIT 3") ?: []
      ),
      array_map(
        fn($r) => array_merge($r, ['request_type' => 'Leave', 'icon' => 'fa-calendar-xmark', 'color' => '#f59e0b', 'link' => APP_URL . '/employees/leave']),
        $this->query("SELECT CONCAT(e.first_name,' ',e.last_name) AS name, lr.id AS ref, 0 AS amount, CONCAT(lr.leave_type,' (',lr.days,' days)') AS detail, lr.created_at FROM leave_requests lr LEFT JOIN employees e ON e.id=lr.employee_id WHERE lr.status='Pending' ORDER BY lr.created_at DESC LIMIT 3") ?: []
      ),
      array_map(
        fn($r) => array_merge($r, ['request_type' => 'KYC', 'icon' => 'fa-id-card', 'color' => '#3b82f6', 'link' => APP_URL . '/customers/kyc']),
        $this->query("SELECT CONCAT(first_name,' ',last_name) AS name, customer_number AS ref, 0 AS amount, 'Identity verification required' AS detail, created_at FROM customers WHERE kyc_status IN('Pending','Under_Review') ORDER BY created_at DESC LIMIT 3") ?: []
      ),
      array_map(
        fn($r) => array_merge($r, ['request_type' => 'Complaint', 'icon' => 'fa-headset', 'color' => '#ef4444', 'link' => APP_URL . '/support/complaints']),
        $this->query("SELECT CONCAT(cu.first_name,' ',cu.last_name) AS name, c.ticket_no AS ref, 0 AS amount, c.subject AS detail, c.created_at FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id WHERE c.status='Open' ORDER BY c.created_at DESC LIMIT 3") ?: []
      )
    );

    // Sort by created_at descending
    usort($pendingRequests, fn($a, $b) => strtotime($b['created_at'] ?? '0') - strtotime($a['created_at'] ?? '0'));
    $pendingRequests = array_slice($pendingRequests, 0, 10);

    $recentTxns = $this->query(
      "SELECT t.*, a.account_number FROM transactions t
       JOIN accounts a ON a.id = t.account_id
       ORDER BY t.created_at DESC LIMIT 8"
    );
    $this->render('dashboard/index', [
      'pageTitle'       => 'Dashboard — ' . APP_NAME,
      'stats'           => $stats,
      'recentTxns'      => $recentTxns,
      'pendingRequests' => $pendingRequests,
      'needsCharts'     => true,
      'extraJs'         => [ASSET_URL . '/js/dashboard.js'],
    ]);
  }

  // ─── Customers ──────────────────────────────────────────────
  public function customerList(): void
  {
    Auth::guard();
    $customers = $this->query(
      "SELECT c.*, COALESCE(b.name, b.branch_name, '--') AS branch_name,
              COALESCE(SUM(a.balance), 0) AS balance
       FROM customers c
       LEFT JOIN branches b ON b.id = c.branch_id
       LEFT JOIN accounts a ON a.customer_id = c.id AND a.status = 'Active'
       GROUP BY c.id
       ORDER BY c.created_at DESC
       LIMIT 300"
    );
    $this->render('customer/list', [
      'pageTitle' => 'Customers — ' . APP_NAME,
      'customers' => $customers,
    ]);
  }

  public function customerRegister(): void
  {
    Auth::guard();
    $branches = $this->query("SELECT id, branch_name FROM branches WHERE status='Active' ORDER BY branch_name");
    $this->render('customer/register', ['pageTitle' => 'Register Customer — ' . APP_NAME, 'branches' => $branches]);
  }

  public function customerKYC(): void
  {
    Auth::guard();
    $pending = $this->query("SELECT c.*, k.kyc_status, k.fayda_id FROM customers c LEFT JOIN kyc_records k ON k.customer_id=c.id WHERE c.kyc_status IN('Pending','Under_Review') ORDER BY c.created_at DESC LIMIT 100");
    $this->render('customer/kyc', ['pageTitle' => 'KYC Management — ' . APP_NAME, 'pending' => $pending]);
  }

  // ─── Accounts ───────────────────────────────────────────────
  public function savings(): void
  {
    Auth::guard();
    $this->accountPage('Savings',      'accounts/savings');
  }
  public function current(): void
  {
    Auth::guard();
    $this->accountPage('Current',       'accounts/current');
  }
  public function fixedDeposit(): void
  {
    Auth::guard();
    $this->accountPage('Fixed Deposit', 'accounts/fixed-deposit');
  }

  private function accountPage(string $type, string $view): void
  {
    $accounts = $this->query(
      "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM accounts a JOIN customers c ON c.id=a.customer_id
             WHERE a.account_type=? ORDER BY a.opened_date DESC LIMIT 300",
      [$type]
    );
    $this->render($view, ['pageTitle' => "{$type} Accounts — " . APP_NAME, 'accounts' => $accounts, 'accountType' => $type, 'extraJs' => [ASSET_URL . '/js/accounts.js']]);
  }

  public function accountStatement(): void
  {
    Auth::guard();
    $this->render('accounts/statement', ['pageTitle' => 'Account Statement — ' . APP_NAME]);
  }

  public function accountOpening(): void
  {
    Auth::guard();
    $customers = $this->query("SELECT id, CONCAT(first_name,' ',last_name) AS name, customer_number FROM customers WHERE status='Active' ORDER BY first_name LIMIT 300");
    $branches  = $this->query("SELECT id, branch_name FROM branches WHERE status='Active'");
    $this->render('accounts/opening', ['pageTitle' => 'Open Account — ' . APP_NAME, 'customers' => $customers, 'branches' => $branches]);
  }

  public function atmCards(): void
  {
    Auth::guard();
    $cards = $this->query("SELECT c.*, a.account_number, CONCAT(cu.first_name,' ',cu.last_name) AS holder FROM atm_cards c JOIN accounts a ON a.id=c.account_id JOIN customers cu ON cu.id=a.customer_id ORDER BY c.issued_date DESC LIMIT 200");
    $this->render('accounts/atm-cards', ['pageTitle' => 'ATM Cards — ' . APP_NAME, 'cards' => $cards]);
  }

  public function cheques(): void
  {
    Auth::guard();
    $cheques = $this->query("SELECT ch.*, a.account_number, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM cheques ch JOIN accounts a ON a.id=ch.account_id JOIN customers c ON c.id=a.customer_id ORDER BY ch.issue_date DESC LIMIT 200");
    $this->render('accounts/cheques', ['pageTitle' => 'Cheques — ' . APP_NAME, 'cheques' => $cheques]);
  }

  // ─── Transactions ────────────────────────────────────────────
  public function deposit(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $this->render('transactions/deposit', ['pageTitle' => 'Deposit — ' . APP_NAME, 'accounts' => $accounts]);
  }

  public function withdrawal(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $this->render('transactions/withdrawal', ['pageTitle' => 'Withdrawal — ' . APP_NAME, 'accounts' => $accounts]);
  }

  public function transfer(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $this->render('transactions/transfer', ['pageTitle' => 'Fund Transfer — ' . APP_NAME, 'accounts' => $accounts]);
  }

  public function transactionHistory(): void
  {
    Auth::guard();
    $transactions = $this->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id ORDER BY t.created_at DESC LIMIT 300");
    $this->render('transactions/history', ['pageTitle' => 'Transaction History — ' . APP_NAME, 'transactions' => $transactions]);
  }

  public function transactionApproval(): void
  {
    Auth::guard(['Admin', 'Manager', 'Teller']);
    $pending = $this->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.status='Pending' ORDER BY t.created_at DESC LIMIT 100");
    $this->render('transactions/approval', ['pageTitle' => 'Transaction Approvals — ' . APP_NAME, 'pending' => $pending]);
  }

  // ─── Loans ──────────────────────────────────────────────────
  public function loanList(): void
  {
    Auth::guard();
    $loans = $this->query("SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM loans l LEFT JOIN customers c ON c.id=l.customer_id ORDER BY l.created_at DESC LIMIT 200");
    $this->render('loans/list', ['pageTitle' => 'Loan Management — ' . APP_NAME, 'loans' => $loans, 'extraJs' => [ASSET_URL . '/js/loans.js']]);
  }

  public function applyLoan(): void
  {
    Auth::guard();
    $customers  = $this->query("SELECT id, CONCAT(first_name,' ',last_name) AS name, customer_number FROM customers WHERE status='Active' ORDER BY first_name LIMIT 300");
    $loanTypes  = $this->query("SELECT * FROM loan_types WHERE is_active=1 ORDER BY name") ?: [
      ['id' => 1, 'name' => 'Personal Loan', 'base_rate' => 12, 'min_amount' => 5000, 'max_amount' => 500000, 'max_term' => 60],
      ['id' => 2, 'name' => 'Business Loan', 'base_rate' => 10.5, 'min_amount' => 10000, 'max_amount' => 5000000, 'max_term' => 120],
      ['id' => 3, 'name' => 'Agricultural Loan', 'base_rate' => 8, 'min_amount' => 5000, 'max_amount' => 1000000, 'max_term' => 84],
    ];
    $this->render('loans/apply', ['pageTitle' => 'Apply Loan — ' . APP_NAME, 'customers' => $customers, 'loanTypes' => $loanTypes]);
  }

  public function loanApproval(): void
  {
    Auth::guard(['Admin', 'Manager', 'Loan Officer']);
    $pending = $this->query("SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE l.status='Pending' ORDER BY l.created_at DESC LIMIT 100");
    $this->render('loans/approval', ['pageTitle' => 'Loan Approvals — ' . APP_NAME, 'pending' => $pending]);
  }

  public function loanPayment(): void
  {
    Auth::guard();
    $loans = $this->query("SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE l.status IN('Active','Disbursed') ORDER BY l.next_due_date LIMIT 200");
    $this->render('loans/payment', ['pageTitle' => 'Loan Payment — ' . APP_NAME, 'loans' => $loans]);
  }

  // ─── Employees ──────────────────────────────────────────────
  public function employees(): void
  {
    Auth::guard();
    $employees = $this->query("SELECT e.*, b.branch_name, d.name AS dept_name FROM employees e LEFT JOIN branches b ON b.id=e.branch_id LEFT JOIN departments d ON d.id=e.department_id WHERE e.status='Active' ORDER BY e.first_name LIMIT 200");
    $this->render('employee/list', ['pageTitle' => 'Employees — ' . APP_NAME, 'employees' => $employees, 'extraJs' => [ASSET_URL . '/js/attendance.js']]);
  }

  public function attendance(): void
  {
    Auth::guard();
    $today = $this->query("SELECT a.*, CONCAT(e.first_name,' ',e.last_name) AS name, e.employee_number FROM attendance a JOIN employees e ON e.id=a.employee_id WHERE a.date=CURDATE() ORDER BY e.first_name");
    $this->render('employee/attendance', ['pageTitle' => 'Attendance — ' . APP_NAME, 'today' => $today, 'extraJs' => [ASSET_URL . '/js/attendance.js']]);
  }

  public function leave(): void
  {
    Auth::guard();
    $requests = $this->query("SELECT l.*, CONCAT(e.first_name,' ',e.last_name) AS name FROM leave_requests l JOIN employees e ON e.id=l.employee_id ORDER BY l.created_at DESC LIMIT 200");
    $this->render('employee/leave', ['pageTitle' => 'Leave Management — ' . APP_NAME, 'requests' => $requests, 'extraJs' => [ASSET_URL . '/js/attendance.js']]);
  }

  public function payroll(): void
  {
    Auth::guard(['Admin', 'Manager', 'HR Officer']);
    $payroll = $this->query("SELECT p.*, CONCAT(e.first_name,' ',e.last_name) AS name, e.employee_number FROM payroll p JOIN employees e ON e.id=p.employee_id ORDER BY p.pay_month DESC, e.first_name LIMIT 200");
    $this->render('employee/payroll', ['pageTitle' => 'Payroll — ' . APP_NAME, 'payroll' => $payroll, 'extraJs' => [ASSET_URL . '/js/payroll.js']]);
  }

  public function performance(): void
  {
    Auth::guard();
    $this->render('employee/performance', ['pageTitle' => 'Performance — ' . APP_NAME]);
  }

  public function recruitment(): void
  {
    Auth::guard(['Admin', 'HR Officer']);
    $vacancies = $this->query("SELECT * FROM job_vacancies ORDER BY created_at DESC LIMIT 50") ?: [];
    $applications = $this->query("SELECT * FROM job_applications ORDER BY applied_at DESC LIMIT 100") ?: [];
    $this->render('employee/recruitment', ['pageTitle' => 'Recruitment — ' . APP_NAME, 'vacancies' => $vacancies, 'applications' => $applications]);
  }

  public function training(): void
  {
    Auth::guard();
    $programs = $this->query("SELECT * FROM training_programs ORDER BY start_date DESC LIMIT 50") ?: [];
    $this->render('employee/training', ['pageTitle' => 'Training — ' . APP_NAME, 'programs' => $programs]);
  }

  // ─── Branches ───────────────────────────────────────────────
  public function branches(): void
  {
    Auth::guard();
    $branches = $this->query("SELECT b.*, COUNT(DISTINCT e.id) AS emp_count, COUNT(DISTINCT a.id) AS acc_count FROM branches b LEFT JOIN employees e ON e.branch_id=b.id AND e.status='Active' LEFT JOIN accounts a ON a.branch_id=b.id AND a.status='Active' GROUP BY b.id ORDER BY b.branch_name");
    $this->render('branch/list', ['pageTitle' => 'Branches — ' . APP_NAME, 'branches' => $branches]);
  }

  public function branchPerformance(): void
  {
    Auth::guard();
    $this->render('branch/performance', ['pageTitle' => 'Branch Performance — ' . APP_NAME, 'needsCharts' => true]);
  }

  // ─── Reports ────────────────────────────────────────────────
  public function reportFinancial(): void
  {
    Auth::guard();
    $this->render('reports/financial',   ['pageTitle' => 'Financial Report — ' . APP_NAME, 'needsCharts' => true, 'extraJs' => [ASSET_URL . '/js/reports.js']]);
  }
  public function reportCustomers(): void
  {
    Auth::guard();
    $this->render('reports/customers',   ['pageTitle' => 'Customer Report — ' . APP_NAME, 'extraJs' => [ASSET_URL . '/js/reports.js']]);
  }
  public function reportLoans(): void
  {
    Auth::guard();
    $this->render('reports/loans',       ['pageTitle' => 'Loan Report — ' . APP_NAME, 'needsCharts' => true, 'extraJs' => [ASSET_URL . '/js/reports.js']]);
  }
  public function reportAttendance(): void
  {
    Auth::guard();
    $this->render('reports/attendance',  ['pageTitle' => 'Attendance Report — ' . APP_NAME, 'extraJs' => [ASSET_URL . '/js/reports.js']]);
  }
  public function reportDashboard(): void
  {
    Auth::guard();
    $this->render('reports/dashboard',   ['pageTitle' => 'Report Dashboard — ' . APP_NAME, 'needsCharts' => true]);
  }

  // ─── Support ────────────────────────────────────────────────
  public function complaints(): void
  {
    Auth::guard();
    $complaints = $this->query("SELECT c.*, CONCAT(cu.first_name,' ',cu.last_name) AS customer_name FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id ORDER BY c.created_at DESC LIMIT 200");
    $this->render('support/complaints', ['pageTitle' => 'Complaints — ' . APP_NAME, 'complaints' => $complaints]);
  }

  public function appointments(): void
  {
    Auth::guard();
    $appointments = $this->query("SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, b.branch_name FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id LEFT JOIN branches b ON b.id=a.branch_id ORDER BY a.appointment_date, a.appointment_time LIMIT 200");
    $this->render('support/appointments', ['pageTitle' => 'Appointments — ' . APP_NAME, 'appointments' => $appointments]);
  }

  public function notifications(): void
  {
    Auth::guard();
    $u = Session::getUser();
    $notifs = $this->query("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100", [$u['id'] ?? 1]);
    $this->render('support/notifications', ['pageTitle' => 'Notifications — ' . APP_NAME, 'notifications' => $notifs]);
  }

  // ─── Administration ──────────────────────────────────────────
  public function adminPermissions(): void
  {
    Auth::guard(['Admin']);
    $this->render('administration/permissions', ['pageTitle' => 'Permissions — ' . APP_NAME]);
  }

  public function adminRequests(): void
  {
    Auth::guard(['Admin', 'Manager']);
    $pendingLoans = $this->query(
      "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
       FROM loans l LEFT JOIN customers c ON c.id=l.customer_id
       WHERE l.status='Pending' ORDER BY l.created_at DESC LIMIT 100"
    ) ?: [
      ['id' => 1, 'loan_number' => 'LN-2026-0001', 'customer_name' => 'Abebe Bekele', 'loan_type' => 'Personal Loan', 'amount' => 50000, 'interest_rate' => 12, 'term_months' => 36, 'purpose' => 'Home renovation', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours')), 'phone' => '0911234567'],
      ['id' => 2, 'loan_number' => 'LN-2026-0002', 'customer_name' => 'Tigist Haile', 'loan_type' => 'Business Loan', 'amount' => 200000, 'interest_rate' => 10.5, 'term_months' => 60, 'purpose' => 'Business expansion', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours')), 'phone' => '0922345678'],
    ];
    $pendingAppointments = $this->query(
      "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, b.branch_name
       FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id LEFT JOIN branches b ON b.id=a.branch_id
       WHERE a.status='Pending' ORDER BY a.appointment_date, a.appointment_time LIMIT 100"
    ) ?: [
      ['id' => 1, 'customer_name' => 'Solomon Girma', 'branch_name' => 'Alem Ketema Branch', 'appointment_date' => date('Y-m-d', strtotime('+2 days')), 'appointment_time' => '10:00:00', 'purpose' => 'Account Inquiry', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
      ['id' => 2, 'customer_name' => 'Meron Alemu',  'branch_name' => 'Bole Branch',        'appointment_date' => date('Y-m-d', strtotime('+3 days')), 'appointment_time' => '14:00:00', 'purpose' => 'Loan Consultation', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))],
    ];
    $pendingLeave = $this->query(
      "SELECT lr.*, CONCAT(e.first_name,' ',e.last_name) AS employee_name, e.position
       FROM leave_requests lr LEFT JOIN employees e ON e.id=lr.employee_id
       WHERE lr.status='Pending' ORDER BY lr.created_at DESC LIMIT 100"
    ) ?: [
      ['id' => 1, 'employee_name' => 'Yohannes Bekele', 'position' => 'Branch Manager', 'leave_type' => 'Annual', 'from_date' => date('Y-m-d', strtotime('+5 days')), 'to_date' => date('Y-m-d', strtotime('+10 days')), 'days' => 5, 'reason' => 'Family vacation', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-6 hours'))],
    ];
    $pendingKYC = $this->query(
      "SELECT c.id, CONCAT(c.first_name,' ',c.last_name) AS customer_name,
              c.customer_number, c.phone, c.kyc_status, c.created_at
       FROM customers c WHERE c.kyc_status IN('Pending','Under_Review')
       ORDER BY c.created_at DESC LIMIT 100"
    ) ?: [
      ['id' => 1, 'customer_name' => 'Daniel Worku', 'customer_number' => 'CUST-Y1Z2A3B', 'phone' => '0977890123', 'kyc_status' => 'Pending', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
      ['id' => 2, 'customer_name' => 'Fikirte Bekele', 'customer_number' => 'CUST-C4D5E6F', 'phone' => '0988901234', 'kyc_status' => 'Under_Review', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
    ];
    $openComplaints = $this->query(
      "SELECT c.*, CONCAT(cu.first_name,' ',cu.last_name) AS customer_name
       FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id
       WHERE c.status='Open' ORDER BY c.created_at DESC LIMIT 100"
    ) ?: [
      ['id' => 1, 'ticket_no' => 'CMP-2026-0001', 'customer_name' => 'Abebe Bekele', 'category' => 'Transaction Issue', 'subject' => 'Wrong debit amount', 'priority' => 'High', 'status' => 'Open', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))],
      ['id' => 2, 'ticket_no' => 'CMP-2026-0002', 'customer_name' => 'Hanna Getnet', 'category' => 'Card Issue',       'subject' => 'ATM card blocked', 'priority' => 'Urgent', 'status' => 'Open', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
    ];
    $this->render('administration/requests', [
      'pageTitle'           => 'Pending Requests — ' . APP_NAME,
      'pendingLoans'        => $pendingLoans,
      'pendingAppointments' => $pendingAppointments,
      'pendingLeave'        => $pendingLeave,
      'pendingKYC'          => $pendingKYC,
      'openComplaints'      => $openComplaints,
    ]);
  }

  public function adminUsers(): void
  {
    Auth::guard(['Admin']);
    $users = $this->query("SELECT u.*, r.role_name FROM users u LEFT JOIN roles r ON r.id=u.role_id ORDER BY u.created_at DESC LIMIT 200");
    $roles = $this->query("SELECT id, role_name FROM roles ORDER BY role_name");
    $this->render('administration/users', ['pageTitle' => 'Users — ' . APP_NAME, 'users' => $users, 'roles' => $roles]);
  }

  public function adminProfile(): void
  {
    Auth::guard();
    $u = Session::getUser();
    if ($this->db && !empty($u['id'])) {
      $dbUser = $this->queryOne("SELECT u.*, r.role_name AS role FROM users u LEFT JOIN roles r ON r.id=u.role_id WHERE u.id=?", [(int)$u['id']]);
      if ($dbUser) $u = array_merge($u, $dbUser);
    }
    $this->render('administration/profile', [
      'pageTitle' => 'My Profile — ' . APP_NAME,
      'user'      => $u,
    ]);
  }

  public function adminRoles(): void
  {
    Auth::guard(['Admin']);
    $roles = $this->query("SELECT r.*, COUNT(u.id) AS user_count FROM roles r LEFT JOIN users u ON u.role_id=r.id GROUP BY r.id ORDER BY r.id");
    $this->render('administration/roles', ['pageTitle' => 'Roles & Permissions — ' . APP_NAME, 'roles' => $roles]);
  }

  public function adminAudit(): void
  {
    Auth::guard(['Admin', 'Auditor']);
    $logs = $this->query("SELECT a.*, u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 300");
    $this->render('administration/audit', ['pageTitle' => 'Audit Log — ' . APP_NAME, 'logs' => $logs]);
  }

  public function adminSecurity(): void
  {
    Auth::guard(['Admin']);
    $sessions  = $this->query("SELECT s.*, u.username FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.is_active=1 ORDER BY s.last_activity DESC LIMIT 50") ?: [];
    $attempts  = $this->query("SELECT * FROM login_attempts ORDER BY created_at DESC LIMIT 100") ?: [];
    $this->render('administration/security', ['pageTitle' => 'Security — ' . APP_NAME, 'sessions' => $sessions, 'attempts' => $attempts]);
  }

  public function adminDocuments(): void
  {
    Auth::guard(['Admin', 'Auditor']);
    $kycDocs = $this->query("SELECT d.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM customer_documents d LEFT JOIN customers c ON c.id=d.customer_id ORDER BY d.uploaded_at DESC LIMIT 200") ?: [];
    $this->render('administration/documents', ['pageTitle' => 'Documents — ' . APP_NAME, 'kycDocs' => $kycDocs]);
  }

  public function adminInventory(): void
  {
    Auth::guard(['Admin']);
    $assets = $this->query("SELECT i.*, b.branch_name FROM inventory i LEFT JOIN branches b ON b.id=i.branch_id ORDER BY i.name LIMIT 300") ?: [];
    $this->render('administration/inventory', ['pageTitle' => 'Inventory — ' . APP_NAME, 'assets' => $assets]);
  }

  public function adminBackup(): void
  {
    Auth::guard(['Admin']);
    $backups = $this->query("SELECT * FROM backups ORDER BY created_at DESC LIMIT 50") ?: [];
    $this->render('administration/backup', ['pageTitle' => 'Backup & Restore — ' . APP_NAME, 'backups' => $backups]);
  }

  public function adminSettings(): void
  {
    Auth::guard(['Admin']);
    $settings = $this->query("SELECT * FROM settings ORDER BY `group`, `key`") ?: [];
    $settingsMap = array_column($settings, null, 'key');
    $this->render('administration/settings', ['pageTitle' => 'System Settings — ' . APP_NAME, 'settings' => $settingsMap]);
  }

  // ─── Cards ──────────────────────────────────────────────────
  public function cardsIndex(): void
  {
    Auth::guard();
    $cards = $this->query("SELECT c.*, a.account_number, a.balance, CONCAT(cu.first_name,' ',cu.last_name) AS holder FROM atm_cards c JOIN accounts a ON a.id=c.account_id JOIN customers cu ON cu.id=a.customer_id ORDER BY c.issued_date DESC LIMIT 200");
    $stats = [
      'total'    => count($cards),
      'active'   => count(array_filter($cards, fn($c) => ($c['status'] ?? '') === 'Active')),
      'blocked'  => count(array_filter($cards, fn($c) => ($c['status'] ?? '') === 'Blocked')),
      'pending'  => count(array_filter($cards, fn($c) => ($c['status'] ?? '') === 'Pending')),
    ];
    $this->render('cards/index', ['pageTitle' => 'Card Management — ' . APP_NAME, 'cards' => $cards, 'cardStats' => $stats]);
  }

  public function cardsApply(): void
  {
    Auth::guard();
    $customers = $this->query("SELECT id, CONCAT(first_name,' ',last_name) AS name, customer_number FROM customers WHERE status='Active' ORDER BY first_name LIMIT 300");
    $accounts  = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $this->render('cards/apply', ['pageTitle' => 'Apply for Card — ' . APP_NAME, 'customers' => $customers, 'accounts' => $accounts]);
  }

  public function cardsVirtual(): void
  {
    Auth::guard();
    $virtualCards = $this->query("SELECT c.*, a.account_number, a.balance, CONCAT(cu.first_name,' ',cu.last_name) AS holder FROM atm_cards c JOIN accounts a ON a.id=c.account_id JOIN customers cu ON cu.id=a.customer_id WHERE c.card_type='Virtual' ORDER BY c.issued_date DESC LIMIT 200") ?: [];
    $this->render('cards/virtual', ['pageTitle' => 'Virtual Cards — ' . APP_NAME, 'cards' => $virtualCards]);
  }

  // ─── Transfers ──────────────────────────────────────────────
  public function transferLocal(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $recentTxns = $this->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.type IN('Transfer Out','Transfer In') ORDER BY t.created_at DESC LIMIT 20");
    $this->render('transfers/local', ['pageTitle' => 'Local Transfer — ' . APP_NAME, 'accounts' => $accounts, 'recentTxns' => $recentTxns]);
  }

  public function transferInternational(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $recentWires = $this->query("SELECT * FROM interbank_transfers ORDER BY created_at DESC LIMIT 20") ?: [];
    $this->render('transfers/international', ['pageTitle' => 'International Transfer — ' . APP_NAME, 'accounts' => $accounts, 'recentWires' => $recentWires]);
  }

  public function transferFund(): void
  {
    Auth::guard();
    $accounts = $this->query("SELECT a.id, a.account_number, a.account_type, a.balance, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.status='Active' ORDER BY a.account_number LIMIT 500");
    $this->render('transfers/fund', ['pageTitle' => 'Fund Transfer — ' . APP_NAME, 'accounts' => $accounts]);
  }

  // ─── Employee Dashboard ──────────────────────────────────────
  public function employeeDashboard(): void
  {
    Auth::guard();
    $u = Session::getUser();
    $empData = $this->queryOne("SELECT e.*, d.name AS dept_name, b.branch_name FROM employees e LEFT JOIN departments d ON d.id=e.department_id LEFT JOIN branches b ON b.id=e.branch_id WHERE e.user_id=?", [$u['id'] ?? 0]);
    $attendanceMonth = $this->query("SELECT * FROM attendance WHERE employee_id=? AND MONTH(date)=MONTH(CURDATE()) ORDER BY date DESC", [$empData['id'] ?? 0]);
    $leaveBalance = $this->queryOne("SELECT * FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())", [$empData['id'] ?? 0]);
    $payslip = $this->queryOne("SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_month DESC LIMIT 1", [$empData['id'] ?? 0]);
    $this->render('employee/dashboard', [
      'pageTitle'       => 'Employee Dashboard — ' . APP_NAME,
      'empData'         => $empData,
      'attendanceMonth' => $attendanceMonth,
      'leaveBalance'    => $leaveBalance,
      'payslip'         => $payslip,
      'needsCharts'     => true,
    ]);
  }

  // ─── Customer Overview (Admin) ───────────────────────────────
  public function customerOverview(): void
  {
    Auth::guard();
    $stats = [
      'total'   => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers")['c'] ?? 2450),
      'active'  => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers WHERE status='Active'")['c'] ?? 2280),
      'kyc_ok'  => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status='Verified'")['c'] ?? 1980),
      'new_month' => (int)($this->queryOne("SELECT COUNT(*) AS c FROM customers WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())")['c'] ?? 124),
    ];
    $recent = $this->query("SELECT c.*, b.branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id ORDER BY c.created_at DESC LIMIT 20");
    $this->render('customer/overview', ['pageTitle' => 'Customer Overview — ' . APP_NAME, 'stats' => $stats, 'recent' => $recent, 'needsCharts' => true]);
  }

  public function customerProfile(): void
  {
    Auth::guard();
    $id = (int)($_GET['id'] ?? 0);
    $customer = $this->queryOne("SELECT c.*, b.branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id WHERE c.id=?", [$id]);
    if (!$customer) {
      View::redirect('customers');
    }
    $accounts = $this->query("SELECT * FROM accounts WHERE customer_id=? ORDER BY opened_date DESC", [$id]);
    $loans    = $this->query("SELECT * FROM loans WHERE customer_id=? ORDER BY created_at DESC LIMIT 10", [$id]);
    $txns     = $this->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? ORDER BY t.created_at DESC LIMIT 20", [$id]);
    $this->render('customer/profile', ['pageTitle' => 'Customer Profile — ' . APP_NAME, 'customer' => $customer, 'accounts' => $accounts, 'loans' => $loans, 'txns' => $txns]);
  }

  // ─── Administration (new) ────────────────────────────────────
  public function adminAppSettings(): void
  {
    Auth::guard(['Admin']);
    $this->render('administration/app-settings', ['pageTitle' => 'App Settings — ' . APP_NAME]);
  }

  public function adminIpSettings(): void
  {
    Auth::guard(['Admin']);
    $ipRules = $this->query("SELECT * FROM ip_whitelist ORDER BY created_at DESC LIMIT 100") ?: [];
    $this->render('administration/ip-settings', ['pageTitle' => 'IP Settings — ' . APP_NAME, 'ipRules' => $ipRules]);
  }

  public function adminPaymentSettings(): void
  {
    Auth::guard(['Admin']);
    $this->render('administration/payment-settings', ['pageTitle' => 'Payment Settings — ' . APP_NAME]);
  }

  public function adminAttendance(): void
  {
    Auth::guard(['Admin', 'Manager', 'HR Officer']);
    $today = $this->query("SELECT a.*, CONCAT(e.first_name,' ',e.last_name) AS name, e.employee_number, d.name AS dept_name FROM attendance a JOIN employees e ON e.id=a.employee_id LEFT JOIN departments d ON d.id=e.department_id WHERE a.date=CURDATE() ORDER BY e.first_name");
    $weekStats = $this->query("SELECT date, COUNT(CASE WHEN status='Present' THEN 1 END) AS present, COUNT(CASE WHEN status='Absent' THEN 1 END) AS absent, COUNT(CASE WHEN status='Late' THEN 1 END) AS late FROM attendance WHERE date >= DATE_SUB(CURDATE(),INTERVAL 7 DAY) GROUP BY date ORDER BY date") ?: [];
    $this->render('administration/attendance', ['pageTitle' => 'Attendance Management — ' . APP_NAME, 'today' => $today, 'weekStats' => $weekStats, 'needsCharts' => true]);
  }

  // ─── Customer Portal ────────────────────────────────────────
  public function customerDashboard(): void
  {
    Auth::customerGuard();
    $cust = Session::getCustomer();
    $accounts = $cust ? $this->query("SELECT * FROM accounts WHERE customer_id=? AND status='Active'", [$cust['id']]) : [];
    $this->render('customer-portal/dashboard', ['pageTitle' => 'My Dashboard — ' . APP_NAME, 'customer' => $cust, 'accounts' => $accounts, 'extraCss' => [ASSET_URL . '/css/customer-portal.css'], 'extraJs' => [ASSET_URL . '/js/customer-auth.js', ASSET_URL . '/js/customer-dashboard.js']], 'layout/customer-base');
  }
}
