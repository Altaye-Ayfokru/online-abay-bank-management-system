<?php

/**
 * Abay Bank — PHP Auth Guard
 * Works with PHP sessions AND falls back to JWT (for API/JS callers).
 */

declare(strict_types=1);

namespace Web\Core;

class Auth
{
  /** Redirect to login if not authenticated */
  public static function guard(string|array|null $requiredRole = null): void
  {
    Session::start();

    if (!Session::isLoggedIn()) {
      Session::flash('error', 'Please login to access this page.');
      Session::flash('redirect_after_login', $_SERVER['REQUEST_URI'] ?? '');
      header('Location: ' . APP_URL . '/login');
      exit;
    }

    // ── ADMIN IS OMNIPOTENT: bypasses every role check, every time ──
    if (Session::hasRole(['Admin'])) return;

    if ($requiredRole !== null) {
      $roles = is_array($requiredRole) ? $requiredRole : [$requiredRole];
      if (!Session::hasRole($roles)) {
        http_response_code(403);
        self::forbidden();
      }
    }
  }

  /**
   * Check if current user has a specific permission.
   * Admin always returns true; used by views to show/hide UI elements.
   */
  public static function can(string|array $roles): bool
  {
    if (!Session::isLoggedIn()) return false;
    if (Session::hasRole(['Admin'])) return true;   // Admin can do everything
    return Session::hasRole(is_array($roles) ? $roles : [$roles]);
  }

  /** True if current user IS an Admin */
  public static function isAdmin(): bool
  {
    return Session::hasRole(['Admin']);
  }

  /** Customer portal guard */
  public static function customerGuard(): void
  {
    Session::start();
    if (!Session::isCustomerLoggedIn()) {
      Session::flash('error', 'Please login to your online banking account.');
      header('Location: ' . APP_URL . '/customer/login');
      exit;
    }
  }

  /** Process login: verify credentials, set session, return result */
  public static function login(string $username, string $password): array
  {
    // Demo credentials (used when DB is offline)
    $demo = [
      'admin'       => ['pwd' => 'Admin@1234',   'user' => ['id' => 1, 'username' => 'admin',      'full_name' => 'Admin User',     'role' => 'Admin',       'email' => 'admin@abaybank.com',   'branch_id' => 1]],
      'manager'     => ['pwd' => 'Manager@1234', 'user' => ['id' => 2, 'username' => 'manager',    'full_name' => 'Branch Manager', 'role' => 'Manager',     'email' => 'manager@abaybank.com', 'branch_id' => 2]],
      'teller'      => ['pwd' => 'Teller@1234',  'user' => ['id' => 3, 'username' => 'teller',     'full_name' => 'Teller Officer', 'role' => 'Teller',      'email' => 'teller@abaybank.com',  'branch_id' => 1]],
      'loanofficer' => ['pwd' => 'Admin@1234',   'user' => ['id' => 4, 'username' => 'loanofficer', 'full_name' => 'Loan Officer',   'role' => 'Loan Officer', 'email' => 'loan@abaybank.com',    'branch_id' => 1]],
      'auditor'     => ['pwd' => 'Admin@1234',   'user' => ['id' => 5, 'username' => 'auditor',    'full_name' => 'Audit Officer',  'role' => 'Auditor',     'email' => 'auditor@abaybank.com', 'branch_id' => 1]],
      'hrstaff'     => ['pwd' => 'Admin@1234',   'user' => ['id' => 6, 'username' => 'hrstaff',    'full_name' => 'HR Officer',     'role' => 'HR Officer',  'email' => 'hr@abaybank.com',      'branch_id' => 1]],
    ];

    // Try real DB first
    try {
      $db   = \App\Config\Database::getInstance()->getConnection();
      $stmt = $db->prepare(
        "SELECT u.*, r.role_name FROM users u
                 LEFT JOIN roles r ON r.id = u.role_id
                 WHERE u.username = :u OR u.email = :u
                 LIMIT 1"
      );
      $stmt->execute([':u' => $username]);
      $row = $stmt->fetch(\PDO::FETCH_ASSOC);

      if ($row && password_verify($password, $row['password'])) {
        if ($row['status'] !== 'Active') {
          return ['success' => false, 'message' => 'Account is ' . $row['status'] . '. Contact admin.'];
        }
        $user = [
          'id'        => (int)$row['id'],
          'username'  => $row['username'],
          'full_name' => $row['full_name'] ?? $row['username'],
          'role'      => $row['role_name'] ?? $row['role'] ?? 'Staff',
          'email'     => $row['email'],
          'branch_id' => (int)($row['branch_id'] ?? 0),
        ];
        Session::setUser($user);
        // Update last login
        $db->prepare("UPDATE users SET last_login_at = NOW(), failed_attempts = 0 WHERE id = :id")
          ->execute([':id' => $row['id']]);
        return ['success' => true, 'user' => $user, 'mode' => 'live'];
      }

      if ($row) {
        // Wrong password — track attempt
        $db->prepare("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = :id")
          ->execute([':id' => $row['id']]);
        return ['success' => false, 'message' => 'Invalid username or password.'];
      }
    } catch (\Throwable $e) {
      // DB offline — fall through to demo
    }

    // Demo fallback
    $key  = strtolower(trim($username));
    $cred = $demo[$key] ?? null;
    if ($cred && $cred['pwd'] === $password) {
      Session::setUser($cred['user']);
      return ['success' => true, 'user' => $cred['user'], 'mode' => 'demo'];
    }

    return ['success' => false, 'message' => 'Invalid username or password.'];
  }

  /** Customer login */
  public static function customerLogin(string $username, string $password): array
  {
    $demo = [
      'abebe.bekele'  => ['id' => 1, 'name' => 'Abebe Bekele', 'email' => 'abebe.bekele@email.com', 'kyc_status' => 'Verified'],
      'tigist.haile'  => ['id' => 2, 'name' => 'Tigist Haile',  'email' => 'tigist.haile@email.com',  'kyc_status' => 'Verified'],
      'solomon.girma' => ['id' => 5, 'name' => 'Solomon Girma', 'email' => 'solomon.girma@email.com', 'kyc_status' => 'Verified'],
    ];
    $DEMO_PWD = 'Customer@1234';

    // Try DB
    try {
      $db   = \App\Config\Database::getInstance()->getConnection();
      $stmt = $db->prepare(
        "SELECT cu.*, c.first_name, c.last_name, c.email AS cust_email, c.status AS cust_status, c.kyc_status
                 FROM customer_users cu
                 JOIN customers c ON c.id = cu.customer_id
                 WHERE cu.username = :u OR cu.email = :u
                 LIMIT 1"
      );
      $stmt->execute([':u' => $username]);
      $row = $stmt->fetch(\PDO::FETCH_ASSOC);
      if ($row && password_verify($password, $row['password'])) {
        $customer = [
          'id'         => (int)$row['customer_id'],
          'name'       => $row['first_name'] . ' ' . $row['last_name'],
          'email'      => $row['cust_email'],
          'kyc_status' => $row['kyc_status'],
        ];
        Session::setCustomer($customer);
        return ['success' => true, 'customer' => $customer, 'mode' => 'live'];
      }
      if ($row) return ['success' => false, 'message' => 'Invalid credentials.'];
    } catch (\Throwable $e) {
      // DB offline
    }

    // Demo fallback
    $key      = strtolower(trim($username));
    $customer = $demo[$key] ?? null;
    if ($customer && $password === $DEMO_PWD) {
      Session::setCustomer($customer);
      return ['success' => true, 'customer' => $customer, 'mode' => 'demo'];
    }

    return ['success' => false, 'message' => 'Invalid username or password.'];
  }

  public static function logout(): void
  {
    Session::destroy();
    header('Location: ' . APP_URL . '/login');
    exit;
  }

  public static function customerLogout(): void
  {
    Session::destroyCustomer();
    header('Location: ' . APP_URL . '/customer/login');
    exit;
  }

  private static function forbidden(): void
  {
    include VIEW_PATH . '/errors/403.php';
    exit;
  }

  /** Get current logged-in user (staff) */
  public static function user(): ?array
  {
    return Session::getUser();
  }

  /** Get current logged-in customer */
  public static function customer(): ?array
  {
    return Session::getCustomer();
  }
}
