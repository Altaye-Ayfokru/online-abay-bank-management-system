<?php

/**
 * Abay Bank — Web Router (for PHP page views)
 * Separate from the API router in backend/app/core/Router.php
 */

declare(strict_types=1);

namespace Web\Core;

class Router
{
  private array $routes = [];

  public function get(string $path, callable|array $handler): void
  {
    $this->routes['GET'][$path] = $handler;
  }

  public function post(string $path, callable|array $handler): void
  {
    $this->routes['POST'][$path] = $handler;
  }

  public function put(string $path, callable|array $handler): void
  {
    $this->routes['PUT'][$path] = $handler;
  }

  public function patch(string $path, callable|array $handler): void
  {
    $this->routes['PATCH'][$path] = $handler;
  }

  public function delete(string $path, callable|array $handler): void
  {
    $this->routes['DELETE'][$path] = $handler;
  }

  public function any(string $path, callable|array $handler): void
  {
    $this->routes['GET'][$path]    = $handler;
    $this->routes['POST'][$path]   = $handler;
    $this->routes['PUT'][$path]    = $handler;
    $this->routes['DELETE'][$path] = $handler;
  }

  public function dispatch(): void
  {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    // ── Method override: HTML forms send _method=PUT/DELETE via POST ──
    if ($method === 'POST') {
      $override = $_POST['_method'] ?? $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? null;
      if ($override) $method = strtoupper($override);
    }
    $uri    = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);

    // Strip base path prefix (e.g. /abay-bank-management-system)
    $base = parse_url(APP_URL, PHP_URL_PATH) ?? '';
    if ($base && str_starts_with($uri, $base)) {
      $uri = substr($uri, strlen($base));
    }

    // Strip script filename if accessed directly (e.g. /public/index.php)
    $script = '/' . ltrim($_SERVER['SCRIPT_NAME'] ?? '', '/');
    $scriptBase = parse_url(APP_URL, PHP_URL_PATH) ?? '';
    $scriptRelative = $scriptBase ? substr($script, strlen($scriptBase)) : $script;
    if ($scriptRelative && $scriptRelative !== '/' && str_starts_with($uri, $scriptRelative)) {
      $uri = substr($uri, strlen($scriptRelative));
    }

    $uri = '/' . ltrim($uri ?: '/', '/');

    // Try exact match
    $handler = $this->routes[$method][$uri] ?? null;

    // Try pattern matching with {param}
    if (!$handler) {
      foreach ($this->routes[$method] ?? [] as $pattern => $h) {
        $regex   = preg_replace('/\{[a-z_]+\}/', '([^/]+)', $pattern);
        $regex   = '#^' . $regex . '$#';
        if (preg_match($regex, $uri, $matches)) {
          array_shift($matches);
          $handler = $h;
          $_GET    = array_merge($_GET, array_values($matches));
          break;
        }
      }
    }

    if (!$handler) {
      http_response_code(404);
      $e404 = VIEW_PATH . '/errors/404.php';
      if (file_exists($e404)) {
        include $e404;
      } else {
        echo '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:80px"><h1 style="color:#1B3A5C">404 — Page Not Found</h1><p><a href="' . APP_URL . '">Go home</a></p></body></html>';
      }
      return;
    }

    if (is_callable($handler)) {
      call_user_func($handler);
    } elseif (is_array($handler) && count($handler) === 2) {
      [$class, $method] = $handler;
      $obj = new $class();
      $obj->$method();
    }
  }
}
