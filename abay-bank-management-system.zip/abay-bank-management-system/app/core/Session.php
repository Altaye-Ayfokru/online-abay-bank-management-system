<?php

/**
 * Abay Bank — PHP Session Manager
 * Wraps $_SESSION with type safety, CSRF tokens, and flash messages.
 */

declare(strict_types=1);

namespace Web\Core;

class Session
{
  private static bool $started = false;

  public static function start(): void
  {
    if (self::$started || session_status() === PHP_SESSION_ACTIVE) {
      self::$started = true;
      return;
    }

    session_name(SESSION_NAME);
    session_set_cookie_params([
      'lifetime' => SESSION_TIMEOUT,
      'path'     => '/',
      'secure'   => isset($_SERVER['HTTPS']),
      'httponly' => true,
      'samesite' => 'Lax',
    ]);
    session_start();
    self::$started = true;

    // Regenerate ID on first start to prevent fixation
    if (empty($_SESSION['_initiated'])) {
      session_regenerate_id(true);
      $_SESSION['_initiated'] = true;
    }
  }

  /* ── User session ── */
  public static function setUser(array $user): void
  {
    self::start();
    $_SESSION['user']       = $user;
    $_SESSION['logged_in']  = true;
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    $_SESSION['ip']         = $_SERVER['REMOTE_ADDR'] ?? '';
    $_SESSION['ua']         = $_SERVER['HTTP_USER_AGENT'] ?? '';
  }

  public static function getUser(): ?array
  {
    self::start();
    return $_SESSION['user'] ?? null;
  }

  public static function isLoggedIn(): bool
  {
    self::start();
    if (empty($_SESSION['logged_in'])) return false;
    // Check timeout
    if (isset($_SESSION['last_activity'])) {
      if ((time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        self::destroy();
        return false;
      }
    }
    // Check IP consistency (optional — disable if behind proxy)
    // if (($_SESSION['ip'] ?? '') !== ($_SERVER['REMOTE_ADDR'] ?? '')) {
    //     self::destroy(); return false;
    // }
    $_SESSION['last_activity'] = time();
    return true;
  }

  public static function hasRole(string|array $roles): bool
  {
    $user = self::getUser();
    if (!$user) return false;
    $userRole = $user['role'] ?? '';
    $check    = is_array($roles) ? $roles : [$roles];
    return in_array($userRole, $check, true);
  }

  public static function destroy(): void
  {
    self::start();
    $_SESSION = [];
    if (isset($_COOKIE[session_name()])) {
      setcookie(session_name(), '', time() - 3600, '/');
    }
    session_destroy();
    self::$started = false;
  }

  /* ── Customer portal session (separate from staff) ── */
  public static function setCustomer(array $customer): void
  {
    self::start();
    $_SESSION['customer']          = $customer;
    $_SESSION['customer_logged_in'] = true;
    $_SESSION['customer_login_time'] = time();
    $_SESSION['customer_last_activity'] = time();
  }

  public static function getCustomer(): ?array
  {
    self::start();
    return $_SESSION['customer'] ?? null;
  }

  public static function isCustomerLoggedIn(): bool
  {
    self::start();
    if (empty($_SESSION['customer_logged_in'])) return false;
    if (isset($_SESSION['customer_last_activity'])) {
      if ((time() - $_SESSION['customer_last_activity']) > SESSION_TIMEOUT) {
        self::destroyCustomer();
        return false;
      }
    }
    $_SESSION['customer_last_activity'] = time();
    return true;
  }

  public static function destroyCustomer(): void
  {
    self::start();
    unset(
      $_SESSION['customer'],
      $_SESSION['customer_logged_in'],
      $_SESSION['customer_login_time'],
      $_SESSION['customer_last_activity']
    );
  }

  /* ── Flash messages ── */
  public static function flash(string $key, mixed $value = null): mixed
  {
    self::start();
    if ($value !== null) {
      $_SESSION['_flash'][$key] = $value;
      return null;
    }
    $val = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $val;
  }

  /* ── CSRF ── */
  public static function csrfToken(): string
  {
    self::start();
    if (empty($_SESSION['_csrf'])) {
      $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
  }

  public static function verifyCsrf(string $token): bool
  {
    self::start();
    return hash_equals($_SESSION['_csrf'] ?? '', $token);
  }

  /* ── Generic get/set ── */
  public static function set(string $key, mixed $value): void
  {
    self::start();
    $_SESSION[$key] = $value;
  }

  public static function get(string $key, mixed $default = null): mixed
  {
    self::start();
    return $_SESSION[$key] ?? $default;
  }

  public static function remove(string $key): void
  {
    self::start();
    unset($_SESSION[$key]);
  }

  /* ── Employee portal session ── */
  public static function setEmployee(array $employee): void
  {
    self::start();
    $_SESSION['employee']              = $employee;
    $_SESSION['employee_logged_in']    = true;
    $_SESSION['employee_login_time']   = time();
    $_SESSION['employee_last_activity'] = time();
  }

  public static function getEmployee(): ?array
  {
    self::start();
    return $_SESSION['employee'] ?? null;
  }

  public static function isEmployeeLoggedIn(): bool
  {
    self::start();
    if (empty($_SESSION['employee_logged_in'])) return false;
    if (isset($_SESSION['employee_last_activity'])) {
      if ((time() - $_SESSION['employee_last_activity']) > SESSION_TIMEOUT) {
        self::destroyEmployee();
        return false;
      }
    }
    $_SESSION['employee_last_activity'] = time();
    return true;
  }

  public static function destroyEmployee(): void
  {
    self::start();
    unset(
      $_SESSION['employee'],
      $_SESSION['employee_logged_in'],
      $_SESSION['employee_login_time'],
      $_SESSION['employee_last_activity']
    );
  }
}
