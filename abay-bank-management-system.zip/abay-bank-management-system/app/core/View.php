<?php

/**
 * Abay Bank — View Renderer
 */

declare(strict_types=1);

namespace Web\Core;

class View
{
  private static array $shared = [];

  public static function share(string $key, mixed $value): void
  {
    self::$shared[$key] = $value;
  }

  /**
   * Render a view inside a layout.
   * $layout = null  → no layout (standalone pages like login, home)
   * $layout omitted → uses layout/base
   */
  public static function render(string $view, array $data = [], ?string $layout = 'layout/base'): void
  {
    // Merge shared + per-call data (per-call wins)
    $vars = array_merge(self::$shared, $data);

    // Defaults
    $vars['user']      ??= Session::getUser();
    $vars['customer']  ??= Session::getCustomer();
    $vars['pageTitle'] ??= APP_NAME;

    // Resolve view file path (dot-notation or slash-notation)
    $viewFile = VIEW_PATH . '/' . str_replace(['.', '\\'], '/', $view) . '.php';
    if (!file_exists($viewFile)) {
      throw new \RuntimeException("View not found: {$viewFile}");
    }

    // Render view into buffer — isolate in a closure to avoid variable leaks
    $content = (static function () use ($viewFile, $vars): string {
      extract($vars);  // EXTR_OVERWRITE so $content from $vars can't pollute
      ob_start();
      include $viewFile;
      return (string) ob_get_clean();
    })();

    // No layout — output raw (standalone pages)
    if ($layout === null) {
      echo $content;
      return;
    }

    // With layout — include layout with $content available
    $layoutFile = VIEW_PATH . '/' . $layout . '.php';
    if (!file_exists($layoutFile)) {
      echo $content; // fallback: no layout file
      return;
    }

    // Render layout — again in isolated scope, $content is explicitly passed
    (static function () use ($layoutFile, $vars, $content): void {
      extract($vars);  // gives layout access to $pageTitle, $user, etc.
      // $content is set explicitly AFTER extract so it cannot be overwritten
      include $layoutFile;
    })();
  }

  public static function partial(string $view, array $data = []): string
  {
    $vars     = array_merge(self::$shared, $data);
    $viewFile = VIEW_PATH . '/' . str_replace(['.', '\\'], '/', $view) . '.php';
    if (!file_exists($viewFile)) return '';
    return (static function () use ($viewFile, $vars): string {
      extract($vars);
      ob_start();
      include $viewFile;
      return (string) ob_get_clean();
    })();
  }

  public static function redirect(string $path, int $code = 302): never
  {
    $url = str_starts_with($path, 'http') ? $path : APP_URL . '/' . ltrim($path, '/');
    http_response_code($code);
    header("Location: {$url}");
    exit;
  }

  public static function asset(string $path): string
  {
    return ASSET_URL . '/' . ltrim($path, '/');
  }

  public static function url(string $path = ''): string
  {
    return APP_URL . '/' . ltrim($path, '/');
  }

  public static function e(mixed $value): string
  {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }

  public static function csrfField(): string
  {
    $token = Session::csrfToken();
    return '<input type="hidden" name="_csrf" value="' . self::e($token) . '">';
  }

  public static function flash(string $key): ?string
  {
    return Session::flash($key);
  }
}
