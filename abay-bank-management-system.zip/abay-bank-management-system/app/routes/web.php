<?php

/**
 * Abay Bank — Web Routes
 */

declare(strict_types=1);

use Web\Core\Router;
use Web\Controllers\AuthWebController;
use Web\Controllers\PageController;
use Web\Controllers\OnlineApplicationController;
use Web\Controllers\ApiController;

$router = new Router();

// ── Root / Home ──────────────────────────────────────
$router->get('/',     [PageController::class, 'home']);
$router->get('/home', [PageController::class, 'home']);

// ── Auth ─────────────────────────────────────────────
$router->get('/login',           [AuthWebController::class, 'loginForm']);
$router->post('/login',          [AuthWebController::class, 'loginPost']);
$router->get('/logout',          [AuthWebController::class, 'logout']);
$router->get('/forgot-password', [AuthWebController::class, 'forgotPasswordForm']);

// ── Customer auth
$router->get('/customer/login',  [AuthWebController::class, 'customerLoginForm']);
$router->post('/customer/login', [AuthWebController::class, 'customerLoginPost']);
$router->get('/customer/logout', [AuthWebController::class, 'customerLogout']);

// ── Employee portal auth
$router->get('/employee/login',    [AuthWebController::class, 'employeeLoginForm']);
$router->post('/employee/login',   [AuthWebController::class, 'employeeLoginPost']);
$router->post('/employee/register', [AuthWebController::class, 'employeeRegisterPost']);
$router->get('/employee/logout',   [AuthWebController::class, 'employeeLogout']);
$router->get('/employee/portal',   [AuthWebController::class, 'employeePortal']);

// ── Cards ─────────────────────────────────────────────
$router->get('/cards',          [PageController::class, 'cardsIndex']);
$router->get('/cards/apply',    [PageController::class, 'cardsApply']);
$router->get('/cards/virtual',  [PageController::class, 'cardsVirtual']);

// ── Transfers ─────────────────────────────────────────
$router->get('/transfers/local',         [PageController::class, 'transferLocal']);
$router->get('/transfers/international', [PageController::class, 'transferInternational']);
$router->get('/transfers/fund',          [PageController::class, 'transferFund']);

// ── Employee Dashboard ────────────────────────────────
$router->get('/employees/dashboard', [PageController::class, 'employeeDashboard']);

// ── Customer Overview (Admin) ─────────────────────────
$router->get('/customers/overview', [PageController::class, 'customerOverview']);
$router->get('/customers/profile',  [PageController::class, 'customerProfile']);

// ── Administration (new) ──────────────────────────────
$router->get('/admin/app-settings',     [PageController::class, 'adminAppSettings']);
$router->get('/admin/ip-settings',      [PageController::class, 'adminIpSettings']);
$router->get('/admin/payment-settings', [PageController::class, 'adminPaymentSettings']);
$router->get('/admin/attendance',       [PageController::class, 'adminAttendance']);
$router->get('/admin/requests',         [PageController::class, 'adminRequests']);

// ── Dashboard ─────────────────────────────────────────
$router->get('/dashboard', [PageController::class, 'dashboard']);

// ── Customers ─────────────────────────────────────────
$router->get('/customers',          [PageController::class, 'customerList']);
$router->get('/customers/register', [PageController::class, 'customerRegister']);
$router->get('/customers/kyc',      [PageController::class, 'customerKYC']);

// ── Accounts ──────────────────────────────────────────
$router->get('/accounts/savings',       [PageController::class, 'savings']);
$router->get('/accounts/current',       [PageController::class, 'current']);
$router->get('/accounts/fixed-deposit', [PageController::class, 'fixedDeposit']);
$router->get('/accounts/statement',     [PageController::class, 'accountStatement']);
$router->get('/accounts/opening',       [PageController::class, 'accountOpening']);
$router->get('/accounts/atm-cards',     [PageController::class, 'atmCards']);
$router->get('/accounts/cheques',       [PageController::class, 'cheques']);

// ── Transactions ──────────────────────────────────────
$router->get('/transactions/deposit',    [PageController::class, 'deposit']);
$router->get('/transactions/withdrawal', [PageController::class, 'withdrawal']);
$router->get('/transactions/transfer',   [PageController::class, 'transfer']);
$router->get('/transactions',            [PageController::class, 'transactionHistory']);
$router->get('/transactions/approval',   [PageController::class, 'transactionApproval']);
$router->get('/transactions/interbank',  [OnlineApplicationController::class, 'interbankTransferPage']);
$router->post('/transactions/interbank', [OnlineApplicationController::class, 'processInterbankTransfer']);

// ── Loans ─────────────────────────────────────────────
$router->get('/loans',          [PageController::class, 'loanList']);
$router->get('/loans/apply',    [PageController::class, 'applyLoan']);
$router->get('/loans/approval', [PageController::class, 'loanApproval']);
$router->get('/loans/payment',  [PageController::class, 'loanPayment']);

// ── Employees / HR ────────────────────────────────────
$router->get('/employees',             [PageController::class, 'employees']);
$router->get('/employees/attendance',  [PageController::class, 'attendance']);
$router->get('/employees/leave',       [PageController::class, 'leave']);
$router->get('/employees/payroll',     [PageController::class, 'payroll']);
$router->get('/employees/performance', [PageController::class, 'performance']);
$router->get('/employees/recruitment', [PageController::class, 'recruitment']);
$router->get('/employees/training',    [PageController::class, 'training']);

// ── Branches ──────────────────────────────────────────
$router->get('/branches',             [PageController::class, 'branches']);
$router->get('/branches/performance', [PageController::class, 'branchPerformance']);

// ── Reports ───────────────────────────────────────────
$router->get('/reports',            [PageController::class, 'reportDashboard']);
$router->get('/reports/financial',  [PageController::class, 'reportFinancial']);
$router->get('/reports/customers',  [PageController::class, 'reportCustomers']);
$router->get('/reports/loans',      [PageController::class, 'reportLoans']);
$router->get('/reports/attendance', [PageController::class, 'reportAttendance']);

// ── Support ───────────────────────────────────────────
$router->get('/support/complaints',   [PageController::class, 'complaints']);
$router->get('/support/appointments', [PageController::class, 'appointments']);
$router->get('/notifications',        [PageController::class, 'notifications']);

// ── Administration ────────────────────────────────────
$router->get('/admin/users',        [PageController::class, 'adminUsers']);
$router->get('/admin/profile',      [PageController::class, 'adminProfile']);
$router->get('/admin/permissions',  [PageController::class, 'adminPermissions']);
$router->get('/admin/roles',     [PageController::class, 'adminRoles']);
$router->get('/admin/audit',     [PageController::class, 'adminAudit']);
$router->get('/admin/security',  [PageController::class, 'adminSecurity']);
$router->get('/admin/documents', [PageController::class, 'adminDocuments']);
$router->get('/admin/inventory', [PageController::class, 'adminInventory']);
$router->get('/admin/backup',    [PageController::class, 'adminBackup']);
$router->get('/admin/settings',  [PageController::class, 'adminSettings']);

// ── Customer Portal ───────────────────────────────────
$router->get('/customer/dashboard', [OnlineApplicationController::class, 'customerDashboard']);
$router->get('/customer/accounts',  [OnlineApplicationController::class, 'customerAccounts']);
$router->get('/customer/transfer',  [OnlineApplicationController::class, 'customerTransferPage']);

// ── Online Account Opening (public) ───────────────────
$router->get('/online/apply',        [OnlineApplicationController::class, 'showForm']);
$router->post('/online/apply',       [OnlineApplicationController::class, 'submitForm']);
$router->get('/online/success',      [OnlineApplicationController::class, 'showForm']);
$router->get('/online/applications', [OnlineApplicationController::class, 'listApplications']);
$router->get('/online/review',       [OnlineApplicationController::class, 'reviewApplication']);
$router->post('/online/approve',     [OnlineApplicationController::class, 'approveApplication']);
$router->post('/online/reject',      [OnlineApplicationController::class, 'rejectApplication']);

// ── ATM Terminal (public simulation) ──────────────────
$router->get('/atm',            [OnlineApplicationController::class, 'atmPage']);
$router->post('/atm/auth',      [OnlineApplicationController::class, 'atmAuth']);
$router->post('/atm/deposit',   [OnlineApplicationController::class, 'atmDeposit']);
$router->post('/atm/withdraw',  [OnlineApplicationController::class, 'atmWithdraw']);
$router->post('/atm/balance',   [OnlineApplicationController::class, 'atmBalance']);
$router->post('/atm/end',       [OnlineApplicationController::class, 'atmEndSession']);
$router->post('/atm/statement', [OnlineApplicationController::class, 'atmMiniStatement']);

// ── API Endpoints (JSON) ─────────────────────────────
$router->get('/api/dashboard/stats',           [ApiController::class, 'dashboardStats']);
$router->get('/api/activity',                  [ApiController::class, 'getActivity']);
$router->get('/api/stats/refresh',             [ApiController::class, 'refreshStats']);
$router->get('/api/pending-count',             [ApiController::class, 'getPendingCount']);
$router->get('/api/accounts',                  [ApiController::class, 'getAccounts']);
$router->get('/api/branches',                  [ApiController::class, 'getBranches']);
$router->get('/api/departments',               [ApiController::class, 'getDepartments']);
$router->get('/api/employees',                 [ApiController::class, 'getEmployees']);
$router->get('/api/customers',                 [ApiController::class, 'getCustomers']);
$router->post('/api/transactions/deposit',     [ApiController::class, 'deposit']);
$router->post('/api/transactions/withdrawal',  [ApiController::class, 'withdrawal']);
$router->post('/api/transactions/transfer',    [ApiController::class, 'transfer']);
$router->post('/api/customers',                [ApiController::class, 'createCustomer']);
$router->post('/api/employees',                [ApiController::class, 'createEmployee']);
$router->post('/api/branches',                 [ApiController::class, 'createBranch']);
$router->post('/api/appointments',             [ApiController::class, 'createAppointment']);
$router->post('/api/loans/apply',              [ApiController::class, 'applyLoan']);
$router->post('/api/loans/approve',            [ApiController::class, 'approveLoan']);
$router->post('/api/loans/reject',             [ApiController::class, 'rejectLoan']);
$router->post('/api/kyc/verify',               [ApiController::class, 'verifyKyc']);
$router->post('/api/transactions/approve',     [ApiController::class, 'approveTransaction']);
$router->post('/api/complaints/respond',       [ApiController::class, 'respondComplaint']);
$router->post('/api/upload/profile-image',     [ApiController::class, 'uploadProfileImage']);
$router->post('/api/upload/employee-photo',    [ApiController::class, 'uploadEmployeePhoto']);
$router->post('/api/upload/document',          [ApiController::class, 'uploadDocument']);
$router->post('/api/upload/customer-document', [ApiController::class, 'uploadCustomerDocument']);
$router->post('/api/auth/change-password',     [ApiController::class, 'changePassword']);
$router->post('/api/auth/update-profile',      [ApiController::class, 'updateProfile']);

// ── Employees — Edit / Delete ─────────────────────────
$router->put('/api/employees/{id}',            [ApiController::class, 'updateEmployee']);
$router->delete('/api/employees/{id}',         [ApiController::class, 'deleteEmployee']);
$router->post('/api/employees/update',         [ApiController::class, 'updateEmployee']);   // form fallback
$router->post('/api/employees/delete',         [ApiController::class, 'deleteEmployee']);   // form fallback

// ── Customers — Edit / Delete ─────────────────────────
$router->put('/api/customers/{id}',            [ApiController::class, 'updateCustomer']);
$router->delete('/api/customers/{id}',         [ApiController::class, 'deleteCustomer']);
$router->post('/api/customers/update',         [ApiController::class, 'updateCustomer']);   // form fallback
$router->post('/api/customers/delete',         [ApiController::class, 'deleteCustomer']);   // fixes broken UI call

// ── Branches — Update / Delete ────────────────────────
$router->put('/api/branches/{id}',             [ApiController::class, 'updateBranch']);     // ApiController::updateBranch already exists
$router->delete('/api/branches/{id}',          [ApiController::class, 'deleteBranch']);
$router->post('/api/branches/update',          [ApiController::class, 'updateBranch']);
$router->post('/api/branches/delete',          [ApiController::class, 'deleteBranch']);

// ── Loans — List / Edit / Cancel ─────────────────────
$router->get('/api/loans',                     [ApiController::class, 'getLoans']);
$router->put('/api/loans/{id}',                [ApiController::class, 'updateLoan']);
$router->post('/api/loans/update',             [ApiController::class, 'updateLoan']);
$router->post('/api/loans/cancel',             [ApiController::class, 'cancelLoan']);

// ── Accounts — Open ───────────────────────────────────
$router->post('/api/accounts/open',            [ApiController::class, 'openAccount']);
$router->post('/api/accounts',                 [ApiController::class, 'openAccount']);      // alias

// ── Users (Admin) ─────────────────────────────────────
$router->get('/api/users',                     [ApiController::class, 'getUsers']);
$router->post('/api/users',                    [ApiController::class, 'createUser']);
$router->put('/api/users/{id}',                [ApiController::class, 'updateUser']);
$router->delete('/api/users/{id}',             [ApiController::class, 'deleteUser']);
$router->post('/api/users/update',             [ApiController::class, 'updateUser']);
$router->post('/api/users/delete',             [ApiController::class, 'deleteUser']);
$router->post('/api/users/reset-password',     [ApiController::class, 'resetUserPassword']);
$router->post('/api/users/toggle-lock',        [ApiController::class, 'toggleUserLock']);

// ── Attendance ────────────────────────────────────────
$router->get('/api/attendance',                [ApiController::class, 'getAttendance']);
$router->post('/api/attendance/checkin',       [ApiController::class, 'attendanceCheckin']);
$router->post('/api/attendance/checkout',      [ApiController::class, 'attendanceCheckout']);
$router->post('/api/attendance/update',        [ApiController::class, 'updateAttendance']);

// ── Leave ─────────────────────────────────────────────
$router->get('/api/leaves',                    [ApiController::class, 'getLeaves']);
$router->post('/api/leaves',                   [ApiController::class, 'applyLeave']);
$router->post('/api/leaves/approve',           [ApiController::class, 'approveLeave']);
$router->post('/api/leaves/reject',            [ApiController::class, 'rejectLeave']);

// ── Payroll ───────────────────────────────────────────
$router->post('/api/payroll/process',          [ApiController::class, 'processPayroll']);
$router->post('/api/payroll/process-all',      [ApiController::class, 'processAllPayroll']);

// ── Notifications ─────────────────────────────────────
$router->post('/api/notifications/send',       [ApiController::class, 'sendNotification']);
$router->post('/api/notifications/mark-read',  [ApiController::class, 'markNotificationRead']);
$router->post('/api/notifications/mark-all',   [ApiController::class, 'markAllNotificationsRead']);

// ── Complaints (full CRUD) ────────────────────────────
$router->get('/api/complaints',                [ApiController::class, 'getComplaints']);
$router->post('/api/complaints',               [ApiController::class, 'createComplaint']);
$router->post('/api/complaints/resolve',       [ApiController::class, 'resolveComplaint']);

// ── Appointments — confirm / cancel ──────────────────
$router->post('/api/appointments/confirm',     [ApiController::class, 'confirmAppointment']);
$router->post('/api/appointments/cancel',      [ApiController::class, 'cancelAppointment']);

// ── Settings ──────────────────────────────────────────
$router->post('/api/settings',                 [ApiController::class, 'saveSettings']);
$router->post('/api/admin/permissions',        [ApiController::class, 'savePermissions']);

// ── Dispatch ──────────────────────────────────────────
$router->dispatch();
