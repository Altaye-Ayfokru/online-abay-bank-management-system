﻿<?php

/** @var array $cards @var array $user */
$demoCards = $cards ?: [
  ['id' => 1, 'account_number' => '1000012345678', 'holder' => 'Abebe Girma', 'card_number' => '4321 **** **** 1234', 'card_type' => 'Visa Debit', 'issued_date' => '2024-03-15', 'expiry' => '2027-03-31', 'status' => 'Active', 'daily_limit' => 'ETB 50,000'],
  ['id' => 2, 'account_number' => '1000098765432', 'holder' => 'Tigist Haile', 'card_number' => '4321 **** **** 5678', 'card_type' => 'Visa Debit', 'issued_date' => '2023-07-22', 'expiry' => '2026-07-31', 'status' => 'Active', 'daily_limit' => 'ETB 50,000'],
  ['id' => 3, 'account_number' => '1000011223344', 'holder' => 'Samuel Bekele', 'card_number' => '5123 **** **** 9012', 'card_type' => 'Mastercard', 'issued_date' => '2022-11-05', 'expiry' => '2025-11-30', 'status' => 'Expired', 'daily_limit' => 'ETB 100,000'],
  ['id' => 4, 'account_number' => '1000055667788', 'holder' => 'Meron Tesfaye', 'card_number' => '4321 **** **** 3456', 'card_type' => 'Visa Debit', 'issued_date' => '2025-01-10', 'expiry' => '2028-01-31', 'status' => 'Active', 'daily_limit' => 'ETB 50,000'],
  ['id' => 5, 'account_number' => '1000099001122', 'holder' => 'Dawit Alemu', 'card_number' => '4321 **** **** 7890', 'card_type' => 'Visa Debit', 'issued_date' => '2024-09-01', 'expiry' => '2027-09-30', 'status' => 'Blocked', 'daily_limit' => 'ETB 50,000'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-credit-card" style="color:var(--primary)"></i> ATM Cards</h1>
    <p class="page-subtitle">Manage customer ATM / debit card issuance and status</p>
  </div>
  <div class="page-actions">
    <a href="<?= APP_URL ?>/cards/apply" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Issue New Card</a>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoCards), 'Total Cards', 'fa-credit-card', '#6366f1'],
    [count(array_filter($demoCards, fn($c) => $c['status'] === 'Active')), 'Active', 'fa-circle-check', '#22c55e'],
    [count(array_filter($demoCards, fn($c) => $c['status'] === 'Blocked')), 'Blocked', 'fa-ban', '#ef4444'],
    [count(array_filter($demoCards, fn($c) => $c['status'] === 'Expired')), 'Expired', 'fa-clock', '#f59e0b'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body" style="padding:16px">
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <input type="text" id="card-search" class="form-control form-control-sm" placeholder="Search by holder, account, card..." style="flex:1;min-width:200px" oninput="filterCards()">
      <select id="filter-card-status" class="form-control form-control-sm" style="width:140px" onchange="filterCards()">
        <option value="">All Status</option>
        <option>Active</option>
        <option>Blocked</option>
        <option>Expired</option>
      </select>
    </div>
  </div>
</div>

<!-- Cards Table -->
<div class="card">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Card Number</th>
            <th>Holder</th>
            <th>Account</th>
            <th>Type</th>
            <th>Issued</th>
            <th>Expiry</th>
            <th>Daily Limit</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="cards-tbody">
          <?php foreach ($demoCards as $card):
            $sc = match ($card['status']) {
              'Active' => 'badge-success',
              'Blocked' => 'badge-danger',
              default => 'badge-warning'
            };
          ?>
            <tr>
              <td class="fw-semibold" style="font-family:monospace"><?= htmlspecialchars($card['card_number']) ?></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($card['holder'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($card['holder']) ?></div>
                  </div>
                </div>
              </td>
              <td class="text-muted" style="font-family:monospace;font-size:.82rem"><?= htmlspecialchars($card['account_number']) ?></td>
              <td><span class="badge badge-info"><?= htmlspecialchars($card['card_type']) ?></span></td>
              <td class="text-muted"><?= $card['issued_date'] ?></td>
              <td class="<?= $card['status'] === 'Expired' ? 'text-danger fw-semibold' : '' ?>"><?= $card['expiry'] ?></td>
              <td><?= $card['daily_limit'] ?></td>
              <td><span class="badge <?= $sc ?>"><?= $card['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <?php if ($card['status'] === 'Active'): ?>
                    <button class="action-btn delete" data-tooltip="Block Card" onclick="blockCard(this, '<?= addslashes($card['holder']) ?>')"><i class="fa-solid fa-ban"></i></button>
                  <?php elseif ($card['status'] === 'Blocked'): ?>
                    <button class="action-btn approve" data-tooltip="Unblock" onclick="ABAY.toast('Card unblocked','success')"><i class="fa-solid fa-lock-open"></i></button>
                  <?php endif; ?>
                  <button class="action-btn edit" data-tooltip="Edit Limit" onclick="ABAY.toast('Edit card limit','info')"><i class="fa-solid fa-pen"></i></button>
                  <button class="action-btn view" data-tooltip="Replace Card" onclick="ABAY.toast('Replacement card request created','info')"><i class="fa-solid fa-rotate"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterCards() {
    const q = document.getElementById('card-search').value.toLowerCase();
    const st = document.getElementById('filter-card-status').value.toLowerCase();
    document.querySelectorAll('#cards-tbody tr').forEach(tr => {
      const txt = tr.textContent.toLowerCase();
      tr.style.display = (!q || txt.includes(q)) && (!st || txt.includes(st)) ? '' : 'none';
    });
  }

  function blockCard(btn, name) {
    if (confirm('Block card for ' + name + '? They will not be able to use the card.')) {
      ABAY.toast('Card blocked for ' + name, 'warning');
    }
  }
</script>