﻿<?php

/** @var array $cheques @var array $user */
$demoCheques = $cheques ?: [
  ['id' => 1, 'cheque_number' => 'CHQ-000001', 'customer_name' => 'Abebe Girma', 'account_number' => '1000012345678', 'amount' => 'ETB 25,000', 'payee' => 'Tigist Construction', 'issue_date' => '2026-08-15', 'status' => 'Cleared'],
  ['id' => 2, 'cheque_number' => 'CHQ-000002', 'customer_name' => 'Samuel Bekele', 'account_number' => '1000011223344', 'amount' => 'ETB 150,000', 'payee' => 'Bole Real Estate', 'issue_date' => '2026-08-18', 'status' => 'Pending'],
  ['id' => 3, 'cheque_number' => 'CHQ-000003', 'customer_name' => 'Meron Tesfaye', 'account_number' => '1000055667788', 'amount' => 'ETB 8,500', 'payee' => 'Merkato Suppliers', 'issue_date' => '2026-08-19', 'status' => 'Bounced'],
  ['id' => 4, 'cheque_number' => 'CHQ-000004', 'customer_name' => 'Dawit Alemu', 'account_number' => '1000099001122', 'amount' => 'ETB 45,000', 'payee' => 'Ethio Telecom', 'issue_date' => '2026-08-20', 'status' => 'Cleared'],
  ['id' => 5, 'cheque_number' => 'CHQ-000005', 'customer_name' => 'Hana Mulugeta', 'account_number' => '1000033445566', 'amount' => 'ETB 12,000', 'payee' => 'Ethiopian Airlines', 'issue_date' => '2026-08-21', 'status' => 'Pending'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-money-check" style="color:var(--primary)"></i> Cheque Management</h1>
    <p class="page-subtitle">Issue, track, and process customer cheques</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="ABAY.toast('Cheque book request processed','success')"><i class="fa-solid fa-book"></i> Issue Cheque Book</button>
    <button class="btn btn-primary" onclick="document.getElementById('cheque-modal').classList.add('active')"><i class="fa-solid fa-plus"></i> Record Cheque</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoCheques), 'Total Cheques', 'fa-money-check', '#6366f1'],
    [count(array_filter($demoCheques, fn($c) => $c['status'] === 'Cleared')), 'Cleared', 'fa-circle-check', '#22c55e'],
    [count(array_filter($demoCheques, fn($c) => $c['status'] === 'Pending')), 'Pending', 'fa-clock', '#f59e0b'],
    [count(array_filter($demoCheques, fn($c) => $c['status'] === 'Bounced')), 'Bounced', 'fa-triangle-exclamation', '#ef4444'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body" style="padding:16px">
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <input type="text" id="cheque-search" class="form-control form-control-sm" placeholder="Search cheque, customer, payee..." style="flex:1;min-width:200px" oninput="filterCheques()">
      <select id="cheque-status-filter" class="form-control form-control-sm" style="width:140px" onchange="filterCheques()">
        <option value="">All Status</option>
        <option>Cleared</option>
        <option>Pending</option>
        <option>Bounced</option>
      </select>
      <input type="date" class="form-control form-control-sm" style="width:145px">
    </div>
  </div>
</div>

<!-- Cheques Table -->
<div class="card">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Cheque #</th>
            <th>Customer</th>
            <th>Account</th>
            <th>Payee</th>
            <th>Amount</th>
            <th>Issue Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="cheques-tbody">
          <?php foreach ($demoCheques as $ch):
            $sc = match ($ch['status']) {
              'Cleared' => 'badge-success',
              'Bounced' => 'badge-danger',
              default => 'badge-warning'
            };
          ?>
            <tr>
              <td class="fw-semibold text-primary" style="font-family:monospace"><?= htmlspecialchars($ch['cheque_number']) ?></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($ch['customer_name'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($ch['customer_name']) ?></div>
                  </div>
                </div>
              </td>
              <td class="text-muted" style="font-family:monospace;font-size:.82rem"><?= htmlspecialchars($ch['account_number']) ?></td>
              <td><?= htmlspecialchars($ch['payee']) ?></td>
              <td class="fw-semibold"><?= $ch['amount'] ?></td>
              <td class="text-muted"><?= $ch['issue_date'] ?></td>
              <td><span class="badge <?= $sc ?>"><?= $ch['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="View" onclick="ABAY.toast('Viewing cheque details','info')"><i class="fa-solid fa-eye"></i></button>
                  <?php if ($ch['status'] === 'Pending'): ?>
                    <button class="action-btn approve" data-tooltip="Clear" onclick="ABAY.toast('Cheque cleared successfully','success')"><i class="fa-solid fa-check"></i></button>
                    <button class="action-btn delete" data-tooltip="Bounce" onclick="ABAY.toast('Cheque marked as bounced','warning')"><i class="fa-solid fa-xmark"></i></button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Record Cheque Modal -->
<div class="modal-overlay" id="cheque-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:480px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-money-check"></i> Record Cheque</h3>
      <button class="modal-close" onclick="document.getElementById('cheque-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="saveCheque(event)">
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label required">Account Number</label>
            <input type="text" class="form-control" placeholder="e.g. 1000012345678" required>
          </div>
          <div class="form-group">
            <label class="form-label required">Cheque Number</label>
            <input type="text" class="form-control" placeholder="e.g. CHQ-000006" required>
          </div>
          <div class="form-group form-group-full">
            <label class="form-label required">Payee Name</label>
            <input type="text" class="form-control" placeholder="Pay to the order of..." required>
          </div>
          <div class="form-group">
            <label class="form-label required">Amount (ETB)</label>
            <input type="number" class="form-control" placeholder="0.00" min="1" required>
          </div>
          <div class="form-group">
            <label class="form-label">Issue Date</label>
            <input type="date" class="form-control" value="<?= date('Y-m-d') ?>">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('cheque-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Record</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterCheques() {
    const q = document.getElementById('cheque-search').value.toLowerCase();
    const st = document.getElementById('cheque-status-filter').value.toLowerCase();
    document.querySelectorAll('#cheques-tbody tr').forEach(tr => {
      const txt = tr.textContent.toLowerCase();
      tr.style.display = (!q || txt.includes(q)) && (!st || txt.includes(st)) ? '' : 'none';
    });
  }

  function saveCheque(e) {
    e.preventDefault();
    document.getElementById('cheque-modal').classList.remove('active');
    ABAY.toast('Cheque recorded successfully!', 'success');
  }
</script>