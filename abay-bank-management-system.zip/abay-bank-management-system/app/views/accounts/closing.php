﻿<?php
/**
 * Abay Bank — View: Close Account
 * Auto-generated from: frontend/pages/accounts/account-closing.html
 * PHP data available: $user, $stats, $data (from PageController)
 */
?>

  <div class="page-header">
    <div class="page-header-left">
      <h1>Account Closing</h1>
      <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/dashboard">Accounts</a><span class="sep">/</span><span>Close Account</span></div>
    </div>
    <a href="<?= APP_URL ?>/dashboard" class="btn btn-ghost btn-sm"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>

  <div class="alert alert-warning" style="margin-bottom:var(--space-6)">
    <i class="fa-solid fa-triangle-exclamation alert-icon"></i>
    <div class="alert-content">
      <div class="alert-title">Account Closure is Permanent</div>
      <div class="alert-message">Closing an account cannot be undone. Ensure all outstanding balances, loans, and obligations are settled before proceeding. Manager approval is required for accounts with balance above ETB 10,000.</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:var(--space-6)">
    <div class="card">
      <div class="card-header"><h3><i class="fa-solid fa-folder-minus text-danger"></i> Account Closure Form</h3></div>
      <div class="card-body">
        <form id="close-account-form" novalidate>
          <div class="form-section"><div class="form-section-title"><i class="fa-solid fa-building-columns"></i> Account Details</div>
            <div class="form-row form-row-2">
              <div class="form-group"><label class="form-label">Account Number <span class="required">*</span></label>
                <div class="input-group"><i class="fa-solid fa-search input-icon"></i>
                  <input type="text" id="close-account-no" class="form-control" placeholder="Enter account number..." oninput="lookupCloseAccount(this.value)">
                </div>
              </div>
              <div class="form-group"><label class="form-label">Account Holder</label>
                <input type="text" id="close-holder" class="form-control" readonly placeholder="Auto-filled">
              </div>
            </div>
            <div id="close-account-preview" style="display:none;background:var(--danger-light);border:1px solid #fecaca;border-radius:var(--radius-lg);padding:var(--space-4);margin-top:var(--space-2)">
              <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:var(--space-4);text-align:center">
                <div><div style="font-size:var(--text-xs);color:var(--gray-600);font-weight:600">ACCOUNT TYPE</div><div style="font-weight:700;color:var(--danger)">Savings Account</div></div>
                <div><div style="font-size:var(--text-xs);color:var(--gray-600);font-weight:600">CURRENT BALANCE</div><div style="font-weight:800;font-size:1.2rem;color:var(--danger)">ETB 84,500.00</div></div>
                <div><div style="font-size:var(--text-xs);color:var(--gray-600);font-weight:600">OPEN SINCE</div><div style="font-weight:700">Jan 15, 2022</div></div>
              </div>
            </div>
          </div>

          <div class="form-section"><div class="form-section-title"><i class="fa-solid fa-clipboard-list"></i> Closure Details</div>
            <div class="form-row form-row-2">
              <div class="form-group"><label class="form-label">Closure Reason <span class="required">*</span></label>
                <select id="close-reason" class="form-control">
                  <option value="">Select reason...</option>
                  <option>Customer Request</option>
                  <option>Inactivity (Dormant)</option>
                  <option>Regulatory Requirement</option>
                  <option>Deceased Customer</option>
                  <option>Fraud/Suspicious Activity</option>
                  <option>Branch Transfer</option>
                  <option>Other</option>
                </select>
              </div>
              <div class="form-group"><label class="form-label">Closure Date</label>
                <input type="date" class="form-control" id="close-date">
              </div>
            </div>
            <div class="form-group"><label class="form-label">Balance Payout Method</label>
              <select class="form-control">
                <option>Cash Payment to Customer</option>
                <option>Transfer to Another Account</option>
                <option>Cheque</option>
                <option>Bank Draft</option>
              </select>
            </div>
            <div class="form-group"><label class="form-label">Transfer To Account (if applicable)</label>
              <input type="text" class="form-control" placeholder="Destination account number...">
            </div>
            <div class="form-group"><label class="form-label">Notes</label>
              <textarea class="form-control" rows="2" placeholder="Additional notes..."></textarea>
            </div>
          </div>

          <div class="form-section"><div class="form-section-title"><i class="fa-solid fa-clipboard-check"></i> Pre-closure Checklist</div>
            <div style="display:flex;flex-direction:column;gap:var(--space-3)">
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-balance"><span class="form-check-label">Outstanding balance has been settled or will be paid out</span></label>
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-loans"><span class="form-check-label">No active loans linked to this account</span></label>
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-standing"><span class="form-check-label">All standing orders and direct debits cancelled</span></label>
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-cards"><span class="form-check-label">ATM card(s) collected and destroyed</span></label>
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-cheques"><span class="form-check-label">Remaining cheque leaves collected</span></label>
              <label class="form-check"><input type="checkbox" class="form-check-input" id="check-customer"><span class="form-check-label">Customer has been informed and consented</span></label>
            </div>
          </div>

          <div class="form-actions between">
            <button type="button" class="btn btn-ghost" onclick="history.back()">Cancel</button>
            <button type="submit" class="btn btn-danger btn-lg ripple" id="close-account-btn">
              <i class="fa-solid fa-folder-minus"></i> Close Account
            </button>
          </div>
        </form>
      </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:var(--space-5)">
      <div class="card">
        <div class="card-header"><h4><i class="fa-solid fa-circle-info text-primary"></i> Closure Policy</h4></div>
        <div class="card-body" style="font-size:var(--text-sm);color:var(--text-secondary)">
          <ul style="padding-left:var(--space-4);display:flex;flex-direction:column;gap:var(--space-3);list-style:disc">
            <li>Accounts with balance below ETB 10,000: Teller can process</li>
            <li>Accounts with balance ETB 10,000�100,000: Manager approval required</li>
            <li>Accounts above ETB 100,000: Senior Manager + Audit sign-off</li>
            <li>Fixed Deposits: Early closure penalty applies</li>
            <li>Linked loans must be fully settled first</li>
            <li>Customer must present valid ID for cash payout</li>
          </ul>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h4><i class="fa-solid fa-receipt text-primary"></i> Closure Summary</h4></div>
        <div class="card-body">
          <div class="info-row"><span class="info-label">Account No.</span><span class="info-value cell-account" id="sum-close-acc">�</span></div>
          <div class="info-row"><span class="info-label">Balance</span><span class="info-value text-danger fw-bold" id="sum-close-bal">�</span></div>
          <div class="info-row"><span class="info-label">Closure Fee</span><span class="info-value">ETB 50.00</span></div>
          <div class="info-row" style="border-top:2px solid var(--border-color);padding-top:var(--space-3);margin-top:var(--space-2)">
            <span class="info-label">Net Payout</span>
            <span class="info-value text-success fw-bold" id="sum-close-net">�</span>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
