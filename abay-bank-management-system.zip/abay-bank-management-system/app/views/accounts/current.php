﻿<?php $pageTitle = 'Current Accounts — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Current Accounts</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Current Accounts</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-light btn-sm" onclick="exportCurrCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <a href="<?= APP_URL ?>/accounts/opening" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Open Account</a>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-briefcase"></i></div><div class="stat-content"><div class="stat-label">Total Current Accounts</div><div class="stat-value" id="cur-total">—</div></div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-coins"></i></div><div class="stat-content"><div class="stat-label">Total Balance</div><div class="stat-value" id="cur-balance">—</div></div></div>
  <div class="stat-card"><div class="stat-icon teal"><i class="fa-solid fa-chart-bar"></i></div><div class="stat-content"><div class="stat-label">With Overdraft</div><div class="stat-value" id="cur-overdraft">—</div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><i class="fa-solid fa-circle-check"></i></div><div class="stat-content"><div class="stat-label">Active</div><div class="stat-value" id="cur-active">—</div></div></div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-briefcase" style="color:#1B3A5C;margin-right:7px"></i>All Current Accounts</h3>
    <div style="display:flex;gap:10px"><input type="search" id="cur-search" placeholder="Search accounts..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:210px;outline:none" oninput="filterCurr(this.value)"></div>
  </div>
  <div class="table-responsive">
    <table class="data-table"><thead><tr><th>Account No.</th><th>Customer</th><th>Balance</th><th>Overdraft Limit</th><th>Opened</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody id="cur-tbody"><tr><td colspan="7" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i><div style="margin-top:8px;font-size:.84rem">Loading...</div></td></tr></tbody></table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="cur-info">Loading...</div>
    <div id="cur-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
var _curAccs=[], _filtCur=[], _cPage=1, _cPer=15;
var demoCurr=[
  {id:'AC101',account_number:'0001-20-200001',customer_name:'Dawit Mekonnen', balance:480000,overdraft_limit:100000,opened_date:'2023-01-15',status:'Active'},
  {id:'AC102',account_number:'0002-20-200002',customer_name:'Hawassa Textile',balance:1250000,overdraft_limit:500000,opened_date:'2023-03-20',status:'Active'},
  {id:'AC103',account_number:'0003-20-200003',customer_name:'Bereket Tadesse', balance:95000,overdraft_limit:50000,opened_date:'2023-06-10',status:'Active'},
  {id:'AC104',account_number:'0004-20-200004',customer_name:'Addis Printing', balance:2100000,overdraft_limit:1000000,opened_date:'2022-11-05',status:'Active'},
  {id:'AC105',account_number:'0005-20-200005',customer_name:'Yared Gebre',    balance:12000,overdraft_limit:0,opened_date:'2024-01-22',status:'Frozen'},
];
function loadCurr(){ABAY.api('/accounts?account_type=Current&per_page=200').then(function(d){var rows=(d&&d.success&&d.data&&d.data.length)?d.data:demoCurr;_curAccs=rows;updateCurrStats(rows);filterCurr();}).catch(function(){_curAccs=demoCurr;updateCurrStats(demoCurr);filterCurr();});}
function updateCurrStats(r){document.getElementById('cur-total').textContent=ABAY.fmtNum(r.length);document.getElementById('cur-active').textContent=ABAY.fmtNum(r.filter(function(x){return x.status==='Active';}).length);var bal=r.reduce(function(s,x){return s+parseFloat(x.balance||0);},0);document.getElementById('cur-balance').textContent=bal>1e6?'ETB '+(bal/1e6).toFixed(1)+'M':ABAY.fmtETB(bal);document.getElementById('cur-overdraft').textContent=ABAY.fmtNum(r.filter(function(x){return parseFloat(x.overdraft_limit||0)>0;}).length);}
function filterCurr(q){var s=(typeof q==='string'?q:document.getElementById('cur-search').value).toLowerCase();_filtCur=_curAccs.filter(function(a){return !s||(a.account_number||'').toLowerCase().includes(s)||(a.customer_name||'').toLowerCase().includes(s);});_cPage=1;renderCurr();}
function renderCurr(){var t=document.getElementById('cur-tbody'),total=_filtCur.length,start=(_cPage-1)*_cPer,slice=_filtCur.slice(start,start+_cPer);if(!total){t.innerHTML='<tr><td colspan="7" style="text-align:center;padding:40px;color:#94a3b8">No accounts found</td></tr>';return;}t.innerHTML=slice.map(function(a){return '<tr><td><span style="font-family:monospace;font-size:.77rem;color:#475569;font-weight:600">'+(a.account_number||'—')+'</span></td><td style="font-size:.83rem;font-weight:600;color:#1e293b">'+(a.customer_name||'—')+'</td><td style="font-weight:700;font-size:.83rem;color:#1B3A5C">'+ABAY.fmtETB(a.balance||0)+'</td><td style="font-size:.82rem;color:#f59e0b">'+ABAY.fmtETB(a.overdraft_limit||0)+'</td><td style="font-size:.78rem;color:#94a3b8">'+(a.opened_date||'—').split('T')[0]+'</td><td>'+ABAY.badge(a.status||'Active')+'</td><td><a href="<?= APP_URL ?>/transactions/deposit" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Deposit"><i class="fa-solid fa-arrow-down" style="color:#10b981"></i></a></td></tr>';}).join('');document.getElementById('cur-info').textContent='Showing '+(start+1)+'–'+Math.min(start+_cPer,total)+' of '+total;var pg=document.getElementById('cur-pagination'),html='';for(var i=1;i<=Math.ceil(total/_cPer);i++)html+='<button onclick="_cPage='+i+';renderCurr()" style="width:30px;height:30px;border:1.5px solid '+(_cPage===i?'#007A8A':'#e2e8f0')+';background:'+(_cPage===i?'#007A8A':'#fff')+';color:'+(_cPage===i?'#fff':'#475569')+';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">'+i+'</button>';pg.innerHTML=html;}
function exportCurrCSV(){var rows=[['Account No.','Customer','Balance','Overdraft Limit','Status']].concat(_filtCur.map(function(a){return[a.account_number,a.customer_name,a.balance,a.overdraft_limit,a.status];}));var csv=rows.map(function(r){return r.map(function(v){return'"'+v+'"';}).join(',');}).join('\n');var a=document.createElement('a');a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);a.download='current-accounts.csv';a.click();}
document.addEventListener('DOMContentLoaded',loadCurr);
</script>