﻿<?php $pageTitle = 'Fixed Deposit Accounts — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Fixed Deposit Accounts</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Fixed Deposit</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-light btn-sm" onclick="exportFDCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <a href="<?= APP_URL ?>/accounts/opening" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> New FD</a>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-lock"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total FD Accounts</div>
      <div class="stat-value" id="fd-total">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-coins"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Invested</div>
      <div class="stat-value" id="fd-invested">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-percent"></i></div>
    <div class="stat-content">
      <div class="stat-label">Avg. Interest Rate</div>
      <div class="stat-value">9.5%</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-calendar-days"></i></div>
    <div class="stat-content">
      <div class="stat-label">Maturing This Month</div>
      <div class="stat-value" id="fd-maturing">—</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-lock" style="color:#1B3A5C;margin-right:7px"></i>All Fixed Deposit Accounts</h3>
    <div style="display:flex;gap:10px">
      <input type="search" id="fd-search" placeholder="Search accounts..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:210px;outline:none" oninput="filterFD(this.value)">
      <select id="fd-status-filter" onchange="filterFD()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
        <option value="">All Status</option>
        <option>Active</option>
        <option>Matured</option>
        <option>Closed</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Account No.</th>
          <th>Customer</th>
          <th>Principal</th>
          <th>Interest Rate</th>
          <th>Duration</th>
          <th>Maturity Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="fd-tbody">
        <tr>
          <td colspan="8" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
            <div style="margin-top:8px;font-size:.84rem">Loading...</div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="fd-info">Loading...</div>
    <div id="fd-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _fdAccs = [],
    _filtFD = [],
    _fPage = 1,
    _fPer = 15;
  var demoFD = [{
      id: 'FD001',
      account_number: '0001-30-300001',
      customer_name: 'Abebe Bekele',
      balance: 500000,
      interest_rate: 12.0,
      fd_duration: 36,
      fd_maturity_date: date('Y-m-d', strtotime('+18 months')),
      opened_date: '2023-06-15',
      status: 'Active'
    },
    {
      id: 'FD002',
      account_number: '0002-30-300002',
      customer_name: 'Selamawit Girma',
      balance: 1000000,
      interest_rate: 12.5,
      fd_duration: 60,
      fd_maturity_date: date('Y-m-d', strtotime('+30 months')),
      opened_date: '2022-12-01',
      status: 'Active'
    },
    {
      id: 'FD003',
      account_number: '0003-30-300003',
      customer_name: 'Daniel Worku',
      balance: 250000,
      interest_rate: 9.5,
      fd_duration: 12,
      fd_maturity_date: date('Y-m-d', strtotime('+1 month')),
      opened_date: '2025-08-01',
      status: 'Active'
    },
    {
      id: 'FD004',
      account_number: '0004-30-300004',
      customer_name: 'Meron Alemu',
      balance: 750000,
      interest_rate: 11.0,
      fd_duration: 24,
      fd_maturity_date: date('Y-m-d', strtotime('-3 months')),
      opened_date: '2023-01-15',
      status: 'Matured'
    },
  ];
  var thisMonth = '<?= date('Y-m') ?>';

  function loadFD() {
    ABAY.api('/accounts?account_type=Fixed+Deposit&per_page=200').then(function(d) {
      var rows = (d && d.success && d.data && d.data.length) ? d.data : demoFD;
      _fdAccs = rows;
      updateFDStats(rows);
      filterFD();
    }).catch(function() {
      _fdAccs = demoFD;
      updateFDStats(demoFD);
      filterFD();
    });
  }

  function updateFDStats(r) {
    var total = r.length,
      invested = r.reduce(function(s, x) {
        return s + parseFloat(x.balance || 0);
      }, 0),
      maturing = r.filter(function(x) {
        return (x.fd_maturity_date || '').startsWith(thisMonth);
      }).length;
    document.getElementById('fd-total').textContent = ABAY.fmtNum(total);
    document.getElementById('fd-invested').textContent = invested > 1e6 ? 'ETB ' + (invested / 1e6).toFixed(1) + 'M' : ABAY.fmtETB(invested);
    document.getElementById('fd-maturing').textContent = ABAY.fmtNum(maturing);
  }

  function filterFD(q) {
    var s = (typeof q === 'string' ? q : document.getElementById('fd-search').value).toLowerCase();
    var status = document.getElementById('fd-status-filter').value;
    _filtFD = _fdAccs.filter(function(a) {
      return (!s || (a.account_number || '').toLowerCase().includes(s) || (a.customer_name || '').toLowerCase().includes(s)) && (!status || a.status === status);
    });
    _fPage = 1;
    renderFD();
  }

  function renderFD() {
    var t = document.getElementById('fd-tbody'),
      total = _filtFD.length,
      start = (_fPage - 1) * _fPer,
      slice = _filtFD.slice(start, start + _fPer);
    if (!total) {
      t.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No accounts found</td></tr>';
      return;
    }
    t.innerHTML = slice.map(function(a) {
      var matDate = a.fd_maturity_date || '—';
      var isClose = matDate !== '—' && new Date(matDate) - new Date() < 30 * 86400000 && new Date(matDate) > new Date();
      return '<tr><td><span style="font-family:monospace;font-size:.77rem;color:#475569;font-weight:600">' + (a.account_number || '—') + '</span></td><td style="font-size:.83rem;font-weight:600;color:#1e293b">' + (a.customer_name || '—') + '</td><td style="font-weight:700;font-size:.83rem;color:#1B3A5C">' + ABAY.fmtETB(a.balance || 0) + '</td><td style="font-size:.82rem;color:#059669;font-weight:700">' + (a.interest_rate || 0) + '% p.a.</td><td style="font-size:.82rem">' + (a.fd_duration || 0) + ' months</td><td style="font-size:.78rem;' + (isClose ? 'color:#d97706;font-weight:700' : '') + '">' + (isClose ? '<i class="fa-solid fa-triangle-exclamation" style="margin-right:4px;color:#d97706"></i>' : '') + matDate + '</td><td>' + ABAY.badge(a.status || 'Active') + '</td><td><a href="<?= APP_URL ?>/accounts/statement" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Statement"><i class="fa-solid fa-file-lines"></i></a></td></tr>';
    }).join('');
    document.getElementById('fd-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _fPer, total) + ' of ' + total;
    var pg = document.getElementById('fd-pagination'),
      html = '';
    for (var i = 1; i <= Math.ceil(total / _fPer); i++) html += '<button onclick="_fPage=' + i + ';renderFD()" style="width:30px;height:30px;border:1.5px solid ' + (_fPage === i ? '#007A8A' : '#e2e8f0') + ';background:' + (_fPage === i ? '#007A8A' : '#fff') + ';color:' + (_fPage === i ? '#fff' : '#475569') + ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">' + i + '</button>';
    pg.innerHTML = html;
  }

  function exportFDCSV() {
    var rows = [
      ['Account No.', 'Customer', 'Principal', 'Rate', 'Duration', 'Maturity', 'Status']
    ].concat(_filtFD.map(function(a) {
      return [a.account_number, a.customer_name, a.balance, a.interest_rate + '%', a.fd_duration + ' mo', a.fd_maturity_date || '', a.status];
    }));
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'fixed-deposits.csv';
    a.click();
  }
  document.addEventListener('DOMContentLoaded', loadFD);
</script>