<?php

/**
 * Abay Bank — View: Open Account
 * Auto-generated from: frontend/pages/accounts/account-opening.html
 * PHP data available: $user, $stats, $data (from PageController)
 */
?>

<div class="page-header">
  <div class="page-header-left">
    <h1>Open New Account</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Open Account</span></div>
  </div>
  <a href="<?= APP_URL ?>/dashboard" class="btn btn-ghost btn-sm"><i class="fa-solid fa-arrow-left"></i> Back</a>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:var(--space-6)">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-folder-open text-primary"></i> Account Details</h3>
    </div>
    <div class="card-body">
      <form id="account-open-form" novalidate>
        <div class="form-section">
          <div class="form-section-title"><i class="fa-solid fa-user"></i> Customer</div>
          <div class="form-row form-row-2">
            <div class="form-group"><label class="form-label">Customer ID / Name <span class="required">*</span></label>
              <div class="input-group"><i class="fa-solid fa-search input-icon"></i><input type="text" id="account-customer" name="account-customer" class="form-control" placeholder="Search by ID or name..."></div>
            </div>
            <div class="form-group"><label class="form-label">Branch <span class="required">*</span></label>
              <select class="form-control">
                <option value="">Select branch...</option>
                <option>Addis Ababa Main</option>
                <option>Bole</option>
                <option>Kirkos</option>
                <option>Arada</option>
                <option>Alem Ketema</option>
              </select>
            </div>
          </div>
        </div>
        <div class="form-section">
          <div class="form-section-title"><i class="fa-solid fa-building-columns"></i> Account Type</div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:var(--space-4);margin-bottom:var(--space-5)">
            <label style="cursor:pointer"><input type="radio" name="account_type" value="savings" checked style="display:none">
              <div class="account-type-card" style="border:2px solid var(--primary);border-radius:var(--radius-lg);padding:var(--space-5);text-align:center;transition:all .2s">
                <i class="fa-solid fa-piggy-bank" style="font-size:2rem;color:var(--primary);margin-bottom:var(--space-3)"></i>
                <div style="font-weight:700;margin-bottom:4px">Savings</div>
                <div style="font-size:var(--text-xs);color:var(--text-muted)">3.5% p.a. interest</div>
              </div>
            </label>
            <label style="cursor:pointer"><input type="radio" name="account_type" value="current" style="display:none">
              <div class="account-type-card" style="border:2px solid var(--border-color);border-radius:var(--radius-lg);padding:var(--space-5);text-align:center;transition:all .2s">
                <i class="fa-solid fa-wallet" style="font-size:2rem;color:var(--text-muted);margin-bottom:var(--space-3)"></i>
                <div style="font-weight:700;margin-bottom:4px">Current</div>
                <div style="font-size:var(--text-xs);color:var(--text-muted)">No interest, unlimited txns</div>
              </div>
            </label>
            <label style="cursor:pointer"><input type="radio" name="account_type" value="fixed_deposit" style="display:none">
              <div class="account-type-card" style="border:2px solid var(--border-color);border-radius:var(--radius-lg);padding:var(--space-5);text-align:center;transition:all .2s">
                <i class="fa-solid fa-lock" style="font-size:2rem;color:var(--text-muted);margin-bottom:var(--space-3)"></i>
                <div style="font-weight:700;margin-bottom:4px">Fixed Deposit</div>
                <div style="font-size:var(--text-xs);color:var(--text-muted)">Up to 9.5% p.a.</div>
              </div>
            </label>
          </div>
          <div id="fd-fields" style="display:none">
            <div class="form-row form-row-2">
              <div class="form-group"><label class="form-label">FD Duration</label>
                <select class="form-control">
                  <option>3 Months (6.5%)</option>
                  <option>6 Months (7.5%)</option>
                  <option>12 Months (8.5%)</option>
                  <option>24 Months (9.0%)</option>
                  <option>36 Months (9.5%)</option>
                </select>
              </div>
              <div class="form-group"><label class="form-label">Maturity Date</label><input type="date" class="form-control" readonly></div>
            </div>
          </div>
        </div>
        <div class="form-section">
          <div class="form-section-title"><i class="fa-solid fa-coins"></i> Initial Deposit</div>
          <div class="form-row form-row-2">
            <div class="form-group"><label class="form-label">Amount (ETB) <span class="required">*</span></label>
              <div class="input-addon-group"><span class="input-addon">ETB</span><input type="number" id="initial-deposit" name="initial-deposit" class="form-control" placeholder="500.00" min="100" data-format="amount"></div>
            </div>
            <div class="form-group"><label class="form-label">Currency</label>
              <select class="form-control">
                <option>ETB</option>
                <option>USD</option>
                <option>EUR</option>
              </select>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" onclick="history.back()">Cancel</button>
          <button type="submit" class="btn btn-primary btn-lg ripple"><i class="fa-solid fa-folder-open"></i> Open Account</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Info panel -->
  <div style="display:flex;flex-direction:column;gap:var(--space-5)">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-circle-info text-primary"></i> Account Types</h4>
      </div>
      <div class="card-body" style="font-size:var(--text-sm)">
        <div style="margin-bottom:var(--space-4)"><strong style="color:var(--primary)">Savings Account</strong>
          <p class="mb-2">Earn 3.5% annual interest. Minimum balance ETB 100. Unlimited deposits, limited withdrawals.</p>
        </div>
        <div style="margin-bottom:var(--space-4)"><strong style="color:var(--primary)">Current Account</strong>
          <p class="mb-2">No interest. Ideal for businesses. Unlimited transactions. Overdraft facility available.</p>
        </div>
        <div><strong style="color:var(--primary)">Fixed Deposit</strong>
          <p class="mb-0">Lock funds for 3�36 months. Higher interest up to 9.5%. Early withdrawal penalties apply.</p>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-calculator text-primary"></i> Interest Preview</h4>
      </div>
      <div class="card-body text-center">
        <div style="font-size:var(--text-xs);color:var(--text-muted);margin-bottom:var(--space-1)">Annual Interest (3.5%)</div>
        <div style="font-size:var(--text-2xl);font-weight:800;color:var(--success)" id="interest-preview">ETB 0.00</div>
        <div style="font-size:var(--text-xs);color:var(--text-muted);margin-top:var(--space-2)">Based on initial deposit</div>
      </div>
    </div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  /* ── Account Opening Form — full submit handler ── */
  (function() {
    var form = document.getElementById('account-open-form');
    var depInp = document.getElementById('initial-deposit');
    var prevEl = document.getElementById('interest-preview');

    /* Live interest preview */
    if (depInp && prevEl) {
      depInp.addEventListener('input', function() {
        var amt = parseFloat(this.value) || 0;
        var type = (document.querySelector('input[name="account_type"]:checked') || {}).value || 'savings';
        var rate = {
          savings: 0.035,
          current: 0,
          fixed_deposit: 0.085
        } [type] || 0.035;
        var interest = amt * rate;
        prevEl.textContent = 'ETB ' + interest.toLocaleString('en-ET', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
      });
    }

    /* Account type card selection */
    document.querySelectorAll('input[name="account_type"]').forEach(function(radio) {
      radio.addEventListener('change', function() {
        document.querySelectorAll('.account-type-card').forEach(function(c) {
          c.style.border = '2px solid var(--border-color)';
          c.querySelectorAll('i').forEach(function(i) {
            i.style.color = 'var(--text-muted)';
          });
        });
        var card = radio.nextElementSibling;
        if (card) {
          card.style.border = '2px solid var(--primary)';
          card.querySelectorAll('i').forEach(function(i) {
            i.style.color = 'var(--primary)';
          });
        }
        var fdFields = document.getElementById('fd-fields');
        if (fdFields) fdFields.style.display = radio.value === 'fixed_deposit' ? '' : 'none';
        if (depInp) depInp.dispatchEvent(new Event('input'));
      });
    });

    /* Form submit */
    if (!form) return;
    form.addEventListener('submit', function(e) {
      e.preventDefault();

      var custSearch = (document.getElementById('account-customer') || {}).value || '';
      var accountType = (document.querySelector('input[name="account_type"]:checked') || {}).value || 'savings';
      var deposit = parseFloat((depInp || {}).value) || 0;
      var branchSel = form.querySelector('select');
      var branch = branchSel ? branchSel.value : '';
      var currency = (form.querySelectorAll('select')[1] || {}).value || 'ETB';

      /* Validation */
      if (!custSearch) {
        showOpenErr('Please enter a customer name or ID.');
        return;
      }
      if (deposit < 100) {
        showOpenErr('Minimum initial deposit is ETB 100.');
        return;
      }

      var submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle"></span> Opening…';
      }

      var base = window.BASE_URL || '';
      fetch(base + '/api/accounts/open', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
          },
          body: JSON.stringify({
            customer_search: custSearch,
            account_type: accountType.replace('_', ' ').replace(/\b\w/g, function(c) {
              return c.toUpperCase();
            }),
            initial_deposit: deposit,
            branch: branch,
            currency: currency
          })
        })
        .then(function(r) {
          return r.json();
        })
        .then(function(d) {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-folder-open"></i> Open Account';
          }
          if (d && d.success) {
            var accNo = (d.data && d.data.account_number) || '';
            showOpenOk('Account opened successfully! Account Number: <strong>' + accNo + '</strong>');
            if (window.ABAY) ABAY.toast('Account ' + accNo + ' opened!', 'ok');
            form.reset();
            /* Redirect to accounts list after 2s */
            setTimeout(function() {
              window.location.href = base + '/accounts/savings';
            }, 2200);
          } else {
            showOpenErr((d && d.message) || 'Failed to open account.');
          }
        })
        .catch(function() {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-folder-open"></i> Open Account';
          }
          var demoAccNo = '100' + Date.now().toString().slice(-8);
          showOpenOk('Demo: Account <strong>' + demoAccNo + '</strong> opened (database offline).');
          if (window.ABAY) ABAY.toast('Demo: Account ' + demoAccNo + ' opened!', 'info');
          setTimeout(function() {
            form.reset();
          }, 2000);
        });
    });

    function showOpenOk(html) {
      var el = document.getElementById('open-acc-ok');
      if (!el) {
        el = document.createElement('div');
        el.id = 'open-acc-ok';
        el.style.cssText = 'background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:12px 16px;margin-bottom:14px;font-size:.86rem;color:#065f46';
        form.insertBefore(el, form.firstChild);
      }
      el.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:7px"></i>' + html;
      el.style.display = 'block';
      document.getElementById('open-acc-err') && (document.getElementById('open-acc-err').style.display = 'none');
    }

    function showOpenErr(msg) {
      var el = document.getElementById('open-acc-err');
      if (!el) {
        el = document.createElement('div');
        el.id = 'open-acc-err';
        el.style.cssText = 'background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:12px 16px;margin-bottom:14px;font-size:.86rem;color:#991b1b';
        form.insertBefore(el, form.firstChild);
      }
      el.innerHTML = '<i class="fa-solid fa-circle-xmark" style="margin-right:7px"></i>' + msg;
      el.style.display = 'block';
    }
  })();
</script>