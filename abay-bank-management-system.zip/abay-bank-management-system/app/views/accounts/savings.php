<?php $pageTitle = 'Savings Accounts — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Savings Accounts</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Savings Accounts</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-light btn-sm" onclick="exportAccCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <a href="<?= APP_URL ?>/accounts/opening" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Open Account</a>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-piggy-bank"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Savings Accounts</div>
      <div class="stat-value" id="sav-total">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-coins"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Deposits</div>
      <div class="stat-value" id="sav-deposits">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-percent"></i></div>
    <div class="stat-content">
      <div class="stat-label">Avg. Interest Rate</div>
      <div class="stat-value">3.5%</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Active</div>
      <div class="stat-value" id="sav-active">—</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-piggy-bank" style="color:#1B3A5C;margin-right:7px"></i>All Savings Accounts</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input type="search" id="sav-search" placeholder="Search accounts..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:210px;outline:none" oninput="filterAccs(this.value)">
      <select id="sav-status-filter" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer" onchange="filterAccs()">
        <option value="">All Status</option>
        <option>Active</option>
        <option>Frozen</option>
        <option>Closed</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Account No.</th>
          <th>Customer</th>
          <th>Balance</th>
          <th>Interest Rate</th>
          <th>Opened</th>
          <th>Last Txn</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="sav-tbody">
        <tr>
          <td colspan="8" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
            <div style="margin-top:8px;font-size:.84rem">Loading accounts...</div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="sav-info">Loading...</div>
    <div id="sav-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allAccs = [],
    _filtAccs = [],
    _savPage = 1,
    _savPer = 15;
  var demoAccs = [{
      id: 'AC001',
      account_number: '0001-10-100001',
      customer_name: 'Abebe Bekele',
      balance: 84500,
      interest_rate: 3.5,
      opened_date: '2024-01-15',
      last_transaction: '2026-08-20',
      status: 'Active'
    },
    {
      id: 'AC002',
      account_number: '0001-10-100002',
      customer_name: 'Tigist Haile',
      balance: 125000,
      interest_rate: 3.5,
      opened_date: '2024-02-20',
      last_transaction: '2026-08-19',
      status: 'Active'
    },
    {
      id: 'AC003',
      account_number: '0002-10-100003',
      customer_name: 'Solomon Girma',
      balance: 45000,
      interest_rate: 3.5,
      opened_date: '2024-03-10',
      last_transaction: '2026-08-18',
      status: 'Active'
    },
    {
      id: 'AC004',
      account_number: '0003-10-100004',
      customer_name: 'Meron Alemu',
      balance: 220000,
      interest_rate: 3.5,
      opened_date: '2024-03-25',
      last_transaction: '2026-08-20',
      status: 'Active'
    },
    {
      id: 'AC005',
      account_number: '0004-10-100005',
      customer_name: 'Dawit Mekonnen',
      balance: 15000,
      interest_rate: 3.5,
      opened_date: '2024-04-05',
      last_transaction: '2026-08-15',
      status: 'Active'
    },
    {
      id: 'AC006',
      account_number: '0005-10-100006',
      customer_name: 'Hanna Getnet',
      balance: 0,
      interest_rate: 3.5,
      opened_date: '2023-06-01',
      last_transaction: '2025-12-01',
      status: 'Frozen'
    },
  ];

  function loadAccs() {
    ABAY.api('/accounts?account_type=Savings&per_page=200').then(function(d) {
      var rows = (d && d.success && d.data && d.data.length) ? d.data : demoAccs;
      _allAccs = rows;
      updateAccStats(rows);
      filterAccs();
    }).catch(function() {
      _allAccs = demoAccs;
      updateAccStats(demoAccs);
      filterAccs();
    });
  }

  function updateAccStats(rows) {
    var total = rows.length,
      active = 0,
      deposits = 0;
    rows.forEach(function(r) {
      if (r.status === 'Active') active++;
      deposits += parseFloat(r.balance || 0);
    });
    document.getElementById('sav-total').textContent = ABAY.fmtNum(total);
    document.getElementById('sav-deposits').textContent = deposits > 1e9 ? 'ETB ' + (deposits / 1e9).toFixed(1) + 'B' : (deposits > 1e6 ? 'ETB ' + (deposits / 1e6).toFixed(1) + 'M' : ABAY.fmtETB(deposits));
    document.getElementById('sav-active').textContent = ABAY.fmtNum(active);
  }

  function filterAccs(q) {
    var search = (typeof q === 'string' ? q : document.getElementById('sav-search').value).toLowerCase();
    var status = document.getElementById('sav-status-filter').value;
    _filtAccs = _allAccs.filter(function(a) {
      return (!search || (a.account_number || '').toLowerCase().includes(search) || (a.customer_name || '').toLowerCase().includes(search)) && (!status || a.status === status);
    });
    _savPage = 1;
    renderAccs();
  }

  function renderAccs() {
    var tbody = document.getElementById('sav-tbody');
    var total = _filtAccs.length;
    var start = (_savPage - 1) * _savPer;
    var slice = _filtAccs.slice(start, start + _savPer);
    if (!total) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No accounts found</td></tr>';
      return;
    }
    tbody.innerHTML = slice.map(function(a) {
      return '<tr>' +
        '<td><span style="font-family:monospace;font-size:.77rem;color:#475569;font-weight:600">' + (a.account_number || '—') + '</span></td>' +
        '<td style="font-size:.83rem;font-weight:600;color:#1e293b">' + (a.customer_name || '—') + '</td>' +
        '<td style="font-weight:700;font-size:.83rem;color:#059669">' + ABAY.fmtETB(a.balance || 0) + '</td>' +
        '<td style="font-size:.82rem">' + (a.interest_rate || 3.5) + '%</td>' +
        '<td style="font-size:.78rem;color:#94a3b8">' + (a.opened_date || (a.created_at || '—').split('T')[0]) + '</td>' +
        '<td style="font-size:.78rem;color:#94a3b8">' + (a.last_transaction || a.updated_at || '—') + '</td>' +
        '<td>' + ABAY.badge(a.status || 'Active') + '</td>' +
        '<td><div style="display:flex;gap:4px">' +
        '<a href="<?= APP_URL ?>/transactions/deposit" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Deposit"><i class="fa-solid fa-arrow-down" style="color:#10b981"></i></a>' +
        '<a href="<?= APP_URL ?>/accounts/statement" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Statement"><i class="fa-solid fa-file-lines"></i></a>' +
        '</div></td>' +
        '</tr>';
    }).join('');
    document.getElementById('sav-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _savPer, total) + ' of ' + total + ' accounts';
    var pages = Math.ceil(total / _savPer);
    var pg = document.getElementById('sav-pagination');
    var html = '';
    for (var i = 1; i <= pages; i++) html += '<button onclick="_savPage=' + i + ';renderAccs()" style="width:30px;height:30px;border:1.5px solid ' + (_savPage === i ? '#007A8A' : '#e2e8f0') + ';background:' + (_savPage === i ? '#007A8A' : '#fff') + ';color:' + (_savPage === i ? '#fff' : '#475569') + ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">' + i + '</button>';
    pg.innerHTML = html;
  }

  function exportAccCSV() {
    var rows = [
      ['Account No.', 'Customer', 'Balance', 'Interest Rate', 'Status']
    ].concat(_filtAccs.map(function(a) {
      return [a.account_number, a.customer_name, a.balance, a.interest_rate + '%', a.status];
    }));
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'savings-accounts.csv';
    a.click();
  }
  document.addEventListener('DOMContentLoaded', loadAccs);
</script>