﻿<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-file-lines" style="color:var(--primary)"></i> Account Statement</h1>
    <p class="page-subtitle">View detailed transaction history for any account</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
    <button class="btn btn-primary" id="export-btn" onclick="exportStatement()"><i class="fa-solid fa-file-pdf"></i> Export PDF</button>
  </div>
</div>

<!-- Account Search -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-magnifying-glass"></i> Search Account</h3>
  </div>
  <div class="card-body">
    <form onsubmit="loadStatement(event)" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div class="form-group" style="flex:1;min-width:200px;margin:0">
        <label class="form-label">Account Number</label>
        <input type="text" id="acct-input" class="form-control" placeholder="e.g. 1000012345678" value="<?= htmlspecialchars($_GET['account'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">From</label>
        <input type="date" id="date-from" class="form-control" value="<?= date('Y-m-01') ?>">
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">To</label>
        <input type="date" id="date-to" class="form-control" value="<?= date('Y-m-d') ?>">
      </div>
      <button type="submit" class="btn btn-primary">
        <i class="fa-solid fa-search"></i> Load Statement
      </button>
    </form>
  </div>
</div>

<!-- Account Summary (shown after search) -->
<div id="statement-area" style="display:none">
  <!-- Account Header -->
  <div class="card" style="margin-bottom:20px">
    <div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
        <div>
          <h3 id="acct-holder" style="margin:0 0 4px">Abebe Girma</h3>
          <div class="text-muted" style="font-size:.85rem"><span id="acct-num">1000012345678</span> · <span id="acct-type">Savings Account</span></div>
        </div>
        <div style="text-align:right">
          <div class="text-muted" style="font-size:.82rem">Current Balance</div>
          <div id="acct-balance" style="font-size:1.6rem;font-weight:700;color:var(--primary)">ETB 84,250.00</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Statement Stats -->
  <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:20px">
    <div class="stat-card">
      <div class="stat-icon" style="background:#22c55e20;color:#22c55e"><i class="fa-solid fa-arrow-down"></i></div>
      <div class="stat-info">
        <div class="stat-value" id="total-credits">ETB 0</div>
        <div class="stat-label">Total Credits</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#ef444420;color:#ef4444"><i class="fa-solid fa-arrow-up"></i></div>
      <div class="stat-info">
        <div class="stat-value" id="total-debits">ETB 0</div>
        <div class="stat-label">Total Debits</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#6366f120;color:#6366f1"><i class="fa-solid fa-list-ol"></i></div>
      <div class="stat-info">
        <div class="stat-value" id="txn-count">0</div>
        <div class="stat-label">Transactions</div>
      </div>
    </div>
  </div>

  <!-- Statement Table -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Transaction History</h3>
      <div class="card-tools">
        <input type="text" class="form-control form-control-sm" placeholder="Filter..." style="width:200px" oninput="filterStatement(this.value)">
      </div>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Reference</th>
              <th>Description</th>
              <th style="text-align:right">Credit</th>
              <th style="text-align:right">Debit</th>
              <th style="text-align:right">Balance</th>
            </tr>
          </thead>
          <tbody id="statement-tbody">
            <!-- filled by JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  const DEMO_TXNS = [{
      date: '2026-08-01',
      ref: 'TXN-00401',
      desc: 'Opening Balance',
      credit: 100000,
      debit: 0
    },
    {
      date: '2026-08-03',
      ref: 'TXN-00412',
      desc: 'ATM Withdrawal - Bole Branch',
      credit: 0,
      debit: 5000
    },
    {
      date: '2026-08-05',
      ref: 'TXN-00425',
      desc: 'Salary Credit - Abay Bank',
      credit: 18500,
      debit: 0
    },
    {
      date: '2026-08-08',
      ref: 'TXN-00434',
      desc: 'Utility Bill Payment - Ethio Electric',
      credit: 0,
      debit: 450
    },
    {
      date: '2026-08-10',
      ref: 'TXN-00448',
      desc: 'Fund Transfer Received from S. Bekele',
      credit: 5000,
      debit: 0
    },
    {
      date: '2026-08-14',
      ref: 'TXN-00461',
      desc: 'ATM Withdrawal - HQ',
      credit: 0,
      debit: 10000
    },
    {
      date: '2026-08-18',
      ref: 'TXN-00472',
      desc: 'Interest Credit - Monthly',
      credit: 250,
      debit: 0
    },
    {
      date: '2026-08-20',
      ref: 'TXN-00481',
      desc: 'Mobile Recharge - Ethio Telecom',
      credit: 0,
      debit: 500
    },
    {
      date: '2026-08-21',
      ref: 'TXN-00488',
      desc: 'Deposit - Counter',
      credit: 15000,
      debit: 0
    },
  ];

  function loadStatement(e) {
    e.preventDefault();
    const acct = document.getElementById('acct-input').value || '1000012345678';
    document.getElementById('acct-num').textContent = acct;
    document.getElementById('statement-area').style.display = '';

    let balance = 0;
    let credits = 0;
    let debits = 0;

    const tbody = document.getElementById('statement-tbody');
    tbody.innerHTML = DEMO_TXNS.map(t => {
      if (t.credit) {
        balance += t.credit;
        credits += t.credit;
      }
      if (t.debit) {
        balance -= t.debit;
        debits += t.debit;
      }
      const isCredit = t.credit > 0;
      return `<tr>
      <td class="text-muted">${t.date}</td>
      <td><code style="font-size:.8rem">${t.ref}</code></td>
      <td>${t.desc}</td>
      <td style="text-align:right;color:#22c55e">${t.credit ? '+ETB ' + t.credit.toLocaleString('en-US',{minimumFractionDigits:2}) : ''}</td>
      <td style="text-align:right;color:#ef4444">${t.debit ? '-ETB ' + t.debit.toLocaleString('en-US',{minimumFractionDigits:2}) : ''}</td>
      <td style="text-align:right;font-weight:600">ETB ${balance.toLocaleString('en-US',{minimumFractionDigits:2})}</td>
    </tr>`;
    }).join('');

    document.getElementById('total-credits').textContent = 'ETB ' + credits.toLocaleString();
    document.getElementById('total-debits').textContent = 'ETB ' + debits.toLocaleString();
    document.getElementById('txn-count').textContent = DEMO_TXNS.length;
    document.getElementById('acct-balance').textContent = 'ETB ' + balance.toLocaleString('en-US', {
      minimumFractionDigits: 2
    });
  }

  function filterStatement(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#statement-tbody tr').forEach(tr => {
      tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  }

  function exportStatement() {
    ABAY.toast('Statement exported to PDF', 'success');
  }

  // Auto-load if account param present
  <?php if (!empty($_GET['account'])): ?>
    document.addEventListener('DOMContentLoaded', () => {
      document.getElementById('acct-input').value = '<?= htmlspecialchars($_GET['account'] ?? '') ?>';
      loadStatement(new Event('submit'));
    });
  <?php endif; ?>
</script>