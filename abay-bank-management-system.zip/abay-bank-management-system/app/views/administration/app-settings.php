<?php $pageTitle = 'App Settings — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-mobile-screen" style="color:#1B3A5C;margin-right:8px"></i>App Settings</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/admin/settings">Settings</a><span class="sep">/</span><span>App Settings</span></div>
  </div>
</div>

<!-- Tab Navigation -->
<div style="display:flex;border-bottom:2px solid #e2e8f0;margin-bottom:22px;gap:4px;overflow-x:auto">
  <?php foreach([['website','Website Information'],['transfer','Transfer Codes'],['preference','Preference'],['email','Email/Captcha'],['theme','Theme/Display']] as $i => [$tab,$label]): ?>
  <button onclick="showAppTab('<?= $tab ?>')" id="apptab-<?= $tab ?>" style="padding:12px 20px;background:none;border:none;border-bottom:3px solid <?= $i===0?'#1B3A5C':'transparent' ?>;font-size:.86rem;font-weight:<?= $i===0?'700':'500' ?>;color:<?= $i===0?'#1B3A5C':'#64748b' ?>;cursor:pointer;font-family:inherit;white-space:nowrap;margin-bottom:-2px;transition:all .2s"><?= $label ?></button>
  <?php endforeach; ?>
</div>

<!-- Save Indicator -->
<div id="app-save-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px 16px;margin-bottom:16px;font-size:.84rem;color:#065f46;display:none;align-items:center;gap:8px"><i class="fa-solid fa-circle-check"></i><span>Settings saved successfully!</span></div>

<!-- Website Information Tab -->
<div id="apppanel-website">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-globe" style="color:#1B3A5C;margin-right:7px"></i>Website Information</h3></div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Website Name</label><input type="text" class="form-control" value="Abay Bank Management System" id="app-site-name"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">PWA Short Name (Max 12 chars)</label><input type="text" class="form-control" value="AbayBank" maxlength="12" id="app-pwa-name"><div style="font-size:.72rem;color:#94a3b8;margin-top:3px">Used for app icon label on mobile devices</div></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Website Title</label><input type="text" class="form-control" value="Welcome to Abay Bank"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Website Keywords</label><input type="text" class="form-control" value="Abay Bank, Ethiopian Banking, Online Banking"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Website URL</label><input type="url" class="form-control" value="<?= APP_URL ?>"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">WhatsApp Number</label><input type="tel" class="form-control" value="+251 912 345 678"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Bank Address</label><textarea class="form-control" rows="2">Bole Road, Addis Ababa, Ethiopia</textarea></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Bank Description</label><textarea class="form-control" rows="2">Abay Bank S.C. — Ethiopia's trusted financial partner since 2010.</textarea></div>
      </div>
      <button onclick="saveAppSettings('website')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Website Info</button>
    </div>
  </div>
</div>

<!-- Transfer Codes Tab -->
<div id="apppanel-transfer" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-right-left" style="color:#1B3A5C;margin-right:7px"></i>Transfer Codes & Methods</h3></div>
    <div class="card-body">
      <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
        <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Enabled Transfer Methods</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <?php foreach(['Internal Transfer (Abay → Abay)'=>true,'EthSwitch Inter-Bank'=>true,'Telebirr Mobile Money'=>true,'M-Pesa Ethiopia'=>true,'SWIFT Wire Transfer'=>true,'Western Union'=>true,'Wise (Low-fee)'=>false,'Payoneer Business'=>false] as $m=>$en): ?>
          <label style="display:flex;align-items:center;gap:9px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;cursor:pointer;transition:border .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'">
            <input type="checkbox" <?= $en?'checked':'' ?> style="accent-color:#007A8A;width:15px;height:15px">
            <span style="font-size:.83rem;font-weight:500"><?= $m ?></span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:16px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">EthSwitch Routing Code</label><input type="text" class="form-control" value="ABYAETAA"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Telebirr Merchant ID</label><input type="text" class="form-control" value="ETL-ABAY-001"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">WU Agent ID</label><input type="text" class="form-control" value="WU-ET-ABAY-2024"></div>
      </div>
      <button onclick="saveAppSettings('transfer')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Transfer Config</button>
    </div>
  </div>
</div>

<!-- Preference Tab -->
<div id="apppanel-preference" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-sliders" style="color:#1B3A5C;margin-right:7px"></i>System Preferences</h3></div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Default Language</label><select class="form-control"><option selected>English</option><option>Amharic (አማርኛ)</option></select></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Date Format</label><select class="form-control"><option selected>DD/MM/YYYY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option></select></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Time Zone</label><select class="form-control"><option selected>Africa/Addis_Ababa (EAT +3)</option><option>UTC</option></select></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Items Per Page</label><select class="form-control"><option>10</option><option selected>15</option><option>25</option><option>50</option></select></div>
      </div>
      <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
        <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Feature Preferences</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
          <?php foreach(['Enable dark mode toggle'=>true,'Show live clock in dashboard'=>true,'Show demo mode banner'=>true,'Auto-refresh dashboard every 60s'=>false,'Enable audit logging'=>true,'Send email on large transactions'=>true,'Show amount in words on receipts'=>true,'Enable biometric login (future)'=>false] as $pref=>$checked): ?>
          <label style="display:flex;align-items:center;gap:9px;cursor:pointer">
            <input type="checkbox" <?= $checked?'checked':'' ?> style="accent-color:#007A8A;width:14px;height:14px">
            <span style="font-size:.82rem;font-weight:500"><?= $pref ?></span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>
      <button onclick="saveAppSettings('preference')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Preferences</button>
    </div>
  </div>
</div>

<!-- Email/Captcha Tab -->
<div id="apppanel-email" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-envelope" style="color:#1B3A5C;margin-right:7px"></i>Email & Login Captcha</h3></div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">SMTP Host</label><input type="text" class="form-control" value="smtp.abaybank.com.et"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">SMTP Port</label><input type="number" class="form-control" value="587"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">From Email</label><input type="email" class="form-control" value="noreply@abaybank.com.et"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">From Name</label><input type="text" class="form-control" value="Abay Bank"></div>
      </div>
      <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
        <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">reCAPTCHA Settings</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Site Key</label><input type="text" class="form-control" placeholder="6Lc..."></div>
          <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Secret Key</label><input type="password" class="form-control" placeholder="6Lc..."></div>
        </div>
        <div style="margin-top:10px;display:flex;gap:9px;flex-wrap:wrap">
          <?php foreach(['Enable CAPTCHA on Login'=>true,'Enable CAPTCHA on Register'=>false,'Enable CAPTCHA on Transfer'=>false] as $c=>$en): ?>
          <label style="display:flex;align-items:center;gap:7px;cursor:pointer"><input type="checkbox" <?= $en?'checked':'' ?> style="accent-color:#007A8A;width:14px;height:14px"><span style="font-size:.82rem;font-weight:500"><?= $c ?></span></label>
          <?php endforeach; ?>
        </div>
      </div>
      <div style="display:flex;gap:10px">
        <button onclick="ABAY.toast('Test email sent!','ok')" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-paper-plane" style="margin-right:5px"></i>Test Email</button>
        <button onclick="saveAppSettings('email')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save</button>
      </div>
    </div>
  </div>
</div>

<!-- Theme/Display Tab -->
<div id="apppanel-theme" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-palette" style="color:#1B3A5C;margin-right:7px"></i>Theme & Display</h3></div>
    <div class="card-body">
      <div style="margin-bottom:20px">
        <div style="font-size:.79rem;font-weight:600;color:#374151;margin-bottom:12px">Color Theme</div>
        <div style="display:flex;gap:14px;flex-wrap:wrap">
          <?php foreach([['#1B3A5C','Navy Blue (Default)',true],['#0f2336','Dark Navy',false],['#1a5c3a','Forest Green',false],['#5b21b6','Royal Purple',false],['#c2410c','Deep Orange',false]] as [$clr,$lbl,$active]): ?>
          <label style="cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:7px">
            <input type="radio" name="theme-color" value="<?= $clr ?>" <?= $active?'checked':'' ?> style="display:none">
            <div style="width:52px;height:52px;border-radius:14px;background:<?= $clr ?>;border:3px solid <?= $active?'#007A8A':'transparent' ?>;transition:border .2s;box-shadow:0 4px 12px rgba(0,0,0,.2)" onclick="this.closest('label').querySelector('input').checked=true;document.querySelectorAll('[name=theme-color]').forEach(function(r){r.closest('label').querySelector('div').style.border=r.checked?'3px solid #007A8A':'3px solid transparent';})"></div>
            <span style="font-size:.72rem;color:#475569;text-align:center"><?= $lbl ?></span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Sidebar Width</label><select class="form-control"><option>260px (Default)</option><option>240px (Compact)</option><option>280px (Wide)</option></select></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Font Size</label><select class="form-control"><option>14px (Default)</option><option>13px (Small)</option><option>15px (Large)</option></select></div>
      </div>
      <button onclick="saveAppSettings('theme')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Theme</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
function showAppTab(tab) {
  ['website','transfer','preference','email','theme'].forEach(function(t) {
    var btn = document.getElementById('apptab-' + t);
    var panel = document.getElementById('apppanel-' + t);
    var isActive = t === tab;
    btn.style.borderBottom = isActive ? '3px solid #1B3A5C' : '3px solid transparent';
    btn.style.fontWeight = isActive ? '700' : '500';
    btn.style.color = isActive ? '#1B3A5C' : '#64748b';
    if (panel) panel.style.display = isActive ? 'block' : 'none';
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function saveAppSettings(tab) {
  var ind = document.getElementById('app-save-ok');
  ABAY.api('/settings/app', { method: 'POST', body: JSON.stringify({ tab: tab }) }).then(function() {
    if (ind) { ind.style.display = 'flex'; setTimeout(function() { ind.style.display = 'none'; }, 3500); }
    ABAY.toast('App settings saved!', 'ok');
  }).catch(function() {
    if (ind) { ind.style.display = 'flex'; setTimeout(function() { ind.style.display = 'none'; }, 3500); }
    ABAY.toast('Settings saved (demo mode).', 'info');
  });
}
</script>
