<?php
$pageTitle = 'Attendance Management — ' . APP_NAME;
$attRows = $today ?? [];
if (empty($attRows)) {
    $attRows = [
        ['employee_number'=>'EMP001','name'=>'Yohannes Bekele','dept_name'=>'Operations',    'check_in'=>'08:02','check_out'=>'','status'=>'Present'],
        ['employee_number'=>'EMP002','name'=>'Tigist Haile',   'dept_name'=>'Customer Svc', 'check_in'=>'08:45','check_out'=>'','status'=>'Late'],
        ['employee_number'=>'EMP003','name'=>'Solomon Girma',  'dept_name'=>'Loans',         'check_in'=>'07:58','check_out'=>'','status'=>'Present'],
        ['employee_number'=>'EMP004','name'=>'Hanna Tadesse',  'dept_name'=>'IT',             'check_in'=>'',     'check_out'=>'','status'=>'Absent'],
        ['employee_number'=>'EMP005','name'=>'Dawit Alemu',    'dept_name'=>'Finance',        'check_in'=>'08:05','check_out'=>'','status'=>'Present'],
        ['employee_number'=>'EMP006','name'=>'Meron Getnet',   'dept_name'=>'HR',             'check_in'=>'',     'check_out'=>'','status'=>'Leave'],
        ['employee_number'=>'EMP007','name'=>'Bereket Tadesse','dept_name'=>'Operations',    'check_in'=>'08:12','check_out'=>'','status'=>'Present'],
        ['employee_number'=>'EMP008','name'=>'Azeb Haile',     'dept_name'=>'Customer Svc', 'check_in'=>'08:30','check_out'=>'','status'=>'Late'],
    ];
}
$present = count(array_filter($attRows, fn($r) => $r['status']==='Present'));
$late    = count(array_filter($attRows, fn($r) => $r['status']==='Late'));
$absent  = count(array_filter($attRows, fn($r) => $r['status']==='Absent'));
$leave   = count(array_filter($attRows, fn($r) => $r['status']==='Leave'));
$total   = count($attRows);
$rate    = $total > 0 ? round(($present+$late)/$total*100) : 0;
?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-calendar-check" style="color:#1B3A5C;margin-right:8px"></i>Attendance Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/employees">Employees</a><span class="sep">/</span><span>Attendance</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <input type="date" id="att-date-filter" value="<?= date('Y-m-d') ?>" onchange="filterByDate(this.value)" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer;outline:none">
    <button onclick="markAllPresent()" class="btn btn-success btn-sm"><i class="fa-solid fa-check-double"></i> Mark All Present</button>
    <button onclick="exportAttendanceCSV()" class="btn btn-light btn-sm"><i class="fa-solid fa-file-csv"></i> Export</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:22px">
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-user-check"></i></div><div class="stat-content"><div class="stat-label">Present</div><div class="stat-value" id="att-stat-present"><?= $present ?></div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><i class="fa-solid fa-clock"></i></div><div class="stat-content"><div class="stat-label">Late</div><div class="stat-value" id="att-stat-late"><?= $late ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red"><i class="fa-solid fa-user-xmark"></i></div><div class="stat-content"><div class="stat-label">Absent</div><div class="stat-value" id="att-stat-absent"><?= $absent ?></div></div></div>
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-calendar-days"></i></div><div class="stat-content"><div class="stat-label">On Leave</div><div class="stat-value" id="att-stat-leave"><?= $leave ?></div></div></div>
  <div class="stat-card"><div class="stat-icon teal"><i class="fa-solid fa-percent"></i></div><div class="stat-content"><div class="stat-label">Attendance Rate</div><div class="stat-value" id="att-stat-rate"><?= $rate ?>%</div></div></div>
</div>

<!-- Rate bar -->
<div style="background:#fff;border-radius:12px;padding:16px 20px;margin-bottom:22px;border:1px solid #e2e8f0;display:flex;align-items:center;gap:16px;flex-wrap:wrap">
  <div style="font-size:.82rem;font-weight:700;color:#374151;min-width:120px">Today's Rate: <span style="color:#1B3A5C"><?= $rate ?>%</span></div>
  <div style="flex:1;min-width:200px">
    <div style="height:10px;background:#e2e8f0;border-radius:99px;overflow:hidden">
      <div style="height:100%;width:<?= $rate ?>%;background:linear-gradient(90deg,#10b981,#059669);border-radius:99px;transition:width 1s"></div>
    </div>
  </div>
  <div style="font-size:.78rem;color:#94a3b8"><?= $present+$late ?>/<?= $total ?> employees attended</div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px">
  <!-- Attendance Table -->
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-table" style="color:#1B3A5C;margin-right:7px"></i>Today's Attendance</h3>
      <div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">
        <input type="search" id="att-search" placeholder="Search employee..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:6px 11px;font-size:.83rem;width:180px;outline:none" oninput="filterAttTable(this.value)">
        <select id="att-dept-filter" onchange="filterAttTable()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:6px 11px;font-size:.83rem;background:#fff;cursor:pointer">
          <option value="">All Departments</option>
          <?php $depts = array_unique(array_column($attRows,'dept_name')); foreach ($depts as $d): ?><option><?= htmlspecialchars($d) ?></option><?php endforeach; ?>
        </select>
        <select id="att-status-filter" onchange="filterAttTable()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:6px 11px;font-size:.83rem;background:#fff;cursor:pointer">
          <option value="">All Status</option><option>Present</option><option>Late</option><option>Absent</option><option>Leave</option>
        </select>
      </div>
    </div>
    <div class="table-responsive">
      <table class="data-table" id="att-table">
        <thead><tr><th>Employee ID</th><th>Name</th><th>Department</th><th>Check In</th><th>Check Out</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="att-tbody">
          <?php foreach ($attRows as $row):
            $sc = match($row['status']??'') {'Present'=>'success','Late'=>'warning','Absent'=>'danger','Leave'=>'info',default=>'secondary'};
          ?>
          <tr data-name="<?= strtolower(htmlspecialchars($row['name']??'')) ?>" data-dept="<?= htmlspecialchars($row['dept_name']??'') ?>" data-status="<?= htmlspecialchars($row['status']??'') ?>">
            <td><span style="font-family:monospace;font-size:.76rem;color:#475569"><?= htmlspecialchars($row['employee_number']??'—') ?></span></td>
            <td>
              <div style="display:flex;align-items:center;gap:8px">
                <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;flex-shrink:0"><?= strtoupper(substr($row['name']??'U',0,1)) ?></div>
                <span style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($row['name']??'—') ?></span>
              </div>
            </td>
            <td><span style="font-size:.77rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600"><?= htmlspecialchars($row['dept_name']??'—') ?></span></td>
            <td style="font-size:.82rem;color:<?= empty($row['check_in'])?'#94a3b8':'#059669' ?>;font-weight:600"><?= $row['check_in'] ?: '—' ?></td>
            <td style="font-size:.82rem;color:<?= empty($row['check_out'])?'#94a3b8':'#475569' ?>"><?= $row['check_out'] ?: '—' ?></td>
            <td><span class="badge badge-<?= $sc ?>"><?= htmlspecialchars($row['status']??'—') ?></span></td>
            <td>
              <div style="display:flex;gap:4px">
                <button onclick="updateAttStatus('<?= htmlspecialchars($row['employee_number']??'') ?>',this)" style="padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Edit Status"><i class="fa-solid fa-pen" style="color:#007A8A"></i></button>
                <?php if (empty($row['check_in'])): ?>
                <button onclick="manualCheckIn('<?= htmlspecialchars($row['employee_number']??'') ?>',this)" style="padding:4px 8px;border:none;border-radius:6px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Manual Check In"><i class="fa-solid fa-right-to-bracket"></i></button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Charts & Quick Check-in -->
  <div style="display:flex;flex-direction:column;gap:18px">
    <!-- Quick Check In/Out -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-fingerprint" style="color:#1B3A5C;margin-right:6px"></i>Quick Check In / Out</h4></div>
      <div class="card-body">
        <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:5px">Employee ID or Name</label>
          <input type="text" id="quick-emp" placeholder="Search employee..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:12px">
          <button onclick="quickCheckAction('in')" style="padding:10px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;border:none;border-radius:9px;font-size:.82rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-to-bracket"></i>Check In</button>
          <button onclick="quickCheckAction('out')" style="padding:10px;background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;border:none;border-radius:9px;font-size:.82rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-from-bracket"></i>Check Out</button>
        </div>
        <div id="quick-msg" style="display:none;font-size:.8rem;border-radius:8px;padding:9px 12px;text-align:center;background:#f0fbfc;color:#0e7490"></div>
        <div style="background:#f8fafc;border-radius:9px;padding:12px;text-align:center;margin-top:8px">
          <div style="font-size:.67rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Current Time (EAT)</div>
          <div style="font-size:1.6rem;font-weight:800;color:#1B3A5C" id="att-live-clock"><?= date('H:i:s') ?></div>
          <div style="font-size:.76rem;color:#94a3b8;margin-top:2px"><?= date('l, d F Y') ?></div>
        </div>
      </div>
    </div>

    <!-- Weekly trend chart -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-chart-bar" style="color:#1B3A5C;margin-right:6px"></i>Weekly Trend</h4></div>
      <div class="card-body"><canvas id="att-weekly-chart" height="200"></canvas></div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
setInterval(function(){var n=new Date(),p=function(x){return String(x).padStart(2,'0')};var el=document.getElementById('att-live-clock');if(el)el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());},1000);

function filterAttTable(q) {
  q = typeof q === 'string' ? q.toLowerCase() : document.getElementById('att-search').value.toLowerCase();
  var dept = document.getElementById('att-dept-filter').value;
  var status = document.getElementById('att-status-filter').value;
  document.querySelectorAll('#att-tbody tr').forEach(function(tr) {
    var nm = tr.dataset.name||'', d = tr.dataset.dept||'', s = tr.dataset.status||'';
    tr.style.display = ((!q||nm.includes(q))&&(!dept||d===dept)&&(!status||s===status)) ? '' : 'none';
  });
}

function markAllPresent() {
  if (!confirm('Mark all employees as Present for today?')) return;
  document.querySelectorAll('#att-tbody tr td:nth-child(6) .badge').forEach(function(b) {
    if (b.textContent !== 'Leave') { b.textContent = 'Present'; b.className = 'badge badge-success'; }
  });
  ABAY.toast('All employees marked as Present.', 'ok');
  ABAY.api('/attendance/mark-all', { method: 'POST', body: JSON.stringify({ date: document.getElementById('att-date-filter').value }) }).catch(function(){});
}

function updateAttStatus(empId, btn) {
  var s = prompt('Update status for ' + empId + ' (Present/Late/Absent/Leave):', 'Present');
  if (!s) return;
  ABAY.api('/attendance/' + empId, { method: 'PUT', body: JSON.stringify({ status: s }) }).then(function() {
    var tr = btn.closest('tr'); var badge = tr.querySelector('.badge');
    var colors = {Present:'success',Late:'warning',Absent:'danger',Leave:'info'};
    badge.textContent = s; badge.className = 'badge badge-' + (colors[s]||'secondary');
    ABAY.toast('Status updated!', 'ok');
  }).catch(function() { ABAY.toast('Demo: Status updated.', 'info'); });
}

function manualCheckIn(empId, btn) {
  var time = new Date().toTimeString().slice(0,5);
  ABAY.api('/attendance/checkin', { method: 'POST', body: JSON.stringify({ employee_id: empId, time: time }) }).then(function() {
    var tr = btn.closest('tr'); tr.querySelector('td:nth-child(4)').textContent = time;
    tr.querySelector('td:nth-child(4)').style.color = '#059669';
    ABAY.toast('Check-in recorded for ' + empId, 'ok'); btn.remove();
  }).catch(function() { ABAY.toast('Demo: Check-in at ' + time, 'info'); btn.remove(); });
}

function quickCheckAction(type) {
  var emp = document.getElementById('quick-emp').value.trim();
  if (!emp) { ABAY.toast('Enter employee ID or name.', 'err'); return; }
  var time = new Date().toLocaleTimeString('en-ET');
  var msg = document.getElementById('quick-msg');
  msg.style.display = 'block';
  msg.style.background = type==='in' ? '#d1fae5' : '#fee2e2';
  msg.style.color = type==='in' ? '#065f46' : '#991b1b';
  msg.textContent = (type==='in' ? '✓ ' : '✗ ') + emp + ' checked ' + type + ' at ' + time;
  ABAY.api('/attendance/check' + type, { method: 'POST', body: JSON.stringify({ employee: emp, time: time }) }).then(function(d) {
    ABAY.toast(emp + ' checked ' + type + '!', 'ok');
  }).catch(function() { ABAY.toast('Demo: ' + emp + ' checked ' + type + '.', 'info'); });
}

function filterByDate(d) { ABAY.toast('Showing attendance for ' + d, 'info'); }

function exportAttendanceCSV() {
  var rows = [['Employee ID','Name','Department','Check In','Check Out','Status']];
  document.querySelectorAll('#att-tbody tr').forEach(function(tr) {
    if (tr.style.display === 'none') return;
    var cells = tr.querySelectorAll('td');
    if (cells.length > 5) rows.push([cells[0].textContent.trim(), cells[1].textContent.trim(), cells[2].textContent.trim(), cells[3].textContent.trim(), cells[4].textContent.trim(), cells[5].textContent.trim()]);
  });
  var csv = rows.map(function(r) { return r.map(function(v) { return '"'+v+'"'; }).join(','); }).join('\n');
  var a = document.createElement('a'); a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv); a.download = 'attendance-' + document.getElementById('att-date-filter').value + '.csv'; a.click();
}

document.addEventListener('DOMContentLoaded', function() {
  if (typeof Chart === 'undefined') return;
  new Chart(document.getElementById('att-weekly-chart'), {
    type: 'bar',
    data: {
      labels: ['Mon','Tue','Wed','Thu','Fri','Sat'],
      datasets: [
        { label: 'Present', data: [142,138,145,140,143,62], backgroundColor: 'rgba(16,185,129,.75)', borderRadius: 4 },
        { label: 'Late',    data: [12,16,10,14,12,8],       backgroundColor: 'rgba(245,158,11,.65)', borderRadius: 4 },
        { label: 'Absent',  data: [2,6,1,3,1,2],            backgroundColor: 'rgba(239,68,68,.65)',  borderRadius: 4 },
      ]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, padding: 10 } } }, scales: { x: { grid: { display: false } }, y: { grid: { color: 'rgba(0,0,0,.04)' } } } }
  });
});
</script>
