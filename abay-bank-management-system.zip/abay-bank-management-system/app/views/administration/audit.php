﻿<?php

/** @var array $logs @var array $user */
$demoLogs = $logs ?: [
  ['id' => 1, 'user' => 'admin', 'action' => 'LOGIN', 'module' => 'Auth', 'detail' => 'Admin logged in from 192.168.1.5', 'ip' => '192.168.1.5', 'created_at' => date('Y-m-d H:i:s', time() - 300), 'level' => 'Info'],
  ['id' => 2, 'user' => 'teller_abebe', 'action' => 'DEPOSIT', 'module' => 'Transactions', 'detail' => 'Deposited ETB 25,000 to ACC-001002', 'ip' => '192.168.1.12', 'created_at' => date('Y-m-d H:i:s', time() - 600), 'level' => 'Info'],
  ['id' => 3, 'user' => 'manager_tigist', 'action' => 'LOAN_APPROVED', 'module' => 'Loans', 'detail' => 'Approved loan L-00043 for ETB 150,000', 'ip' => '192.168.1.8', 'created_at' => date('Y-m-d H:i:s', time() - 900), 'level' => 'Success'],
  ['id' => 4, 'user' => 'teller_samuel', 'action' => 'LOGIN_FAILED', 'module' => 'Auth', 'detail' => 'Invalid password attempt for user teller_samuel', 'ip' => '41.89.12.5', 'created_at' => date('Y-m-d H:i:s', time() - 1200), 'level' => 'Warning'],
  ['id' => 5, 'user' => 'admin', 'action' => 'USER_CREATED', 'module' => 'Administration', 'detail' => 'Created new user account: teller_meron', 'ip' => '192.168.1.5', 'created_at' => date('Y-m-d H:i:s', time() - 1800), 'level' => 'Info'],
  ['id' => 6, 'user' => 'teller_abebe', 'action' => 'WITHDRAWAL', 'module' => 'Transactions', 'detail' => 'Withdrew ETB 10,000 from ACC-001008', 'ip' => '192.168.1.12', 'created_at' => date('Y-m-d H:i:s', time() - 2100), 'level' => 'Info'],
  ['id' => 7, 'user' => 'admin', 'action' => 'SETTINGS_CHANGED', 'module' => 'Administration', 'detail' => 'Changed transaction daily limit to ETB 500,000', 'ip' => '192.168.1.5', 'created_at' => date('Y-m-d H:i:s', time() - 3600), 'level' => 'Warning'],
  ['id' => 8, 'user' => 'loan_officer_dawit', 'action' => 'LOAN_REJECTED', 'module' => 'Loans', 'detail' => 'Rejected loan application L-00044', 'ip' => '192.168.1.20', 'created_at' => date('Y-m-d H:i:s', time() - 4800), 'level' => 'Info'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-file-shield" style="color:var(--primary)"></i> Audit Log</h1>
    <p class="page-subtitle">Complete trail of all system activities and user actions</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="ABAY.toast('Audit log exported','success')"><i class="fa-solid fa-download"></i> Export</button>
    <button class="btn btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="if(confirm('Clear logs older than 90 days?')) ABAY.toast('Old logs archived','info')">
      <i class="fa-solid fa-trash"></i> Archive Old
    </button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <?php $kpis = [['1,284', 'Total Events', 'fa-list', '#6366f1'], ['98', 'Login Events', 'fa-right-to-bracket', '#3b82f6'], ['342', 'Transactions', 'fa-arrow-right-arrow-left', '#22c55e'], ['12', 'Warnings', 'fa-triangle-exclamation', '#f59e0b'], ['3', 'Security Alerts', 'fa-shield-halved', '#ef4444']];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body" style="padding:16px">
    <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
      <input type="text" id="audit-search" class="form-control form-control-sm" placeholder="Search user, action, detail..." style="flex:1;min-width:200px" oninput="filterAudit()">
      <select id="filter-level" class="form-control form-control-sm" style="width:130px" onchange="filterAudit()">
        <option value="">All Levels</option>
        <option>Info</option>
        <option>Warning</option>
        <option>Success</option>
        <option>Error</option>
      </select>
      <select id="filter-module" class="form-control form-control-sm" style="width:160px" onchange="filterAudit()">
        <option value="">All Modules</option>
        <option>Auth</option>
        <option>Transactions</option>
        <option>Loans</option>
        <option>Administration</option>
        <option>Accounts</option>
      </select>
      <input type="date" id="filter-date" class="form-control form-control-sm" style="width:145px" onchange="filterAudit()">
    </div>
  </div>
</div>

<!-- Audit Table -->
<div class="card">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>User</th>
            <th>Action</th>
            <th>Module</th>
            <th>Detail</th>
            <th>IP Address</th>
            <th>Level</th>
          </tr>
        </thead>
        <tbody id="audit-tbody">
          <?php foreach ($demoLogs as $log):
            $lc = match ($log['level']) {
              'Warning' => 'badge-warning',
              'Error' => 'badge-danger',
              'Success' => 'badge-success',
              default => 'badge-info'
            };
            $ac = match ($log['level']) {
              'Warning' => '#f59e0b20',
              'Error' => '#ef444420',
              'Success' => '#22c55e20',
              default => ''
            };
          ?>
            <tr style="background:<?= $ac ?>">
              <td class="text-muted" style="font-size:.82rem;white-space:nowrap"><?= $log['created_at'] ?></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($log['user'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($log['user']) ?></div>
                  </div>
                </div>
              </td>
              <td><code style="background:var(--surface);padding:2px 6px;border-radius:4px;font-size:.8rem"><?= htmlspecialchars($log['action']) ?></code></td>
              <td><?= htmlspecialchars($log['module']) ?></td>
              <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.83rem"><?= htmlspecialchars($log['detail']) ?></td>
              <td class="text-muted" style="font-size:.82rem;font-family:monospace"><?= htmlspecialchars($log['ip']) ?></td>
              <td><span class="badge <?= $lc ?>"><?= $log['level'] ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer" style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px">
    <span class="text-muted" style="font-size:.85rem">Showing <?= count($demoLogs) ?> of 1,284 entries</span>
    <div style="display:flex;gap:8px">
      <button class="btn btn-sm btn-outline">← Prev</button>
      <button class="btn btn-sm btn-primary">Next →</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterAudit() {
    const q = document.getElementById('audit-search').value.toLowerCase();
    const lvl = document.getElementById('filter-level').value.toLowerCase();
    const mod = document.getElementById('filter-module').value.toLowerCase();
    document.querySelectorAll('#audit-tbody tr').forEach(tr => {
      const txt = tr.textContent.toLowerCase();
      const show = (!q || txt.includes(q)) && (!lvl || txt.includes(lvl)) && (!mod || txt.includes(mod));
      tr.style.display = show ? '' : 'none';
    });
  }
</script>