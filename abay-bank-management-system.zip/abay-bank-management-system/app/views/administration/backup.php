﻿<?php

/** @var array $backups @var array $user */
$demoBackups = $backups ?: [
  ['id' => 1, 'name' => 'abay_bank_full_2026_08_21.sql.gz', 'type' => 'Full', 'size' => '48.3 MB', 'created_at' => '2026-08-21 02:00:00', 'status' => 'Success', 'duration' => '4m 12s'],
  ['id' => 2, 'name' => 'abay_bank_incremental_2026_08_20.sql.gz', 'type' => 'Incremental', 'size' => '5.1 MB', 'created_at' => '2026-08-20 02:00:00', 'status' => 'Success', 'duration' => '0m 38s'],
  ['id' => 3, 'name' => 'abay_bank_incremental_2026_08_19.sql.gz', 'type' => 'Incremental', 'size' => '4.8 MB', 'created_at' => '2026-08-19 02:00:00', 'status' => 'Success', 'duration' => '0m 35s'],
  ['id' => 4, 'name' => 'abay_bank_full_2026_08_14.sql.gz', 'type' => 'Full', 'size' => '47.9 MB', 'created_at' => '2026-08-14 02:00:00', 'status' => 'Success', 'duration' => '4m 05s'],
  ['id' => 5, 'name' => 'abay_bank_incremental_2026_08_13.sql.gz', 'type' => 'Incremental', 'size' => '3.2 MB', 'created_at' => '2026-08-13 02:00:00', 'status' => 'Failed', 'duration' => '0m 12s'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-database" style="color:var(--primary)"></i> Backup & Restore</h1>
    <p class="page-subtitle">Database backup management and recovery operations</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="restoreBackup()"><i class="fa-solid fa-rotate-left"></i> Restore</button>
    <button class="btn btn-primary" id="run-backup-btn" onclick="runBackup()"><i class="fa-solid fa-database"></i> Run Backup Now</button>
  </div>
</div>

<!-- Status Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(175px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:#22c55e20;color:#22c55e"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-info">
      <div class="stat-value">2026-08-21</div>
      <div class="stat-label">Last Backup</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#3b82f620;color:#3b82f6"><i class="fa-solid fa-hard-drive"></i></div>
    <div class="stat-info">
      <div class="stat-value">214.8 MB</div>
      <div class="stat-label">Total Backup Size</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#6366f120;color:#6366f1"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-info">
      <div class="stat-value">Daily 02:00</div>
      <div class="stat-label">Schedule</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#10b98120;color:#10b981"><i class="fa-solid fa-cloud"></i></div>
    <div class="stat-info">
      <div class="stat-value">Cloud + Local</div>
      <div class="stat-label">Storage</div>
    </div>
  </div>
</div>

<!-- Backup Progress Bar (hidden by default) -->
<div id="backup-progress-card" class="card" style="display:none;margin-bottom:24px">
  <div class="card-body">
    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
      <span class="fw-semibold"><i class="fa-solid fa-spinner fa-spin"></i> Backup in progress...</span>
      <span id="backup-pct">0%</span>
    </div>
    <div style="height:10px;background:#e5e7eb;border-radius:5px;overflow:hidden">
      <div id="backup-bar" style="height:100%;background:linear-gradient(90deg,#6366f1,#22c55e);border-radius:5px;width:0%;transition:width .3s"></div>
    </div>
  </div>
</div>

<!-- Backup Settings -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title"><i class="fa-solid fa-sliders"></i> Backup Configuration</h3>
    </div>
    <div class="card-body">
      <div class="form-group">
        <label class="form-label">Backup Type</label>
        <select class="form-control">
          <option>Full Backup (weekly)</option>
          <option>Incremental (daily)</option>
          <option>Differential</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Schedule</label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <select class="form-control">
            <option>Every Day</option>
            <option>Every Week</option>
            <option>Every Month</option>
          </select>
          <input type="time" class="form-control" value="02:00">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Retention</label>
        <select class="form-control">
          <option>30 days</option>
          <option>60 days</option>
          <option>90 days</option>
          <option>1 year</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Storage Location</label>
        <div style="display:flex;flex-direction:column;gap:8px">
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" checked> <span>Local Server</span>
          </label>
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" checked> <span>Cloud Storage (AWS S3)</span>
          </label>
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox"> <span>Remote FTP Server</span>
          </label>
        </div>
      </div>
      <button class="btn btn-primary" onclick="ABAY.toast('Backup settings saved','success')">
        <i class="fa-solid fa-save"></i> Save Settings
      </button>
    </div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title"><i class="fa-solid fa-cloud"></i> Storage Usage</h3>
    </div>
    <div class="card-body">
      <canvas id="storage-chart" height="200"></canvas>
      <div style="margin-top:16px">
        <?php $storages = [['Local Server', '48%', '#6366f1'], ['Cloud (S3)', '35%', '#3b82f6'], ['Free Space', '17%', '#e5e7eb']];
        foreach ($storages as [$n, $p, $c]): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:12px;height:12px;border-radius:3px;background:<?= $c ?>"></div>
              <span style="font-size:.85rem"><?= $n ?></span>
            </div>
            <span class="fw-semibold"><?= $p ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Backup History -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-history"></i> Backup History</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>File Name</th>
            <th>Type</th>
            <th>Size</th>
            <th>Date & Time</th>
            <th>Duration</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoBackups as $b):
            $sc = $b['status'] === 'Success' ? 'badge-success' : 'badge-danger';
          ?>
            <tr>
              <td style="font-family:monospace;font-size:.82rem"><?= htmlspecialchars($b['name']) ?></td>
              <td><span class="badge badge-info"><?= $b['type'] ?></span></td>
              <td><?= $b['size'] ?></td>
              <td class="text-muted" style="font-size:.83rem"><?= $b['created_at'] ?></td>
              <td><?= $b['duration'] ?></td>
              <td><span class="badge <?= $sc ?>"><?= $b['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="Download" onclick="ABAY.toast('Downloading backup...','info')"><i class="fa-solid fa-download"></i></button>
                  <?php if ($b['status'] === 'Success'): ?>
                    <button class="action-btn approve" data-tooltip="Restore" onclick="ABAY.toast('Restore started — this may take a few minutes','warning')"><i class="fa-solid fa-rotate-left"></i></button>
                  <?php endif; ?>
                  <button class="action-btn delete" data-tooltip="Delete" onclick="ABAY.toast('Backup deleted','warning')"><i class="fa-solid fa-trash"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function runBackup() {
    const card = document.getElementById('backup-progress-card');
    const bar = document.getElementById('backup-bar');
    const pct = document.getElementById('backup-pct');
    const btn = document.getElementById('run-backup-btn');
    card.style.display = '';
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Running...';
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random() * 15;
      if (p >= 100) {
        p = 100;
        clearInterval(iv);
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-database"></i> Run Backup Now';
        ABAY.toast('Backup completed successfully!', 'success');
        setTimeout(() => {
          card.style.display = 'none';
          bar.style.width = '0%';
        }, 2000);
      }
      bar.style.width = p + '%';
      pct.textContent = Math.round(p) + '%';
    }, 300);
  }

  function restoreBackup() {
    if (confirm('Restore from the latest backup? Current data will be overwritten.')) {
      ABAY.toast('Restore initiated — system will restart after completion', 'warning');
    }
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    new Chart(document.getElementById('storage-chart'), {
      type: 'doughnut',
      data: {
        labels: ['Local Server', 'Cloud (S3)', 'Free Space'],
        datasets: [{
          data: [48, 35, 17],
          backgroundColor: ['#6366f1', '#3b82f6', '#e5e7eb']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
  });
</script>