﻿<?php

/** @var array $kycDocs @var array $user */
$demoDocs = $kycDocs ?: [
  ['id' => 1, 'customer_name' => 'Abebe Girma', 'doc_type' => 'National ID', 'file_name' => 'national_id_001.jpg', 'uploaded_at' => '2026-08-10 09:30', 'status' => 'Verified', 'size' => '1.2 MB'],
  ['id' => 2, 'customer_name' => 'Tigist Haile', 'doc_type' => 'Passport', 'file_name' => 'passport_tigist.pdf', 'uploaded_at' => '2026-08-12 11:15', 'status' => 'Verified', 'size' => '3.4 MB'],
  ['id' => 3, 'customer_name' => 'Samuel Bekele', 'doc_type' => 'Fayda ID', 'file_name' => 'fayda_samuel.png', 'uploaded_at' => '2026-08-15 14:20', 'status' => 'Pending', 'size' => '0.8 MB'],
  ['id' => 4, 'customer_name' => 'Meron Tesfaye', 'doc_type' => 'Business License', 'file_name' => 'biz_license_meron.pdf', 'uploaded_at' => '2026-08-16 10:00', 'status' => 'Pending', 'size' => '2.1 MB'],
  ['id' => 5, 'customer_name' => 'Dawit Alemu', 'doc_type' => 'National ID', 'file_name' => 'nid_dawit.jpg', 'uploaded_at' => '2026-08-18 08:45', 'status' => 'Rejected', 'size' => '0.9 MB'],
  ['id' => 6, 'customer_name' => 'Hana Mulugeta', 'doc_type' => 'Utility Bill', 'file_name' => 'utility_hana.pdf', 'uploaded_at' => '2026-08-19 16:30', 'status' => 'Verified', 'size' => '0.5 MB'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-folder-open" style="color:var(--primary)"></i> Document Management</h1>
    <p class="page-subtitle">Customer KYC documents, verification, and storage</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="ABAY.toast('Documents exported','success')"><i class="fa-solid fa-download"></i> Export List</button>
    <button class="btn btn-primary" onclick="document.getElementById('upload-modal').classList.add('active')">
      <i class="fa-solid fa-upload"></i> Upload Document
    </button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoDocs), 'Total Documents', 'fa-folder', '#6366f1'],
    [count(array_filter($demoDocs, fn($d) => $d['status'] === 'Verified')), 'Verified', 'fa-circle-check', '#22c55e'],
    [count(array_filter($demoDocs, fn($d) => $d['status'] === 'Pending')), 'Pending Review', 'fa-clock', '#f59e0b'],
    [count(array_filter($demoDocs, fn($d) => $d['status'] === 'Rejected')), 'Rejected', 'fa-circle-xmark', '#ef4444'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body" style="padding:16px">
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <input type="text" class="form-control form-control-sm" placeholder="Search customer or document..." style="flex:1;min-width:200px" oninput="filterDocs(this.value)">
      <select class="form-control form-control-sm" style="width:150px" onchange="filterByStatus(this.value)">
        <option value="">All Status</option>
        <option>Verified</option>
        <option>Pending</option>
        <option>Rejected</option>
      </select>
      <select class="form-control form-control-sm" style="width:175px">
        <option value="">All Document Types</option>
        <option>National ID</option>
        <option>Passport</option>
        <option>Fayda ID</option>
        <option>Business License</option>
        <option>Utility Bill</option>
      </select>
    </div>
  </div>
</div>

<!-- Documents Table -->
<div class="card">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Document</th>
            <th>Customer</th>
            <th>Type</th>
            <th>Size</th>
            <th>Uploaded</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="docs-tbody">
          <?php foreach ($demoDocs as $doc):
            $ext = strtolower(pathinfo($doc['file_name'], PATHINFO_EXTENSION));
            $ico = in_array($ext, ['jpg', 'png', 'jpeg']) ? 'fa-image' : ($ext === 'pdf' ? 'fa-file-pdf' : 'fa-file');
            $icoColor = in_array($ext, ['jpg', 'png', 'jpeg']) ? '#3b82f6' : '#ef4444';
            $sc = match ($doc['status']) {
              'Verified' => 'badge-success',
              'Pending' => 'badge-warning',
              default => 'badge-danger'
            };
          ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:10px">
                  <div style="width:36px;height:36px;background:<?= $icoColor ?>20;border-radius:8px;display:flex;align-items:center;justify-content:center">
                    <i class="fa-solid <?= $ico ?>" style="color:<?= $icoColor ?>"></i>
                  </div>
                  <span style="font-size:.83rem;color:var(--text-muted)"><?= htmlspecialchars($doc['file_name']) ?></span>
                </div>
              </td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($doc['customer_name'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($doc['customer_name']) ?></div>
                  </div>
                </div>
              </td>
              <td><span class="badge badge-secondary"><?= htmlspecialchars($doc['doc_type']) ?></span></td>
              <td class="text-muted"><?= $doc['size'] ?></td>
              <td class="text-muted" style="font-size:.82rem"><?= $doc['uploaded_at'] ?></td>
              <td><span class="badge <?= $sc ?>"><?= $doc['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="View" onclick="ABAY.toast('Opening document preview','info')"><i class="fa-solid fa-eye"></i></button>
                  <button class="action-btn approve" data-tooltip="Verify" onclick="ABAY.toast('Document verified','success')"><i class="fa-solid fa-check"></i></button>
                  <button class="action-btn delete" data-tooltip="Reject" onclick="ABAY.toast('Document rejected','warning')"><i class="fa-solid fa-xmark"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Upload Modal -->
<div class="modal-overlay" id="upload-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:460px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-upload"></i> Upload Document</h3>
      <button class="modal-close" onclick="document.getElementById('upload-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="uploadDoc(event)">
        <div class="form-group">
          <label class="form-label required">Customer</label>
          <select class="form-control">
            <option>-- Select Customer --</option>
            <option>Abebe Girma</option>
            <option>Tigist Haile</option>
            <option>Samuel Bekele</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Document Type</label>
          <select class="form-control">
            <option>National ID</option>
            <option>Passport</option>
            <option>Fayda ID</option>
            <option>Business License</option>
            <option>Utility Bill</option>
            <option>Other</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label required">File</label>
          <div style="border:2px dashed var(--border);border-radius:10px;padding:32px;text-align:center;cursor:pointer" onclick="this.querySelector('input').click()">
            <i class="fa-solid fa-cloud-arrow-up" style="font-size:2rem;color:var(--primary);margin-bottom:8px;display:block"></i>
            <p class="text-muted" style="margin:0;font-size:.85rem">Click to select or drag & drop</p>
            <p class="text-muted" style="margin:4px 0 0;font-size:.78rem">PDF, JPG, PNG — max 10MB</p>
            <input type="file" accept=".pdf,.jpg,.png,.jpeg" style="display:none">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('upload-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterDocs(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#docs-tbody tr').forEach(tr => {
      tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  }

  function filterByStatus(s) {
    s = s.toLowerCase();
    document.querySelectorAll('#docs-tbody tr').forEach(tr => {
      tr.style.display = !s || tr.cells[5].textContent.toLowerCase().includes(s) ? '' : 'none';
    });
  }

  function uploadDoc(e) {
    e.preventDefault();
    document.getElementById('upload-modal').classList.remove('active');
    ABAY.toast('Document uploaded and queued for verification', 'success');
  }
</script>