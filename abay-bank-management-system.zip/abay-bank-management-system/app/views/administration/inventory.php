﻿<?php

/** @var array $assets @var array $user */
$demoAssets = $assets ?: [
  ['id' => 1, 'name' => 'Dell Latitude 5530 Laptop', 'category' => 'IT Equipment', 'branch' => 'HQ', 'quantity' => 15, 'unit_cost' => 'ETB 85,000', 'total_value' => 'ETB 1,275,000', 'condition' => 'Good', 'assigned_to' => 'IT Department'],
  ['id' => 2, 'name' => 'ATM Machine (NCR SelfServ)', 'category' => 'ATM', 'branch' => 'Bole', 'quantity' => 2, 'unit_cost' => 'ETB 850,000', 'total_value' => 'ETB 1,700,000', 'condition' => 'Good', 'assigned_to' => 'Branch Operations'],
  ['id' => 3, 'name' => 'Currency Counter', 'category' => 'Banking Equipment', 'branch' => 'HQ', 'quantity' => 8, 'unit_cost' => 'ETB 12,500', 'total_value' => 'ETB 100,000', 'condition' => 'Good', 'assigned_to' => 'Teller Department'],
  ['id' => 4, 'name' => 'Office Chair', 'category' => 'Furniture', 'branch' => 'Piassa', 'quantity' => 40, 'unit_cost' => 'ETB 3,500', 'total_value' => 'ETB 140,000', 'condition' => 'Fair', 'assigned_to' => 'All Staff'],
  ['id' => 5, 'name' => 'Security Camera (IP)', 'category' => 'Security', 'branch' => 'HQ', 'quantity' => 24, 'unit_cost' => 'ETB 8,500', 'total_value' => 'ETB 204,000', 'condition' => 'Good', 'assigned_to' => 'Security Department'],
  ['id' => 6, 'name' => 'Printer (HP LaserJet)', 'category' => 'IT Equipment', 'branch' => 'Arada', 'quantity' => 5, 'unit_cost' => 'ETB 18,000', 'total_value' => 'ETB 90,000', 'condition' => 'Good', 'assigned_to' => 'Operations'],
];
$categories = ['IT Equipment', 'ATM', 'Banking Equipment', 'Furniture', 'Security', 'Vehicles', 'Other'];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-boxes-stacked" style="color:var(--primary)"></i> Asset Inventory</h1>
    <p class="page-subtitle">Track bank assets, equipment, and physical inventory</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="ABAY.toast('Inventory exported to Excel','success')"><i class="fa-solid fa-file-excel"></i> Export</button>
    <button class="btn btn-primary" onclick="document.getElementById('asset-modal').classList.add('active')">
      <i class="fa-solid fa-plus"></i> Add Asset
    </button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:#6366f120;color:#6366f1"><i class="fa-solid fa-boxes-stacked"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count($demoAssets) ?></div>
      <div class="stat-label">Asset Types</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#22c55e20;color:#22c55e"><i class="fa-solid fa-calculator"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= array_sum(array_column($demoAssets, 'quantity')) ?></div>
      <div class="stat-label">Total Units</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#3b82f620;color:#3b82f6"><i class="fa-solid fa-money-bill-wave"></i></div>
    <div class="stat-info">
      <div class="stat-value">ETB 3.5M</div>
      <div class="stat-label">Total Value</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#f59e0b20;color:#f59e0b"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div class="stat-info">
      <div class="stat-value">2</div>
      <div class="stat-label">Needs Maintenance</div>
    </div>
  </div>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body" style="padding:16px">
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <input type="text" id="inv-search" class="form-control form-control-sm" placeholder="Search assets..." style="flex:1;min-width:200px" oninput="filterInv()">
      <select id="filter-cat" class="form-control form-control-sm" style="width:175px" onchange="filterInv()">
        <option value="">All Categories</option>
        <?php foreach ($categories as $c): ?><option><?= $c ?></option><?php endforeach; ?>
      </select>
      <select id="filter-branch-inv" class="form-control form-control-sm" style="width:145px" onchange="filterInv()">
        <option value="">All Branches</option>
        <option>HQ</option>
        <option>Bole</option>
        <option>Piassa</option>
        <option>Alem Ketema</option><option>Arada</option><option>Alem Ketema</option>
      </select>
    </div>
  </div>
</div>

<!-- Inventory Table -->
<div class="card">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Asset Name</th>
            <th>Category</th>
            <th>Branch</th>
            <th>Qty</th>
            <th>Unit Cost</th>
            <th>Total Value</th>
            <th>Condition</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="inv-tbody">
          <?php foreach ($demoAssets as $a):
            $cc = match ($a['condition']) {
              'Good' => 'badge-success',
              'Fair' => 'badge-warning',
              default => 'badge-danger'
            };
          ?>
            <tr>
              <td>
                <div>
                  <div class="fw-semibold"><?= htmlspecialchars($a['name']) ?></div>
                  <div class="text-muted" style="font-size:.78rem"><?= htmlspecialchars($a['assigned_to']) ?></div>
                </div>
              </td>
              <td><span class="badge badge-info"><?= htmlspecialchars($a['category']) ?></span></td>
              <td><?= htmlspecialchars($a['branch']) ?></td>
              <td class="fw-semibold"><?= $a['quantity'] ?></td>
              <td><?= $a['unit_cost'] ?></td>
              <td class="fw-semibold text-primary"><?= $a['total_value'] ?></td>
              <td><span class="badge <?= $cc ?>"><?= $a['condition'] ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn edit" data-tooltip="Edit" onclick="ABAY.toast('Edit asset form','info')"><i class="fa-solid fa-pen"></i></button>
                  <button class="action-btn view" data-tooltip="Transfer" onclick="ABAY.toast('Asset transfer request','info')"><i class="fa-solid fa-right-left"></i></button>
                  <button class="action-btn delete" data-tooltip="Dispose" onclick="ABAY.toast('Asset disposal initiated','warning')"><i class="fa-solid fa-trash"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Asset Modal -->
<div class="modal-overlay" id="asset-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-plus"></i> Add New Asset</h3>
      <button class="modal-close" onclick="document.getElementById('asset-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="saveAsset(event)">
        <div class="form-grid-2">
          <div class="form-group form-group-full">
            <label class="form-label required">Asset Name</label>
            <input type="text" class="form-control" placeholder="e.g. Dell Laptop" required>
          </div>
          <div class="form-group">
            <label class="form-label">Category</label>
            <select class="form-control">
              <?php foreach ($categories as $c): ?><option><?= $c ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Branch</label>
            <select class="form-control">
              <option>HQ</option>
              <option>Bole</option>
              <option>Piassa</option>
              <option>Alem Ketema</option><option>Arada</option><option>Alem Ketema</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Quantity</label>
            <input type="number" class="form-control" value="1" min="1" required>
          </div>
          <div class="form-group">
            <label class="form-label">Unit Cost (ETB)</label>
            <input type="number" class="form-control" placeholder="0.00">
          </div>
          <div class="form-group">
            <label class="form-label">Condition</label>
            <select class="form-control">
              <option>Good</option>
              <option>Fair</option>
              <option>Poor</option>
            </select>
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Assigned To</label>
            <input type="text" class="form-control" placeholder="Department or person">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('asset-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Add Asset</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterInv() {
    const q = document.getElementById('inv-search').value.toLowerCase();
    const cat = document.getElementById('filter-cat').value.toLowerCase();
    const br = document.getElementById('filter-branch-inv').value.toLowerCase();
    document.querySelectorAll('#inv-tbody tr').forEach(tr => {
      const txt = tr.textContent.toLowerCase();
      tr.style.display = (!q || txt.includes(q)) && (!cat || txt.includes(cat)) && (!br || txt.includes(br)) ? '' : 'none';
    });
  }

  function saveAsset(e) {
    e.preventDefault();
    document.getElementById('asset-modal').classList.remove('active');
    ABAY.toast('Asset added to inventory!', 'success');
  }
</script>