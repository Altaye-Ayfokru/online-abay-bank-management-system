<?php
$pageTitle = 'IP Settings — ' . APP_NAME;
$ipList = $ipRules ?? [];
if (empty($ipList)) {
    $ipList = [
        ['id'=>1,'ip_address'=>'192.168.1.0/24','description'=>'Local Office Network','type'=>'Whitelist','status'=>'Active','created_at'=>'2024-01-15'],
        ['id'=>2,'ip_address'=>'10.0.0.0/8',    'description'=>'Internal VPN Range',  'type'=>'Whitelist','status'=>'Active','created_at'=>'2024-02-01'],
        ['id'=>3,'ip_address'=>'185.220.101.45', 'description'=>'Suspicious IP blocked','type'=>'Blacklist','status'=>'Active','created_at'=>'2026-07-10'],
        ['id'=>4,'ip_address'=>'41.206.0.0/16',  'description'=>'Ethiopia ISP Range',  'type'=>'Whitelist','status'=>'Active','created_at'=>'2024-03-05'],
    ];
}
?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-network-wired" style="color:#1B3A5C;margin-right:8px"></i>IP Settings</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/admin/settings">Settings</a><span class="sep">/</span><span>IP Settings</span></div>
  </div>
  <button onclick="document.getElementById('add-ip-modal').style.display='flex'" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add IP Rule</button>
</div>

<!-- Info Banner -->
<div style="background:linear-gradient(135deg,#1B3A5C,#254d7a);border-radius:12px;padding:16px 20px;margin-bottom:20px;color:#fff;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
  <i class="fa-solid fa-shield-halved" style="font-size:1.4rem;color:#C8A84B;flex-shrink:0"></i>
  <div>
    <div style="font-size:.9rem;font-weight:700;margin-bottom:3px">IP Access Control</div>
    <div style="font-size:.8rem;opacity:.75">Control which IP addresses can access the admin portal. Whitelist allows access; Blacklist blocks it. Use CIDR notation for IP ranges (e.g. 192.168.1.0/24).</div>
  </div>
  <div style="margin-left:auto;display:flex;gap:8px">
    <div style="background:rgba(255,255,255,.1);border-radius:8px;padding:8px 14px;text-align:center">
      <div style="font-size:1.2rem;font-weight:800;color:#C8A84B"><?= count(array_filter($ipList,fn($r)=>$r['type']==='Whitelist')) ?></div>
      <div style="font-size:.68rem;opacity:.65;text-transform:uppercase;letter-spacing:.5px">Whitelisted</div>
    </div>
    <div style="background:rgba(255,255,255,.1);border-radius:8px;padding:8px 14px;text-align:center">
      <div style="font-size:1.2rem;font-weight:800;color:#f87171"><?= count(array_filter($ipList,fn($r)=>$r['type']==='Blacklist')) ?></div>
      <div style="font-size:.68rem;opacity:.65;text-transform:uppercase;letter-spacing:.5px">Blacklisted</div>
    </div>
  </div>
</div>

<!-- Current IP -->
<div style="background:#f0fbfc;border:1px solid #b3e4e9;border-radius:10px;padding:13px 16px;margin-bottom:20px;display:flex;align-items:center;gap:10px">
  <i class="fa-solid fa-location-dot" style="color:#007A8A;font-size:1.1rem"></i>
  <div style="font-size:.84rem;color:#0e7490"><strong>Your current IP:</strong> <?= htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1') ?></div>
  <button onclick="addCurrentIP()" style="margin-left:auto;padding:6px 14px;background:#007A8A;color:#fff;border:none;border-radius:7px;font-size:.78rem;font-weight:700;cursor:pointer;font-family:inherit">+ Add to Whitelist</button>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-list-check" style="color:#1B3A5C;margin-right:7px"></i>IP Rules</h3>
    <div style="display:flex;gap:9px">
      <select id="ip-type-filter" onchange="filterIpRules()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.83rem;background:#fff;cursor:pointer">
        <option value="">All Types</option><option>Whitelist</option><option>Blacklist</option>
      </select>
      <input type="search" id="ip-search" placeholder="Search IP or description..." onchange="filterIpRules()" oninput="filterIpRules()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.83rem;width:200px;outline:none">
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table" id="ip-table">
      <thead><tr><th>IP Address / Range</th><th>Description</th><th>Type</th><th>Status</th><th>Added</th><th>Actions</th></tr></thead>
      <tbody id="ip-tbody">
        <?php foreach ($ipList as $rule):
          $tc = ($rule['type']??'') === 'Whitelist' ? 'success' : 'danger';
          $sc = ($rule['status']??'') === 'Active'   ? 'success' : 'secondary';
        ?>
        <tr data-ip="<?= strtolower(htmlspecialchars($rule['ip_address']??'')) ?>" data-type="<?= htmlspecialchars($rule['type']??'') ?>">
          <td><span style="font-family:monospace;font-size:.83rem;font-weight:700;color:#1B3A5C"><?= htmlspecialchars($rule['ip_address']??'—') ?></span></td>
          <td style="font-size:.82rem;color:#475569"><?= htmlspecialchars($rule['description']??'—') ?></td>
          <td><span class="badge badge-<?= $tc ?>"><?= htmlspecialchars($rule['type']??'—') ?></span></td>
          <td><span class="badge badge-<?= $sc ?>"><?= htmlspecialchars($rule['status']??'—') ?></span></td>
          <td style="font-size:.78rem;color:#94a3b8"><?= htmlspecialchars($rule['created_at']??'—') ?></td>
          <td>
            <div style="display:flex;gap:4px">
              <button onclick="toggleIpRule(<?= (int)($rule['id']??0) ?>,this)" style="padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Toggle">
                <i class="fa-solid <?= ($rule['status']??'')==='Active'?'fa-pause':'fa-play' ?>" style="color:#007A8A"></i>
              </button>
              <button onclick="deleteIpRule(<?= (int)($rule['id']??0) ?>,this)" style="padding:4px 8px;border:1.5px solid #fecaca;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Delete">
                <i class="fa-solid fa-trash" style="color:#dc2626"></i>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add IP Modal -->
<div id="add-ip-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:440px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Add IP Rule</div>
      <button onclick="document.getElementById('add-ip-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="ip-add-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">IP Address or CIDR Range *</label><input type="text" id="new-ip" placeholder="e.g. 192.168.1.1 or 10.0.0.0/8" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none;font-family:monospace" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Description</label><input type="text" id="new-ip-desc" placeholder="e.g. Office network, VPN range" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Rule Type *</label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <label style="cursor:pointer"><input type="radio" name="ip-rule-type" value="Whitelist" checked style="display:none"><div id="ip-type-wl" style="border:2px solid #10b981;border-radius:9px;padding:12px;text-align:center;background:#d1fae5">
            <i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.2rem;display:block;margin-bottom:5px"></i>
            <div style="font-size:.83rem;font-weight:700;color:#065f46">Whitelist</div>
            <div style="font-size:.72rem;color:#047857">Allow access</div>
          </div></label>
          <label style="cursor:pointer"><input type="radio" name="ip-rule-type" value="Blacklist" style="display:none"><div id="ip-type-bl" style="border:2px solid #e2e8f0;border-radius:9px;padding:12px;text-align:center">
            <i class="fa-solid fa-ban" style="color:#94a3b8;font-size:1.2rem;display:block;margin-bottom:5px"></i>
            <div style="font-size:.83rem;font-weight:700;color:#374151">Blacklist</div>
            <div style="font-size:.72rem;color:#94a3b8">Block access</div>
          </div></label>
        </div>
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('add-ip-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="ip-add-btn" onclick="submitIpRule()" style="padding:10px 20px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-plus"></i>Add Rule</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
// Radio button styling for IP type
document.querySelectorAll('input[name="ip-rule-type"]').forEach(function(r) {
  r.addEventListener('change', function() {
    document.getElementById('ip-type-wl').style.border = '2px solid #e2e8f0';
    document.getElementById('ip-type-wl').style.background = '';
    document.getElementById('ip-type-bl').style.border = '2px solid #e2e8f0';
    document.getElementById('ip-type-bl').style.background = '';
    if (r.value === 'Whitelist') {
      document.getElementById('ip-type-wl').style.border = '2px solid #10b981';
      document.getElementById('ip-type-wl').style.background = '#d1fae5';
    } else {
      document.getElementById('ip-type-bl').style.border = '2px solid #ef4444';
      document.getElementById('ip-type-bl').style.background = '#fee2e2';
    }
  });
});

function filterIpRules() {
  var q = document.getElementById('ip-search').value.toLowerCase();
  var type = document.getElementById('ip-type-filter').value;
  document.querySelectorAll('#ip-tbody tr').forEach(function(tr) {
    tr.style.display = ((!q || tr.dataset.ip.includes(q)) && (!type || tr.dataset.type === type)) ? '' : 'none';
  });
}

function addCurrentIP() {
  document.getElementById('new-ip').value = '<?= htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1') ?>';
  document.getElementById('new-ip-desc').value = 'My current IP';
  document.getElementById('add-ip-modal').style.display = 'flex';
}

function submitIpRule() {
  var ip = document.getElementById('new-ip').value.trim();
  var desc = document.getElementById('new-ip-desc').value.trim();
  var type = document.querySelector('input[name="ip-rule-type"]:checked')?.value || 'Whitelist';
  if (!ip) { ABAY.toast('IP address is required.', 'err'); return; }
  ABAY.setBtn('ip-add-btn', true);
  ABAY.api('/ip-rules', { method: 'POST', body: JSON.stringify({ ip_address: ip, description: desc, type: type }) }).then(function(d) {
    ABAY.setBtn('ip-add-btn', false, '<i class="fa-solid fa-plus"></i>Add Rule');
    document.getElementById('ip-add-ok').textContent = type + ' rule for ' + ip + ' added!';
    document.getElementById('ip-add-ok').style.display = 'block';
    ABAY.toast('IP rule added!', 'ok');
    setTimeout(function() { document.getElementById('add-ip-modal').style.display = 'none'; location.reload(); }, 1500);
  }).catch(function() {
    ABAY.setBtn('ip-add-btn', false, '<i class="fa-solid fa-plus"></i>Add Rule');
    document.getElementById('ip-add-ok').textContent = 'Demo: ' + type + ' rule for ' + ip + ' recorded.';
    document.getElementById('ip-add-ok').style.display = 'block';
    ABAY.toast('Demo IP rule added.', 'info');
    setTimeout(function() { document.getElementById('add-ip-modal').style.display = 'none'; }, 1500);
  });
}

function toggleIpRule(id, btn) {
  ABAY.api('/ip-rules/' + id + '/toggle', { method: 'PUT', body: JSON.stringify({}) }).then(function() { ABAY.toast('IP rule toggled!', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: IP rule toggled.', 'info'); });
}

function deleteIpRule(id, btn) {
  if (!confirm('Delete this IP rule?')) return;
  ABAY.api('/ip-rules/' + id, { method: 'DELETE' }).then(function() { btn.closest('tr').remove(); ABAY.toast('IP rule deleted!', 'ok'); }).catch(function() { btn.closest('tr').remove(); ABAY.toast('Demo: IP rule removed.', 'info'); });
}

document.addEventListener('keydown', function(e) { if (e.key === 'Escape') document.getElementById('add-ip-modal').style.display = 'none'; });
</script>
