<?php $pageTitle = 'Payment Settings — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-money-bill-transfer" style="color:#1B3A5C;margin-right:8px"></i>Payment Settings</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/admin/settings">Settings</a><span class="sep">/</span><span>Payment Settings</span></div>
  </div>
</div>

<!-- Section Nav -->
<div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
  <?php foreach([['gateways','fa-credit-card','Payment Gateways'],['fees','fa-percent','Fee Structure'],['limits','fa-shield-halved','Limits'],['mobile','fa-mobile-screen','Mobile Money'],['crypto','fa-bitcoin-sign','Crypto (Future)']] as $i=>[$s,$ic,$lbl]): ?>
  <button onclick="showPayTab('<?= $s ?>')" id="paytab-<?= $s ?>" class="btn <?= $i===0?'btn-primary':'btn-ghost' ?>" style="display:inline-flex;align-items:center;gap:7px;padding:9px 16px">
    <i class="fa-solid <?= $ic ?>"></i><?= $lbl ?>
  </button>
  <?php endforeach; ?>
</div>

<div id="pay-save-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px 16px;margin-bottom:16px;font-size:.84rem;color:#065f46;align-items:center;gap:8px"><i class="fa-solid fa-circle-check"></i>Payment settings saved!</div>

<!-- Gateways Panel -->
<div id="paypanel-gateways">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
    <?php foreach([
      ['EthSwitch','fa-bolt','#059669','Real-time inter-bank transfers via EthSwitch network',['Routing Code'=>'ABYAETAA','API Endpoint'=>'https://api.ethswitch.com/v2','API Key'=>'','Status'=>'Active']],
      ['Telebirr','fa-mobile-screen','#ea580c','Ethio Telecom mobile money integration',['Merchant ID'=>'ETL-ABAY-001','Secret Key'=>'','Callback URL'=>APP_URL.'/api/telebirr/callback','Status'=>'Active']],
      ['M-Pesa','fa-sim-card','#047857','Safaricom M-Pesa Ethiopia integration',['Consumer Key'=>'','Consumer Secret'=>'','Callback URL'=>APP_URL.'/api/mpesa/callback','Status'=>'Inactive']],
      ['Western Union','fa-money-bill-transfer','#854d0e','Cash pickup and international transfers',['Agent ID'=>'WU-ET-ABAY','Agent Password'=>'','Test Mode'=>'Yes','Status'=>'Active']],
    ] as [$gw,$ic,$clr,$desc,$fields]): ?>
    <div class="card">
      <div class="card-header">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:38px;height:38px;border-radius:9px;background:<?= $clr ?>1a;color:<?= $clr ?>;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0"><i class="fa-solid <?= $ic ?>"></i></div>
          <div><div style="font-size:.9rem;font-weight:700;color:#1B3A5C"><?= $gw ?></div><div style="font-size:.73rem;color:#94a3b8"><?= $desc ?></div></div>
        </div>
        <span class="badge badge-<?= ($fields['Status']??'')!=='Inactive'?'success':'secondary' ?>"><?= $fields['Status']??'Active' ?></span>
      </div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:10px">
        <?php foreach ($fields as $k=>$v): if ($k==='Status') continue; ?>
        <div><label style="display:block;font-size:.77rem;font-weight:600;color:#374151;margin-bottom:3px"><?= $k ?></label>
          <input type="<?= in_array($k,['API Key','Secret Key','Agent Password','Consumer Secret'])?'password':'text' ?>" class="form-control" value="<?= htmlspecialchars($v) ?>" style="font-size:.84rem"></div>
        <?php endforeach; ?>
        <div style="display:flex;gap:8px;margin-top:4px">
          <button onclick="ABAY.toast('<?= $gw ?> connection test passed!','ok')" style="flex:1;padding:8px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.8rem;font-weight:600;cursor:pointer;font-family:inherit">Test Connection</button>
          <button onclick="savePayGateway('<?= strtolower($gw) ?>')" style="flex:1;padding:8px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.8rem;font-weight:700;cursor:pointer;font-family:inherit">Save</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Fee Structure Panel -->
<div id="paypanel-fees" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-percent" style="color:#1B3A5C;margin-right:7px"></i>Transaction Fee Structure</h3></div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="data-table">
          <thead><tr><th>Transaction Type</th><th>Channel</th><th>Fee Type</th><th>Fee Value</th><th>Min Fee</th><th>Max Fee</th></tr></thead>
          <tbody>
            <?php foreach([
              ['Internal Transfer','Abay → Abay','Fixed','ETB 0.00','—','—'],
              ['Inter-Branch Transfer','Counter','Fixed','ETB 10.00','ETB 10','ETB 10'],
              ['EthSwitch Transfer','Online','Fixed','ETB 15.00','ETB 15','ETB 15'],
              ['Telebirr Transfer','Mobile','Fixed','ETB 5.00','ETB 5','ETB 50'],
              ['SWIFT Wire','International','Percentage','1.00%','USD 25','USD 500'],
              ['Western Union','Cash Pickup','Percentage','1.50%','ETB 50','ETB 5,000'],
              ['ATM Withdrawal (Abay)','ATM','Free','ETB 0.00','—','—'],
              ['ATM Withdrawal (Other)','ATM','Fixed','ETB 15.00','ETB 15','ETB 15'],
            ] as [$type,$ch,$ft,$fv,$min,$max]): ?>
            <tr>
              <td style="font-size:.83rem;font-weight:600;color:#1e293b"><?= $type ?></td>
              <td style="font-size:.81rem;color:#475569"><?= $ch ?></td>
              <td><span style="font-size:.77rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600"><?= $ft ?></span></td>
              <td><input type="text" value="<?= $fv ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:6px 10px;font-size:.83rem;width:90px;outline:none;text-align:right" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></td>
              <td style="font-size:.8rem;color:#94a3b8"><?= $min ?></td>
              <td style="font-size:.8rem;color:#94a3b8"><?= $max ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="margin-top:16px">
        <button onclick="savePaySettings('fees')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Fee Structure</button>
      </div>
    </div>
  </div>
</div>

<!-- Limits Panel -->
<div id="paypanel-limits" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-shield-halved" style="color:#1B3A5C;margin-right:7px"></i>Transaction Limits by Role</h3></div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="data-table">
          <thead><tr><th>Role</th><th>Max Deposit</th><th>Max Withdrawal</th><th>Max Transfer</th><th>Daily Limit</th><th>Approval Required Above</th></tr></thead>
          <tbody>
            <?php foreach([
              ['Teller',      '500,000','200,000','100,000','1,000,000','100,000'],
              ['Manager',    '2,000,000','1,000,000','500,000','5,000,000','1,000,000'],
              ['Admin',      '10,000,000','5,000,000','2,000,000','Unlimited','5,000,000'],
              ['Loan Officer','Deposits only','N/A','N/A','500,000','N/A'],
              ['Auditor',    'Read-only','Read-only','Read-only','—','—'],
            ] as [$role,$dep,$wd,$txf,$daily,$approval]): ?>
            <tr>
              <td style="font-weight:600;font-size:.83rem"><?= $role ?></td>
              <td><input type="text" value="<?= $dep ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:5px 9px;font-size:.82rem;width:100px;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></td>
              <td><input type="text" value="<?= $wd ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:5px 9px;font-size:.82rem;width:100px;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></td>
              <td><input type="text" value="<?= $txf ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:5px 9px;font-size:.82rem;width:100px;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></td>
              <td style="font-size:.81rem;color:#475569"><?= $daily ?></td>
              <td style="font-size:.81rem;color:#f59e0b;font-weight:600">ETB <?= $approval ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="margin-top:16px">
        <button onclick="savePaySettings('limits')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Limits</button>
      </div>
    </div>
  </div>
</div>

<!-- Mobile Money Panel -->
<div id="paypanel-mobile" style="display:none">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-mobile-screen" style="color:#1B3A5C;margin-right:7px"></i>Mobile Money Configuration</h3></div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Telebirr Daily Limit (ETB)</label><input type="number" class="form-control" value="50000"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">M-Pesa Daily Limit (ETB)</label><input type="number" class="form-control" value="30000"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Min Mobile Transfer</label><input type="number" class="form-control" value="1"></div>
        <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Mobile Transfer Fee (ETB)</label><input type="number" class="form-control" value="5" step="1"></div>
      </div>
      <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
        <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Mobile Notifications</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
          <?php foreach(['SMS on every transfer'=>true,'Push notification on receive'=>true,'Daily summary SMS'=>false,'Failed transfer alert'=>true] as $n=>$en): ?>
          <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" <?= $en?'checked':'' ?> style="accent-color:#007A8A;width:14px;height:14px"><span style="font-size:.82rem;font-weight:500"><?= $n ?></span></label>
          <?php endforeach; ?>
        </div>
      </div>
      <button onclick="savePaySettings('mobile')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Mobile Settings</button>
    </div>
  </div>
</div>

<!-- Crypto Panel -->
<div id="paypanel-crypto" style="display:none">
  <div style="background:#f8fafc;border:2px dashed #e2e8f0;border-radius:14px;padding:48px;text-align:center">
    <i class="fa-brands fa-bitcoin" style="font-size:2.5rem;color:#94a3b8;margin-bottom:16px;display:block"></i>
    <div style="font-size:1.05rem;font-weight:700;color:#374151;margin-bottom:8px">Cryptocurrency Payments — Coming Soon</div>
    <div style="font-size:.85rem;color:#94a3b8;max-width:400px;margin:0 auto;line-height:1.7">Bitcoin, Ethereum, and USDT payment integration is planned for a future release. This feature will enable crypto-to-ETB conversion and cross-border settlements.</div>
    <div style="margin-top:20px;display:flex;justify-content:center;gap:12px">
      <?php foreach([['fa-brands fa-bitcoin','#f59e0b','Bitcoin (BTC)'],['fa-brands fa-ethereum','#475569','Ethereum (ETH)'],['fa-solid fa-dollar-sign','#16a34a','USDT']] as [$ic,$c,$lbl]): ?>
      <div style="background:#fff;border-radius:10px;padding:12px 18px;border:1.5px solid #e2e8f0;text-align:center">
        <i class="<?= $ic ?>" style="font-size:1.5rem;color:<?= $c ?>;display:block;margin-bottom:5px"></i>
        <div style="font-size:.78rem;font-weight:600;color:#374151"><?= $lbl ?></div>
        <div style="font-size:.69rem;color:#94a3b8;margin-top:2px">Planned</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
function showPayTab(tab) {
  ['gateways','fees','limits','mobile','crypto'].forEach(function(t) {
    var btn = document.getElementById('paytab-' + t);
    var panel = document.getElementById('paypanel-' + t);
    btn.className = 'btn ' + (t === tab ? 'btn-primary' : 'btn-ghost');
    btn.style.display = 'inline-flex'; btn.style.alignItems = 'center'; btn.style.gap = '7px'; btn.style.padding = '9px 16px';
    if (panel) panel.style.display = t === tab ? 'block' : 'none';
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function savePayGateway(gw) {
  ABAY.api('/settings/payment/gateway', { method: 'POST', body: JSON.stringify({ gateway: gw }) }).then(function() {
    ABAY.toast(gw + ' gateway settings saved!', 'ok');
  }).catch(function() { ABAY.toast('Demo: ' + gw + ' settings saved.', 'info'); });
}
function savePaySettings(section) {
  var ind = document.getElementById('pay-save-ok');
  ABAY.api('/settings/payment', { method: 'POST', body: JSON.stringify({ section: section }) }).then(function() {
    if (ind) { ind.style.display = 'flex'; setTimeout(function() { ind.style.display = 'none'; }, 3000); }
    ABAY.toast('Payment settings saved!', 'ok');
  }).catch(function() {
    if (ind) { ind.style.display = 'flex'; setTimeout(function() { ind.style.display = 'none'; }, 3000); }
    ABAY.toast('Settings saved (demo mode).', 'info');
  });
}
</script>
