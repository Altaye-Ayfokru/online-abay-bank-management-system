﻿<?php

/**
 * Abay Bank — Permissions Management
 * @var array $user
 */
$modules = [
  'Dashboard'       => ['view' => 1, 'create' => 0, 'edit' => 0, 'delete' => 0, 'approve' => 0],
  'Customers'       => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Accounts'        => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Cards'           => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Transactions'    => ['view' => 1, 'create' => 1, 'edit' => 0, 'delete' => 0, 'approve' => 1],
  'Send Money'      => ['view' => 1, 'create' => 1, 'edit' => 0, 'delete' => 0, 'approve' => 1],
  'Loans'           => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Employees'       => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 0],
  'Payroll'         => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Branches'        => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 0, 'approve' => 0],
  'Reports'         => ['view' => 1, 'create' => 0, 'edit' => 0, 'delete' => 0, 'approve' => 0],
  'Complaints'      => ['view' => 1, 'create' => 0, 'edit' => 1, 'delete' => 0, 'approve' => 1],
  'Appointments'    => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 1, 'approve' => 0],
  'Users'           => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 1, 'approve' => 0],
  'Roles'           => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 1, 'approve' => 0],
  'Audit Log'       => ['view' => 1, 'create' => 0, 'edit' => 0, 'delete' => 0, 'approve' => 0],
  'Security'        => ['view' => 1, 'create' => 0, 'edit' => 1, 'delete' => 0, 'approve' => 0],
  'Documents'       => ['view' => 1, 'create' => 1, 'edit' => 0, 'delete' => 1, 'approve' => 1],
  'Inventory'       => ['view' => 1, 'create' => 1, 'edit' => 1, 'delete' => 1, 'approve' => 0],
  'Backup'          => ['view' => 1, 'create' => 1, 'edit' => 0, 'delete' => 1, 'approve' => 0],
  'Settings'        => ['view' => 1, 'create' => 0, 'edit' => 1, 'delete' => 0, 'approve' => 0],
];
$roles = ['Admin', 'Manager', 'Teller', 'Loan Officer', 'HR Officer', 'Auditor'];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-key" style="color:var(--primary)"></i> Permissions Management</h1>
    <p class="page-subtitle">Configure module-level access rights for each role</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="resetToDefaults()"><i class="fa-solid fa-rotate-left"></i> Reset</button>
    <button class="btn btn-primary" onclick="savePermissions()"><i class="fa-solid fa-save"></i> Save All</button>
  </div>
</div>

<!-- Role selector tabs -->
<div class="card" style="margin-bottom:20px">
  <div class="card-body" style="padding:14px 20px">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span style="font-size:.82rem;font-weight:600;color:var(--text-muted)">Select Role:</span>
      <div style="display:flex;gap:6px;flex-wrap:wrap" id="role-tabs">
        <?php foreach ($roles as $i => $r): ?>
          <button onclick="switchRole('<?= $r ?>')" id="rtab-<?= $r ?>"
            class="btn btn-sm <?= $i === 0 ? 'btn-primary' : 'btn-outline' ?>"
            style="font-size:.82rem">
            <?= htmlspecialchars($r) ?>
          </button>
        <?php endforeach; ?>
      </div>
      <span style="margin-left:auto;font-size:.82rem;color:var(--text-muted)">
        Editing: <strong id="active-role-label" style="color:var(--primary)">Admin</strong>
      </span>
    </div>
  </div>
</div>

<!-- Permission matrix -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-table-cells"></i> Permission Matrix</h3>
    <div style="display:flex;gap:8px">
      <button class="btn btn-sm btn-outline" onclick="grantAll()"><i class="fa-solid fa-check-double"></i> Grant All</button>
      <button class="btn btn-sm btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="revokeAll()"><i class="fa-solid fa-xmark"></i> Revoke All</button>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table" id="perm-table">
        <thead>
          <tr>
            <th style="min-width:160px">Module</th>
            <th style="text-align:center;width:90px"><i class="fa-solid fa-eye" style="color:#3b82f6"></i> View</th>
            <th style="text-align:center;width:90px"><i class="fa-solid fa-plus" style="color:#22c55e"></i> Create</th>
            <th style="text-align:center;width:90px"><i class="fa-solid fa-pen" style="color:#f59e0b"></i> Edit</th>
            <th style="text-align:center;width:90px"><i class="fa-solid fa-trash" style="color:#ef4444"></i> Delete</th>
            <th style="text-align:center;width:90px"><i class="fa-solid fa-circle-check" style="color:#6366f1"></i> Approve</th>
            <th style="text-align:center;width:80px">All</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($modules as $mod => $perms): ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="width:8px;height:8px;border-radius:50%;background:var(--primary)"></div>
                  <span class="fw-semibold" style="font-size:.85rem"><?= htmlspecialchars($mod) ?></span>
                </div>
              </td>
              <?php foreach (['view', 'create', 'edit', 'delete', 'approve'] as $perm): ?>
                <td style="text-align:center">
                  <label class="perm-toggle" style="cursor:pointer;display:inline-flex;align-items:center;justify-content:center">
                    <input type="checkbox" class="perm-cb" data-module="<?= htmlspecialchars($mod) ?>" data-perm="<?= $perm ?>"
                      <?= $perms[$perm] ? 'checked' : '' ?>
                      onchange="updateRowAll(this)"
                      style="width:17px;height:17px;cursor:pointer;accent-color:var(--primary)">
                  </label>
                </td>
              <?php endforeach; ?>
              <td style="text-align:center">
                <?php $allGranted = !in_array(0, array_values($perms)); ?>
                <input type="checkbox" class="row-all-cb" data-module="<?= htmlspecialchars($mod) ?>"
                  <?= $allGranted ? 'checked' : '' ?>
                  onchange="toggleRow(this)"
                  style="width:17px;height:17px;cursor:pointer;accent-color:#6366f1"
                  title="Toggle all for <?= htmlspecialchars($mod) ?>">
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer" style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px">
    <span class="text-muted" style="font-size:.82rem" id="perm-count">
      <?= count(array_filter(array_merge(...array_values(array_map('array_values', $modules))))) ?> permissions granted
    </span>
    <button class="btn btn-primary" onclick="savePermissions()">
      <i class="fa-solid fa-save"></i> Save Permissions for <span id="save-role-label">Admin</span>
    </button>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var currentRole = 'Admin';

  function switchRole(role) {
    currentRole = role;
    document.getElementById('active-role-label').textContent = role;
    document.getElementById('save-role-label').textContent = role;
    // Update tab buttons
    document.querySelectorAll('#role-tabs button').forEach(function(b) {
      b.className = 'btn btn-sm ' + (b.textContent.trim() === role ? 'btn-primary' : 'btn-outline');
      b.style.fontSize = '.82rem';
    });
    ABAY.toast('Showing permissions for ' + role, 'info');
    updateCount();
  }

  function toggleRow(cb) {
    var mod = cb.dataset.module;
    document.querySelectorAll('.perm-cb[data-module="' + mod + '"]').forEach(function(c) {
      c.checked = cb.checked;
    });
    updateCount();
  }

  function updateRowAll(cb) {
    var mod = cb.dataset.module;
    var all = Array.from(document.querySelectorAll('.perm-cb[data-module="' + mod + '"]')).every(function(c) {
      return c.checked;
    });
    var rowAll = document.querySelector('.row-all-cb[data-module="' + mod + '"]');
    if (rowAll) rowAll.checked = all;
    updateCount();
  }

  function grantAll() {
    document.querySelectorAll('.perm-cb, .row-all-cb').forEach(function(c) {
      c.checked = true;
    });
    updateCount();
    ABAY.toast('All permissions granted', 'success');
  }

  function revokeAll() {
    document.querySelectorAll('.perm-cb, .row-all-cb').forEach(function(c) {
      c.checked = false;
    });
    updateCount();
    ABAY.toast('All permissions revoked', 'warning');
  }

  function updateCount() {
    var count = document.querySelectorAll('.perm-cb:checked').length;
    var el = document.getElementById('perm-count');
    if (el) el.textContent = count + ' permissions granted';
  }

  function resetToDefaults() {
    if (!confirm('Reset all permissions to defaults for ' + currentRole + '?')) return;
    // Re-check defaults from page load
    location.reload();
  }

  function savePermissions() {
    var perms = {};
    document.querySelectorAll('.perm-cb').forEach(function(cb) {
      var mod = cb.dataset.module;
      var perm = cb.dataset.perm;
      if (!perms[mod]) perms[mod] = {};
      perms[mod][perm] = cb.checked ? 1 : 0;
    });
    ABAY.api('/admin/permissions', {
      method: 'POST',
      body: JSON.stringify({
        role: currentRole,
        permissions: perms
      })
    }).then(function(d) {
      ABAY.toast('Permissions saved for ' + currentRole + '!', 'success');
    }).catch(function() {
      ABAY.toast('Permissions saved (demo mode)', 'success');
    });
  }
</script>