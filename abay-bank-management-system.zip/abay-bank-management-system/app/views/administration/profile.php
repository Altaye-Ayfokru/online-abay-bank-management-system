<?php
/**
 * Abay Bank — User Profile & Settings
 * Accessible via /admin/profile
 */
/** @var array $user */
$u       = $user ?? [];
$name    = htmlspecialchars($u['full_name'] ?? $u['username'] ?? 'User');
$role    = htmlspecialchars($u['role']  ?? 'Staff');
$email   = htmlspecialchars($u['email'] ?? '');
$phone   = htmlspecialchars($u['phone'] ?? '');
$avatar  = htmlspecialchars($u['avatar'] ?? '');
$initial = strtoupper(substr($u['full_name'] ?? $u['username'] ?? 'U', 0, 1));
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-user-circle" style="color:var(--primary)"></i> My Profile</h1>
    <p class="page-subtitle">Manage your account details, password, and profile picture</p>
  </div>
</div>

<div style="display:grid;grid-template-columns:300px 1fr;gap:24px;align-items:start">

  <!-- Left: Avatar Card -->
  <div>
    <div class="card" style="text-align:center">
      <div class="card-body" style="padding:32px 20px">
        <!-- Avatar -->
        <div style="position:relative;display:inline-block;margin-bottom:20px" id="avatar-wrap">
          <?php if ($avatar): ?>
          <img id="profile-img" src="<?= $avatar ?>" alt="Profile"
               style="width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid var(--primary);box-shadow:0 4px 16px rgba(0,0,0,.15)">
          <?php else: ?>
          <div id="profile-initial" style="width:110px;height:110px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--teal));color:#fff;display:flex;align-items:center;justify-content:center;font-size:2.8rem;font-weight:800;border:4px solid rgba(255,255,255,.2);box-shadow:0 4px 16px rgba(0,0,0,.15);margin:0 auto">
            <?= $initial ?>
          </div>
          <?php endif; ?>

          <!-- Upload overlay -->
          <label for="avatar-input" style="position:absolute;bottom:4px;right:4px;width:34px;height:34px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.2);transition:.2s" title="Change photo" onmouseover="this.style.background='var(--teal)'" onmouseout="this.style.background='var(--primary)'">
            <i class="fa-solid fa-camera" style="color:#fff;font-size:.75rem"></i>
          </label>
          <input type="file" id="avatar-input" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none" onchange="uploadAvatar(this)">
        </div>

        <h3 style="margin:0 0 4px;font-size:1.1rem"><?= $name ?></h3>
        <p style="margin:0 0 4px;color:var(--teal);font-size:.85rem;font-weight:600"><?= $role ?></p>
        <p style="margin:0;color:var(--text-muted);font-size:.8rem"><?= $email ?></p>

        <div id="upload-progress" style="display:none;margin-top:14px">
          <div style="height:4px;background:#e5e7eb;border-radius:2px;overflow:hidden">
            <div id="upload-bar" style="height:100%;background:var(--teal);border-radius:2px;width:0%;transition:width .3s"></div>
          </div>
          <p style="font-size:.75rem;color:var(--text-muted);margin-top:6px">Uploading...</p>
        </div>
      </div>
    </div>

    <!-- Quick Stats -->
    <div class="card" style="margin-top:16px">
      <div class="card-body" style="padding:16px">
        <h4 style="font-size:.82rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--text-muted);margin-bottom:12px">Account Info</h4>
        <div style="display:flex;flex-direction:column;gap:10px;font-size:.84rem">
          <div style="display:flex;justify-content:space-between">
            <span class="text-muted">Username</span>
            <span class="fw-semibold"><?= htmlspecialchars($u['username'] ?? '—') ?></span>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span class="text-muted">Role</span>
            <span class="badge badge-primary" style="font-size:.75rem"><?= $role ?></span>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span class="text-muted">Member Since</span>
            <span><?= date('M Y', strtotime($u['created_at'] ?? 'now')) ?></span>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span class="text-muted">Last Login</span>
            <span class="text-muted" style="font-size:.8rem"><?= date('d M H:i', strtotime($u['last_login'] ?? 'now')) ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Right: Tabs -->
  <div>
    <!-- Tab Nav -->
    <div style="display:flex;gap:4px;background:var(--surface);border-radius:12px;padding:4px;margin-bottom:20px;width:fit-content">
      <?php foreach (['profile'=>['fa-user','Profile'],'password'=>['fa-lock','Password'],'notifications'=>['fa-bell','Alerts'],'sessions'=>['fa-shield-halved','Security']] as $tab=>[$ico,$lbl]): ?>
      <button onclick="switchProfileTab('<?= $tab ?>')" id="ptab-<?= $tab ?>"
              class="btn btn-sm <?= $tab==='profile'?'btn-primary':'btn-ghost' ?>"
              style="display:flex;align-items:center;gap:6px;font-size:.84rem;padding:8px 16px;border-radius:9px">
        <i class="fa-solid <?= $ico ?>"></i> <?= $lbl ?>
      </button>
      <?php endforeach; ?>
    </div>

    <!-- Profile Tab -->
    <div id="ptab-panel-profile">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><i class="fa-solid fa-user"></i> Personal Information</h3>
        </div>
        <div class="card-body">
          <form id="profile-form" onsubmit="saveProfile(event)">
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label required">Full Name</label>
                <input type="text" id="pf-name" class="form-control" value="<?= $name ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($u['username'] ?? '') ?>" readonly style="background:var(--surface);color:var(--text-muted)">
              </div>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" id="pf-email" class="form-control" value="<?= $email ?>">
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input type="tel" id="pf-phone" class="form-control" value="<?= $phone ?>" placeholder="+251...">
              </div>
              <div class="form-group">
                <label class="form-label">Role</label>
                <input type="text" class="form-control" value="<?= $role ?>" readonly style="background:var(--surface);color:var(--text-muted)">
              </div>
              <div class="form-group">
                <label class="form-label">Time Zone</label>
                <select class="form-control">
                  <option selected>Africa/Addis_Ababa (EAT +3)</option>
                  <option>UTC</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Language</label>
                <select class="form-control">
                  <option>English</option>
                  <option>አማርኛ (Amharic)</option>
                  <option>Afaan Oromoo</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Theme</label>
                <select class="form-control" onchange="applyThemePref(this.value)">
                  <option value="light" id="theme-opt-light">Light</option>
                  <option value="dark"  id="theme-opt-dark">Dark</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Bio / Notes</label>
              <textarea class="form-control" rows="2" placeholder="Short bio or work notes..."></textarea>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
              <button type="button" class="btn btn-outline" onclick="document.getElementById('profile-form').reset()">Reset</button>
              <button type="submit" id="save-profile-btn" class="btn btn-primary">
                <i class="fa-solid fa-save"></i> Save Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Password Tab -->
    <div id="ptab-panel-password" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><i class="fa-solid fa-lock"></i> Change Password</h3>
        </div>
        <div class="card-body" style="max-width:480px">
          <div id="pw-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:18px;color:#065f46;display:flex;align-items:center;gap:10px">
            <i class="fa-solid fa-circle-check"></i> Password changed successfully!
          </div>
          <div id="pw-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin-bottom:18px;color:#991b1b;font-size:.85rem"></div>
          <form id="password-form" onsubmit="changePassword(event)">
            <div class="form-group">
              <label class="form-label required">Current Password</label>
              <div style="position:relative">
                <input type="password" id="pw-current" class="form-control" placeholder="Your current password" required
                       style="padding-right:42px">
                <button type="button" onclick="togglePw('pw-current',this)" class="btn" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);padding:4px 8px;background:none;color:var(--text-muted)">
                  <i class="fa-solid fa-eye"></i>
                </button>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label required">New Password</label>
              <div style="position:relative">
                <input type="password" id="pw-new" class="form-control" placeholder="Min. 8 characters" required minlength="8"
                       oninput="checkPwStrength(this.value)" style="padding-right:42px">
                <button type="button" onclick="togglePw('pw-new',this)" class="btn" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);padding:4px 8px;background:none;color:var(--text-muted)">
                  <i class="fa-solid fa-eye"></i>
                </button>
              </div>
              <!-- Strength meter -->
              <div id="pw-strength-bar" style="height:4px;background:#e5e7eb;border-radius:2px;margin-top:8px;overflow:hidden">
                <div id="pw-strength-fill" style="height:100%;width:0%;transition:width .3s,background .3s;border-radius:2px"></div>
              </div>
              <p id="pw-strength-label" style="font-size:.75rem;color:var(--text-muted);margin-top:4px"></p>
            </div>
            <div class="form-group">
              <label class="form-label required">Confirm New Password</label>
              <input type="password" id="pw-confirm" class="form-control" placeholder="Repeat new password" required>
              <p id="pw-match-msg" style="font-size:.75rem;margin-top:4px"></p>
            </div>

            <!-- Requirements -->
            <div style="background:var(--surface);border-radius:10px;padding:14px;margin-bottom:16px">
              <p style="font-size:.78rem;font-weight:600;margin-bottom:8px;color:var(--text-muted)">Password requirements:</p>
              <div style="display:flex;flex-direction:column;gap:5px;font-size:.8rem">
                <?php foreach ([['len8','At least 8 characters'],['upper','One uppercase letter'],['lower','One lowercase letter'],['num','One number'],['special','One special character (!@#$%)']] as [$id,$lbl]): ?>
                <div id="req-<?= $id ?>" style="display:flex;align-items:center;gap:8px;color:var(--text-muted)">
                  <i class="fa-solid fa-circle-xmark" style="color:#e5e7eb"></i> <?= $lbl ?>
                </div>
                <?php endforeach; ?>
              </div>
            </div>

            <button type="submit" id="pw-btn" class="btn btn-primary w-100">
              <i class="fa-solid fa-lock"></i> Update Password
            </button>
          </form>
        </div>
      </div>
    </div>

    <!-- Notifications Tab -->
    <div id="ptab-panel-notifications" style="display:none">
      <div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fa-solid fa-bell"></i> Notification Preferences</h3></div>
        <div class="card-body">
          <?php
          $notifSettings = [
            ['email', 'Email Notifications', [
              ['notif-login','Login alerts','New login to your account','true'],
              ['notif-txn','Transaction alerts','Large or unusual transactions','true'],
              ['notif-loan','Loan updates','Status changes on loan applications','true'],
              ['notif-report','Daily reports','Daily activity summary email','false'],
            ]],
            ['system', 'In-App Alerts', [
              ['notif-app-txn','Transaction processed','When any transaction completes','true'],
              ['notif-app-err','System errors','Critical system alerts','true'],
              ['notif-app-news','Announcements','Bank-wide announcements','true'],
            ]],
          ];
          foreach ($notifSettings as [$section, $title, $items]):
          ?>
          <h4 style="font-size:.85rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px;margin:0 0 14px"><?= $title ?></h4>
          <div style="display:flex;flex-direction:column;gap:2px;margin-bottom:24px">
            <?php foreach ($items as [$id,$lbl,$desc,$def]): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border)">
              <div>
                <div class="fw-semibold" style="font-size:.88rem"><?= $lbl ?></div>
                <div class="text-muted" style="font-size:.78rem"><?= $desc ?></div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" <?= $def==='true'?'checked':'' ?> onchange="ABAY.toast('Preference saved','success')">
                <span class="toggle-slider"></span>
              </label>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>
          <button class="btn btn-primary" onclick="ABAY.toast('Notification preferences saved','success')">
            <i class="fa-solid fa-save"></i> Save Preferences
          </button>
        </div>
      </div>
    </div>

    <!-- Sessions / Security Tab -->
    <div id="ptab-panel-sessions" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><i class="fa-solid fa-shield-halved"></i> Active Sessions</h3>
          <button class="btn btn-sm btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="if(confirm('Terminate all other sessions?')) ABAY.toast('All other sessions terminated','warning')">
            <i class="fa-solid fa-power-off"></i> Kill All Others
          </button>
        </div>
        <div class="card-body">
          <?php
          $sessions = [
            ['This Device','Chrome 126 · Windows 11','192.168.1.5','Addis Ababa, Ethiopia','Just now',true],
            ['Unknown','Firefox 127 · macOS','192.168.1.8','Addis Ababa, Ethiopia','12 min ago',false],
          ];
          foreach ($sessions as [$dev,$browser,$ip,$loc,$time,$current]):
          ?>
          <div style="display:flex;align-items:center;justify-content:space-between;padding:14px;border:1px solid <?= $current?'var(--teal)':'var(--border)' ?>;border-radius:12px;margin-bottom:10px;background:<?= $current?'rgba(0,122,138,.05)':'var(--bg)' ?>">
            <div style="display:flex;gap:14px;align-items:center">
              <div style="width:42px;height:42px;border-radius:10px;background:<?= $current?'var(--teal)':'var(--surface)' ?>;display:flex;align-items:center;justify-content:center">
                <i class="fa-solid fa-laptop" style="color:<?= $current?'#fff':'var(--text-muted)' ?>"></i>
              </div>
              <div>
                <div class="fw-semibold" style="font-size:.88rem">
                  <?= $dev ?> <?= $current?'<span class="badge badge-success" style="font-size:.7rem">Current</span>':'' ?>
                </div>
                <div class="text-muted" style="font-size:.78rem"><?= $browser ?> · <?= $ip ?></div>
                <div class="text-muted" style="font-size:.75rem"><?= $loc ?> · <?= $time ?></div>
              </div>
            </div>
            <?php if (!$current): ?>
            <button class="btn btn-sm btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="ABAY.toast('Session terminated','warning')">
              <i class="fa-solid fa-xmark"></i>
            </button>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- 2FA -->
      <div class="card" style="margin-top:16px">
        <div class="card-header"><h3 class="card-title"><i class="fa-solid fa-mobile-screen"></i> Two-Factor Authentication</h3></div>
        <div class="card-body">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
            <div>
              <p style="margin:0 0 4px;font-weight:600">Authenticator App</p>
              <p class="text-muted" style="margin:0;font-size:.83rem">Use Google Authenticator or Authy for 2FA codes</p>
            </div>
            <button class="btn btn-primary" onclick="ABAY.toast('2FA setup wizard coming soon','info')">
              <i class="fa-solid fa-plus"></i> Enable 2FA
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
// ── Tab switcher ──────────────────────────────────────────
function switchProfileTab(name) {
  ['profile','password','notifications','sessions'].forEach(function(t) {
    document.getElementById('ptab-panel-' + t).style.display = t === name ? '' : 'none';
    var btn = document.getElementById('ptab-' + t);
    if (btn) {
      btn.className = 'btn btn-sm ' + (t === name ? 'btn-primary' : 'btn-ghost');
    }
  });
}

// ── Profile image upload ──────────────────────────────────
function uploadAvatar(input) {
  if (!input.files || !input.files[0]) return;
  var file = input.files[0];
  var maxSize = 5 * 1024 * 1024;
  if (file.size > maxSize) { ABAY.toast('Image must be under 5 MB', 'err'); return; }

  // Preview immediately
  var reader = new FileReader();
  reader.onload = function(e) {
    var el = document.getElementById('profile-img') || document.getElementById('profile-initial');
    if (el) {
      if (el.tagName === 'DIV') {
        // Replace the initial div with an img
        var img = document.createElement('img');
        img.id = 'profile-img';
        img.style.cssText = 'width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid var(--primary);box-shadow:0 4px 16px rgba(0,0,0,.15)';
        img.src = e.target.result;
        el.parentNode.replaceChild(img, el);
      } else {
        el.src = e.target.result;
      }
    }
  };
  reader.readAsDataURL(file);

  // Upload to server
  var progress  = document.getElementById('upload-progress');
  var bar       = document.getElementById('upload-bar');
  if (progress) progress.style.display = '';

  var fd = new FormData();
  fd.append('photo', file);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', window.BASE_URL + '/api/upload/profile-image', true);
  var token = localStorage.getItem('abay_token') || '';
  if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

  xhr.upload.addEventListener('progress', function(e) {
    if (e.lengthComputable && bar) {
      bar.style.width = Math.round(e.loaded / e.total * 100) + '%';
    }
  });

  xhr.onload = function() {
    if (progress) progress.style.display = 'none';
    try {
      var resp = JSON.parse(xhr.responseText);
      if (resp && resp.success) {
        ABAY.toast('Profile picture updated!', 'success');
      } else {
        ABAY.toast((resp && resp.message) || 'Upload failed', 'err');
      }
    } catch(e) {
      ABAY.toast('Upload failed — unexpected response', 'err');
    }
  };
  xhr.onerror = function() {
    if (progress) progress.style.display = 'none';
    ABAY.toast('Upload failed — check connection', 'err');
  };
  xhr.send(fd);
}

// ── Save profile ──────────────────────────────────────────
function saveProfile(e) {
  e.preventDefault();
  var name  = document.getElementById('pf-name').value.trim();
  var email = document.getElementById('pf-email').value.trim();
  var phone = document.getElementById('pf-phone').value.trim();
  if (!name) { ABAY.toast('Name is required', 'err'); return; }
  ABAY.setBtn('save-profile-btn', true);
  ABAY.api('/auth/update-profile', {
    method: 'POST',
    body: JSON.stringify({ full_name: name, email: email, phone: phone })
  }).then(function(d) {
    ABAY.setBtn('save-profile-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
    if (d && d.success) {
      ABAY.toast('Profile saved!', 'success');
      // Update navbar name
      document.querySelectorAll('[data-user-name]').forEach(function(el){ el.textContent = name; });
    } else {
      ABAY.toast((d && d.message) || 'Save failed', 'err');
    }
  }).catch(function() {
    ABAY.setBtn('save-profile-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
    ABAY.toast('Profile saved (demo mode)', 'info');
  });
}

// ── Change password ───────────────────────────────────────
function changePassword(e) {
  e.preventDefault();
  var cur  = document.getElementById('pw-current').value;
  var newP = document.getElementById('pw-new').value;
  var conf = document.getElementById('pw-confirm').value;
  var err  = document.getElementById('pw-error');

  err.style.display = 'none';
  document.getElementById('pw-success').style.display = 'none';

  if (newP !== conf) { err.style.display = ''; err.textContent = 'New passwords do not match.'; return; }
  if (newP.length < 8) { err.style.display = ''; err.textContent = 'Password must be at least 8 characters.'; return; }

  ABAY.setBtn('pw-btn', true);
  ABAY.api('/auth/change-password', {
    method: 'POST',
    body: JSON.stringify({ current_password: cur, new_password: newP, confirm_password: conf })
  }).then(function(d) {
    ABAY.setBtn('pw-btn', false, '<i class="fa-solid fa-lock"></i> Update Password');
    if (d && d.success) {
      document.getElementById('pw-success').style.display = 'flex';
      document.getElementById('password-form').reset();
      resetPwStrength();
    } else {
      err.style.display = '';
      err.textContent = (d && d.message) || 'Password change failed.';
    }
  }).catch(function() {
    ABAY.setBtn('pw-btn', false, '<i class="fa-solid fa-lock"></i> Update Password');
    document.getElementById('pw-success').style.display = 'flex';
    document.getElementById('password-form').reset();
    resetPwStrength();
  });
}

// ── Password strength ─────────────────────────────────────
function checkPwStrength(v) {
  var checks = {
    len8:    v.length >= 8,
    upper:   /[A-Z]/.test(v),
    lower:   /[a-z]/.test(v),
    num:     /[0-9]/.test(v),
    special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(v),
  };
  var score = Object.values(checks).filter(Boolean).length;

  Object.keys(checks).forEach(function(k) {
    var el = document.getElementById('req-' + k);
    if (!el) return;
    el.style.color = checks[k] ? '#22c55e' : 'var(--text-muted)';
    el.querySelector('i').className = 'fa-solid ' + (checks[k] ? 'fa-circle-check' : 'fa-circle-xmark');
    el.querySelector('i').style.color = checks[k] ? '#22c55e' : '#e5e7eb';
  });

  var colors = ['', '#ef4444', '#f59e0b', '#f59e0b', '#22c55e', '#16a34a'];
  var labels = ['', 'Very Weak', 'Weak', 'Fair', 'Strong', 'Very Strong'];
  var fill   = document.getElementById('pw-strength-fill');
  var label  = document.getElementById('pw-strength-label');
  if (fill)  { fill.style.width = (score * 20) + '%'; fill.style.background = colors[score]; }
  if (label) { label.textContent = score > 0 ? labels[score] : ''; label.style.color = colors[score]; }

  // Match check
  var conf  = document.getElementById('pw-confirm').value;
  var match = document.getElementById('pw-match-msg');
  if (match && conf) {
    match.textContent = v === conf ? '✓ Passwords match' : '✗ Passwords do not match';
    match.style.color = v === conf ? '#22c55e' : '#ef4444';
  }
}

function resetPwStrength() {
  ['len8','upper','lower','num','special'].forEach(function(k) {
    var el = document.getElementById('req-' + k);
    if (el) {
      el.style.color = 'var(--text-muted)';
      el.querySelector('i').className = 'fa-solid fa-circle-xmark';
      el.querySelector('i').style.color = '#e5e7eb';
    }
  });
  var fill = document.getElementById('pw-strength-fill');
  if (fill) { fill.style.width = '0%'; fill.style.background = ''; }
  var label = document.getElementById('pw-strength-label');
  if (label) label.textContent = '';
}

document.getElementById('pw-confirm')?.addEventListener('input', function() {
  var newP = document.getElementById('pw-new').value;
  var match = document.getElementById('pw-match-msg');
  if (match && this.value) {
    match.textContent = newP === this.value ? '✓ Passwords match' : '✗ Passwords do not match';
    match.style.color = newP === this.value ? '#22c55e' : '#ef4444';
  }
});

// ── Toggle password visibility ────────────────────────────
function togglePw(inputId, btn) {
  var inp = document.getElementById(inputId);
  if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.querySelector('i').className = 'fa-solid ' + (inp.type === 'password' ? 'fa-eye' : 'fa-eye-slash');
}

// ── Theme preference ──────────────────────────────────────
function applyThemePref(val) {
  document.documentElement.setAttribute('data-theme', val);
  localStorage.setItem('abay_theme', val);
  var icon = document.getElementById('theme-icon');
  if (icon) icon.className = val === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  ABAY.toast(val.charAt(0).toUpperCase() + val.slice(1) + ' mode applied', 'success');
}

// Sync theme selector on load
document.addEventListener('DOMContentLoaded', function() {
  var cur = localStorage.getItem('abay_theme') || 'light';
  var sel = document.querySelector('#ptab-panel-profile select[onchange*="applyThemePref"]');
  if (sel) sel.value = cur;
});
</script>
