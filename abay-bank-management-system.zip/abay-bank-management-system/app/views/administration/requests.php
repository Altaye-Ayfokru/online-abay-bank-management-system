<?php
/** @var array $pendingLoans @var array $pendingAppointments @var array $pendingLeave @var array $pendingKYC @var array $openComplaints */
$totalPending = count($pendingLoans) + count($pendingAppointments) + count($pendingLeave) + count($pendingKYC) + count($openComplaints);
$e = fn($v) => htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
$ago = function($dt) {
    try {
        $diff = time() - (new DateTime($dt))->getTimestamp();
        if ($diff < 60)    return 'Just now';
        if ($diff < 3600)  return round($diff/60).'m ago';
        if ($diff < 86400) return round($diff/3600).'h ago';
        return (new DateTime($dt))->format('d M Y');
    } catch (\Throwable) { return $dt ?? ''; }
};
?>
<div class="page-header">
  <div>
    <h1 class="page-title">
      <i class="fa-solid fa-inbox" style="color:#ef4444"></i> Pending Requests
      <?php if ($totalPending > 0): ?>
        <span style="background:#ef4444;color:#fff;font-size:.65rem;padding:2px 10px;border-radius:99px;font-weight:700;vertical-align:middle;margin-left:8px"><?= $totalPending ?> pending</span>
      <?php endif; ?>
    </h1>
    <p class="page-subtitle">All pending requests from Customer Portal and Employee Portal — approve or reject from one place</p>
  </div>
  <div class="page-actions">
    <a href="<?= APP_URL ?>/dashboard" class="btn btn-outline btn-sm"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
  </div>
</div>

<!-- Portal source indicators -->
<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px">
  <?php foreach ([
    ['Customer Portal', 'fa-user', '#007A8A', APP_URL.'/customer-portal/auth/login.php', count($pendingLoans)+count($pendingAppointments)+count($pendingKYC)+count($openComplaints)],
    ['Employee Portal', 'fa-id-badge', '#2d6a4f', 'http://localhost/abay-bank-management-system/employee-portal/', count($pendingLeave)],
    ['Staff Portal',    'fa-shield-halved', '#1B3A5C', APP_URL.'/dashboard', 0],
  ] as [$label, $icon, $color, $url, $cnt]): ?>
  <a href="<?= $url ?>" target="_blank" style="display:flex;align-items:center;gap:8px;background:#fff;border:1.5px solid #e2e8f0;border-radius:10px;padding:10px 16px;text-decoration:none;transition:.2s" onmouseover="this.style.borderColor='<?= $color ?>'" onmouseout="this.style.borderColor='#e2e8f0'">
    <i class="fa-solid <?= $icon ?>" style="color:<?= $color ?>;font-size:.95rem"></i>
    <span style="font-size:.84rem;font-weight:600;color:#374151"><?= $label ?></span>
    <?php if ($cnt > 0): ?><span style="background:<?= $color ?>;color:#fff;font-size:.65rem;padding:1px 7px;border-radius:99px;font-weight:700"><?= $cnt ?></span><?php endif; ?>
    <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.62rem;color:#94a3b8;margin-left:2px"></i>
  </a>
  <?php endforeach; ?>
</div>

<?php if ($totalPending === 0): ?>
<div class="card">
  <div class="card-body" style="text-align:center;padding:64px">
    <i class="fa-solid fa-check-circle" style="font-size:2.5rem;color:#10b981;display:block;margin-bottom:12px"></i>
    <div style="font-size:1.1rem;font-weight:700;color:#1e293b;margin-bottom:6px">All caught up!</div>
    <p style="color:#94a3b8;font-size:.88rem">No pending requests from any portal right now.</p>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ LOAN APPLICATIONS ══════════════════════════ -->
<?php if (!empty($pendingLoans)): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-file-invoice-dollar" style="color:#7c3aed;margin-right:7px"></i>Loan Applications
      <span style="background:#7c3aed15;color:#7c3aed;font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:700;margin-left:6px"><?= count($pendingLoans) ?> pending</span>
    </h3>
    <a href="<?= APP_URL ?>/loans/approval" class="btn btn-ghost btn-sm">Full Approval Page <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Loan No.</th><th>Customer</th><th>Type</th><th>Amount</th><th>Term</th><th>Purpose</th><th>Submitted</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($pendingLoans as $loan): ?>
        <tr>
          <td><span style="font-family:monospace;font-size:.75rem;font-weight:700;color:#7c3aed"><?= $e($loan['loan_number']??'LN-XXXX') ?></span></td>
          <td>
            <div style="font-size:.83rem;font-weight:600"><?= $e($loan['customer_name']??'—') ?></div>
            <?php if (!empty($loan['phone'])): ?><div style="font-size:.72rem;color:#94a3b8"><?= $e($loan['phone']) ?></div><?php endif; ?>
          </td>
          <td style="font-size:.81rem"><?= $e($loan['loan_type']??'—') ?></td>
          <td style="font-weight:700;font-size:.83rem">ETB <?= number_format((float)($loan['amount']??0)) ?></td>
          <td style="font-size:.81rem"><?= $e($loan['term_months']??'—') ?> mo</td>
          <td style="font-size:.78rem;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= $e($loan['purpose']??'—') ?></td>
          <td style="font-size:.75rem;color:#94a3b8"><?= $ago($loan['created_at']??'') ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <button onclick="requestAction('loans/approve','<?= (int)($loan['id']??0) ?>','loan_id','Approve loan <?= $e($loan['loan_number']??'') ?>?',this,'#10b981')" class="btn btn-sm btn-success" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-check"></i> Approve
              </button>
              <button onclick="requestReject('<?= (int)($loan['id']??0) ?>','loan')" class="btn btn-sm btn-danger" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-xmark"></i> Reject
              </button>
              <a href="<?= APP_URL ?>/loans/approval" class="btn btn-sm btn-ghost" style="font-size:.74rem;padding:4px 10px" title="Full review">
                <i class="fa-solid fa-eye"></i>
              </a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ APPOINTMENTS ════════════════════════════════ -->
<?php if (!empty($pendingAppointments)): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-calendar-days" style="color:#0d9488;margin-right:7px"></i>Appointment Requests
      <span style="background:#0d948815;color:#0d9488;font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:700;margin-left:6px"><?= count($pendingAppointments) ?> pending</span>
    </h3>
    <a href="<?= APP_URL ?>/support/appointments" class="btn btn-ghost btn-sm">All Appointments <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Customer</th><th>Branch</th><th>Date</th><th>Time</th><th>Purpose</th><th>Submitted</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($pendingAppointments as $appt): ?>
        <tr>
          <td style="font-size:.83rem;font-weight:600"><?= $e($appt['customer_name']??'—') ?></td>
          <td style="font-size:.8rem"><?= $e($appt['branch_name']??'—') ?></td>
          <td style="font-size:.8rem;font-weight:600"><?= $e($appt['appointment_date']??'—') ?></td>
          <td style="font-size:.8rem"><?= $e(substr($appt['appointment_time']??'',0,5)) ?></td>
          <td style="font-size:.78rem"><?= $e($appt['purpose']??'—') ?></td>
          <td style="font-size:.75rem;color:#94a3b8"><?= $ago($appt['created_at']??'') ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <button onclick="requestAction('appointments/confirm','<?= (int)($appt['id']??0) ?>','appointment_id','Confirm this appointment?',this,'#0d9488')" class="btn btn-sm" style="background:#0d9488;color:#fff;font-size:.74rem;padding:4px 10px;border:none;cursor:pointer;border-radius:6px">
                <i class="fa-solid fa-check"></i> Confirm
              </button>
              <button onclick="requestAction('appointments/cancel','<?= (int)($appt['id']??0) ?>','appointment_id','Cancel this appointment?',this,'#ef4444')" class="btn btn-sm btn-danger" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-xmark"></i> Cancel
              </button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ LEAVE REQUESTS ══════════════════════════════ -->
<?php if (!empty($pendingLeave)): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-calendar-xmark" style="color:#f59e0b;margin-right:7px"></i>Leave Requests
      <span style="background:#f59e0b15;color:#f59e0b;font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:700;margin-left:6px"><?= count($pendingLeave) ?> pending</span>
    </h3>
    <a href="<?= APP_URL ?>/employees/leave" class="btn btn-ghost btn-sm">All Leave <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Employee</th><th>Position</th><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Submitted</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($pendingLeave as $leave): ?>
        <tr>
          <td style="font-size:.83rem;font-weight:600"><?= $e($leave['employee_name']??$leave['name']??'—') ?></td>
          <td style="font-size:.78rem;color:#94a3b8"><?= $e($leave['position']??'—') ?></td>
          <td><span style="font-size:.75rem;background:#fef9c3;color:#92400e;padding:2px 8px;border-radius:6px;font-weight:600"><?= $e($leave['leave_type']??'—') ?></span></td>
          <td style="font-size:.8rem"><?= $e($leave['from_date']??$leave['start_date']??'—') ?></td>
          <td style="font-size:.8rem"><?= $e($leave['to_date']??$leave['end_date']??'—') ?></td>
          <td style="font-weight:700;font-size:.82rem"><?= (int)($leave['days']??0) ?></td>
          <td style="font-size:.77rem;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?= $e($leave['reason']??'') ?>"><?= $e($leave['reason']??'—') ?></td>
          <td style="font-size:.75rem;color:#94a3b8"><?= $ago($leave['created_at']??'') ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <button onclick="requestAction('leaves/approve','<?= (int)($leave['id']??0) ?>','id','Approve leave for <?= $e($leave['employee_name']??'') ?>?',this,'#10b981')" class="btn btn-sm btn-success" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-check"></i> Approve
              </button>
              <button onclick="requestReject('<?= (int)($leave['id']??0) ?>','leave')" class="btn btn-sm btn-danger" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-xmark"></i> Reject
              </button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ KYC VERIFICATIONS ══════════════════════════ -->
<?php if (!empty($pendingKYC)): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-id-card" style="color:#3b82f6;margin-right:7px"></i>KYC Verifications
      <span style="background:#3b82f615;color:#3b82f6;font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:700;margin-left:6px"><?= count($pendingKYC) ?> pending</span>
    </h3>
    <a href="<?= APP_URL ?>/customers/kyc" class="btn btn-ghost btn-sm">KYC Management <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Customer</th><th>Customer No.</th><th>Phone</th><th>KYC Status</th><th>Registered</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($pendingKYC as $kyc): ?>
        <tr>
          <td style="font-size:.83rem;font-weight:600"><?= $e($kyc['customer_name']??'—') ?></td>
          <td><span style="font-family:monospace;font-size:.75rem;color:#475569"><?= $e($kyc['customer_number']??'—') ?></span></td>
          <td style="font-size:.8rem"><?= $e($kyc['phone']??'—') ?></td>
          <td>
            <span style="font-size:.74rem;font-weight:700;padding:2px 9px;border-radius:99px;background:<?= ($kyc['kyc_status']??'') === 'Under_Review' ? '#fef9c3' : '#dbeafe' ?>;color:<?= ($kyc['kyc_status']??'') === 'Under_Review' ? '#92400e' : '#1d4ed8' ?>">
              <?= $e($kyc['kyc_status']??'Pending') ?>
            </span>
          </td>
          <td style="font-size:.75rem;color:#94a3b8"><?= $ago($kyc['created_at']??'') ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <button onclick="requestAction('kyc/verify','<?= (int)($kyc['id']??0) ?>','customer_id','Verify KYC for <?= $e($kyc['customer_name']??'') ?>?',this,'#10b981')" class="btn btn-sm btn-success" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-check"></i> Verify
              </button>
              <a href="<?= APP_URL ?>/customers/kyc" class="btn btn-sm btn-ghost" style="font-size:.74rem;padding:4px 10px">
                <i class="fa-solid fa-eye"></i> Review
              </a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ══════════════ OPEN COMPLAINTS ═════════════════════════════ -->
<?php if (!empty($openComplaints)): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-headset" style="color:#ef4444;margin-right:7px"></i>Open Complaints
      <span style="background:#ef444415;color:#ef4444;font-size:.7rem;padding:2px 8px;border-radius:99px;font-weight:700;margin-left:6px"><?= count($openComplaints) ?> open</span>
    </h3>
    <a href="<?= APP_URL ?>/support/complaints" class="btn btn-ghost btn-sm">All Complaints <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Ticket</th><th>Customer</th><th>Category</th><th>Subject</th><th>Priority</th><th>Submitted</th><th>Actions</th></tr></thead>
      <tbody>
      <?php
      $prioColors = ['Urgent'=>'#ef4444','High'=>'#f97316','Medium'=>'#f59e0b','Low'=>'#22c55e'];
      foreach ($openComplaints as $comp): ?>
        <tr>
          <td><span style="font-family:monospace;font-size:.75rem;font-weight:700;color:#ef4444"><?= $e($comp['ticket_no']??'CMP-XXXX') ?></span></td>
          <td style="font-size:.83rem;font-weight:600"><?= $e($comp['customer_name']??'—') ?></td>
          <td style="font-size:.78rem"><?= $e($comp['category']??'—') ?></td>
          <td style="font-size:.78rem;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= $e($comp['subject']??'—') ?></td>
          <td>
            <?php $pc = $prioColors[$comp['priority']??'Medium'] ?? '#94a3b8'; ?>
            <span style="font-size:.72rem;font-weight:700;color:<?= $pc ?>;background:<?= $pc ?>15;padding:2px 8px;border-radius:99px"><?= $e($comp['priority']??'—') ?></span>
          </td>
          <td style="font-size:.75rem;color:#94a3b8"><?= $ago($comp['created_at']??'') ?></td>
          <td>
            <a href="<?= APP_URL ?>/support/complaints" class="btn btn-sm btn-ghost" style="font-size:.74rem;padding:4px 10px">
              <i class="fa-solid fa-reply"></i> Respond
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
/* ── One-click request action ── */
function requestAction(endpoint, id, idKey, confirmMsg, btn, color) {
  if (!confirm(confirmMsg)) return;
  btn.disabled = true;
  var origHtml = btn.innerHTML;
  btn.innerHTML = '<span class="spinner" style="width:12px;height:12px;border:2px solid rgba(255,255,255,.35);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite;display:inline-block;vertical-align:middle"></span>';

  var body = {}; body[idKey] = parseInt(id);
  (window.ABAY ? ABAY.api : apiFallback)('/api/' + endpoint, {
    method: 'POST', body: JSON.stringify(body)
  }).then(function(d) {
    if (d && d.success) {
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Done';
      btn.style.background = color || '#10b981';
      ABAY && ABAY.toast(d.message || 'Action completed', 'ok');
      // Fade out the row
      var row = btn.closest('tr');
      if (row) {
        row.style.transition = 'opacity .5s';
        row.style.opacity = '0';
        setTimeout(function() { row.remove(); }, 600);
      }
    } else {
      btn.disabled = false;
      btn.innerHTML = origHtml;
      ABAY && ABAY.toast((d && d.message) || 'Action failed', 'err');
    }
  }).catch(function() {
    btn.disabled = false;
    btn.innerHTML = origHtml;
    ABAY && ABAY.toast('Demo: Action recorded (DB offline).', 'info');
    var row = btn.closest('tr');
    if (row) { row.style.opacity = '0.4'; }
  });
}

function requestReject(id, type) {
  var reason = prompt('Reason for rejection (required):');
  if (!reason) return;
  var endpoint = type === 'loan' ? 'loans/reject' : 'leaves/reject';
  var idKey    = type === 'loan' ? 'loan_id' : 'id';
  var body = { reason: reason }; body[idKey] = parseInt(id);
  (window.ABAY ? ABAY.api : apiFallback)('/api/' + endpoint, { method:'POST', body:JSON.stringify(body) })
    .then(function(d) {
      ABAY && ABAY.toast(d && d.message || 'Rejected', 'ok');
      location.reload();
    }).catch(function() {
      ABAY && ABAY.toast('Demo: Rejected (DB offline).', 'info');
      location.reload();
    });
}

function apiFallback(path, opts) {
  return fetch(window.BASE_URL ? window.BASE_URL + path : path, Object.assign({
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest',
                'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '') }
  }, opts || {})).then(function(r) { return r.json(); });
}
</script>
