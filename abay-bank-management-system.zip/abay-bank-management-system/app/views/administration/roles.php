﻿<?php

/** @var array $roles @var array $user */
$demoRoles = $roles ?: [
  ['id' => 1, 'role_name' => 'Admin', 'user_count' => 3, 'description' => 'Full system access', 'color' => '#ef4444', 'permissions' => ['all']],
  ['id' => 2, 'role_name' => 'Manager', 'user_count' => 8, 'description' => 'Branch management access', 'color' => '#f59e0b', 'permissions' => ['customers', 'accounts', 'loans', 'reports', 'employees']],
  ['id' => 3, 'role_name' => 'Teller', 'user_count' => 45, 'description' => 'Transaction processing', 'color' => '#3b82f6', 'permissions' => ['customers', 'accounts', 'transactions']],
  ['id' => 4, 'role_name' => 'Loan Officer', 'user_count' => 12, 'description' => 'Loan management access', 'color' => '#22c55e', 'permissions' => ['customers', 'loans']],
  ['id' => 5, 'role_name' => 'HR Officer', 'user_count' => 4, 'description' => 'Human resource management', 'color' => '#6366f1', 'permissions' => ['employees', 'attendance', 'payroll', 'recruitment']],
  ['id' => 6, 'role_name' => 'Auditor', 'user_count' => 2, 'description' => 'Read-only audit access', 'color' => '#10b981', 'permissions' => ['reports', 'audit', 'documents']],
];
$allPerms = ['customers', 'accounts', 'transactions', 'loans', 'employees', 'attendance', 'payroll', 'recruitment', 'branches', 'reports', 'administration', 'audit', 'documents', 'backup', 'settings'];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-user-shield" style="color:var(--primary)"></i> Roles & Permissions</h1>
    <p class="page-subtitle">Manage system roles and their access permissions</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-primary" onclick="document.getElementById('add-role-modal').classList.add('active')">
      <i class="fa-solid fa-plus"></i> Add Role
    </button>
  </div>
</div>

<!-- Roles Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px;margin-bottom:24px">
  <?php foreach ($demoRoles as $role): ?>
    <div class="card" style="border-left:4px solid <?= $role['color'] ?>">
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <div>
            <h4 style="margin:0 0 4px;font-size:1rem"><?= htmlspecialchars($role['role_name']) ?></h4>
            <p class="text-muted" style="margin:0;font-size:.83rem"><?= htmlspecialchars($role['description']) ?></p>
          </div>
          <span style="background:<?= $role['color'] ?>20;color:<?= $role['color'] ?>;padding:4px 12px;border-radius:20px;font-weight:600;font-size:.82rem;white-space:nowrap">
            <?= $role['user_count'] ?> users
          </span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px">
          <?php if (in_array('all', $role['permissions'])): ?>
            <span class="badge badge-danger">All Permissions</span>
            <?php else: foreach ($role['permissions'] as $perm): ?>
              <span class="badge badge-secondary" style="font-size:.75rem;text-transform:capitalize"><?= htmlspecialchars($perm) ?></span>
          <?php endforeach;
          endif; ?>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm btn-outline" style="flex:1" onclick="editRole(<?= $role['id'] ?>, '<?= addslashes($role['role_name']) ?>')">
            <i class="fa-solid fa-pen"></i> Edit
          </button>
          <?php if ($role['role_name'] !== 'Admin'): ?>
            <button class="btn btn-sm btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="deleteRole(<?= $role['id'] ?>, '<?= addslashes($role['role_name']) ?>')">
              <i class="fa-solid fa-trash"></i>
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Permission Matrix -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-table"></i> Permission Matrix</h3>
  </div>
  <div class="card-body p-0">
    <div style="overflow-x:auto">
      <table class="data-table" style="white-space:nowrap;min-width:600px">
        <thead>
          <tr>
            <th style="position:sticky;left:0;background:var(--surface);z-index:1">Permission</th>
            <?php foreach ($demoRoles as $r): ?>
              <th style="text-align:center"><?= htmlspecialchars($r['role_name']) ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($allPerms as $perm): ?>
            <tr>
              <td style="position:sticky;left:0;background:var(--surface);font-weight:500;text-transform:capitalize"><?= $perm ?></td>
              <?php foreach ($demoRoles as $r):
                $has = in_array('all', $r['permissions']) || in_array($perm, $r['permissions']);
              ?>
                <td style="text-align:center">
                  <?php if ($has): ?>
                    <i class="fa-solid fa-circle-check" style="color:#22c55e;font-size:1rem"></i>
                  <?php else: ?>
                    <i class="fa-solid fa-circle-xmark" style="color:#e5e7eb;font-size:1rem"></i>
                  <?php endif; ?>
                </td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Role Modal -->
<div class="modal-overlay" id="add-role-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <h3 class="modal-title" id="role-modal-title"><i class="fa-solid fa-plus"></i> Add New Role</h3>
      <button class="modal-close" onclick="document.getElementById('add-role-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="saveRole(event)">
        <div class="form-group">
          <label class="form-label required">Role Name</label>
          <input type="text" id="role-name-input" class="form-control" placeholder="e.g. Branch Manager" required>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <input type="text" class="form-control" placeholder="Brief role description">
        </div>
        <div class="form-group">
          <label class="form-label">Permissions</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <?php foreach ($allPerms as $perm): ?>
              <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:6px;border:1px solid var(--border);border-radius:6px">
                <input type="checkbox" name="perms[]" value="<?= $perm ?>" style="width:16px;height:16px">
                <span style="text-transform:capitalize;font-size:.85rem"><?= $perm ?></span>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('add-role-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Role</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function editRole(id, name) {
    document.getElementById('role-modal-title').innerHTML = '<i class="fa-solid fa-pen"></i> Edit Role: ' + name;
    document.getElementById('role-name-input').value = name;
    document.getElementById('add-role-modal').classList.add('active');
  }

  function deleteRole(id, name) {
    if (confirm('Delete role "' + name + '"? Users with this role will need reassignment.')) {
      ABAY.toast('Role "' + name + '" deleted', 'warning');
    }
  }

  function saveRole(e) {
    e.preventDefault();
    document.getElementById('add-role-modal').classList.remove('active');
    ABAY.toast('Role saved successfully!', 'success');
  }
</script>