﻿<?php

/** @var array $sessions @var array $attempts @var array $user */
$demoSessions = $sessions ?: [
  ['username' => 'admin', 'ip' => '192.168.1.5', 'last_activity' => date('Y-m-d H:i:s', time() - 120), 'browser' => 'Chrome 126', 'os' => 'Windows 11', 'location' => 'Addis Ababa'],
  ['username' => 'manager_tigist', 'ip' => '192.168.1.8', 'last_activity' => date('Y-m-d H:i:s', time() - 480), 'browser' => 'Firefox 127', 'os' => 'macOS', 'location' => 'Addis Ababa'],
  ['username' => 'teller_abebe', 'ip' => '192.168.1.12', 'last_activity' => date('Y-m-d H:i:s', time() - 900), 'browser' => 'Chrome 126', 'os' => 'Windows 10', 'location' => 'Bole Branch'],
];
$demoAttempts = $attempts ?: [
  ['username' => 'teller_samuel', 'ip' => '41.89.12.5', 'created_at' => date('Y-m-d H:i:s', time() - 1200), 'status' => 'Failed', 'reason' => 'Wrong password'],
  ['username' => 'admin', 'ip' => '103.45.67.89', 'created_at' => date('Y-m-d H:i:s', time() - 2400), 'status' => 'Blocked', 'reason' => 'Too many attempts - IP blocked'],
  ['username' => 'unknown', 'ip' => '185.234.12.1', 'created_at' => date('Y-m-d H:i:s', time() - 3600), 'status' => 'Failed', 'reason' => 'User not found'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-shield-halved" style="color:var(--primary)"></i> Security Center</h1>
    <p class="page-subtitle">Monitor active sessions, login attempts, and security settings</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="if(confirm('Force logout ALL other sessions?')) ABAY.toast('All sessions terminated','warning')">
      <i class="fa-solid fa-power-off"></i> Kill All Sessions
    </button>
  </div>
</div>

<!-- Security Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoSessions), 'Active Sessions', 'fa-users', '#22c55e'],
    [count($demoAttempts), 'Failed Logins (24h)', 'fa-lock', '#f59e0b'],
    ['2', 'IPs Blocked', 'fa-ban', '#ef4444'],
    ['TLS 1.3', 'Encryption', 'fa-shield-halved', '#3b82f6'],
    ['99.9%', 'Uptime', 'fa-circle-dot', '#10b981'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Active Sessions -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-users" style="color:#22c55e"></i> Active Sessions</h3>
    <span class="badge badge-success"><?= count($demoSessions) ?> online</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>User</th>
            <th>IP Address</th>
            <th>Browser / OS</th>
            <th>Location</th>
            <th>Last Active</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoSessions as $s): ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div style="width:10px;height:10px;background:#22c55e;border-radius:50%;margin-right:8px"></div>
                  <span class="fw-semibold"><?= htmlspecialchars($s['username']) ?></span>
                </div>
              </td>
              <td class="text-muted" style="font-family:monospace;font-size:.85rem"><?= htmlspecialchars($s['ip']) ?></td>
              <td style="font-size:.83rem"><?= htmlspecialchars($s['browser']) ?> · <?= htmlspecialchars($s['os']) ?></td>
              <td><?= htmlspecialchars($s['location']) ?></td>
              <td class="text-muted" style="font-size:.82rem"><?= $s['last_activity'] ?></td>
              <td>
                <button class="btn btn-sm btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="ABAY.toast('Session terminated','warning')">
                  <i class="fa-solid fa-power-off"></i> Terminate
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Failed Login Attempts -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-lock" style="color:#f59e0b"></i> Recent Login Attempts</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Username</th>
            <th>IP Address</th>
            <th>Time</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoAttempts as $a):
            $sc = $a['status'] === 'Blocked' ? 'badge-danger' : 'badge-warning';
          ?>
            <tr>
              <td class="fw-semibold"><?= htmlspecialchars($a['username']) ?></td>
              <td class="text-muted" style="font-family:monospace;font-size:.85rem"><?= htmlspecialchars($a['ip']) ?></td>
              <td class="text-muted" style="font-size:.82rem"><?= $a['created_at'] ?></td>
              <td style="font-size:.83rem"><?= htmlspecialchars($a['reason']) ?></td>
              <td><span class="badge <?= $sc ?>"><?= $a['status'] ?></span></td>
              <td>
                <button class="btn btn-sm btn-outline" onclick="ABAY.toast('IP <?= addslashes($a['ip']) ?> blocked','warning')">
                  <i class="fa-solid fa-ban"></i> Block IP
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Security Settings -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-sliders"></i> Security Settings</h3>
  </div>
  <div class="card-body">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px">
      <?php
      $settings = [
        ['Two-Factor Authentication', 'Require 2FA for all admin logins', 'fa-mobile-screen', true, '2fa'],
        ['Password Expiry', 'Force password change every 90 days', 'fa-key', true, 'pw-expiry'],
        ['IP Whitelist', 'Restrict admin access to whitelisted IPs only', 'fa-network-wired', false, 'ip-whitelist'],
        ['Session Timeout', 'Auto-logout after 30 minutes inactivity', 'fa-clock', true, 'session-timeout'],
        ['Login Attempt Limit', 'Block IP after 5 failed attempts', 'fa-lock', true, 'attempt-limit'],
        ['Audit Logging', 'Record all system activities', 'fa-file-shield', true, 'audit-log'],
      ];
      foreach ($settings as [$name, $desc, $icon, $enabled, $key]): ?>
        <div style="display:flex;justify-content:space-between;align-items:flex-start;padding:16px;border:1px solid var(--border);border-radius:10px">
          <div style="display:flex;gap:12px;align-items:flex-start">
            <div style="width:40px;height:40px;background:var(--primary-light);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fa-solid <?= $icon ?>" style="color:var(--primary)"></i>
            </div>
            <div>
              <div class="fw-semibold" style="margin-bottom:2px"><?= $name ?></div>
              <div class="text-muted" style="font-size:.82rem"><?= $desc ?></div>
            </div>
          </div>
          <label class="toggle-switch" style="flex-shrink:0;margin-left:12px">
            <input type="checkbox" <?= $enabled ? 'checked' : '' ?> onchange="ABAY.toast('<?= addslashes($name) ?> ' + (this.checked ? 'enabled' : 'disabled'), this.checked ? 'success' : 'warning')">
            <span class="toggle-slider"></span>
          </label>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>