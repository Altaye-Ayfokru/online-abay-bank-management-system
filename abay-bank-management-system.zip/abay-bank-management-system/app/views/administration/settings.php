﻿<?php $pageTitle = 'System Settings — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-sliders" style="color:#1B3A5C;margin-right:8px"></i>System Settings</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Settings</span>
    </div>
  </div>
  <div id="settings-save-indicator" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;color:#065f46;padding:7px 16px;border-radius:8px;font-size:.84rem;font-weight:600;display:none;align-items:center;gap:7px">
    <i class="fa-solid fa-circle-check"></i> Settings saved
  </div>
</div>

<div style="display:grid;grid-template-columns:220px 1fr;gap:20px;align-items:start">
  <!-- Settings Nav -->
  <div class="card" style="position:sticky;top:80px">
    <div style="padding:8px 0">
      <?php
      $navItems = [
        ['bank',      'fa-building-columns', 'Bank Information'],
        ['interest',  'fa-percent',         'Interest Rates'],
        ['transfer',  'fa-right-left',      'Transfer Settings'],
        ['currency',  'fa-coins',           'Currency & FX'],
        ['limits',    'fa-shield-halved',   'Transaction Limits'],
        ['email',     'fa-envelope',        'Email Config'],
        ['sms',       'fa-message',         'SMS & Alerts'],
        ['security',  'fa-lock',            'Security'],
        ['appearance', 'fa-palette',         'Appearance'],
      ];
      foreach ($navItems as $i => [$id, $ic, $label]): ?>
        <button onclick="showSection('<?= $id ?>')" id="nav-<?= $id ?>" class="settings-nav-btn"
          style="display:flex;align-items:center;gap:12px;width:100%;padding:11px 18px;background:<?= $i === 0 ? 'rgba(27,58,92,.07)' : 'none' ?>;border:none;border-left:3px solid <?= $i === 0 ? 'var(--primary)' : 'transparent' ?>;cursor:pointer;font-size:.84rem;font-weight:<?= $i === 0 ? '600' : '500' ?>;color:<?= $i === 0 ? 'var(--primary)' : 'var(--text-secondary)' ?>;text-align:left;font-family:inherit;transition:all .2s">
          <i class="fa-solid <?= $ic ?>" style="width:16px;text-align:center"></i><?= $label ?>
        </button>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Settings Panels -->
  <div>

    <!-- ── BANK INFORMATION ── -->
    <div id="section-bank" class="settings-section">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-building-columns" style="color:#1B3A5C;margin-right:7px"></i>Bank Information</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Bank Name</label><input type="text" class="form-control" value="Abay Bank S.C." id="bank-name"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Short Name</label><input type="text" class="form-control" value="Abay Bank" id="bank-short"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">License Number</label><input type="text" class="form-control" value="NBE/LIC/2010/001"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">SWIFT Code</label><input type="text" class="form-control" value="ABYAETAA"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Head Office Address</label><input type="text" class="form-control" value="Bole Road, Addis Ababa, Ethiopia"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Main Phone</label><input type="tel" class="form-control" value="+251-11-570-0588"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Official Email</label><input type="email" class="form-control" value="info@abaybank.com.et"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Website URL</label><input type="url" class="form-control" value="https://www.abaybank.com.et"></div>
          </div>
          <div style="margin-bottom:20px"><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Bank Logo</label>
            <div style="border:2px dashed #e2e8f0;border-radius:10px;padding:20px;text-align:center;cursor:pointer" onclick="this.querySelector('input').click()">
              <input type="file" accept="image/*" style="display:none">
              <i class="fa-solid fa-image" style="font-size:1.5rem;color:#94a3b8;margin-bottom:8px;display:block"></i>
              <div style="font-size:.84rem;font-weight:600;color:#475569">Upload Bank Logo</div>
              <div style="font-size:.76rem;color:#94a3b8;margin-top:4px">PNG or SVG, max 2MB</div>
            </div>
          </div>
          <button onclick="saveSettings('bank')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
        </div>
      </div>
    </div>

    <!-- ── INTEREST RATES ── -->
    <div id="section-interest" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-percent" style="color:#1B3A5C;margin-right:7px"></i>Interest Rate Configuration</h3>
        </div>
        <div class="card-body">
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-arrow-down" style="color:#059669;margin-right:5px"></i>Deposit Rates</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
              <?php foreach ([['Savings Account (% p.a.)', '3.5'], ['Fixed Deposit 3M (% p.a.)', '6.5'], ['Fixed Deposit 6M (% p.a.)', '7.5'], ['Fixed Deposit 12M (% p.a.)', '8.5'], ['Fixed Deposit 24M (% p.a.)', '9.0'], ['Fixed Deposit 36M (% p.a.)', '9.5']] as [$l, $v]): ?>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px"><?= $l ?></label>
                  <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden">
                    <input type="number" class="form-control" value="<?= $v ?>" step="0.25" style="border:none;border-radius:0">
                    <span style="padding:0 10px;background:#f1f5f9;color:#64748b;font-size:.84rem;height:42px;display:flex;align-items:center;border-left:1.5px solid #e2e8f0">%</span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-hand-holding-dollar" style="color:#ef4444;margin-right:5px"></i>Lending Rates</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
              <?php foreach ([['Personal Loan (% p.a.)', '12.0'], ['Business Loan (% p.a.)', '10.5'], ['Mortgage Loan (% p.a.)', '9.0'], ['Agricultural Loan (% p.a.)', '8.0'], ['Student Loan (% p.a.)', '7.5'], ['Emergency Loan (% p.a.)', '16.0']] as [$l, $v]): ?>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px"><?= $l ?></label>
                  <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden">
                    <input type="number" class="form-control" value="<?= $v ?>" step="0.5" style="border:none;border-radius:0">
                    <span style="padding:0 10px;background:#f1f5f9;color:#64748b;font-size:.84rem;height:42px;display:flex;align-items:center;border-left:1.5px solid #e2e8f0">%</span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <button onclick="saveSettings('interest')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Rates</button>
        </div>
      </div>
    </div>

    <!-- ── TRANSFER SETTINGS ── -->
    <div id="section-transfer" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-right-left" style="color:#1B3A5C;margin-right:7px"></i>Transfer Settings</h3>
        </div>
        <div class="card-body">
          <!-- Local Transfer -->
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-building-columns" style="color:#1d4ed8;margin-right:5px"></i>Local Transfer (ETB)</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Daily Limit (ETB)</label><input type="number" class="form-control" value="500000"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Per Transaction Limit</label><input type="number" class="form-control" value="200000"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Transfer Fee (ETB)</label><input type="number" class="form-control" value="10" step="1"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">EthSwitch Fee (ETB)</label><input type="number" class="form-control" value="15" step="1"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Minimum Transfer</label><input type="number" class="form-control" value="1"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Inter-Branch Fee</label><input type="number" class="form-control" value="10"></div>
            </div>
            <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable internal transfers</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable EthSwitch inter-bank transfers</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable Telebirr transfers</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable M-Pesa transfers</span></label>
            </div>
          </div>
          <!-- International Transfer -->
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-globe" style="color:#7c3aed;margin-right:5px"></i>International Transfer (SWIFT / Wire)</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">SWIFT Code</label><input type="text" class="form-control" value="ABYAETAA"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Correspondent Bank</label><input type="text" class="form-control" value="Standard Chartered"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Wire Fee (USD)</label><input type="number" class="form-control" value="25" step="1"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Max Wire (USD)</label><input type="number" class="form-control" value="50000"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Processing Days</label><input type="number" class="form-control" value="3" min="1" max="7"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Western Union Fee %</label><input type="number" class="form-control" value="1.5" step="0.1"></div>
            </div>
            <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable SWIFT/Wire transfers</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" checked style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable Western Union</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable Wise transfers</span></label>
              <label style="display:flex;align-items:center;gap:9px;cursor:pointer"><input type="checkbox" style="accent-color:#007A8A;width:15px;height:15px"><span style="font-size:.83rem;font-weight:500">Enable Payoneer</span></label>
            </div>
          </div>
          <button onclick="saveSettings('transfer')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Transfer Settings</button>
        </div>
      </div>
    </div>

    <!-- ── CURRENCY & FX ── -->
    <div id="section-currency" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-coins" style="color:#1B3A5C;margin-right:7px"></i>Currency & Exchange Rates</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Base Currency</label>
              <select class="form-control">
                <option selected>ETB — Ethiopian Birr</option>
                <option>USD — US Dollar</option>
                <option>EUR — Euro</option>
              </select>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Currency Symbol</label>
              <input type="text" class="form-control" value="ETB">
            </div>
          </div>
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Exchange Rates (per 1 ETB)</div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
              <?php foreach ([['USD', '0.0181'], ['EUR', '0.0167'], ['GBP', '0.0143'], ['AED', '0.0666'], ['SAR', '0.0679'], ['CNY', '0.1308'], ['CAD', '0.0245'], ['AUD', '0.0278']] as [$c, $r]): ?>
                <div><label style="display:block;font-size:.78rem;font-weight:700;color:#374151;margin-bottom:4px"><?= $c ?></label>
                  <input type="number" class="form-control" value="<?= $r ?>" step="0.0001">
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <button onclick="saveSettings('currency')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save</button>
        </div>
      </div>
    </div>

    <!-- ── TRANSACTION LIMITS ── -->
    <div id="section-limits" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-shield-halved" style="color:#1B3A5C;margin-right:7px"></i>Transaction Limits & Controls</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
            <div style="background:#f8fafc;border-radius:10px;padding:14px">
              <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Cash Deposit Limits</div>
              <div style="display:flex;flex-direction:column;gap:10px">
                <?php foreach ([['Min Deposit (ETB)', '1'], ['Max Single Deposit', '500000'], ['Daily Deposit Limit', '2000000'], ['Monthly Limit', '10000000']] as [$l, $v]): ?>
                  <div style="display:flex;justify-content:space-between;align-items:center">
                    <label style="font-size:.8rem;font-weight:500;color:#374151"><?= $l ?></label>
                    <input type="number" value="<?= $v ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:7px 10px;font-size:.84rem;width:140px;outline:none;text-align:right">
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px">
              <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Withdrawal Limits</div>
              <div style="display:flex;flex-direction:column;gap:10px">
                <?php foreach ([['Min Withdrawal (ETB)', '100'], ['ATM Daily Limit', '10000'], ['Counter Daily Limit', '500000'], ['Large Txn Threshold', '100000']] as [$l, $v]): ?>
                  <div style="display:flex;justify-content:space-between;align-items:center">
                    <label style="font-size:.8rem;font-weight:500;color:#374151"><?= $l ?></label>
                    <input type="number" value="<?= $v ?>" style="border:1.5px solid #e2e8f0;border-radius:7px;padding:7px 10px;font-size:.84rem;width:140px;outline:none;text-align:right">
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
          <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:9px;padding:12px;margin-bottom:16px;font-size:.83rem;color:#92400e;display:flex;align-items:center;gap:8px">
            <i class="fa-solid fa-triangle-exclamation"></i> Transactions above the large transaction threshold require Branch Manager approval.
          </div>
          <button onclick="saveSettings('limits')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Limits</button>
        </div>
      </div>
    </div>

    <!-- ── EMAIL CONFIG ── -->
    <div id="section-email" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-envelope" style="color:#1B3A5C;margin-right:7px"></i>Email Configuration</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Mail Driver</label>
              <select class="form-control">
                <option>SMTP</option>
                <option>Sendmail</option>
                <option>Mailgun</option>
              </select>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">SMTP Host</label>
              <input type="text" class="form-control" value="smtp.abaybank.com.et">
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Port</label><input type="number" class="form-control" value="587"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Username</label><input type="text" class="form-control" value="noreply@abaybank.com.et"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Password</label><input type="password" class="form-control" value="smtp_secret"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">From Name</label><input type="text" class="form-control" value="Abay Bank"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">From Email</label><input type="email" class="form-control" value="noreply@abaybank.com.et"></div>
          </div>
          <div style="display:flex;gap:10px">
            <button onclick="ABAY.toast('Test email sent to admin@abaybank.com.et','info')" style="padding:10px 20px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-paper-plane" style="margin-right:5px"></i>Test Connection</button>
            <button onclick="saveSettings('email')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:10px 24px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── SMS & ALERTS ── -->
    <div id="section-sms" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-message" style="color:#1B3A5C;margin-right:7px"></i>SMS & Alert Configuration</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">SMS Provider</label>
              <select class="form-control">
                <option>Africa's Talking</option>
                <option>Twilio</option>
                <option>Nexmo</option>
              </select>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Sender ID</label><input type="text" class="form-control" value="ABAYBANK"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">API Key</label><input type="password" class="form-control" value="sms_api_key"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">API Username</label><input type="text" class="form-control" value="abaybank_sms"></div>
          </div>
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">SMS Triggers</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
              <?php foreach (['Transaction Alerts' => true, 'Loan Status Updates' => true, 'Login OTP' => false, 'Account Statements' => true, 'Failed Login Alert' => true, 'Large Transaction Alert' => true, 'Loan Due Reminders' => true, 'Overdraft Alerts' => true] as $t => $checked): ?>
                <label style="display:flex;align-items:center;gap:9px;cursor:pointer">
                  <input type="checkbox" <?= $checked ? 'checked' : '' ?> style="accent-color:#007A8A;width:14px;height:14px">
                  <span style="font-size:.82rem;font-weight:500"><?= $t ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <button onclick="saveSettings('sms')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save SMS Config</button>
        </div>
      </div>
    </div>

    <!-- ── SECURITY ── -->
    <div id="section-security" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-lock" style="color:#1B3A5C;margin-right:7px"></i>Security Settings</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Session Timeout (minutes)</label><input type="number" class="form-control" value="120" min="5" max="480"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Max Login Attempts</label><input type="number" class="form-control" value="5" min="3" max="10"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Account Lockout Duration (min)</label><input type="number" class="form-control" value="15" min="5"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Password Min Length</label><input type="number" class="form-control" value="8" min="6"></div>
          </div>
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Security Policies</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
              <?php foreach (['Require uppercase letters' => true, 'Require numbers' => true, 'Require special characters' => false, 'Force 2FA for Admins' => false, 'IP Whitelist Enforcement' => false, 'Audit All API Calls' => true] as $p => $checked): ?>
                <label style="display:flex;align-items:center;gap:9px;cursor:pointer">
                  <input type="checkbox" <?= $checked ? 'checked' : '' ?> style="accent-color:#007A8A;width:14px;height:14px">
                  <span style="font-size:.82rem;font-weight:500"><?= $p ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <button onclick="saveSettings('security')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Security</button>
        </div>
      </div>
    </div>

    <!-- ── APPEARANCE ── -->
    <div id="section-appearance" class="settings-section" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-palette" style="color:#1B3A5C;margin-right:7px"></i>Appearance & Display</h3>
        </div>
        <div class="card-body">
          <div style="margin-bottom:20px">
            <div style="font-size:.79rem;font-weight:600;color:#374151;margin-bottom:10px">Color Theme</div>
            <div style="display:flex;gap:12px;flex-wrap:wrap">
              <?php foreach ([['#1B3A5C', 'Navy Blue (Default)', true], ['#0f2336', 'Dark Navy', false], ['#1a5c3a', 'Forest Green', false], ['#5b21b6', 'Royal Purple', false]] as [$clr, $lbl, $active]): ?>
                <label style="cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:6px">
                  <input type="radio" name="theme-color" <?= $active ? 'checked' : '' ?> style="display:none">
                  <div style="width:48px;height:48px;border-radius:12px;background:<?= $clr ?>;border:<?= $active ? '3px solid #007A8A' : '3px solid transparent' ?>;transition:border .2s"></div>
                  <span style="font-size:.72rem;color:#475569"><?= $lbl ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Default Date Format</label>
              <select class="form-control">
                <option selected>DD/MM/YYYY</option>
                <option>MM/DD/YYYY</option>
                <option>YYYY-MM-DD</option>
              </select>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Timezone</label>
              <select class="form-control">
                <option selected>Africa/Addis_Ababa (EAT +3)</option>
                <option>UTC</option>
              </select>
            </div>
          </div>
          <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px">Display Options</div>
            <div style="display:flex;flex-direction:column;gap:9px">
              <?php foreach (['Show amount in words on receipts' => true, 'Show QR code on receipts' => false, 'Enable dark mode toggle' => true, 'Show real-time clock in dashboard' => true, 'Show demo mode banner' => true] as $o => $checked): ?>
                <label style="display:flex;align-items:center;gap:9px;cursor:pointer">
                  <input type="checkbox" <?= $checked ? 'checked' : '' ?> style="accent-color:#007A8A;width:14px;height:14px">
                  <span style="font-size:.82rem;font-weight:500"><?= $o ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <button onclick="saveSettings('appearance')" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-floppy-disk"></i> Save Appearance</button>
        </div>
      </div>
    </div>

  </div><!-- end panels -->
</div><!-- end grid -->

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  // ── showSection: the missing function ──
  function showSection(id) {
    // Hide all panels
    document.querySelectorAll('.settings-section').forEach(function(s) {
      s.style.display = 'none';
    });
    // Reset all nav buttons
    document.querySelectorAll('.settings-nav-btn').forEach(function(btn) {
      btn.style.background = 'none';
      btn.style.borderLeft = '3px solid transparent';
      btn.style.fontWeight = '500';
      btn.style.color = 'var(--text-secondary)';
    });
    // Show selected panel
    var panel = document.getElementById('section-' + id);
    if (panel) panel.style.display = 'block';
    // Activate nav button
    var navBtn = document.getElementById('nav-' + id);
    if (navBtn) {
      navBtn.style.background = 'rgba(27,58,92,.07)';
      navBtn.style.borderLeft = '3px solid var(--primary)';
      navBtn.style.fontWeight = '600';
      navBtn.style.color = 'var(--primary)';
    }
    // Scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }

  // ── saveSettings: wired to API ──
  function saveSettings(section) {
    var ind = document.getElementById('settings-save-indicator');
    // Collect all inputs in the current section
    var panel = document.getElementById('section-' + section);
    var inputs = {};
    if (panel) {
      panel.querySelectorAll('input,select,textarea').forEach(function(el) {
        if (el.id || el.name) {
          inputs[el.id || el.name] = el.type === 'checkbox' ? el.checked : el.value;
        }
      });
    }
    ABAY.api('/settings', {
      method: 'POST',
      body: JSON.stringify({
        section: section,
        data: inputs
      })
    }).then(function(d) {
      if (ind) {
        ind.style.display = 'flex';
        setTimeout(function() {
          ind.style.display = 'none';
        }, 3000);
      }
      ABAY.toast('Settings saved successfully!', 'ok');
    }).catch(function() {
      // Demo mode — still show success
      if (ind) {
        ind.style.display = 'flex';
        setTimeout(function() {
          ind.style.display = 'none';
        }, 3000);
      }
      ABAY.toast('Settings saved (demo mode).', 'info');
    });
  }
</script>