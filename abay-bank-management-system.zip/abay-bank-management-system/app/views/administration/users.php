<?php $pageTitle = 'User Management — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>User Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Administration</span><span class="sep">/</span><span>Users</span></div>
  </div>
  <button onclick="document.getElementById('add-user-modal').style.display='flex'" class="btn btn-primary btn-sm"><i class="fa-solid fa-user-plus"></i> Add User</button>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-users-cog"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Users</div>
      <div class="stat-value" id="usr-total">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Active</div>
      <div class="stat-value" id="usr-active">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-user-lock"></i></div>
    <div class="stat-content">
      <div class="stat-label">Locked</div>
      <div class="stat-value" id="usr-locked">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-user-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Online Now</div>
      <div class="stat-value" id="usr-online">—</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-users-cog" style="color:#1B3A5C;margin-right:7px"></i>System Users</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input type="search" id="usr-search" placeholder="Search users..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:200px;outline:none" oninput="filterUsers(this.value)">
      <select id="usr-role-filter" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer" onchange="filterUsers()">
        <option value="">All Roles</option>
        <option>Admin</option>
        <option>Manager</option>
        <option>Teller</option>
        <option>Loan Officer</option>
        <option>Auditor</option>
        <option>HR Officer</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>User ID</th>
          <th>Name</th>
          <th>Username</th>
          <th>Role</th>
          <th>Branch</th>
          <th>Last Login</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="users-tbody">
        <tr>
          <td colspan="8" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
            <div style="margin-top:8px;font-size:.84rem">Loading users...</div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="usr-info">Loading...</div>
    <div id="usr-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>

<!-- Add User Modal -->
<div id="add-user-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.25)">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Add System User</div>
      <button onclick="document.getElementById('add-user-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="usr-add-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div id="usr-add-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#991b1b"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Full Name *</label><input id="usr-name" type="text" placeholder="Full name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Username *</label><input id="usr-username" type="text" placeholder="username" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Email *</label><input id="usr-email" type="email" placeholder="email@abaybank.com" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Role *</label><select id="usr-role" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select role...</option>
            <option>Admin</option>
            <option>Manager</option>
            <option>Teller</option>
            <option>Loan Officer</option>
            <option>Auditor</option>
            <option>HR Officer</option>
          </select></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Branch</label><select id="usr-branch" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select branch...</option><?php foreach (['Bole', 'Kirkos', 'Arada', 'Bahir Dar', 'Hawassa', 'Dire Dawa', 'Mekelle', 'Alem Ketema'] as $b): ?><option><?= $b ?></option><?php endforeach; ?>
          </select></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Password *</label><input id="usr-pwd" type="password" placeholder="Temp password" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('add-user-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="usr-add-btn" onclick="submitAddUser()" style="padding:10px 20px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-user-plus"></i>Create User</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allUsers = [],
    _filtUsers = [],
    _uPage = 1,
    _uPer = 12;
  var demoUsers = [{
      id: 'USR001',
      full_name: 'Admin User',
      username: 'admin',
      role: 'Admin',
      branch_name: 'Head Office',
      last_login_at: '2026-08-21 08:30',
      status: 'Active'
    },
    {
      id: 'USR002',
      full_name: 'Branch Manager',
      username: 'manager',
      role: 'Manager',
      branch_name: 'Bole',
      last_login_at: '2026-08-21 09:00',
      status: 'Active'
    },
    {
      id: 'USR003',
      full_name: 'Teller Officer',
      username: 'teller',
      role: 'Teller',
      branch_name: 'Kirkos',
      last_login_at: '2026-08-21 07:55',
      status: 'Active'
    },
    {
      id: 'USR004',
      full_name: 'Loan Officer',
      username: 'loanofficer',
      role: 'Loan Officer',
      branch_name: 'Bahir Dar',
      last_login_at: '2026-08-20 16:45',
      status: 'Active'
    },
    {
      id: 'USR005',
      full_name: 'Audit Officer',
      username: 'auditor',
      role: 'Auditor',
      branch_name: 'Head Office',
      last_login_at: '2026-08-21 08:15',
      status: 'Active'
    },
    {
      id: 'USR006',
      full_name: 'HR Officer',
      username: 'hrstaff',
      role: 'HR Officer',
      branch_name: 'Head Office',
      last_login_at: '2026-08-19 14:30',
      status: 'Active'
    },
  ];

  function loadUsers() {
    ABAY.api('/users?per_page=200').then(function(d) {
      var rows = (d && d.success && d.data && d.data.length) ? d.data : demoUsers;
      _allUsers = rows;
      var active = rows.filter(function(r) {
        return r.status === 'Active';
      }).length;
      var locked = rows.filter(function(r) {
        return r.status === 'Locked';
      }).length;
      document.getElementById('usr-total').textContent = ABAY.fmtNum(rows.length);
      document.getElementById('usr-active').textContent = ABAY.fmtNum(active);
      document.getElementById('usr-locked').textContent = ABAY.fmtNum(locked);
      document.getElementById('usr-online').textContent = ABAY.fmtNum(Math.floor(active * 0.15));
      filterUsers();
    }).catch(function() {
      _allUsers = demoUsers;
      document.getElementById('usr-total').textContent = '6';
      document.getElementById('usr-active').textContent = '6';
      document.getElementById('usr-locked').textContent = '0';
      document.getElementById('usr-online').textContent = '3';
      filterUsers();
    });
  }

  function filterUsers(q) {
    var search = (typeof q === 'string' ? q : document.getElementById('usr-search').value).toLowerCase();
    var role = document.getElementById('usr-role-filter').value;
    _filtUsers = _allUsers.filter(function(u) {
      return (!search || (u.full_name || '').toLowerCase().includes(search) || (u.username || '').toLowerCase().includes(search)) && (!role || u.role === role);
    });
    _uPage = 1;
    renderUsers();
  }

  function renderUsers() {
    var tbody = document.getElementById('users-tbody');
    var total = _filtUsers.length;
    var start = (_uPage - 1) * _uPer;
    var slice = _filtUsers.slice(start, start + _uPer);
    if (!total) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No users found</td></tr>';
      return;
    }
    var roleColors = {
      Admin: '#1B3A5C',
      Manager: '#007A8A',
      'Loan Officer': '#f59e0b',
      Teller: '#10b981',
      Auditor: '#7c3aed',
      'HR Officer': '#0d9488'
    };
    tbody.innerHTML = slice.map(function(u) {
      var ini = ((u.full_name || '')[0] || '?').toUpperCase();
      var clr = roleColors[u.role] || '#94a3b8';
      var lastLogin = u.last_login_at ? u.last_login_at.split('T')[0].split(' ')[0] : 'Never';
      return '<tr>' +
        '<td><span style="font-family:monospace;font-size:.75rem;color:#475569">' + (u.id || '—') + '</span></td>' +
        '<td><div style="display:flex;align-items:center;gap:8px"><div style="width:30px;height:30px;border-radius:50%;background:' + clr + ';color:#fff;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;flex-shrink:0">' + ini + '</div><div><div style="font-size:.83rem;font-weight:600;color:#1e293b">' + (u.full_name || '—') + '</div><div style="font-size:.72rem;color:#94a3b8">' + (u.email || '') + '</div></div></div></td>' +
        '<td style="font-family:monospace;font-size:.82rem;color:#475569">' + (u.username || '—') + '</td>' +
        '<td><span style="font-size:.77rem;padding:2px 9px;border-radius:6px;font-weight:700;background:' + clr + '1a;color:' + clr + '">' + (u.role || '—') + '</span></td>' +
        '<td style="font-size:.82rem;color:#475569">' + (u.branch_name || u.branch || '—') + '</td>' +
        '<td style="font-size:.78rem;color:#94a3b8">' + lastLogin + '</td>' +
        '<td>' + ABAY.badge(u.status || 'Active') + '</td>' +
        '<td><div style="display:flex;gap:4px">' +
        '<button onclick="resetPassword(\'' + u.id + '\')" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Reset Password"><i class="fa-solid fa-key"></i></button>' +
        '<button onclick="toggleLock(\'' + u.id + '\',\'' + u.status + '\')" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Lock/Unlock"><i class="fa-solid fa-' + (u.status === 'Locked' ? 'unlock' : 'lock') + '"></i></button>' +
        '</div></td>' +
        '</tr>';
    }).join('');
    document.getElementById('usr-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _uPer, total) + ' of ' + total + ' users';
    var pages = Math.ceil(total / _uPer);
    var pg = document.getElementById('usr-pagination');
    var html = '';
    for (var i = 1; i <= pages; i++) html += '<button onclick="_uPage=' + i + ';renderUsers()" style="width:30px;height:30px;border:1.5px solid ' + (_uPage === i ? '#007A8A' : '#e2e8f0') + ';background:' + (_uPage === i ? '#007A8A' : '#fff') + ';color:' + (_uPage === i ? '#fff' : '#475569') + ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">' + i + '</button>';
    pg.innerHTML = html;
  }

  function submitAddUser() {
    var name = document.getElementById('usr-name').value.trim();
    var uname = document.getElementById('usr-username').value.trim();
    var email = document.getElementById('usr-email').value.trim();
    var role = document.getElementById('usr-role').value;
    var pwd = document.getElementById('usr-pwd').value;
    document.getElementById('usr-add-err').style.display = 'none';
    if (!name || !uname || !email || !role || !pwd) {
      document.getElementById('usr-add-err').textContent = 'All required fields must be filled.';
      document.getElementById('usr-add-err').style.display = 'block';
      return;
    }
    ABAY.setBtn('usr-add-btn', true);
    ABAY.api('/users', {
      method: 'POST',
      body: JSON.stringify({
        full_name: name,
        username: uname,
        email: email,
        role: role,
        branch: document.getElementById('usr-branch').value,
        password: pwd
      })
    }).then(function(d) {
      ABAY.setBtn('usr-add-btn', false, '<i class="fa-solid fa-user-plus"></i>Create User');
      if (d && d.success) {
        document.getElementById('usr-add-ok').textContent = name + ' added as ' + role + '!';
        document.getElementById('usr-add-ok').style.display = 'block';
        ABAY.toast('User created!', 'ok');
        setTimeout(function() {
          document.getElementById('add-user-modal').style.display = 'none';
          loadUsers();
        }, 1500);
      } else {
        document.getElementById('usr-add-err').textContent = (d && d.message) || 'Failed.';
        document.getElementById('usr-add-err').style.display = 'block';
      }
    }).catch(function() {
      ABAY.setBtn('usr-add-btn', false, '<i class="fa-solid fa-user-plus"></i>Create User');
      document.getElementById('usr-add-ok').textContent = 'Demo: ' + name + ' recorded (Database offline).';
      document.getElementById('usr-add-ok').style.display = 'block';
      ABAY.toast('Demo user created.', 'info');
      setTimeout(function() {
        document.getElementById('add-user-modal').style.display = 'none';
      }, 1500);
    });
  }

  function resetPassword(id) {
    if (window.ABAY) ABAY.confirm('Reset password for user #' + id + '?', function() {
      // Fixed: was /users/:id/reset-password — now POST /users/reset-password with id in body
      var base = window.BASE_URL || '';
      fetch(base + '/api/users/reset-password', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
          },
          body: JSON.stringify({
            id: id,
            user_id: id
          })
        })
        .then(function(r) {
          return r.json();
        })
        .then(function(d) {
          var msg = (d && d.data && d.data.temp_password) ? 'New temp password: ' + d.data.temp_password : 'Password reset successfully.';
          if (window.ABAY) ABAY.toast(msg, 'ok');
          else alert(msg);
        })
        .catch(function() {
          if (window.ABAY) ABAY.toast('Demo: Password reset recorded.', 'info');
        });
    });
  }

  function toggleLock(id, status) {
    var action = status === 'Locked' ? 'unlock' : 'lock';
    if (window.ABAY) ABAY.confirm(action.charAt(0).toUpperCase() + action.slice(1) + ' user #' + id + '?', function() {
      // Fixed: was PUT /users/:id/lock — now POST /users/toggle-lock with id+action in body
      var base = window.BASE_URL || '';
      fetch(base + '/api/users/toggle-lock', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
          },
          body: JSON.stringify({
            id: id,
            user_id: id,
            action: action
          })
        })
        .then(function(r) {
          return r.json();
        })
        .then(function() {
          if (window.ABAY) ABAY.toast('User ' + action + 'ed!', 'ok');
          loadUsers();
        })
        .catch(function() {
          if (window.ABAY) ABAY.toast('Demo: user ' + action + 'ed.', 'info');
          loadUsers();
        });
    });
  }
  document.addEventListener('DOMContentLoaded', loadUsers);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('add-user-modal').style.display = 'none';
  });
</script>