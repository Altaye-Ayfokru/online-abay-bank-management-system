<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ATM Terminal — Abay Bank</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    *,
    *::before,
    *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0
    }

    :root {
      --atm-bg: #1a1a2e;
      --atm-panel: #16213e;
      --atm-screen: #0d1117;
      --teal: #00b4d8;
      --gold: #C8A84B;
      --green: #22c55e;
      --red: #ef4444;
      --yellow: #f59e0b;
      --text: #e2e8f0;
      --sub: #94a3b8;
      --card: #1e2a3a;
      --border: #2a3850;
      --r: 12px
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--atm-bg);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 16px
    }

    /* ATM Machine Housing */
    .atm-machine {
      width: 100%;
      max-width: 440px;
      background: linear-gradient(160deg, #2d3a4a, #1a2333);
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, .7), inset 0 1px 0 rgba(255, 255, 255, .08);
      border: 1px solid rgba(255, 255, 255, .07);
      overflow: hidden
    }

    .atm-top-bar {
      background: linear-gradient(135deg, #1B3A5C, #007A8A);
      padding: 14px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between
    }

    .atm-brand {
      display: flex;
      align-items: center;
      gap: 10px
    }

    .atm-bars {
      display: flex;
      align-items: flex-end;
      gap: 2px
    }

    .ab {
      border-radius: 1px 1px 0 0
    }

    .ab1 {
      width: 3px;
      height: 10px;
      background: var(--gold)
    }

    .ab2 {
      width: 3px;
      height: 13px;
      background: var(--teal)
    }

    .ab3 {
      width: 3px;
      height: 16px;
      background: #fff
    }

    .ab4 {
      width: 3px;
      height: 10px;
      background: var(--teal)
    }

    .atm-title {
      font-size: .85rem;
      font-weight: 800;
      color: #fff
    }

    .atm-sub {
      font-size: .6rem;
      color: rgba(255, 255, 255, .65);
      font-weight: 400
    }

    .atm-status {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: .7rem;
      color: rgba(255, 255, 255, .7)
    }

    .status-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--green);
      animation: pulse 2s infinite
    }

    /* Screen */
    .atm-screen-wrap {
      background: #000;
      margin: 16px 16px 0;
      border-radius: 12px;
      overflow: hidden;
      border: 2px solid #0d1929;
      box-shadow: inset 0 2px 12px rgba(0, 0, 0, .8), 0 0 0 4px #0a0f1a
    }

    .atm-screen {
      background: var(--atm-screen);
      min-height: 320px;
      padding: 20px;
      position: relative;
      overflow: hidden
    }

    .screen-scanline {
      position: absolute;
      inset: 0;
      background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 180, 216, .015) 2px, rgba(0, 180, 216, .015) 4px);
      pointer-events: none
    }

    /* Screen panels */
    .screen-panel {
      display: none
    }

    .screen-panel.active {
      display: block;
      animation: fadeIn .3s ease
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(8px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    /* Welcome screen */
    .welcome-title {
      font-size: 1.3rem;
      font-weight: 800;
      color: var(--teal);
      text-align: center;
      margin-bottom: 6px;
      letter-spacing: .04em
    }

    .welcome-sub {
      font-size: .75rem;
      color: var(--sub);
      text-align: center;
      margin-bottom: 24px
    }

    .atm-id-tag {
      background: rgba(0, 180, 216, .08);
      border: 1px solid rgba(0, 180, 216, .2);
      border-radius: 6px;
      padding: 6px 12px;
      font-size: .7rem;
      color: var(--teal);
      text-align: center;
      margin-bottom: 16px;
      font-family: monospace
    }

    .btn-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px
    }

    .atm-btn {
      border: none;
      border-radius: 8px;
      padding: 12px;
      font-size: .82rem;
      font-weight: 700;
      cursor: pointer;
      transition: .2s;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      font-family: inherit
    }

    .atm-btn i {
      font-size: 1.2rem
    }

    .atm-btn:active {
      transform: scale(.96)
    }

    .atm-btn.primary {
      background: linear-gradient(135deg, var(--teal), #0099b8);
      color: #fff
    }

    .atm-btn.gold {
      background: linear-gradient(135deg, var(--gold), #a88830);
      color: #0d1117
    }

    .atm-btn.green {
      background: linear-gradient(135deg, var(--green), #16a34a);
      color: #fff
    }

    .atm-btn.red {
      background: linear-gradient(135deg, var(--red), #dc2626);
      color: #fff
    }

    .atm-btn.ghost {
      background: rgba(255, 255, 255, .06);
      border: 1px solid var(--border);
      color: var(--text)
    }

    /* Auth screens */
    .auth-title {
      font-size: .92rem;
      font-weight: 700;
      color: var(--teal);
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 8px
    }

    .form-field {
      margin-bottom: 12px
    }

    .field-label {
      font-size: .72rem;
      font-weight: 600;
      color: var(--sub);
      text-transform: uppercase;
      letter-spacing: .06em;
      margin-bottom: 5px
    }

    .atm-input {
      width: 100%;
      background: rgba(0, 0, 0, .5);
      border: 1.5px solid var(--border);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: .88rem;
      color: var(--text);
      font-family: inherit;
      transition: .2s
    }

    .atm-input:focus {
      outline: none;
      border-color: var(--teal);
      box-shadow: 0 0 0 3px rgba(0, 180, 216, .15)
    }

    .atm-input::placeholder {
      color: rgba(148, 163, 184, .5)
    }

    .btn-full {
      width: 100%;
      border: none;
      border-radius: 8px;
      padding: 11px;
      font-size: .88rem;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      transition: .2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      margin-top: 10px
    }

    .btn-full:disabled {
      opacity: .5;
      cursor: not-allowed
    }

    .btn-teal {
      background: linear-gradient(135deg, var(--teal), #0099b8);
      color: #fff
    }

    .btn-gold {
      background: linear-gradient(135deg, var(--gold), #a88830);
      color: #0d1117
    }

    .btn-green {
      background: linear-gradient(135deg, var(--green), #16a34a);
      color: #fff
    }

    .btn-red {
      background: linear-gradient(135deg, var(--red), #dc2626);
      color: #fff
    }

    .btn-gray {
      background: rgba(255, 255, 255, .08);
      border: 1px solid var(--border);
      color: var(--text)
    }

    .auth-tabs {
      display: flex;
      gap: 6px;
      margin-bottom: 16px
    }

    .auth-tab {
      flex: 1;
      padding: 8px;
      border: 1.5px solid var(--border);
      border-radius: 8px;
      background: transparent;
      color: var(--sub);
      font-size: .75rem;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      transition: .2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px
    }

    .auth-tab.active {
      background: rgba(0, 180, 216, .12);
      border-color: var(--teal);
      color: var(--teal)
    }

    .biometric-ring {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      border: 3px solid var(--border);
      margin: 0 auto 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      color: var(--sub);
      position: relative
    }

    .biometric-ring.scanning {
      border-color: var(--teal);
      animation: scan-ring 1.5s ease-in-out infinite;
      color: var(--teal)
    }

    .biometric-ring.success {
      border-color: var(--green);
      color: var(--green)
    }

    .biometric-ring.fail {
      border-color: var(--red);
      color: var(--red)
    }

    @keyframes scan-ring {

      0%,
      100% {
        box-shadow: 0 0 0 0 rgba(0, 180, 216, .4)
      }

      50% {
        box-shadow: 0 0 0 12px rgba(0, 180, 216, .0)
      }
    }

    /* Dashboard / menu */
    .customer-bar {
      background: rgba(0, 180, 216, .08);
      border: 1px solid rgba(0, 180, 216, .15);
      border-radius: 8px;
      padding: 12px 14px;
      margin-bottom: 14px
    }

    .cust-name {
      font-size: .92rem;
      font-weight: 700;
      color: var(--teal)
    }

    .cust-acct {
      font-size: .72rem;
      color: var(--sub);
      margin-top: 2px;
      font-family: monospace
    }

    .balance-big {
      text-align: center;
      margin: 16px 0
    }

    .balance-label {
      font-size: .72rem;
      color: var(--sub);
      text-transform: uppercase;
      letter-spacing: .08em
    }

    .balance-value {
      font-size: 2rem;
      font-weight: 800;
      color: var(--green);
      margin-top: 4px;
      font-variant-numeric: tabular-nums
    }

    .balance-currency {
      font-size: 1rem;
      font-weight: 500;
      color: var(--sub);
      vertical-align: super;
      margin-right: 4px
    }

    .menu-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px
    }

    .menu-item {
      background: rgba(255, 255, 255, .04);
      border: 1.5px solid var(--border);
      border-radius: 10px;
      padding: 12px 6px;
      text-align: center;
      cursor: pointer;
      transition: .2s;
      border: none
    }

    .menu-item:hover {
      background: rgba(0, 180, 216, .1);
      border-color: var(--teal)
    }

    .menu-item i {
      font-size: 1.3rem;
      color: var(--teal);
      margin-bottom: 6px;
      display: block
    }

    .menu-item span {
      font-size: .68rem;
      font-weight: 600;
      color: var(--sub);
      display: block
    }

    .session-timer {
      text-align: center;
      font-size: .65rem;
      color: var(--sub);
      margin-top: 10px
    }

    .timer-val {
      color: var(--yellow);
      font-weight: 700
    }

    /* Transaction screens */
    .tx-icon {
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: rgba(0, 180, 216, .12);
      border: 1px solid rgba(0, 180, 216, .2);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      color: var(--teal);
      margin-bottom: 14px
    }

    .quick-amounts {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin: 10px 0
    }

    .qa {
      background: rgba(255, 255, 255, .05);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 6px 12px;
      font-size: .78rem;
      font-weight: 600;
      cursor: pointer;
      color: var(--text);
      font-family: inherit;
      transition: .15s
    }

    .qa:hover {
      background: rgba(0, 180, 216, .1);
      border-color: var(--teal);
      color: var(--teal)
    }

    /* Receipt / result */
    .receipt {
      background: rgba(0, 0, 0, .5);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 14px
    }

    .receipt-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 0;
      border-bottom: 1px solid rgba(255, 255, 255, .04);
      font-size: .78rem
    }

    .receipt-row:last-child {
      border: none
    }

    .receipt-label {
      color: var(--sub)
    }

    .receipt-value {
      font-weight: 600;
      color: var(--text)
    }

    .result-icon {
      text-align: center;
      margin-bottom: 12px
    }

    .result-icon i {
      font-size: 2.2rem
    }

    .result-title {
      text-align: center;
      font-size: 1rem;
      font-weight: 800;
      margin-bottom: 4px
    }

    .result-sub {
      text-align: center;
      font-size: .75rem;
      color: var(--sub);
      margin-bottom: 14px
    }

    .ref-code {
      background: rgba(0, 180, 216, .08);
      border: 1px solid rgba(0, 180, 216, .2);
      border-radius: 6px;
      padding: 8px 12px;
      font-family: monospace;
      font-size: .75rem;
      color: var(--teal);
      text-align: center;
      margin-bottom: 12px;
      word-break: break-all
    }

    /* Bottom controls */
    .atm-controls {
      padding: 16px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 8px
    }

    .ctrl-btn {
      background: rgba(0, 0, 0, .4);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 10px;
      font-size: .72rem;
      font-weight: 600;
      cursor: pointer;
      color: var(--text);
      font-family: inherit;
      transition: .15s;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px
    }

    .ctrl-btn i {
      font-size: 1rem
    }

    .ctrl-btn:hover {
      background: rgba(255, 255, 255, .06)
    }

    .ctrl-btn.ctrl-cancel {
      color: var(--red)
    }

    .ctrl-btn.ctrl-clear {
      color: var(--yellow)
    }

    .ctrl-btn.ctrl-enter {
      color: var(--green)
    }

    /* Toast */
    .atm-toast {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #1e2a3a;
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 10px 20px;
      font-size: .82rem;
      z-index: 9999;
      opacity: 0;
      transition: .3s;
      pointer-events: none;
      max-width: 90%
    }

    .atm-toast.show {
      opacity: 1
    }

    .atm-toast.ok {
      border-color: var(--green);
      color: var(--green)
    }

    .atm-toast.err {
      border-color: var(--red);
      color: var(--red)
    }

    /* Loading overlay */
    .screen-loader {
      position: absolute;
      inset: 0;
      background: rgba(13, 17, 23, .85);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 10;
      display: none
    }

    .screen-loader.show {
      display: flex
    }

    .loader-spinner {
      width: 36px;
      height: 36px;
      border: 3px solid rgba(0, 180, 216, .15);
      border-top-color: var(--teal);
      border-radius: 50%;
      animation: spin .8s linear infinite;
      margin-bottom: 10px
    }

    .loader-text {
      font-size: .78rem;
      color: var(--sub)
    }

    @keyframes spin {
      to {
        transform: rotate(360deg)
      }
    }

    @keyframes pulse {

      0%,
      100% {
        opacity: 1
      }

      50% {
        opacity: .4
      }
    }
  </style>
</head>

<body>

  <div class="atm-toast" id="toast"></div>

  <div class="atm-machine">
    <!-- Top bar -->
    <div class="atm-top-bar">
      <div class="atm-brand">
        <div class="atm-bars">
          <div class="ab ab1"></div>
          <div class="ab ab2"></div>
          <div class="ab ab3"></div>
          <div class="ab ab4"></div>
        </div>
        <div>
          <div class="atm-title">ዓባይ ባንክ — Abay Bank</div>
          <div class="atm-sub">Automated Teller Machine · Alem Ketema</div>
        </div>
      </div>
      <div class="atm-status">
        <div class="status-dot"></div>Online
      </div>
    </div>

    <!-- Screen -->
    <div class="atm-screen-wrap">
      <div class="atm-screen" id="screen">
        <div class="screen-scanline"></div>

        <!-- Loading Overlay -->
        <div class="screen-loader" id="loader">
          <div class="loader-spinner"></div>
          <div class="loader-text" id="loader-text">Processing...</div>
        </div>

        <!-- === PANEL: WELCOME === -->
        <div class="screen-panel active" id="panel-welcome">
          <div style="text-align:center;margin-bottom:20px">
            <div style="font-size:.65rem;color:var(--sub);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px"><?= date('D, d M Y — H:i') ?></div>
            <div class="atm-id-tag"><i class="fa-solid fa-location-dot"></i> ATM-ALEM-001 · Alem Ketema Branch, North Shewa</div>
          </div>
          <div class="welcome-title"><i class="fa-solid fa-building-columns"></i> ABAY BANK ATM</div>
          <div class="welcome-sub">Please choose how to authenticate</div>
          <div class="btn-row">
            <button class="atm-btn primary" onclick="showPanel('panel-auth-username')">
              <i class="fa-solid fa-user"></i>Username + Account
            </button>
            <button class="atm-btn gold" onclick="showPanel('panel-auth-biometric')">
              <i class="fa-solid fa-fingerprint"></i>Biometric / Ashara
            </button>
          </div>
          <div style="margin-top:12px">
            <button class="atm-btn ghost" style="width:100%;flex-direction:row;justify-content:center" onclick="window.location='<?= APP_URL ?>/online/apply'">
              <i class="fa-solid fa-plus"></i> Open Account Online
            </button>
          </div>
        </div>

        <!-- === PANEL: AUTH — USERNAME + ACCOUNT === -->
        <div class="screen-panel" id="panel-auth-username">
          <div class="auth-title"><i class="fa-solid fa-user"></i> Sign In — Username &amp; Account</div>
          <div class="form-field">
            <div class="field-label">Username or Email</div>
            <input type="text" id="auth-username" class="atm-input" placeholder="e.g. abebe.bekele" autocomplete="off" autocorrect="off" autocapitalize="off">
          </div>
          <div class="form-field">
            <div class="field-label">Account Number</div>
            <input type="text" id="auth-account" class="atm-input" placeholder="e.g. 000110010000000001" autocomplete="off">
          </div>
          <div class="form-field">
            <div class="field-label">PIN (4–6 digits)</div>
            <input type="password" id="auth-pin" class="atm-input" placeholder="••••" maxlength="6" inputmode="numeric">
          </div>
          <div style="font-size:.7rem;color:var(--sub);margin-bottom:8px;background:rgba(0,180,216,.06);padding:8px 10px;border-radius:6px;border:1px solid rgba(0,180,216,.12)">
            <i class="fa-solid fa-circle-info" style="color:var(--teal)"></i>
            Demo &#8212; username: <strong style="color:var(--teal)">abebe.bekele</strong> &nbsp;|&nbsp;
            account: <strong style="color:var(--teal)">000110010000000001</strong> &nbsp;|&nbsp;
            PIN: <strong style="color:var(--gold)">0001</strong> (last 4 of account)
          </div>
          <button class="btn-full btn-teal" onclick="doAuthUsername()"><i class="fa-solid fa-right-to-bracket"></i> Authenticate</button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="showPanel('panel-welcome')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: AUTH — BIOMETRIC === -->
        <div class="screen-panel" id="panel-auth-biometric">
          <div class="auth-title"><i class="fa-solid fa-fingerprint"></i> Biometric Authentication</div>
          <div class="auth-tabs">
            <button class="auth-tab active" id="tab-finger" onclick="setBioType('Fingerprint',this)"><i class="fa-solid fa-fingerprint"></i> Fingerprint</button>
            <button class="auth-tab" id="tab-iris" onclick="setBioType('Iris',this)"><i class="fa-solid fa-eye"></i> Iris / Ashara</button>
          </div>
          <div class="biometric-ring" id="bio-ring">
            <i class="fa-solid fa-fingerprint" id="bio-icon"></i>
          </div>
          <div style="text-align:center;font-size:.78rem;color:var(--sub);margin-bottom:14px" id="bio-status-text">Place your finger on the sensor below</div>
          <div class="form-field">
            <div class="field-label">Account Number</div>
            <input type="text" id="bio-account" class="atm-input" placeholder="Enter your account number">
          </div>
          <button class="btn-full btn-gold" id="bio-scan-btn" onclick="doBiometricAuth()">
            <i class="fa-solid fa-fingerprint"></i> Scan Biometric
          </button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="showPanel('panel-welcome')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: MAIN MENU === -->
        <div class="screen-panel" id="panel-menu">
          <div class="customer-bar">
            <div class="cust-name" id="menu-cust-name">—</div>
            <div class="cust-acct" id="menu-cust-acct">Account: —</div>
          </div>
          <div class="balance-big">
            <div class="balance-label">Available Balance</div>
            <div class="balance-value" id="menu-balance"><span class="balance-currency">ETB</span><span id="bal-num">—</span></div>
          </div>
          <div class="menu-grid">
            <button class="menu-item" onclick="showPanel('panel-deposit')">
              <i class="fa-solid fa-arrow-down"></i><span>Deposit</span>
            </button>
            <button class="menu-item" onclick="showPanel('panel-withdraw')">
              <i class="fa-solid fa-arrow-up"></i><span>Withdraw</span>
            </button>
            <button class="menu-item" onclick="doBalanceEnquiry()">
              <i class="fa-solid fa-magnifying-glass-dollar"></i><span>Balance</span>
            </button>
            <button class="menu-item" onclick="doMiniStatement()">
              <i class="fa-solid fa-file-lines"></i><span>Mini Stmt</span>
            </button>
            <button class="menu-item" onclick="doEndSession()">
              <i class="fa-solid fa-right-from-bracket"></i><span>Exit / Eject</span>
            </button>
            <button class="menu-item" onclick="window.open('<?= APP_URL ?>/online/apply','_blank')">
              <i class="fa-solid fa-globe"></i><span>Open Account</span>
            </button>
          </div>
          <div class="session-timer">Session timeout: <span class="timer-val" id="timer">15:00</span></div>
        </div>

        <!-- === PANEL: DEPOSIT === -->
        <div class="screen-panel" id="panel-deposit">
          <div class="tx-icon"><i class="fa-solid fa-arrow-down"></i></div>
          <div class="auth-title">Cash Deposit</div>
          <div class="form-field">
            <div class="field-label">Amount (ETB) — Min 50, Max 50,000</div>
            <input type="number" id="dep-amount" class="atm-input" placeholder="Enter amount" min="50" max="50000" step="50" inputmode="decimal">
          </div>
          <div class="quick-amounts">
            <?php foreach ([500, 1000, 2000, 5000, 10000] as $qa): ?>
              <button class="qa" onclick="document.getElementById('dep-amount').value=<?= $qa ?>"><?= number_format($qa) ?></button>
            <?php endforeach; ?>
          </div>
          <button class="btn-full btn-green" onclick="doDeposit()"><i class="fa-solid fa-check"></i> Confirm Deposit</button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="showPanel('panel-menu')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: WITHDRAW === -->
        <div class="screen-panel" id="panel-withdraw">
          <div class="tx-icon" style="background:rgba(239,68,68,.1);border-color:rgba(239,68,68,.2)"><i class="fa-solid fa-arrow-up" style="color:var(--red)"></i></div>
          <div class="auth-title" style="color:var(--red)">Cash Withdrawal</div>
          <div class="form-field">
            <div class="field-label">Amount (ETB) — Multiples of 100, Max 10,000</div>
            <input type="number" id="wdr-amount" class="atm-input" placeholder="Enter amount" min="100" max="10000" step="100" inputmode="decimal">
          </div>
          <div class="quick-amounts">
            <?php foreach ([200, 500, 1000, 2000, 5000] as $qa): ?>
              <button class="qa" onclick="document.getElementById('wdr-amount').value=<?= $qa ?>"><?= number_format($qa) ?></button>
            <?php endforeach; ?>
          </div>
          <button class="btn-full btn-red" onclick="doWithdraw()"><i class="fa-solid fa-check"></i> Confirm Withdrawal</button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="showPanel('panel-menu')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: BALANCE === -->
        <div class="screen-panel" id="panel-balance">
          <div class="result-icon"><i class="fa-solid fa-magnifying-glass-dollar" style="color:var(--teal);font-size:2.5rem"></i></div>
          <div class="result-title" style="color:var(--teal)">Balance Enquiry</div>
          <div class="receipt" id="balance-receipt" style="margin-bottom:12px"></div>
          <button class="btn-full btn-teal" onclick="doPrint()"><i class="fa-solid fa-print"></i> Print Receipt</button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="showPanel('panel-menu')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: MINI STATEMENT === -->
        <div class="screen-panel" id="panel-statement">
          <div class="auth-title"><i class="fa-solid fa-file-lines"></i> Mini Statement</div>
          <div id="stmt-rows" style="font-size:.72rem"></div>
          <button class="btn-full btn-gray" style="margin-top:10px" onclick="showPanel('panel-menu')"><i class="fa-solid fa-arrow-left"></i> Back</button>
        </div>

        <!-- === PANEL: RESULT === -->
        <div class="screen-panel" id="panel-result">
          <div class="result-icon" id="result-icon"></div>
          <div class="result-title" id="result-title"></div>
          <div class="result-sub" id="result-sub"></div>
          <div class="ref-code" id="result-ref" style="display:none"></div>
          <div class="receipt" id="result-receipt" style="display:none"></div>
          <button class="btn-full btn-teal" id="result-back-btn" onclick="showPanel('panel-menu')"><i class="fa-solid fa-home"></i> Back to Menu</button>
          <button class="btn-full btn-gray" style="margin-top:6px" onclick="doEndSession()"><i class="fa-solid fa-right-from-bracket"></i> Exit ATM</button>
        </div>

      </div><!-- /atm-screen -->
    </div><!-- /screen-wrap -->

    <!-- Physical Controls -->
    <div class="atm-controls">
      <button class="ctrl-btn ctrl-cancel" onclick="doEndSession()"><i class="fa-solid fa-xmark"></i><span>Cancel</span></button>
      <button class="ctrl-btn ctrl-clear" onclick="clearCurrentInput()"><i class="fa-solid fa-delete-left"></i><span>Clear</span></button>
      <button class="ctrl-btn ctrl-enter" onclick="enterAction()"><i class="fa-solid fa-check"></i><span>Enter</span></button>
    </div>
  </div>

  <div style="text-align:center;margin-top:12px;font-size:.68rem;color:rgba(255,255,255,.25)">
    Abay Bank ATM · NBE Licensed · Protected by 256-bit Encryption
    &nbsp;·&nbsp; <a href="<?= APP_URL ?>" style="color:rgba(255,255,255,.25)">Staff Portal</a>
  </div>

  <script>
    const BASE = '<?= APP_URL ?>';
    let sessionToken = null;
    let custName = null;
    let custAcct = null;
    let custBalance = 0;
    let bioType = 'Fingerprint';
    let sessionInterval = null;
    let countdown = 900; // 15 min

    // ── Panel manager ──────────────────────────────────────────────
    function showPanel(id) {
      document.querySelectorAll('.screen-panel').forEach(p => p.classList.remove('active'));
      const el = document.getElementById(id);
      if (el) {
        el.classList.add('active');
      }
      if (id === 'panel-menu') startSessionTimer();
    }

    // ── Toast ──────────────────────────────────────────────────────
    function toast(msg, type = '') {
      const el = document.getElementById('toast');
      el.textContent = msg;
      el.className = 'atm-toast show ' + type;
      setTimeout(() => el.className = 'atm-toast', 3500);
    }

    // ── Loader ─────────────────────────────────────────────────────
    function showLoader(msg = 'Processing...') {
      document.getElementById('loader-text').textContent = msg;
      document.getElementById('loader').classList.add('show');
    }

    function hideLoader() {
      document.getElementById('loader').classList.remove('show');
    }

    // ── Session timer ──────────────────────────────────────────────
    function startSessionTimer() {
      if (sessionInterval) clearInterval(sessionInterval);
      countdown = 900;
      sessionInterval = setInterval(() => {
        countdown--;
        const m = Math.floor(countdown / 60).toString().padStart(2, '0');
        const s = (countdown % 60).toString().padStart(2, '0');
        const el = document.getElementById('timer');
        if (el) el.textContent = m + ':' + s;
        if (countdown <= 0) {
          clearInterval(sessionInterval);
          toast('Session timed out.', 'err');
          doEndSession();
        }
      }, 1000);
    }

    // ── Authentication: Username + Account ────────────────────────
    async function doAuthUsername() {
      const username = document.getElementById('auth-username').value.trim();
      const acct = document.getElementById('auth-account').value.trim();
      const pin = document.getElementById('auth-pin').value.trim();
      if (!username) {
        toast('Please enter your username or email.', 'err');
        return;
      }
      if (!acct) {
        toast('Please enter your account number.', 'err');
        return;
      }

      showLoader('Verifying identity...');
      const res = await post('/atm/auth', {
        auth_method: 'username',
        username,
        account_number: acct,
        pin,
        atm_id: 'ATM-ALEM-001',
        atm_location: 'Alem Ketema Branch'
      });
      hideLoader();
      if (res && res.success) {
        sessionToken = res.session_token;
        custName = res.customer_name;
        custAcct = res.account_number;
        custBalance = res.balance;
        updateMenu();
        showPanel('panel-menu');
        toast('Welcome, ' + custName + '!', 'ok');
      } else {
        toast((res && res.message) || 'Authentication failed.', 'err');
      }
    }

    // ── Authentication: Biometric ──────────────────────────────────
    function setBioType(type, btn) {
      bioType = type;
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      const icon = document.getElementById('bio-icon');
      icon.className = type === 'Iris' ? 'fa-solid fa-eye' : 'fa-solid fa-fingerprint';
      document.getElementById('bio-status-text').textContent =
        type === 'Iris' ? 'Look into the iris scanner' : 'Place your finger on the sensor below';
    }

    async function doBiometricAuth() {
      const acct = document.getElementById('bio-account').value.trim();
      if (!acct) {
        toast('Please enter account number.', 'err');
        return;
      }

      const ring = document.getElementById('bio-ring');
      const btn = document.getElementById('bio-scan-btn');
      ring.className = 'biometric-ring scanning';
      btn.disabled = true;
      document.getElementById('bio-status-text').textContent = 'Scanning ' + bioType + '...';
      await sleep(2000);

      showLoader('Matching ' + bioType + ' template...');
      const res = await post('/atm/auth', {
        auth_method: 'biometric',
        biometric_type: bioType,
        account_number: acct,
        template_data: btoa('simulated_template_' + acct),
        atm_id: 'ATM-ALEM-001',
        atm_location: 'Alem Ketema Branch'
      });
      hideLoader();
      if (res && res.success) {
        ring.className = 'biometric-ring success';
        document.getElementById('bio-status-text').textContent = bioType + ' verified! Score: ' + res.match_score + '%';
        sessionToken = res.session_token;
        custName = res.customer_name;
        custAcct = res.account_number;
        custBalance = res.balance;
        updateMenu();
        await sleep(700);
        showPanel('panel-menu');
        toast(bioType + ' verified. Welcome, ' + custName + '!', 'ok');
      } else {
        ring.className = 'biometric-ring fail';
        document.getElementById('bio-status-text').textContent = (res && res.message) || 'Biometric match failed.';
        toast((res && res.message) || 'Biometric failed.', 'err');
        btn.disabled = false;
      }
    }

    function updateMenu() {
      document.getElementById('menu-cust-name').textContent = custName || '—';
      document.getElementById('menu-cust-acct').textContent = 'Account: ' + (custAcct || '—');
      document.getElementById('bal-num').textContent = Number(custBalance).toLocaleString('en-ET', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }

    // ── Deposit ────────────────────────────────────────────────────
    async function doDeposit() {
      const amount = parseFloat(document.getElementById('dep-amount').value);
      if (!amount || amount < 50) {
        toast('Minimum deposit is ETB 50', 'err');
        return;
      }
      if (amount > 50000) {
        toast('Maximum deposit is ETB 50,000', 'err');
        return;
      }
      showLoader('Processing deposit...');
      const res = await post('/atm/deposit', {
        session_token: sessionToken,
        amount
      });
      hideLoader();
      if (res && res.success) {
        custBalance = res.new_balance;
        updateMenu();
        showResult('ok', 'Deposit Successful', 'ETB ' + fmtAmt(amount) + ' deposited', res.reference, [
          ['Amount Deposited', 'ETB ' + fmtAmt(res.amount)],
          ['New Balance', 'ETB ' + fmtAmt(res.new_balance)],
          ['Reference', res.reference],
        ]);
      } else {
        toast((res && res.message) || 'Deposit failed. Please retry.', 'err');
      }
    }

    // ── Withdrawal ─────────────────────────────────────────────────
    async function doWithdraw() {
      const amount = parseFloat(document.getElementById('wdr-amount').value);
      if (!amount || amount < 100) {
        toast('Minimum withdrawal is ETB 100', 'err');
        return;
      }
      if (amount % 100 !== 0) {
        toast('Amount must be multiple of ETB 100', 'err');
        return;
      }
      if (amount > 10000) {
        toast('Maximum withdrawal is ETB 10,000', 'err');
        return;
      }
      showLoader('Processing withdrawal...');
      const res = await post('/atm/withdraw', {
        session_token: sessionToken,
        amount
      });
      hideLoader();
      if (res && res.success) {
        custBalance = res.new_balance;
        updateMenu();
        showResult('ok', 'Please Collect Cash', 'ETB ' + fmtAmt(amount) + ' dispensed', res.reference, [
          ['Amount Withdrawn', 'ETB ' + fmtAmt(res.amount)],
          ['Remaining Balance', 'ETB ' + fmtAmt(res.new_balance)],
          ['Reference', res.reference],
        ]);
      } else {
        toast((res && res.message) || 'Withdrawal failed. Please retry.', 'err');
      }
    }

    // ── Balance Enquiry ────────────────────────────────────────────
    async function doBalanceEnquiry() {
      showLoader('Fetching balance...');
      const res = await post('/atm/balance', {
        session_token: sessionToken
      });
      hideLoader();
      if (res && res.success) {
        custBalance = res.balance;
        updateMenu();
        document.getElementById('balance-receipt').innerHTML = receiptHtml([
          ['Account Number', res.account_number],
          ['Account Type', res.account_type],
          ['Customer', res.customer_name],
          ['Available Balance', 'ETB ' + fmtAmt(res.balance)],
          ['As of', res.as_of],
        ]);
        showPanel('panel-balance');
      } else {
        toast((res && res.message) || 'Could not fetch balance.', 'err');
      }
    }

    // ── Mini Statement ─────────────────────────────────────────────
    async function doMiniStatement() {
      showLoader('Loading statement...');
      const res = await post('/atm/statement', {
        session_token: sessionToken
      });
      hideLoader();
      if (res && res.success) {
        const rows = res.transactions || [];
        let html = '<div style="overflow-y:auto;max-height:220px">';
        if (!rows.length) {
          html += '<div style="color:var(--sub);text-align:center;padding:20px">No transactions found</div>';
        }
        rows.forEach(function(t) {
          const isCredit = ['Deposit', 'Transfer In', 'Interest Credit'].includes(t.type);
          const clr = isCredit ? 'var(--green)' : 'var(--red)';
          html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05)">' +
            '<div><div style="font-size:.72rem;font-weight:600;color:' + clr + '">' + t.type + '</div>' +
            '<div style="font-size:.65rem;color:var(--sub)">' + (t.created_at || '').substring(0, 10) + '</div></div>' +
            '<div style="text-align:right"><div style="font-size:.75rem;font-weight:700;color:' + clr + '">' +
            (isCredit ? '+' : '-') + 'ETB ' + fmtAmt(t.amount) + '</div>' +
            '<div style="font-size:.65rem;color:var(--sub)">Bal: ETB ' + fmtAmt(t.balance_after) + '</div></div>' +
            '</div>';
        });
        html += '</div>';
        document.getElementById('stmt-rows').innerHTML = html;
        showPanel('panel-statement');
      } else {
        toast((res && res.message) || 'Could not load statement.', 'err');
      }
    }

    // ── End session ────────────────────────────────────────────────
    async function doEndSession() {
      if (sessionToken) {
        await post('/atm/end', {
          session_token: sessionToken
        }); // always resolves now
        sessionToken = null;
      }
      if (sessionInterval) clearInterval(sessionInterval);
      custName = null;
      custAcct = null;
      custBalance = 0;
      showPanel('panel-welcome');
      document.getElementById('auth-username').value = '';
      document.getElementById('auth-account').value = '';
      document.getElementById('auth-pin').value = '';
      document.getElementById('bio-account').value = '';
    }

    // ── Show result ────────────────────────────────────────────────
    function showResult(type, title, sub, ref, receiptRows) {
      const iconEl = document.getElementById('result-icon');
      const titleEl = document.getElementById('result-title');
      const subEl = document.getElementById('result-sub');
      const refEl = document.getElementById('result-ref');
      const recEl = document.getElementById('result-receipt');

      if (type === 'ok') {
        iconEl.innerHTML = '<i class="fa-solid fa-circle-check" style="color:var(--green)"></i>';
        titleEl.textContent = title;
        titleEl.style.color = 'var(--green)';
      } else {
        iconEl.innerHTML = '<i class="fa-solid fa-circle-xmark" style="color:var(--red)"></i>';
        titleEl.textContent = title;
        titleEl.style.color = 'var(--red)';
      }
      subEl.textContent = sub;
      if (ref) {
        refEl.textContent = 'REF: ' + ref;
        refEl.style.display = 'block';
      } else {
        refEl.style.display = 'none';
      }
      if (receiptRows) {
        recEl.innerHTML = receiptHtml(receiptRows);
        recEl.style.display = 'block';
      } else {
        recEl.style.display = 'none';
      }
      showPanel('panel-result');
    }

    function receiptHtml(rows) {
      return rows.map(([l, v]) =>
        `<div class="receipt-row"><span class="receipt-label">${l}</span><span class="receipt-value">${v}</span></div>`
      ).join('');
    }

    // ── Print receipt (simple) ─────────────────────────────────────
    function doPrint() {
      window.print();
    }

    // ── Clear / Enter physical buttons ────────────────────────────
    function clearCurrentInput() {
      const active = document.querySelector('.screen-panel.active');
      if (!active) return;
      const inputs = active.querySelectorAll('.atm-input');
      if (inputs.length) inputs[inputs.length - 1].value = '';
    }

    function enterAction() {
      const panel = document.querySelector('.screen-panel.active');
      if (!panel) return;
      const id = panel.id;
      if (id === 'panel-auth-username') doAuthUsername();
      else if (id === 'panel-auth-biometric') doBiometricAuth();
      else if (id === 'panel-deposit') doDeposit();
      else if (id === 'panel-withdraw') doWithdraw();
    }

    // ── Helpers ────────────────────────────────────────────────────
    function fmtAmt(n) {
      return Number(n).toLocaleString('en-ET', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }

    function sleep(ms) {
      return new Promise(r => setTimeout(r, ms));
    }

    /**
     * post() — robust fetch wrapper for ATM endpoints.
     *
     * Key fixes:
     *  1. Never throws on non-2xx HTTP — reads JSON body and returns it.
     *     This means PHP error responses (400/500) are surfaced as
     *     {success:false, message:…} instead of triggering the catch block.
     *  2. Sends credentials so any staff/customer session cookie is passed.
     *  3. 10-second timeout — avoids indefinite "processing" spinners.
     *  4. Falls back to a typed error object if the body is not JSON.
     */
    async function post(path, data) {
      const controller = new AbortController();
      const tid = setTimeout(() => controller.abort(), 10000); // 10 s timeout

      try {
        const body = new URLSearchParams(data);
        const res = await fetch(BASE + path, {
          method: 'POST',
          body: body,
          credentials: 'include',
          signal: controller.signal,
          headers: {
            'X-Requested-With': 'XMLHttpRequest'
          },
        });
        clearTimeout(tid);

        // Always try to parse JSON — even on 4xx/5xx
        const ct = res.headers.get('content-type') || '';
        if (ct.includes('application/json') || ct.includes('text/')) {
          try {
            return await res.json();
          } catch (_) {}
        }
        // Non-JSON body (e.g. PHP fatal error HTML)
        if (!res.ok) {
          return {
            success: false,
            message: 'Server error (' + res.status + '). Please try again.'
          };
        }
        return {
          success: false,
          message: 'Unexpected response from server.'
        };

      } catch (err) {
        clearTimeout(tid);
        if (err.name === 'AbortError') {
          return {
            success: false,
            message: 'Request timed out. Check your connection and try again.'
          };
        }
        // Network down / XAMPP not running / CORS
        return {
          success: false,
          message: 'Cannot reach server. Make sure XAMPP is running.'
        };
      }
    }
  </script>
</body>

</html>