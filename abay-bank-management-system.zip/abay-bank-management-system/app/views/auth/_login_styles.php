*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#f0f4f8;min-height:100vh;display:flex;align-items:center;justify-content:center;}
.login-wrap{display:flex;max-width:1060px;width:100%;margin:24px;background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 24px 80px rgba(27,58,92,.2);}
.brand-side{flex:1.1;background:linear-gradient(160deg,#1B3A5C,#007A8A);padding:52px 44px;color:#fff;display:flex;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;}
.brand-side::before{content:'';position:absolute;top:-100px;right:-100px;width:380px;height:380px;background:radial-gradient(circle,rgba(200,168,75,.18),transparent 70%);border-radius:50%;}
.logo-row{display:flex;align-items:center;gap:13px;margin-bottom:32px;position:relative;z-index:2;}
.logo-bars{display:flex;align-items:flex-end;gap:4px;background:rgba(255,255,255,.12);border-radius:10px;padding:8px 10px 10px;}
.logo-bars .b{border-radius:2px 2px 0 0;}
.logo-bars .b1{width:6px;height:18px;background:#C8A84B;}
.logo-bars .b2{width:6px;height:24px;background:#7ecfd8;}
.logo-bars .b3{width:6px;height:30px;background:#fff;}
.logo-bars .b4{width:6px;height:18px;background:#7ecfd8;}
.logo-text .am{font-size:1.05rem;font-weight:800;}
.logo-text .en{font-size:.72rem;color:#C8A84B;font-weight:600;letter-spacing:.1em;text-transform:uppercase;}
.brand-headline{font-size:1.9rem;font-weight:800;line-height:1.2;margin-bottom:12px;position:relative;z-index:2;}
.brand-headline span{color:#C8A84B;}
.brand-sub{font-size:.88rem;opacity:.82;line-height:1.7;margin-bottom:32px;position:relative;z-index:2;}
.features{display:flex;flex-direction:column;gap:11px;position:relative;z-index:2;}
.feat{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:12px 14px;}
.feat-ic{width:34px;height:34px;background:#C8A84B;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#1B3A5C;font-size:.85rem;flex-shrink:0;}
.feat-text{font-size:.8rem;font-weight:500;}
.brand-footer{font-size:.72rem;opacity:.5;margin-top:28px;position:relative;z-index:2;}
.form-side{flex:1;padding:50px 44px;display:flex;flex-direction:column;justify-content:center;}
.form-tag{font-size:.7rem;font-weight:700;color:#007A8A;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:9px;}
.form-title{font-size:1.6rem;font-weight:800;color:#1B3A5C;margin-bottom:5px;display:flex;align-items:center;gap:10px;}
.form-sub{font-size:.85rem;color:#64748b;margin-bottom:22px;}
.mode-badge{font-size:.65rem;font-weight:700;padding:2px 9px;border-radius:99px;}
.mode-live{background:#dcfce7;color:#15803d;}
.mode-demo{background:#fef9c3;color:#854d0e;}
.demo-box{background:linear-gradient(135deg,#e0f5f7,#f0fafb);border:1px solid #b3e4e9;border-radius:12px;padding:13px 15px;margin-bottom:20px;}
.demo-title{font-size:.7rem;font-weight:700;color:#007A8A;text-transform:uppercase;letter-spacing:.8px;margin-bottom:9px;}
.demo-row{display:grid;grid-template-columns:90px 1fr 1fr;gap:8px;padding:6px 8px;border-radius:7px;cursor:pointer;font-size:.8rem;align-items:center;transition:background .2s;}
.demo-row:hover{background:rgba(0,122,138,.12);}
.dr-role{font-weight:700;color:#1B3A5C;}
.dr-user{color:#475569;}
.dr-pass{font-family:monospace;color:#007A8A;font-size:.78rem;}
.alert-err,.alert-info{display:none;align-items:center;gap:9px;padding:11px 14px;border-radius:9px;font-size:.85rem;margin-bottom:16px;}
.alert-err.show{display:flex;background:#fee2e2;border:1px solid #fecaca;color:#991b1b;}
.alert-info.show{display:flex;background:#e0f5f7;border:1px solid #b3e4e9;color:#0e7490;}
.form-group{margin-bottom:16px;}
.form-label{display:block;font-size:.82rem;font-weight:600;color:#374151;margin-bottom:5px;}
.inp-wrap{position:relative;}
.inp-ic{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.9rem;}
.form-inp{width:100%;padding:12px 14px 12px 40px;border:2px solid #e2e8f0;border-radius:10px;font-size:.9rem;font-family:inherit;outline:none;transition:border .2s;}
.form-inp:focus{border-color:#007A8A;box-shadow:0 0 0 3px rgba(0,122,138,.1);}
.eye-btn{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#94a3b8;cursor:pointer;}
.form-foot{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
.btn-signin{width:100%;padding:14px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:11px;font-size:.95rem;font-weight:700;cursor:pointer;transition:all .3s;display:flex;align-items:center;justify-content:center;gap:9px;}
.btn-signin:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,122,138,.4);}
.btn-signin:disabled{opacity:.65;cursor:not-allowed;transform:none;}
@keyframes spin{to{transform:rotate(360deg);}}
@media(max-width:800px){.brand-side{display:none;}.form-side{padding:36px 24px;}}
