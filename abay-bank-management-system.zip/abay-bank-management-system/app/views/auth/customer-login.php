<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Customer Login — <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
<?php include VIEW_PATH . '/auth/_login_styles.php'; ?>
.demo-row .dr-role{width:130px;}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="brand-side">
    <div>
      <div class="logo-row">
        <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
        <div class="logo-text"><div class="am">ዓባይ ባንክ</div><div class="en">Abay Bank</div></div>
      </div>
      <h1 class="brand-headline">Your Money,<br><span>Your Control</span></h1>
      <p class="brand-sub">Access your accounts, transfer funds, pay loans, and manage your finances — anytime, from anywhere in Ethiopia.</p>
      <div class="features">
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-shield-halved"></i></div><span class="feat-text">PHP Session Authentication</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-arrow-right-arrow-left"></i></div><span class="feat-text">Instant Abay Bank transfers — free</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-file-lines"></i></div><span class="feat-text">Statements, receipts &amp; loan schedules</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-id-card"></i></div><span class="feat-text">Fayda KYC verification online</span></div>
      </div>
    </div>
    <div class="brand-footer">© <?= date('Y') ?> Abay Bank S.C. · NBE Licensed · SWIFT: ABYAETAA</div>
  </div>

  <div class="form-side">
    <div class="form-tag">Customer Online Banking</div>
    <h2 class="form-title">Sign In</h2>
    <p class="form-sub">Access your personal banking dashboard</p>

    <div class="demo-box">
      <div class="demo-title"><i class="fa-solid fa-circle-info"></i> Demo Credentials — click to fill</div>
      <div class="demo-row" onclick="fill('abebe.bekele','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings + Current</span><span class="dr-user">abebe.bekele</span><span class="dr-pass">Customer@1234</span></div>
      <div class="demo-row" onclick="fill('tigist.haile','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings + Loan</span><span class="dr-user">tigist.haile</span><span class="dr-pass">Customer@1234</span></div>
      <div class="demo-row" onclick="fill('solomon.girma','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings</span><span class="dr-user">solomon.girma</span><span class="dr-pass">Customer@1234</span></div>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert-err show"><i class="fa-solid fa-circle-xmark"></i><span><?= htmlspecialchars($error) ?></span></div>
    <?php endif; ?>

    <form id="login-form" method="POST" action="<?= APP_URL ?>/customer/login">
      <?= \Web\Core\View::csrfField() ?>
      <div class="form-group">
        <label class="form-label">Username / Email</label>
        <div class="inp-wrap"><i class="fa-solid fa-user inp-ic"></i>
          <input type="text" name="username" id="username" class="form-inp" placeholder="Enter username or email" autocomplete="username" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="inp-wrap"><i class="fa-solid fa-lock inp-ic"></i>
          <input type="password" name="password" id="password" class="form-inp" placeholder="Enter password" autocomplete="current-password" required>
          <button type="button" class="eye-btn" onclick="togglePwd()"><i class="fa-solid fa-eye" id="eye-ic"></i></button>
        </div>
      </div>
      <div class="form-foot">
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;color:#64748b;font-size:.82rem"><input type="checkbox" name="remember"> Keep me signed in</label>
        <a href="#" style="font-size:.82rem;color:#007A8A;font-weight:600">Forgot password?</a>
      </div>
      <button type="submit" class="btn-signin" id="signin-btn"><i class="fa-solid fa-right-to-bracket"></i><span>Sign In</span></button>
    </form>

    <div style="text-align:center;margin-top:16px;font-size:.8rem;color:#94a3b8">
      <a href="<?= APP_URL ?>/customer/register" style="color:#007A8A;font-weight:600"><i class="fa-solid fa-folder-open"></i> Open an Account</a>
      &nbsp;·&nbsp;
      <a href="<?= APP_URL ?>/login" style="color:#94a3b8"><i class="fa-solid fa-shield-halved"></i> Staff Login</a>
      &nbsp;·&nbsp;
      <a href="<?= APP_URL ?>" style="color:#94a3b8"><i class="fa-solid fa-house"></i> Website</a>
    </div>
  </div>
</div>
<script>
function fill(u,p){document.getElementById('username').value=u;document.getElementById('password').value=p;}
function togglePwd(){var i=document.getElementById('password'),ic=document.getElementById('eye-ic');i.type=i.type==='password'?'text':'password';ic.className=i.type==='password'?'fa-solid fa-eye':'fa-solid fa-eye-slash';}
document.getElementById('login-form').addEventListener('submit',function(){var btn=document.getElementById('signin-btn');btn.innerHTML='<span style="width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite;display:inline-block"></span><span>Signing in...</span>';btn.disabled=true;});
</script>
</body></html>
