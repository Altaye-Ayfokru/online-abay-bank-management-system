<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Employee Portal — <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
<?php include VIEW_PATH . '/auth/_login_styles.php'; ?>

/* Employee portal overrides */
.brand-side{background:linear-gradient(160deg,#1B3A5C,#2d6a4f)!important;}
.brand-side::before{background:radial-gradient(circle,rgba(45,106,79,.35),transparent 70%)!important;}
.feat-ic{background:#2d6a4f!important;color:#fff!important;}
.form-inp:focus{border-color:#2d6a4f!important;box-shadow:0 0 0 3px rgba(45,106,79,.12)!important;}
.btn-signin{background:linear-gradient(135deg,#1B3A5C,#2d6a4f)!important;}
.form-tag{color:#2d6a4f!important;}
.demo-box{background:linear-gradient(135deg,#ecfdf5,#f0faf4)!important;border-color:#a7f3d0!important;}
.demo-title{color:#065f46!important;}
.demo-row:hover{background:rgba(45,106,79,.1)!important;}

/* Tabs */
.auth-tabs{display:flex;background:#f1f5f9;border-radius:12px;padding:4px;margin-bottom:24px;gap:4px;}
.auth-tab{flex:1;padding:10px;border:none;background:none;border-radius:9px;font-size:.88rem;font-weight:600;cursor:pointer;color:#64748b;transition:all .2s;font-family:inherit;}
.auth-tab.active{background:#fff;color:#1B3A5C;box-shadow:0 2px 8px rgba(0,0,0,.1);}

/* Signup extras */
.form-row-2{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.strength-bar{height:4px;background:#e2e8f0;border-radius:2px;margin-top:6px;overflow:hidden;}
.strength-fill{height:100%;border-radius:2px;transition:width .3s,background .3s;}
.strength-label{font-size:.72rem;margin-top:3px;}

/* Switch link */
.switch-link{text-align:center;font-size:.82rem;color:#64748b;margin-top:16px;}
.switch-link a{color:#2d6a4f;font-weight:600;}
</style>
</head>
<body>
<div class="login-wrap">

  <!-- Left panel -->
  <div class="brand-side">
    <div>
      <div class="logo-row">
        <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
        <div class="logo-text"><div class="am">ዓባይ ባንክ</div><div class="en">Abay Bank</div></div>
      </div>
      <h1 class="brand-headline">Employee<br><span style="color:#C8A84B">Self-Service</span><br>Portal</h1>
      <p class="brand-sub">Access your payslips, attendance records, leave requests, and performance reviews — all in one place.</p>
      <div class="features">
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-id-badge"></i></div><span class="feat-text">View payslips &amp; salary history</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-calendar-check"></i></div><span class="feat-text">Check attendance &amp; apply for leave</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-chart-bar"></i></div><span class="feat-text">View performance reviews &amp; KPIs</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-graduation-cap"></i></div><span class="feat-text">Enroll in training programs</span></div>
      </div>
    </div>
    <div class="brand-footer">© <?= date('Y') ?> Abay Bank S.C. · Employee Self-Service Portal</div>
  </div>

  <!-- Right panel -->
  <div class="form-side" style="max-width:460px;width:100%;overflow-y:auto;max-height:100vh;">
    <div class="form-tag"><i class="fa-solid fa-id-badge"></i> &nbsp;Employee Portal</div>

    <!-- Tabs -->
    <div class="auth-tabs" id="auth-tabs">
      <button class="auth-tab active" onclick="switchTab('signin')" id="tab-signin">
        <i class="fa-solid fa-right-to-bracket"></i> Sign In
      </button>
      <button class="auth-tab" onclick="switchTab('signup')" id="tab-signup">
        <i class="fa-solid fa-user-plus"></i> Sign Up
      </button>
    </div>

    <!-- Demo credentials -->
    <div class="demo-box" id="demo-box">
      <div class="demo-title"><i class="fa-solid fa-circle-info"></i> Demo Credentials — click to fill</div>
      <div class="demo-row" onclick="fillDemo('abebe.girma','Employee@1234')" style="grid-template-columns:140px 1fr 1fr">
        <span class="dr-role"><i class="fa-solid fa-user-tie"></i> Sr. Teller</span>
        <span class="dr-user">abebe.girma</span><span class="dr-pass">Employee@1234</span>
      </div>
      <div class="demo-row" onclick="fillDemo('tigist.haile','Employee@1234')" style="grid-template-columns:140px 1fr 1fr">
        <span class="dr-role"><i class="fa-solid fa-user-tie"></i> Loan Officer</span>
        <span class="dr-user">tigist.haile</span><span class="dr-pass">Employee@1234</span>
      </div>
      <div class="demo-row" onclick="fillDemo('samuel.bekele','Employee@1234')" style="grid-template-columns:140px 1fr 1fr">
        <span class="dr-role"><i class="fa-solid fa-user-tie"></i> IT Staff</span>
        <span class="dr-user">samuel.bekele</span><span class="dr-pass">Employee@1234</span>
      </div>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert-err show"><i class="fa-solid fa-circle-xmark"></i><span><?= htmlspecialchars($error) ?></span></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
    <div class="alert-info show"><i class="fa-solid fa-circle-check"></i><span><?= htmlspecialchars($success) ?></span></div>
    <?php endif; ?>

    <!-- ── SIGN IN FORM ── -->
    <div id="panel-signin">
      <h2 class="form-title">Welcome Back</h2>
      <p class="form-sub">Sign in to your employee account</p>
      <form method="POST" action="<?= APP_URL ?>/employee/login" id="signin-form">
        <?= \Web\Core\View::csrfField() ?>
        <input type="hidden" name="_form" value="signin">
        <div class="form-group">
          <label class="form-label">Employee ID / Username</label>
          <div class="inp-wrap">
            <i class="fa-solid fa-id-badge inp-ic"></i>
            <input type="text" name="username" id="si-username" class="form-inp"
                   placeholder="e.g. abebe.girma or EMP-001234" required autocomplete="username">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="inp-wrap">
            <i class="fa-solid fa-lock inp-ic"></i>
            <input type="password" name="password" id="si-password" class="form-inp"
                   placeholder="Enter your password" required autocomplete="current-password">
            <button type="button" class="eye-btn" onclick="togglePw('si-password',this)">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>
        </div>
        <div class="form-foot">
          <label style="display:flex;align-items:center;gap:7px;font-size:.82rem;cursor:pointer">
            <input type="checkbox" name="remember"> Remember me
          </label>
          <a href="<?= APP_URL ?>/forgot-password" style="font-size:.82rem;color:#2d6a4f;font-weight:600">Forgot password?</a>
        </div>
        <button type="submit" class="btn-signin" id="signin-btn">
          <i class="fa-solid fa-right-to-bracket"></i> Sign In
        </button>
      </form>
      <div class="switch-link">Don't have an account? <a href="#" onclick="switchTab('signup');return false">Sign Up</a></div>
    </div>

    <!-- ── SIGN UP FORM ── -->
    <div id="panel-signup" style="display:none">
      <h2 class="form-title">Create Account</h2>
      <p class="form-sub">Register with your employee ID to get started</p>
      <form method="POST" action="<?= APP_URL ?>/employee/register" id="signup-form">
        <?= \Web\Core\View::csrfField() ?>
        <input type="hidden" name="_form" value="signup">
        <div class="form-row-2">
          <div class="form-group">
            <label class="form-label">First Name <span style="color:#ef4444">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-user inp-ic"></i>
              <input type="text" name="first_name" class="form-inp" placeholder="Abebe" required style="padding-left:38px">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Last Name <span style="color:#ef4444">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-user inp-ic"></i>
              <input type="text" name="last_name" class="form-inp" placeholder="Girma" required style="padding-left:38px">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Employee ID <span style="color:#ef4444">*</span></label>
          <div class="inp-wrap">
            <i class="fa-solid fa-id-card inp-ic"></i>
            <input type="text" name="employee_id" class="form-inp"
                   placeholder="e.g. EMP-001234" required pattern="EMP-\d{6}" title="Format: EMP-123456">
          </div>
          <p style="font-size:.73rem;color:#94a3b8;margin-top:4px">Your Employee ID is on your ID badge (format: EMP-XXXXXX)</p>
        </div>
        <div class="form-group">
          <label class="form-label">Work Email <span style="color:#ef4444">*</span></label>
          <div class="inp-wrap">
            <i class="fa-solid fa-envelope inp-ic"></i>
            <input type="email" name="email" class="form-inp" placeholder="yourname@abaybank.com" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Username <span style="color:#ef4444">*</span></label>
          <div class="inp-wrap">
            <i class="fa-solid fa-at inp-ic"></i>
            <input type="text" name="username" class="form-inp"
                   placeholder="firstname.lastname" required minlength="4"
                   oninput="checkUsername(this.value)">
          </div>
          <p id="username-msg" style="font-size:.73rem;margin-top:4px;color:#94a3b8"></p>
        </div>
        <div class="form-group">
          <label class="form-label">Password <span style="color:#ef4444">*</span></label>
          <div class="inp-wrap">
            <i class="fa-solid fa-lock inp-ic"></i>
            <input type="password" name="password" id="su-password" class="form-inp"
                   placeholder="Min. 8 characters" required minlength="8"
                   oninput="checkStrength(this.value)">
            <button type="button" class="eye-btn" onclick="togglePw('su-password',this)">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>
          <div class="strength-bar"><div class="strength-fill" id="str-fill" style="width:0%"></div></div>
          <p class="strength-label" id="str-label" style="color:#94a3b8"></p>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password <span style="color:#ef4444">*</span></label>
          <div class="inp-wrap">
            <i class="fa-solid fa-lock inp-ic"></i>
            <input type="password" name="confirm_password" id="su-confirm" class="form-inp"
                   placeholder="Repeat your password" required
                   oninput="checkMatch()">
          </div>
          <p id="match-msg" style="font-size:.73rem;margin-top:4px"></p>
        </div>
        <div style="background:#fef9c3;border:1px solid #fde68a;border-radius:9px;padding:12px 14px;margin-bottom:16px;font-size:.8rem;color:#78350f">
          <i class="fa-solid fa-triangle-exclamation" style="color:#d97706;margin-right:6px"></i>
          Your Employee ID will be verified against bank records. If not found, registration will be rejected.
        </div>
        <button type="submit" class="btn-signin" id="signup-btn" style="background:linear-gradient(135deg,#1B3A5C,#2d6a4f)!important">
          <i class="fa-solid fa-user-plus"></i> Create Account
        </button>
      </form>
      <div class="switch-link">Already have an account? <a href="#" onclick="switchTab('signin');return false">Sign In</a></div>
    </div>

    <div style="text-align:center;margin-top:24px;padding-top:20px;border-top:1px solid #f1f5f9">
      <a href="<?= APP_URL ?>/" style="font-size:.8rem;color:#94a3b8;display:inline-flex;align-items:center;gap:6px">
        <i class="fa-solid fa-arrow-left"></i> Back to Home
      </a>
      <span style="margin:0 12px;color:#e2e8f0">|</span>
      <a href="<?= APP_URL ?>/login" style="font-size:.8rem;color:#94a3b8;display:inline-flex;align-items:center;gap:6px">
        <i class="fa-solid fa-shield-halved"></i> Staff Portal
      </a>
      <span style="margin:0 12px;color:#e2e8f0">|</span>
      <a href="<?= APP_URL ?>/customer/login" style="font-size:.8rem;color:#94a3b8;display:inline-flex;align-items:center;gap:6px">
        <i class="fa-solid fa-user"></i> Customer Portal
      </a>
    </div>
  </div>
</div>

<script>
// Switch between sign-in and sign-up tabs
function switchTab(tab) {
  var isSignin = tab === 'signin';
  document.getElementById('panel-signin').style.display = isSignin ? '' : 'none';
  document.getElementById('panel-signup').style.display = isSignin ? 'none' : '';
  document.getElementById('demo-box').style.display     = isSignin ? '' : 'none';
  document.getElementById('tab-signin').className = 'auth-tab' + (isSignin ? ' active' : '');
  document.getElementById('tab-signup').className = 'auth-tab' + (!isSignin ? ' active' : '');
}

// Fill demo credentials
function fillDemo(u, p) {
  document.getElementById('si-username').value = u;
  document.getElementById('si-password').value = p;
  document.getElementById('si-username').focus();
}

// Toggle password visibility
function togglePw(id, btn) {
  var inp = document.getElementById(id);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.querySelector('i').className = 'fa-solid ' + (inp.type === 'password' ? 'fa-eye' : 'fa-eye-slash');
}

// Password strength
function checkStrength(v) {
  var score = 0;
  if (v.length >= 8) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^a-zA-Z0-9]/.test(v)) score++;
  var colors = ['','#ef4444','#f59e0b','#3b82f6','#22c55e'];
  var labels = ['','Weak','Fair','Good','Strong'];
  var fill  = document.getElementById('str-fill');
  var label = document.getElementById('str-label');
  fill.style.width = (score * 25) + '%';
  fill.style.background = colors[score] || '#e2e8f0';
  label.textContent = labels[score] || '';
  label.style.color = colors[score] || '#94a3b8';
}

// Password match
function checkMatch() {
  var pw  = document.getElementById('su-password').value;
  var cf  = document.getElementById('su-confirm').value;
  var msg = document.getElementById('match-msg');
  if (!cf) { msg.textContent = ''; return; }
  msg.textContent = pw === cf ? '✓ Passwords match' : '✗ Passwords do not match';
  msg.style.color = pw === cf ? '#22c55e' : '#ef4444';
}

// Username availability check
var _unTimer;
function checkUsername(v) {
  var msg = document.getElementById('username-msg');
  if (v.length < 4) { msg.textContent = ''; return; }
  msg.textContent = 'Checking...'; msg.style.color = '#94a3b8';
  clearTimeout(_unTimer);
  _unTimer = setTimeout(function() {
    // Demo: always available
    msg.textContent = '✓ Username available';
    msg.style.color = '#22c55e';
  }, 600);
}

// Form loading states
document.getElementById('signin-form').addEventListener('submit', function() {
  var btn = document.getElementById('signin-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Signing in...';
});
document.getElementById('signup-form').addEventListener('submit', function(e) {
  var pw = document.getElementById('su-password').value;
  var cf = document.getElementById('su-confirm').value;
  if (pw !== cf) { e.preventDefault(); alert('Passwords do not match'); return; }
  var btn = document.getElementById('signup-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Creating account...';
});

// Check for tab param in URL
var params = new URLSearchParams(location.search);
if (params.get('tab') === 'signup') switchTab('signup');
</script>
</body>
</html>
