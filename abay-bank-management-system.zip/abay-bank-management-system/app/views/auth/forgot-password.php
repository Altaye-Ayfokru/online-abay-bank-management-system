<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Forgot Password — <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
<?php include VIEW_PATH . '/auth/_login_styles.php'; ?>
</style>
</head>
<body>
<div class="login-wrap" style="max-width:560px">
  <div class="form-side" style="flex:1">
    <div class="logo-row" style="margin-bottom:24px">
      <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
      <div class="logo-text"><div class="am">ዓባይ ባንክ</div><div class="en">Abay Bank</div></div>
    </div>
    <div class="form-tag">Password Reset</div>
    <h2 class="form-title">Forgot Password?</h2>
    <p class="form-sub">Enter your email address and we will send you a reset link.</p>

    <?php if (!empty($message)): ?>
    <div class="alert-info show"><i class="fa-solid fa-circle-check"></i><span><?= htmlspecialchars($message) ?></span></div>
    <?php endif; ?>

    <form method="POST" action="<?= APP_URL ?>/forgot-password">
      <?= \Web\Core\View::csrfField() ?>
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="inp-wrap"><i class="fa-solid fa-envelope inp-ic"></i>
          <input type="email" name="email" class="form-inp" placeholder="your@email.com" required autocomplete="email">
        </div>
      </div>
      <button type="submit" class="btn-signin"><i class="fa-solid fa-paper-plane"></i><span>Send Reset Link</span></button>
    </form>
    <div style="text-align:center;margin-top:16px;font-size:.83rem">
      <a href="<?= APP_URL ?>/login" style="color:#007A8A;font-weight:600"><i class="fa-solid fa-arrow-left"></i> Back to Login</a>
    </div>
  </div>
</div>
</body></html>
