<!DOCTYPE html>
<html lang="am-ET">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Sign In — አባይ ባንክ ሻ.ኩ.</title>
  <meta name="description" content="Abay Bank Staff Management Portal — Secure Sign In">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Ethiopic:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    *,
    *::before,
    *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    :root {
      --navy: #1B3A5C;
      --navy-d: #0f2336;
      --navy-m: #254d7a;
      --teal: #007A8A;
      --teal-l: #e0f5f7;
      --gold: #C8A84B;
      --gold-l: #e8c86a;
      --g100: #f1f5f9;
      --g200: #e2e8f0;
      --g400: #94a3b8;
      --g600: #475569;
      --g700: #334155;
      --g800: #1e293b;
      --ok: #10b981;
      --err: #ef4444;
      --r: 10px;
    }

    html,
    body {
      height: 100%;
      font-family: 'Inter', sans-serif;
    }

    body {
      display: flex;
      min-height: 100vh;
      background: var(--navy-d);
      overflow-x: hidden;
    }

    /* ═══════════════════════════════════════════════════════════════
       LEFT PANEL
    ═══════════════════════════════════════════════════════════════ */
    .lp {
      flex: 1.25;
      position: relative;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      min-height: 100vh;
    }

    /* Animated gradient bg */
    .lp-bg {
      position: absolute;
      inset: 0;
      background: linear-gradient(-55deg, #071420, #1B3A5C, #004f5c, #071420);
      background-size: 400% 400%;
      animation: gradShift 16s ease infinite;
    }

    @keyframes gradShift {

      0%,
      100% {
        background-position: 0% 50%
      }

      50% {
        background-position: 100% 50%
      }
    }

    /* Background photo */
    .lp-photo {
      position: absolute;
      inset: 0;
      background: url('https://images.unsplash.com/photo-1605792657660-596af9009e82?w=1600&q=65&auto=format') center/cover no-repeat;
      opacity: .08;
    }

    /* Radial colour blobs */
    .lp-blob1 {
      position: absolute;
      top: -120px;
      right: -80px;
      width: 520px;
      height: 520px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(200, 168, 75, .18), transparent 70%);
    }

    .lp-blob2 {
      position: absolute;
      bottom: -80px;
      left: -60px;
      width: 380px;
      height: 380px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(0, 122, 138, .22), transparent 70%);
    }

    /* Floating particles */
    .lp-particles {
      position: absolute;
      inset: 0;
      overflow: hidden;
      pointer-events: none;
    }

    .pt {
      position: absolute;
      border-radius: 50%;
      animation: ptUp linear infinite;
    }

    @keyframes ptUp {
      0% {
        transform: translateY(110vh) scale(0);
        opacity: 0
      }

      8% {
        opacity: .7
      }

      92% {
        opacity: .25
      }

      100% {
        transform: translateY(-100px) scale(1.3);
        opacity: 0
      }
    }

    /* Content */
    .lp-body {
      position: relative;
      z-index: 3;
      display: flex;
      flex-direction: column;
      height: 100%;
      padding: 44px 52px;
    }

    /* ── Logo ── */
    .logo-wrap {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    /* Official Abay Bank logo mark — SVG recreation of the stacked bar chart icon */
    .logo-svg-wrap {
      width: 56px;
      height: 56px;
      background: rgba(255, 255, 255, .1);
      border: 1.5px solid rgba(255, 255, 255, .18);
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      box-shadow: 0 4px 20px rgba(0, 0, 0, .3);
    }

    .logo-text-block {
      display: flex;
      flex-direction: column;
      gap: 1px;
    }

    .logo-am {
      font-family: 'Noto Sans Ethiopic', 'Nyala', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      letter-spacing: .01em;
    }

    .logo-en {
      font-size: .58rem;
      font-weight: 700;
      color: var(--gold);
      letter-spacing: .15em;
      text-transform: uppercase;
      line-height: 1;
    }

    .logo-sub {
      font-size: .55rem;
      font-weight: 500;
      color: rgba(255, 255, 255, .45);
      letter-spacing: .08em;
      text-transform: uppercase;
    }

    /* ── Hero area ── */
    .lp-hero {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 44px 0;
    }

    .lp-eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(200, 168, 75, .14);
      border: 1px solid rgba(200, 168, 75, .32);
      color: var(--gold);
      padding: 5px 16px;
      border-radius: 99px;
      font-size: .67rem;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      margin-bottom: 24px;
      width: fit-content;
    }

    .lp-eyebrow .blink {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--gold);
      animation: blink 2s infinite;
    }

    @keyframes blink {

      0%,
      100% {
        opacity: 1;
        transform: scale(1)
      }

      50% {
        opacity: .25;
        transform: scale(.55)
      }
    }

    .lp-headline {
      font-size: 3rem;
      font-weight: 900;
      color: #fff;
      line-height: 1.06;
      letter-spacing: -.03em;
      margin-bottom: 20px;
    }

    .lp-headline .hl-accent {
      color: var(--gold);
      display: block;
    }

    .lp-headline .hl-am {
      font-family: 'Noto Sans Ethiopic', sans-serif;
      font-size: 1.9rem;
      font-weight: 700;
      display: block;
      color: rgba(255, 255, 255, .55);
      margin-top: 4px;
    }

    .lp-lead {
      font-size: .96rem;
      color: rgba(255, 255, 255, .65);
      line-height: 1.8;
      max-width: 430px;
      margin-bottom: 38px;
    }

    .lp-lead strong {
      color: var(--gold);
      font-weight: 600;
    }

    /* Stats strip */
    .lp-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      border: 1px solid rgba(255, 255, 255, .1);
      border-radius: 16px;
      overflow: hidden;
      background: rgba(255, 255, 255, .045);
      backdrop-filter: blur(6px);
      margin-bottom: 28px;
    }

    .ls {
      padding: 18px 14px;
      text-align: center;
      border-right: 1px solid rgba(255, 255, 255, .07);
    }

    .ls:last-child {
      border-right: none;
    }

    .ls .n {
      font-size: 1.85rem;
      font-weight: 900;
      color: var(--gold);
      line-height: 1;
    }

    .ls .l {
      font-size: .6rem;
      color: rgba(255, 255, 255, .45);
      text-transform: uppercase;
      letter-spacing: .7px;
      margin-top: 5px;
    }

    /* Trust badges */
    .lp-trust {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }

    .lp-badge {
      display: flex;
      align-items: center;
      gap: 7px;
      background: rgba(255, 255, 255, .06);
      border: 1px solid rgba(255, 255, 255, .1);
      border-radius: 8px;
      padding: 6px 12px;
      font-size: .71rem;
      color: rgba(255, 255, 255, .65);
      backdrop-filter: blur(4px);
    }

    .lp-badge i {
      color: var(--gold);
      font-size: .68rem;
    }

    /* Footer */
    .lp-foot {
      border-top: 1px solid rgba(255, 255, 255, .08);
      padding-top: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: .7rem;
      color: rgba(255, 255, 255, .3);
      flex-wrap: wrap;
      gap: 8px;
    }

    .lp-foot a {
      color: rgba(255, 255, 255, .4);
      text-decoration: none;
      transition: color .2s;
    }

    .lp-foot a:hover {
      color: var(--gold);
    }

    /* ═══════════════════════════════════════════════════════════════
       RIGHT PANEL
    ═══════════════════════════════════════════════════════════════ */
    .rp {
      width: 490px;
      min-width: 360px;
      background: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 52px 46px;
      overflow-y: auto;
      position: relative;
    }

    /* Subtle top accent bar */
    .rp::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--navy), var(--teal), var(--gold));
    }

    /* Small logo in right panel for mobile fallback */
    .rp-logo {
      display: none;
      align-items: center;
      gap: 12px;
      margin-bottom: 28px;
    }

    /* Mode pill */
    .mode-pill {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 5px 14px;
      border-radius: 99px;
      font-size: .67rem;
      font-weight: 700;
      letter-spacing: .3px;
      margin-bottom: 26px;
      border: 1px solid;
      width: fit-content;
    }

    .pill-live {
      background: #dcfce7;
      border-color: #86efac;
      color: #15803d;
    }

    .pill-demo {
      background: #fef9c3;
      border-color: #fcd34d;
      color: #92400e;
    }

    .pill-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      animation: blink 2.5s infinite;
    }

    .pill-live .pill-dot {
      background: #16a34a;
    }

    .pill-demo .pill-dot {
      background: #b45309;
    }

    .rp-title {
      font-size: 1.7rem;
      font-weight: 900;
      color: var(--navy);
      letter-spacing: -.02em;
      margin-bottom: 5px;
    }

    .rp-sub {
      font-size: .84rem;
      color: var(--g600);
      line-height: 1.55;
      margin-bottom: 28px;
    }

    /* ── Demo credentials box ── */
    .demo-box {
      background: linear-gradient(135deg, #f0fbfc 0%, #e8f5f7 100%);
      border: 1px solid #b3e4e9;
      border-radius: 12px;
      padding: 13px 15px;
      margin-bottom: 24px;
    }

    .demo-hdr {
      font-size: .63rem;
      font-weight: 800;
      color: var(--teal);
      text-transform: uppercase;
      letter-spacing: 1px;
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 9px;
    }

    .demo-row {
      display: grid;
      grid-template-columns: 90px 1fr 100px;
      gap: 6px;
      padding: 6px 8px;
      border-radius: 8px;
      cursor: pointer;
      align-items: center;
      transition: background .15s;
    }

    .demo-row:hover {
      background: rgba(0, 122, 138, .1);
    }

    .dr-role {
      font-size: .75rem;
      font-weight: 700;
      color: var(--navy);
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .dr-role i {
      color: var(--teal);
      font-size: .72rem;
      width: 14px;
      text-align: center;
    }

    .dr-user {
      font-size: .73rem;
      color: var(--g600);
    }

    .dr-pass {
      font-size: .71rem;
      font-family: 'Courier New', monospace;
      color: var(--teal);
      font-weight: 700;
      text-align: right;
    }

    /* ── Alert ── */
    .alert {
      display: none;
      align-items: flex-start;
      gap: 9px;
      padding: 11px 14px;
      border-radius: 9px;
      font-size: .82rem;
      line-height: 1.5;
      margin-bottom: 16px;
      animation: fadeIn .25s ease;
    }

    .alert.show {
      display: flex;
    }

    .alert i {
      flex-shrink: 0;
      margin-top: 1px;
    }

    .alert-err {
      background: #fee2e2;
      border: 1px solid #fca5a5;
      color: #991b1b;
    }

    .alert-info {
      background: var(--teal-l);
      border: 1px solid #99d6dd;
      color: #065f76;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-6px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    /* ── Form elements ── */
    .fg {
      margin-bottom: 18px;
    }

    .fg label {
      display: block;
      font-size: .74rem;
      font-weight: 700;
      color: var(--g800);
      margin-bottom: 7px;
    }

    .fi-wrap {
      position: relative;
    }

    .fi-wrap .fi-icon {
      position: absolute;
      left: 13px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--g400);
      font-size: .8rem;
      pointer-events: none;
      transition: color .2s;
    }

    .fi-wrap:focus-within .fi-icon {
      color: var(--teal);
    }

    .fi {
      width: 100%;
      padding: 11px 42px 11px 38px;
      border: 1.5px solid var(--g200);
      border-radius: var(--r);
      font-size: .88rem;
      font-family: inherit;
      color: var(--g800);
      background: #fff;
      outline: none;
      transition: border-color .2s, box-shadow .2s;
    }

    .fi:focus {
      border-color: var(--teal);
      box-shadow: 0 0 0 3px rgba(0, 122, 138, .12);
    }

    .fi.err {
      border-color: var(--err);
      box-shadow: 0 0 0 3px rgba(239, 68, 68, .1);
    }

    .pwd-eye {
      position: absolute;
      right: 11px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: var(--g400);
      font-size: .82rem;
      padding: 5px;
      transition: color .2s;
    }

    .pwd-eye:hover {
      color: var(--teal);
    }

    /* ── Remember + forgot row ── */
    .opt-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 22px;
      font-size: .8rem;
    }

    .chk-wrap {
      display: flex;
      align-items: center;
      gap: 7px;
      cursor: pointer;
      color: var(--g600);
    }

    .chk-wrap input {
      accent-color: var(--teal);
      width: 15px;
      height: 15px;
      cursor: pointer;
    }

    .forgot {
      color: var(--teal);
      font-weight: 600;
      text-decoration: none;
      transition: color .2s;
    }

    .forgot:hover {
      color: var(--navy);
      text-decoration: underline;
    }

    /* ── Submit button ── */
    .btn-submit {
      width: 100%;
      padding: 13px 20px;
      background: linear-gradient(135deg, var(--navy) 0%, var(--teal) 100%);
      color: #fff;
      border: none;
      border-radius: var(--r);
      font-size: .92rem;
      font-weight: 700;
      font-family: inherit;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all .25s;
      box-shadow: 0 4px 18px rgba(27, 58, 92, .28);
      position: relative;
      overflow: hidden;
    }

    .btn-submit::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(135deg, var(--teal), var(--navy));
      opacity: 0;
      transition: opacity .3s;
    }

    .btn-submit:hover:not(:disabled)::after {
      opacity: 1;
    }

    .btn-submit span,
    .btn-submit i {
      position: relative;
      z-index: 1;
    }

    .btn-submit:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 8px 28px rgba(27, 58, 92, .38);
    }

    .btn-submit:active:not(:disabled) {
      transform: translateY(0);
    }

    .btn-submit:disabled {
      opacity: .65;
      cursor: not-allowed;
      transform: none;
    }

    /* Spinner */
    .spin {
      display: inline-block;
      width: 15px;
      height: 15px;
      border: 2px solid rgba(255, 255, 255, .35);
      border-top-color: #fff;
      border-radius: 50%;
      animation: rotate .7s linear infinite;
    }

    @keyframes rotate {
      to {
        transform: rotate(360deg)
      }
    }

    /* ── Divider ── */
    .divider {
      text-align: center;
      position: relative;
      font-size: .71rem;
      color: var(--g400);
      margin: 22px 0 14px;
    }

    .divider::before,
    .divider::after {
      content: '';
      position: absolute;
      top: 50%;
      height: 1px;
      background: var(--g200);
      width: calc(50% - 65px);
    }

    .divider::before {
      left: 0
    }

    .divider::after {
      right: 0
    }

    /* ── Portal links ── */
    .portal-row {
      display: flex;
      gap: 10px;
    }

    .portal-btn {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
      padding: 10px;
      border: 1.5px solid var(--g200);
      border-radius: var(--r);
      font-size: .77rem;
      font-weight: 600;
      color: var(--g600);
      text-decoration: none;
      background: #fff;
      transition: all .2s;
    }

    .portal-btn:hover {
      border-color: var(--navy);
      color: var(--navy);
      background: var(--g100);
    }

    .portal-btn i {
      color: var(--teal);
      font-size: .8rem;
    }

    /* ── Responsive ── */
    @media (max-width: 960px) {
      .lp {
        display: none;
      }

      .rp {
        width: 100%;
        min-width: 0;
        padding: 36px 28px;
      }

      .rp-logo {
        display: flex;
      }
    }

    @media (max-width: 420px) {
      .rp {
        padding: 28px 20px;
      }

      .demo-row {
        grid-template-columns: 1fr 1fr;
      }

      .dr-pass {
        display: none;
      }
    }
  </style>
</head>

<body>

  <!-- ════════════════════════════════════════════════════════════
     LEFT PANEL
════════════════════════════════════════════════════════════ -->
  <div class="lp" role="complementary" aria-hidden="true">
    <div class="lp-bg"></div>
    <div class="lp-photo"></div>
    <div class="lp-blob1"></div>
    <div class="lp-blob2"></div>
    <div class="lp-particles" id="particles"></div>

    <div class="lp-body">

      <!-- Official Abay Bank Logo -->
      <div class="logo-wrap">
        <div class="logo-svg-wrap">
          <!-- Official Abay Bank logo mark: stacked bar chart representing the Blue Nile's growth,
             rendered in the bank's brand colours: navy, teal, white and gold -->
          <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Abay Bank Logo">
            <!-- Base water-line -->
            <rect x="3" y="28" width="28" height="3" rx="1.5" fill="rgba(255,255,255,0.25)" />
            <!-- Bar 1 — gold (shortest) -->
            <rect x="4" y="20" width="5" height="8" rx="1.5" fill="#C8A84B" />
            <!-- Bar 2 — teal -->
            <rect x="11" y="14" width="5" height="14" rx="1.5" fill="#7ecfd8" />
            <!-- Bar 3 — white (tallest — the Abay / Blue Nile peak) -->
            <rect x="18" y="8" width="5" height="20" rx="1.5" fill="#ffffff" />
            <!-- Bar 4 — teal light -->
            <rect x="25" y="17" width="5" height="11" rx="1.5" fill="#5ab8c4" />
            <!-- Flowing wave accent — Blue Nile motif -->
            <path d="M3 26 Q8.5 23 14 26 Q19.5 29 25 26 Q28 24.5 31 26"
              stroke="rgba(200,168,75,0.55)" stroke-width="1.4" fill="none" stroke-linecap="round" />
          </svg>
        </div>
        <div class="logo-text-block">
          <div class="logo-am">አባይ ባንክ</div>
          <div class="logo-en">Abay Bank S.C.</div>
          <div class="logo-sub">NBE Licensed · Est. 2010</div>
        </div>
      </div>

      <!-- Hero -->
      <div class="lp-hero">
        <div class="lp-eyebrow">
          <span class="blink"></span>
          SWIFT: ABYAETAA &nbsp;·&nbsp; Addis Ababa, Ethiopia
        </div>

        <h1 class="lp-headline">
          Staff Management
          <span class="hl-accent">Portal</span>
          <span class="hl-am">የሠራተኞች አስተዳደር</span>
        </h1>

        <p class="lp-lead">
          Secure access to Abay Bank's <strong>internal management system</strong> —
          customers, accounts, loans, transactions, employees and full branch administration.
          Named after <strong>Ethiopia's Blue Nile River</strong>.
        </p>

        <div class="lp-stats">
          <div class="ls">
            <div class="n">500<span style="font-size:1.1rem">+</span></div>
            <div class="l">Branches</div>
          </div>
          <div class="ls">
            <div class="n">2M<span style="font-size:1.1rem">+</span></div>
            <div class="l">Customers</div>
          </div>
          <div class="ls">
            <div class="n">5K<span style="font-size:1.1rem">+</span></div>
            <div class="l">Staff</div>
          </div>
        </div>

        <div class="lp-trust">
          <div class="lp-badge"><i class="fa-solid fa-shield-halved"></i> SSL Encrypted</div>
          <div class="lp-badge"><i class="fa-solid fa-clock-rotate-left"></i> Session: 2h Timeout</div>
          <div class="lp-badge"><i class="fa-solid fa-key"></i> CSRF Protected</div>
          <div class="lp-badge"><i class="fa-solid fa-building-columns"></i> NBE Regulated</div>
        </div>
      </div>

      <!-- Footer -->
      <div class="lp-foot">
        <span>&copy; <?= date('Y') ?> አባይ ባንክ ሻ.ኩ. · Abay Bank S.C. All rights reserved.</span>
        <div style="display:flex;gap:18px">
          <a href="#">Privacy Policy</a>
          <a href="#">Help Desk: 8397</a>
        </div>
      </div>
    </div>
  </div>


  <!-- ════════════════════════════════════════════════════════════
     RIGHT PANEL
════════════════════════════════════════════════════════════ -->
  <div class="rp">

    <!-- Mobile-only logo -->
    <div class="rp-logo">
      <svg width="36" height="36" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="28" width="28" height="3" rx="1.5" fill="#e2e8f0" />
        <rect x="4" y="20" width="5" height="8" rx="1.5" fill="#C8A84B" />
        <rect x="11" y="14" width="5" height="14" rx="1.5" fill="#007A8A" />
        <rect x="18" y="8" width="5" height="20" rx="1.5" fill="#1B3A5C" />
        <rect x="25" y="17" width="5" height="11" rx="1.5" fill="#5ab8c4" />
      </svg>
      <div>
        <div style="font-family:'Noto Sans Ethiopic',sans-serif;font-size:1rem;font-weight:800;color:var(--navy)">አባይ ባንክ</div>
        <div style="font-size:.58rem;font-weight:700;color:var(--gold);letter-spacing:.12em;text-transform:uppercase">Abay Bank S.C.</div>
      </div>
    </div>

    <?php
    /* DB connectivity check — determines mode pill */
    $dbOnline = false;
    try {
      \App\Config\Database::getInstance()->getConnection();
      $dbOnline = true;
    } catch (\Throwable $_) {
    }
    ?>

    <!-- Mode indicator -->
    <div class="mode-pill <?= $dbOnline ? 'pill-live' : 'pill-demo' ?>">
      <span class="pill-dot"></span>
      <?= $dbOnline
        ? '<i class="fa-solid fa-circle-check" style="font-size:.65rem"></i> Live Database Connected'
        : '<i class="fa-solid fa-flask" style="font-size:.65rem"></i> Demo Mode — No Database' ?>
    </div>

    <h1 class="rp-title">Welcome back</h1>
    <p class="rp-sub">Sign in to your Abay Bank staff account.<br>Admin accounts have full system access.</p>

    <!-- Error alert (server-side flash + JS-populated) -->
    <?php $flashErr = \Web\Core\Session::flash('error'); ?>
    <div class="alert alert-err <?= $flashErr ? 'show' : '' ?>" id="alert-err" role="alert">
      <i class="fa-solid fa-circle-xmark"></i>
      <span id="alert-err-msg"><?= htmlspecialchars($flashErr ?? '', ENT_QUOTES, 'UTF-8') ?></span>
    </div>
    <div class="alert alert-info" id="alert-info" role="alert">
      <i class="fa-solid fa-circle-info"></i>
      <span id="alert-info-msg"></span>
    </div>

    <!-- Demo credentials -->
    <div class="demo-box">
      <div class="demo-hdr"><i class="fa-solid fa-flask"></i> Demo Credentials — click any row to fill</div>
      <?php
      $creds = [
        ['Admin',        'fa-shield-halved',            'admin',        'Admin@1234',   '#1B3A5C'],
        ['Manager',      'fa-user-tie',                 'manager',      'Manager@1234', '#2d6a4f'],
        ['Teller',       'fa-cash-register',            'teller',       'Teller@1234',  '#007A8A'],
        ['Loan Officer', 'fa-hand-holding-dollar',      'loanofficer',  'Admin@1234',   '#b45309'],
        ['Auditor',      'fa-magnifying-glass-chart',   'auditor',      'Admin@1234',   '#6d28d9'],
        ['HR Officer',   'fa-people-group',             'hrstaff',      'Admin@1234',   '#0e7490'],
      ];
      foreach ($creds as [$role, $icon, $user, $pass, $col]): ?>
        <div class="demo-row" onclick="fillCreds('<?= $user ?>','<?= $pass ?>')" title="Click to fill — <?= $user ?> / <?= $pass ?>">
          <span class="dr-role" style="color:<?= $col ?>">
            <i class="fa-solid <?= $icon ?>" style="color:<?= $col ?>"></i> <?= $role ?>
          </span>
          <span class="dr-user"><?= $user ?></span>
          <span class="dr-pass"><?= $pass ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Login form -->
    <form id="login-form" method="POST" action="<?= APP_URL ?>/login" novalidate autocomplete="on">
      <?= \Web\Core\View::csrfField() ?>

      <div class="fg">
        <label for="username">Username or Email</label>
        <div class="fi-wrap">
          <i class="fa-solid fa-user fi-icon"></i>
          <input
            type="text" id="username" name="username" class="fi"
            placeholder="admin · manager · teller…"
            autocomplete="username" spellcheck="false"
            value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            required autofocus>
        </div>
      </div>

      <div class="fg">
        <label for="password">Password</label>
        <div class="fi-wrap">
          <i class="fa-solid fa-lock fi-icon"></i>
          <input
            type="password" id="password" name="password" class="fi"
            placeholder="Enter your password"
            autocomplete="current-password" required>
          <button type="button" class="pwd-eye" id="pwd-toggle" aria-label="Show/hide password">
            <i class="fa-solid fa-eye" id="eye-icon"></i>
          </button>
        </div>
      </div>

      <div class="opt-row">
        <label class="chk-wrap">
          <input type="checkbox" name="remember" id="remember" value="1">
          Keep me signed in
        </label>
        <a href="<?= APP_URL ?>/forgot-password" class="forgot">Forgot password?</a>
      </div>

      <button type="submit" class="btn-submit" id="login-btn">
        <i class="fa-solid fa-right-to-bracket"></i>
        <span>Sign In to Portal</span>
      </button>
    </form>

    <div class="divider">or access another portal</div>
    <div class="portal-row">
      <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="portal-btn">
        <i class="fa-solid fa-user"></i> Customer Portal
      </a>
      <a href="<?= APP_URL ?>/employee-portal/auth/login.php" class="portal-btn">
        <i class="fa-solid fa-id-badge"></i> Employee Portal
      </a>
    </div>

  </div><!-- .rp -->


  <script>
    /* ── Floating particles ── */
    (function() {
      var el = document.getElementById('particles');
      if (!el) return;
      var colors = ['#C8A84B', '#7ecfd8', 'rgba(255,255,255,.9)', '#5ab8c4', 'rgba(200,168,75,.6)'];
      for (var i = 0; i < 22; i++) {
        var p = document.createElement('div');
        p.className = 'pt';
        var sz = Math.random() * 5 + 2.5;
        var dur = Math.random() * 16 + 10;
        var del = Math.random() * 14;
        p.style.cssText = [
          'width:' + sz + 'px',
          'height:' + sz + 'px',
          'left:' + (Math.random() * 100) + '%',
          'background:' + colors[Math.floor(Math.random() * colors.length)],
          'animation-duration:' + dur + 's',
          'animation-delay:-' + del + 's',
          'opacity:.65',
        ].join(';');
        el.appendChild(p);
      }
    })();

    /* ── Fill demo credentials ── */
    function fillCreds(u, p) {
      var uf = document.getElementById('username');
      var pf = document.getElementById('password');
      uf.value = u;
      pf.value = p;
      /* Brief teal flash on fields */
      [uf, pf].forEach(function(el) {
        el.style.borderColor = '#007A8A';
        el.style.boxShadow = '0 0 0 3px rgba(0,122,138,.18)';
        setTimeout(function() {
          el.style.borderColor = '';
          el.style.boxShadow = '';
        }, 900);
      });
      uf.focus();
      /* Hide any error */
      document.getElementById('alert-err').classList.remove('show');
    }

    /* ── Toggle password visibility ── */
    document.getElementById('pwd-toggle').addEventListener('click', function() {
      var inp = document.getElementById('password');
      var ico = document.getElementById('eye-icon');
      if (inp.type === 'password') {
        inp.type = 'text';
        ico.className = 'fa-solid fa-eye-slash';
      } else {
        inp.type = 'password';
        ico.className = 'fa-solid fa-eye';
      }
    });

    /* ── Form submit: validate + spinner ── */
    document.getElementById('login-form').addEventListener('submit', function(e) {
      var u = document.getElementById('username').value.trim();
      var p = document.getElementById('password').value;
      var err = document.getElementById('alert-err');
      var msg = document.getElementById('alert-err-msg');

      err.classList.remove('show');

      if (!u) {
        e.preventDefault();
        document.getElementById('username').classList.add('err');
        msg.textContent = 'Please enter your username or email address.';
        err.classList.add('show');
        document.getElementById('username').focus();
        return;
      }
      if (!p) {
        e.preventDefault();
        document.getElementById('password').classList.add('err');
        msg.textContent = 'Please enter your password.';
        err.classList.add('show');
        document.getElementById('password').focus();
        return;
      }

      /* Show spinner */
      var btn = document.getElementById('login-btn');
      btn.disabled = true;
      btn.innerHTML = '<span class="spin"></span><span>Signing in…</span>';
    });

    /* Clear error styling on input */
    ['username', 'password'].forEach(function(id) {
      document.getElementById(id).addEventListener('input', function() {
        this.classList.remove('err');
        document.getElementById('alert-err').classList.remove('show');
      });
    });

    /* ── Auto-dismiss server-side flash error after 7s ── */
    (function() {
      var el = document.getElementById('alert-err');
      if (el && el.classList.contains('show')) {
        setTimeout(function() {
          el.style.transition = 'opacity .6s ease';
          el.style.opacity = '0';
          setTimeout(function() {
            el.classList.remove('show');
            el.style.opacity = '';
          }, 600);
        }, 7000);
      }
    })();
  </script>

</body>

</html>