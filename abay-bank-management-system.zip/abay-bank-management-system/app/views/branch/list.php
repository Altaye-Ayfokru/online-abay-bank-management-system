<?php

/** @var array $branches @var array $user */
$demoBranches = $branches ?: [
  ['id' => 1, 'branch_name' => 'Head Office', 'branch_code' => 'HQ001', 'address' => 'Bole Sub-City, Kirkos, Addis Ababa', 'manager' => 'Abebe Girma', 'phone' => '+251 11 551 2345', 'emp_count' => 42, 'acc_count' => 980, 'status' => 'Active'],
  ['id' => 2, 'branch_name' => 'Bole Branch', 'branch_code' => 'BOL001', 'address' => 'Bole Road, Addis Ababa', 'manager' => 'Tigist Haile', 'phone' => '+251 11 663 4567', 'emp_count' => 18, 'acc_count' => 420, 'status' => 'Active'],
  ['id' => 3, 'branch_name' => 'Alem Ketema Branch', 'branch_code' => 'ALEM001', 'address' => 'Main Street, Alem Ketema, North Shewa', 'manager' => 'Dawit Kebede', 'phone' => '+251 116 782 345', 'emp_count' => 12, 'acc_count' => 215, 'status' => 'Active'],
  ['id' => 3, 'branch_name' => 'Piassa Branch', 'branch_code' => 'PIA001', 'address' => 'Piassa, Arada Sub-City, Addis Ababa', 'manager' => 'Samuel Bekele', 'phone' => '+251 11 125 6789', 'emp_count' => 15, 'acc_count' => 340, 'status' => 'Active'],
  ['id' => 4, 'branch_name' => 'Arada Branch', 'branch_code' => 'ARA001', 'address' => 'Churchill Avenue, Addis Ababa', 'manager' => 'Meron Tesfaye', 'phone' => '+251 11 227 8901', 'emp_count' => 12, 'acc_count' => 290, 'status' => 'Active'],
  ['id' => 5, 'branch_name' => 'Akaki Branch', 'branch_code' => 'AKA001', 'address' => 'Akaki Kaliti Sub-City, Addis Ababa', 'manager' => 'Dawit Alemu', 'phone' => '+251 11 439 0123', 'emp_count' => 10, 'acc_count' => 220, 'status' => 'Active'],
  ['id' => 6, 'branch_name' => 'Bishoftu Branch', 'branch_code' => 'BSH001', 'address' => 'Debre Zeit Road, Bishoftu', 'manager' => 'Hana Mulugeta', 'phone' => '+251 11 332 4560', 'emp_count' => 8, 'acc_count' => 150, 'status' => 'Active'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-building" style="color:var(--primary)"></i> Branch Network</h1>
    <p class="page-subtitle">Manage all Abay Bank branches and their details</p>
  </div>
  <div class="page-actions">
    <a href="<?= APP_URL ?>/branches/performance" class="btn btn-outline"><i class="fa-solid fa-chart-bar"></i> Performance</a>
    <button class="btn btn-primary" onclick="document.getElementById('branch-modal').classList.add('active')"><i class="fa-solid fa-plus"></i> Add Branch</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoBranches), 'Total Branches', 'fa-building', '#6366f1'],
    [array_sum(array_column($demoBranches, 'emp_count')), 'Total Employees', 'fa-people-group', '#3b82f6'],
    [array_sum(array_column($demoBranches, 'acc_count')), 'Total Accounts', 'fa-building-columns', '#22c55e'],
    [count(array_filter($demoBranches, fn($b) => $b['status'] === 'Active')), 'Active', 'fa-circle-check', '#10b981'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Branch Cards -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px;margin-bottom:24px">
  <?php foreach ($demoBranches as $b): ?>
    <div class="card">
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px">
          <div style="display:flex;gap:12px;align-items:center">
            <div style="width:46px;height:46px;background:var(--primary-light);border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fa-solid fa-building" style="color:var(--primary);font-size:1.2rem"></i>
            </div>
            <div>
              <div class="fw-semibold" style="font-size:.95rem"><?= htmlspecialchars($b['branch_name']) ?></div>
              <div class="text-muted" style="font-size:.78rem;font-family:monospace"><?= $b['branch_code'] ?></div>
            </div>
          </div>
          <span class="badge badge-success">Active</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:16px;font-size:.83rem">
          <div style="display:flex;gap:8px">
            <i class="fa-solid fa-location-dot text-muted" style="width:16px"></i>
            <span class="text-muted"><?= htmlspecialchars($b['address']) ?></span>
          </div>
          <div style="display:flex;gap:8px">
            <i class="fa-solid fa-phone text-muted" style="width:16px"></i>
            <span><?= htmlspecialchars($b['phone']) ?></span>
          </div>
          <div style="display:flex;gap:8px">
            <i class="fa-solid fa-user-tie text-muted" style="width:16px"></i>
            <span><?= htmlspecialchars($b['manager']) ?></span>
          </div>
        </div>
        <div style="display:flex;gap:16px;margin-bottom:14px">
          <div style="flex:1;background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold" style="font-size:1.1rem"><?= $b['emp_count'] ?></div>
            <div class="text-muted" style="font-size:.75rem">Staff</div>
          </div>
          <div style="flex:1;background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold" style="font-size:1.1rem"><?= $b['acc_count'] ?></div>
            <div class="text-muted" style="font-size:.75rem">Accounts</div>
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm btn-outline" style="flex:1" onclick="ABAY.toast('Viewing <?= addslashes($b['branch_name']) ?> details','info')">
            <i class="fa-solid fa-eye"></i> View
          </button>
          <button class="btn btn-sm btn-primary" style="flex:1" onclick="ABAY.toast('Edit branch','info')">
            <i class="fa-solid fa-pen"></i> Edit
          </button>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Add Branch Modal -->
<div class="modal-overlay" id="branch-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-plus"></i> Add New Branch</h3>
      <button class="modal-close" onclick="document.getElementById('branch-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="saveBranch(event)" id="branch-form">
        <div class="form-grid-2">
          <div class="form-group form-group-full">
            <label class="form-label required">Branch Name</label>
            <input type="text" id="br-name" class="form-control" placeholder="e.g. Sarbet Branch" required>
          </div>
          <div class="form-group">
            <label class="form-label required">Branch Code</label>
            <input type="text" id="br-code" class="form-control" placeholder="e.g. SAR001" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="tel" id="br-phone" class="form-control" placeholder="+251 ...">
          </div>
          <div class="form-group form-group-full">
            <label class="form-label required">Address</label>
            <input type="text" id="br-addr" class="form-control" placeholder="Full address" required>
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Branch Manager</label>
            <input type="text" id="br-mgr" class="form-control" placeholder="Manager name">
          </div>
          <div class="form-group">
            <label class="form-label">Opening Date</label>
            <input type="date" id="br-date" class="form-control" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">City / Region</label>
            <input type="text" id="br-city" class="form-control" placeholder="e.g. Addis Ababa">
          </div>
        </div>
        <div id="br-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:10px 14px;margin-top:10px;font-size:.84rem;color:#065f46"><i class="fa-solid fa-circle-check"></i> <span id="br-ok-msg"></span></div>
        <div id="br-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-top:10px;font-size:.84rem;color:#991b1b"><i class="fa-solid fa-circle-xmark"></i> <span id="br-err-msg"></span></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('branch-modal').classList.remove('active')">Cancel</button>
          <button type="submit" id="br-submit-btn" class="btn btn-primary">Add Branch</button>
        </div>
      </form>
    </div>
    <button type="submit" class="btn btn-primary">Add Branch</button>
  </div>
  </form>
</div>
</div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function saveBranch(e) {
    e.preventDefault();
    var name = document.getElementById('br-name').value.trim();
    var code = document.getElementById('br-code').value.trim();
    var phone = document.getElementById('br-phone').value.trim();
    var addr = document.getElementById('br-addr').value.trim();
    var mgr = document.getElementById('br-mgr').value.trim();
    var city = document.getElementById('br-city').value.trim();

    document.getElementById('br-err').style.display = 'none';
    document.getElementById('br-ok').style.display = 'none';

    if (!name) {
      showBrErr('Branch name is required.');
      return;
    }
    if (!code) {
      showBrErr('Branch code is required.');
      return;
    }
    if (!addr) {
      showBrErr('Address is required.');
      return;
    }

    var btn = document.getElementById('br-submit-btn');
    ABAY.setBtn(btn, true, 'Saving…');

    ABAY.api('/branches', {
      method: 'POST',
      body: JSON.stringify({
        branch_name: name,
        branch_code: code,
        phone: phone,
        address: addr,
        manager: mgr,
        city: city
      })
    }).then(function(d) {
      ABAY.setBtn(btn, false, 'Add Branch');
      if (d && d.success) {
        document.getElementById('br-ok-msg').textContent = 'Branch "' + name + '" added successfully!';
        document.getElementById('br-ok').style.display = 'block';
        ABAY.toast('Branch "' + name + '" added!', 'success');
        setTimeout(function() {
          document.getElementById('branch-modal').classList.remove('active');
          location.reload();
        }, 1200);
      } else {
        showBrErr((d && d.message) || 'Failed to add branch.');
      }
    }).catch(function() {
      ABAY.setBtn(btn, false, 'Add Branch');
      document.getElementById('br-ok-msg').textContent = 'Demo: Branch "' + name + '" recorded (Database offline).';
      document.getElementById('br-ok').style.display = 'block';
      ABAY.toast('Demo: Branch "' + name + '" recorded.', 'info');
      setTimeout(function() {
        document.getElementById('branch-modal').classList.remove('active');
      }, 1200);
    });
  }

  function showBrErr(msg) {
    document.getElementById('br-err-msg').textContent = msg;
    document.getElementById('br-err').style.display = 'block';
  }
</script>