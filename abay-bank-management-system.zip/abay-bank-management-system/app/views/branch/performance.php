<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-chart-bar" style="color:var(--primary)"></i> Branch Performance</h1>
    <p class="page-subtitle">Compare branch KPIs, revenue, and growth metrics</p>
  </div>
  <div class="page-actions">
    <select class="form-control form-control-sm" style="width:145px">
      <option>This Month</option>
      <option>This Quarter</option>
      <option>This Year</option>
    </select>
    <button class="btn btn-primary" onclick="ABAY.toast('Branch performance report exported','success')"><i class="fa-solid fa-download"></i> Export</button>
  </div>
</div>

<!-- Branch KPI Summary -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;margin-bottom:24px">
  <?php
  $branchData = [
    ['HQ', 'Head Office', '+15.2%', 'ETB 4.2M', '980', '42', '#6366f1', 94],
    ['BOL', 'Bole Branch', '+12.8%', 'ETB 2.8M', '420', '18', '#3b82f6', 88],
      ['ALEM', 'Alem Ketema Branch', '+9.4%', 'ETB 1.1M', '215', '12', '#10b981', 81],
    ['PIA', 'Piassa Branch', '+8.4%', 'ETB 1.9M', '340', '15', '#22c55e', 81],
    ['ARA', 'Arada Branch', '+6.1%', 'ETB 1.4M', '290', '12', '#f59e0b', 75],
    ['AKA', 'Akaki Branch', '+5.3%', 'ETB 0.9M', '220', '10', '#10b981', 70],
    ['BSH', 'Bishoftu Branch', '+4.2%', 'ETB 0.6M', '150', '8', '#ef4444', 65],
  ];
  foreach ($branchData as [$code, $name, $growth, $rev, $accs, $staff, $color, $score]):
    $scoreColor = $score >= 90 ? '#22c55e' : ($score >= 75 ? '#3b82f6' : '#f59e0b');
  ?>
    <div class="card" style="border-top:3px solid <?= $color ?>">
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <div>
            <span class="fw-semibold" style="font-size:.95rem"><?= $name ?></span>
            <span class="text-muted" style="font-size:.78rem;display:block"><?= $code ?></span>
          </div>
          <div style="width:48px;height:48px;border-radius:50%;border:3px solid <?= $scoreColor ?>;display:flex;align-items:center;justify-content:center;font-weight:700;color:<?= $scoreColor ?>;font-size:.9rem"><?= $score ?></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
          <div style="background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold"><?= $rev ?></div>
            <div class="text-muted" style="font-size:.75rem">Revenue</div>
          </div>
          <div style="background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold"><?= $accs ?></div>
            <div class="text-muted" style="font-size:.75rem">Accounts</div>
          </div>
          <div style="background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold"><?= $staff ?></div>
            <div class="text-muted" style="font-size:.75rem">Staff</div>
          </div>
          <div style="background:var(--surface);padding:10px;border-radius:8px;text-align:center">
            <div class="fw-semibold" style="color:#22c55e"><?= $growth ?></div>
            <div class="text-muted" style="font-size:.75rem">Growth</div>
          </div>
        </div>
        <div style="height:5px;background:#e5e7eb;border-radius:3px">
          <div style="width:<?= $score ?>%;height:100%;background:<?= $color ?>;border-radius:3px"></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Charts -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Revenue by Branch</h3>
    </div>
    <div class="card-body"><canvas id="branch-rev-chart" height="260"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Accounts & Customers Growth</h3>
    </div>
    <div class="card-body"><canvas id="branch-accts-chart" height="260"></canvas></div>
  </div>
</div>

<!-- Performance Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Detailed Comparison</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Branch</th>
            <th>Revenue</th>
            <th>Accounts</th>
            <th>New Customers</th>
            <th>Loans</th>
            <th>NPS Score</th>
            <th>Performance</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $rows = [
            ['Head Office', 'ETB 4.2M', 980, 45, 28, 92, 'Excellent'],
            ['Bole Branch', 'ETB 2.8M', 420, 32, 18, 88, 'Excellent'],
        ['Alem Ketema Branch', 'ETB 1.1M', 215, 18, 12, 81, 'Good'],
            ['Piassa Branch', 'ETB 1.9M', 340, 20, 12, 81, 'Good'],
            ['Arada Branch', 'ETB 1.4M', 290, 14, 8, 75, 'Good'],
            ['Akaki Branch', 'ETB 0.9M', 220, 10, 5, 70, 'Average'],
            ['Bishoftu Branch', 'ETB 0.6M', 150, 7, 3, 65, 'Average'],
          ];
          foreach ($rows as [$br, $rev, $acc, $nc, $ln, $nps, $perf]):
            $pc = match ($perf) {
              'Excellent' => 'badge-success',
              'Good' => 'badge-info',
              default => 'badge-warning'
            };
          ?>
            <tr>
              <td class="fw-semibold"><?= $br ?></td>
              <td class="text-primary fw-semibold"><?= $rev ?></td>
              <td><?= $acc ?></td>
              <td><span class="text-success">+<?= $nc ?></span></td>
              <td><?= $ln ?></td>
              <td><span class="fw-semibold"><?= $nps ?>/100</span></td>
              <td><span class="badge <?= $pc ?>"><?= $perf ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    const branches = ['HQ', 'Bole', 'Piassa', 'Arada', 'Akaki', 'Bishoftu'];
    const colors = ['#6366f1', '#3b82f6', '#22c55e', '#f59e0b', '#10b981', '#ef4444'];

    new Chart(document.getElementById('branch-rev-chart'), {
      type: 'bar',
      data: {
        labels: branches,
        datasets: [{
          label: 'Revenue (ETB M)',
          data: [4.2, 2.8, 1.9, 1.4, 0.9, 0.6],
          backgroundColor: colors,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });

    new Chart(document.getElementById('branch-accts-chart'), {
      type: 'bar',
      data: {
        labels: branches,
        datasets: [{
            label: 'Accounts',
            data: [980, 420, 340, 290, 220, 150],
            backgroundColor: colors.map(c => c + '90'),
            borderRadius: 4
          },
          {
            label: 'New Customers',
            data: [45, 32, 20, 14, 10, 7],
            backgroundColor: colors,
            borderRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>