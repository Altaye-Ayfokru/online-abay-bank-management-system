<?php $pageTitle = 'Apply for Card — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-credit-card" style="color:#1B3A5C;margin-right:8px"></i>Issue / Apply for Card</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/cards">Cards</a><span class="sep">/</span><span>Apply</span></div>
  </div>
  <a href="<?= APP_URL ?>/cards" class="btn btn-ghost btn-sm"><i class="fa-solid fa-arrow-left"></i> Back to Cards</a>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px">
  <div>
    <div id="apply-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:12px;padding:20px;margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:12px"><i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.5rem"></i>
        <div><div style="font-weight:800;color:#065f46;font-size:1rem">Card Application Submitted!</div><div style="font-size:.84rem;color:#047857" id="apply-ok-msg"></div></div></div>
      <div style="margin-top:14px;display:flex;gap:10px">
        <a href="<?= APP_URL ?>/cards" class="btn btn-ghost btn-sm"><i class="fa-solid fa-list"></i> All Cards</a>
        <button onclick="resetApplyForm()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-plus"></i> New Application</button>
      </div>
    </div>
    <div id="apply-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:13px;margin-bottom:16px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px"><i class="fa-solid fa-circle-xmark"></i><span id="apply-err-msg"></span></div>

    <form id="card-apply-form" novalidate>
      <!-- Card Type Selection -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header"><h3><i class="fa-solid fa-layer-group" style="color:#1B3A5C;margin-right:7px"></i>Select Card Type</h3></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px">
            <?php foreach([
              ['visa_debit',   'fa-cc-visa',       'Visa Debit',    'Physical card for ATM & POS','Free issuance · ETB 50/yr'],
              ['mastercard',   'fa-cc-mastercard', 'Mastercard',    'Physical Mastercard debit', 'ETB 75 issuance · ETB 75/yr'],
              ['visa_virtual', 'fa-credit-card',   'Virtual Card',  'Online payments only',      'Free · Instant issuance'],
            ] as $i => [$val,$ic,$label,$desc,$fee]): ?>
            <label style="cursor:pointer">
              <input type="radio" name="card_type" value="<?= $val ?>" <?= $i===0?'checked':'' ?> style="display:none" onchange="updateCardPreview()">
              <div class="card-type-option" data-val="<?= $val ?>" style="border:2px solid <?= $i===0?'#007A8A':'#e2e8f0' ?>;border-radius:12px;padding:16px;text-align:center;transition:all .25s" onclick="selectCardType('<?= $val ?>',this)">
                <i class="fa-brands <?= $ic ?>" style="font-size:2rem;color:#1B3A5C;margin-bottom:8px;display:block"></i>
                <div style="font-size:.88rem;font-weight:700;color:#1B3A5C;margin-bottom:4px"><?= $label ?></div>
                <div style="font-size:.74rem;color:#64748b;margin-bottom:6px"><?= $desc ?></div>
                <div style="font-size:.7rem;background:#f1f5f9;color:#475569;padding:3px 8px;border-radius:99px;display:inline-block"><?= $fee ?></div>
              </div>
            </label>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Customer & Account -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header"><h3><i class="fa-solid fa-user" style="color:#1B3A5C;margin-right:7px"></i>Customer & Account</h3></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Customer Name / ID <span style="color:#ef4444">*</span></label>
              <input type="text" id="card-customer" placeholder="Search customer name or ID..." list="card-cust-list" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
              <datalist id="card-cust-list">
                <?php foreach ($customers ?? [] as $c): ?><option value="<?= htmlspecialchars($c['name']??'') ?>">
                <?php endforeach; ?>
              </datalist>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Linked Account <span style="color:#ef4444">*</span></label>
              <select id="card-account" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option value="">Select account...</option>
                <?php foreach ($accounts ?? [] as $a): ?>
                <option value="<?= $a['id'] ?>" data-num="<?= htmlspecialchars($a['account_number']??'') ?>" data-bal="<?= $a['balance']??0 ?>"><?= htmlspecialchars($a['account_number']??'') ?> — <?= htmlspecialchars($a['customer_name']??'') ?> (ETB <?= number_format($a['balance']??0) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Cardholder Name <span style="color:#ef4444">*</span></label>
              <input type="text" id="card-holder-name" placeholder="Name as it will appear on card" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none;text-transform:uppercase" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'" oninput="updateCardPreview()"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Currency</label>
              <select id="card-currency" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option value="ETB" selected>ETB — Ethiopian Birr</option>
                <option value="USD">USD — US Dollar</option>
                <option value="EUR">EUR — Euro</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Card Features -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header"><h3><i class="fa-solid fa-sliders" style="color:#1B3A5C;margin-right:7px"></i>Card Features & Limits</h3></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:16px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Daily ATM Limit (ETB)</label>
              <input type="number" id="card-atm-limit" value="10000" min="1000" step="1000" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Daily POS Limit (ETB)</label>
              <input type="number" id="card-pos-limit" value="50000" min="5000" step="5000" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Online Limit (ETB)</label>
              <input type="number" id="card-online-limit" value="25000" min="1000" step="1000" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
            <?php foreach(['Enable international transactions'=>true,'Enable contactless payments'=>true,'Enable online payments'=>true,'Enable ATM withdrawals'=>true,'SMS alerts for transactions'=>true,'Email statements monthly'=>false] as $feat=>$checked): ?>
            <label style="display:flex;align-items:center;gap:9px;cursor:pointer">
              <input type="checkbox" <?= $checked?'checked':'' ?> style="accent-color:#007A8A;width:14px;height:14px">
              <span style="font-size:.82rem;font-weight:500"><?= $feat ?></span>
            </label>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:12px;justify-content:flex-end">
        <a href="<?= APP_URL ?>/cards" class="btn btn-ghost">Cancel</a>
        <button type="submit" id="apply-submit-btn" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:10px;padding:13px 32px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Submit Application</button>
      </div>
    </form>
  </div>

  <!-- Preview Panel -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <!-- Card Preview -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-eye" style="color:#1B3A5C;margin-right:6px"></i>Card Preview</h4></div>
      <div class="card-body" style="text-align:center">
        <div id="card-preview" style="background:linear-gradient(135deg,#1B3A5C,#254d7a);border-radius:14px;padding:20px;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.2);max-width:280px;margin:0 auto">
          <div style="display:flex;justify-content:space-between;margin-bottom:10px">
            <span style="font-size:.62rem;opacity:.75;font-weight:700;text-transform:uppercase;letter-spacing:.8px">Abay Bank S.C.</span>
            <i class="fa-brands fa-cc-visa" id="preview-net-icon" style="font-size:1.4rem;opacity:.9"></i>
          </div>
          <div style="width:32px;height:24px;background:rgba(255,255,255,.25);border-radius:4px;margin:8px 0"></div>
          <div style="font-size:.85rem;letter-spacing:3px;font-family:monospace;opacity:.9;margin-bottom:8px">**** **** **** ????</div>
          <div style="display:flex;justify-content:space-between">
            <div><div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Card Holder</div><div id="preview-name" style="font-size:.76rem;font-weight:700;text-transform:uppercase;margin-top:1px">YOUR NAME</div></div>
            <div style="text-align:right"><div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Expires</div><div style="font-size:.76rem;font-weight:700;margin-top:1px"><?= date('m/y', strtotime('+3 years')) ?></div></div>
          </div>
        </div>
        <div style="margin-top:12px;font-size:.8rem;color:#94a3b8">Preview updates as you type</div>
      </div>
    </div>

    <!-- Card Type Info -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-circle-info" style="color:#1B3A5C;margin-right:6px"></i>Card Benefits</h4></div>
      <div class="card-body" id="card-benefits" style="display:flex;flex-direction:column;gap:8px">
        <?php foreach(['Zero issuance fee for first card','Free ATM withdrawals at Abay Bank ATMs','Secure chip & PIN technology','Contactless payment support','24/7 card freeze/unfreeze via app','Fraud monitoring & alerts'] as $b): ?>
        <div style="display:flex;align-items:center;gap:8px;font-size:.82rem;color:#475569"><i class="fa-solid fa-circle-check" style="color:#10b981;font-size:.7rem;flex-shrink:0"></i><?= $b ?></div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
var _cardThemes = {
  'visa_debit': {bg:'linear-gradient(135deg,#1B3A5C,#254d7a)', icon:'fa-cc-visa'},
  'mastercard': {bg:'linear-gradient(135deg,#007A8A,#00a3b5)', icon:'fa-cc-mastercard'},
  'visa_virtual': {bg:'linear-gradient(135deg,#5b21b6,#7c3aed)', icon:'fa-cc-visa'}
};

function selectCardType(val, el) {
  document.querySelectorAll('.card-type-option').forEach(function(o) { o.style.border = '2px solid #e2e8f0'; });
  el.style.border = '2px solid #007A8A';
  document.querySelector('input[name="card_type"][value="' + val + '"]').checked = true;
  updateCardPreview();
}

function updateCardPreview() {
  var selected = document.querySelector('input[name="card_type"]:checked');
  var val = selected ? selected.value : 'visa_debit';
  var theme = _cardThemes[val] || _cardThemes['visa_debit'];
  var name = (document.getElementById('card-holder-name').value || 'YOUR NAME').toUpperCase();
  document.getElementById('card-preview').style.background = theme.bg;
  document.getElementById('preview-net-icon').className = 'fa-brands ' + theme.icon;
  document.getElementById('preview-name').textContent = name || 'YOUR NAME';
}

document.getElementById('card-apply-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var customer = document.getElementById('card-customer').value.trim();
  var account  = document.getElementById('card-account').value;
  var holder   = document.getElementById('card-holder-name').value.trim();
  var type     = document.querySelector('input[name="card_type"]:checked');
  document.getElementById('apply-error').style.display = 'none';
  if (!customer) { document.getElementById('apply-err-msg').textContent = 'Customer is required.'; document.getElementById('apply-error').style.display = 'flex'; return; }
  if (!holder)   { document.getElementById('apply-err-msg').textContent = 'Cardholder name is required.'; document.getElementById('apply-error').style.display = 'flex'; return; }
  ABAY.setBtn('apply-submit-btn', true);
  ABAY.api('/cards', { method: 'POST', body: JSON.stringify({
    customer: customer, account_id: account, holder_name: holder,
    card_type: type ? type.value : 'visa_debit',
    currency: document.getElementById('card-currency').value,
    atm_limit: document.getElementById('card-atm-limit').value,
    pos_limit: document.getElementById('card-pos-limit').value,
    online_limit: document.getElementById('card-online-limit').value
  })}).then(function(d) {
    ABAY.setBtn('apply-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Submit Application');
    if (d && d.success) {
      document.getElementById('apply-ok-msg').textContent = 'Card for ' + holder + ' submitted. Ref: ' + (d.data && d.data.ref ? d.data.ref : 'N/A');
      document.getElementById('apply-success').style.display = 'block'; document.getElementById('card-apply-form').style.display = 'none'; ABAY.toast('Card application submitted!', 'ok');
    } else { document.getElementById('apply-err-msg').textContent = (d && d.message) || 'Submission failed.'; document.getElementById('apply-error').style.display = 'flex'; }
  }).catch(function() {
    ABAY.setBtn('apply-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Submit Application');
    document.getElementById('apply-ok-msg').textContent = 'Demo: Card application for ' + holder + ' submitted (Database offline). Ref: CARD-' + Date.now().toString(36).toUpperCase();
    document.getElementById('apply-success').style.display = 'block'; document.getElementById('card-apply-form').style.display = 'none'; ABAY.toast('Demo card application recorded.', 'info');
  });
});

function resetApplyForm() { document.getElementById('card-apply-form').reset(); document.getElementById('card-apply-form').style.display = ''; document.getElementById('apply-success').style.display = 'none'; updateCardPreview(); }
</script>
