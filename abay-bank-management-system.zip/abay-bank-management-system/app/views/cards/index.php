<?php
$pageTitle = 'Card Management — ' . APP_NAME;
$cs = $cardStats ?? ['total'=>0,'active'=>0,'blocked'=>0,'pending'=>0];
$cardRows = $cards ?? [];
if (empty($cardRows)) {
    $cardRows = [
        ['id'=>1,'card_number'=>'**** **** **** 8421','card_type'=>'Visa Debit','account_number'=>'0001-10-100001','holder'=>'Abebe Bekele',   'balance'=>84500, 'status'=>'Active', 'issued_date'=>'2024-01-15','expiry_date'=>'12/28','theme'=>'navy'],
        ['id'=>2,'card_number'=>'**** **** **** 6241','card_type'=>'Mastercard','account_number'=>'0001-20-100002','holder'=>'Tigist Haile',    'balance'=>125000,'status'=>'Active', 'issued_date'=>'2024-02-20','expiry_date'=>'03/29','theme'=>'teal'],
        ['id'=>3,'card_number'=>'**** **** **** 3317','card_type'=>'Visa Virtual','account_number'=>'0002-10-100003','holder'=>'Solomon Girma', 'balance'=>45000, 'status'=>'Active', 'issued_date'=>'2024-03-10','expiry_date'=>'06/29','theme'=>'gold'],
        ['id'=>4,'card_number'=>'**** **** **** 9982','card_type'=>'Visa Debit','account_number'=>'0003-20-100004','holder'=>'Meron Alemu',    'balance'=>0,     'status'=>'Blocked','issued_date'=>'2023-11-01','expiry_date'=>'11/27','theme'=>'dark'],
        ['id'=>5,'card_number'=>'**** **** **** 1155','card_type'=>'Mastercard','account_number'=>'0004-10-100005','holder'=>'Dawit Mekonnen', 'balance'=>220000,'status'=>'Pending','issued_date'=>'2026-08-20','expiry_date'=>'08/30','theme'=>'purple'],
        ['id'=>6,'card_number'=>'**** **** **** 4473','card_type'=>'Visa Virtual','account_number'=>'0005-10-100006','holder'=>'Hanna Getnet', 'balance'=>98000, 'status'=>'Active', 'issued_date'=>'2024-06-01','expiry_date'=>'06/28','theme'=>'teal'],
    ];
    $cs = ['total'=>6,'active'=>4,'blocked'=>1,'pending'=>1];
}
$themes = ['navy'=>'linear-gradient(135deg,#1B3A5C,#254d7a)','teal'=>'linear-gradient(135deg,#007A8A,#00a3b5)','gold'=>'linear-gradient(135deg,#92400e,#C8A84B)','dark'=>'linear-gradient(135deg,#1e293b,#475569)','purple'=>'linear-gradient(135deg,#5b21b6,#7c3aed)'];
?>
<style>
.vc-flip-scene{width:100%;height:185px;perspective:1000px;cursor:pointer;user-select:none}
.vc-flip-inner{width:100%;height:100%;position:relative;transform-style:preserve-3d;transition:transform .65s cubic-bezier(.4,0,.2,1)}
.vc-flip-inner.flipped{transform:rotateY(180deg)}
.vc-face{position:absolute;inset:0;border-radius:16px;backface-visibility:hidden;-webkit-backface-visibility:hidden;overflow:hidden;box-shadow:0 12px 32px rgba(0,0,0,.25)}
.vc-front{padding:20px;display:flex;flex-direction:column;justify-content:space-between;color:#fff}
.vc-back{transform:rotateY(180deg);background:linear-gradient(135deg,#1e293b,#334155)}
.vc-chip{width:34px;height:26px;background:linear-gradient(135deg,rgba(255,255,255,.3),rgba(255,255,255,.15));border-radius:4px;margin:8px 0}
.vc-num{font-size:.88rem;letter-spacing:3px;font-family:'Courier New',monospace;opacity:.9;margin-bottom:8px}
.vc-back-stripe{height:42px;background:rgba(0,0,0,.5);margin:22px 0 16px}
.vc-sig{height:32px;background:linear-gradient(90deg,#f1f5f9,#fff);border-radius:4px;display:flex;align-items:center;justify-content:flex-end;padding:0 10px;gap:8px;margin:0 16px}
.vc-cvv{font-size:.88rem;font-weight:900;color:#1e293b;font-family:'Courier New',monospace}
.vc-back-info{padding:0 16px;display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px}
.vc-bi-l{font-size:.58rem;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.5px}
.vc-bi-v{font-size:.7rem;color:rgba(255,255,255,.85);font-weight:600;margin-top:1px}
</style>

<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-credit-card" style="color:#1B3A5C;margin-right:8px"></i>Card Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Cards</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <a href="<?= APP_URL ?>/cards/virtual" class="btn btn-ghost btn-sm"><i class="fa-solid fa-layer-group"></i> Virtual Cards</a>
    <a href="<?= APP_URL ?>/cards/apply" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Issue New Card</a>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-credit-card"></i></div><div class="stat-content"><div class="stat-label">Total Cards</div><div class="stat-value"><?= $cs['total'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div><div class="stat-content"><div class="stat-label">Active</div><div class="stat-value"><?= $cs['active'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red"><i class="fa-solid fa-ban"></i></div><div class="stat-content"><div class="stat-label">Blocked</div><div class="stat-value"><?= $cs['blocked'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div><div class="stat-content"><div class="stat-label">Pending</div><div class="stat-value"><?= $cs['pending'] ?></div></div></div>
</div>

<!-- Cards Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:22px;margin-bottom:24px">
  <?php foreach ($cardRows as $c):
    $bg = $themes[$c['theme']??'navy'] ?? $themes['navy'];
    $sc = match($c['status']??'') {'Active'=>'success','Blocked'=>'danger','Pending'=>'warning',default=>'secondary'};
    $ini = strtoupper(substr($c['holder']??'X',0,1));
    $netIcon = str_contains(strtolower($c['card_type']??''),'mastercard') ? 'fa-cc-mastercard' : 'fa-cc-visa';
  ?>
  <div>
    <!-- Flip card -->
    <div class="vc-flip-scene" onclick="flipCard(<?= $c['id'] ?>)" title="Click to flip">
      <div class="vc-flip-inner" id="card-<?= $c['id'] ?>">
        <!-- Front -->
        <div class="vc-face vc-front" style="background:<?= $bg ?>">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div style="font-size:.62rem;font-weight:700;opacity:.75;text-transform:uppercase;letter-spacing:.8px">Abay Bank S.C.</div>
            <div style="display:flex;align-items:center;gap:7px">
              <span class="badge badge-<?= $sc ?>" style="font-size:.6rem"><?= $c['status'] ?></span>
              <i class="fa-brands <?= $netIcon ?>" style="font-size:1.5rem;opacity:.9"></i>
            </div>
          </div>
          <div class="vc-chip"></div>
          <div class="vc-num"><?= htmlspecialchars($c['card_number']??'**** **** **** 0000') ?></div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end">
            <div><div style="font-size:.56rem;opacity:.6;text-transform:uppercase;letter-spacing:.5px">Card Holder</div><div style="font-size:.78rem;font-weight:700;text-transform:uppercase;margin-top:1px"><?= htmlspecialchars($c['holder']??'—') ?></div></div>
            <div style="text-align:right"><div style="font-size:.56rem;opacity:.6;text-transform:uppercase;letter-spacing:.5px">Expires</div><div style="font-size:.78rem;font-weight:700;margin-top:1px"><?= htmlspecialchars($c['expiry_date']??'—') ?></div></div>
          </div>
        </div>
        <!-- Back -->
        <div class="vc-face vc-back">
          <div class="vc-back-stripe"></div>
          <div class="vc-sig"><span style="font-size:.62rem;color:#64748b;font-style:italic">Authorized Signature</span><span class="vc-cvv">***</span></div>
          <div class="vc-back-info">
            <div><div class="vc-bi-l">Card Type</div><div class="vc-bi-v"><?= htmlspecialchars($c['card_type']??'Debit') ?></div></div>
            <div><div class="vc-bi-l">Account</div><div class="vc-bi-v"><?= htmlspecialchars($c['account_number']??'—') ?></div></div>
            <div><div class="vc-bi-l">Balance</div><div class="vc-bi-v">ETB <?= number_format($c['balance']??0) ?></div></div>
            <div><div class="vc-bi-l">Issued</div><div class="vc-bi-v"><?= htmlspecialchars($c['issued_date']??'—') ?></div></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Card actions -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
      <button onclick="flipCard(<?= $c['id'] ?>)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;cursor:pointer;font-size:.78rem;font-weight:600;font-family:inherit;transition:all .2s" onmouseover="this.style.borderColor='#007A8A';this.style.color='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#334155'"><i class="fa-solid fa-rotate"></i> Flip Card</button>
      <button onclick="openCardDetail(<?= htmlspecialchars(json_encode($c)) ?>)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:none;border-radius:9px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;cursor:pointer;font-size:.78rem;font-weight:700;font-family:inherit"><i class="fa-solid fa-eye"></i> View Details</button>
      <button onclick="fundCard(<?= $c['id'] ?>,<?= htmlspecialchars(json_encode($c['holder']??'')) ?>)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;cursor:pointer;font-size:.78rem;font-weight:600;font-family:inherit;transition:all .2s" onmouseover="this.style.background='#d1fae5';this.style.borderColor='#059669'" onmouseout="this.style.background='#fff';this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-plus-circle" style="color:#059669"></i> Fund</button>
      <?php if ($c['status']==='Active'): ?>
      <button onclick="blockCard(<?= $c['id'] ?>,this)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:1.5px solid #fecaca;border-radius:9px;background:#fff;cursor:pointer;font-size:.78rem;font-weight:600;color:#dc2626;font-family:inherit" onmouseover="this.style.background='#fee2e2'" onmouseout="this.style.background='#fff'"><i class="fa-solid fa-ban"></i> Block</button>
      <?php elseif ($c['status']==='Blocked'): ?>
      <button onclick="unblockCard(<?= $c['id'] ?>,this)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:none;border-radius:9px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;cursor:pointer;font-size:.78rem;font-weight:700;font-family:inherit"><i class="fa-solid fa-unlock"></i> Unblock</button>
      <?php else: ?>
      <button onclick="approveCard(<?= $c['id'] ?>,this)" style="display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border:none;border-radius:9px;background:linear-gradient(135deg,#d97706,#f59e0b);color:#fff;cursor:pointer;font-size:.78rem;font-weight:700;font-family:inherit"><i class="fa-solid fa-check"></i> Approve</button>
      <?php endif;?>
    </div>
    <!-- Card meta -->
    <div style="padding:10px 4px;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.75rem;color:#94a3b8"><?= htmlspecialchars($c['card_type']??'') ?></div>
      <div style="font-size:.75rem;color:#94a3b8"><?= htmlspecialchars($c['account_number']??'') ?></div>
    </div>
  </div>
  <?php endforeach; ?>

  <!-- Add new card tile -->
  <div>
    <div onclick="window.location.href='<?= APP_URL ?>/cards/apply'" style="border:2px dashed #e2e8f0;border-radius:16px;height:185px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;cursor:pointer;transition:all .3s" onmouseover="this.style.borderColor='#007A8A';this.style.background='#f0fbfc'" onmouseout="this.style.borderColor='#e2e8f0';this.style.background='transparent'">
      <div style="width:48px;height:48px;border-radius:12px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#94a3b8"><i class="fa-solid fa-plus"></i></div>
      <div style="font-size:.85rem;font-weight:700;color:#94a3b8">Issue New Card</div>
      <div style="font-size:.74rem;color:#94a3b8;text-align:center;max-width:160px">Visa, Mastercard, or Virtual card</div>
    </div>
  </div>
</div>

<!-- Card Detail Modal -->
<div id="card-detail-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:500px;box-shadow:0 24px 64px rgba(0,0,0,.28);max-height:90vh;overflow-y:auto">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1;border-radius:18px 18px 0 0">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Card Details</div>
      <button onclick="document.getElementById('card-detail-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px" id="card-detail-body"></div>
    <div style="padding:14px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:9px;justify-content:flex-end">
      <button onclick="document.getElementById('card-detail-modal').style.display='none'" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Close</button>
    </div>
  </div>
</div>

<!-- Fund Card Modal -->
<div id="fund-card-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:420px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div><div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Fund Card</div><div id="fund-card-holder" style="font-size:.76rem;color:#94a3b8;margin-top:2px"></div></div>
      <button onclick="document.getElementById('fund-card-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="fund-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div style="margin-bottom:14px"><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Source Account</label>
        <input type="text" id="fund-src-acc" placeholder="Source account number" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      <div style="margin-bottom:14px"><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Amount (ETB) *</label>
        <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden" id="fund-amt-wrap">
          <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
          <input type="number" id="fund-amount" min="100" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.87rem;outline:none" onfocus="document.getElementById('fund-amt-wrap').style.borderColor='#007A8A'" onblur="document.getElementById('fund-amt-wrap').style.borderColor='#e2e8f0'">
        </div>
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('fund-card-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="fund-submit-btn" onclick="submitFundCard()" style="padding:10px 22px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-plus-circle"></i>Fund Card</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
var _fundCardId = null;

function flipCard(id) {
  var el = document.getElementById('card-' + id);
  if (el) el.classList.toggle('flipped');
}

function openCardDetail(c) {
  var sc = c.status === 'Active' ? '#d1fae5|#065f46|Active' : (c.status === 'Blocked' ? '#fee2e2|#991b1b|Blocked' : '#fef3c7|#92400e|Pending');
  var scp = sc.split('|');
  document.getElementById('card-detail-body').innerHTML =
    '<div style="display:flex;flex-direction:column;gap:12px">'
    + '<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:14px;padding:20px;color:#fff">'
    + '<div style="display:flex;justify-content:space-between;margin-bottom:10px"><span style="font-size:.62rem;opacity:.7;font-weight:700;text-transform:uppercase">Abay Bank S.C.</span><span style="font-size:1.4rem"><i class="fa-brands ' + (c.card_type&&c.card_type.toLowerCase().includes('mastercard')?'fa-cc-mastercard':'fa-cc-visa') + '"></i></span></div>'
    + '<div style="width:32px;height:24px;background:rgba(255,255,255,.25);border-radius:4px;margin-bottom:10px"></div>'
    + '<div style="font-size:.88rem;letter-spacing:3px;font-family:monospace;margin-bottom:10px">' + (c.card_number||'—') + '</div>'
    + '<div style="display:flex;justify-content:space-between"><div><div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Card Holder</div><div style="font-size:.78rem;font-weight:700;text-transform:uppercase">' + (c.holder||'—') + '</div></div><div style="text-align:right"><div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Expires</div><div style="font-size:.78rem;font-weight:700">' + (c.expiry_date||'—') + '</div></div></div>'
    + '</div>'
    + '<div style="background:#f8fafc;border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:9px">'
    + ['Card Type|'+(c.card_type||'—'),'Account No.|'+(c.account_number||'—'),'Balance|ETB '+Number(c.balance||0).toLocaleString(),'Issued Date|'+(c.issued_date||'—'),'Status|<span style="background:'+scp[0]+';color:'+scp[1]+';padding:2px 10px;border-radius:99px;font-size:.75rem;font-weight:700">'+scp[2]+'</span>'].map(function(row) {
      var parts = row.split('|'); return '<div style="display:flex;justify-content:space-between;align-items:center"><span style="font-size:.79rem;color:#64748b;font-weight:600">' + parts[0] + '</span><span style="font-size:.82rem;font-weight:600;color:#1e293b">' + parts[1] + '</span></div>';
    }).join('')
    + '</div></div>';
  document.getElementById('card-detail-modal').style.display = 'flex';
}

function fundCard(id, holder) {
  _fundCardId = id;
  document.getElementById('fund-card-holder').textContent = 'Cardholder: ' + holder;
  document.getElementById('fund-ok').style.display = 'none';
  document.getElementById('fund-card-modal').style.display = 'flex';
}

function submitFundCard() {
  var amt = parseFloat(document.getElementById('fund-amount').value) || 0;
  var src = document.getElementById('fund-src-acc').value.trim();
  if (amt < 100) { ABAY.toast('Minimum fund amount is ETB 100.', 'err'); return; }
  ABAY.setBtn('fund-submit-btn', true);
  ABAY.api('/cards/' + _fundCardId + '/fund', { method: 'POST', body: JSON.stringify({ amount: amt, source_account: src }) }).then(function(d) {
    ABAY.setBtn('fund-submit-btn', false, '<i class="fa-solid fa-plus-circle"></i>Fund Card');
    if (d && d.success) { document.getElementById('fund-ok').textContent = 'Card funded with ETB ' + amt.toFixed(2) + ' successfully!'; document.getElementById('fund-ok').style.display = 'block'; ABAY.toast('Card funded!', 'ok'); setTimeout(function() { document.getElementById('fund-card-modal').style.display = 'none'; location.reload(); }, 2000); }
    else { ABAY.toast((d && d.message) || 'Funding failed.', 'err'); }
  }).catch(function() {
    ABAY.setBtn('fund-submit-btn', false, '<i class="fa-solid fa-plus-circle"></i>Fund Card');
    document.getElementById('fund-ok').textContent = 'Demo: Card funded with ETB ' + amt.toFixed(2) + ' (Database offline).'; document.getElementById('fund-ok').style.display = 'block'; ABAY.toast('Demo fund recorded.', 'info');
    setTimeout(function() { document.getElementById('fund-card-modal').style.display = 'none'; }, 2000);
  });
}

function blockCard(id, btn) {
  if (!confirm('Block this card? Customer will not be able to use it.')) return;
  btn.disabled = true;
  ABAY.api('/cards/' + id + '/block', { method: 'PUT', body: JSON.stringify({}) }).then(function() { ABAY.toast('Card blocked!', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: Card blocked.', 'info'); btn.textContent = 'Blocked'; btn.style.background = '#fee2e2'; });
}

function unblockCard(id, btn) {
  if (!confirm('Unblock this card?')) return;
  btn.disabled = true;
  ABAY.api('/cards/' + id + '/activate', { method: 'PUT', body: JSON.stringify({}) }).then(function() { ABAY.toast('Card unblocked!', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: Card unblocked.', 'info'); location.reload(); });
}

function approveCard(id, btn) {
  if (!confirm('Approve and activate this card?')) return;
  btn.disabled = true;
  ABAY.api('/cards/' + id + '/activate', { method: 'PUT', body: JSON.stringify({}) }).then(function() { ABAY.toast('Card approved!', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: Card approved.', 'info'); location.reload(); });
}

document.addEventListener('keydown', function(e) { if (e.key === 'Escape') { document.getElementById('card-detail-modal').style.display = 'none'; document.getElementById('fund-card-modal').style.display = 'none'; } });
</script>
