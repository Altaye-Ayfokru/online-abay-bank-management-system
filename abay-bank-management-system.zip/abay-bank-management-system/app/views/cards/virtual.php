<?php
$pageTitle = 'Virtual Cards — ' . APP_NAME;
$vCards = $cards ?? [];
if (empty($vCards)) {
    $vCards = [
        ['id'=>1,'card_number'=>'**** **** **** 3317','card_type'=>'Visa Virtual','holder'=>'Solomon Girma',  'account_number'=>'0002-10-100003','balance'=>45000, 'status'=>'Active','issued_date'=>'2024-03-10','expiry_date'=>'06/29','theme'=>'teal'],
        ['id'=>2,'card_number'=>'**** **** **** 7741','card_type'=>'Visa Virtual','holder'=>'Hanna Getnet',   'account_number'=>'0005-10-100006','balance'=>98000, 'status'=>'Active','issued_date'=>'2024-06-01','expiry_date'=>'06/28','theme'=>'purple'],
        ['id'=>3,'card_number'=>'**** **** **** 5529','card_type'=>'Visa Virtual','holder'=>'Daniel Worku',   'account_number'=>'0007-10-100007','balance'=>320000,'status'=>'Pending','issued_date'=>'2026-08-20','expiry_date'=>'08/30','theme'=>'navy'],
    ];
}
$gradients = ['navy'=>'linear-gradient(135deg,#1B3A5C,#254d7a)','teal'=>'linear-gradient(135deg,#007A8A,#00a3b5)','purple'=>'linear-gradient(135deg,#5b21b6,#7c3aed)','gold'=>'linear-gradient(135deg,#92400e,#C8A84B)'];
?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-layer-group" style="color:#1B3A5C;margin-right:8px"></i>Virtual Cards</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/cards">Cards</a><span class="sep">/</span><span>Virtual</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <a href="<?= APP_URL ?>/cards" class="btn btn-ghost btn-sm"><i class="fa-solid fa-credit-card"></i> All Cards</a>
    <a href="<?= APP_URL ?>/cards/apply" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Apply Virtual Card</a>
  </div>
</div>

<!-- Info Banner -->
<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:14px;padding:20px 24px;margin-bottom:20px;color:#fff;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px">
  <div>
    <div style="font-size:1.1rem;font-weight:800;margin-bottom:6px"><i class="fa-solid fa-shield-halved" style="color:#C8A84B;margin-right:8px"></i>Virtual Card Benefits</div>
    <div style="font-size:.85rem;opacity:.75;max-width:600px;line-height:1.7">Virtual cards are digital-only cards perfect for online payments and subscriptions. They share the balance of your linked account but have separate transaction limits for enhanced security. Instant issuance with zero physical card fees.</div>
  </div>
  <a href="<?= APP_URL ?>/cards/apply" class="btn btn-gold btn-lg"><i class="fa-solid fa-plus"></i> Get Virtual Card</a>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-layer-group"></i></div><div class="stat-content"><div class="stat-label">Total Virtual Cards</div><div class="stat-value"><?= count($vCards) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div><div class="stat-content"><div class="stat-label">Active</div><div class="stat-value"><?= count(array_filter($vCards,fn($c)=>($c['status']??'')==='Active')) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon teal"><i class="fa-solid fa-coins"></i></div><div class="stat-content"><div class="stat-label">Total Balance</div><div class="stat-value" style="font-size:1.1rem">ETB <?= number_format(array_sum(array_column($vCards,'balance'))) ?></div></div></div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:22px">
  <?php foreach ($vCards as $c):
    $bg = $gradients[$c['theme']??'teal'] ?? $gradients['teal'];
    $sc = match($c['status']??'') {'Active'=>'success','Blocked'=>'danger','Pending'=>'warning',default=>'secondary'};
  ?>
  <div class="card" style="overflow:visible">
    <div class="card-body" style="padding:20px">
      <!-- Card face -->
      <div style="background:<?= $bg ?>;border-radius:14px;padding:20px;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.22);margin-bottom:16px;position:relative">
        <div style="position:absolute;top:12px;right:12px"><span class="badge badge-<?= $sc ?>" style="font-size:.6rem"><?= $c['status'] ?></span></div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <div style="font-size:.62rem;font-weight:700;opacity:.75;text-transform:uppercase;letter-spacing:.8px">Abay Bank S.C. · Virtual</div>
          <i class="fa-brands fa-cc-visa" style="font-size:1.5rem;opacity:.9"></i>
        </div>
        <div style="width:32px;height:24px;background:rgba(255,255,255,.25);border-radius:4px;margin:8px 0"></div>
        <div style="font-size:.9rem;letter-spacing:3px;font-family:monospace;opacity:.9;margin-bottom:10px"><?= htmlspecialchars($c['card_number']??'—') ?></div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end">
          <div>
            <div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Card Holder</div>
            <div style="font-size:.8rem;font-weight:700;text-transform:uppercase;margin-top:1px"><?= htmlspecialchars($c['holder']??'—') ?></div>
          </div>
          <div style="text-align:center">
            <div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Balance</div>
            <div style="font-size:.9rem;font-weight:900;color:#C8A84B;margin-top:1px">ETB <?= number_format($c['balance']??0) ?></div>
          </div>
          <div style="text-align:right">
            <div style="font-size:.56rem;opacity:.6;text-transform:uppercase">Expires</div>
            <div style="font-size:.78rem;font-weight:700;margin-top:1px"><?= htmlspecialchars($c['expiry_date']??'—') ?></div>
          </div>
        </div>
      </div>

      <!-- Card info -->
      <div style="display:flex;flex-direction:column;gap:7px;margin-bottom:14px">
        <?php foreach([['Account','account_number'],['Type','card_type'],['Issued','issued_date']] as [$l,$k]): ?>
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9">
          <span style="font-size:.78rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
          <span style="font-size:.8rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($c[$k]??'—') ?></span>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Actions -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <a href="<?= APP_URL ?>/accounts/statement?card=<?= $c['id'] ?>" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;font-size:.78rem;font-weight:600;color:#334155;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#007A8A';this.style.color='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#334155'"><i class="fa-solid fa-list"></i> Transactions</a>
        <button onclick="fundVirtualCard(<?= $c['id'] ?>,<?= htmlspecialchars(json_encode($c['holder']??'')) ?>)" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px;border:none;border-radius:9px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;cursor:pointer;font-size:.78rem;font-weight:700;font-family:inherit"><i class="fa-solid fa-plus-circle"></i> Fund</button>
        <button onclick="freezeCard(<?= $c['id'] ?>)" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px;border:1.5px solid #fde68a;border-radius:9px;background:#fff;cursor:pointer;font-size:.78rem;font-weight:600;color:#92400e;font-family:inherit" onmouseover="this.style.background='#fef3c7'" onmouseout="this.style.background='#fff'"><i class="fa-solid fa-snowflake"></i> Freeze</button>
        <button onclick="deleteVCard(<?= $c['id'] ?>)" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px;border:1.5px solid #fecaca;border-radius:9px;background:#fff;cursor:pointer;font-size:.78rem;font-weight:600;color:#dc2626;font-family:inherit" onmouseover="this.style.background='#fee2e2'" onmouseout="this.style.background='#fff'"><i class="fa-solid fa-trash"></i> Cancel</button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>

  <!-- Apply new tile -->
  <div class="card" style="cursor:pointer;border:2px dashed #e2e8f0;background:transparent;transition:all .3s" onclick="window.location.href='<?= APP_URL ?>/cards/apply'" onmouseover="this.style.borderColor='#007A8A';this.style.background='#f0fbfc'" onmouseout="this.style.borderColor='#e2e8f0';this.style.background='transparent'">
    <div class="card-body" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:280px;gap:12px;text-align:center">
      <div style="width:52px;height:52px;border-radius:14px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:#94a3b8"><i class="fa-solid fa-plus"></i></div>
      <div style="font-size:.9rem;font-weight:700;color:#94a3b8">Apply for Virtual Card</div>
      <div style="font-size:.78rem;color:#94a3b8;max-width:180px">Free · Instant issuance · Use for online payments worldwide</div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
function fundVirtualCard(id, holder) {
  var amt = parseFloat(prompt('Fund amount for ' + holder + ' (ETB):'));
  if (!amt || amt < 100) { ABAY.toast('Enter a valid amount (min ETB 100).', 'err'); return; }
  ABAY.api('/cards/' + id + '/fund', { method: 'POST', body: JSON.stringify({ amount: amt }) }).then(function(d) {
    ABAY.toast('Card funded with ETB ' + amt.toFixed(2) + '!', 'ok');
  }).catch(function() { ABAY.toast('Demo: Card funded with ETB ' + amt.toFixed(2) + '.', 'info'); });
}
function freezeCard(id) {
  if (!confirm('Freeze this virtual card temporarily?')) return;
  ABAY.api('/cards/' + id + '/block', { method: 'PUT', body: JSON.stringify({}) }).then(function() { ABAY.toast('Card frozen.', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: Card frozen.', 'info'); });
}
function deleteVCard(id) {
  if (!confirm('Cancel and delete this virtual card? This cannot be undone.')) return;
  ABAY.api('/cards/' + id, { method: 'DELETE' }).then(function() { ABAY.toast('Card cancelled.', 'ok'); location.reload(); }).catch(function() { ABAY.toast('Demo: Card cancelled.', 'info'); });
}
</script>
