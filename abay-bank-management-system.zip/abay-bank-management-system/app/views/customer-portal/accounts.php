﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= \Web\Core\View::e($pageTitle ?? 'My Accounts') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--blue:#1B3A5C;--teal:#007A8A;--gold:#C8A84B;--green:#10b981;--bg:#f1f5f9;--text:#1e293b;--sub:#64748b;--border:#e2e8f0}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
.top-nav{background:var(--blue);color:#fff;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.nav-brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff}
.logo-bars{display:flex;align-items:flex-end;gap:2px}.b{border-radius:2px 2px 0 0}
.b1{width:3px;height:10px;background:var(--gold)}.b2{width:3px;height:13px;background:var(--teal)}.b3{width:3px;height:16px;background:#fff}.b4{width:3px;height:10px;background:var(--teal)}
.nav-right{display:flex;align-items:center;gap:10px}
.nav-link{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:6px 14px;border-radius:6px;font-size:.78rem;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.container{max-width:900px;margin:0 auto;padding:24px 16px 64px}
.page-title{font-size:1.3rem;font-weight:800;color:var(--blue);margin-bottom:20px}
.account-block{background:#fff;border-radius:14px;box-shadow:0 1px 8px rgba(0,0,0,.07);margin-bottom:24px;overflow:hidden}
.acct-banner{padding:20px 24px;color:#fff;position:relative}
.acct-banner::after{content:'';position:absolute;bottom:-1px;right:-30px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.06)}
.acct-banner-title{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;opacity:.7;margin-bottom:4px}
.acct-banner-num{font-family:monospace;font-size:.9rem;opacity:.85;margin-bottom:10px}
.acct-banner-bal{font-size:2rem;font-weight:800}
.acct-banner-curr{font-size:.9rem;font-weight:400;opacity:.75;vertical-align:super;margin-right:4px}
.txn-table{width:100%;border-collapse:collapse}
.txn-table th{padding:10px 16px;text-align:left;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--sub);background:#f8fafc;border-bottom:2px solid var(--border)}
.txn-table td{padding:10px 16px;font-size:.84rem;border-bottom:1px solid #f1f5f9}
.txn-table tr:last-child td{border:none}
.credit{color:#10b981;font-weight:700}
.debit{color:#ef4444;font-weight:700}
.badge{padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700}
.badge-ok{background:rgba(16,185,129,.1);color:#047857}
.badge-fail{background:rgba(239,68,68,.1);color:#dc2626}
.badge-pending{background:rgba(234,179,8,.1);color:#b45309}
</style>
</head>
<body>
<nav class="top-nav">
  <a class="nav-brand" href="<?= APP_URL ?>/customer/dashboard">
    <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
    <div style="font-size:.88rem;font-weight:700">Abay Bank</div>
  </a>
  <div class="nav-right">
    <a href="<?= APP_URL ?>/customer/dashboard" class="nav-link"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    <a href="<?= APP_URL ?>/customer/logout" class="nav-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<div class="container">
  <div class="page-title"><i class="fa-solid fa-building-columns" style="color:var(--teal);margin-right:8px"></i>My Accounts</div>

  <?php if (empty($accounts)): ?>
  <div style="text-align:center;background:#fff;border-radius:14px;padding:60px;color:var(--sub)">
    <i class="fa-solid fa-building-columns fa-3x" style="opacity:.2;margin-bottom:12px;display:block"></i>
    <p>No accounts found. Visit any Abay Bank branch to open an account.</p>
    <a href="<?= APP_URL ?>/online/apply" style="display:inline-block;margin-top:16px;background:var(--teal);color:#fff;padding:10px 24px;border-radius:8px;text-decoration:none;font-weight:600;font-size:.9rem">Open Account Online</a>
  </div>
  <?php endif; ?>

  <?php
  $acctGradients = [
    'Savings'       => 'linear-gradient(135deg,#1B3A5C,#007A8A)',
    'Current'       => 'linear-gradient(135deg,#312e81,#4f46e5)',
    'Fixed Deposit' => 'linear-gradient(135deg,#92400e,#d97706)',
  ];
  foreach ($accounts as $acc):
    $grad = $acctGradients[$acc['account_type']] ?? 'linear-gradient(135deg,#1B3A5C,#007A8A)';
  ?>
  <div class="account-block">
    <div class="acct-banner" style="background:<?= $grad ?>">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div class="acct-banner-title"><?= \Web\Core\View::e($acc['account_type']) ?> Account</div>
          <div class="acct-banner-num"><?= \Web\Core\View::e($acc['account_number']) ?></div>
          <div class="acct-banner-bal"><span class="acct-banner-curr">ETB</span><?= number_format((float)$acc['balance'],2) ?></div>
        </div>
        <span style="background:rgba(255,255,255,.18);font-size:.72rem;font-weight:700;padding:4px 10px;border-radius:10px"><?= $acc['status'] ?></span>
      </div>
      <div style="margin-top:10px;font-size:.72rem;opacity:.65">
        Opened: <?= date('d M Y',strtotime($acc['opened_date'])) ?> &nbsp;·&nbsp;
        Interest: <?= $acc['interest_rate'] ?>% p.a.
      </div>
    </div>
    <div style="padding:0">
      <table class="txn-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Description</th>
            <th>Amount (ETB)</th>
            <th>Balance After</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="txn-<?= $acc['id'] ?>">
          <tr><td colspan="6" style="text-align:center;color:var(--sub);padding:20px">
            <i class="fa-solid fa-circle-notch fa-spin"></i> Loading...
          </td></tr>
        </tbody>
      </table>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<script>
// Load transactions per account via API
<?php foreach ($accounts as $acc): ?>
(function(accId) {
  fetch('<?= APP_URL ?>/api/accounts/' + accId + '/statement?limit=10')
    .then(r => r.json())
    .then(res => {
      const tbody = document.getElementById('txn-' + accId);
      const rows = res.data || res.transactions || res || [];
      if (!Array.isArray(rows) || rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:20px">No transactions for this account</td></tr>';
        return;
      }
      const creditTypes = ['Deposit','Transfer In','Interest Credit','Loan Disbursement'];
      tbody.innerHTML = rows.map(t => {
        const isCredit = creditTypes.includes(t.type);
        const badge = t.status === 'Completed' ? 'badge-ok' : (t.status === 'Failed' ? 'badge-fail' : 'badge-pending');
        return `<tr>
          <td>${new Date(t.created_at).toLocaleDateString('en-ET',{day:'2-digit',month:'short',year:'numeric'})}</td>
          <td>${t.type}</td>
          <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.description||''}</td>
          <td class="${isCredit?'credit':'debit'}">${isCredit?'+':'-'} ${Number(t.amount).toLocaleString('en-ET',{minimumFractionDigits:2})}</td>
          <td>${Number(t.balance_after).toLocaleString('en-ET',{minimumFractionDigits:2})}</td>
          <td><span class="badge ${badge}">${t.status}</span></td>
        </tr>`;
      }).join('');
    })
const csrfMeta=document.querySelector('meta[name="csrf-token"]');const csrfToken=csrfMeta?csrfMeta.content:'';body.append('_csrf',csrfToken);const r = await fetch(BASE + '/transactions/interbank', {
})(<?= $acc['id'] ?>);
<?php endforeach; ?>
</script>
</body>
</html>
