<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= \Web\Core\View::e($pageTitle ?? 'My Banking — Abay Bank') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--blue:#1B3A5C;--teal:#007A8A;--gold:#C8A84B;--green:#10b981;--red:#ef4444;--bg:#f1f5f9;--card:#fff;--text:#1e293b;--sub:#64748b;--border:#e2e8f0}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
.top-nav{background:var(--blue);color:#fff;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.3)}
.nav-brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff}
.logo-bars{display:flex;align-items:flex-end;gap:2px}.b{border-radius:2px 2px 0 0}
.b1{width:3px;height:10px;background:var(--gold)}.b2{width:3px;height:13px;background:var(--teal)}.b3{width:3px;height:16px;background:#fff}.b4{width:3px;height:10px;background:var(--teal)}
.nav-title{font-size:.92rem;font-weight:800}.nav-sub{font-size:.62rem;opacity:.65}
.nav-right{display:flex;align-items:center;gap:12px}
.nav-user{font-size:.82rem;font-weight:600;opacity:.9}
.nav-btn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:6px 14px;border-radius:6px;font-size:.78rem;font-weight:600;text-decoration:none;display:flex;align-items:center;gap:6px;transition:.2s}
.nav-btn:hover{background:rgba(255,255,255,.2)}
.container{max-width:1000px;margin:0 auto;padding:24px 16px 64px}
.greeting{margin-bottom:24px}
.greeting h1{font-size:1.4rem;font-weight:800;color:var(--blue)}
.greeting p{color:var(--sub);font-size:.88rem;margin-top:4px}
/* Quick actions */
.qa-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px}
.qa-card{background:var(--card);border-radius:12px;padding:16px;text-align:center;text-decoration:none;color:var(--text);box-shadow:0 1px 8px rgba(0,0,0,.07);transition:.2s;border:1.5px solid transparent}
.qa-card:hover{transform:translateY(-2px);border-color:var(--teal);box-shadow:0 4px 20px rgba(0,122,138,.15)}
.qa-ic{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;margin:0 auto 10px}
.qa-label{font-size:.78rem;font-weight:700;color:var(--text)}
/* Account cards */
.accounts-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;margin-bottom:24px}
.account-card{border-radius:14px;padding:20px;color:#fff;position:relative;overflow:hidden;min-height:130px}
.account-card::before{content:'';position:absolute;top:-30px;right:-30px;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.08)}
.account-card::after{content:'';position:absolute;bottom:-20px;left:-20px;width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.05)}
.ac-type{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;opacity:.75;margin-bottom:6px}
.ac-number{font-size:.82rem;font-family:monospace;opacity:.85;margin-bottom:12px}
.ac-balance{font-size:1.6rem;font-weight:800}
.ac-currency{font-size:.85rem;font-weight:400;opacity:.8;vertical-align:super;margin-right:4px}
.ac-status{position:absolute;top:14px;right:14px;font-size:.65rem;font-weight:700;background:rgba(255,255,255,.18);padding:3px 8px;border-radius:10px}
/* Two column layout */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.card{background:var(--card);border-radius:12px;box-shadow:0 1px 8px rgba(0,0,0,.07);overflow:hidden}
.card-head{padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-head h3{font-size:.9rem;font-weight:700;color:var(--blue);display:flex;align-items:center;gap:8px}
.card-body{padding:16px}
/* Transactions list */
.txn-item{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #f8fafc}
.txn-item:last-child{border:none}
.txn-ic{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0}
.txn-title{font-size:.85rem;font-weight:600;color:var(--text)}
.txn-sub{font-size:.72rem;color:var(--sub);margin-top:2px}
.txn-amount{margin-left:auto;font-size:.88rem;font-weight:700;white-space:nowrap}
/* Loan mini */
.loan-item{background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:8px}
.loan-bar{height:5px;background:#e2e8f0;border-radius:2px;margin-top:8px;overflow:hidden}
.loan-fill{height:100%;border-radius:2px;background:linear-gradient(90deg,var(--teal),var(--blue))}
/* ATM shortcut */
.atm-shortcut{background:linear-gradient(135deg,var(--blue),var(--teal));color:#fff;border-radius:12px;padding:18px 20px;display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;text-decoration:none}
.atm-shortcut:hover{opacity:.95}
@media(max-width:640px){.qa-grid{grid-template-columns:repeat(2,1fr)}.two-col{grid-template-columns:1fr}.accounts-row{grid-template-columns:1fr}}
</style>
</head>
<body>
<nav class="top-nav">
  <a class="nav-brand" href="<?= APP_URL ?>/customer/dashboard">
    <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
    <div><div class="nav-title">ዓባይ ባንክ — Abay Bank</div><div class="nav-sub">Online Banking Portal</div></div>
  </a>
  <div class="nav-right">
    <span class="nav-user"><i class="fa-solid fa-user-circle"></i> <?= \Web\Core\View::e($customer['name'] ?? '') ?></span>
    <a href="<?= APP_URL ?>/customer/transfer" class="nav-btn"><i class="fa-solid fa-right-left"></i> Transfer</a>
    <a href="<?= APP_URL ?>/customer/logout" class="nav-btn"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<div class="container">
  <!-- Greeting -->
  <div class="greeting">
    <h1>Hello, <?= \Web\Core\View::e(explode(' ', $customer['name'] ?? 'Customer')[0]) ?> 👋</h1>
    <p><?= date('l, d F Y') ?> &nbsp;·&nbsp; <?= !empty($dbOnline) ? '<span style="color:var(--green)"><i class="fa-solid fa-circle"></i> Live Banking</span>' : '<span style="color:#f59e0b"><i class="fa-solid fa-circle"></i> Demo Mode</span>' ?></p>
  </div>

  <!-- ATM shortcut -->
  <a href="<?= APP_URL ?>/atm" class="atm-shortcut" target="_blank">
    <div>
      <div style="font-weight:800;font-size:1rem;margin-bottom:4px"><i class="fa-solid fa-credit-card" style="color:var(--gold)"></i> &nbsp;Abay Bank ATM Simulator</div>
      <div style="font-size:.78rem;opacity:.8">Deposit, withdraw, and check balance using biometrics or account number</div>
    </div>
    <i class="fa-solid fa-arrow-right fa-lg"></i>
  </a>

  <!-- Quick actions -->
  <div class="qa-grid">
    <?php $quickActions = [
      ['icon'=>'fa-arrow-down','color'=>'rgba(16,185,129,.12)','ic_color'=>'#10b981','label'=>'Deposit','href'=>'#'],
      ['icon'=>'fa-arrow-up','color'=>'rgba(239,68,68,.1)','ic_color'=>'#ef4444','label'=>'Withdraw','href'=>'#'],
      ['icon'=>'fa-right-left','color'=>'rgba(0,122,138,.1)','ic_color'=>'#007A8A','label'=>'Transfer','href'=>APP_URL.'/customer/transfer'],
      ['icon'=>'fa-file-lines','color'=>'rgba(27,58,92,.1)','ic_color'=>'#1B3A5C','label'=>'Statement','href'=>APP_URL.'/customer/accounts'],
    ]; ?>
    <?php foreach ($quickActions as $q): ?>
    <a href="<?= $q['href'] ?>" class="qa-card">
      <div class="qa-ic" style="background:<?= $q['color'] ?>;color:<?= $q['ic_color'] ?>"><i class="fa-solid <?= $q['icon'] ?>"></i></div>
      <div class="qa-label"><?= $q['label'] ?></div>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- Account cards -->
  <?php if (!empty($accounts)): ?>
  <div style="font-weight:700;font-size:.88rem;color:var(--sub);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px"><i class="fa-solid fa-building-columns" style="color:var(--teal);margin-right:6px"></i> My Accounts</div>
  <div class="accounts-row">
    <?php
    $acctGradients = [
      'Savings'       => 'linear-gradient(135deg,#1B3A5C,#007A8A)',
      'Current'       => 'linear-gradient(135deg,#312e81,#4f46e5)',
      'Fixed Deposit' => 'linear-gradient(135deg,#92400e,#d97706)',
    ];
    foreach ($accounts as $a):
      $grad = $acctGradients[$a['account_type']] ?? 'linear-gradient(135deg,#1B3A5C,#007A8A)';
    ?>
    <div class="account-card" style="background:<?= $grad ?>">
      <div class="ac-type"><?= \Web\Core\View::e($a['account_type']) ?></div>
      <div class="ac-number"><?= \Web\Core\View::e($a['account_number']) ?></div>
      <div class="ac-balance"><span class="ac-currency">ETB</span><?= number_format((float)$a['balance'],2) ?></div>
      <span class="ac-status"><?= $a['status'] ?></span>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Two column: transactions + loans -->
  <div class="two-col">
    <!-- Recent Transactions -->
    <div class="card">
      <div class="card-head">
        <h3><i class="fa-solid fa-clock-rotate-left" style="color:var(--teal)"></i> Recent Transactions</h3>
        <a href="<?= APP_URL ?>/customer/accounts" style="font-size:.75rem;color:var(--teal);text-decoration:none;font-weight:600">View All</a>
      </div>
      <div class="card-body" style="padding:0 16px">
        <?php if (empty($recentTxns)): ?>
        <div style="text-align:center;padding:30px;color:var(--sub);font-size:.85rem"><i class="fa-solid fa-inbox fa-2x" style="opacity:.3;display:block;margin-bottom:8px"></i>No transactions yet</div>
        <?php else: ?>
        <?php foreach (array_slice($recentTxns,0,8) as $t):
          $isCredit = in_array($t['type'],['Deposit','Transfer In','Interest Credit','Loan Disbursement']);
          $icBg     = $isCredit ? 'rgba(16,185,129,.1)' : 'rgba(239,68,68,.08)';
          $icColor  = $isCredit ? '#10b981' : '#ef4444';
          $ic       = $isCredit ? 'fa-arrow-down' : 'fa-arrow-up';
        ?>
        <div class="txn-item">
          <div class="txn-ic" style="background:<?= $icBg ?>;color:<?= $icColor ?>"><i class="fa-solid <?= $ic ?>"></i></div>
          <div>
            <div class="txn-title"><?= \Web\Core\View::e($t['type']) ?></div>
            <div class="txn-sub"><?= date('d M Y',strtotime($t['created_at'])) ?> &nbsp;·&nbsp; <?= \Web\Core\View::e(substr($t['description']??'',0,30)) ?></div>
          </div>
          <div class="txn-amount" style="color:<?= $icColor ?>"><?= $isCredit?'+':'-' ?>ETB <?= number_format((float)$t['amount'],2) ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Loans -->
    <div class="card">
      <div class="card-head">
        <h3><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i> My Loans</h3>
        <a href="<?= APP_URL ?>/loans/apply" style="font-size:.75rem;color:var(--teal);text-decoration:none;font-weight:600">Apply</a>
      </div>
      <div class="card-body">
        <?php if (empty($loans)): ?>
        <div style="text-align:center;padding:30px;color:var(--sub);font-size:.85rem"><i class="fa-solid fa-file-slash fa-2x" style="opacity:.3;display:block;margin-bottom:8px"></i>No active loans</div>
        <?php else: ?>
        <?php foreach ($loans as $l):
          $paid  = (float)$l['paid_amount'];
          $total = (float)$l['amount'];
          $pct   = $total > 0 ? round(($paid/$total)*100) : 0;
        ?>
        <div class="loan-item">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
            <div style="font-size:.85rem;font-weight:700;color:var(--text)"><?= \Web\Core\View::e($l['loan_type']) ?> Loan</div>
            <span style="background:<?= $l['status']==='Active'?'rgba(16,185,129,.1)':'rgba(234,179,8,.1)' ?>;color:<?= $l['status']==='Active'?'#047857':'#b45309' ?>;font-size:.7rem;font-weight:700;padding:2px 8px;border-radius:10px"><?= $l['status'] ?></span>
          </div>
          <div style="font-size:.78rem;color:var(--sub);margin-bottom:6px">Outstanding: <strong style="color:var(--text)">ETB <?= number_format((float)$l['outstanding'],2) ?></strong></div>
          <div class="loan-bar"><div class="loan-fill" style="width:<?= $pct ?>%"></div></div>
          <div style="font-size:.7rem;color:var(--sub);margin-top:4px"><?= $pct ?>% repaid &nbsp;·&nbsp; Next due: <?= $l['next_due_date'] ? date('d M Y',strtotime($l['next_due_date'])) : '—' ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</body>
</html>
