﻿<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= \Web\Core\View::e($pageTitle ?? 'Transfer Funds') ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    *,
    *::before,
    *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0
    }

    :root {
      --blue: #1B3A5C;
      --teal: #007A8A;
      --gold: #C8A84B;
      --green: #10b981;
      --red: #ef4444;
      --bg: #f1f5f9;
      --text: #1e293b;
      --sub: #64748b;
      --border: #e2e8f0
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh
    }

    .top-nav {
      background: var(--blue);
      color: #fff;
      padding: 14px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 100
    }

    .nav-brand {
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
      color: #fff
    }

    .logo-bars {
      display: flex;
      align-items: flex-end;
      gap: 2px
    }

    .b {
      border-radius: 2px 2px 0 0
    }

    .b1 {
      width: 3px;
      height: 10px;
      background: var(--gold)
    }

    .b2 {
      width: 3px;
      height: 13px;
      background: var(--teal)
    }

    .b3 {
      width: 3px;
      height: 16px;
      background: #fff
    }

    .b4 {
      width: 3px;
      height: 10px;
      background: var(--teal)
    }

    .nav-link {
      background: rgba(255, 255, 255, .12);
      border: 1px solid rgba(255, 255, 255, .2);
      color: #fff;
      padding: 6px 14px;
      border-radius: 6px;
      font-size: .78rem;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 6px
    }

    .container {
      max-width: 680px;
      margin: 0 auto;
      padding: 24px 16px 64px
    }

    .page-title {
      font-size: 1.3rem;
      font-weight: 800;
      color: var(--blue);
      margin-bottom: 4px
    }

    .page-sub {
      font-size: .85rem;
      color: var(--sub);
      margin-bottom: 24px
    }

    .card {
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 2px 16px rgba(0, 0, 0, .07);
      overflow: hidden;
      margin-bottom: 20px
    }

    .card-header {
      background: linear-gradient(135deg, var(--blue), var(--teal));
      color: #fff;
      padding: 16px 20px
    }

    .card-header h2 {
      font-size: .95rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px
    }

    .card-header .sub {
      font-size: .72rem;
      opacity: .75;
      margin-top: 3px
    }

    .card-body {
      padding: 22px
    }

    .transfer-tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 20px
    }

    .ttab {
      flex: 1;
      padding: 10px;
      border: 1.5px solid var(--border);
      border-radius: 10px;
      background: transparent;
      color: var(--sub);
      font-size: .82rem;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      transition: .2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px
    }

    .ttab.active {
      background: rgba(0, 122, 138, .08);
      border-color: var(--teal);
      color: var(--teal)
    }

    .tab-panel {
      display: none
    }

    .tab-panel.active {
      display: block
    }

    .form-group {
      margin-bottom: 14px
    }

    .form-label {
      font-size: .82rem;
      font-weight: 600;
      color: var(--sub);
      display: block;
      margin-bottom: 6px
    }

    .req {
      color: var(--red);
      margin-left: 2px
    }

    .inp-wrap {
      position: relative
    }

    .inp-ic {
      position: absolute;
      left: 11px;
      top: 50%;
      transform: translateY(-50%);
      color: #94a3b8;
      font-size: .85rem
    }

    .form-inp,
    .form-sel {
      width: 100%;
      padding: 10px 12px 10px 34px;
      border: 1.5px solid var(--border);
      border-radius: 8px;
      font-size: .88rem;
      font-family: inherit;
      color: var(--text);
      background: #fff;
      transition: .2s
    }

    .form-inp:focus,
    .form-sel:focus {
      outline: none;
      border-color: var(--teal);
      box-shadow: 0 0 0 3px rgba(0, 122, 138, .1)
    }

    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 14px
    }

    .full {
      grid-column: 1/-1
    }

    .fee-box {
      background: linear-gradient(135deg, rgba(0, 122, 138, .05), rgba(27, 58, 92, .03));
      border: 1.5px solid rgba(0, 122, 138, .12);
      border-radius: 10px;
      padding: 14px;
      margin: 14px 0;
      display: none
    }

    .fee-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: .82rem;
      padding: 4px 0
    }

    .fee-row.total {
      font-weight: 800;
      border-top: 1px solid var(--border);
      margin-top: 4px;
      padding-top: 8px;
      font-size: .9rem
    }

    .btn-transfer {
      width: 100%;
      background: linear-gradient(135deg, var(--teal), var(--blue));
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 13px;
      font-size: .95rem;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: .2s;
      font-family: inherit
    }

    .btn-transfer:hover {
      opacity: .9
    }

    .btn-transfer:disabled {
      opacity: .5;
      cursor: not-allowed
    }

    .beneficiary-card {
      border: 1.5px solid var(--border);
      border-radius: 10px;
      padding: 12px;
      cursor: pointer;
      transition: .2s;
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      gap: 12px
    }

    .beneficiary-card:hover {
      border-color: var(--teal);
      background: rgba(0, 122, 138, .04)
    }

    .bic {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      background: rgba(0, 122, 138, .1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: .9rem;
      color: var(--teal);
      flex-shrink: 0
    }

    .modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, .5);
      z-index: 9999;
      align-items: center;
      justify-content: center
    }

    .modal.show {
      display: flex
    }

    .modal-box {
      background: #fff;
      border-radius: 16px;
      padding: 32px;
      max-width: 400px;
      width: 90%;
      text-align: center
    }
  </style>
</head>

<body>
  <nav class="top-nav">
    <a class="nav-brand" href="<?= APP_URL ?>/customer/dashboard">
      <div class="logo-bars">
        <div class="b b1"></div>
        <div class="b b2"></div>
        <div class="b b3"></div>
        <div class="b b4"></div>
      </div>
      <div style="font-size:.88rem;font-weight:700">Abay Bank</div>
    </a>
    <div style="display:flex;gap:8px">
      <a href="<?= APP_URL ?>/customer/dashboard" class="nav-link"><i class="fa-solid fa-gauge"></i> Dashboard</a>
      <a href="<?= APP_URL ?>/customer/logout" class="nav-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
  </nav>

  <div class="container">
    <div class="page-title"><i class="fa-solid fa-right-left" style="color:var(--teal);margin-right:8px"></i>Transfer Funds</div>
    <p class="page-sub">Send money within Abay Bank or to any Ethiopian bank via EthSwitch</p>

    <div class="card">
      <div class="card-header">
        <h2><i class="fa-solid fa-right-left"></i> Fund Transfer</h2>
        <div class="sub">Instant · Secure · NBE Regulated</div>
      </div>
      <div class="card-body">
        <!-- Transfer type tabs -->
        <div class="transfer-tabs">
          <button class="ttab active" onclick="switchTab('internal',this)">
            <i class="fa-solid fa-building-columns"></i> Within Abay Bank
          </button>
          <button class="ttab" onclick="switchTab('interbank',this)">
            <i class="fa-solid fa-globe"></i> Inter-Bank Transfer
          </button>
        </div>

        <!-- Internal Transfer -->
        <div class="tab-panel active" id="tab-internal">
          <div class="form-grid">
            <div class="form-group full">
              <label class="form-label">From Account <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-building-columns inp-ic"></i>
                <select name="from_account" id="from-account" class="form-sel" onchange="updateFromBalance()">
                  <option value="">— Select —</option>
                  <?php foreach ($accounts as $a): ?>
                    <option value="<?= $a['id'] ?>" data-balance="<?= $a['balance'] ?>">
                      <?= \Web\Core\View::e($a['account_number']) ?> · <?= $a['account_type'] ?> · ETB <?= number_format($a['balance'], 2) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div id="from-bal-bar" style="margin-top:5px;font-size:.75rem;color:var(--sub);display:none">
                Available: <strong id="from-bal" style="color:var(--blue)">—</strong>
              </div>
            </div>
            <div class="form-group full">
              <label class="form-label">To Account Number <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-hashtag inp-ic"></i>
                <input type="text" id="int-to-acct" class="form-inp" placeholder="Abay Bank account number">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Amount (ETB) <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-money-bill inp-ic"></i>
                <input type="number" id="int-amount" class="form-inp" min="1" step="0.01" placeholder="0.00">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Narration</label>
              <div class="inp-wrap">
                <i class="fa-solid fa-pen inp-ic"></i>
                <input type="text" id="int-narration" class="form-inp" placeholder="e.g. Rent, Family support">
              </div>
            </div>
          </div>
          <button class="btn-transfer" onclick="submitInternal()">
            <i class="fa-solid fa-paper-plane"></i> Send Transfer
          </button>
        </div>

        <!-- Inter-Bank Transfer -->
        <div class="tab-panel" id="tab-interbank">
          <!-- Saved beneficiaries -->
          <?php if (!empty($beneficiaries)): ?>
            <div style="margin-bottom:16px">
              <div style="font-size:.78rem;font-weight:700;color:var(--sub);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Saved Beneficiaries</div>
              <?php foreach ($beneficiaries as $b): ?>
                <div class="beneficiary-card" onclick="fillBeneficiary('<?= \Web\Core\View::e($b['bank_code']) ?>','<?= \Web\Core\View::e($b['account_number']) ?>','<?= \Web\Core\View::e($b['account_name']) ?>')">
                  <div class="bic"><i class="fa-solid fa-building-columns"></i></div>
                  <div>
                    <div style="font-size:.85rem;font-weight:700"><?= \Web\Core\View::e($b['nickname']) ?></div>
                    <div style="font-size:.73rem;color:var(--sub)"><?= \Web\Core\View::e($b['bank_name']) ?> · <?= \Web\Core\View::e($b['account_number']) ?></div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div class="form-grid">
            <div class="form-group full">
              <label class="form-label">From Account <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-building-columns inp-ic"></i>
                <select id="ibt-from-account" class="form-sel">
                  <option value="">— Select —</option>
                  <?php foreach ($accounts as $a): ?>
                    <option value="<?= $a['id'] ?>" data-balance="<?= $a['balance'] ?>">
                      <?= \Web\Core\View::e($a['account_number']) ?> · <?= $a['account_type'] ?> · ETB <?= number_format($a['balance'], 2) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Destination Bank <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-building-columns inp-ic"></i>
                <select id="ibt-bank" class="form-sel">
                  <option value="">— Select bank —</option>
                  <?php foreach ($banks as $code => $name): ?>
                    <option value="<?= $code ?>"><?= \Web\Core\View::e($name) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Destination Account No. <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-hashtag inp-ic"></i>
                <input type="text" id="ibt-dest-acct" class="form-inp" placeholder="Account number">
              </div>
            </div>
            <div class="form-group full">
              <label class="form-label">Beneficiary Name</label>
              <div class="inp-wrap">
                <i class="fa-solid fa-user inp-ic"></i>
                <input type="text" id="ibt-dest-name" class="form-inp" placeholder="Recipient name">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Amount (ETB) <span class="req">*</span></label>
              <div class="inp-wrap">
                <i class="fa-solid fa-money-bill inp-ic"></i>
                <input type="number" id="ibt-amount" class="form-inp" min="1" placeholder="0.00" oninput="calcIBTFee()">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Purpose</label>
              <div class="inp-wrap">
                <i class="fa-solid fa-pen inp-ic"></i>
                <input type="text" id="ibt-purpose" class="form-inp" placeholder="e.g. Business payment">
              </div>
            </div>
          </div>

          <div class="fee-box" id="ibt-fee-box">
            <div style="font-size:.75rem;font-weight:700;color:var(--teal);margin-bottom:8px"><i class="fa-solid fa-receipt"></i> Fee Breakdown</div>
            <div class="fee-row"><span style="color:var(--sub)">Amount:</span><span id="ibt-fee-amount">—</span></div>
            <div class="fee-row"><span style="color:var(--sub)">Service Fee (0.5%):</span><span id="ibt-fee-val" style="color:#f59e0b">—</span></div>
            <div class="fee-row total"><span>Total Deducted:</span><span id="ibt-fee-total" style="color:var(--blue)">—</span></div>
          </div>

          <button class="btn-transfer" onclick="submitIBT()">
            <i class="fa-solid fa-globe"></i> Send Inter-Bank Transfer
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Result Modal -->
  <div class="modal" id="result-modal">
    <div class="modal-box">
      <div id="modal-icon" style="font-size:2.5rem;margin-bottom:12px"></div>
      <div id="modal-title" style="font-size:1.1rem;font-weight:800;margin-bottom:8px"></div>
      <div id="modal-body" style="font-size:.85rem;color:var(--sub);margin-bottom:20px"></div>
      <div id="modal-ref" style="background:#f8fafc;border-radius:8px;padding:10px;font-family:monospace;font-size:.78rem;color:var(--teal);margin-bottom:16px;display:none"></div>
      <button onclick="closeModal()" style="background:linear-gradient(135deg,var(--teal),var(--blue));color:#fff;border:none;border-radius:8px;padding:10px 28px;font-weight:700;cursor:pointer">Close</button>
    </div>
  </div>

  <script>
    const BASE = '<?= APP_URL ?>';

    function switchTab(tab, btn) {
      document.querySelectorAll('.transfer-tabs .ttab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + tab).classList.add('active');
    }

    function updateFromBalance() {
      const sel = document.getElementById('from-account');
      const opt = sel.options[sel.selectedIndex];
      const bar = document.getElementById('from-bal-bar');
      if (opt.dataset.balance !== undefined) {
        document.getElementById('from-bal').textContent = 'ETB ' + Number(opt.dataset.balance).toLocaleString('en-ET', {
          minimumFractionDigits: 2
        });
        bar.style.display = 'block';
      } else {
        bar.style.display = 'none';
      }
    }

    function fillBeneficiary(bank, acct, name) {
      document.getElementById('ibt-bank').value = bank;
      document.getElementById('ibt-dest-acct').value = acct;
      document.getElementById('ibt-dest-name').value = name;
    }

    function calcIBTFee() {
      const amt = parseFloat(document.getElementById('ibt-amount').value);
      const box = document.getElementById('ibt-fee-box');
      if (!amt || amt < 1) {
        box.style.display = 'none';
        return;
      }
      const fee = Math.min(500, Math.max(10, Math.round(amt * 0.005 * 100) / 100));
      const total = amt + fee;
      document.getElementById('ibt-fee-amount').textContent = 'ETB ' + amt.toLocaleString('en-ET', {
        minimumFractionDigits: 2
      });
      document.getElementById('ibt-fee-val').textContent = 'ETB ' + fee.toLocaleString('en-ET', {
        minimumFractionDigits: 2
      });
      document.getElementById('ibt-fee-total').textContent = 'ETB ' + total.toLocaleString('en-ET', {
        minimumFractionDigits: 2
      });
      box.style.display = 'block';
    }

    async function submitInternal() {
      const fromAcct = document.getElementById('from-account') ? document.getElementById('from-account').value : '';
      const toAcct = document.getElementById('to-account') ? document.getElementById('to-account').value : '';
      const amount = parseFloat(document.getElementById('transfer-amount') ? document.getElementById('transfer-amount').value : 0);
      const purpose = document.getElementById('transfer-purpose') ? document.getElementById('transfer-purpose').value : 'Fund Transfer';
      if (!fromAcct || !toAcct || !amount) {
        showModal('err', 'Missing Fields', 'Please fill all required fields (from account, to account, amount).');
        return;
      }
      if (fromAcct === toAcct) {
        showModal('err', 'Invalid Transfer', 'Source and destination accounts must be different.');
        return;
      }
      const csrfMeta = document.querySelector('meta[name="csrf-token"]');
      const csrfToken = csrfMeta ? csrfMeta.content : '';
      try {
        const r = await fetch(BASE + '/api/transactions/transfer', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
          },
          body: JSON.stringify({
            from_account_number: fromAcct,
            to_account_number: toAcct,
            amount: amount,
            description: purpose,
            _csrf: csrfToken
          })
        });
        const res = await r.json();
        if (res && res.success) {
          showModal('ok', 'Transfer Successful', 'ETB ' + (amount).toLocaleString('en-ET', {
            minimumFractionDigits: 2
          }) + ' transferred successfully!', res.data && res.data.reference ? res.data.reference : 'TRF-' + Date.now().toString(36).toUpperCase());
        } else {
          showModal('err', 'Transfer Failed', (res && res.message) || 'Transfer could not be completed.');
        }
      } catch (e) {
        // Demo fallback
        showModal('ok', 'Demo Transfer', 'ETB ' + (amount || 0).toLocaleString('en-ET', {
          minimumFractionDigits: 2
        }) + ' transfer recorded in demo mode (database offline).', 'TRF-DEMO-' + Date.now().toString(36).toUpperCase());
      }
    }

    async function submitIBT() {
      const fromId = document.getElementById('ibt-from-account').value;
      const bank = document.getElementById('ibt-bank').value;
      const acct = document.getElementById('ibt-dest-acct').value;
      const name = document.getElementById('ibt-dest-name').value;
      const amount = parseFloat(document.getElementById('ibt-amount').value);
      const purpose = document.getElementById('ibt-purpose').value;

      if (!fromId || !bank || !acct || !amount) {
        showModal('err', 'Missing Fields', 'Please fill all required fields.');
        return;
      }

      // Get CSRF from API or use customer session
      const body = new URLSearchParams({
        source_account_id: fromId,
        dest_bank_code: bank,
        dest_account_number: acct,
        dest_account_name: name,
        amount,
        purpose,
        channel: 'Online'
      });
      try {
        const csrfMeta=document.querySelector('meta[name="csrf-token"]');const csrfToken=csrfMeta?csrfMeta.content:'';body.append('_csrf',csrfToken);const r = await fetch(BASE + '/transactions/interbank', {
          method: 'POST',
          body,
          headers: {
            'X-Requested-With': 'XMLHttpRequest'
          }
        });
        const res = await r.json();
        if (res.success) {
          showModal('ok', 'Transfer Successful', res.message, res.reference);
        } else {
          showModal('err', 'Transfer Failed', res.message || 'An error occurred.');
        }
      } catch (e) {
        showModal('err', 'Error', 'Connection error. Please try again.');
      }
    }

    function showModal(type, title, body, ref = '') {
      document.getElementById('modal-icon').innerHTML = type === 'ok' ?
        '<i class="fa-solid fa-circle-check" style="color:#10b981"></i>' :
        '<i class="fa-solid fa-circle-xmark" style="color:#ef4444"></i>';
      document.getElementById('modal-title').textContent = title;
      document.getElementById('modal-title').style.color = type === 'ok' ? '#047857' : '#dc2626';
      document.getElementById('modal-body').textContent = body;
      const refEl = document.getElementById('modal-ref');
      if (ref) {
        refEl.textContent = 'REF: ' + ref;
        refEl.style.display = 'block';
      } else {
        refEl.style.display = 'none';
      }
      document.getElementById('result-modal').classList.add('show');
    }

    function closeModal() {
      document.getElementById('result-modal').classList.remove('show');
    }
  </script>
</body>

</html>