﻿<?php

/**
 * Abay Bank — View: KYC Management
 * Auto-generated from: frontend/pages/customer/customer-kyc.html
 * PHP data available: $user, $stats, $data (from PageController)
 */
?>

<div class="page-header">
  <div class="page-header-left">
    <h1>KYC Verification</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/dashboard">Customers</a><span class="sep">/</span><span>KYC</span></div>
  </div>
  <div style="display:flex;gap:var(--space-3)">
    <button class="btn btn-light btn-sm" id="export-kyc"><i class="fa-solid fa-file-csv"></i> Export</button>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:var(--space-5)">
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Verified</div>
      <div class="stat-value">10,847</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Pending Review</div>
      <div class="stat-value">347</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-circle-xmark"></i></div>
    <div class="stat-content">
      <div class="stat-label">Rejected</div>
      <div class="stat-value">89</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-content">
      <div class="stat-label">Expiring Soon</div>
      <div class="stat-value">124</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-id-card text-primary"></i> KYC Verification Queue</h3>
  </div>
  <div class="card-body" style="padding-bottom:0;padding-top:var(--space-4)">
    <div class="table-toolbar">
      <div class="table-toolbar-left">
        <div class="table-search"><i class="fa-solid fa-magnifying-glass search-icon"></i><input type="search" placeholder="Search customers..."></div>
        <select class="form-control" style="width:auto;padding:var(--space-2) var(--space-6) var(--space-2) var(--space-3)">
          <option>All Status</option>
          <option>Pending</option>
          <option>Verified</option>
          <option>Rejected</option>
        </select>
      </div>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Customer ID</th>
          <th>Name</th>
          <th>ID Type</th>
          <th>Submitted</th>
          <th>Documents</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="kyc-tbody">
        <?php if (!empty($pending)): foreach ($pending as $k): ?>
            <tr>
              <td style="font-family:monospace;font-size:.82rem"><?= htmlspecialchars($k['customer_number'] ?? '') ?></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($k['first_name'] ?? '?', 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars(($k['first_name'] ?? '') . ' ' . ($k['last_name'] ?? '')) ?></div>
                  </div>
                </div>
              </td>
              <td><?= htmlspecialchars($k['id_type'] ?? 'National ID') ?></td>
              <td style="font-size:.82rem;color:var(--text-muted)"><?= htmlspecialchars(substr($k['created_at'] ?? '', 0, 10)) ?></td>
              <td><span class="badge badge-secondary">Pending</span></td>
              <td><span class="badge badge-warning"><?= htmlspecialchars($k['kyc_status'] ?? 'Pending') ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn approve" data-tooltip="Verify" onclick="kycVerify(<?= (int)$k['id'] ?>)"><i class="fa-solid fa-check"></i></button>
                  <button class="action-btn delete" data-tooltip="Reject" onclick="kycReject(<?= (int)$k['id'] ?>)"><i class="fa-solid fa-xmark"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach;
        else: ?>
          <tr>
            <td colspan="7" style="text-align:center;padding:32px;color:#94a3b8">No pending KYC verifications</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="pagination-wrapper">
    <div class="pagination-info">Showing 1�10 of 347</div>
    <div class="pagination"></div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function kycVerify(id) {
    if (!confirm('Mark KYC as Verified for customer #' + id + '?')) return;
    ABAY.api('/kyc/verify', {
        method: 'POST',
        body: JSON.stringify({
          customer_id: id,
          action: 'verify'
        })
      })
      .then(function(d) {
        if (d && d.success) {
          ABAY.toast('KYC verified!', 'ok');
          setTimeout(function() {
            location.reload();
          }, 1200);
        } else {
          ABAY.toast((d && d.message) || 'Failed', 'err');
        }
      }).catch(function() {
        ABAY.toast('Demo: KYC #' + id + ' verified', 'success');
        setTimeout(function() {
          location.reload();
        }, 1200);
      });
  }

  function kycReject(id) {
    var reason = prompt('Reason for KYC rejection:');
    if (!reason) return;
    ABAY.api('/kyc/verify', {
        method: 'POST',
        body: JSON.stringify({
          customer_id: id,
          action: 'reject',
          note: reason
        })
      })
      .then(function(d) {
        if (d && d.success) {
          ABAY.toast('KYC rejected.', 'warning');
          setTimeout(function() {
            location.reload();
          }, 1200);
        } else {
          ABAY.toast((d && d.message) || 'Failed', 'err');
        }
      }).catch(function() {
        ABAY.toast('Demo: KYC #' + id + ' rejected', 'warning');
        setTimeout(function() {
          location.reload();
        }, 1200);
      });
  }
</script>>