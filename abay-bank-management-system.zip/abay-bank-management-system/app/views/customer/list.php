<?php

/** @var array $customers @var array $user */
$pageTitle = 'Customers — ' . APP_NAME;
$dbCustomers = $customers ?? [];
?>

<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-users" style="color:var(--primary)"></i> Customer Management</h1>
    <p class="page-subtitle">View, search and manage all registered customers</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline btn-sm" onclick="exportCSV()"><i class="fa-solid fa-file-csv"></i> Export CSV</button>
    <button class="btn btn-primary btn-sm" onclick="document.getElementById('add-cust-modal').style.display='flex'"><i class="fa-solid fa-user-plus"></i> Add Customer</button>
  </div>
</div>

<!-- KPI Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:#3b82f620;color:#3b82f6"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-value" id="stat-total"><?= number_format(count($dbCustomers) ?: 2450) ?></div>
      <div class="stat-label">Total Customers</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#22c55e20;color:#22c55e"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-info">
      <div class="stat-value" id="stat-active">—</div>
      <div class="stat-label">Active</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#f59e0b20;color:#f59e0b"><i class="fa-solid fa-id-card"></i></div>
    <div class="stat-info">
      <div class="stat-value" id="stat-kyc">—</div>
      <div class="stat-label">KYC Pending</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#ef444420;color:#ef4444"><i class="fa-solid fa-ban"></i></div>
    <div class="stat-info">
      <div class="stat-value" id="stat-sus">—</div>
      <div class="stat-label">Suspended</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#6366f120;color:#6366f1"><i class="fa-solid fa-user-plus"></i></div>
    <div class="stat-info">
      <div class="stat-value" id="stat-new">—</div>
      <div class="stat-label">New This Month</div>
    </div>
  </div>
</div>

<!-- Filters + Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-list"></i> All Customers</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <div style="position:relative">
        <i class="fa-solid fa-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.8rem;pointer-events:none"></i>
        <input type="search" id="cust-search" placeholder="Name, phone, ID…"
          style="padding:8px 12px 8px 32px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.83rem;width:210px;outline:none"
          oninput="filterCustomers()" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
      </div>
      <select id="cust-status-filter" onchange="filterCustomers()"
        style="border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:.83rem;background:#fff;cursor:pointer">
        <option value="">All Status</option>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
        <option value="Suspended">Suspended</option>
      </select>
      <select id="cust-kyc-filter" onchange="filterCustomers()"
        style="border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:.83rem;background:#fff;cursor:pointer">
        <option value="">All KYC</option>
        <option value="Verified">Verified</option>
        <option value="Pending">Pending</option>
        <option value="Rejected">Rejected</option>
      </select>
    </div>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Customer ID</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Branch</th>
          <th>Balance</th>
          <th>KYC</th>
          <th>Status</th>
          <th>Joined</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="cust-tbody">
        <tr>
          <td colspan="9" style="text-align:center;padding:48px;color:#94a3b8">
            <i class="fa-solid fa-spinner fa-spin" style="font-size:1.5rem;display:block;margin-bottom:10px"></i>
            Loading customers…
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="cust-info">Loading…</div>
    <div id="cust-pagination" style="display:flex;gap:5px;flex-wrap:wrap"></div>
  </div>
</div>

<!-- View Customer Modal -->
<div id="view-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1050;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:18px;max-width:520px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9">
      <h3 style="font-size:.98rem;font-weight:800;color:#1B3A5C">Customer Details</h3>
      <button onclick="document.getElementById('view-modal').style.display='none'" style="width:28px;height:28px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.85rem">✕</button>
    </div>
    <div id="view-modal-body" style="padding:20px"></div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allCustomers = [],
    _filtered = [],
    _page = 1,
    _perPage = 15;

  // PHP-rendered customers as seed (from database via controller)
  var _phpCustomers = <?= json_encode(array_map(function ($c) {
                        return [
                          'id'              => (int)$c['id'],
                          'customer_number' => $c['customer_number'] ?? '',
                          'first_name'      => $c['first_name']      ?? '',
                          'last_name'       => $c['last_name']        ?? '',
                          'phone'           => $c['phone']            ?? '',
                          'email'           => $c['email']            ?? '',
                          'gender'          => $c['gender']           ?? '',
                          'kyc_status'      => $c['kyc_status']       ?? 'Pending',
                          'status'          => $c['status']           ?? 'Active',
                          'created_at'      => $c['created_at']       ?? '',
                          'branch_name'     => $c['branch_name']      ?? '—',
                          'balance'         => (float)($c['balance']  ?? 0),
                        ];
                      }, $dbCustomers)) ?>;

  var _demoCustomers = [{
      id: 1,
      customer_number: 'CUST-A1B2C3D',
      first_name: 'Abebe',
      last_name: 'Bekele',
      phone: '0911234567',
      email: 'abebe@email.com',
      gender: 'Male',
      kyc_status: 'Verified',
      status: 'Active',
      created_at: '2024-01-15',
      branch_name: 'Bole Branch',
      balance: 84500
    },
    {
      id: 2,
      customer_number: 'CUST-E4F5G6H',
      first_name: 'Tigist',
      last_name: 'Haile',
      phone: '0922345678',
      email: 'tigist@email.com',
      gender: 'Female',
      kyc_status: 'Verified',
      status: 'Active',
      created_at: '2024-02-20',
      branch_name: 'Kirkos Branch',
      balance: 125000
    },
    {
      id: 3,
      customer_number: 'CUST-I7J8K9L',
      first_name: 'Solomon',
      last_name: 'Girma',
      phone: '0933456789',
      email: 'solomon@email.com',
      gender: 'Male',
      kyc_status: 'Pending',
      status: 'Active',
      created_at: '2024-03-10',
      branch_name: 'Bahir Dar',
      balance: 45000
    },
    {
      id: 4,
      customer_number: 'CUST-M1N2O3P',
      first_name: 'Meron',
      last_name: 'Alemu',
      phone: '0944567890',
      email: 'meron@email.com',
      gender: 'Female',
      kyc_status: 'Verified',
      status: 'Active',
      created_at: '2024-03-25',
      branch_name: 'Bole Branch',
      balance: 220000
    },
    {
      id: 5,
      customer_number: 'CUST-Q4R5S6T',
      first_name: 'Dawit',
      last_name: 'Mekonnen',
      phone: '0955678901',
      email: 'dawit@email.com',
      gender: 'Male',
      kyc_status: 'Pending',
      status: 'Active',
      created_at: '2024-04-05',
      branch_name: 'Arada Branch',
      balance: 15000
    },
    {
      id: 6,
      customer_number: 'CUST-U7V8W9X',
      first_name: 'Hanna',
      last_name: 'Getnet',
      phone: '0966789012',
      email: 'hanna@email.com',
      gender: 'Female',
      kyc_status: 'Verified',
      status: 'Active',
      created_at: '2024-04-18',
      branch_name: 'Head Office',
      balance: 98000
    },
    {
      id: 7,
      customer_number: 'CUST-Y1Z2A3B',
      first_name: 'Daniel',
      last_name: 'Worku',
      phone: '0977890123',
      email: 'daniel@email.com',
      gender: 'Male',
      kyc_status: 'Verified',
      status: 'Active',
      created_at: '2024-05-02',
      branch_name: 'Kirkos Branch',
      balance: 350000
    },
    {
      id: 8,
      customer_number: 'CUST-C4D5E6F',
      first_name: 'Fikirte',
      last_name: 'Bekele',
      phone: '0988901234',
      email: 'fikirte@email.com',
      gender: 'Female',
      kyc_status: 'Rejected',
      status: 'Inactive',
      created_at: '2024-05-20',
      branch_name: 'Dire Dawa',
      balance: 7500
    },
  ];

  function loadCustomers() {
    // Use PHP-rendered data first if available, else fetch from API
    if (_phpCustomers && _phpCustomers.length > 0) {
      _allCustomers = _phpCustomers;
      updateStats(_allCustomers);
      filterCustomers();
    }
    // Always refresh from API in background
    ABAY.api('/customers?per_page=300').then(function(d) {
      if (d && d.success && d.data && d.data.customers && d.data.customers.length) {
        _allCustomers = d.data.customers;
        if (d.data.stats) {
          document.getElementById('stat-total').textContent = Number(d.data.stats.total).toLocaleString();
          document.getElementById('stat-active').textContent = Number(d.data.stats.active).toLocaleString();
          document.getElementById('stat-kyc').textContent = Number(d.data.stats.kyc_pending).toLocaleString();
          document.getElementById('stat-sus').textContent = Number(d.data.stats.suspended).toLocaleString();
        } else {
          updateStats(_allCustomers);
        }
        filterCustomers();
      } else if (!_phpCustomers || !_phpCustomers.length) {
        _allCustomers = _demoCustomers;
        updateStats(_allCustomers);
        filterCustomers();
      }
    }).catch(function() {
      if (!_phpCustomers || !_phpCustomers.length) {
        _allCustomers = _demoCustomers;
        updateStats(_allCustomers);
        filterCustomers();
      }
    });
  }

  function updateStats(rows) {
    document.getElementById('stat-total').textContent = rows.length.toLocaleString();
    document.getElementById('stat-active').textContent = rows.filter(function(r) {
      return r.status === 'Active';
    }).length.toLocaleString();
    document.getElementById('stat-kyc').textContent = rows.filter(function(r) {
      return r.kyc_status === 'Pending';
    }).length.toLocaleString();
    document.getElementById('stat-sus').textContent = rows.filter(function(r) {
      return r.status === 'Suspended';
    }).length.toLocaleString();
    var thisMonth = new Date().toISOString().slice(0, 7);
    document.getElementById('stat-new').textContent = rows.filter(function(r) {
      return (r.created_at || '').startsWith(thisMonth);
    }).length.toLocaleString();
  }

  function filterCustomers() {
    var q = document.getElementById('cust-search').value.toLowerCase();
    var status = document.getElementById('cust-status-filter').value;
    var kyc = document.getElementById('cust-kyc-filter').value;
    _filtered = _allCustomers.filter(function(c) {
      var name = ((c.first_name || '') + ' ' + (c.last_name || '')).toLowerCase();
      var matchQ = !q || name.includes(q) || (c.phone || '').includes(q) || (c.customer_number || '').toLowerCase().includes(q) || (c.email || '').toLowerCase().includes(q);
      return matchQ && (!status || c.status === status) && (!kyc || c.kyc_status === kyc);
    });
    _page = 1;
    renderTable();
  }

  function renderTable() {
    var tbody = document.getElementById('cust-tbody');
    var total = _filtered.length;
    var start = (_page - 1) * _perPage;
    var slice = _filtered.slice(start, start + _perPage);

    if (!total) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:48px;color:#94a3b8"><i class="fa-solid fa-magnifying-glass" style="font-size:1.5rem;display:block;margin-bottom:10px"></i>No customers found</td></tr>';
      document.getElementById('cust-info').textContent = 'No results';
      document.getElementById('cust-pagination').innerHTML = '';
      return;
    }

    var kycColors = {
      Verified: '#22c55e20,#16a34a',
      Pending: '#fef9c320,#b45309',
      Rejected: '#fee2e220,#dc2626'
    };
    var statusColors = {
      Active: '#22c55e20,#16a34a',
      Inactive: '#f1f5f920,#64748b',
      Suspended: '#fee2e220,#dc2626'
    };

    function badge(val, colors) {
      var parts = (colors[val] || '#f1f5f920,#64748b').split(',');
      return '<span style="background:' + parts[0] + ';color:' + parts[1] + ';padding:3px 10px;border-radius:99px;font-size:.72rem;font-weight:700">' + val + '</span>';
    }

    tbody.innerHTML = slice.map(function(c) {
      var name = (c.first_name || '') + ' ' + (c.last_name || '');
      var initials = ((c.first_name || '?')[0] + ((c.last_name || '?')[0])).toUpperCase();
      var date = (c.created_at || '').substring(0, 10) || '—';
      var bal = typeof c.balance === 'number' ? 'ETB ' + c.balance.toLocaleString('en-US', {
        minimumFractionDigits: 2
      }) : '—';
      var custNo = c.customer_number || 'CUST-' + c.id;
      return '<tr>' +
        '<td style="font-family:monospace;font-size:.77rem;color:#475569">' + custNo + '</td>' +
        '<td><div style="display:flex;align-items:center;gap:10px">' +
        '<div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;flex-shrink:0">' + initials + '</div>' +
        '<div><div style="font-size:.84rem;font-weight:600;color:#1e293b">' + name + '</div>' +
        '<div style="font-size:.73rem;color:#94a3b8">' + (c.email || '') + '</div></div>' +
        '</div></td>' +
        '<td style="font-size:.83rem">' + (c.phone || '—') + '</td>' +
        '<td style="font-size:.82rem">' + (c.branch_name || '—') + '</td>' +
        '<td style="font-weight:600;font-size:.82rem;color:#1B3A5C">' + bal + '</td>' +
        '<td>' + badge(c.kyc_status || 'Pending', kycColors) + '</td>' +
        '<td>' + badge(c.status || 'Active', statusColors) + '</td>' +
        '<td style="font-size:.78rem;color:#94a3b8">' + date + '</td>' +
        '<td><div style="display:flex;gap:4px">' +
        '<button onclick="viewCustomer(' + JSON.stringify(c).replace(/"/g, '&quot;') + ')" title="View" style="padding:5px 9px;background:none;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;font-size:.75rem;color:#475569"><i class="fa-solid fa-eye"></i></button>' +
        '<a href="<?= APP_URL ?>/customers/profile?id=' + c.id + '" title="Profile" style="padding:5px 9px;background:none;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;font-size:.75rem;color:#007A8A;text-decoration:none"><i class="fa-solid fa-circle-user"></i></a>' +
        '<button onclick="editCustomer(' + JSON.stringify(c).replace(/"/g, '&quot;') + ')" title="Edit" style="padding:5px 9px;background:none;border:1px solid #dbeafe;border-radius:6px;cursor:pointer;font-size:.75rem;color:#1d4ed8"><i class="fa-solid fa-pen"></i></button>' +
        '<button onclick="deleteCustomer(' + c.id + ',\'' + name + '\')" title="Delete" style="padding:5px 9px;background:none;border:1px solid #fee2e2;border-radius:6px;cursor:pointer;font-size:.75rem;color:#dc2626"><i class="fa-solid fa-trash"></i></button>' +
        '</div></td>' +
        '</tr>';
    }).join('');

    document.getElementById('cust-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _perPage, total) + ' of ' + total.toLocaleString() + ' customers';

    var pages = Math.ceil(total / _perPage);
    var phtml = '';
    if (_page > 1) phtml += '<button onclick="goPage(' + (_page - 1) + ')" style="' + pgStyle(false) + '">‹</button>';
    var s = Math.max(1, _page - 2),
      e = Math.min(pages, _page + 2);
    for (var i = s; i <= e; i++) phtml += '<button onclick="goPage(' + i + ')" style="' + pgStyle(i === _page) + '">' + i + '</button>';
    if (_page < pages) phtml += '<button onclick="goPage(' + (_page + 1) + ')" style="' + pgStyle(false) + '">›</button>';
    document.getElementById('cust-pagination').innerHTML = phtml;
  }

  function pgStyle(active) {
    return 'width:30px;height:30px;border:1.5px solid ' + (active ? '#007A8A' : '#e2e8f0') + ';background:' + (active ? '#007A8A' : '#fff') + ';color:' + (active ? '#fff' : '#475569') + ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit';
  }

  function goPage(p) {
    _page = p;
    renderTable();
  }

  function viewCustomer(c) {
    var modal = document.getElementById('view-modal');
    var body = document.getElementById('view-modal-body');
    var rows = [
      ['Customer No.', c.customer_number || '—'],
      ['Full Name', (c.first_name || '') + ' ' + (c.last_name || '')],
      ['Phone', c.phone || '—'],
      ['Email', c.email || '—'],
      ['Gender', c.gender || '—'],
      ['Branch', c.branch_name || '—'],
      ['Balance', typeof c.balance === 'number' ? 'ETB ' + c.balance.toLocaleString() : '—'],
      ['KYC Status', c.kyc_status || '—'],
      ['Account Status', c.status || '—'],
      ['Joined', (c.created_at || '').substring(0, 10) || '—'],
    ];
    body.innerHTML = rows.map(function(r) {
        return '<div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid #f1f5f9;font-size:.85rem">' +
          '<span style="color:#94a3b8;font-weight:500">' + r[0] + '</span>' +
          '<span style="font-weight:600;color:#1e293b">' + r[1] + '</span>' +
          '</div>';
      }).join('') +
      '<div style="margin-top:16px;display:flex;gap:10px">' +
      '<a href="<?= APP_URL ?>/customers/profile?id=' + c.id + '" class="btn btn-primary btn-sm"><i class="fa-solid fa-circle-user"></i> Full Profile</a>' +
      '<a href="<?= APP_URL ?>/accounts/statement?account=' + c.id + '" class="btn btn-outline btn-sm"><i class="fa-solid fa-file-lines"></i> Statement</a>' +
      '</div>';
    modal.style.display = 'flex';
  }

  function deleteCustomer(id, name) {
    if (!confirm('Delete customer "' + name + '"? This cannot be undone.')) return;
    ABAY.api('/customers/delete', {
        method: 'POST',
        body: JSON.stringify({
          customer_id: id
        })
      })
      .then(function(d) {
        if (d && d.success) {
          ABAY.toast(name + ' deleted', 'ok');
          _allCustomers = _allCustomers.filter(function(c) {
            return c.id !== id;
          });
          filterCustomers();
        } else {
          ABAY.toast((d && d.message) || 'Delete failed', 'err');
        }
      }).catch(function() {
        ABAY.toast('Demo: Delete recorded', 'info');
      });
  }

  function exportCSV() {
    var rows = [
      ['Customer ID', 'Name', 'Phone', 'Email', 'Branch', 'Balance', 'KYC', 'Status', 'Joined']
    ].concat(
      _filtered.map(function(c) {
        return [c.customer_number || c.id, (c.first_name || '') + ' ' + (c.last_name || ''), c.phone || '', c.email || '', c.branch_name || '', c.balance || 0, c.kyc_status || '', c.status || '', (c.created_at || '').substring(0, 10)];
      })
    );
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'customers_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
  }

  document.addEventListener('DOMContentLoaded', loadCustomers);

  // Close modal on outside click
  document.getElementById('view-modal').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      document.getElementById('view-modal').style.display = 'none';
      var em = document.getElementById('edit-cust-modal');
      if (em) em.style.display = 'none';
    }
  });

  /* ── EDIT CUSTOMER ─────────────────────────────────────────── */
  function editCustomer(c) {
    document.getElementById('ec-id').value = c.id || '';
    document.getElementById('ec-fn').value = c.first_name || '';
    document.getElementById('ec-ln').value = c.last_name || '';
    document.getElementById('ec-phone').value = c.phone || '';
    document.getElementById('ec-email').value = c.email || '';
    document.getElementById('ec-gender').value = c.gender || '';
    document.getElementById('ec-kyc').value = c.kyc_status || 'Pending';
    document.getElementById('ec-status').value = c.status || 'Active';
    document.getElementById('ec-addr').value = c.address || '';
    document.getElementById('ec-ok').style.display = 'none';
    document.getElementById('ec-err').style.display = 'none';
    document.getElementById('edit-cust-modal').style.display = 'flex';
  }

  function submitEditCustomer() {
    var id = document.getElementById('ec-id').value;
    var fn = document.getElementById('ec-fn').value.trim();
    var ln = document.getElementById('ec-ln').value.trim();
    var phone = document.getElementById('ec-phone').value.trim();
    var email = document.getElementById('ec-email').value.trim();
    var gender = document.getElementById('ec-gender').value;
    var kyc = document.getElementById('ec-kyc').value;
    var status = document.getElementById('ec-status').value;
    var addr = document.getElementById('ec-addr').value.trim();

    if (!fn || !ln) {
      document.getElementById('ec-err').textContent = 'Name is required.';
      document.getElementById('ec-err').style.display = 'block';
      return;
    }
    if (!phone) {
      document.getElementById('ec-err').textContent = 'Phone is required.';
      document.getElementById('ec-err').style.display = 'block';
      return;
    }

    ABAY.setBtn('ec-save-btn', true);
    ABAY.api('/customers/update', {
      method: 'POST',
      body: JSON.stringify({
        id: id,
        first_name: fn,
        last_name: ln,
        phone: phone,
        email: email,
        gender: gender,
        kyc_status: kyc,
        status: status,
        address: addr
      })
    }).then(function(d) {
      ABAY.setBtn('ec-save-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
      if (d && d.success) {
        document.getElementById('ec-ok').textContent = fn + ' ' + ln + ' updated successfully!';
        document.getElementById('ec-ok').style.display = 'block';
        ABAY.toast(fn + ' ' + ln + ' updated!', 'ok');
        setTimeout(function() {
          document.getElementById('edit-cust-modal').style.display = 'none';
          loadCustomers();
        }, 1400);
      } else {
        document.getElementById('ec-err').textContent = (d && d.message) || 'Update failed.';
        document.getElementById('ec-err').style.display = 'block';
      }
    }).catch(function() {
      ABAY.setBtn('ec-save-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
      document.getElementById('ec-ok').textContent = 'Demo: ' + fn + ' ' + ln + ' updated (DB offline).';
      document.getElementById('ec-ok').style.display = 'block';
      ABAY.toast('Demo: Customer updated.', 'info');
      setTimeout(function() {
        document.getElementById('edit-cust-modal').style.display = 'none';
        loadCustomers();
      }, 1400);
    });
  }

  document.getElementById('edit-cust-modal') && document.getElementById('edit-cust-modal').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
  });
</script>

<!-- EDIT CUSTOMER MODAL -->
<div id="edit-cust-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:540px;box-shadow:0 24px 64px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;position:sticky;top:0;background:#fff;z-index:1;border-radius:18px 18px 0 0">
      <div>
        <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Edit Customer</div>
        <div style="font-size:.74rem;color:#94a3b8;margin-top:2px">Update customer information</div>
      </div>
      <button onclick="document.getElementById('edit-cust-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <input type="hidden" id="ec-id">
      <div id="ec-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div id="ec-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.84rem;color:#991b1b"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <?php $inpStyle = 'border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none'; ?>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">First Name *</label><input id="ec-fn" type="text" style="<?= $inpStyle ?>"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Last Name *</label><input id="ec-ln" type="text" style="<?= $inpStyle ?>"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Phone *</label><input id="ec-phone" type="tel" style="<?= $inpStyle ?>"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Email</label><input id="ec-email" type="email" style="<?= $inpStyle ?>"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Gender</label>
          <select id="ec-gender" style="<?= $inpStyle ?>;background:#fff">
            <option value="">—</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">KYC Status</label>
          <select id="ec-kyc" style="<?= $inpStyle ?>;background:#fff">
            <option>Pending</option>
            <option>Verified</option>
            <option>Rejected</option>
            <option>Under_Review</option>
          </select>
        </div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Status</label>
          <select id="ec-status" style="<?= $inpStyle ?>;background:#fff">
            <option>Active</option>
            <option>Inactive</option>
            <option>Suspended</option>
          </select>
        </div>
      </div>
      <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Address</label>
        <textarea id="ec-addr" rows="2" style="<?= $inpStyle ?>;resize:vertical;font-family:inherit"></textarea>
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end;position:sticky;bottom:0;background:#fff;border-radius:0 0 18px 18px">
      <button onclick="document.getElementById('edit-cust-modal').style.display='none'" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.86rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="ec-save-btn" onclick="submitEditCustomer()" style="padding:10px 22px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.86rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-save"></i> Save Changes</button>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════════
     ADD CUSTOMER MODAL
═══════════════════════════════════════════════════════════ -->
<div id="add-cust-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:580px;box-shadow:0 24px 64px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;position:sticky;top:0;background:#fff;z-index:1;border-radius:18px 18px 0 0">
      <div>
        <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Add New Customer</div>
        <div style="font-size:.74rem;color:#94a3b8;margin-top:2px">Customer registration form</div>
      </div>
      <button onclick="closeCustModal()" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="cust-add-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px 14px;margin-bottom:14px;font-size:.84rem;color:#065f46"><i class="fa-solid fa-circle-check" style="margin-right:6px"></i><span id="cust-add-ok-msg"></span></div>
      <div id="cust-add-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;margin-bottom:14px;font-size:.84rem;color:#991b1b"><i class="fa-solid fa-circle-xmark" style="margin-right:6px"></i><span id="cust-add-err-msg"></span></div>

      <!-- Profile Photo -->
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;padding:14px;background:#f8fafc;border-radius:10px">
        <div id="cust-photo-preview-wrap" style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:1.2rem;overflow:hidden;flex-shrink:0">
          <span id="cust-photo-initials">?</span>
          <img id="cust-photo-preview" style="display:none;width:100%;height:100%;object-fit:cover;border-radius:50%">
        </div>
        <div>
          <div style="font-size:.82rem;font-weight:600;color:#374151;margin-bottom:4px">Profile Photo <span style="color:#94a3b8;font-weight:400">(optional)</span></div>
          <button type="button" onclick="document.getElementById('cust-photo-input').click()" style="padding:6px 14px;background:#fff;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit;color:#374151">
            <i class="fa-solid fa-camera"></i> Choose Photo
          </button>
          <div style="font-size:.71rem;color:#94a3b8;margin-top:3px">JPG, PNG — max 5 MB</div>
          <input type="file" id="cust-photo-input" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="previewCustPhoto(this)">
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">First Name *</label><input id="cust-fn" type="text" placeholder="First name" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Last Name *</label><input id="cust-ln" type="text" placeholder="Last name" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Phone *</label><input id="cust-phone" type="tel" placeholder="+251 9XX XXX XXX" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Email</label><input id="cust-email" type="email" placeholder="customer@email.com" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">National ID *</label><input id="cust-nid" type="text" placeholder="ET12345678" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Date of Birth</label><input id="cust-dob" type="date" class="cust-inp"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Gender</label>
          <select id="cust-gender" class="cust-inp" style="background:#fff;cursor:pointer">
            <option value="">Select…</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Branch</label>
          <select id="cust-branch" class="cust-inp" style="background:#fff;cursor:pointer">
            <option value="">Select branch…</option>
            <?php foreach (['Head Office', 'Bole Branch', 'Alem Ketema Branch', 'Kirkos Branch', 'Piassa Branch', 'Arada Branch', 'Bahir Dar Branch', 'Hawassa Branch', 'Dire Dawa Branch', 'Mekelle Branch'] as $br): ?>
              <option><?= $br ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Address</label><textarea id="cust-addr" class="cust-inp" rows="2" placeholder="Residential address…" style="resize:vertical;font-family:inherit"></textarea></div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end;position:sticky;bottom:0;background:#fff;border-radius:0 0 18px 18px">
      <button onclick="closeCustModal()" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.86rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="cust-add-btn" onclick="submitAddCustomer()" style="padding:10px 22px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.86rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-user-plus"></i> Register Customer</button>
    </div>
  </div>
</div>

<style>
  .cust-inp {
    border: 1.5px solid #e2e8f0;
    border-radius: 8px;
    padding: 9px 12px;
    font-size: .86rem;
    width: 100%;
    outline: none;
    font-family: inherit;
    transition: border-color .2s;
  }

  .cust-inp:focus {
    border-color: #007A8A;
    box-shadow: 0 0 0 3px rgba(0, 122, 138, .1);
  }
</style>

<script>
  function closeCustModal() {
    document.getElementById('add-cust-modal').style.display = 'none';
    document.getElementById('cust-add-ok').style.display = 'none';
    document.getElementById('cust-add-err').style.display = 'none';
  }

  function previewCustPhoto(input) {
    if (!input.files || !input.files[0]) return;
    var reader = new FileReader();
    reader.onload = function(e) {
      var img = document.getElementById('cust-photo-preview');
      var init = document.getElementById('cust-photo-initials');
      img.src = e.target.result;
      img.style.display = 'block';
      init.style.display = 'none';
    };
    reader.readAsDataURL(input.files[0]);
  }
  // Update initials in the preview as name is typed
  ['cust-fn', 'cust-ln'].forEach(function(id) {
    document.getElementById(id).addEventListener('input', function() {
      var fn = document.getElementById('cust-fn').value.trim();
      var ln = document.getElementById('cust-ln').value.trim();
      var init = (fn ? fn[0] : '') + (ln ? ln[0] : '');
      var el = document.getElementById('cust-photo-initials');
      if (el && !document.getElementById('cust-photo-preview').src) el.textContent = init.toUpperCase() || '?';
    });
  });

  function submitAddCustomer() {
    var fn = document.getElementById('cust-fn').value.trim();
    var ln = document.getElementById('cust-ln').value.trim();
    var phone = document.getElementById('cust-phone').value.trim();
    var nid = document.getElementById('cust-nid').value.trim();
    var email = document.getElementById('cust-email').value.trim();
    var dob = document.getElementById('cust-dob').value;
    var gender = document.getElementById('cust-gender').value;
    var branch = document.getElementById('cust-branch').value;
    var addr = document.getElementById('cust-addr').value.trim();

    document.getElementById('cust-add-err').style.display = 'none';

    if (!fn || !ln) {
      showCustErr('First and last name are required.');
      return;
    }
    if (!phone) {
      showCustErr('Phone number is required.');
      return;
    }
    if (!nid) {
      showCustErr('National ID is required.');
      return;
    }

    ABAY.setBtn('cust-add-btn', true);

    ABAY.api('/customers', {
      method: 'POST',
      body: JSON.stringify({
        first_name: fn,
        last_name: ln,
        phone: phone,
        national_id: nid,
        email: email,
        date_of_birth: dob,
        gender: gender,
        branch: branch,
        address: addr
      })
    }).then(function(d) {
      ABAY.setBtn('cust-add-btn', false, '<i class="fa-solid fa-user-plus"></i> Register Customer');
      if (d && d.success) {
        var custId = d.data && d.data.customer_id;
        document.getElementById('cust-add-ok-msg').textContent = fn + ' ' + ln + ' registered! ID: ' + (d.data && d.data.customer_number || '');
        document.getElementById('cust-add-ok').style.display = 'block';
        ABAY.toast(fn + ' ' + ln + ' registered successfully!', 'ok');
        // Upload photo if selected
        var photoInput = document.getElementById('cust-photo-input');
        if (photoInput && photoInput.files && photoInput.files[0] && custId) {
          var fd = new FormData();
          fd.append('photo', photoInput.files[0]);
          fd.append('customer_id', custId);
          fetch(window.BASE_URL + '/api/upload/customer-document', {
            method: 'POST',
            credentials: 'include',
            headers: {
              'X-Requested-With': 'XMLHttpRequest'
            },
            body: fd
          }).catch(function() {});
        }
        setTimeout(function() {
          closeCustModal();
          loadCustomers();
        }, 1600);
      } else {
        showCustErr((d && d.message) || 'Failed to register customer.');
      }
    }).catch(function() {
      ABAY.setBtn('cust-add-btn', false, '<i class="fa-solid fa-user-plus"></i> Register Customer');
      var fn2 = document.getElementById('cust-fn').value.trim();
      var ln2 = document.getElementById('cust-ln').value.trim();
      document.getElementById('cust-add-ok-msg').textContent = 'Demo: ' + fn2 + ' ' + ln2 + ' recorded (Database offline).';
      document.getElementById('cust-add-ok').style.display = 'block';
      ABAY.toast('Demo customer added.', 'info');
      setTimeout(closeCustModal, 1600);
    });
  }

  function showCustErr(msg) {
    document.getElementById('cust-add-err-msg').textContent = msg;
    document.getElementById('cust-add-err').style.display = 'block';
  }
  // Close on Escape / outside click
  document.getElementById('add-cust-modal').addEventListener('click', function(e) {
    if (e.target === this) closeCustModal();
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && document.getElementById('add-cust-modal').style.display === 'flex') closeCustModal();
  });
</script>