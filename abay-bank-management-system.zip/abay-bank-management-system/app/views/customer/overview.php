<?php
$pageTitle = 'Customer Overview — ' . APP_NAME;
$st = $stats ?? ['total'=>2450,'active'=>2280,'kyc_ok'=>1980,'new_month'=>124];
$recentList = $recent ?? [];
if (empty($recentList)) {
    $recentList = [
        ['id'=>1,'customer_number'=>'CUS20260001','first_name'=>'Abebe','last_name'=>'Bekele','phone'=>'0911234567','branch_name'=>'Bole','kyc_status'=>'Verified','status'=>'Active','created_at'=>date('Y-m-d',strtotime('-2 days'))],
        ['id'=>2,'customer_number'=>'CUS20260002','first_name'=>'Tigist','last_name'=>'Haile','phone'=>'0922345678','branch_name'=>'Kirkos','kyc_status'=>'Pending','status'=>'Active','created_at'=>date('Y-m-d',strtotime('-3 days'))],
        ['id'=>3,'customer_number'=>'CUS20260003','first_name'=>'Solomon','last_name'=>'Girma','phone'=>'0933456789','branch_name'=>'Bahir Dar','kyc_status'=>'Verified','status'=>'Active','created_at'=>date('Y-m-d',strtotime('-5 days'))],
        ['id'=>4,'customer_number'=>'CUS20260004','first_name'=>'Meron','last_name'=>'Alemu','phone'=>'0944567890','branch_name'=>'Bole','kyc_status'=>'Verified','status'=>'Active','created_at'=>date('Y-m-d',strtotime('-6 days'))],
        ['id'=>5,'customer_number'=>'CUS20260005','first_name'=>'Dawit','last_name'=>'Mekonnen','phone'=>'0955678901','branch_name'=>'Arada','kyc_status'=>'Under Review','status'=>'Active','created_at'=>date('Y-m-d',strtotime('-7 days'))],
    ];
}
?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-chart-pie" style="color:#1B3A5C;margin-right:8px"></i>Customer Overview</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Customer Overview</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <a href="<?= APP_URL ?>/customers" class="btn btn-ghost btn-sm"><i class="fa-solid fa-list"></i> All Customers</a>
    <a href="<?= APP_URL ?>/customers/register" class="btn btn-primary btn-sm"><i class="fa-solid fa-user-plus"></i> New Customer</a>
  </div>
</div>

<!-- KPI Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:22px">
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-users"></i></div><div class="stat-content"><div class="stat-label">Total Customers</div><div class="stat-value"><?= number_format($st['total']) ?></div><div class="stat-change up"><i class="fa-solid fa-arrow-trend-up"></i> All time</div></div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div><div class="stat-content"><div class="stat-label">Active</div><div class="stat-value"><?= number_format($st['active']) ?></div><div class="stat-change up"><i class="fa-solid fa-arrow-trend-up"></i> <?= round($st['active']/$st['total']*100) ?>% of total</div></div></div>
  <div class="stat-card"><div class="stat-icon teal"><i class="fa-solid fa-id-card"></i></div><div class="stat-content"><div class="stat-label">KYC Verified</div><div class="stat-value"><?= number_format($st['kyc_ok']) ?></div><div class="stat-change up"><i class="fa-solid fa-arrow-trend-up"></i> <?= round($st['kyc_ok']/$st['total']*100) ?>% verified</div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><i class="fa-solid fa-user-plus"></i></div><div class="stat-content"><div class="stat-label">New This Month</div><div class="stat-value"><?= number_format($st['new_month']) ?></div><div class="stat-change up"><i class="fa-solid fa-arrow-trend-up"></i> +12% vs last month</div></div></div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px;margin-bottom:22px">
  <!-- Charts -->
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-chart-bar" style="color:#1B3A5C;margin-right:7px"></i>Customer Growth (Last 12 Months)</h3></div>
    <div class="card-body"><div style="height:280px"><canvas id="cust-growth-chart"></canvas></div></div>
  </div>
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-chart-pie" style="color:#1B3A5C;margin-right:7px"></i>Customer Segments</h3></div>
    <div class="card-body">
      <div style="height:220px"><canvas id="cust-segment-chart"></canvas></div>
      <div style="display:flex;flex-direction:column;gap:7px;margin-top:14px">
        <?php foreach([['Retail','#1B3A5C','65%'],['Premium','#007A8A','20%'],['SME','#C8A84B','10%'],['Corporate','#10b981','5%']] as [$l,$c,$p]): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:.79rem">
          <div style="display:flex;align-items:center;gap:7px"><div style="width:10px;height:10px;border-radius:50%;background:<?= $c ?>;flex-shrink:0"></div><span style="color:#475569"><?= $l ?></span></div>
          <span style="font-weight:700;color:#1e293b"><?= $p ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Branch Distribution + KYC Status -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-bottom:22px">
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-building" style="color:#1B3A5C;margin-right:7px"></i>Customer by Branch</h3></div>
    <div class="card-body">
      <?php foreach([['Bole (Addis)',620,25],['Kirkos',480,19],['Arada',410,17],['Bahir Dar',380,15],['Hawassa',320,13],['Dire Dawa',240,10],['Others',278,11]] as [$bn,$count,$pct]): ?>
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:.81rem;font-weight:600;color:#374151"><?= $bn ?></span><span style="font-size:.78rem;color:#64748b"><?= number_format($count) ?> (<?= $pct ?>%)</span></div>
        <div style="height:7px;background:#e2e8f0;border-radius:99px;overflow:hidden"><div style="height:100%;width:<?= $pct ?>%;background:linear-gradient(90deg,#1B3A5C,#007A8A);border-radius:99px"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><h3><i class="fa-solid fa-id-card" style="color:#1B3A5C;margin-right:7px"></i>KYC Status Overview</h3></div>
    <div class="card-body">
      <?php foreach([['Verified',1980,'#10b981','success',81],['Pending',347,'#f59e0b','warning',14],['Under Review',89,'#007A8A','info',4],['Rejected',34,'#ef4444','danger',1]] as [$l,$count,$c,$badge,$pct]): ?>
      <div style="display:flex;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid #f1f5f9">
        <div style="width:38px;height:38px;border-radius:9px;background:<?= $c ?>1a;color:<?= $c ?>;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0"><i class="fa-solid fa-id-card"></i></div>
        <div style="flex:1">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:.82rem;font-weight:600;color:#1e293b"><?= $l ?></span><span style="font-size:.79rem;font-weight:700;color:<?= $c ?>"><?= number_format($count) ?></span></div>
          <div style="height:5px;background:#f1f5f9;border-radius:99px;overflow:hidden"><div style="height:100%;width:<?= $pct ?>%;background:<?= $c ?>;border-radius:99px"></div></div>
        </div>
      </div>
      <?php endforeach; ?>
      <div style="margin-top:14px">
        <a href="<?= APP_URL ?>/customers/kyc" style="display:flex;align-items:center;justify-content:center;gap:7px;padding:10px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border-radius:9px;text-decoration:none;font-size:.83rem;font-weight:700"><i class="fa-solid fa-id-card"></i> Manage KYC</a>
      </div>
    </div>
  </div>
</div>

<!-- Recently Registered -->
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-user-plus" style="color:#1B3A5C;margin-right:7px"></i>Recently Registered Customers</h3>
    <a href="<?= APP_URL ?>/customers" style="font-size:.76rem;color:#007A8A;font-weight:700;text-decoration:none">View All →</a>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead><tr><th>Customer ID</th><th>Name</th><th>Phone</th><th>Branch</th><th>KYC Status</th><th>Status</th><th>Registered</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($recentList as $c):
          $ksc = match($c['kyc_status']??'') {'Verified'=>'success','Pending'=>'warning','Rejected'=>'danger',default=>'info'};
          $sc  = ($c['status']??'') === 'Active' ? 'success' : 'danger';
          $ini = strtoupper(substr($c['first_name']??'U',0,1));
        ?>
        <tr>
          <td><span style="font-family:monospace;font-size:.76rem;color:#475569;font-weight:600"><?= htmlspecialchars($c['customer_number']??'—') ?></span></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;flex-shrink:0"><?= $ini ?></div>
              <span style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($c['first_name'].' '.$c['last_name']) ?></span>
            </div>
          </td>
          <td style="font-size:.81rem"><?= htmlspecialchars($c['phone']??'—') ?></td>
          <td style="font-size:.81rem;color:#475569"><?= htmlspecialchars($c['branch_name']??'—') ?></td>
          <td><span class="badge badge-<?= $ksc ?>"><?= htmlspecialchars($c['kyc_status']??'—') ?></span></td>
          <td><span class="badge badge-<?= $sc ?>"><?= htmlspecialchars($c['status']??'—') ?></span></td>
          <td style="font-size:.78rem;color:#94a3b8"><?= htmlspecialchars($c['created_at']??'—') ?></td>
          <td>
            <div style="display:flex;gap:4px">
              <a href="<?= APP_URL ?>/customers/profile?id=<?= $c['id'] ?>" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="View Profile"><i class="fa-solid fa-eye" style="color:#007A8A"></i></a>
              <a href="<?= APP_URL ?>/customers/kyc" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="KYC"><i class="fa-solid fa-id-card" style="color:#1B3A5C"></i></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  if (typeof Chart === 'undefined') return;
  Chart.defaults.font.family = "'Inter',sans-serif";
  Chart.defaults.color = '#64748b';
  // Growth chart
  new Chart(document.getElementById('cust-growth-chart'), {
    type: 'bar',
    data: {
      labels: ['Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'],
      datasets: [{ label: 'New Customers', data: [89,102,115,98,132,148,156,143,167,182,198,124], backgroundColor: 'rgba(27,58,92,.75)', borderRadius: 5 }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { grid: { color: 'rgba(0,0,0,.04)' } } } }
  });
  // Segment doughnut
  new Chart(document.getElementById('cust-segment-chart'), {
    type: 'doughnut',
    data: {
      labels: ['Retail','Premium','SME','Corporate'],
      datasets: [{ data: [65,20,10,5], backgroundColor: ['#1B3A5C','#007A8A','#C8A84B','#10b981'], borderWidth: 3, borderColor: '#fff', hoverOffset: 6 }]
    },
    options: { responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { display: false } } }
  });
});
</script>
