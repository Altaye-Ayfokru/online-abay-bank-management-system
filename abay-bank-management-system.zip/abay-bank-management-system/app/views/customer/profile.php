﻿<?php
/**
 * Abay Bank — View: Customer Profile
 * Auto-generated from: frontend/pages/customer/customer-profile.html
 * PHP data available: $user, $stats, $data (from PageController)
 */
?>

  <div class="page-header">
    <div class="page-header-left">
      <h1>Customer Profile</h1>
      <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/dashboard">Customers</a><span class="sep">/</span><span id="breadcrumb-name">Profile</span></div>
    </div>
    <div style="display:flex;gap:var(--space-3)">
      <button class="btn btn-light btn-sm" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
      <button class="btn btn-outline-primary btn-sm" onclick="Modal.open('edit-customer-modal')"><i class="fa-solid fa-pen"></i> Edit</button>
      <button class="btn btn-danger btn-sm" onclick="Confirm.show('Suspend this customer?',()=>Toast.warning('Customer suspended.'),{type:'danger'})"><i class="fa-solid fa-ban"></i> Suspend</button>
    </div>
  </div>

  <!-- Profile Hero -->
  <div class="card" style="margin-bottom:var(--space-6)">
    <div style="background:linear-gradient(135deg,var(--primary-dark),var(--primary-light));padding:var(--space-8) var(--space-8) var(--space-10);position:relative">
      <div style="display:flex;align-items:center;gap:var(--space-6);flex-wrap:wrap">
        <div class="avatar avatar-2xl" style="background:var(--secondary);color:var(--primary-dark);font-weight:900;font-size:2rem;border:4px solid rgba(255,255,255,.3)" id="profile-avatar">AB</div>
        <div style="color:white">
          <h2 id="profile-name" style="color:white;margin-bottom:var(--space-2)">Abebe Bekele</h2>
          <div style="display:flex;gap:var(--space-4);flex-wrap:wrap;font-size:var(--text-sm);opacity:.85">
            <span><i class="fa-solid fa-id-card"></i> <span id="profile-id">CUST-00001</span></span>
            <span><i class="fa-solid fa-envelope"></i> <span id="profile-email">abebe@email.com</span></span>
            <span><i class="fa-solid fa-phone"></i> <span id="profile-phone">0911234567</span></span>
            <span><i class="fa-solid fa-building"></i> <span id="profile-branch">Bole Branch</span></span>
          </div>
        </div>
        <div style="margin-left:auto;display:flex;gap:var(--space-3);flex-wrap:wrap">
          <span class="badge badge-success badge-dot" style="font-size:.8rem;padding:6px 14px">Active</span>
          <span class="badge badge-info badge-dot" style="font-size:.8rem;padding:6px 14px">KYC Verified</span>
        </div>
      </div>
    </div>
    <!-- Account Summary Cards -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:0;border-top:1px solid var(--border-color)">
      <div style="padding:var(--space-5) var(--space-6);border-right:1px solid var(--border-color);text-align:center">
        <div style="font-size:var(--text-xs);color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:var(--space-1)">Total Balance</div>
        <div style="font-size:var(--text-xl);font-weight:800;color:var(--success)">ETB 124,500</div>
      </div>
      <div style="padding:var(--space-5) var(--space-6);border-right:1px solid var(--border-color);text-align:center">
        <div style="font-size:var(--text-xs);color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:var(--space-1)">Accounts</div>
        <div style="font-size:var(--text-xl);font-weight:800;color:var(--primary)">3</div>
      </div>
      <div style="padding:var(--space-5) var(--space-6);border-right:1px solid var(--border-color);text-align:center">
        <div style="font-size:var(--text-xs);color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:var(--space-1)">Active Loans</div>
        <div style="font-size:var(--text-xl);font-weight:800;color:var(--warning)">1</div>
      </div>
      <div style="padding:var(--space-5) var(--space-6);text-align:center">
        <div style="font-size:var(--text-xs);color:var(--text-muted);font-weight:600;text-transform:uppercase;margin-bottom:var(--space-1)">Member Since</div>
        <div style="font-size:var(--text-xl);font-weight:800;color:var(--primary)">Jan 2022</div>
      </div>
    </div>
  </div>

  <!-- Tabs -->
  <div style="display:flex;gap:0;border-bottom:2px solid var(--border-color);margin-bottom:var(--space-6)">
    <button class="tab-btn active" data-tab="info" onclick="switchTab('info',this)" style="padding:var(--space-3) var(--space-5);background:none;border:none;border-bottom:3px solid var(--primary);cursor:pointer;font-weight:600;color:var(--primary);font-size:var(--text-sm)">Personal Info</button>
    <button class="tab-btn" data-tab="accounts" onclick="switchTab('accounts',this)" style="padding:var(--space-3) var(--space-5);background:none;border:none;border-bottom:3px solid transparent;cursor:pointer;font-weight:500;color:var(--text-muted);font-size:var(--text-sm)">Accounts</button>
    <button class="tab-btn" data-tab="transactions" onclick="switchTab('transactions',this)" style="padding:var(--space-3) var(--space-5);background:none;border:none;border-bottom:3px solid transparent;cursor:pointer;font-weight:500;color:var(--text-muted);font-size:var(--text-sm)">Transactions</button>
    <button class="tab-btn" data-tab="loans" onclick="switchTab('loans',this)" style="padding:var(--space-3) var(--space-5);background:none;border:none;border-bottom:3px solid transparent;cursor:pointer;font-weight:500;color:var(--text-muted);font-size:var(--text-sm)">Loans</button>
    <button class="tab-btn" data-tab="documents" onclick="switchTab('documents',this)" style="padding:var(--space-3) var(--space-5);background:none;border:none;border-bottom:3px solid transparent;cursor:pointer;font-weight:500;color:var(--text-muted);font-size:var(--text-sm)">Documents</button>
  </div>

  <!-- Tab: Personal Info -->
  <div id="tab-info" class="tab-panel" style="display:block">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-6)">
      <div class="card"><div class="card-header"><h4><i class="fa-solid fa-user text-primary"></i> Personal Details</h4></div>
        <div class="card-body">
          <div class="info-row"><span class="info-label">Full Name</span><span class="info-value">Abebe Bekele</span></div>
          <div class="info-row"><span class="info-label">Date of Birth</span><span class="info-value">15 March 1985</span></div>
          <div class="info-row"><span class="info-label">Gender</span><span class="info-value">Male</span></div>
          <div class="info-row"><span class="info-label">Nationality</span><span class="info-value">Ethiopian</span></div>
          <div class="info-row"><span class="info-label">National ID</span><span class="info-value mono">ET12345678</span></div>
          <div class="info-row"><span class="info-label">Occupation</span><span class="info-value">Business Owner</span></div>
        </div>
      </div>
      <div class="card"><div class="card-header"><h4><i class="fa-solid fa-address-book text-primary"></i> Contact & Address</h4></div>
        <div class="card-body">
          <div class="info-row"><span class="info-label">Phone</span><span class="info-value">0911 234 567</span></div>
          <div class="info-row"><span class="info-label">Alt. Phone</span><span class="info-value">0922 345 678</span></div>
          <div class="info-row"><span class="info-label">Email</span><span class="info-value">abebe@email.com</span></div>
          <div class="info-row"><span class="info-label">Region</span><span class="info-value">Addis Ababa</span></div>
          <div class="info-row"><span class="info-label">Subcity</span><span class="info-value">Bole, Woreda 03</span></div>
          <div class="info-row"><span class="info-label">P.O. Box</span><span class="info-value">1234</span></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tab: Accounts -->
  <div id="tab-accounts" class="tab-panel" style="display:none">
    <div class="card"><div class="card-header"><h4><i class="fa-solid fa-building-columns text-primary"></i> Customer Accounts</h4>
      <a href="<?= APP_URL ?>/dashboard" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Open Account</a></div>
      <div class="table-responsive">
        <table class="data-table"><thead><tr><th>Account No.</th><th>Type</th><th>Balance</th><th>Interest</th><th>Status</th><th>Opened</th><th>Actions</th></tr></thead>
        <tbody>
          <tr><td class="cell-account">1000 0000 0001</td><td><span class="badge badge-success">Savings</span></td><td class="amount text-success">ETB 84,500.00</td><td>3.5%</td><td><span class="badge badge-success badge-dot">Active</span></td><td>Jan 2022</td><td><div class="table-actions"><a href="<?= APP_URL ?>/dashboard" class="action-btn view" data-tooltip="Statement"><i class="fa-solid fa-file-lines"></i></a></div></td></tr>
          <tr><td class="cell-account">2000 0000 0001</td><td><span class="badge badge-info">Current</span></td><td class="amount text-success">ETB 40,000.00</td><td>�</td><td><span class="badge badge-success badge-dot">Active</span></td><td>Mar 2022</td><td><div class="table-actions"><a href="<?= APP_URL ?>/dashboard" class="action-btn view" data-tooltip="Statement"><i class="fa-solid fa-file-lines"></i></a></div></td></tr>
        </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Tab: Transactions -->
  <div id="tab-transactions" class="tab-panel" style="display:none">
    <div class="card"><div class="card-header"><h4><i class="fa-solid fa-list text-primary"></i> Transaction History</h4>
      <a href="<?= APP_URL ?>/dashboard" class="btn btn-ghost btn-sm">View All <i class="fa-solid fa-arrow-right"></i></a></div>
      <div class="table-responsive">
        <table class="data-table"><thead><tr><th>Txn ID</th><th>Date</th><th>Type</th><th>Amount</th><th>Balance</th><th>Status</th></tr></thead>
        <tbody id="profile-txn-tbody"></tbody></table>
      </div>
    </div>
  </div>

  <!-- Tab: Loans -->
  <div id="tab-loans" class="tab-panel" style="display:none">
    <div class="card"><div class="card-header"><h4><i class="fa-solid fa-file-invoice-dollar text-primary"></i> Loan History</h4>
      <a href="<?= APP_URL ?>/dashboard" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Apply Loan</a></div>
      <div class="table-responsive">
        <table class="data-table"><thead><tr><th>Loan ID</th><th>Type</th><th>Amount</th><th>EMI</th><th>Outstanding</th><th>Status</th></tr></thead>
        <tbody>
          <tr><td class="cell-account">L-00123</td><td><span class="badge badge-info">Personal</span></td><td class="amount">ETB 100,000</td><td class="amount">ETB 2,224</td><td class="amount text-warning">ETB 67,000</td><td><span class="badge badge-success badge-dot">Active</span></td></tr>
        </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Tab: Documents -->
  <div id="tab-documents" class="tab-panel" style="display:none">
    <div class="card"><div class="card-header"><h4><i class="fa-solid fa-folder-open text-primary"></i> KYC Documents</h4>
      <button class="btn btn-primary btn-sm" onclick="Modal.open('upload-doc-modal')"><i class="fa-solid fa-upload"></i> Upload</button></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:var(--space-4)">
          <div class="card" style="border:2px solid var(--success)"><div class="card-body text-center" style="padding:var(--space-5)">
            <i class="fa-solid fa-id-card" style="font-size:2rem;color:var(--success);margin-bottom:var(--space-3)"></i>
            <div style="font-weight:600;margin-bottom:var(--space-1)">National ID</div>
            <span class="badge badge-success badge-dot">Verified</span>
          </div></div>
          <div class="card" style="border:2px solid var(--success)"><div class="card-body text-center" style="padding:var(--space-5)">
            <i class="fa-solid fa-passport" style="font-size:2rem;color:var(--success);margin-bottom:var(--space-3)"></i>
            <div style="font-weight:600;margin-bottom:var(--space-1)">Passport</div>
            <span class="badge badge-success badge-dot">Verified</span>
          </div></div>
          <div class="card" style="border:2px dashed var(--border-color)"><div class="card-body text-center" style="padding:var(--space-5)">
            <i class="fa-solid fa-file-image" style="font-size:2rem;color:var(--text-muted);margin-bottom:var(--space-3)"></i>
            <div style="font-weight:600;margin-bottom:var(--space-1)">Utility Bill</div>
            <span class="badge badge-warning badge-dot">Pending</span>
          </div></div>
        </div>
      </div>
    </div>
  </div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
