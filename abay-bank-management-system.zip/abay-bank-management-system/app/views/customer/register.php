<?php $pageTitle = 'Register Customer — ' . APP_NAME; ?>
<?php
/**
 * Abay Bank — View: Register Customer
 * Auto-generated from: frontend/pages/customer/customer-registration.html
 * PHP data available: $user, $stats, $data (from PageController)
 */
?>

  <div class="page-header">
    <div class="page-header-left">
      <h1>Register New Customer</h1>
      <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/dashboard">Customers</a><span class="sep">/</span><span>Register</span></div>
    </div>
    <a href="<?= APP_URL ?>/dashboard" class="btn btn-ghost btn-sm"><i class="fa-solid fa-arrow-left"></i> Back to List</a>
  </div>

  <!-- Step Wizard -->
  <div class="step-wizard" id="step-wizard">
    <div class="step-item active" id="step-1-indicator"><div class="step-number">1</div><div class="step-label">Personal Info</div></div>
    <div class="step-item" id="step-2-indicator"><div class="step-number">2</div><div class="step-label">Contact & Address</div></div>
    <div class="step-item" id="step-3-indicator"><div class="step-number">3</div><div class="step-label">Account Setup</div></div>
    <div class="step-item" id="step-4-indicator"><div class="step-number">4</div><div class="step-label">Documents</div></div>
    <div class="step-item" id="step-5-indicator"><div class="step-number">5</div><div class="step-label">Review</div></div>
  </div>

  <form id="registration-form" novalidate>
    <!-- Step 1: Personal Info -->
    <div id="step-1" class="step-panel active">
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-user text-primary"></i> Personal Information</h3></div>
        <div class="card-body">
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">First Name <span class="required">*</span></label><input type="text" name="first_name" class="form-control" placeholder="Abebe"></div>
            <div class="form-group"><label class="form-label">Middle Name</label><input type="text" name="middle_name" class="form-control" placeholder="Girma"></div>
            <div class="form-group"><label class="form-label">Last Name <span class="required">*</span></label><input type="text" name="last_name" class="form-control" placeholder="Bekele"></div>
          </div>
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Date of Birth <span class="required">*</span></label><input type="date" name="dob" class="form-control"></div>
            <div class="form-group"><label class="form-label">Gender <span class="required">*</span></label>
              <select name="gender" class="form-control"><option value="">Select...</option><option>Male</option><option>Female</option></select></div>
            <div class="form-group"><label class="form-label">Marital Status</label>
              <select class="form-control"><option>Single</option><option>Married</option><option>Divorced</option><option>Widowed</option></select></div>
          </div>
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Nationality</label><input type="text" class="form-control" value="Ethiopian"></div>
            <div class="form-group"><label class="form-label">National ID <span class="required">*</span></label><input type="text" name="national_id" class="form-control" placeholder="ET12345678"></div>
            <div class="form-group"><label class="form-label">Occupation</label><input type="text" class="form-control" placeholder="Business Owner"></div>
          </div>
        </div>
        <div class="form-actions"><button type="button" class="btn btn-primary" onclick="nextStep(2)">Next: Contact Info <i class="fa-solid fa-arrow-right"></i></button></div>
      </div>
    </div>

    <!-- Step 2: Contact & Address -->
    <div id="step-2" class="step-panel">
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-address-book text-primary"></i> Contact & Address</h3></div>
        <div class="card-body">
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Phone Number <span class="required">*</span></label><input type="tel" name="phone" class="form-control" placeholder="0911234567" data-format="phone"></div>
            <div class="form-group"><label class="form-label">Alt. Phone</label><input type="tel" class="form-control" placeholder="0922345678" data-format="phone"></div>
            <div class="form-group"><label class="form-label">Email Address <span class="required">*</span></label><input type="email" name="email" class="form-control" placeholder="abebe@email.com"></div>
          </div>
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Region <span class="required">*</span></label>
              <select name="region" class="form-control"><option>Addis Ababa</option><option>Oromia</option><option>Amhara</option><option>SNNPR</option><option>Tigray</option><option>Somali</option><option>Afar</option></select></div>
            <div class="form-group"><label class="form-label">City</label><input type="text" class="form-control" placeholder="Addis Ababa"></div>
            <div class="form-group"><label class="form-label">Subcity / Woreda</label><input type="text" class="form-control" placeholder="Bole, Woreda 03"></div>
          </div>
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Kebele</label><input type="text" class="form-control" placeholder="01"></div>
            <div class="form-group"><label class="form-label">House No.</label><input type="text" class="form-control" placeholder="123"></div>
            <div class="form-group"><label class="form-label">P.O. Box</label><input type="text" class="form-control" placeholder="1234"></div>
          </div>
        </div>
        <div class="form-actions between">
          <button type="button" class="btn btn-ghost" onclick="prevStep(1)"><i class="fa-solid fa-arrow-left"></i> Back</button>
          <button type="button" class="btn btn-primary" onclick="nextStep(3)">Next: Account Setup <i class="fa-solid fa-arrow-right"></i></button>
        </div>
      </div>
    </div>

    <!-- Step 3: Account Setup -->
    <div id="step-3" class="step-panel">
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-building-columns text-primary"></i> Account Setup</h3></div>
        <div class="card-body">
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Branch <span class="required">*</span></label>
              <select name="branch" class="form-control"><option value="">Select branch...</option><option>Addis Ababa Main</option><option>Bole</option><option>Kirkos</option><option>Arada</option><option>Lideta</option><option>Yeka</option><option>Alem Ketema</option></select></div>
            <div class="form-group"><label class="form-label">Account Type <span class="required">*</span></label>
              <select name="account_type" class="form-control"><option>Savings</option><option>Current</option><option>Fixed Deposit</option></select></div>
            <div class="form-group"><label class="form-label">Currency</label>
              <select class="form-control"><option>ETB - Ethiopian Birr</option><option>USD - US Dollar</option><option>EUR - Euro</option></select></div>
          </div>
          <div class="form-row form-row-3">
            <div class="form-group"><label class="form-label">Initial Deposit (ETB) <span class="required">*</span></label>
              <div class="input-addon-group"><span class="input-addon">ETB</span><input type="number" name="initial_deposit" class="form-control" placeholder="500.00" min="100" data-format="amount"></div></div>
            <div class="form-group"><label class="form-label">Customer Segment</label>
              <select class="form-control"><option>Retail</option><option>Premium</option><option>Corporate</option><option>SME</option></select></div>
            <div class="form-group"><label class="form-label">Relationship Manager</label>
              <select class="form-control"><option value="">Assign later...</option><option>Tigist Haile</option><option>Solomon Girma</option></select></div>
          </div>
        </div>
        <div class="form-actions between">
          <button type="button" class="btn btn-ghost" onclick="prevStep(2)"><i class="fa-solid fa-arrow-left"></i> Back</button>
          <button type="button" class="btn btn-primary" onclick="nextStep(4)">Next: Documents <i class="fa-solid fa-arrow-right"></i></button>
        </div>
      </div>
    </div>

    <!-- Step 4: Documents -->
    <div id="step-4" class="step-panel">
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-folder-open text-primary"></i> KYC Documents</h3></div>
        <div class="card-body">
          <div class="form-row form-row-2">
            <div class="form-group"><label class="form-label">National ID / Kebele ID <span class="required">*</span></label>
              <div class="file-drop-zone"><input type="file" accept=".jpg,.jpeg,.png,.pdf"><div class="file-icon"><i class="fa-solid fa-id-card"></i></div><div class="file-title">Upload ID Document</div><div class="file-hint">Drag & drop or click to browse</div><div class="file-types"><span class="file-type-badge">JPG</span><span class="file-type-badge">PNG</span><span class="file-type-badge">PDF</span></div></div></div>
            <div class="form-group"><label class="form-label">Passport (Optional)</label>
              <div class="file-drop-zone"><input type="file" accept=".jpg,.jpeg,.png,.pdf"><div class="file-icon"><i class="fa-solid fa-passport"></i></div><div class="file-title">Upload Passport</div><div class="file-hint">Drag & drop or click to browse</div></div></div>
            <div class="form-group"><label class="form-label">Customer Photo <span class="required">*</span></label>
              <div class="file-drop-zone"><input type="file" accept=".jpg,.jpeg,.png"><div class="file-icon"><i class="fa-solid fa-camera"></i></div><div class="file-title">Upload Photo</div><div class="file-hint">Passport-size photo (JPG/PNG)</div></div></div>
            <div class="form-group"><label class="form-label">Utility Bill / Address Proof</label>
              <div class="file-drop-zone"><input type="file" accept=".jpg,.jpeg,.png,.pdf"><div class="file-icon"><i class="fa-solid fa-file-invoice"></i></div><div class="file-title">Address Proof</div><div class="file-hint">Electric, water or phone bill</div></div></div>
          </div>
        </div>
        <div class="form-actions between">
          <button type="button" class="btn btn-ghost" onclick="prevStep(3)"><i class="fa-solid fa-arrow-left"></i> Back</button>
          <button type="button" class="btn btn-primary" onclick="nextStep(5)">Next: Review <i class="fa-solid fa-arrow-right"></i></button>
        </div>
      </div>
    </div>

    <!-- Step 5: Review -->
    <div id="step-5" class="step-panel">
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-clipboard-check text-primary"></i> Review &amp; Submit</h3></div>
        <div class="card-body">
          <div class="alert alert-info"><i class="fa-solid fa-circle-info alert-icon"></i><div class="alert-content"><div class="alert-title">Review your information</div><div class="alert-message">Please confirm all details before submitting.</div></div></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
            <div>
              <h4 style="margin-bottom:12px;color:var(--primary)">Personal Info</h4>
              <div class="info-row"><span class="info-label">Full Name</span><span class="info-value" id="rv-name">--</span></div>
              <div class="info-row"><span class="info-label">Date of Birth</span><span class="info-value" id="rv-dob">--</span></div>
              <div class="info-row"><span class="info-label">Gender</span><span class="info-value" id="rv-gender">--</span></div>
              <div class="info-row"><span class="info-label">National ID</span><span class="info-value" id="rv-nid">--</span></div>
              <div class="info-row"><span class="info-label">Phone</span><span class="info-value" id="rv-phone">--</span></div>
              <div class="info-row"><span class="info-label">Email</span><span class="info-value" id="rv-email">--</span></div>
            </div>
            <div>
              <h4 style="margin-bottom:12px;color:var(--primary)">Account Info</h4>
              <div class="info-row"><span class="info-label">Branch</span><span class="info-value" id="rv-branch">--</span></div>
              <div class="info-row"><span class="info-label">Account Type</span><span class="info-value" id="rv-acct">--</span></div>
              <div class="info-row"><span class="info-label">Initial Deposit</span><span class="info-value" id="rv-deposit">--</span></div>
              <div class="info-row"><span class="info-label">Region</span><span class="info-value" id="rv-region">--</span></div>
            </div>
          </div>
          <div id="doc-upload-status" style="margin-top:16px;font-size:.82rem;color:#64748b"></div>
        </div>
        <div class="form-actions between">
          <button type="button" class="btn btn-ghost" onclick="prevStep(4)"><i class="fa-solid fa-arrow-left"></i> Back</button>
          <button type="submit" id="submit-registration" class="btn btn-primary btn-lg ripple"><i class="fa-solid fa-user-plus"></i> Register Customer</button>
        </div>
      </div>
    </div>
  </form>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
var _currentStep = 1;

function nextStep(n) {
  // Populate review when moving to step 5
  if (n === 5) populateReview();
  document.getElementById('step-' + _currentStep).classList.remove('active');
  document.getElementById('step-' + _currentStep + '-indicator').classList.remove('active');
  _currentStep = n;
  document.getElementById('step-' + n).classList.add('active');
  document.getElementById('step-' + n + '-indicator').classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function prevStep(n) { nextStep(n); }

function g(name) {
  var el = document.querySelector('[name="' + name + '"]');
  return el ? el.value.trim() : '';
}

function populateReview() {
  var fn  = g('first_name'), mn = g('middle_name') ? ' ' + g('middle_name') : '', ln = g('last_name');
  document.getElementById('rv-name').textContent    = (fn + mn + ' ' + ln).trim() || '--';
  document.getElementById('rv-dob').textContent     = g('dob')        || '--';
  document.getElementById('rv-gender').textContent  = g('gender')     || '--';
  document.getElementById('rv-nid').textContent     = g('national_id')|| '--';
  document.getElementById('rv-phone').textContent   = g('phone')      || '--';
  document.getElementById('rv-email').textContent   = g('email')      || '--';
  document.getElementById('rv-branch').textContent  = g('branch')     || '--';
  document.getElementById('rv-acct').textContent    = g('account_type')|| '--';
  var dep = parseFloat(g('initial_deposit')) || 0;
  document.getElementById('rv-deposit').textContent = dep > 0 ? 'ETB ' + dep.toLocaleString() : '--';
  document.getElementById('rv-region').textContent  = g('region')     || '--';

  // Show document upload status
  var docFiles = document.querySelectorAll('#step-4 input[type="file"]');
  var uploaded = 0;
  docFiles.forEach(function(f) { if (f.files && f.files.length) uploaded++; });
  var statusEl = document.getElementById('doc-upload-status');
  if (statusEl) {
    statusEl.innerHTML = uploaded > 0
      ? '<i class="fa-solid fa-circle-check" style="color:#10b981"></i> ' + uploaded + ' document(s) selected for upload'
      : '<i class="fa-solid fa-triangle-exclamation" style="color:#f59e0b"></i> No documents selected (you can add them later)';
  }
}

document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('registration-form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var fn    = g('first_name');
    var ln    = g('last_name');
    var phone = g('phone');
    var nid   = g('national_id');
    var email = g('email');
    var dob   = g('dob');
    var gender= g('gender');
    var region= g('region');
    var acct  = g('account_type');
    var dep   = parseFloat(g('initial_deposit')) || 0;
    var branch= g('branch');

    if (!fn || !ln || !phone) {
      ABAY.toast('First name, last name and phone are required.', 'err');
      return;
    }

    var btn = document.getElementById('submit-registration');
    ABAY.setBtn('submit-registration', true);

    // Step 1: Register the customer
    ABAY.api('/customers', {
      method: 'POST',
      body: JSON.stringify({
        first_name: fn, last_name: ln, phone: phone,
        email: email, dob: dob, gender: gender,
        national_id: nid, region: region,
        address: region, account_type: acct,
        initial_deposit: dep, branch: branch,
        id_type: 'National ID', id_number: nid
      })
    }).then(function (d) {
      if (d && d.success) {
        var custId = d.data && d.data.customer_id;
        ABAY.toast((fn + ' ' + ln) + ' registered! ID: ' + (d.data && d.data.customer_number || ''), 'ok');

        // Step 2: Upload documents if any files selected
        var docFields = [
          { input: document.querySelectorAll('#step-4 input[type="file"]')[0], type: 'National ID' },
          { input: document.querySelectorAll('#step-4 input[type="file"]')[1], type: 'Passport' },
          { input: document.querySelectorAll('#step-4 input[type="file"]')[2], type: 'Photo' },
          { input: document.querySelectorAll('#step-4 input[type="file"]')[3], type: 'Utility Bill' },
        ];
        var uploads = docFields.filter(function(df) {
          return df.input && df.input.files && df.input.files.length > 0;
        });
        var uploadPromises = uploads.map(function(df) {
          var fd = new FormData();
          fd.append('document', df.input.files[0]);
          fd.append('doc_type', df.type);
          fd.append('field_name', df.type.toLowerCase().replace(' ','_'));
          if (custId) fd.append('customer_id', custId);
          return fetch(window.BASE_URL + '/api/upload/customer-document', {
            method: 'POST',
            credentials: 'include',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: fd
          }).then(function(r) { return r.json(); }).catch(function() { return null; });
        });

        Promise.all(uploadPromises).then(function(results) {
          ABAY.setBtn('submit-registration', false, '<i class="fa-solid fa-user-plus"></i> Register Customer');
          var uploaded = results.filter(function(r) { return r && r.success; }).length;
          if (uploaded > 0) ABAY.toast(uploaded + ' document(s) uploaded successfully.', 'success');
          setTimeout(function () { window.location.href = ABAY.url('customers'); }, 1800);
        });

      } else {
        ABAY.setBtn('submit-registration', false, '<i class="fa-solid fa-user-plus"></i> Register Customer');
        ABAY.toast((d && d.message) || 'Registration failed. Please try again.', 'err');
      }
    }).catch(function () {
      ABAY.setBtn('submit-registration', false, '<i class="fa-solid fa-user-plus"></i> Register Customer');
      ABAY.toast('Demo: ' + fn + ' ' + ln + ' registered (Database offline).', 'info');
      setTimeout(function () { window.location.href = ABAY.url('customers'); }, 2000);
    });
  });
});
</script>