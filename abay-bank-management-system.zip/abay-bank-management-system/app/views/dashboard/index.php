<?php
$name  = \Web\Core\View::e($user['full_name'] ?? $user['username'] ?? 'User');
$first = htmlspecialchars(explode(' ', $user['full_name'] ?? $user['username'] ?? 'User')[0]);
$role  = \Web\Core\View::e($user['role'] ?? 'Staff');
$hour  = (int)date('G');
$greet = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$s     = $stats ?? [];
$live  = $dbOnline ?? false;
$fmt   = fn($n) => number_format((int)($n ?? 0));
$etb   = fn($n) => 'ETB ' . number_format((float)($n ?? 0), 2);
$s += [
  'customers' => 2450,
  'accounts' => 3182,
  'today_transactions' => 842,
  'active_loans' => 124,
  'total_deposits' => 1250000,
  'total_withdrawals' => 890000,
  'employees' => 156,
  'branches' => 9
];
?>
<style>
  /* ── VIRTUAL CARD FLIP ── */
  .vc-scene {
    width: 100%;
    height: 185px;
    perspective: 1000px;
    cursor: pointer;
    user-select: none;
  }

  .vc-inner {
    width: 100%;
    height: 100%;
    position: relative;
    transform-style: preserve-3d;
    transition: transform .65s cubic-bezier(.4, 0, .2, 1);
  }

  .vc-inner.flipped {
    transform: rotateY(180deg);
  }

  .vc-face {
    position: absolute;
    inset: 0;
    border-radius: 16px;
    backface-visibility: hidden;
    -webkit-backface-visibility: hidden;
    overflow: hidden;
  }

  .vc-front {
    color: #fff;
    padding: 20px 20px 16px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-shadow: 0 12px 40px rgba(0, 0, 0, .28);
  }

  .vc-back {
    transform: rotateY(180deg);
    background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
    box-shadow: 0 12px 40px rgba(0, 0, 0, .28);
  }

  .cn-navy {
    background: linear-gradient(135deg, #1B3A5C, #254d7a);
  }

  .cn-teal {
    background: linear-gradient(135deg, #007A8A, #00a3b5);
  }

  .cn-gold {
    background: linear-gradient(135deg, #92400e, #C8A84B);
  }

  .cn-dark {
    background: linear-gradient(135deg, #1e293b, #475569);
  }

  .cn-purple {
    background: linear-gradient(135deg, #5b21b6, #7c3aed);
  }

  .vc-chip {
    width: 34px;
    height: 26px;
    background: linear-gradient(135deg, rgba(255, 255, 255, .35), rgba(255, 255, 255, .15));
    border-radius: 4px;
    margin: 8px 0;
  }

  .vc-num {
    font-size: .88rem;
    letter-spacing: 3px;
    font-family: 'Courier New', monospace;
    opacity: .9;
    margin-bottom: 8px;
  }

  .vc-bot {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
  }

  .vc-holder-lbl {
    font-size: .58rem;
    opacity: .6;
    text-transform: uppercase;
    letter-spacing: .5px;
  }

  .vc-holder-name {
    font-size: .76rem;
    font-weight: 700;
    text-transform: uppercase;
    margin-top: 1px;
  }

  .vc-exp-lbl {
    font-size: .58rem;
    opacity: .6;
    text-transform: uppercase;
    letter-spacing: .5px;
    text-align: right;
  }

  .vc-exp-val {
    font-size: .76rem;
    font-weight: 700;
    text-align: right;
    margin-top: 1px;
  }

  .vc-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .vc-bank-name {
    font-size: .65rem;
    font-weight: 700;
    opacity: .75;
    text-transform: uppercase;
    letter-spacing: .8px;
  }

  .vc-network {
    font-size: 1.5rem;
  }

  .vc-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: .6rem;
    font-weight: 700;
    padding: 2px 8px;
    background: rgba(255, 255, 255, .2);
    border-radius: 99px;
    backdrop-filter: blur(4px);
  }

  .pulse-green {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: #6ee7b7;
    animation: pulse-g 2s infinite;
  }

  .pulse-yellow {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: #fbbf24;
  }

  @keyframes pulse-g {

    0%,
    100% {
      opacity: 1
    }

    50% {
      opacity: .3
    }
  }

  .vc-back-stripe {
    height: 42px;
    background: rgba(0, 0, 0, .5);
    margin: 22px 0 16px;
  }

  .vc-back-body {
    padding: 0 16px;
  }

  .vc-sig {
    height: 32px;
    background: linear-gradient(90deg, #f1f5f9, #fff);
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0 10px;
    gap: 8px;
  }

  .vc-sig-text {
    font-size: .65rem;
    color: #64748b;
    font-style: italic;
  }

  .vc-cvv {
    font-size: .88rem;
    font-weight: 900;
    color: #1e293b;
    font-family: 'Courier New', monospace;
  }

  .vc-back-info {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 6px;
    margin-top: 10px;
  }

  .vc-bi-label {
    font-size: .58rem;
    color: rgba(255, 255, 255, .45);
    text-transform: uppercase;
    letter-spacing: .5px;
  }

  .vc-bi-val {
    font-size: .68rem;
    color: rgba(255, 255, 255, .85);
    font-weight: 600;
    margin-top: 1px;
  }

  /* Card action buttons */
  .vc-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 10px;
  }

  .vc-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    padding: 8px 10px;
    border: 1.5px solid #e2e8f0;
    border-radius: 9px;
    font-size: .76rem;
    font-weight: 600;
    cursor: pointer;
    transition: all .2s;
    background: #fff;
    color: #334155;
    font-family: inherit;
  }

  .vc-btn:hover {
    background: #f8fafc;
    border-color: #007A8A;
    color: #007A8A;
  }

  .vc-btn.primary {
    background: linear-gradient(135deg, #1B3A5C, #007A8A);
    color: #fff;
    border-color: transparent;
  }

  .vc-btn.primary:hover {
    box-shadow: 0 4px 14px rgba(0, 122, 138, .35);
    transform: translateY(-1px);
  }

  .vc-btn.danger {
    color: #dc2626;
    border-color: #fecaca;
  }

  .vc-btn.danger:hover {
    background: #fee2e2;
  }

  .vc-add {
    border: 2px dashed #e2e8f0;
    border-radius: 16px;
    height: 185px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    transition: all .3s;
    color: #94a3b8;
    background: transparent;
  }

  .vc-add:hover {
    border-color: #007A8A;
    color: #007A8A;
    background: #f0fbfc;
  }

  .vc-add-ic {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    transition: all .3s;
  }

  .vc-add:hover .vc-add-ic {
    background: #e0f5f7;
    color: #007A8A;
  }

  /* Transfer Method Grid */
  .tm-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
  }

  .tm-item {
    background: #fff;
    border: 1.5px solid #e2e8f0;
    border-radius: 14px;
    padding: 16px 12px 12px;
    cursor: pointer;
    transition: all .25s;
    display: flex;
    flex-direction: column;
    gap: 5px;
    position: relative;
    text-align: center;
  }

  .tm-item:hover {
    border-color: #007A8A;
    box-shadow: 0 6px 24px rgba(0, 122, 138, .14);
    transform: translateY(-3px);
  }

  .tm-item:active {
    transform: translateY(-1px);
  }

  .tm-ic {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    margin: 0 auto 6px;
    transition: transform .25s;
  }

  .tm-item:hover .tm-ic {
    transform: scale(1.1);
  }

  .tm-name {
    font-size: .83rem;
    font-weight: 700;
    color: #1e293b;
  }

  .tm-desc {
    font-size: .7rem;
    color: #94a3b8;
    line-height: 1.3;
  }

  .tm-badge {
    position: absolute;
    top: 8px;
    right: 8px;
    font-size: .56rem;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 99px;
    text-transform: uppercase;
  }

  .popular {
    background: #dcfce7;
    color: #15803d;
  }

  .fast {
    background: #fef3c7;
    color: #92400e;
  }

  .new-badge {
    background: #dbeafe;
    color: #1d4ed8;
  }

  /* Modal system */
  .db-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, .6);
    backdrop-filter: blur(6px);
    z-index: 1050;
    align-items: center;
    justify-content: center;
    padding: 16px;
  }

  .db-modal.open {
    display: flex;
    animation: mFade .2s ease;
  }

  @keyframes mFade {
    from {
      opacity: 0
    }

    to {
      opacity: 1
    }
  }

  .db-mbox {
    background: #fff;
    border-radius: 20px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 32px 80px rgba(0, 0, 0, .28);
    animation: mSlide .3s ease;
  }

  .db-mbox.wide {
    max-width: 580px;
  }

  @keyframes mSlide {
    from {
      transform: translateY(28px);
      opacity: 0
    }

    to {
      transform: translateY(0);
      opacity: 1
    }
  }

  .db-mh {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 22px 14px;
    border-bottom: 1px solid #f1f5f9;
    position: sticky;
    top: 0;
    background: #fff;
    z-index: 2;
    border-radius: 20px 20px 0 0;
  }

  .db-mh-l {
    display: flex;
    align-items: center;
    gap: 11px;
  }

  .db-mh-ic {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
  }

  .db-mh h3 {
    font-size: .98rem;
    font-weight: 800;
    color: #1B3A5C;
    margin: 0;
  }

  .db-mh p {
    font-size: .73rem;
    color: #94a3b8;
    margin: 2px 0 0;
  }

  .db-mx {
    width: 30px;
    height: 30px;
    border: none;
    background: #f1f5f9;
    border-radius: 7px;
    cursor: pointer;
    font-size: .85rem;
    color: #64748b;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all .2s;
    flex-shrink: 0;
  }

  .db-mx:hover {
    background: #e2e8f0;
    color: #1e293b;
  }

  .db-mb {
    padding: 18px 22px;
  }

  .db-mf {
    padding: 13px 22px 18px;
    border-top: 1px solid #f1f5f9;
    display: flex;
    gap: 9px;
    justify-content: flex-end;
    position: sticky;
    bottom: 0;
    background: #fff;
    border-radius: 0 0 20px 20px;
  }

  /* Form inside modal */
  .mf-g {
    margin-bottom: 14px;
  }

  .mf-lbl {
    display: block;
    font-size: .72rem;
    font-weight: 700;
    color: #374151;
    margin-bottom: 5px;
    text-transform: uppercase;
    letter-spacing: .5px;
  }

  .mf-inp {
    width: 100%;
    padding: 10px 13px;
    border: 1.5px solid #e2e8f0;
    border-radius: 9px;
    font-size: .87rem;
    font-family: inherit;
    outline: none;
    transition: border .2s;
    color: #1e293b;
    background: #fff;
  }

  .mf-inp:focus {
    border-color: #007A8A;
    box-shadow: 0 0 0 3px rgba(0, 122, 138, .1);
  }

  select.mf-inp {
    cursor: pointer;
  }

  .mf-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 13px;
  }

  .mf-row3 {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 10px;
  }

  .mf-sec {
    background: #f8fafc;
    border-radius: 10px;
    padding: 13px 14px;
    margin-bottom: 13px;
  }

  .mf-sec-t {
    font-size: .68rem;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: .8px;
    margin-bottom: 11px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .mf-sec-t i {
    color: #007A8A;
  }

  .mf-amt-box {
    background: linear-gradient(135deg, #1B3A5C, #007A8A);
    border-radius: 12px;
    padding: 14px 16px;
    margin-bottom: 14px;
    text-align: center;
    display: none;
  }

  .mf-amt-box.show {
    display: block;
  }

  .mf-amt-box .albl {
    font-size: .65rem;
    color: rgba(255, 255, 255, .6);
    text-transform: uppercase;
    letter-spacing: .8px;
    margin-bottom: 3px;
  }

  .mf-amt-box .aval {
    font-size: 2rem;
    font-weight: 900;
    color: #fff;
  }

  .mf-amt-box .aval span {
    font-size: .85rem;
    color: rgba(255, 255, 255, .65);
    margin-right: 3px;
  }

  .mf-amt-box .afee {
    font-size: .68rem;
    color: rgba(255, 255, 255, .5);
    margin-top: 3px;
  }

  .mf-alert {
    display: none;
    padding: 9px 12px;
    border-radius: 8px;
    font-size: .81rem;
    margin-bottom: 12px;
    align-items: center;
    gap: 8px;
  }

  .mf-alert.show {
    display: flex;
  }

  .mf-alert.err {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #991b1b;
  }

  .mf-alert.ok {
    background: #d1fae5;
    border: 1px solid #a7f3d0;
    color: #065f46;
  }

  .mf-alert.info {
    background: #dbeafe;
    border: 1px solid #bfdbfe;
    color: #1e40af;
  }

  .db-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 20px;
    background: linear-gradient(135deg, #1B3A5C, #007A8A);
    color: #fff;
    border: none;
    border-radius: 9px;
    font-size: .86rem;
    font-weight: 700;
    cursor: pointer;
    font-family: inherit;
    transition: all .25s;
  }

  .db-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 5px 18px rgba(0, 122, 138, .38);
  }

  .db-btn:disabled {
    opacity: .6;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }

  .db-btn-cancel {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    background: #f1f5f9;
    color: #374151;
    border: none;
    border-radius: 9px;
    font-size: .86rem;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
    transition: background .2s;
  }

  .db-btn-cancel:hover {
    background: #e2e8f0;
  }

  @keyframes db-spin {
    to {
      transform: rotate(360deg)
    }
  }

  .db-spin {
    width: 14px;
    height: 14px;
    border: 2px solid rgba(255, 255, 255, .3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: db-spin .6s linear infinite;
    display: inline-block;
  }

  /* Toast */
  #db-toasts {
    position: fixed;
    bottom: 22px;
    right: 22px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 9px;
    max-width: 320px;
    pointer-events: none;
  }

  .db-t {
    display: flex;
    align-items: flex-start;
    gap: 9px;
    padding: 12px 14px;
    border-radius: 11px;
    box-shadow: 0 6px 28px rgba(0, 0, 0, .14);
    border: 1px solid;
    font-size: .82rem;
    animation: tSlide .3s ease;
    pointer-events: all;
  }

  @keyframes tSlide {
    from {
      transform: translateX(110%);
      opacity: 0
    }

    to {
      transform: translateX(0);
      opacity: 1
    }
  }

  .db-t.ok {
    background: #d1fae5;
    border-color: #a7f3d0;
    color: #065f46;
  }

  .db-t.err {
    background: #fee2e2;
    border-color: #fecaca;
    color: #991b1b;
  }

  .db-t.info {
    background: #dbeafe;
    border-color: #bfdbfe;
    color: #1e40af;
  }

  .db-t .tic {
    font-size: .9rem;
    flex-shrink: 0;
    margin-top: 1px;
  }
</style>

<!-- Accent bar -->
<div style="margin:-24px -24px 0;height:4px;background:linear-gradient(90deg,#1B3A5C,#007A8A 55%,#C8A84B)"></div>

<!-- WELCOME BANNER -->
<div style="background:linear-gradient(135deg,#1B3A5C 0%,#007A8A 100%);border-radius:16px;margin:20px 0 24px;position:relative;overflow:hidden">
  <div style="position:absolute;top:-80px;right:-80px;width:300px;height:300px;background:radial-gradient(circle,rgba(200,168,75,.15),transparent 70%);border-radius:50%;pointer-events:none"></div>
  <div style="display:flex;align-items:center;justify-content:space-between;padding:22px 26px;gap:16px;flex-wrap:wrap;position:relative;z-index:1">
    <div style="display:flex;align-items:center;gap:16px">
      <div style="display:flex;align-items:flex-end;gap:3px;background:rgba(255,255,255,.14);border-radius:10px;padding:7px 9px 9px;flex-shrink:0">
        <div style="width:5px;height:12px;background:#C8A84B;border-radius:2px 2px 0 0"></div>
        <div style="width:5px;height:17px;background:#7ecfd8;border-radius:2px 2px 0 0"></div>
        <div style="width:5px;height:22px;background:#fff;border-radius:2px 2px 0 0"></div>
        <div style="width:5px;height:12px;background:#7ecfd8;border-radius:2px 2px 0 0"></div>
      </div>
      <div>
        <div style="font-size:.65rem;color:rgba(255,255,255,.5);font-weight:700;letter-spacing:1.3px;text-transform:uppercase;margin-bottom:2px">Abay Bank Management System</div>
        <div style="font-size:1.25rem;font-weight:800;color:#fff;display:flex;align-items:center;gap:9px;flex-wrap:wrap">
          <?= $greet ?>, <?= $first ?>!
          <?php if (!$live): ?><span style="background:rgba(200,168,75,.25);color:#C8A84B;padding:2px 8px;border-radius:99px;font-size:.6rem;font-weight:700"><i class="fa-solid fa-circle-exclamation" style="margin-right:3px"></i>Demo Mode</span><?php else: ?><span style="background:rgba(16,185,129,.22);color:#6ee7b7;padding:2px 8px;border-radius:99px;font-size:.6rem;font-weight:700"><i class="fa-solid fa-circle" style="font-size:.35rem;margin-right:3px"></i>Live DB</span><?php endif; ?>
        </div>
        <div style="font-size:.78rem;color:rgba(255,255,255,.62);margin-top:3px">
          <i class="fa-solid fa-calendar-day" style="color:#C8A84B;margin-right:4px"></i><?= date('l, d F Y') ?>&nbsp;&middot;&nbsp;
          <i class="fa-solid fa-user-shield" style="color:#C8A84B;margin-right:4px"></i><?= $role ?>&nbsp;&middot;&nbsp;
          <i class="fa-solid fa-clock" style="color:#C8A84B;margin-right:4px"></i><span id="dash-clock"><?= date('H:i:s') ?></span>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button onclick="openModal('depositModal')" style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:8px 14px;border-radius:9px;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-arrow-down"></i>Deposit</button>
      <button onclick="openModal('localTransferModal')" style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:8px 14px;border-radius:9px;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-right-left"></i>Transfer</button>
      <button onclick="openModal('newCustomerModal')" style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:8px 14px;border-radius:9px;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-user-plus"></i>New Customer</button>
      <a href="<?= APP_URL ?>/reports/financial" style="display:inline-flex;align-items:center;gap:6px;background:#C8A84B;color:#1B3A5C;padding:8px 14px;border-radius:9px;font-size:.78rem;font-weight:700;text-decoration:none"><i class="fa-solid fa-chart-bar"></i>Reports</a>
    </div>
  </div>
</div>

<!-- KPI CARDS -->
<div class="stats-grid" style="margin-bottom:24px">
  <?php
  $kpis = [
    ['Total Customers',      $fmt($s['customers']),           'fa-users',                 'blue',   '+4.2% this month',   'up',   APP_URL . '/customers',           'kpi-customers'],
    ['Active Accounts',      $fmt($s['accounts']),            'fa-building-columns',       'green',  '+2.8% this month',   'up',   APP_URL . '/accounts/savings',    'kpi-accounts'],
    ["Today's Txns",         $fmt($s['today_transactions']),  'fa-arrow-right-arrow-left', 'teal',   '+12% vs yesterday',  'up',   APP_URL . '/transactions',        'kpi-txns'],
    ["Today's Deposits",     $etb($s['total_deposits']),      'fa-arrow-down',             'green',  '+8.5% vs yesterday', 'up',   APP_URL . '/transactions/deposit', 'kpi-deposits'],
    ["Today's Withdrawals",  $etb($s['total_withdrawals']),   'fa-arrow-up',               'red',    '-2.1% vs yesterday', 'down', APP_URL . '/transactions/withdrawal', 'kpi-withdrawals'],
    ['Active Loans',         $fmt($s['active_loans']),        'fa-file-invoice-dollar',    'yellow', '47 pending',         'info', APP_URL . '/loans',               'kpi-loans'],
    ['Total Employees',      $fmt($s['employees']),           'fa-people-group',           'purple', $fmt((int)($s['employees'] * .92)) . ' present today', 'up', APP_URL . '/employees', 'kpi-employees'],
    ['Active Branches',      $fmt($s['branches']),            'fa-building',               'orange', 'All operational',    'up',   APP_URL . '/branches',            'kpi-branches'],
  ];
  foreach ($kpis as [$lbl, $val, $ic, $clr, $chg, $dir, $href, $kid]): ?>
    <a href="<?= $href ?>" style="text-decoration:none;display:block">
      <div class="stat-card" style="cursor:pointer;transition:transform .2s,box-shadow .2s;border:1.5px solid transparent" onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='0 12px 32px rgba(0,0,0,.12)';this.style.borderColor='#e2e8f0'" onmouseout="this.style.transform='';this.style.boxShadow='';this.style.borderColor='transparent'">
        <div class="stat-icon <?= $clr ?>"><i class="fa-solid <?= $ic ?>"></i></div>
        <div class="stat-content">
          <div class="stat-label"><?= $lbl ?></div>
          <div class="stat-value" id="<?= $kid ?>" style="font-size:<?= strlen($val) > 10 ? '1.05rem' : '1.35rem' ?>"><?= $val ?></div>
          <div class="stat-change <?= $dir === 'down' ? 'down' : 'up' ?>" style="font-size:.7rem;margin-top:3px">
            <i class="fa-solid <?= $dir === 'down' ? 'fa-arrow-trend-down' : ($dir === 'info' ? 'fa-circle-info' : 'fa-arrow-trend-up') ?>" style="font-size:.67rem"></i> <?= $chg ?>
          </div>
        </div>
      </div>
    </a>
  <?php endforeach; ?>
</div>

<!-- SEND MONEY SECTION -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header" style="padding:16px 20px 12px">
    <div>
      <h3 style="font-size:.95rem;font-weight:800;color:#1B3A5C;margin:0"><i class="fa-solid fa-paper-plane" style="color:#007A8A;margin-right:7px"></i>Send Money</h3>
      <p style="font-size:.76rem;color:#94a3b8;margin:3px 0 0">Choose your preferred transfer method</p>
    </div>
    <a href="<?= APP_URL ?>/transactions/transfer" style="font-size:.78rem;color:#007A8A;font-weight:700;text-decoration:none">View All <i class="fa-solid fa-arrow-right"></i></a>
  </div>
  <div class="card-body">
    <div style="font-size:.65rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:12px">Primary Methods</div>
    <div class="tm-grid" style="margin-bottom:18px">
      <div class="tm-item" onclick="openModal('localTransferModal')">
        <span class="tm-badge popular">Popular</span>
        <div class="tm-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-building-columns"></i></div>
        <div class="tm-name">Local Transfer</div>
        <div class="tm-desc">Domestic ETB transfer</div>
      </div>
      <div class="tm-item" onclick="openModal('wireTransferModal')">
        <div class="tm-ic" style="background:#ede9fe;color:#5b21b6"><i class="fa-solid fa-globe"></i></div>
        <div class="tm-name">Wire Transfer</div>
        <div class="tm-desc">International bank transfer</div>
      </div>
      <div class="tm-item" onclick="openModal('ethswitchModal')">
        <span class="tm-badge fast">Fast</span>
        <div class="tm-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-bolt"></i></div>
        <div class="tm-name">EthSwitch</div>
        <div class="tm-desc">Real-time inter-bank ETB</div>
      </div>
      <div class="tm-item" onclick="openModal('telebirrModal')">
        <span class="tm-badge popular">Popular</span>
        <div class="tm-ic" style="background:#fed7aa;color:#ea580c"><i class="fa-solid fa-mobile-screen"></i></div>
        <div class="tm-name">Telebirr</div>
        <div class="tm-desc">Mobile money transfer</div>
      </div>
    </div>
    <div style="font-size:.65rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:12px">More Options</div>
    <div class="tm-grid">
      <div class="tm-item" onclick="openModal('wuModal')">
        <div class="tm-ic" style="background:#fef9c3;color:#854d0e;font-size:1rem;font-weight:900">WU</div>
        <div class="tm-name">Western Union</div>
        <div class="tm-desc">Cash pickup worldwide</div>
      </div>
      <div class="tm-item" onclick="openModal('mpesaModal')">
        <span class="tm-badge new-badge">New</span>
        <div class="tm-ic" style="background:#d1fae5;color:#047857"><i class="fa-solid fa-sim-card"></i></div>
        <div class="tm-name">M-Pesa</div>
        <div class="tm-desc">Mobile wallet transfer</div>
      </div>
      <div class="tm-item" onclick="openModal('wiseModal')">
        <span class="tm-badge new-badge">New</span>
        <div class="tm-ic" style="background:#dcfce7;color:#16a34a" style="font-size:.85rem;font-weight:900">wise</div>
        <div class="tm-name">Wise</div>
        <div class="tm-desc">Low-fee multi-currency</div>
      </div>
      <div class="tm-item" onclick="openModal('payoneerModal')">
        <div class="tm-ic" style="background:#fee2e2;color:#dc2626"><i class="fa-solid fa-credit-card"></i></div>
        <div class="tm-name">Payoneer</div>
        <div class="tm-desc">Business payments</div>
      </div>
    </div>
  </div>
</div>

<!-- VIRTUAL CARDS SECTION -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header" style="padding:16px 20px 12px">
    <div>
      <h3 style="font-size:.95rem;font-weight:800;color:#1B3A5C;margin:0"><i class="fa-solid fa-credit-card" style="color:#007A8A;margin-right:7px"></i>Your Cards</h3>
      <p style="font-size:.76rem;color:#94a3b8;margin:3px 0 0">Manage your virtual debit cards</p>
    </div>
    <div style="display:flex;align-items:center;gap:10px">
      <a href="<?= APP_URL ?>/accounts/atm-cards" style="font-size:.78rem;color:#007A8A;font-weight:700;text-decoration:none">View all <i class="fa-solid fa-arrow-right"></i></a>
      <button onclick="openModal('applyCardModal')" style="display:inline-flex;align-items:center;gap:5px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;padding:7px 14px;font-size:.78rem;font-weight:700;cursor:pointer;font-family:inherit"><i class="fa-solid fa-plus"></i>Apply for Card</button>
    </div>
  </div>
  <div class="card-body">
    <!-- Card stats row -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:20px">
      <div style="background:#f8fafc;border-radius:10px;padding:13px 14px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:.7rem;color:#94a3b8;margin-bottom:3px">Total Balance</div>
          <div style="font-size:1.1rem;font-weight:800;color:#1B3A5C"><?= $etb($s['total_deposits'] * 0.05) ?></div>
        </div>
        <div style="width:34px;height:34px;background:#e0f5f7;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#007A8A"><i class="fa-solid fa-wallet"></i></div>
      </div>
      <div style="background:#f8fafc;border-radius:10px;padding:13px 14px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:.7rem;color:#94a3b8;margin-bottom:3px">Total Transactions</div>
          <div style="font-size:1.1rem;font-weight:800;color:#1B3A5C">20</div>
        </div>
        <div style="width:34px;height:34px;background:#d1fae5;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#059669"><i class="fa-solid fa-arrow-trend-up"></i></div>
      </div>
      <div style="background:#f8fafc;border-radius:10px;padding:13px 14px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:.7rem;color:#94a3b8;margin-bottom:3px">Pending Applications</div>
          <div style="font-size:1.1rem;font-weight:800;color:#1B3A5C">1</div>
        </div>
        <div style="width:34px;height:34px;background:#fef3c7;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#d97706"><i class="fa-solid fa-hourglass-half"></i></div>
      </div>
    </div>

    <!-- Cards grid -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">

      <!-- Card 1: Visa Active -->
      <div>
        <div class="vc-scene" onclick="flipCard(1)" title="Click to flip card">
          <div class="vc-inner cn-navy" id="vc-inner-1">
            <div class="vc-face vc-front">
              <div class="vc-top">
                <div class="vc-bank-name">Abay Bank S.C.</div>
                <span class="vc-status-badge"><span class="pulse-green"></span> Active</span>
              </div>
              <div class="vc-chip"></div>
              <div class="vc-num">**** **** **** 8421</div>
              <div class="vc-bot">
                <div>
                  <div class="vc-holder-lbl">Card Holder</div>
                  <div class="vc-holder-name"><?= strtoupper($name) ?></div>
                </div>
                <div>
                  <div class="vc-exp-lbl">Expires</div>
                  <div class="vc-exp-val">12/28</div>
                </div>
                <div style="font-size:1.6rem;opacity:.9"><i class="fa-brands fa-cc-visa"></i></div>
              </div>
            </div>
            <div class="vc-face vc-back">
              <div class="vc-back-stripe"></div>
              <div class="vc-back-body">
                <div class="vc-sig">
                  <span class="vc-sig-text">Authorized Signature</span>
                  <span class="vc-cvv">***</span>
                </div>
                <div class="vc-back-info">
                  <div>
                    <div class="vc-bi-label">Card Type</div>
                    <div class="vc-bi-val">Virtual Debit</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Network</div>
                    <div class="vc-bi-val">Visa International</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Issued By</div>
                    <div class="vc-bi-val">Abay Bank S.C.</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Support</div>
                    <div class="vc-bi-val">+251 115 570 588</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="vc-actions">
          <button class="vc-btn" onclick="flipCard(1)"><i class="fa-solid fa-rotate"></i> Flip Card</button>
          <button class="vc-btn primary" onclick="openCardDetail(1,'Visa','8421','12/28','Active')"><i class="fa-solid fa-eye"></i> View Details</button>
          <button class="vc-btn" onclick="openModal('fundCardModal')"><i class="fa-solid fa-plus-circle"></i> Fund Card</button>
          <button class="vc-btn" onclick="openModal('cardBalanceModal')"><i class="fa-solid fa-arrow-right-arrow-left"></i> To Balance</button>
        </div>
      </div>

      <!-- Card 2: Mastercard Active -->
      <div>
        <div class="vc-scene" onclick="flipCard(2)" title="Click to flip card">
          <div class="vc-inner cn-teal" id="vc-inner-2">
            <div class="vc-face vc-front">
              <div class="vc-top">
                <div class="vc-bank-name">Abay Bank S.C.</div>
                <span class="vc-status-badge"><span class="pulse-green"></span> Active</span>
              </div>
              <div style="display:flex;margin:8px 0">
                <div style="width:28px;height:28px;border-radius:50%;background:#eb001b;opacity:.9"></div>
                <div style="width:28px;height:28px;border-radius:50%;background:#f79e1b;opacity:.9;margin-left:-12px"></div>
              </div>
              <div class="vc-num">**** **** **** 6241</div>
              <div class="vc-bot">
                <div>
                  <div class="vc-holder-lbl">Card Holder</div>
                  <div class="vc-holder-name"><?= strtoupper($name) ?></div>
                </div>
                <div>
                  <div class="vc-exp-lbl">Expires</div>
                  <div class="vc-exp-val">03/29</div>
                </div>
                <div style="font-size:.65rem;font-weight:700;opacity:.8">Standard</div>
              </div>
            </div>
            <div class="vc-face vc-back">
              <div class="vc-back-stripe"></div>
              <div class="vc-back-body">
                <div class="vc-sig">
                  <span class="vc-sig-text">Authorized Signature</span>
                  <span class="vc-cvv">***</span>
                </div>
                <div class="vc-back-info">
                  <div>
                    <div class="vc-bi-label">Card Type</div>
                    <div class="vc-bi-val">Virtual Debit</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Network</div>
                    <div class="vc-bi-val">Mastercard</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Issued By</div>
                    <div class="vc-bi-val">Abay Bank S.C.</div>
                  </div>
                  <div>
                    <div class="vc-bi-label">Support</div>
                    <div class="vc-bi-val">+251 115 570 588</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="vc-actions">
          <button class="vc-btn" onclick="flipCard(2)"><i class="fa-solid fa-rotate"></i> Flip Card</button>
          <button class="vc-btn primary" onclick="openCardDetail(2,'Mastercard','6241','03/29','Active')"><i class="fa-solid fa-eye"></i> View Details</button>
          <button class="vc-btn" onclick="openModal('fundCardModal')"><i class="fa-solid fa-plus-circle"></i> Fund Card</button>
          <button class="vc-btn" onclick="openModal('cardBalanceModal')"><i class="fa-solid fa-arrow-right-arrow-left"></i> To Balance</button>
        </div>
      </div>

      <!-- Card 3: Add New -->
      <div style="display:flex;flex-direction:column;gap:10px">
        <div class="vc-add" onclick="openModal('applyCardModal')">
          <div class="vc-add-ic"><i class="fa-solid fa-plus"></i></div>
          <div style="font-size:.84rem;font-weight:700;color:inherit">Apply for New Card</div>
          <div style="font-size:.72rem;color:#94a3b8;text-align:center">Virtual Visa / Mastercard<br>Instant approval</div>
        </div>
        <div style="background:#f8fafc;border-radius:12px;padding:13px 14px;border:1px solid #f1f5f9">
          <div style="font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px">Card Benefits</div>
          <?php foreach (['Free virtual card issuance', 'Zero foreign transaction fee', 'Instant freeze & unfreeze', 'Real-time spend alerts'] as $b): ?>
            <div style="display:flex;align-items:center;gap:7px;font-size:.76rem;color:#475569;margin-bottom:5px"><i class="fa-solid fa-circle-check" style="color:#10b981;font-size:.66rem"></i><?= $b ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- QUICK ACTIONS -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3><i class="fa-solid fa-bolt" style="color:#C8A84B;margin-right:7px"></i>Quick Actions</h3>
  </div>
  <div class="card-body">
    <div class="quick-actions" style="grid-template-columns:repeat(auto-fill,minmax(100px,1fr))">
      <?php
      $qa = [
        ['depositModal',       'fa-arrow-down',          '#10b981', 'Deposit',      true],
        ['/transactions/withdrawal', 'fa-arrow-up',       '#ef4444', 'Withdrawal',  false],
        ['localTransferModal', 'fa-right-left',           '#007A8A', 'Transfer',     true],
        ['newCustomerModal',   'fa-user-plus',             '#1B3A5C', 'New Customer', true],
        ['newEmployeeModal',   'fa-id-badge',              '#2d6a4f', 'New Employee', true],
        ['/accounts/opening',  'fa-folder-open',           '#7c3aed', 'Open Account', false],
        ['/loans/apply',       'fa-file-invoice-dollar',   '#f59e0b', 'Apply Loan',  false],
        ['/reports/financial', 'fa-chart-pie',             '#ea580c', 'Reports',      false],
      ];
      foreach ($qa as [$t, $ic, $clr, $lbl, $modal]): ?>
        <?php if ($modal): ?>
          <button onclick="openModal('<?= $t ?>')" class="quick-action-btn" style="border:none;background:none;cursor:pointer;font-family:inherit">
            <div class="qa-icon"><i class="fa-solid <?= $ic ?>" style="color:<?= $clr ?>"></i></div>
            <div class="qa-label"><?= $lbl ?></div>
          </button>
        <?php else: ?>
          <a href="<?= APP_URL . $t ?>" class="quick-action-btn">
            <div class="qa-icon"><i class="fa-solid <?= $ic ?>" style="color:<?= $clr ?>"></i></div>
            <div class="qa-label"><?= $lbl ?></div>
          </a>
      <?php endif;
      endforeach; ?>
      <!-- Employee Portal shortcut -->
      <a href="http://localhost/abay-bank-management-system/employee-portal/" target="_blank" class="quick-action-btn">
        <div class="qa-icon"><i class="fa-solid fa-id-badge" style="color:#2d6a4f"></i></div>
        <div class="qa-label">Emp. Portal</div>
      </a>
    </div>
  </div>
</div>

<!-- EMPLOYEE PORTAL BANNER -->
<div style="background:linear-gradient(135deg,#1B3A5C 0%,#2d6a4f 100%);border-radius:16px;padding:22px 26px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;position:relative;overflow:hidden">
  <div style="position:absolute;top:-40px;right:-40px;width:180px;height:180px;background:rgba(200,168,75,.12);border-radius:50%;pointer-events:none"></div>
  <div style="position:relative;z-index:1">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
      <div style="width:40px;height:40px;background:rgba(255,255,255,.15);border-radius:10px;display:flex;align-items:center;justify-content:center">
        <i class="fa-solid fa-id-badge" style="color:#C8A84B;font-size:1.1rem"></i>
      </div>
      <div>
        <div style="font-size:1rem;font-weight:800;color:#fff">Employee Self-Service Portal</div>
        <div style="font-size:.78rem;color:rgba(255,255,255,.65)">Payslips, attendance, leave, tasks, KPIs &amp; more</div>
      </div>
    </div>
    <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:.78rem;color:rgba(255,255,255,.55)">
      <span><i class="fa-solid fa-receipt" style="margin-right:4px;color:#C8A84B"></i>Payslips</span>
      <span><i class="fa-solid fa-calendar-check" style="margin-right:4px;color:#C8A84B"></i>Attendance</span>
      <span><i class="fa-solid fa-calendar-xmark" style="margin-right:4px;color:#C8A84B"></i>Leave Requests</span>
      <span><i class="fa-solid fa-list-check" style="margin-right:4px;color:#C8A84B"></i>Tasks</span>
      <span><i class="fa-solid fa-chart-bar" style="margin-right:4px;color:#C8A84B"></i>Performance</span>
    </div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;position:relative;z-index:1">
    <a href="http://localhost/abay-bank-management-system/employee-portal/" target="_blank"
      style="display:inline-flex;align-items:center;gap:8px;background:#C8A84B;color:#1B3A5C;padding:11px 22px;border-radius:10px;font-weight:800;font-size:.88rem;text-decoration:none;transition:.2s"
      onmouseover="this.style.background='#e8c86a'" onmouseout="this.style.background='#C8A84B'">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> Open Portal
    </a>
    <a href="http://localhost/abay-bank-management-system/employee-portal/auth/login.php" target="_blank"
      style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:11px 22px;border-radius:10px;font-weight:600;font-size:.88rem;text-decoration:none;transition:.2s"
      onmouseover="this.style.background='rgba(255,255,255,.2)'" onmouseout="this.style.background='rgba(255,255,255,.12)'">
      <i class="fa-solid fa-right-to-bracket"></i> Employee Sign In
    </a>
  </div>
</div>

<!-- CHARTS ROW -->
<div class="dashboard-row" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-chart-bar" style="color:#1B3A5C;margin-right:7px"></i>Monthly Revenue</h3>
      <div style="display:flex;gap:8px;align-items:center">
        <span class="badge badge-success badge-dot">Live</span>
        <select style="font-size:.72rem;border:1px solid #e2e8f0;border-radius:6px;padding:3px 8px;color:#475569;background:#fff;cursor:pointer">
          <option>2026</option>
          <option>2025</option>
        </select>
      </div>
    </div>
    <div class="card-body">
      <div class="chart-container" style="height:265px"><canvas id="revenueChart"></canvas></div>
    </div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-chart-line" style="color:#007A8A;margin-right:7px"></i>Daily Transactions</h3>
      <span class="badge badge-info badge-dot">Last 7 days</span>
    </div>
    <div class="card-body">
      <div class="chart-container" style="height:265px"><canvas id="txnChart"></canvas></div>
    </div>
  </div>
</div>

<!-- TRANSACTIONS + ACTIVITY + PENDING REQUESTS -->
<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;margin-bottom:24px">
  <!-- Recent Transactions -->
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-clock-rotate-left" style="color:#1B3A5C;margin-right:7px"></i>Recent Transactions</h3>
      <a href="<?= APP_URL ?>/transactions" class="btn btn-ghost btn-sm">View All <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <table class="data-table">
      <thead>
        <tr>
          <th>Reference</th>
          <th>Account</th>
          <th>Type</th>
          <th>Amount (ETB)</th>
          <th>Status</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody id="recent-txns-tbody">
        <?php
        $rows = !empty($recentTxns) ? $recentTxns : [
          ['reference' => 'DEP-A1B2C3', 'account_number' => '0001-10-100001', 'type' => 'Deposit',     'amount' => 15000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 min'))],
          ['reference' => 'WDR-B2C3D4', 'account_number' => '0001-20-100002', 'type' => 'Withdrawal',  'amount' => 5000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', strtotime('-18 min'))],
          ['reference' => 'TRF-C3D4E5', 'account_number' => '0001-10-100001', 'type' => 'Transfer Out', 'amount' => 8200, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', strtotime('-32 min'))],
          ['reference' => 'DEP-D4E5F6', 'account_number' => '0002-10-100003', 'type' => 'Deposit',     'amount' => 22500, 'status' => 'Pending',  'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
          ['reference' => 'TRF-E5F6G7', 'account_number' => '0003-20-100004', 'type' => 'Transfer In', 'amount' => 12000, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
          ['reference' => 'WDR-F6G7H8', 'account_number' => '0002-20-100005', 'type' => 'Withdrawal',  'amount' => 3200, 'status' => 'Completed', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))],
        ];
        foreach ($rows as $t):
          $tc = match ($t['type'] ?? '') {
            'Deposit', 'Transfer In' => 'success',
            'Withdrawal', 'Transfer Out' => 'danger',
            default => 'info'
          };
          $sc = ($t['status'] ?? '') === 'Completed' ? 'success' : (($t['status'] ?? '') === 'Pending' ? 'warning' : 'danger');
          $diff = time() - strtotime($t['created_at'] ?? 'now');
          $ago = $diff < 60 ? 'Just now' : ($diff < 3600 ? round($diff / 60) . 'm ago' : ($diff < 86400 ? round($diff / 3600) . 'h ago' : round($diff / 86400) . 'd ago'));
        ?>
          <tr>
            <td><span style="font-family:monospace;font-size:.75rem;color:#475569;font-weight:600"><?= \Web\Core\View::e($t['reference'] ?? '—') ?></span></td>
            <td style="font-size:.81rem"><?= \Web\Core\View::e($t['account_number'] ?? '—') ?></td>
            <td><span class="badge badge-<?= $tc ?>"><?= \Web\Core\View::e($t['type'] ?? '—') ?></span></td>
            <td style="font-weight:700;font-size:.82rem"><?= number_format((float)($t['amount'] ?? 0), 2) ?></td>
            <td><span class="badge badge-<?= $sc ?>"><?= \Web\Core\View::e($t['status'] ?? '—') ?></span></td>
            <td style="font-size:.73rem;color:#94a3b8"><?= $ago ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer" style="text-align:center"><a href="<?= APP_URL ?>/transactions" class="btn btn-outline-primary btn-sm">View All Transactions</a></div>
</div>

<!-- PENDING REQUESTS PANEL (from all portals) -->
<div class="card">
  <div class="card-header" style="padding-bottom:8px">
    <h3>
      <i class="fa-solid fa-inbox" style="color:#ef4444;margin-right:7px"></i>
      Pending Requests
      <?php
      $totalPending = ($stats['pending_loans'] ?? 3) + ($stats['pending_appointments'] ?? 5)
        + ($stats['pending_leave'] ?? 2) + ($stats['pending_kyc'] ?? 8)
        + ($stats['pending_complaints'] ?? 4);
      ?>
      <?php if ($totalPending > 0): ?>
        <span style="background:#ef4444;color:#fff;font-size:.65rem;padding:2px 7px;border-radius:99px;font-weight:700;vertical-align:middle;margin-left:4px"><?= $totalPending ?></span>
      <?php endif; ?>
    </h3>
    <a href="<?= APP_URL ?>/admin/requests" class="btn btn-ghost btn-sm">View All <i class="fa-solid fa-arrow-right"></i></a>
  </div>

  <!-- Summary badges -->
  <div style="display:flex;flex-wrap:wrap;gap:8px;padding:10px 20px 12px;border-bottom:1px solid #f1f5f9">
    <?php foreach (
      [
        ['Loans',        $stats['pending_loans'] ?? 3,        '#7c3aed', 'fa-file-invoice-dollar', APP_URL . '/loans/approval'],
        ['Appointments', $stats['pending_appointments'] ?? 5,  '#0d9488', 'fa-calendar-days',       APP_URL . '/support/appointments'],
        ['Leave',        $stats['pending_leave'] ?? 2,         '#f59e0b', 'fa-calendar-xmark',       APP_URL . '/employees/leave'],
        ['KYC',          $stats['pending_kyc'] ?? 8,           '#3b82f6', 'fa-id-card',              APP_URL . '/customers/kyc'],
        ['Complaints',   $stats['pending_complaints'] ?? 4,    '#ef4444', 'fa-headset',              APP_URL . '/support/complaints'],
      ] as [$label, $count, $color, $icon, $link]
    ): ?>
      <a href="<?= $link ?>" style="display:flex;align-items:center;gap:6px;background:<?= $color ?>0f;border:1px solid <?= $color ?>30;border-radius:8px;padding:6px 12px;text-decoration:none;transition:.2s" onmouseover="this.style.background='<?= $color ?>20'" onmouseout="this.style.background='<?= $color ?>0f'">
        <i class="fa-solid <?= $icon ?>" style="color:<?= $color ?>;font-size:.78rem"></i>
        <span style="font-size:.78rem;font-weight:700;color:#374151"><?= $label ?></span>
        <span style="background:<?= $color ?>;color:#fff;font-size:.65rem;padding:1px 7px;border-radius:99px;font-weight:700"><?= $count ?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Recent pending items feed -->
  <div class="card-body" style="padding:0">
    <?php
    $pending = $pendingRequests ?? [
      ['request_type' => 'Loan',        'icon' => 'fa-file-invoice-dollar', 'color' => '#7c3aed', 'name' => 'Abebe Bekele',  'detail' => 'Personal Loan — ETB 50,000',         'created_at' => date('Y-m-d H:i:s', time() - 3600),  'link' => APP_URL . '/loans/approval'],
      ['request_type' => 'KYC',         'icon' => 'fa-id-card',            'color' => '#3b82f6', 'name' => 'Daniel Worku',  'detail' => 'Identity verification required',      'created_at' => date('Y-m-d H:i:s', time() - 7200),  'link' => APP_URL . '/customers/kyc'],
      ['request_type' => 'Appointment', 'icon' => 'fa-calendar-days',      'color' => '#0d9488', 'name' => 'Meron Alemu',   'detail' => 'Loan Consultation — Alem Ketema',     'created_at' => date('Y-m-d H:i:s', time() - 10800), 'link' => APP_URL . '/support/appointments'],
      ['request_type' => 'Leave',       'icon' => 'fa-calendar-xmark',     'color' => '#f59e0b', 'name' => 'Yohannes Bekele', 'detail' => 'Annual Leave — 5 days',              'created_at' => date('Y-m-d H:i:s', time() - 18000), 'link' => APP_URL . '/employees/leave'],
      ['request_type' => 'Complaint',   'icon' => 'fa-headset',            'color' => '#ef4444', 'name' => 'Hanna Getnet',  'detail' => 'ATM card blocked — URGENT',           'created_at' => date('Y-m-d H:i:s', time() - 900),   'link' => APP_URL . '/support/complaints'],
    ];
    foreach (array_slice($pending, 0, 8) as $req):
      $diff = time() - strtotime($req['created_at'] ?? 'now');
      $ago  = $diff < 60 ? 'Just now' : ($diff < 3600 ? round($diff / 60) . 'm ago' : ($diff < 86400 ? round($diff / 3600) . 'h ago' : round($diff / 86400) . 'd ago'));
      $link = $req['link'] ?? APP_URL . '/admin/requests';
    ?>
      <a href="<?= htmlspecialchars($link) ?>" style="display:flex;align-items:flex-start;gap:9px;padding:10px 16px;border-bottom:1px solid #f8fafc;transition:background .15s;text-decoration:none" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
        <div style="width:32px;height:32px;border-radius:8px;background:<?= $req['color'] ?? '#94a3b8' ?>1a;color:<?= $req['color'] ?? '#94a3b8' ?>;display:flex;align-items:center;justify-content:center;font-size:.82rem;flex-shrink:0">
          <i class="fa-solid <?= $req['icon'] ?? 'fa-circle-dot' ?>"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px">
            <div>
              <span style="font-size:.77rem;font-weight:700;color:#1e293b"><?= htmlspecialchars($req['name'] ?? '—') ?></span>
              <span style="font-size:.68rem;background:<?= $req['color'] ?? '#94a3b8' ?>15;color:<?= $req['color'] ?? '#94a3b8' ?>;padding:1px 7px;border-radius:99px;font-weight:700;margin-left:6px"><?= htmlspecialchars($req['request_type'] ?? '') ?></span>
            </div>
            <span style="font-size:.67rem;color:#94a3b8;flex-shrink:0"><?= $ago ?></span>
          </div>
          <div style="font-size:.74rem;color:#64748b;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($req['detail'] ?? '') ?></div>
        </div>
      </a>
    <?php endforeach; ?>
    <?php if (empty($pending)): ?>
      <div style="padding:28px;text-align:center;color:#94a3b8;font-size:.84rem">
        <i class="fa-solid fa-check-circle" style="font-size:1.4rem;display:block;margin-bottom:6px;color:#10b981"></i>
        All caught up — no pending requests
      </div>
    <?php endif; ?>
  </div>
</div>
<div class="card-header">
  <h3><i class="fa-solid fa-bolt" style="color:#C8A84B;margin-right:7px"></i>Live Activity
    <span id="activity-live-dot" style="display:inline-block;width:7px;height:7px;background:#10b981;border-radius:50%;margin-left:6px;animation:pulse-g 2s infinite;vertical-align:middle"></span>
  </h3>
  <button onclick="loadActivity()" style="font-size:.72rem;color:#007A8A;font-weight:600;background:none;border:none;cursor:pointer;font-family:inherit" title="Refresh">
    <i class="fa-solid fa-rotate" id="activity-refresh-ic"></i> Refresh
  </button>
</div>
<div style="padding:13px 16px;border-bottom:1px solid #f1f5f9">
  <div style="font-size:.66rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:9px">Active Staff Today</div>
  <?php foreach (
    [
      ['Yohannes B.', 'Branch Mgr', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&q=80&auto=format&fit=crop'],
      ['Tigist H.', 'Teller', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&q=80&auto=format&fit=crop'],
      ['Solomon G.', 'Loan Officer', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=60&q=80&auto=format&fit=crop'],
    ] as [$sn, $sr, $si]
  ): ?>
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:7px">
      <img src="<?= $si ?>" alt="<?= $sn ?>" style="width:30px;height:30px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #e2e8f0" onerror="this.style.display='none'">
      <div style="flex:1">
        <div style="font-size:.76rem;font-weight:600;color:#1e293b"><?= $sn ?></div>
        <div style="font-size:.66rem;color:#007A8A"><?= $sr ?></div>
      </div>
      <span style="width:7px;height:7px;border-radius:50%;background:#10b981;display:inline-block;animation:pulse-g 2s infinite"></span>
    </div>
  <?php endforeach; ?>
</div>
<div class="card-body" style="padding:0" id="activity-feed">
  <!-- Loaded by JS -->
  <div style="padding:20px;text-align:center;color:#94a3b8;font-size:.82rem">
    <i class="fa-solid fa-spinner fa-spin" style="display:block;font-size:1.2rem;margin-bottom:6px"></i>Loading activity…
  </div>
</div>
</div>
</div>

<!-- 3-COL: BRANCHES + LOANS + ACCOUNT TYPES -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:22px;margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-building" style="color:#1B3A5C;margin-right:7px"></i>Branch Performance</h3>
    </div>
    <div class="card-body">
      <?php foreach ([['Bole (Addis)', 88, 'success'], ['Kirkos', 76, ''], ['Arada', 71, ''], ['Bahir Dar', 65, 'warning'], ['Hawassa', 58, 'warning'], ['Dire Dawa', 52, 'danger']] as [$bn, $bp, $bc]): ?>
        <div class="branch-item">
          <span class="branch-name" style="font-size:.77rem"><?= $bn ?></span>
          <div class="branch-progress">
            <div class="progress">
              <div class="progress-bar <?= $bc ?>" style="width:<?= $bp ?>%"></div>
            </div>
          </div>
          <span style="font-size:.77rem;font-weight:700;color:<?= $bc === 'danger' ? '#ef4444' : ($bc === 'warning' ? '#f59e0b' : '#1B3A5C') ?>;min-width:28px;text-align:right"><?= $bp ?>%</span>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="card-footer"><a href="<?= APP_URL ?>/branches/performance" class="btn btn-ghost btn-sm btn-full">All Branches <i class="fa-solid fa-arrow-right"></i></a></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-file-invoice-dollar" style="color:#1B3A5C;margin-right:7px"></i>Loan Portfolio</h3>
    </div>
    <div class="card-body" style="display:flex;flex-direction:column;gap:11px">
      <?php foreach (
        [
          ['ACTIVE',  $fmt($s['active_loans']) . ' Loans', '#d1fae5', '#065f46', '#059669', 'fa-circle-check', 'green'],
          ['PENDING', '47 Applications',                 '#fef3c7', '#92400e', '#d97706', 'fa-hourglass-half', 'yellow'],
          ['OVERDUE', '12 Accounts',                     '#fee2e2', '#991b1b', '#dc2626', 'fa-triangle-exclamation', 'red'],
        ] as [$lbl, $val, $bg, $tc, $vc, $icon, $clr]
      ): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:11px 13px;background:<?= $bg ?>;border-radius:10px">
          <div>
            <div style="font-size:.65rem;color:<?= $tc ?>;font-weight:700;text-transform:uppercase;letter-spacing:.5px"><?= $lbl ?></div>
            <div style="font-size:1.15rem;font-weight:800;color:<?= $vc ?>"><?= $val ?></div>
          </div>
          <div class="stat-icon <?= $clr ?>" style="width:38px;height:38px;flex-shrink:0"><i class="fa-solid <?= $icon ?>"></i></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="card-footer"><a href="<?= APP_URL ?>/loans" class="btn btn-ghost btn-sm btn-full">Manage Loans <i class="fa-solid fa-arrow-right"></i></a></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-chart-pie" style="color:#1B3A5C;margin-right:7px"></i>Account Types</h3>
    </div>
    <div class="card-body">
      <div class="chart-container" style="height:185px"><canvas id="acctChart"></canvas></div>
      <div style="display:flex;flex-direction:column;gap:6px;margin-top:12px">
        <?php foreach ([['Savings', '#10b981', '52%'], ['Current', '#1B3A5C', '31%'], ['Fixed Dep.', '#C8A84B', '17%']] as [$al, $ac, $ap]): ?>
          <div style="display:flex;align-items:center;justify-content:space-between;font-size:.77rem">
            <div style="display:flex;align-items:center;gap:6px">
              <div style="width:9px;height:9px;border-radius:50%;background:<?= $ac ?>;flex-shrink:0"></div><span style="color:#475569"><?= $al ?></span>
            </div>
            <span style="font-weight:700;color:#1e293b"><?= $ap ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- BOTTOM: APPROVALS + ATTENDANCE + TOP CUSTOMERS -->
<div style="display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:22px;margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-circle-exclamation" style="color:#f59e0b;margin-right:7px"></i>Pending Approvals</h3><span class="badge badge-warning">3</span>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Customer</th>
            <th>Amount</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><span class="badge badge-info">Loan</span></td>
            <td style="font-size:.8rem">Abebe Bekele</td>
            <td style="font-weight:600;font-size:.8rem">ETB 150,000</td>
            <td><a href="<?= APP_URL ?>/loans/approval" style="font-size:.73rem;color:#007A8A;font-weight:700">Review</a></td>
          </tr>
          <tr>
            <td><span class="badge badge-warning">Withdrawal</span></td>
            <td style="font-size:.8rem">Tigist Haile</td>
            <td style="font-weight:600;font-size:.8rem">ETB 45,000</td>
            <td><a href="<?= APP_URL ?>/transactions/approval" style="font-size:.73rem;color:#007A8A;font-weight:700">Review</a></td>
          </tr>
          <tr>
            <td><span class="badge badge-secondary">Transfer</span></td>
            <td style="font-size:.8rem">Solomon Girma</td>
            <td style="font-weight:600;font-size:.8rem">ETB 22,500</td>
            <td><a href="<?= APP_URL ?>/transactions/approval" style="font-size:.73rem;color:#007A8A;font-weight:700">Review</a></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="card-footer" style="text-align:center"><a href="<?= APP_URL ?>/loans/approval" class="btn btn-outline-primary btn-sm">All Approvals</a></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-check" style="color:#1B3A5C;margin-right:7px"></i>Attendance Today</h3>
    </div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:12px">
        <?php foreach ([['143', 'Present', '#d1fae5', '#059669', '#065f46'], ['13', 'Absent', '#fee2e2', '#dc2626', '#991b1b'], ['8', 'Late', '#fef3c7', '#d97706', '#92400e'], ['91%', 'Rate', '#dbeafe', '#2563eb', '#1e40af']] as [$v, $l, $bg, $vc, $tc]): ?>
          <div style="background:<?= $bg ?>;border-radius:10px;padding:11px;text-align:center">
            <div style="font-size:1.4rem;font-weight:800;color:<?= $vc ?>"><?= $v ?></div>
            <div style="font-size:.65rem;font-weight:700;color:<?= $tc ?>;text-transform:uppercase"><?= $l ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <div style="height:6px;background:#e2e8f0;border-radius:99px;overflow:hidden">
        <div style="height:100%;width:91%;background:linear-gradient(90deg,#10b981,#059669);border-radius:99px"></div>
      </div>
      <div style="font-size:.69rem;color:#94a3b8;text-align:right;margin-top:4px">91% attendance rate</div>
    </div>
    <div class="card-footer"><a href="<?= APP_URL ?>/employees/attendance" class="btn btn-ghost btn-sm btn-full">Full Report <i class="fa-solid fa-arrow-right"></i></a></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-star" style="color:#C8A84B;margin-right:7px"></i>Top Customers</h3>
    </div>
    <div class="card-body" style="padding:0">
      <?php foreach (
        [
          ['Dawit Mekonnen', 'ETB 2.4M', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&q=80&auto=format&fit=crop'],
          ['Selamawit Girma', 'ETB 1.8M', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&q=80&auto=format&fit=crop'],
          ['Abebe Worku', 'ETB 1.2M', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=60&q=80&auto=format&fit=crop'],
          ['Hanna Getnet', 'ETB 980K', 'https://images.unsplash.com/photo-1614644147798-f8c0fc9da7f6?w=60&q=80&auto=format&fit=crop'],
          ['Daniel Worku', 'ETB 760K', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&q=80&auto=format&fit=crop'],
        ] as $i => [$cn, $cb, $ci]
      ): ?>
        <div style="display:flex;align-items:center;gap:9px;padding:9px 14px;border-bottom:1px solid #f1f5f9;transition:background .15s" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
          <div style="font-size:.7rem;font-weight:700;color:#94a3b8;width:14px;flex-shrink:0"><?= $i + 1 ?></div>
          <img src="<?= $ci ?>" alt="<?= $cn ?>" style="width:30px;height:30px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #e2e8f0">
          <div style="flex:1;min-width:0">
            <div style="font-size:.78rem;font-weight:600;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= $cn ?></div>
          </div>
          <div style="font-size:.75rem;font-weight:700;color:#1B3A5C;white-space:nowrap"><?= $cb ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="card-footer"><a href="<?= APP_URL ?>/customers" class="btn btn-ghost btn-sm btn-full">All Customers <i class="fa-solid fa-arrow-right"></i></a></div>
  </div>
</div>

<!-- ═══ ALL MODALS ═══ -->

<!-- DEPOSIT MODAL -->
<div class="db-modal" id="depositModal" onclick="if(event.target===this)closeModal('depositModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-arrow-down"></i></div>
        <div>
          <h3>Make a Deposit</h3>
          <p>Add funds to an account</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('depositModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="dep-err"><i class="fa-solid fa-circle-xmark"></i><span id="dep-err-msg"></span></div>
      <div class="mf-alert ok" id="dep-ok"><i class="fa-solid fa-circle-check"></i><span id="dep-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">Account Number *</label><input type="text" id="dep-acc" class="mf-inp" placeholder="e.g. 0001-10-100001"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="dep-amt" class="mf-inp" placeholder="Minimum ETB 50" min="50" step="0.01" oninput="showAmt('dep-amt','dep-disp','dep-dval')"></div>
      <div class="mf-amt-box" id="dep-disp">
        <div class="albl">Deposit Amount</div>
        <div class="aval"><span>ETB</span><span id="dep-dval">0.00</span></div>
      </div>
      <div class="mf-g"><label class="mf-lbl">Description</label><input type="text" id="dep-desc" class="mf-inp" placeholder="Cash deposit, salary, etc." value="Cash Deposit"></div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('depositModal')">Cancel</button>
      <button class="db-btn" id="dep-btn" onclick="submitDeposit()"><i class="fa-solid fa-arrow-down"></i>Confirm Deposit</button>
    </div>
  </div>
</div>

<!-- LOCAL TRANSFER MODAL -->
<div class="db-modal" id="localTransferModal" onclick="if(event.target===this)closeModal('localTransferModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-building-columns"></i></div>
        <div>
          <h3>Local Transfer</h3>
          <p>Domestic ETB bank transfer</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('localTransferModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="loc-err"><i class="fa-solid fa-circle-xmark"></i><span id="loc-err-msg"></span></div>
      <div class="mf-alert ok" id="loc-ok"><i class="fa-solid fa-circle-check"></i><span id="loc-ok-msg"></span></div>
      <div class="mf-sec">
        <div class="mf-sec-t"><i class="fa-solid fa-user"></i>Beneficiary Information</div>
        <div class="mf-g"><label class="mf-lbl">Bank Name</label>
          <select id="loc-bank" class="mf-inp">
            <option value="">Select your bank</option>
            <?php foreach (['Abay Bank S.C.', 'Commercial Bank of Ethiopia', 'Dashen Bank', 'Awash Bank', 'Bank of Abyssinia', 'Wegagen Bank', 'Oromia Bank', 'Zemen Bank', 'Berhan Bank', 'Enat Bank', 'Telebirr'] as $bk): ?>
              <option><?= $bk ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="mf-g"><label class="mf-lbl">Account Holder Name *</label><input type="text" id="loc-holder" class="mf-inp" placeholder="Full name as per bank records"></div>
        <div class="mf-row">
          <div class="mf-g"><label class="mf-lbl">Account Number *</label><input type="text" id="loc-to" class="mf-inp" placeholder="123456789"></div>
          <div class="mf-g"><label class="mf-lbl">Account Type</label><select id="loc-type" class="mf-inp">
              <option>Select...</option>
              <option>Savings</option>
              <option>Current</option>
            </select></div>
        </div>
      </div>
      <div class="mf-sec">
        <div class="mf-sec-t"><i class="fa-solid fa-money-bill-transfer"></i>Transfer Details</div>
        <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="loc-from" class="mf-inp" placeholder="Your account number"></div>
        <div class="mf-g"><label class="mf-lbl">Amount to Transfer (ETB) *</label><input type="number" id="loc-amt" class="mf-inp" placeholder="Enter amount" min="1" step="0.01" oninput="showAmt('loc-amt','loc-disp','loc-dval')"></div>
        <div class="mf-amt-box" id="loc-disp">
          <div class="albl">Transfer Amount</div>
          <div class="aval"><span>ETB</span><span id="loc-dval">0.00</span></div>
          <div class="afee">Fee: ETB 10 — 25 (based on amount)</div>
        </div>
        <div class="mf-g"><label class="mf-lbl">Purpose</label><input type="text" id="loc-purpose" class="mf-inp" placeholder="e.g. Business payment, Family support" value="Fund Transfer"></div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('localTransferModal')">Cancel</button>
      <button class="db-btn" id="loc-btn" onclick="submitLocalTransfer()"><i class="fa-solid fa-paper-plane"></i>Send Money</button>
    </div>
  </div>
</div>

<!-- WIRE TRANSFER MODAL -->
<div class="db-modal" id="wireTransferModal" onclick="if(event.target===this)closeModal('wireTransferModal')">
  <div class="db-mbox wide">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#ede9fe;color:#5b21b6"><i class="fa-solid fa-globe"></i></div>
        <div>
          <h3>Wire Transfer</h3>
          <p>Secure international bank transfer</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('wireTransferModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="wire-err"><i class="fa-solid fa-circle-xmark"></i><span id="wire-err-msg"></span></div>
      <div class="mf-alert ok" id="wire-ok"><i class="fa-solid fa-circle-check"></i><span id="wire-ok-msg"></span></div>
      <div class="mf-sec">
        <div class="mf-sec-t"><i class="fa-solid fa-user"></i>Beneficiary Information</div>
        <div class="mf-row">
          <div class="mf-g"><label class="mf-lbl">Bank Name *</label><input type="text" id="wire-bank" class="mf-inp" placeholder="Recipient bank name"></div>
          <div class="mf-g"><label class="mf-lbl">SWIFT / BIC Code *</label><input type="text" id="wire-swift" class="mf-inp" placeholder="e.g. ABYAETAA" style="text-transform:uppercase"></div>
        </div>
        <div class="mf-g"><label class="mf-lbl">Account Holder Name *</label><input type="text" id="wire-holder" class="mf-inp" placeholder="Full legal name"></div>
        <div class="mf-row">
          <div class="mf-g"><label class="mf-lbl">Account / IBAN *</label><input type="text" id="wire-iban" class="mf-inp" placeholder="Account number or IBAN"></div>
          <div class="mf-g"><label class="mf-lbl">Country *</label><select id="wire-country" class="mf-inp">
              <option value="">Select country</option><?php foreach (['United States', 'United Kingdom', 'European Union', 'United Arab Emirates', 'Saudi Arabia', 'China', 'India', 'Canada', 'Australia', 'Other'] as $c): ?><option><?= $c ?></option><?php endforeach; ?>
            </select></div>
        </div>
      </div>
      <div class="mf-sec">
        <div class="mf-sec-t"><i class="fa-solid fa-money-bill-transfer"></i>Transfer Details</div>
        <div class="mf-g"><label class="mf-lbl">From Account (Abay Bank) *</label><input type="text" id="wire-from" class="mf-inp" placeholder="Your account number"></div>
        <div class="mf-row">
          <div class="mf-g"><label class="mf-lbl">Amount *</label><input type="number" id="wire-amt" class="mf-inp" placeholder="Amount to send" min="1" step="0.01" oninput="showAmt('wire-amt','wire-disp','wire-dval')"></div>
          <div class="mf-g"><label class="mf-lbl">Currency</label><select id="wire-currency" class="mf-inp">
              <option>USD</option>
              <option>EUR</option>
              <option>GBP</option>
              <option>AED</option>
              <option>SAR</option>
              <option>ETB</option>
            </select></div>
        </div>
        <div class="mf-amt-box" id="wire-disp">
          <div class="albl">Transfer Amount</div>
          <div class="aval"><span id="wire-cur-lbl">USD</span><span id="wire-dval">0.00</span></div>
          <div class="afee">Wire fee: USD 25 — 50 · Processing: 1-3 business days</div>
        </div>
        <div class="mf-g"><label class="mf-lbl">Transfer Purpose *</label><select id="wire-purpose" class="mf-inp">
            <option>Business Payment</option>
            <option>Personal Transfer</option>
            <option>Education</option>
            <option>Medical</option>
            <option>Property Purchase</option>
            <option>Import Payment</option>
            <option>Other</option>
          </select></div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('wireTransferModal')">Cancel</button>
      <button class="db-btn" id="wire-btn" onclick="submitWireTransfer()"><i class="fa-solid fa-globe"></i>Send Wire Transfer</button>
    </div>
  </div>
</div>

<!-- ETHSWITCH MODAL -->
<div class="db-modal" id="ethswitchModal" onclick="if(event.target===this)closeModal('ethswitchModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-bolt"></i></div>
        <div>
          <h3>EthSwitch Transfer</h3>
          <p>Real-time inter-bank transfer</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('ethswitchModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="eth-err"><i class="fa-solid fa-circle-xmark"></i><span id="eth-err-msg"></span></div>
      <div class="mf-alert ok" id="eth-ok"><i class="fa-solid fa-circle-check"></i><span id="eth-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account (Abay Bank) *</label><input type="text" id="eth-from" class="mf-inp" placeholder="Your Abay Bank account number"></div>
      <div class="mf-g"><label class="mf-lbl">Destination Bank *</label>
        <select id="eth-bank" class="mf-inp">
          <option value="">Select destination bank</option>
          <?php foreach (['Commercial Bank of Ethiopia (CBE)', 'Dashen Bank', 'Awash Bank', 'Bank of Abyssinia', 'Wegagen Bank', 'NIB International Bank', 'Oromia Bank', 'Zemen Bank', 'Berhan Bank', 'Enat Bank'] as $bk): ?>
            <option><?= $bk ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="mf-g"><label class="mf-lbl">Destination Account Number *</label><input type="text" id="eth-to" class="mf-inp" placeholder="Recipient account number"></div>
      <div class="mf-g"><label class="mf-lbl">Account Holder Name *</label><input type="text" id="eth-holder" class="mf-inp" placeholder="Name on destination account"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="eth-amt" class="mf-inp" placeholder="Enter amount" min="1" step="0.01" oninput="showAmt('eth-amt','eth-disp','eth-dval')"></div>
      <div class="mf-amt-box" id="eth-disp">
        <div class="albl">Transfer Amount</div>
        <div class="aval"><span>ETB</span><span id="eth-dval">0.00</span></div>
        <div class="afee">EthSwitch fee: ETB 5 — 15 · Instant settlement</div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('ethswitchModal')">Cancel</button>
      <button class="db-btn" id="eth-btn" onclick="submitEthSwitch()"><i class="fa-solid fa-bolt"></i>Send via EthSwitch</button>
    </div>
  </div>
</div>

<!-- TELEBIRR MODAL -->
<div class="db-modal" id="telebirrModal" onclick="if(event.target===this)closeModal('telebirrModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#fed7aa;color:#ea580c"><i class="fa-solid fa-mobile-screen"></i></div>
        <div>
          <h3>Telebirr Transfer</h3>
          <p>Send to Telebirr mobile wallet</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('telebirrModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="tel-err"><i class="fa-solid fa-circle-xmark"></i><span id="tel-err-msg"></span></div>
      <div class="mf-alert ok" id="tel-ok"><i class="fa-solid fa-circle-check"></i><span id="tel-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="tel-from" class="mf-inp" placeholder="Your account number"></div>
      <div class="mf-g"><label class="mf-lbl">Telebirr Phone Number *</label><input type="tel" id="tel-phone" class="mf-inp" placeholder="+251 912 345 678"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="tel-amt" class="mf-inp" placeholder="Enter amount" min="1" max="50000" step="0.01" oninput="showAmt('tel-amt','tel-disp','tel-dval')"></div>
      <div class="mf-amt-box" id="tel-disp">
        <div class="albl">Transfer Amount</div>
        <div class="aval"><span>ETB</span><span id="tel-dval">0.00</span></div>
        <div class="afee">Telebirr fee: ETB 5 · Limit: ETB 50,000/day</div>
      </div>
      <div class="mf-g"><label class="mf-lbl">Note</label><input type="text" id="tel-note" class="mf-inp" placeholder="Optional note"></div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('telebirrModal')">Cancel</button>
      <button class="db-btn" id="tel-btn" onclick="submitDemo('telebirrModal','tel-ok','tel-ok-msg','Telebirr transfer sent successfully!')"><i class="fa-solid fa-paper-plane"></i>Send to Telebirr</button>
    </div>
  </div>
</div>

<!-- WESTERN UNION MODAL -->
<div class="db-modal" id="wuModal" onclick="if(event.target===this)closeModal('wuModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#fef9c3;color:#854d0e;font-size:.8rem;font-weight:900">WU</div>
        <div>
          <h3>Western Union</h3>
          <p>Cash pickup worldwide</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('wuModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="wu-err"><i class="fa-solid fa-circle-xmark"></i><span id="wu-err-msg"></span></div>
      <div class="mf-alert ok" id="wu-ok"><i class="fa-solid fa-circle-check"></i><span id="wu-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="wu-from" class="mf-inp" placeholder="Your account number"></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Recipient First Name *</label><input type="text" id="wu-fname" class="mf-inp" placeholder="First name"></div>
        <div class="mf-g"><label class="mf-lbl">Recipient Last Name *</label><input type="text" id="wu-lname" class="mf-inp" placeholder="Last name"></div>
      </div>
      <div class="mf-g"><label class="mf-lbl">Destination Country *</label><select id="wu-country" class="mf-inp">
          <option value="">Select country</option><?php foreach (['United States', 'United Kingdom', 'Germany', 'Saudi Arabia', 'UAE', 'Canada', 'Australia', 'South Africa', 'Kenya', 'Uganda'] as $c): ?><option><?= $c ?></option><?php endforeach; ?>
        </select></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Amount (USD) *</label><input type="number" id="wu-amt" class="mf-inp" placeholder="Amount in USD" min="1" step="0.01" oninput="showAmt('wu-amt','wu-disp','wu-dval')"></div>
        <div class="mf-g"><label class="mf-lbl">Purpose</label><select id="wu-purpose" class="mf-inp">
            <option>Family Support</option>
            <option>Business</option>
            <option>Education</option>
            <option>Medical</option>
          </select></div>
      </div>
      <div class="mf-amt-box" id="wu-disp">
        <div class="albl">Send Amount</div>
        <div class="aval"><span>USD</span><span id="wu-dval">0.00</span></div>
        <div class="afee">WU fee applies · Exchange rate: 1 USD = ETB 56.5</div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('wuModal')">Cancel</button>
      <button class="db-btn" id="wu-btn" onclick="submitDemo('wuModal','wu-ok','wu-ok-msg','Western Union transfer initiated! MTCN will be sent via SMS.')"><i class="fa-solid fa-paper-plane"></i>Send via WU</button>
    </div>
  </div>
</div>

<!-- M-PESA MODAL -->
<div class="db-modal" id="mpesaModal" onclick="if(event.target===this)closeModal('mpesaModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#d1fae5;color:#047857"><i class="fa-solid fa-sim-card"></i></div>
        <div>
          <h3>M-Pesa Transfer</h3>
          <p>Send to M-Pesa mobile wallet</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('mpesaModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="mp-err"><i class="fa-solid fa-circle-xmark"></i><span id="mp-err-msg"></span></div>
      <div class="mf-alert ok" id="mp-ok"><i class="fa-solid fa-circle-check"></i><span id="mp-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="mp-from" class="mf-inp" placeholder="Your account number"></div>
      <div class="mf-g"><label class="mf-lbl">M-Pesa Phone Number *</label><input type="tel" id="mp-phone" class="mf-inp" placeholder="+251 912 345 678"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="mp-amt" class="mf-inp" placeholder="Enter amount" min="10" oninput="showAmt('mp-amt','mp-disp','mp-dval')"></div>
      <div class="mf-amt-box" id="mp-disp">
        <div class="albl">Transfer Amount</div>
        <div class="aval"><span>ETB</span><span id="mp-dval">0.00</span></div>
        <div class="afee">M-Pesa fee: ETB 5 — 20</div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('mpesaModal')">Cancel</button>
      <button class="db-btn" id="mp-btn" onclick="submitDemo('mpesaModal','mp-ok','mp-ok-msg','M-Pesa transfer sent successfully!')"><i class="fa-solid fa-paper-plane"></i>Send via M-Pesa</button>
    </div>
  </div>
</div>

<!-- WISE MODAL -->
<div class="db-modal" id="wiseModal" onclick="if(event.target===this)closeModal('wiseModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#dcfce7;color:#16a34a;font-weight:900;font-size:.8rem">wise</div>
        <div>
          <h3>Wise Transfer</h3>
          <p>Low-fee multi-currency transfer</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('wiseModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert ok" id="wise-ok"><i class="fa-solid fa-circle-check"></i><span id="wise-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="wise-from" class="mf-inp" placeholder="Your account number"></div>
      <div class="mf-g"><label class="mf-lbl">Recipient Email / Phone *</label><input type="text" id="wise-to" class="mf-inp" placeholder="email@example.com or phone"></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Amount *</label><input type="number" id="wise-amt" class="mf-inp" placeholder="Amount" min="1" oninput="showAmt('wise-amt','wise-disp','wise-dval')"></div>
        <div class="mf-g"><label class="mf-lbl">Currency</label><select id="wise-cur" class="mf-inp">
            <option>USD</option>
            <option>EUR</option>
            <option>GBP</option>
            <option>ETB</option>
          </select></div>
      </div>
      <div class="mf-amt-box" id="wise-disp">
        <div class="albl">Send Amount</div>
        <div class="aval"><span id="wise-cur-l">USD</span><span id="wise-dval">0.00</span></div>
        <div class="afee">Wise fee: ~0.5% · Mid-market exchange rate</div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('wiseModal')">Cancel</button>
      <button class="db-btn" onclick="submitDemo('wiseModal','wise-ok','wise-ok-msg','Wise transfer initiated! Funds will arrive in 1-2 business days.')"><i class="fa-solid fa-paper-plane"></i>Send via Wise</button>
    </div>
  </div>
</div>

<!-- PAYONEER MODAL -->
<div class="db-modal" id="payoneerModal" onclick="if(event.target===this)closeModal('payoneerModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#fee2e2;color:#dc2626"><i class="fa-solid fa-credit-card"></i></div>
        <div>
          <h3>Payoneer</h3>
          <p>Global business payments</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('payoneerModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert ok" id="pay-ok"><i class="fa-solid fa-circle-check"></i><span id="pay-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">From Account *</label><input type="text" id="pay-from" class="mf-inp" placeholder="Your account number"></div>
      <div class="mf-g"><label class="mf-lbl">Payoneer Email *</label><input type="email" id="pay-email" class="mf-inp" placeholder="recipient@payoneer.com"></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Amount (USD) *</label><input type="number" id="pay-amt" class="mf-inp" placeholder="Amount" min="50" oninput="showAmt('pay-amt','pay-disp','pay-dval')"></div>
        <div class="mf-g"><label class="mf-lbl">Purpose</label><select id="pay-purpose" class="mf-inp">
            <option>Freelance Payment</option>
            <option>Business Payment</option>
            <option>Service Fee</option>
          </select></div>
      </div>
      <div class="mf-amt-box" id="pay-disp">
        <div class="albl">Send Amount</div>
        <div class="aval"><span>USD</span><span id="pay-dval">0.00</span></div>
        <div class="afee">Payoneer fee: 1% · Min. USD 50</div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('payoneerModal')">Cancel</button>
      <button class="db-btn" onclick="submitDemo('payoneerModal','pay-ok','pay-ok-msg','Payoneer payment initiated successfully!')"><i class="fa-solid fa-paper-plane"></i>Send via Payoneer</button>
    </div>
  </div>
</div>

<!-- NEW CUSTOMER MODAL -->
<div class="db-modal" id="newCustomerModal" onclick="if(event.target===this)closeModal('newCustomerModal')">
  <div class="db-mbox wide">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#ede9fe;color:#7c3aed"><i class="fa-solid fa-user-plus"></i></div>
        <div>
          <h3>Register New Customer</h3>
          <p>Quick customer registration</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('newCustomerModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="cust-err"><i class="fa-solid fa-circle-xmark"></i><span id="cust-err-msg"></span></div>
      <div class="mf-alert ok" id="cust-ok"><i class="fa-solid fa-circle-check"></i><span id="cust-ok-msg"></span></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">First Name *</label><input type="text" id="cust-fn" class="mf-inp" placeholder="First name"></div>
        <div class="mf-g"><label class="mf-lbl">Last Name *</label><input type="text" id="cust-ln" class="mf-inp" placeholder="Last name"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Phone *</label><input type="tel" id="cust-phone" class="mf-inp" placeholder="+251 912 345 678"></div>
        <div class="mf-g"><label class="mf-lbl">National ID *</label><input type="text" id="cust-nid" class="mf-inp" placeholder="National ID number"></div>
      </div>
      <div class="mf-g"><label class="mf-lbl">Email</label><input type="email" id="cust-email" class="mf-inp" placeholder="email@example.com"></div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Account Type *</label><select id="cust-acct" class="mf-inp">
            <option value="">Select type...</option>
            <option>Savings</option>
            <option>Current</option>
            <option>Fixed Deposit</option>
          </select></div>
        <div class="mf-g"><label class="mf-lbl">Initial Deposit (ETB)</label><input type="number" id="cust-dep" class="mf-inp" placeholder="Min. ETB 100" min="100" step="0.01"></div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('newCustomerModal')">Cancel</button>
      <a href="<?= APP_URL ?>/customers/register" style="display:inline-flex;align-items:center;gap:5px;padding:10px 16px;background:#f1f5f9;color:#374151;border-radius:9px;font-size:.85rem;font-weight:600;text-decoration:none">Full Form <i class="fa-solid fa-arrow-right"></i></a>
      <button class="db-btn" id="cust-btn" onclick="submitNewCustomer()"><i class="fa-solid fa-user-plus"></i>Register</button>
    </div>
  </div>
</div>

<!-- APPLY CARD MODAL -->
<div class="db-modal" id="applyCardModal" onclick="if(event.target===this)closeModal('applyCardModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-credit-card"></i></div>
        <div>
          <h3>Apply for Virtual Card</h3>
          <p>Instant virtual card issuance</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('applyCardModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert ok" id="card-ok"><i class="fa-solid fa-circle-check"></i><span id="card-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">Card Network *</label>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:4px">
          <?php foreach ([['Visa', 'fa-cc-visa', '#1a56db'], ['Mastercard', 'fa-cc-mastercard', '#eb001b'], ['Amex', 'fa-cc-amex', '#1a3a6b']] as [$cn, $ci, $cc]): ?>
            <label style="display:flex;align-items:center;gap:8px;border:1.5px solid #e2e8f0;border-radius:9px;padding:10px;cursor:pointer;transition:border .2s">
              <input type="radio" name="card-network" value="<?= $cn ?>" style="accent-color:#007A8A">
              <i class="fa-brands <?= $ci ?>" style="color:<?= $cc ?>;font-size:1.3rem"></i>
              <span style="font-size:.8rem;font-weight:600"><?= $cn ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="mf-g"><label class="mf-lbl">Cardholder Name *</label><input type="text" id="card-name" class="mf-inp" placeholder="Name to appear on card" value="<?= strtoupper($name) ?>"></div>
      <div class="mf-g"><label class="mf-lbl">Link to Account *</label><input type="text" id="card-acc" class="mf-inp" placeholder="Your account number"></div>
      <div style="background:#f0fbfc;border-radius:9px;padding:12px 14px;font-size:.78rem;color:#0e7490"><i class="fa-solid fa-circle-info" style="margin-right:6px"></i>Virtual cards are issued instantly and can be used for online payments worldwide.</div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('applyCardModal')">Cancel</button>
      <button class="db-btn" onclick="submitApplyCard()"><i class="fa-solid fa-credit-card"></i>Apply for Card</button>
    </div>
  </div>
</div>

<!-- ADD EMPLOYEE MODAL -->
<div class="db-modal" id="newEmployeeModal" onclick="if(event.target===this)closeModal('newEmployeeModal')">
  <div class="db-mbox wide">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-id-badge"></i></div>
        <div>
          <h3>Add New Employee</h3>
          <p>Staff registration — saves to database</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('newEmployeeModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert err" id="emp-db-err"><i class="fa-solid fa-circle-xmark"></i><span id="emp-db-err-msg"></span></div>
      <div class="mf-alert ok" id="emp-db-ok"><i class="fa-solid fa-circle-check"></i><span id="emp-db-ok-msg"></span></div>

      <!-- Photo -->
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px;padding:12px;background:#f8fafc;border-radius:10px">
        <div id="emp-av-wrap" style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:1.1rem;overflow:hidden;flex-shrink:0">
          <span id="emp-av-init">?</span>
          <img id="emp-av-img" style="display:none;width:100%;height:100%;object-fit:cover;border-radius:50%">
        </div>
        <div>
          <div style="font-size:.8rem;font-weight:600;color:#374151;margin-bottom:4px">Photo <span style="font-weight:400;color:#94a3b8">(optional)</span></div>
          <button type="button" onclick="document.getElementById('emp-photo-file').click()" class="db-btn-cancel" style="padding:6px 12px;font-size:.76rem"><i class="fa-solid fa-camera"></i> Choose Photo</button>
          <div style="font-size:.7rem;color:#94a3b8;margin-top:3px">JPG/PNG — max 5 MB</div>
          <input type="file" id="emp-photo-file" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="previewEmpAv(this)">
        </div>
      </div>

      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">First Name *</label><input type="text" id="enew-fn" class="mf-inp" placeholder="First name" oninput="updateEmpAv()"></div>
        <div class="mf-g"><label class="mf-lbl">Last Name *</label><input type="text" id="enew-ln" class="mf-inp" placeholder="Last name" oninput="updateEmpAv()"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Phone *</label><input type="tel" id="enew-phone" class="mf-inp" placeholder="+251 912 345 678"></div>
        <div class="mf-g"><label class="mf-lbl">Email</label><input type="email" id="enew-email" class="mf-inp" placeholder="employee@abaybank.com"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Department *</label>
          <select id="enew-dept" class="mf-inp">
            <option value="">Select…</option>
            <?php foreach (['Finance', 'Operations', 'IT', 'HR', 'Loans', 'Customer Service', 'Audit', 'Legal', 'Marketing', 'Security'] as $d): ?>
              <option><?= $d ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mf-g"><label class="mf-lbl">Position *</label><input type="text" id="enew-pos" class="mf-inp" placeholder="Job title"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Branch</label>
          <select id="enew-branch" class="mf-inp">
            <option value="">Select branch…</option>
            <?php foreach ($branches ?? [['branch_name' => 'Head Office'], ['branch_name' => 'Bole Branch'], ['branch_name' => 'Alem Ketema Branch'], ['branch_name' => 'Kirkos Branch'], ['branch_name' => 'Bahir Dar Branch'], ['branch_name' => 'Hawassa Branch'], ['branch_name' => 'Dire Dawa Branch'], ['branch_name' => 'Mekelle Branch']] as $br): ?>
              <option><?= htmlspecialchars($br['branch_name'] ?? $br['name'] ?? '') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mf-g"><label class="mf-lbl">Basic Salary (ETB)</label><input type="number" id="enew-salary" class="mf-inp" placeholder="0.00" min="0"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">National ID</label><input type="text" id="enew-nid" class="mf-inp" placeholder="ET12345678"></div>
        <div class="mf-g"><label class="mf-lbl">Join Date</label><input type="date" id="enew-join" class="mf-inp" value="<?= date('Y-m-d') ?>"></div>
      </div>
      <div class="mf-row">
        <div class="mf-g"><label class="mf-lbl">Gender</label>
          <select id="enew-gender" class="mf-inp">
            <option value="">Select…</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>
        <div class="mf-g"><label class="mf-lbl">Employment Type</label>
          <select id="enew-type" class="mf-inp">
            <option>Permanent</option>
            <option>Contract</option>
            <option>Probation</option>
            <option>Part-time</option>
          </select>
        </div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('newEmployeeModal')">Cancel</button>
      <a href="<?= APP_URL ?>/employees" style="display:inline-flex;align-items:center;gap:5px;padding:10px 14px;background:#f1f5f9;color:#374151;border-radius:9px;font-size:.83rem;font-weight:600;text-decoration:none">Full List <i class="fa-solid fa-arrow-right"></i></a>
      <button class="db-btn" id="enew-btn" onclick="submitDashEmployee()"><i class="fa-solid fa-user-plus"></i> Add Employee</button>
    </div>
  </div>
</div>

<!-- CARD DETAIL MODAL -->
<div class="db-modal" id="cardDetailModal" onclick="if(event.target===this)closeModal('cardDetailModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-id-card"></i></div>
        <div>
          <h3>Card Details</h3>
          <p>Virtual card information</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('cardDetailModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px">
        <span id="cd-status-badge" style="display:inline-flex;align-items:center;gap:5px;font-size:.72rem;font-weight:700;padding:4px 10px;border-radius:99px;background:#d1fae5;color:#065f46"><i class="fa-solid fa-circle-check"></i><span id="cd-status">Active</span></span>
        <div style="margin-left:auto;display:flex;gap:8px">
          <button onclick="dbToast('Card deactivated successfully.','info');closeModal('cardDetailModal')" style="display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border:1.5px solid #e2e8f0;background:#fff;border-radius:8px;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-ban"></i>Deactivate</button>
          <button onclick="dbToast('Card blocked successfully. Contact support to unblock.','err');closeModal('cardDetailModal')" style="display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border:1.5px solid #fecaca;background:#fff;border-radius:8px;font-size:.78rem;font-weight:600;cursor:pointer;color:#dc2626;font-family:inherit"><i class="fa-solid fa-lock"></i>Block Card</button>
        </div>
      </div>
      <!-- Card display -->
      <div id="cd-card-display" style="background:linear-gradient(135deg,#1B3A5C,#254d7a);border-radius:14px;padding:20px;color:#fff;margin-bottom:18px;box-shadow:0 8px 28px rgba(0,0,0,.2)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <span style="font-size:.62rem;font-weight:700;opacity:.7;text-transform:uppercase;letter-spacing:.8px">Abay Bank S.C.</span>
          <span id="cd-network-icon" style="font-size:1.6rem"><i class="fa-brands fa-cc-visa"></i></span>
        </div>
        <div style="width:32px;height:24px;background:linear-gradient(135deg,rgba(255,255,255,.35),rgba(255,255,255,.15));border-radius:4px;margin-bottom:10px"></div>
        <div style="font-size:.85rem;letter-spacing:3px;font-family:'Courier New',monospace;opacity:.9;margin-bottom:10px">**** **** **** <span id="cd-last4">8421</span></div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end">
          <div>
            <div style="font-size:.58rem;opacity:.6;text-transform:uppercase;letter-spacing:.5px">Card Holder</div>
            <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;margin-top:1px" id="cd-holder"><?= strtoupper($name) ?></div>
          </div>
          <div style="text-align:right">
            <div style="font-size:.58rem;opacity:.6;text-transform:uppercase;letter-spacing:.5px">Valid Thru</div>
            <div style="font-size:.78rem;font-weight:700;margin-top:1px" id="cd-expiry">12/28</div>
          </div>
        </div>
      </div>
      <!-- Card actions -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <button onclick="flipCard(window._cdCardId||1);closeModal('cardDetailModal')" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;font-size:.8rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-rotate"></i>Flip Card</button>
        <button onclick="openModal('fundCardModal');closeModal('cardDetailModal')" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border:none;border-radius:9px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;font-size:.8rem;font-weight:700;cursor:pointer;font-family:inherit"><i class="fa-solid fa-plus-circle"></i>Fund Card</button>
        <button onclick="openModal('cardBalanceModal');closeModal('cardDetailModal')" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;font-size:.8rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-arrow-right-arrow-left"></i>Send to Balance</button>
        <a href="<?= APP_URL ?>/accounts/statement" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;background:#fff;font-size:.8rem;font-weight:600;cursor:pointer;font-family:inherit;text-decoration:none;color:#334155"><i class="fa-solid fa-list"></i>Transactions</a>
      </div>
    </div>
  </div>
</div>

<!-- FUND CARD MODAL -->
<div class="db-modal" id="fundCardModal" onclick="if(event.target===this)closeModal('fundCardModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-plus-circle"></i></div>
        <div>
          <h3>Fund Your Card</h3>
          <p>Add money to virtual card</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('fundCardModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert ok" id="fund-ok"><i class="fa-solid fa-circle-check"></i><span id="fund-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">Source Account *</label><input type="text" id="fund-acc" class="mf-inp" placeholder="Your bank account number"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="fund-amt" class="mf-inp" placeholder="Amount to fund" min="100" step="0.01" oninput="showAmt('fund-amt','fund-disp','fund-dval')"></div>
      <div class="mf-amt-box" id="fund-disp">
        <div class="albl">Fund Amount</div>
        <div class="aval"><span>ETB</span><span id="fund-dval">0.00</span></div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('fundCardModal')">Cancel</button>
      <button class="db-btn" onclick="submitDemo('fundCardModal','fund-ok','fund-ok-msg','Card funded successfully!')"><i class="fa-solid fa-plus-circle"></i>Fund Card</button>
    </div>
  </div>
</div>

<!-- CARD TO BALANCE MODAL -->
<div class="db-modal" id="cardBalanceModal" onclick="if(event.target===this)closeModal('cardBalanceModal')">
  <div class="db-mbox">
    <div class="db-mh">
      <div class="db-mh-l">
        <div class="db-mh-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-arrow-right-arrow-left"></i></div>
        <div>
          <h3>Send to Balance</h3>
          <p>Move funds from card to account</p>
        </div>
      </div>
      <button class="db-mx" onclick="closeModal('cardBalanceModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="db-mb">
      <div class="mf-alert ok" id="bal-ok"><i class="fa-solid fa-circle-check"></i><span id="bal-ok-msg"></span></div>
      <div class="mf-g"><label class="mf-lbl">Destination Account *</label><input type="text" id="bal-acc" class="mf-inp" placeholder="Your bank account number"></div>
      <div class="mf-g"><label class="mf-lbl">Amount (ETB) *</label><input type="number" id="bal-amt" class="mf-inp" placeholder="Amount to transfer" min="1" step="0.01" oninput="showAmt('bal-amt','bal-disp','bal-dval')"></div>
      <div class="mf-amt-box" id="bal-disp">
        <div class="albl">Transfer Amount</div>
        <div class="aval"><span>ETB</span><span id="bal-dval">0.00</span></div>
      </div>
    </div>
    <div class="db-mf">
      <button class="db-btn-cancel" onclick="closeModal('cardBalanceModal')">Cancel</button>
      <button class="db-btn" onclick="submitDemo('cardBalanceModal','bal-ok','bal-ok-msg','Funds transferred to balance successfully!')"><i class="fa-solid fa-arrow-right-arrow-left"></i>Send to Balance</button>
    </div>
  </div>
</div>

<!-- TOAST CONTAINER -->
<div id="db-toasts"></div>

<script>
  /* ── CLOCK ── */
  setInterval(function() {
    var n = new Date(),
      p = function(x) {
        return String(x).padStart(2, '0');
      };
    var el = document.getElementById('dash-clock');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
  }, 1000);

  /* ── MODAL ── */
  function openModal(id) {
    var m = document.getElementById(id);
    if (m) {
      m.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal(id) {
    var m = document.getElementById(id);
    if (m) {
      m.classList.remove('open');
    }
    // Only restore scroll if no other modal open
    if (!document.querySelector('.db-modal.open')) document.body.style.overflow = '';
  }
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.db-modal.open').forEach(function(m) {
        m.classList.remove('open');
      });
      document.body.style.overflow = '';
    }
  });

  /* ── TOAST ── */
  function dbToast(msg, type) {
    type = type || 'info';
    var icons = {
      ok: 'fa-circle-check',
      err: 'fa-circle-xmark',
      info: 'fa-circle-info'
    };
    var t = document.createElement('div');
    t.className = 'db-t ' + type;
    t.innerHTML = '<i class="fa-solid ' + icons[type] + ' tic"></i><div style="flex:1"><div>' + msg + '</div></div><button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:inherit;padding:0;margin-left:6px;font-size:.85rem"><i class="fa-solid fa-xmark"></i></button>';
    document.getElementById('db-toasts').appendChild(t);
    setTimeout(function() {
      if (t.parentElement) {
        t.style.opacity = '0';
        t.style.transform = 'translateX(110%)';
        t.style.transition = 'all .4s';
        setTimeout(function() {
          t.remove();
        }, 400);
      }
    }, 4000);
  }

  /* ── AMOUNT DISPLAY ── */
  function showAmt(inputId, boxId, valId) {
    var v = parseFloat(document.getElementById(inputId).value) || 0;
    var box = document.getElementById(boxId),
      val = document.getElementById(valId);
    if (v > 0 && box && val) {
      box.classList.add('show');
      val.textContent = v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    } else if (box) {
      box.classList.remove('show');
    }
  }

  /* ── VIRTUAL CARD FLIP ── */
  function flipCard(n) {
    var el = document.getElementById('vc-inner-' + n);
    if (el) el.classList.toggle('flipped');
  }

  /* ── OPEN CARD DETAIL ── */
  function openCardDetail(id, network, last4, expiry, status) {
    window._cdCardId = id;
    var ni = document.getElementById('cd-network-icon');
    var icons = {
      'Visa': 'fa-cc-visa',
      'Mastercard': 'fa-cc-mastercard',
      'Amex': 'fa-cc-amex'
    };
    if (ni) ni.innerHTML = '<i class="fa-brands ' + (icons[network] || 'fa-credit-card') + '"></i>';
    var l4 = document.getElementById('cd-last4');
    if (l4) l4.textContent = last4;
    var exp = document.getElementById('cd-expiry');
    if (exp) exp.textContent = expiry;
    var st = document.getElementById('cd-status');
    if (st) st.textContent = status;
    openModal('cardDetailModal');
  }

  /* ── SUBMIT HELPERS ── */
  function setBtn(id, loading, text) {
    var b = document.getElementById(id);
    if (!b) return;
    if (loading) {
      b.disabled = true;
      b.innerHTML = '<span class="db-spin"></span> Processing...';
    } else {
      b.disabled = false;
      b.innerHTML = text;
    }
  }

  function showErr(errId, msgId, msg) {
    var e = document.getElementById(errId),
      m = document.getElementById(msgId);
    if (e) e.classList.remove('show');
    if (e && m) {
      m.textContent = msg;
      e.classList.add('show');
    }
  }

  function showOk(okId, msgId, msg) {
    var o = document.getElementById(okId),
      m = document.getElementById(msgId);
    if (o && m) {
      m.textContent = msg;
      o.classList.add('show');
    }
  }

  function clearAlerts() {
    document.querySelectorAll('.mf-alert.show').forEach(function(a) {
      a.classList.remove('show');
    });
  }

  /* ═══════════════════════════════════════════════════════════════
     LIVE DASHBOARD REFRESH — called after any successful action
     Updates KPI cards, recent transactions and activity feed
     without a full page reload.
  ═══════════════════════════════════════════════════════════════ */
  var BASE_URL = '<?= APP_URL ?>';

  /* Helper: robust fetch with credentials + JSON */
  function apiFetch(path, opts) {
    var defaults = {
      credentials: 'include',
      headers: Object.assign({
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
      }, (opts && opts.headers) || {})
    };
    return fetch(BASE_URL + path, Object.assign({}, opts || {}, defaults, {
      headers: Object.assign(defaults.headers, (opts && opts.headers) || {})
    })).then(function(r) {
      return r.json();
    });
  }

  /* Soft refresh: update stats + transactions + activity */
  function refreshDashboard() {
    refreshStats();
    loadActivity();
  }

  function refreshStats() {
    apiFetch('/api/stats/refresh').then(function(d) {
      if (!d || !d.success) return;
      var s = d.data;
      var fmt = function(n) {
        return Number(n || 0).toLocaleString('en');
      };
      var etb = function(n) {
        return 'ETB ' + Number(n || 0).toLocaleString('en', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
      };

      /* Update KPI card values */
      var kpiMap = {
        'kpi-customers': fmt(s.customers),
        'kpi-accounts': fmt(s.accounts),
        'kpi-txns': fmt(s.today_transactions),
        'kpi-deposits': etb(s.total_deposits),
        'kpi-withdrawals': etb(s.total_withdrawals),
        'kpi-loans': fmt(s.active_loans),
        'kpi-employees': fmt(s.employees),
        'kpi-branches': fmt(s.branches)
      };
      Object.keys(kpiMap).forEach(function(id) {
        var el = document.getElementById(id);
        if (el) {
          /* Flash green to signal update */
          el.style.transition = 'color .3s';
          el.style.color = '#10b981';
          el.textContent = kpiMap[id];
          setTimeout(function() {
            el.style.color = '';
          }, 1200);
        }
      });

      /* Update recent transactions table */
      if (s.recent_transactions && s.recent_transactions.length) {
        var tbody = document.getElementById('recent-txns-tbody');
        if (tbody) {
          tbody.innerHTML = s.recent_transactions.map(function(t) {
            var typeColors = {
              'Deposit': '#10b981',
              'Transfer In': '#10b981',
              'Withdrawal': '#ef4444',
              'Transfer Out': '#ef4444'
            };
            var tc = typeColors[t.type] || '#007A8A';
            var sc = t.status === 'Completed' ? 'success' : (t.status === 'Pending' ? 'warning' : 'danger');
            var diff = Math.floor((Date.now() - new Date(t.created_at).getTime()) / 1000);
            var ago = diff < 60 ? 'Just now' : diff < 3600 ? Math.floor(diff / 60) + 'm ago' : diff < 86400 ? Math.floor(diff / 3600) + 'h ago' : Math.floor(diff / 86400) + 'd ago';
            return '<tr>' +
              '<td><span style="font-family:monospace;font-size:.75rem;color:#475569;font-weight:600">' + esc(t.reference || '—') + '</span></td>' +
              '<td style="font-size:.81rem">' + esc(t.account_number || '—') + '</td>' +
              '<td><span style="background:' + tc + '1a;color:' + tc + ';padding:2px 8px;border-radius:6px;font-size:.74rem;font-weight:700">' + esc(t.type || '—') + '</span></td>' +
              '<td style="font-weight:700;font-size:.82rem">' + Number(t.amount || 0).toLocaleString('en', {
                minimumFractionDigits: 2
              }) + '</td>' +
              '<td><span class="badge badge-' + sc + '">' + esc(t.status || '—') + '</span></td>' +
              '<td style="font-size:.73rem;color:#94a3b8">' + ago + '</td>' +
              '</tr>';
          }).join('');
        }
      }
    }).catch(function() {});
  }

  /* Activity feed icons by action */
  var actIcons = {
    CUSTOMER_CREATED: ['fa-user-plus', '#3b82f6'],
    EMPLOYEE_CREATED: ['fa-id-badge', '#2d6a4f'],
    DEPOSIT: ['fa-arrow-down', '#10b981'],
    WITHDRAWAL: ['fa-arrow-up', '#ef4444'],
    TRANSFER: ['fa-right-left', '#007A8A'],
    LOAN_APPROVED: ['fa-circle-check', '#10b981'],
    LOAN_APPLICATION: ['fa-file-invoice-dollar', '#f59e0b'],
    LOAN_REJECTED: ['fa-circle-xmark', '#ef4444'],
    BRANCH_CREATED: ['fa-building', '#8b5cf6'],
    ACCOUNT_OPENED: ['fa-building-columns', '#0d9488'],
    KYC_VERIFIED: ['fa-id-card', '#22c55e'],
    COMPLAINT_RESPONDED: ['fa-headset', '#f97316'],
    EMPLOYEE_PHOTO_UPDATED: ['fa-camera', '#64748b'],
  };

  function loadActivity() {
    var feed = document.getElementById('activity-feed');
    var ic = document.getElementById('activity-refresh-ic');
    if (ic) ic.className = 'fa-solid fa-rotate fa-spin';

    apiFetch('/api/activity?limit=15').then(function(d) {
      if (ic) ic.className = 'fa-solid fa-rotate';
      if (!d || !d.success || !feed) return;
      var rows = d.data;
      if (!rows || !rows.length) {
        feed.innerHTML = '<div style="padding:20px;text-align:center;color:#94a3b8;font-size:.82rem">No activity yet</div>';
        return;
      }
      feed.innerHTML = rows.map(function(a) {
        var pair = actIcons[a.action] || ['fa-circle-dot', '#94a3b8'];
        var diff = Math.floor((Date.now() - new Date(a.created_at).getTime()) / 1000);
        var ago = diff < 60 ? 'Just now' : diff < 3600 ? Math.floor(diff / 60) + 'm ago' : diff < 86400 ? Math.floor(diff / 3600) + 'h ago' : Math.floor(diff / 86400) + 'd ago';
        return '<div style="display:flex;align-items:flex-start;gap:9px;padding:9px 14px;border-bottom:1px solid #f8fafc;transition:background .15s" onmouseover="this.style.background=\'#f8fafc\'" onmouseout="this.style.background=\'\'">' +
          '<div style="width:30px;height:30px;border-radius:8px;background:' + pair[1] + '1a;color:' + pair[1] + ';display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0"><i class="fa-solid ' + pair[0] + '"></i></div>' +
          '<div style="flex:1;min-width:0">' +
          '<div style="font-size:.77rem;color:#1e293b;line-height:1.4;word-break:break-word">' + esc(a.detail || a.action) + '</div>' +
          '<div style="font-size:.67rem;color:#94a3b8;margin-top:2px">' +
          '<i class="fa-solid fa-user" style="margin-right:3px;font-size:.6rem"></i>' + esc(a.actor || 'System') +
          ' &nbsp;·&nbsp; <i class="fa-regular fa-clock" style="margin-right:2px"></i>' + ago +
          '</div>' +
          '</div></div>';
      }).join('');
    }).catch(function() {
      if (ic) ic.className = 'fa-solid fa-rotate';
      if (feed) feed.innerHTML = '<div style="padding:20px;text-align:center;color:#94a3b8;font-size:.82rem"><i class="fa-solid fa-wifi-slash"></i> Activity unavailable</div>';
    });
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* Auto-refresh every 30 seconds */
  document.addEventListener('DOMContentLoaded', function() {
    loadActivity();
    setTimeout(function autoRefresh() {
      refreshDashboard();
      setTimeout(autoRefresh, 30000);
    }, 30000);
  });

  /* ── DEPOSIT ── */
  function submitDeposit() {
    clearAlerts();
    var acc = document.getElementById('dep-acc').value.trim();
    var amt = parseFloat(document.getElementById('dep-amt').value) || 0;
    var desc = document.getElementById('dep-desc').value.trim() || 'Cash Deposit';
    if (!acc) {
      showErr('dep-err', 'dep-err-msg', 'Account number is required.');
      return;
    }
    if (amt < 50) {
      showErr('dep-err', 'dep-err-msg', 'Minimum deposit is ETB 50.');
      return;
    }
    setBtn('dep-btn', true);
    apiFetch('/api/transactions/deposit', {
      method: 'POST',
      body: JSON.stringify({
        account_number: acc,
        amount: amt,
        description: desc
      })
    }).then(function(r) {
      return r.json();
    }).then(function(d) {
      setBtn('dep-btn', false, '<i class="fa-solid fa-arrow-down"></i>Confirm Deposit');
      if (d && d.success) {
        showOk('dep-ok', 'dep-ok-msg', 'Deposit of ETB ' + amt.toFixed(2) + ' successful! Ref: ' + (d.data && d.data.reference ? d.data.reference : 'N/A'));
        dbToast('Deposit of ETB ' + amt.toFixed(2) + ' posted successfully!', 'ok');
        setTimeout(function() {
          closeModal('depositModal');
          refreshDashboard();
        }, 2200);
      } else {
        showErr('dep-err', 'dep-err-msg', (d && d.message) || 'Deposit failed. Please try again.');
      }
    }).catch(function() {
      setBtn('dep-btn', false, '<i class="fa-solid fa-arrow-down"></i>Confirm Deposit');
      showOk('dep-ok', 'dep-ok-msg', 'Demo: Deposit of ETB ' + amt.toFixed(2) + ' recorded (database offline).');
      dbToast('Demo deposit recorded.', 'info');
      setTimeout(function() {
        closeModal('depositModal');
      }, 2000);
    });
  }

  /* ── LOCAL TRANSFER ── */
  function submitLocalTransfer() {
    clearAlerts();
    var from = document.getElementById('loc-from').value.trim();
    var to = document.getElementById('loc-to').value.trim();
    var holder = document.getElementById('loc-holder').value.trim();
    var amt = parseFloat(document.getElementById('loc-amt').value) || 0;
    var purpose = document.getElementById('loc-purpose').value.trim();
    if (!from) {
      showErr('loc-err', 'loc-err-msg', 'Source account is required.');
      return;
    }
    if (!to) {
      showErr('loc-err', 'loc-err-msg', 'Destination account is required.');
      return;
    }
    if (!holder) {
      showErr('loc-err', 'loc-err-msg', 'Account holder name is required.');
      return;
    }
    if (amt < 1) {
      showErr('loc-err', 'loc-err-msg', 'Please enter a valid amount.');
      return;
    }
    setBtn('loc-btn', true);
    apiFetch('/api/transactions/transfer', {
      method: 'POST',
      body: JSON.stringify({
        from_account_number: from,
        to_account_number: to,
        amount: amt,
        description: purpose
      })
    }).then(function(r) {
      return r.json();
    }).then(function(d) {
      setBtn('loc-btn', false, '<i class="fa-solid fa-paper-plane"></i>Send Money');
      if (d && d.success) {
        showOk('loc-ok', 'loc-ok-msg', 'Transfer of ETB ' + amt.toFixed(2) + ' sent successfully to ' + holder + '!');
        dbToast('Local transfer of ETB ' + amt.toFixed(2) + ' completed!', 'ok');
        setTimeout(function() {
          closeModal('localTransferModal');
          refreshDashboard();
        }, 2200);
      } else {
        showErr('loc-err', 'loc-err-msg', (d && d.message) || 'Transfer failed.');
      }
    }).catch(function() {
      setBtn('loc-btn', false, '<i class="fa-solid fa-paper-plane"></i>Send Money');
      showOk('loc-ok', 'loc-ok-msg', 'Demo: Transfer of ETB ' + amt.toFixed(2) + ' to ' + holder + ' recorded.');
      dbToast('Demo local transfer recorded.', 'info');
      setTimeout(function() {
        closeModal('localTransferModal');
      }, 2200);
    });
  }

  /* ── WIRE TRANSFER ── */
  function submitWireTransfer() {
    clearAlerts();
    var from = document.getElementById('wire-from').value.trim();
    var swift = document.getElementById('wire-swift').value.trim().toUpperCase();
    var bank = document.getElementById('wire-bank').value.trim();
    var iban = document.getElementById('wire-iban').value.trim();
    var holder = document.getElementById('wire-holder').value.trim();
    var country = document.getElementById('wire-country').value;
    var amt = parseFloat(document.getElementById('wire-amt').value) || 0;
    var currency = document.getElementById('wire-currency').value;
    if (!from) {
      showErr('wire-err', 'wire-err-msg', 'Source account is required.');
      return;
    }
    if (!swift || swift.length < 8) {
      showErr('wire-err', 'wire-err-msg', 'Valid SWIFT/BIC code is required (8-11 chars).');
      return;
    }
    if (!holder) {
      showErr('wire-err', 'wire-err-msg', 'Beneficiary name is required.');
      return;
    }
    if (!iban) {
      showErr('wire-err', 'wire-err-msg', 'Account/IBAN is required.');
      return;
    }
    if (!country) {
      showErr('wire-err', 'wire-err-msg', 'Please select destination country.');
      return;
    }
    if (amt < 1) {
      showErr('wire-err', 'wire-err-msg', 'Please enter a valid amount.');
      return;
    }
    setBtn('wire-btn', true);
    setTimeout(function() {
      setBtn('wire-btn', false, '<i class="fa-solid fa-globe"></i>Send Wire Transfer');
      showOk('wire-ok', 'wire-ok-msg', 'Wire transfer of ' + currency + ' ' + amt.toFixed(2) + ' to ' + bank + ' (' + swift + ') initiated! Processing in 1-3 business days.');
      dbToast('Wire transfer initiated. Ref: WIRE-' + Date.now().toString(36).toUpperCase(), 'ok');
      setTimeout(function() {
        closeModal('wireTransferModal');
      }, 2500);
    }, 1800);
  }

  /* ── ETHSWITCH ── */
  function submitEthSwitch() {
    clearAlerts();
    var from = document.getElementById('eth-from').value.trim();
    var bank = document.getElementById('eth-bank').value;
    var to = document.getElementById('eth-to').value.trim();
    var holder = document.getElementById('eth-holder').value.trim();
    var amt = parseFloat(document.getElementById('eth-amt').value) || 0;
    if (!from) {
      showErr('eth-err', 'eth-err-msg', 'Source account is required.');
      return;
    }
    if (!bank) {
      showErr('eth-err', 'eth-err-msg', 'Please select destination bank.');
      return;
    }
    if (!to) {
      showErr('eth-err', 'eth-err-msg', 'Destination account is required.');
      return;
    }
    if (!holder) {
      showErr('eth-err', 'eth-err-msg', 'Account holder name is required.');
      return;
    }
    if (amt < 1) {
      showErr('eth-err', 'eth-err-msg', 'Please enter a valid amount.');
      return;
    }
    setBtn('eth-btn', true);
    apiFetch('/api/transactions/transfer', {
      method: 'POST',
      body: JSON.stringify({
        from_account_number: from,
        to_account_number: to,
        to_bank: bank,
        amount: amt,
        description: 'EthSwitch transfer to ' + holder,
        channel: 'EthSwitch'
      })
    }).then(function(r) {
      return r.json();
    }).then(function(d) {
      setBtn('eth-btn', false, '<i class="fa-solid fa-bolt"></i>Send via EthSwitch');
      if (d && d.success) {
        showOk('eth-ok', 'eth-ok-msg', 'EthSwitch transfer of ETB ' + amt.toFixed(2) + ' to ' + holder + ' at ' + bank + ' completed instantly!');
        dbToast('EthSwitch transfer completed!', 'ok');
        setTimeout(function() {
          closeModal('ethswitchModal');
          refreshDashboard();
        }, 2200);
      } else {
        showErr('eth-err', 'eth-err-msg', (d && d.message) || 'Transfer failed.');
      }
    }).catch(function() {
      setBtn('eth-btn', false, '<i class="fa-solid fa-bolt"></i>Send via EthSwitch');
      showOk('eth-ok', 'eth-ok-msg', 'Demo: EthSwitch ETB ' + amt.toFixed(2) + ' → ' + holder + ' (' + bank + ') recorded.');
      dbToast('Demo EthSwitch transfer recorded.', 'info');
      setTimeout(function() {
        closeModal('ethswitchModal');
      }, 2200);
    });
  }

  /* ── DEMO SUBMIT (Telebirr, WU, M-Pesa, Wise, Payoneer, Fund, Balance) ── */
  function submitDemo(modalId, okId, msgId, successMsg) {
    dbToast(successMsg, 'ok');
    var okEl = document.getElementById(okId);
    var msgEl = document.getElementById(msgId);
    if (okEl && msgEl) {
      msgEl.textContent = successMsg;
      okEl.classList.add('show');
    }
    setTimeout(function() {
      closeModal(modalId);
    }, 2000);
  }

  /* ── NEW CUSTOMER ── */
  function submitNewCustomer() {
    clearAlerts();
    var fn = document.getElementById('cust-fn').value.trim();
    var ln = document.getElementById('cust-ln').value.trim();
    var ph = document.getElementById('cust-phone').value.trim();
    var nid = document.getElementById('cust-nid').value.trim();
    var at = document.getElementById('cust-acct').value;
    if (!fn || !ln) {
      showErr('cust-err', 'cust-err-msg', 'Full name is required.');
      return;
    }
    if (!ph) {
      showErr('cust-err', 'cust-err-msg', 'Phone number is required.');
      return;
    }
    if (!nid) {
      showErr('cust-err', 'cust-err-msg', 'National ID is required.');
      return;
    }
    if (!at) {
      showErr('cust-err', 'cust-err-msg', 'Please select account type.');
      return;
    }
    setBtn('cust-btn', true);
    var em = document.getElementById('cust-email').value.trim();
    var dep = parseFloat(document.getElementById('cust-dep').value) || 0;
    apiFetch('/api/customers', {
      method: 'POST',
      body: JSON.stringify({
        first_name: fn,
        last_name: ln,
        phone: ph,
        national_id: nid,
        email: em,
        account_type: at,
        initial_deposit: dep
      })
    }).then(function(r) {
      return r.json();
    }).then(function(d) {
      setBtn('cust-btn', false, '<i class="fa-solid fa-user-plus"></i>Register');
      if (d && d.success) {
        showOk('cust-ok', 'cust-ok-msg', 'Customer ' + fn + ' ' + ln + ' registered successfully!');
        dbToast('Customer ' + fn + ' ' + ln + ' registered!', 'ok');
        setTimeout(function() {
          closeModal('newCustomerModal');
          refreshDashboard();
        }, 2200);
      } else {
        showErr('cust-err', 'cust-err-msg', (d && d.message) || 'Registration failed.');
      }
    }).catch(function() {
      setBtn('cust-btn', false, '<i class="fa-solid fa-user-plus"></i>Register');
      showOk('cust-ok', 'cust-ok-msg', 'Demo: Customer ' + fn + ' ' + ln + ' recorded (database offline).');
      dbToast('Demo customer registration recorded.', 'info');
      setTimeout(function() {
        closeModal('newCustomerModal');
      }, 2200);
    });
  }

  /* ── ADD EMPLOYEE (Dashboard Quick Action) ── */
  function previewEmpAv(input) {
    if (!input.files || !input.files[0]) return;
    var reader = new FileReader();
    reader.onload = function(e) {
      var img = document.getElementById('emp-av-img');
      var init = document.getElementById('emp-av-init');
      img.src = e.target.result;
      img.style.display = 'block';
      init.style.display = 'none';
    };
    reader.readAsDataURL(input.files[0]);
  }

  function updateEmpAv() {
    var fn = (document.getElementById('enew-fn').value.trim()[0] || '').toUpperCase();
    var ln = (document.getElementById('enew-ln').value.trim()[0] || '').toUpperCase();
    var init = document.getElementById('emp-av-init');
    var img = document.getElementById('emp-av-img');
    if (init && !img.src) init.textContent = (fn + ln) || '?';
  }

  function submitDashEmployee() {
    var fn = document.getElementById('enew-fn').value.trim();
    var ln = document.getElementById('enew-ln').value.trim();
    var phone = document.getElementById('enew-phone').value.trim();
    var dept = document.getElementById('enew-dept').value;
    var pos = document.getElementById('enew-pos').value.trim();
    var email = document.getElementById('enew-email').value.trim();
    var branch = document.getElementById('enew-branch').value;
    var salary = parseFloat(document.getElementById('enew-salary').value) || 0;
    var nid = document.getElementById('enew-nid').value.trim();
    var join = document.getElementById('enew-join').value;
    var gender = document.getElementById('enew-gender').value;
    var etype = document.getElementById('enew-type').value;

    document.getElementById('emp-db-err').classList.remove('show');
    document.getElementById('emp-db-ok').classList.remove('show');

    if (!fn || !ln) {
      showEmpDbErr('First and last name are required.');
      return;
    }
    if (!phone) {
      showEmpDbErr('Phone number is required.');
      return;
    }
    if (!dept) {
      showEmpDbErr('Department is required.');
      return;
    }
    if (!pos) {
      showEmpDbErr('Position is required.');
      return;
    }

    setBtn('enew-btn', true);

    apiFetch('/api/employees', {
      method: 'POST',
      body: JSON.stringify({
        first_name: fn,
        last_name: ln,
        phone: phone,
        email: email,
        department: dept,
        position: pos,
        branch: branch,
        basic_salary: salary,
        national_id: nid,
        join_date: join,
        gender: gender,
        employment_type: etype
      })
    }).then(function(d) {
      setBtn('enew-btn', false, '<i class="fa-solid fa-user-plus"></i> Add Employee');
      if (d && d.success) {
        var empId = d.data && d.data.employee_id;
        var empNo = d.data && d.data.employee_number;
        document.getElementById('emp-db-ok-msg').textContent = fn + ' ' + ln + ' added! Employee No: ' + (empNo || '');
        document.getElementById('emp-db-ok').classList.add('show');
        dbToast(fn + ' ' + ln + ' added as employee!', 'ok');

        /* Upload photo if selected */
        var photoFile = document.getElementById('emp-photo-file');
        if (photoFile && photoFile.files && photoFile.files[0] && empId) {
          var fd = new FormData();
          fd.append('photo', photoFile.files[0]);
          fd.append('employee_id', empId);
          fetch(BASE_URL + '/api/upload/employee-photo', {
              method: 'POST',
              credentials: 'include',
              headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
              },
              body: fd
            }).then(function(r) {
              return r.json();
            })
            .then(function(pr) {
              if (pr && pr.success) dbToast('Photo uploaded!', 'ok');
            })
            .catch(function() {});
        }

        setTimeout(function() {
          closeModal('newEmployeeModal');
          refreshDashboard();
          /* Reset form */
          ['enew-fn', 'enew-ln', 'enew-phone', 'enew-email', 'enew-dept', 'enew-pos',
            'enew-branch', 'enew-salary', 'enew-nid', 'enew-gender'
          ].forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.value = '';
          });
          document.getElementById('emp-av-init').textContent = '?';
          document.getElementById('emp-av-img').style.display = 'none';
          document.getElementById('emp-av-img').src = '';
        }, 1800);
      } else {
        showEmpDbErr((d && d.message) || 'Failed to add employee. Please check all required fields.');
      }
    }).catch(function() {
      setBtn('enew-btn', false, '<i class="fa-solid fa-user-plus"></i> Add Employee');
      /* Demo mode */
      document.getElementById('emp-db-ok-msg').textContent = 'Demo: ' + fn + ' ' + ln + ' recorded (Database offline).';
      document.getElementById('emp-db-ok').classList.add('show');
      dbToast('Demo employee recorded.', 'info');
      setTimeout(function() {
        closeModal('newEmployeeModal');
        refreshDashboard();
      }, 1800);
    });
  }

  function showEmpDbErr(msg) {
    document.getElementById('emp-db-err-msg').textContent = msg;
    document.getElementById('emp-db-err').classList.add('show');
  }

  /* ── APPLY CARD ── */
  function submitApplyCard() {
    var name = document.getElementById('card-name').value.trim();
    var acc = document.getElementById('card-acc').value.trim();
    var net = document.querySelector('input[name="card-network"]:checked');
    if (!name || !acc || !net) {
      dbToast('Please fill all required fields.', 'err');
      return;
    }
    var okEl = document.getElementById('card-ok');
    var msgEl = document.getElementById('card-ok-msg');
    if (okEl && msgEl) {
      msgEl.textContent = 'Virtual ' + net.value + ' card application submitted! Approval within 24 hours.';
      okEl.classList.add('show');
    }
    dbToast('Card application submitted successfully!', 'ok');
    setTimeout(function() {
      closeModal('applyCardModal');
    }, 2500);
  }

  /* ── CHARTS ── */
  document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;
    Chart.defaults.font.family = "'Inter',sans-serif";
    Chart.defaults.color = '#64748b';

    new Chart(document.getElementById('revenueChart'), {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'Deposits (ETB B)',
            data: [1.2, 1.4, 1.1, 1.6, 1.8, 2.1, 1.9, 2.4, 2.2, 2.6, 2.3, 2.8],
            backgroundColor: 'rgba(16,185,129,.75)',
            borderRadius: 6,
            borderSkipped: false
          },
          {
            label: 'Withdrawals (ETB B)',
            data: [0.9, 1.0, 0.8, 1.1, 1.3, 1.5, 1.4, 1.8, 1.6, 1.9, 1.7, 2.0],
            backgroundColor: 'rgba(239,68,68,.65)',
            borderRadius: 6,
            borderSkipped: false
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: {
                size: 11
              },
              padding: 12
            }
          },
          tooltip: {
            callbacks: {
              label: function(c) {
                return c.dataset.label + ': ETB ' + c.raw + 'B';
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0,0,0,.04)'
            },
            ticks: {
              callback: function(v) {
                return 'ETB ' + v + 'B';
              }
            }
          }
        }
      }
    });

    new Chart(document.getElementById('txnChart'), {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
          label: 'Transactions',
          data: [720, 845, 690, 910, 1050, 620, 380],
          borderColor: '#007A8A',
          backgroundColor: 'rgba(0,122,138,.1)',
          borderWidth: 2.5,
          fill: true,
          tension: .4,
          pointBackgroundColor: '#007A8A',
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0,0,0,.04)'
            }
          }
        }
      }
    });

    var ac = document.getElementById('acctChart');
    if (ac) {
      new Chart(ac, {
        type: 'doughnut',
        data: {
          labels: ['Savings', 'Current', 'Fixed Deposit'],
          datasets: [{
            data: [52, 31, 17],
            backgroundColor: ['#10b981', '#1B3A5C', '#C8A84B'],
            borderWidth: 3,
            borderColor: '#fff',
            hoverOffset: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '68%',
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              callbacks: {
                label: function(c) {
                  return c.label + ': ' + c.raw + '%';
                }
              }
            }
          }
        }
      });
    }
  });
</script>