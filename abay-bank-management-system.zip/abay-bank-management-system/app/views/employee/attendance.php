<?php $pageTitle = 'Attendance — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Attendance Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/employees">Employees</a><span class="sep">/</span><span>Attendance</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <input type="date" id="att-date" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer;outline:none" onchange="loadAttendance()">
    <button class="btn btn-success btn-sm" onclick="markAllPresent()"><i class="fa-solid fa-check-double"></i> Mark All Present</button>
    <button class="btn btn-light btn-sm" onclick="exportAttCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-user-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Present</div>
      <div class="stat-value" id="att-present">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-user-xmark"></i></div>
    <div class="stat-content">
      <div class="stat-label">Absent</div>
      <div class="stat-value" id="att-absent">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-content">
      <div class="stat-label">Late</div>
      <div class="stat-value" id="att-late">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-percent"></i></div>
    <div class="stat-content">
      <div class="stat-label">Attendance Rate</div>
      <div class="stat-value" id="att-rate">—</div>
    </div>
  </div>
</div>
<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-check" style="color:#1B3A5C;margin-right:7px"></i>Today's Attendance</h3>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Check In</th>
            <th>Check Out</th>
            <th>Hours</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="att-tbody">
          <tr>
            <td colspan="7" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
              <div style="margin-top:8px;font-size:.84rem">Loading...</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-fingerprint" style="color:#1B3A5C;margin-right:6px"></i>Check In / Out</h4>
      </div>
      <div class="card-body">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:5px">Employee ID / Name</label>
          <input type="text" id="checkin-emp" placeholder="Search employee..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none;margin-bottom:10px" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
          <button onclick="doCheckIn()" style="padding:11px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;border:none;border-radius:9px;font-size:.84rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-to-bracket"></i>Check In</button>
          <button onclick="doCheckOut()" style="padding:11px;background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;border:none;border-radius:9px;font-size:.84rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-from-bracket"></i>Check Out</button>
        </div>
        <div id="checkin-msg" style="display:none;font-size:.82rem;border-radius:8px;padding:9px 12px;text-align:center"></div>
        <div style="background:#f8fafc;border-radius:9px;padding:12px;text-align:center;margin-top:6px">
          <div style="font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Current Time</div>
          <div style="font-size:1.5rem;font-weight:800;color:#1B3A5C" id="att-clock"><?= date('H:i:s') ?></div>
          <div style="font-size:.76rem;color:#94a3b8;margin-top:2px"><?= date('l, d F Y') ?></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-chart-bar" style="color:#1B3A5C;margin-right:6px"></i>Weekly Overview</h4>
      </div>
      <div class="card-body"><canvas id="att-chart" height="160"></canvas></div>
    </div>
  </div>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _attData = [];
  var demoAtt = [{
      employee_number: 'EMP001',
      name: 'Yohannes Bekele',
      check_in: '08:02',
      check_out: '17:05',
      hours: '9h 03m',
      status: 'Present'
    },
    {
      employee_number: 'EMP002',
      name: 'Tigist Haile',
      check_in: '08:45',
      check_out: '17:10',
      hours: '8h 25m',
      status: 'Late'
    },
    {
      employee_number: 'EMP003',
      name: 'Solomon Girma',
      check_in: '07:58',
      check_out: '17:00',
      hours: '9h 02m',
      status: 'Present'
    },
    {
      employee_number: 'EMP004',
      name: 'Hanna Tadesse',
      check_in: '',
      check_out: '',
      hours: '—',
      status: 'Absent'
    },
    {
      employee_number: 'EMP005',
      name: 'Dawit Alemu',
      check_in: '08:05',
      check_out: '17:15',
      hours: '9h 10m',
      status: 'Present'
    },
    {
      employee_number: 'EMP006',
      name: 'Meron Getnet',
      check_in: '',
      check_out: '',
      hours: '—',
      status: 'Leave'
    },
  ];
  // Set today's date
  var today = new Date();
  today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
  document.getElementById('att-date').value = today.toISOString().split('T')[0];
  // Clock
  setInterval(function() {
    var n = new Date(),
      p = function(x) {
        return String(x).padStart(2, '0');
      };
    var el = document.getElementById('att-clock');
    if (el) el.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
  }, 1000);

  function loadAttendance() {
    var date = document.getElementById('att-date').value;
    ABAY.api('/attendance?date=' + date).then(function(d) {
      var rows = (d && d.success && d.data && d.data.length) ? d.data : demoAtt;
      _attData = rows;
      renderAtt(rows);
    }).catch(function() {
      _attData = demoAtt;
      renderAtt(demoAtt);
    });
  }

  function renderAtt(rows) {
    var present = 0,
      absent = 0,
      late = 0;
    rows.forEach(function(r) {
      if (r.status === 'Present') present++;
      else if (r.status === 'Absent') absent++;
      else if (r.status === 'Late') late++;
    });
    var total = rows.length || 1;
    document.getElementById('att-present').textContent = present;
    document.getElementById('att-absent').textContent = absent;
    document.getElementById('att-late').textContent = late;
    document.getElementById('att-rate').textContent = Math.round((present + late) / total * 100) + '%';
    var statColors = {
      Present: '#10b981',
      Late: '#f59e0b',
      Absent: '#ef4444',
      Leave: '#3b82f6'
    };
    document.getElementById('att-tbody').innerHTML = rows.map(function(r) {
      return '<tr>' +
        '<td><span style="font-family:monospace;font-size:.75rem;color:#475569">' + (r.employee_number || '—') + '</span></td>' +
        '<td style="font-size:.83rem;font-weight:600;color:#1e293b">' + (r.name || '—') + '</td>' +
        '<td style="font-size:.82rem">' + (r.check_in || '<span style="color:#94a3b8">—</span>') + '</td>' +
        '<td style="font-size:.82rem">' + (r.check_out || '<span style="color:#94a3b8">—</span>') + '</td>' +
        '<td style="font-size:.82rem">' + (r.hours || '—') + '</td>' +
        '<td>' + ABAY.badge(r.status || 'Absent') + '</td>' +
        '<td><button onclick="updateStatus(\'' + r.employee_number + '\',\'' + r.status + '\')" style="font-size:.73rem;padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-family:inherit" title="Edit Status"><i class="fa-solid fa-pen"></i></button></td>' +
        '</tr>';
    }).join('');
    drawAttChart(present, absent, late);
  }

  function drawAttChart(p, a, l) {
    if (typeof Chart === 'undefined') return;
    var ctx = document.getElementById('att-chart');
    if (!ctx) return;
    if (window._attChart) window._attChart.destroy();
    window._attChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [{
          label: 'Present',
          data: [142, 138, 145, 140, 143, 98],
          backgroundColor: 'rgba(16,185,129,.75)',
          borderRadius: 4
        }, {
          label: 'Absent',
          data: [14, 18, 11, 16, 13, 8],
          backgroundColor: 'rgba(239,68,68,.65)',
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: {
                size: 10
              },
              padding: 10
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0,0,0,.04)'
            },
            stacked: false
          }
        }
      }
    });
  }

  function doCheckIn() {
    var emp = document.getElementById('checkin-emp').value.trim();
    if (!emp) {
      ABAY.toast('Please enter employee ID or name.', 'err');
      return;
    }
    ABAY.api('/attendance/checkin', {
      method: 'POST',
      body: JSON.stringify({
        employee: emp,
        time: new Date().toTimeString().slice(0, 5)
      })
    }).then(function(d) {
      var msg = document.getElementById('checkin-msg');
      msg.style.display = 'block';
      msg.style.background = '#d1fae5';
      msg.style.color = '#065f46';
      msg.style.border = '1px solid #a7f3d0';
      msg.textContent = (d && d.success) ? '✓ ' + emp + ' checked in at ' + new Date().toLocaleTimeString() : 'Demo: ' + emp + ' checked in at ' + new Date().toLocaleTimeString();
      ABAY.toast(emp + ' checked in!', 'ok');
    }).catch(function() {
      var msg = document.getElementById('checkin-msg');
      msg.style.display = 'block';
      msg.style.background = '#d1fae5';
      msg.style.color = '#065f46';
      msg.style.border = '1px solid #a7f3d0';
      msg.textContent = 'Demo: ' + emp + ' checked in at ' + new Date().toLocaleTimeString();
      ABAY.toast('Demo check-in recorded.', 'info');
    });
  }

  function doCheckOut() {
    var emp = document.getElementById('checkin-emp').value.trim();
    if (!emp) {
      ABAY.toast('Please enter employee ID or name.', 'err');
      return;
    }
    ABAY.api('/attendance/checkout', {
      method: 'POST',
      body: JSON.stringify({
        employee: emp,
        time: new Date().toTimeString().slice(0, 5)
      })
    }).then(function(d) {
      var msg = document.getElementById('checkin-msg');
      msg.style.display = 'block';
      msg.style.background = '#fee2e2';
      msg.style.color = '#991b1b';
      msg.style.border = '1px solid #fecaca';
      msg.textContent = (d && d.success) ? '✓ ' + emp + ' checked out at ' + new Date().toLocaleTimeString() : 'Demo: ' + emp + ' checked out at ' + new Date().toLocaleTimeString();
      ABAY.toast(emp + ' checked out!', 'ok');
    }).catch(function() {
      var msg = document.getElementById('checkin-msg');
      msg.style.display = 'block';
      msg.style.background = '#fee2e2';
      msg.style.color = '#991b1b';
      msg.style.border = '1px solid #fecaca';
      msg.textContent = 'Demo: ' + emp + ' checked out at ' + new Date().toLocaleTimeString();
      ABAY.toast('Demo check-out recorded.', 'info');
    });
  }

  function markAllPresent() {
    if (!confirm('Mark all employees as present today?')) return;
    ABAY.toast('All employees marked as present!', 'ok');
    _attData.forEach(function(r) {
      if (r.status !== 'Leave') r.status = 'Present';
    });
    renderAtt(_attData);
  }

  function updateStatus(empId, current) {
    var newStatus = prompt('Update status for ' + empId + ' (Present/Absent/Late/Leave):', current);
    if (newStatus) {
      ABAY.api('/attendance/' + empId, {
        method: 'PUT',
        body: JSON.stringify({
          status: newStatus
        })
      }).then(function() {
        ABAY.toast('Status updated!', 'ok');
        loadAttendance();
      }).catch(function() {
        ABAY.toast('Demo: status updated.', 'info');
        _attData.forEach(function(r) {
          if (r.employee_number === empId) r.status = newStatus;
        });
        renderAtt(_attData);
      });
    }
  }

  function exportAttCSV() {
    var rows = [
      ['Employee ID', 'Name', 'Check In', 'Check Out', 'Hours', 'Status']
    ].concat(_attData.map(function(r) {
      return [r.employee_number, r.name, r.check_in || '', r.check_out || '', r.hours || '', r.status];
    }));
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'attendance.csv';
    a.click();
  }
  document.addEventListener('DOMContentLoaded', function() {
    loadAttendance();
  });
</script>