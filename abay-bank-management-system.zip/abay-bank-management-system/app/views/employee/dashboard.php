<?php
$pageTitle = 'Employee Dashboard — ' . APP_NAME;
$u = $user ?? [];
$emp = $empData ?? null;
$hour = (int)date('G');
$greet = $hour < 12 ? 'Good Morning' : ($hour < 17 ? 'Good Afternoon' : 'Good Evening');
$name = htmlspecialchars($u['full_name'] ?? $u['username'] ?? 'Employee');
$first = explode(' ', $name)[0];

// Demo data
if (!$emp) {
    $emp = ['employee_number'=>'EMP002','dept_name'=>'Customer Service','position'=>'Senior Teller','branch_name'=>'Bole Branch','basic_salary'=>18000,'phone'=>'0922-222-002'];
}
$attMonth = $attendanceMonth ?? [];
if (empty($attMonth)) {
    $attMonth = [
        ['date'=>date('Y-m-d'),'check_in'=>'08:05','check_out'=>'17:10','status'=>'Present'],
        ['date'=>date('Y-m-d',strtotime('-1 day')),'check_in'=>'08:32','check_out'=>'17:05','status'=>'Late'],
        ['date'=>date('Y-m-d',strtotime('-2 days')),'check_in'=>'07:58','check_out'=>'17:00','status'=>'Present'],
        ['date'=>date('Y-m-d',strtotime('-3 days')),'check_in'=>'','check_out'=>'','status'=>'Absent'],
        ['date'=>date('Y-m-d',strtotime('-4 days')),'check_in'=>'08:01','check_out'=>'17:05','status'=>'Present'],
        ['date'=>date('Y-m-d',strtotime('-7 days')),'check_in'=>'08:10','check_out'=>'17:00','status'=>'Present'],
    ];
}
$present = count(array_filter($attMonth, fn($r) => ($r['status']??'') === 'Present'));
$late    = count(array_filter($attMonth, fn($r) => ($r['status']??'') === 'Late'));
$absent  = count(array_filter($attMonth, fn($r) => ($r['status']??'') === 'Absent'));
$total   = count($attMonth);
$rate    = $total > 0 ? round(($present + $late) / $total * 100) : 0;

$leave = $leaveBalance ?? ['annual_total'=>21,'annual_used'=>8,'sick_total'=>10,'sick_used'=>2];
$slip  = $payslip ?? ['basic_salary'=>18000,'allowances'=>3500,'deductions'=>3100,'tax'=>2700,'net_salary'=>15700,'pay_month'=>date('Y-m')];
?>
<style>
.emp-hero{background:linear-gradient(135deg,#1B3A5C 0%,#007A8A 100%);border-radius:16px;padding:24px 28px;margin-bottom:24px;color:#fff;position:relative;overflow:hidden}
.emp-hero::before{content:'';position:absolute;top:-60px;right:-60px;width:240px;height:240px;background:radial-gradient(circle,rgba(200,168,75,.18),transparent 70%);border-radius:50%;pointer-events:none}
.att-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:99px;font-size:.78rem;font-weight:700}
.leave-bar{height:10px;border-radius:99px;overflow:hidden;background:#e2e8f0;margin-top:6px}
.leave-bar-fill{height:100%;border-radius:99px;transition:width .8s ease}
</style>

<!-- Page header -->
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-id-badge" style="color:#1B3A5C;margin-right:8px"></i>Employee Dashboard</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/employees">Employees</a><span class="sep">/</span><span>My Dashboard</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <a href="<?= APP_URL ?>/employees/attendance" class="btn btn-ghost btn-sm"><i class="fa-solid fa-calendar-check"></i> Attendance</a>
    <a href="<?= APP_URL ?>/employees/leave" class="btn btn-ghost btn-sm"><i class="fa-solid fa-calendar-xmark"></i> Leave</a>
    <a href="<?= APP_URL ?>/employees/payroll" class="btn btn-primary btn-sm"><i class="fa-solid fa-receipt"></i> Payroll</a>
  </div>
</div>

<!-- Hero Banner -->
<div class="emp-hero">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;position:relative;z-index:1">
    <div style="display:flex;align-items:center;gap:18px">
      <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#C8A84B,#e8c86a);color:#1B3A5C;display:flex;align-items:center;justify-content:center;font-size:1.6rem;font-weight:900;flex-shrink:0;box-shadow:0 4px 16px rgba(0,0,0,.2)"><?= strtoupper(substr($first,0,1)) ?></div>
      <div>
        <div style="font-size:.68rem;color:rgba(255,255,255,.55);font-weight:700;letter-spacing:1.2px;text-transform:uppercase;margin-bottom:3px"><?= $greet ?></div>
        <div style="font-size:1.4rem;font-weight:800;color:#fff"><?= $first ?>!</div>
        <div style="font-size:.82rem;color:rgba(255,255,255,.68);margin-top:3px">
          <i class="fa-solid fa-briefcase" style="color:#C8A84B;margin-right:5px"></i><?= htmlspecialchars($emp['position']??'Staff') ?>
          &nbsp;·&nbsp;
          <i class="fa-solid fa-building" style="color:#C8A84B;margin-right:5px"></i><?= htmlspecialchars($emp['branch_name']??'Head Office') ?>
          &nbsp;·&nbsp;
          <i class="fa-solid fa-id-badge" style="color:#C8A84B;margin-right:5px"></i><?= htmlspecialchars($emp['employee_number']??'—') ?>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <div style="background:rgba(255,255,255,.1);border-radius:12px;padding:12px 18px;text-align:center;backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.15)">
        <div style="font-size:.65rem;color:rgba(255,255,255,.55);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Department</div>
        <div style="font-size:.92rem;font-weight:700;color:#fff"><?= htmlspecialchars($emp['dept_name']??'Operations') ?></div>
      </div>
      <div style="background:rgba(255,255,255,.1);border-radius:12px;padding:12px 18px;text-align:center;backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.15)">
        <div style="font-size:.65rem;color:rgba(255,255,255,.55);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">This Month</div>
        <div style="font-size:.92rem;font-weight:700;color:#C8A84B"><?= $rate ?>% Attendance</div>
      </div>
      <div style="background:rgba(255,255,255,.1);border-radius:12px;padding:12px 18px;text-align:center;backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.15)">
        <div style="font-size:.65rem;color:rgba(255,255,255,.55);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Net Salary</div>
        <div style="font-size:.92rem;font-weight:700;color:#6ee7b7">ETB <?= number_format($slip['net_salary']??0) ?></div>
      </div>
    </div>
  </div>
</div>

<!-- Stats Row -->
<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:22px">
  <div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-user-check"></i></div><div class="stat-content"><div class="stat-label">Present Days</div><div class="stat-value"><?= $present ?></div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><i class="fa-solid fa-clock"></i></div><div class="stat-content"><div class="stat-label">Late Days</div><div class="stat-value"><?= $late ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red"><i class="fa-solid fa-user-xmark"></i></div><div class="stat-content"><div class="stat-label">Absent Days</div><div class="stat-value"><?= $absent ?></div></div></div>
  <div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-percent"></i></div><div class="stat-content"><div class="stat-label">Attendance Rate</div><div class="stat-value"><?= $rate ?>%</div></div></div>
  <div class="stat-card"><div class="stat-icon teal"><i class="fa-solid fa-calendar-days"></i></div><div class="stat-content"><div class="stat-label">Leave Balance</div><div class="stat-value"><?= (int)($leave['annual_total']??21) - (int)($leave['annual_used']??0) ?> days</div></div></div>
</div>

<div style="display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:22px">
  <!-- Attendance Table -->
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-check" style="color:#1B3A5C;margin-right:7px"></i>This Month's Attendance</h3>
      <a href="<?= APP_URL ?>/employees/attendance" style="font-size:.76rem;color:#007A8A;font-weight:700;text-decoration:none">Full Report →</a>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($attMonth as $a):
            $sc = match($a['status']??'') {'Present'=>'success','Late'=>'warning','Absent'=>'danger',default=>'secondary'};
          ?>
          <tr>
            <td style="font-size:.81rem"><?= date('d M', strtotime($a['date']??'now')) ?></td>
            <td style="font-size:.81rem;color:<?= empty($a['check_in'])?'#94a3b8':'#059669' ?>"><?= $a['check_in'] ?: '—' ?></td>
            <td style="font-size:.81rem;color:<?= empty($a['check_out'])?'#94a3b8':'#475569' ?>"><?= $a['check_out'] ?: '—' ?></td>
            <td><span class="badge badge-<?= $sc ?>"><?= $a['status'] ?></span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <!-- Check In/Out widget -->
    <div style="padding:14px 16px;border-top:1px solid #f1f5f9;background:#f8fafc">
      <div style="font-size:.7rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px">Today's Check In / Out</div>
      <div style="display:flex;gap:8px">
        <button onclick="doCheckInOut('in')" style="flex:1;padding:10px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;border:none;border-radius:9px;font-size:.82rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-to-bracket"></i>Check In</button>
        <button onclick="doCheckInOut('out')" style="flex:1;padding:10px;background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;border:none;border-radius:9px;font-size:.82rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-right-from-bracket"></i>Check Out</button>
      </div>
      <div id="checkinout-msg" style="margin-top:8px;font-size:.78rem;color:#64748b;text-align:center"></div>
    </div>
  </div>

  <!-- Leave Balance -->
  <div style="display:flex;flex-direction:column;gap:18px">
    <div class="card">
      <div class="card-header"><h3><i class="fa-solid fa-calendar-xmark" style="color:#1B3A5C;margin-right:7px"></i>Leave Balance</h3><a href="<?= APP_URL ?>/employees/leave" style="font-size:.76rem;color:#007A8A;font-weight:700;text-decoration:none">Apply →</a></div>
      <div class="card-body">
        <?php foreach([
          ['Annual Leave', $leave['annual_used']??8, $leave['annual_total']??21, '#1B3A5C'],
          ['Sick Leave',   $leave['sick_used']??2,   $leave['sick_total']??10,   '#007A8A'],
        ] as [$lt,$used,$total,$color]): ?>
        <div style="margin-bottom:16px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <span style="font-size:.82rem;font-weight:600;color:#374151"><?= $lt ?></span>
            <span style="font-size:.78rem;color:#64748b"><?= $used ?>/<?= $total ?> days used</span>
          </div>
          <div class="leave-bar"><div class="leave-bar-fill" style="width:<?= $total>0?round($used/$total*100):0 ?>%;background:<?= $color ?>"></div></div>
          <div style="font-size:.73rem;color:#94a3b8;margin-top:4px"><?= $total - $used ?> days remaining</div>
        </div>
        <?php endforeach; ?>
        <button onclick="document.getElementById('apply-leave-modal').style.display='flex'" style="width:100%;padding:10px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;font-size:.83rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:7px"><i class="fa-solid fa-plus"></i>Apply for Leave</button>
      </div>
    </div>

    <!-- Monthly Payslip -->
    <div class="card">
      <div class="card-header"><h3><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:7px"></i>Latest Payslip</h3><a href="<?= APP_URL ?>/employees/payroll" style="font-size:.76rem;color:#007A8A;font-weight:700;text-decoration:none">All →</a></div>
      <div class="card-body">
        <div style="text-align:center;background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:10px;padding:14px;margin-bottom:14px">
          <div style="font-size:.67rem;color:rgba(255,255,255,.6);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px"><?= htmlspecialchars($slip['pay_month']??date('Y-m')) ?></div>
          <div style="font-size:1.6rem;font-weight:900;color:#fff">ETB <?= number_format($slip['net_salary']??0) ?></div>
          <div style="font-size:.74rem;color:rgba(255,255,255,.55);margin-top:3px">Net Salary</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <?php foreach([['Basic Salary','basic_salary','#059669'],['Allowances','allowances','#059669'],['Deductions','deductions','#ef4444'],['Income Tax','tax','#f59e0b']] as [$l,$k,$c]): ?>
          <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.79rem;color:#64748b;font-weight:600"><?= $l ?></span>
            <span style="font-size:.82rem;font-weight:700;color:<?= $c ?>">ETB <?= number_format($slip[$k]??0) ?></span>
          </div>
          <?php endforeach; ?>
        </div>
        <button onclick="printPayslip()" style="width:100%;margin-top:12px;padding:9px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.82rem;font-weight:600;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px"><i class="fa-solid fa-print"></i>Print Payslip</button>
      </div>
    </div>
  </div>

  <!-- Quick Links + Performance -->
  <div style="display:flex;flex-direction:column;gap:18px">
    <div class="card">
      <div class="card-header"><h3><i class="fa-solid fa-bolt" style="color:#C8A84B;margin-right:7px"></i>Quick Actions</h3></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:9px">
        <?php foreach([
          ['/employees/attendance','fa-calendar-check','#059669','View Attendance Record'],
          ['/employees/leave',     'fa-calendar-xmark','#f59e0b','Apply for Leave'],
          ['/employees/payroll',   'fa-receipt',       '#1B3A5C','View Payroll History'],
          ['/employees/performance','fa-chart-bar',    '#007A8A','My Performance'],
          ['/employees/training',  'fa-graduation-cap','#5b21b6','Training Programs'],
          ['/support/complaints',  'fa-headset',       '#dc2626','Support / Complaints'],
        ] as [$href,$ic,$clr,$lbl]): ?>
        <a href="<?= APP_URL . $href ?>" style="display:flex;align-items:center;gap:10px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#007A8A';this.style.background='#f8fafc'" onmouseout="this.style.borderColor='#e2e8f0';this.style.background=''">
          <div style="width:32px;height:32px;border-radius:8px;background:<?= $clr ?>1a;color:<?= $clr ?>;display:flex;align-items:center;justify-content:center;font-size:.88rem;flex-shrink:0"><i class="fa-solid <?= $ic ?>"></i></div>
          <span style="font-size:.83rem;font-weight:600;color:#1e293b"><?= $lbl ?></span>
          <i class="fa-solid fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.75rem"></i>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-chart-bar" style="color:#1B3A5C;margin-right:6px"></i>Attendance Chart</h4></div>
      <div class="card-body"><canvas id="emp-att-chart" height="180"></canvas></div>
    </div>
  </div>
</div>

<!-- Apply Leave Modal -->
<div id="apply-leave-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:460px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Apply for Leave</div>
      <button onclick="document.getElementById('apply-leave-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="leave-apply-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Leave Type *</label><select id="lv-type" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer"><option>Annual Leave</option><option>Sick Leave</option><option>Emergency Leave</option><option>Maternity/Paternity</option></select></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Start Date *</label><input type="date" id="lv-start" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">End Date *</label><input type="date" id="lv-end" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff"></div>
      </div>
      <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Reason</label><textarea id="lv-reason" rows="3" placeholder="Brief reason for leave..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea></div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('apply-leave-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="lv-submit" onclick="submitLeave()" style="padding:10px 20px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-paper-plane"></i>Submit</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
// Live clock
setInterval(function(){var n=new Date(),p=function(x){return String(x).padStart(2,'0');};var el=document.getElementById('dash-clock');if(el)el.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());},1000);

function doCheckInOut(type) {
  var now = new Date().toLocaleTimeString('en-ET');
  ABAY.api('/attendance/check' + type, { method: 'POST', body: JSON.stringify({ time: now }) }).then(function(d) {
    var msg = document.getElementById('checkinout-msg');
    msg.textContent = (type==='in' ? '✓ Checked in at ' : '✓ Checked out at ') + now;
    msg.style.color = type==='in' ? '#059669' : '#dc2626';
    ABAY.toast(type==='in' ? 'Check in recorded!' : 'Check out recorded!', 'ok');
  }).catch(function() {
    var msg = document.getElementById('checkinout-msg');
    msg.textContent = 'Demo: ' + (type==='in' ? 'Checked in' : 'Checked out') + ' at ' + now;
    msg.style.color = '#64748b';
    ABAY.toast('Demo: ' + (type==='in' ? 'Check in' : 'Check out') + ' recorded.', 'info');
  });
}

function submitLeave() {
  var start = document.getElementById('lv-start').value;
  var end   = document.getElementById('lv-end').value;
  var type  = document.getElementById('lv-type').value;
  if (!start || !end) { ABAY.toast('Start and end dates are required.', 'err'); return; }
  ABAY.setBtn('lv-submit', true);
  ABAY.api('/leaves', { method: 'POST', body: JSON.stringify({ leave_type: type, start_date: start, end_date: end, reason: document.getElementById('lv-reason').value }) }).then(function(d) {
    ABAY.setBtn('lv-submit', false, '<i class="fa-solid fa-paper-plane"></i>Submit');
    document.getElementById('leave-apply-ok').textContent = 'Leave request submitted successfully!';
    document.getElementById('leave-apply-ok').style.display = 'block';
    ABAY.toast('Leave request submitted!', 'ok');
    setTimeout(function() { document.getElementById('apply-leave-modal').style.display = 'none'; }, 1800);
  }).catch(function() {
    ABAY.setBtn('lv-submit', false, '<i class="fa-solid fa-paper-plane"></i>Submit');
    document.getElementById('leave-apply-ok').textContent = 'Demo: Leave request submitted (Database offline).';
    document.getElementById('leave-apply-ok').style.display = 'block';
    ABAY.toast('Demo leave request recorded.', 'info');
    setTimeout(function() { document.getElementById('apply-leave-modal').style.display = 'none'; }, 1800);
  });
}

function printPayslip() { window.print(); }

document.addEventListener('DOMContentLoaded', function() {
  if (typeof Chart === 'undefined') return;
  new Chart(document.getElementById('emp-att-chart'), {
    type: 'bar',
    data: {
      labels: ['Mon','Tue','Wed','Thu','Fri','Mon','Tue','Wed'],
      datasets: [
        { label: 'Present', data: [1,1,0,1,1,1,0,1], backgroundColor: '#10b981', borderRadius: 4 },
        { label: 'Late',    data: [0,0,1,0,0,0,1,0], backgroundColor: '#f59e0b', borderRadius: 4 },
        { label: 'Absent',  data: [0,0,0,0,0,0,0,0], backgroundColor: '#ef4444', borderRadius: 4 },
      ]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, padding: 10 } } }, scales: { x: { grid: { display: false }, stacked: true }, y: { display: false, stacked: true } } }
  });
});
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') document.getElementById('apply-leave-modal').style.display = 'none'; });
</script>
