﻿<?php
$pageTitle = 'Leave Management — ' . APP_NAME;

$leaveRows = $requests ?? [];
if (empty($leaveRows)) {
  $leaveRows = [
    ['id' => 1, 'name' => 'Tigist Haile',   'employee_number' => 'EMP002', 'leave_type' => 'Annual',    'start_date' => date('Y-m-d', strtotime('+2 days')), 'end_date' => date('Y-m-d', strtotime('+7 days')), 'days' => 5, 'reason' => 'Family vacation', 'status' => 'Pending',  'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 2, 'name' => 'Solomon Girma',  'employee_number' => 'EMP003', 'leave_type' => 'Sick',       'start_date' => date('Y-m-d'), 'end_date' => date('Y-m-d', strtotime('+2 days')), 'days' => 3, 'reason' => 'Medical appointment', 'status' => 'Approved', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
    ['id' => 3, 'name' => 'Meron Getnet',   'employee_number' => 'EMP006', 'leave_type' => 'Maternity', 'start_date' => date('Y-m-d', strtotime('-10 days')), 'end_date' => date('Y-m-d', strtotime('+80 days')), 'days' => 90, 'reason' => 'Maternity leave', 'status' => 'Approved', 'created_at' => date('Y-m-d H:i:s', strtotime('-15 days'))],
    ['id' => 4, 'name' => 'Dawit Alemu',    'employee_number' => 'EMP005', 'leave_type' => 'Emergency', 'start_date' => date('Y-m-d', strtotime('-3 days')), 'end_date' => date('Y-m-d', strtotime('-1 day')), 'days' => 2, 'reason' => 'Family emergency', 'status' => 'Approved', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))],
    ['id' => 5, 'name' => 'Hanna Tadesse',  'employee_number' => 'EMP004', 'leave_type' => 'Annual',    'start_date' => date('Y-m-d', strtotime('+10 days')), 'end_date' => date('Y-m-d', strtotime('+14 days')), 'days' => 5, 'reason' => 'Personal trip', 'status' => 'Pending',  'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
    ['id' => 6, 'name' => 'Yohannes Bekele', 'employee_number' => 'EMP001', 'leave_type' => 'Annual',    'start_date' => date('Y-m-d', strtotime('+30 days')), 'end_date' => date('Y-m-d', strtotime('+37 days')), 'days' => 7, 'reason' => 'Annual holiday', 'status' => 'Rejected', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
  ];
}

$pending  = count(array_filter($leaveRows, fn($r) => ($r['status'] ?? '') === 'Pending'));
$approved = count(array_filter($leaveRows, fn($r) => ($r['status'] ?? '') === 'Approved'));
$onLeave  = count(array_filter($leaveRows, fn($r) => ($r['status'] ?? '') === 'Approved' && ($r['start_date'] ?? '') <= date('Y-m-d') && ($r['end_date'] ?? '') >= date('Y-m-d')));
$upcoming = count(array_filter($leaveRows, fn($r) => ($r['status'] ?? '') === 'Approved' && ($r['start_date'] ?? '') > date('Y-m-d')));
?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Leave Management</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span>
      <a href="<?= APP_URL ?>/employees">Employees</a><span class="sep">/</span><span>Leave</span>
    </div>
  </div>
  <button class="btn btn-primary btn-sm" onclick="document.getElementById('new-leave-modal').style.display='flex'"><i class="fa-solid fa-plus"></i> New Leave Request</button>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Pending</div>
      <div class="stat-value"><?= $pending ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Approved</div>
      <div class="stat-value"><?= $approved ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-user-clock"></i></div>
    <div class="stat-content">
      <div class="stat-label">On Leave Today</div>
      <div class="stat-value"><?= $onLeave ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-calendar-days"></i></div>
    <div class="stat-content">
      <div class="stat-label">Upcoming</div>
      <div class="stat-value"><?= $upcoming ?></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-calendar-xmark" style="color:#1B3A5C;margin-right:7px"></i>Leave Requests</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input type="search" id="leave-search" placeholder="Search employee..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:190px;outline:none" oninput="filterLeave(this.value)">
      <select id="leave-status-filter" onchange="filterLeave()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
        <option value="">All Status</option>
        <option>Pending</option>
        <option>Approved</option>
        <option>Rejected</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Employee</th>
          <th>Leave Type</th>
          <th>From</th>
          <th>To</th>
          <th>Days</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="leave-tbody">
        <?php foreach ($leaveRows as $row): ?>
          <?php
          $sc = match ($row['status'] ?? '') {
            'Approved' => 'success',
            'Rejected' => 'danger',
            'Pending' => 'warning',
            default => 'secondary'
          };
          $typeColors = ['Annual' => '#dbeafe|#1d4ed8', 'Sick' => '#fee2e2|#dc2626', 'Maternity' => '#fce7f3|#be185d', 'Emergency' => '#fef3c7|#d97706', 'Paternity' => '#dcfce7|#15803d'];
          [$tbg, $tc] = explode('|', $typeColors[$row['leave_type'] ?? 'Annual'] ?? '#f1f5f9|#475569');
          ?>
          <tr data-name="<?= strtolower(htmlspecialchars($row['name'] ?? '')) ?>" data-status="<?= htmlspecialchars($row['status'] ?? '') ?>">
            <td>
              <div style="display:flex;align-items:center;gap:8px">
                <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;flex-shrink:0"><?= strtoupper(substr($row['name'] ?? 'U', 0, 1)) ?></div>
                <div>
                  <div style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($row['name'] ?? '—') ?></div>
                  <div style="font-size:.72rem;color:#94a3b8"><?= htmlspecialchars($row['employee_number'] ?? '') ?></div>
                </div>
              </div>
            </td>
            <td><span style="font-size:.76rem;padding:2px 8px;border-radius:6px;font-weight:700;background:<?= $tbg ?>;color:<?= $tc ?>"><?= htmlspecialchars($row['leave_type'] ?? '—') ?></span></td>
            <td style="font-size:.81rem"><?= htmlspecialchars($row['start_date'] ?? '—') ?></td>
            <td style="font-size:.81rem"><?= htmlspecialchars($row['end_date'] ?? '—') ?></td>
            <td style="font-size:.82rem;font-weight:700;text-align:center"><?= (int)($row['days'] ?? 0) ?></td>
            <td style="font-size:.8rem;color:#475569;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($row['reason'] ?? '—') ?></td>
            <td><span class="badge badge-<?= $sc ?>"><?= htmlspecialchars($row['status'] ?? '—') ?></span></td>
            <td>
              <div style="display:flex;gap:4px">
                <?php if (($row['status'] ?? '') === 'Pending'): ?>
                  <button onclick="leaveAction(<?= (int)($row['id'] ?? 0) ?>,'approve',this)" style="padding:4px 9px;border:none;border-radius:6px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Approve"><i class="fa-solid fa-check"></i> Approve</button>
                  <button onclick="leaveAction(<?= (int)($row['id'] ?? 0) ?>,'reject',this)" style="padding:4px 9px;border:none;border-radius:6px;background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Reject"><i class="fa-solid fa-xmark"></i> Reject</button>
                <?php else: ?>
                  <span style="font-size:.75rem;color:#94a3b8">—</span>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- New Leave Request Modal -->
<div id="new-leave-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">New Leave Request</div>
      <button onclick="document.getElementById('new-leave-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="leave-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div id="leave-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#991b1b"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Employee *</label><input id="lv-emp" type="text" placeholder="Employee name or ID" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Leave Type *</label><select id="lv-type" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select...</option>
            <option>Annual</option>
            <option>Sick</option>
            <option>Maternity</option>
            <option>Paternity</option>
            <option>Emergency</option>
          </select></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Start Date *</label><input id="lv-start" type="date" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">End Date *</label><input id="lv-end" type="date" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer"></div>
      </div>
      <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Reason</label><textarea id="lv-reason" rows="3" placeholder="Reason for leave request..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea></div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('new-leave-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="lv-submit-btn" onclick="submitLeaveRequest()" style="padding:10px 20px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-paper-plane"></i>Submit Request</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterLeave(q) {
    q = typeof q === 'string' ? q.toLowerCase() : document.getElementById('leave-search').value.toLowerCase();
    var status = document.getElementById('leave-status-filter').value;
    document.querySelectorAll('#leave-tbody tr').forEach(function(tr) {
      var name = tr.dataset.name || '';
      var s = tr.dataset.status || '';
      tr.style.display = ((!q || name.includes(q)) && (!status || s === status)) ? '' : 'none';
    });
  }

  function leaveAction(id, action, btn) {
    var label = action === 'approve' ? 'Approve' : 'Reject';
    if (!confirm(label + ' this leave request?')) return;
    btn.disabled = true;
    var origHtml = btn.innerHTML;
    btn.innerHTML = '<span style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle"></span>';
    // Fixed: POST to flat endpoint with id in body (was wrongly PUT to /leaves/:id/action)
    var base = window.BASE_URL || '';
    fetch(base + '/api/leaves/' + action, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
        },
        body: JSON.stringify({
          id: id,
          leave_id: id
        })
      })
      .then(function(r) {
        return r.json();
      })
      .then(function(d) {
        var tr = btn.closest('tr');
        if (action === 'approve') {
          tr.querySelector('.badge').textContent = 'Approved';
          tr.querySelector('.badge').className = 'badge badge-success';
        } else {
          tr.querySelector('.badge').textContent = 'Rejected';
          tr.querySelector('.badge').className = 'badge badge-danger';
        }
        tr.querySelector('td:last-child').innerHTML = '<span style="font-size:.75rem;color:#94a3b8">Done</span>';
        if (window.ABAY) ABAY.toast('Leave request ' + action + 'd!', 'ok');
      })
      .catch(function() {
        btn.disabled = false;
        btn.innerHTML = origHtml;
        if (window.ABAY) ABAY.toast('Demo: Leave ' + action + 'd (DB offline).', 'info');
        var tr = btn.closest('tr');
        tr.querySelector('.badge').textContent = action === 'approve' ? 'Approved' : 'Rejected';
        tr.querySelector('.badge').className = action === 'approve' ? 'badge badge-success' : 'badge badge-danger';
        tr.querySelector('td:last-child').innerHTML = '<span style="font-size:.75rem;color:#94a3b8">Done</span>';
      });
  }

  function submitLeaveRequest() {
    var emp = document.getElementById('lv-emp').value.trim();
    var type = document.getElementById('lv-type').value;
    var start = document.getElementById('lv-start').value;
    var end = document.getElementById('lv-end').value;
    var reason = document.getElementById('lv-reason').value.trim();
    document.getElementById('leave-err').style.display = 'none';
    if (!emp || !type || !start || !end) {
      document.getElementById('leave-err').textContent = 'Please fill all required fields.';
      document.getElementById('leave-err').style.display = 'block';
      return;
    }
    if (end < start) {
      document.getElementById('leave-err').textContent = 'End date must be after start date.';
      document.getElementById('leave-err').style.display = 'block';
      return;
    }
    ABAY.setBtn('lv-submit-btn', true);
    ABAY.api('/leaves', {
      method: 'POST',
      body: JSON.stringify({
        employee: emp,
        leave_type: type,
        start_date: start,
        end_date: end,
        reason: reason
      })
    }).then(function(d) {
      ABAY.setBtn('lv-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Submit Request');
      if (d && d.success) {
        document.getElementById('leave-ok').textContent = 'Leave request submitted successfully!';
        document.getElementById('leave-ok').style.display = 'block';
        ABAY.toast('Leave request submitted!', 'ok');
        setTimeout(function() {
          document.getElementById('new-leave-modal').style.display = 'none';
          location.reload();
        }, 1500);
      } else {
        document.getElementById('leave-err').textContent = (d && d.message) || 'Submission failed.';
        document.getElementById('leave-err').style.display = 'block';
      }
    }).catch(function() {
      ABAY.setBtn('lv-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Submit Request');
      document.getElementById('leave-ok').textContent = 'Demo: Leave request recorded (Database offline).';
      document.getElementById('leave-ok').style.display = 'block';
      ABAY.toast('Demo leave request recorded.', 'info');
      setTimeout(function() {
        document.getElementById('new-leave-modal').style.display = 'none';
      }, 1500);
    });
  }
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('new-leave-modal').style.display = 'none';
  });
</script>