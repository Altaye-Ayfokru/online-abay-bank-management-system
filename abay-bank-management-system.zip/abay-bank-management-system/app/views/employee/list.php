<?php $pageTitle = 'Employees — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Employee Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Employees</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-light btn-sm" onclick="exportEmpCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <button class="btn btn-primary btn-sm" onclick="document.getElementById('add-emp-modal').style.display='flex'"><i class="fa-solid fa-plus"></i> Add Employee</button>
  </div>
</div>
<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-people-group"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total</div>
      <div class="stat-value" id="emp-stat-total">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Active</div>
      <div class="stat-value" id="emp-stat-active">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-building"></i></div>
    <div class="stat-content">
      <div class="stat-label">Departments</div>
      <div class="stat-value">12</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-calendar-xmark"></i></div>
    <div class="stat-content">
      <div class="stat-label">On Leave</div>
      <div class="stat-value" id="emp-stat-leave">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon purple"><i class="fa-solid fa-user-plus"></i></div>
    <div class="stat-content">
      <div class="stat-label">New This Month</div>
      <div class="stat-value" id="emp-stat-new">—</div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-people-group" style="color:#1B3A5C;margin-right:7px"></i>All Employees</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input type="search" id="emp-search" placeholder="Search employees..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:200px;outline:none" oninput="filterEmps(this.value)">
      <select id="emp-dept-filter" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer" onchange="filterEmps()">
        <option value="">All Departments</option>
        <option>Finance</option>
        <option>Operations</option>
        <option>IT</option>
        <option>HR</option>
        <option>Loans</option>
        <option>Customer Service</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Employee ID</th>
          <th>Name</th>
          <th>Department</th>
          <th>Position</th>
          <th>Branch</th>
          <th>Phone</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="emp-tbody">
        <tr>
          <td colspan="8" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
            <div style="margin-top:8px;font-size:.84rem">Loading employees...</div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="emp-info">Loading...</div>
    <div id="emp-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>

<!-- Add Employee Modal -->
<div id="add-emp-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:560px;box-shadow:0 24px 64px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;position:sticky;top:0;background:#fff;z-index:1;border-radius:18px 18px 0 0">
      <div>
        <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Add New Employee</div>
        <div style="font-size:.74rem;color:#94a3b8;margin-top:2px">Staff registration form</div>
      </div>
      <button onclick="document.getElementById('add-emp-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="emp-add-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px 14px;margin-bottom:14px;font-size:.84rem;color:#065f46"><i class="fa-solid fa-circle-check" style="margin-right:6px"></i><span id="emp-add-ok-msg"></span></div>
      <div id="emp-add-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;margin-bottom:14px;font-size:.84rem;color:#991b1b"><i class="fa-solid fa-circle-xmark" style="margin-right:6px"></i><span id="emp-add-err-msg"></span></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">First Name *</label><input id="emp-fn" type="text" placeholder="First name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Last Name *</label><input id="emp-ln" type="text" placeholder="Last name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Phone *</label><input id="emp-phone" type="tel" placeholder="+251 912 345 678" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Email</label><input id="emp-email" type="email" placeholder="email@abaybank.com" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Department *</label><select id="emp-dept" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select...</option>
            <option>Finance</option>
            <option>Operations</option>
            <option>IT</option>
            <option>HR</option>
            <option>Loans</option>
            <option>Customer Service</option>
          </select></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Position *</label><input id="emp-pos" type="text" placeholder="Job title" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Branch</label><select id="emp-branch" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select...</option><?php foreach ($branches ?: [['branch_name' => 'Head Office'], ['branch_name' => 'Bole Branch'], ['branch_name' => 'Kirkos Branch'], ['branch_name' => 'Piassa Branch'], ['branch_name' => 'Arada Branch'], ['branch_name' => 'Alem Ketema Branch'], ['branch_name' => 'Bahir Dar Branch'], ['branch_name' => 'Hawassa Branch'], ['branch_name' => 'Dire Dawa Branch'], ['branch_name' => 'Mekelle Branch']] as $br): ?><option><?= htmlspecialchars($br['branch_name'] ?? $br['name'] ?? '') ?></option><?php endforeach; ?>
          </select></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Basic Salary (ETB)</label><input id="emp-salary" type="number" placeholder="0.00" min="0" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">National ID</label><input id="emp-nid" type="text" placeholder="ET12345678" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Join Date</label><input id="emp-join" type="date" value="<?= date('Y-m-d') ?>" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Gender</label>
          <select id="emp-gender" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff">
            <option value="">Select...</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Employment Type</label>
          <select id="emp-type" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff">
            <option value="Permanent">Permanent</option>
            <option value="Contract">Contract</option>
            <option value="Probation">Probation</option>
            <option value="Part-time">Part-time</option>
          </select>
        </div>
      </div>
      <!-- Photo upload -->
      <div style="margin-bottom:12px">
        <label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Employee Photo (optional)</label>
        <div id="emp-photo-wrap" onclick="document.getElementById('emp-photo').click()"
          style="border:2px dashed #e2e8f0;border-radius:10px;padding:18px;text-align:center;cursor:pointer;transition:.2s"
          onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'">
          <i class="fa-solid fa-camera" style="font-size:1.4rem;color:#94a3b8;display:block;margin-bottom:6px"></i>
          <div style="font-size:.8rem;color:#94a3b8" id="emp-photo-label">Click to select photo (JPG, PNG — max 5 MB)</div>
          <img id="emp-photo-preview" style="display:none;max-width:80px;max-height:80px;margin:8px auto 0;border-radius:50%;object-fit:cover">
        </div>
        <input type="file" id="emp-photo" accept="image/jpeg,image/png,image/webp" style="display:none"
          onchange="previewEmpPhoto(this)">
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end;position:sticky;bottom:0;background:#fff;border-radius:0 0 18px 18px">
      <button onclick="document.getElementById('add-emp-modal').style.display='none'" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.86rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="emp-add-btn" onclick="submitAddEmployee()" style="padding:10px 22px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.86rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-user-plus"></i> Add Employee</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allEmps = [],
    _filtEmps = [],
    _ePage = 1,
    _ePer = 12;
  var demoEmps = [{
      id: 'EMP001',
      employee_number: 'EMP20260001',
      first_name: 'Yohannes',
      last_name: 'Bekele',
      department: 'Operations',
      position: 'Branch Manager',
      branch_name: 'Bole',
      phone: '0911-111-001',
      status: 'Active',
      created_at: '2022-01-15'
    },
    {
      id: 'EMP002',
      employee_number: 'EMP20260002',
      first_name: 'Tigist',
      last_name: 'Haile',
      department: 'Customer Service',
      position: 'Senior Teller',
      branch_name: 'Kirkos',
      phone: '0922-222-002',
      status: 'Active',
      created_at: '2022-03-20'
    },
    {
      id: 'EMP003',
      employee_number: 'EMP20260003',
      first_name: 'Solomon',
      last_name: 'Girma',
      department: 'Loans',
      position: 'Loan Officer',
      branch_name: 'Bahir Dar',
      phone: '0933-333-003',
      status: 'Active',
      created_at: '2022-06-10'
    },
    {
      id: 'EMP004',
      employee_number: 'EMP20260004',
      first_name: 'Hanna',
      last_name: 'Tadesse',
      department: 'IT',
      position: 'System Administrator',
      branch_name: 'Head Office',
      phone: '0944-444-004',
      status: 'Active',
      created_at: '2023-01-05'
    },
    {
      id: 'EMP005',
      employee_number: 'EMP20260005',
      first_name: 'Dawit',
      last_name: 'Alemu',
      department: 'Finance',
      position: 'Accountant',
      branch_name: 'Arada',
      phone: '0955-555-005',
      status: 'Active',
      created_at: '2023-04-18'
    },
    {
      id: 'EMP006',
      employee_number: 'EMP20260006',
      first_name: 'Meron',
      last_name: 'Getnet',
      department: 'HR',
      position: 'HR Officer',
      branch_name: 'Head Office',
      phone: '0966-666-006',
      status: 'On Leave',
      created_at: '2023-07-22'
    },
  ];

  function loadEmps() {
    var base = window.BASE_URL || '';
    var url = base + '/api/employees?per_page=200';
    fetch(url, {
        credentials: 'include',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
        }
      })
      .then(function(r) {
        return r.json();
      })
      .then(function(d) {
        var rows = (d && d.success && d.data && d.data.length) ? d.data : demoEmps;
        _allEmps = rows;
        updateEmpStats(rows);
        filterEmps();
      })
      .catch(function() {
        _allEmps = demoEmps;
        updateEmpStats(demoEmps);
        filterEmps();
      });
  }

  function updateEmpStats(rows) {
    var total = rows.length,
      active = 0,
      leave = 0,
      newThisMonth = 0;
    var now = new Date();
    var thisMonth = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
    rows.forEach(function(r) {
      if (r.status === 'Active') active++;
      if (r.status === 'On Leave') leave++;
      if ((r.created_at || '').startsWith(thisMonth)) newThisMonth++;
    });
    var fmt = function(n) {
      return window.ABAY ? ABAY.fmtNum(n) : String(n);
    };
    var t = document.getElementById('emp-stat-total');
    if (t) t.textContent = fmt(total);
    var a = document.getElementById('emp-stat-active');
    if (a) a.textContent = fmt(active);
    var l = document.getElementById('emp-stat-leave');
    if (l) l.textContent = fmt(leave);
    var nm = document.getElementById('emp-stat-new');
    if (nm) nm.textContent = fmt(newThisMonth);
  }

  function filterEmps(q) {
    var search = (typeof q === 'string' ? q : document.getElementById('emp-search').value).toLowerCase();
    var dept = document.getElementById('emp-dept-filter').value;
    _filtEmps = _allEmps.filter(function(e) {
      var name = ((e.first_name || '') + ' ' + (e.last_name || '')).toLowerCase();
      return (!search || name.includes(search) || (e.employee_number || '').toLowerCase().includes(search)) && (!dept || e.department === dept);
    });
    _ePage = 1;
    renderEmps();
  }

  function renderEmps() {
    var tbody = document.getElementById('emp-tbody');
    var total = _filtEmps.length;
    var start = (_ePage - 1) * _ePer;
    var slice = _filtEmps.slice(start, start + _ePer);
    if (!total) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">No employees found</td></tr>';
      return;
    }
    tbody.innerHTML = slice.map(function(e) {
      var name = (e.first_name || '') + ' ' + (e.last_name || '');
      var ini = ((e.first_name || '?')[0] + ((e.last_name || '?')[0])).toUpperCase();
      var dept = e.department || e.dept_name || '—';
      var br = e.branch_name || e.branch || '—';
      var eid = e.id || e.employee_number || 0;
      var eJson = encodeURIComponent(JSON.stringify(e));
      return '<tr>' +
        '<td><span style="font-family:monospace;font-size:.75rem;color:#475569">' + (e.employee_number || e.id || '—') + '</span></td>' +
        '<td><div style="display:flex;align-items:center;gap:8px">' +
        '<div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;flex-shrink:0">' + ini + '</div>' +
        '<span style="font-size:.83rem;font-weight:600;color:#1e293b">' + name + '</span>' +
        '</div></td>' +
        '<td><span style="font-size:.78rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600">' + dept + '</span></td>' +
        '<td style="font-size:.82rem;color:#475569">' + (e.position || '—') + '</td>' +
        '<td style="font-size:.82rem;color:#475569">' + br + '</td>' +
        '<td style="font-size:.82rem">' + (e.phone || '—') + '</td>' +
        '<td>' + (window.ABAY ? ABAY.badge(e.status || 'Active') : '<span>' + (e.status || 'Active') + '</span>') + '</td>' +
        '<td><div style="display:flex;gap:4px">' +
        '<a href="<?= APP_URL ?>/employees/attendance" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Attendance"><i class="fa-solid fa-calendar-check"></i></a>' +
        '<a href="<?= APP_URL ?>/employees/payroll" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem" title="Payroll"><i class="fa-solid fa-receipt"></i></a>' +
        '<button onclick="editEmployee(decodeURIComponent(\'' + eJson + '\'))" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem;color:#007A8A" title="Edit"><i class="fa-solid fa-pen"></i></button>' +
        '<button onclick="confirmDeleteEmployee(' + JSON.stringify(eid) + ',' + JSON.stringify(name) + ')" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.73rem;color:#dc2626" title="Delete"><i class="fa-solid fa-trash"></i></button>' +
        '</div></td>' +
        '</tr>';
    }).join('');
    document.getElementById('emp-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _ePer, total) + ' of ' + total + ' employees';
    var pages = Math.ceil(total / _ePer);
    var pg = document.getElementById('emp-pagination');
    var html = '';
    for (var i = 1; i <= pages; i++) {
      html += '<button onclick="_ePage=' + i + ';renderEmps()" style="width:30px;height:30px;border:1.5px solid ' +
        (_ePage === i ? '#007A8A' : '#e2e8f0') +
        ';background:' + (_ePage === i ? '#007A8A' : '#fff') +
        ';color:' + (_ePage === i ? '#fff' : '#475569') +
        ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">' + i + '</button>';
    }
    pg.innerHTML = html;
  } // end renderEmps

  function submitAddEmployee() {
    var fn = document.getElementById('emp-fn').value.trim();
    var ln = document.getElementById('emp-ln').value.trim();
    var phone = document.getElementById('emp-phone').value.trim();
    var dept = document.getElementById('emp-dept').value;
    var pos = document.getElementById('emp-pos').value.trim();
    var email = document.getElementById('emp-email').value.trim();
    var branch = document.getElementById('emp-branch').value;
    var salary = parseFloat(document.getElementById('emp-salary').value) || 0;
    var nid = (document.getElementById('emp-nid') || {}).value || '';
    var joinDt = (document.getElementById('emp-join') || {}).value || new Date().toISOString().slice(0, 10);
    var gender = (document.getElementById('emp-gender') || {}).value || '';
    var empType = (document.getElementById('emp-type') || {}).value || 'Permanent';

    document.getElementById('emp-add-err').style.display = 'none';
    document.getElementById('emp-add-ok').style.display = 'none';

    if (!fn || !ln) {
      showEmpErr('Full name is required.');
      return;
    }
    if (!phone) {
      showEmpErr('Phone is required.');
      return;
    }
    if (!dept || !pos) {
      showEmpErr('Department and position are required.');
      return;
    }

    /* Use ABAY if ready, else direct fetch */
    var btn = document.getElementById('emp-add-btn');
    btn.disabled = true;
    btn.innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.35);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle"></span> Adding…';

    var payload = {
      first_name: fn,
      last_name: ln,
      phone: phone,
      email: email,
      department: dept,
      position: pos,
      branch: branch,
      basic_salary: salary,
      national_id: nid,
      join_date: joinDt,
      gender: gender,
      employment_type: empType
    };

    var base = window.BASE_URL || '';
    var url = base + '/api/employees';

    fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
        },
        body: JSON.stringify(payload)
      })
      .then(function(r) {
        if (!r.ok && r.status !== 200) {
          return r.json().catch(function() {
            return {
              success: false,
              message: 'Server error ' + r.status
            };
          });
        }
        return r.json();
      })
      .then(function(d) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Add Employee';

        if (d && d.success) {
          var empNo = (d.data && d.data.employee_number) || '';
          document.getElementById('emp-add-ok-msg').textContent = fn + ' ' + ln + ' added! ID: ' + empNo;
          document.getElementById('emp-add-ok').style.display = 'block';
          if (window.ABAY) ABAY.toast(fn + ' ' + ln + ' added successfully!', 'ok');

          /* Upload photo if selected */
          var photoInput = document.getElementById('emp-photo');
          var empId = d.data && d.data.employee_id;
          if (photoInput && photoInput.files && photoInput.files[0] && empId) {
            var fd = new FormData();
            fd.append('photo', photoInput.files[0]);
            fd.append('employee_id', empId);
            fetch(base + '/api/upload/employee-photo', {
                method: 'POST',
                credentials: 'include',
                headers: {
                  'X-Requested-With': 'XMLHttpRequest',
                  'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
                },
                body: fd
              }).then(function(r) {
                return r.json();
              })
              .then(function(pr) {
                if (pr && pr.success && window.ABAY) ABAY.toast('Photo uploaded!', 'success');
              }).catch(function() {});
          }

          setTimeout(function() {
            document.getElementById('add-emp-modal').style.display = 'none';
            /* Clear form */
            ['emp-fn', 'emp-ln', 'emp-phone', 'emp-email', 'emp-pos', 'emp-salary', 'emp-nid'].forEach(function(id) {
              var el = document.getElementById(id);
              if (el) el.value = '';
            });
            document.getElementById('emp-add-ok').style.display = 'none';
            document.getElementById('emp-add-err').style.display = 'none';
            loadEmps();
          }, 1500);
        } else {
          showEmpErr((d && d.message) || 'Failed to add employee.');
        }
      })
      .catch(function(err) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Add Employee';
        /* Demo fallback — DB offline */
        document.getElementById('emp-add-ok-msg').textContent = 'Demo: ' + fn + ' ' + ln + ' recorded (database offline).';
        document.getElementById('emp-add-ok').style.display = 'block';
        if (window.ABAY) ABAY.toast('Demo employee added.', 'info');
        /* Still add to local table so user can see the row */
        var demoEmp = {
          id: 'NEW-' + Date.now(),
          employee_number: 'EMP-' + new Date().getFullYear() + '-' + Math.floor(Math.random() * 9000 + 1000),
          first_name: fn,
          last_name: ln,
          phone: phone,
          email: email,
          department: dept,
          position: pos,
          branch_name: branch,
          status: 'Active',
          created_at: new Date().toISOString().slice(0, 10)
        };
        _allEmps.unshift(demoEmp);
        updateEmpStats(_allEmps);
        filterEmps();
        setTimeout(function() {
          document.getElementById('add-emp-modal').style.display = 'none';
          document.getElementById('emp-add-ok').style.display = 'none';
        }, 1600);
      });
  }

  function showEmpErr(msg) {
    document.getElementById('emp-add-err-msg').textContent = msg;
    document.getElementById('emp-add-err').style.display = 'block';
  }

  function exportEmpCSV() {
    var rows = [
      ['ID', 'Name', 'Department', 'Position', 'Branch', 'Phone', 'Status']
    ].concat(_filtEmps.map(function(e) {
      return [e.employee_number || e.id, e.first_name + ' ' + e.last_name, e.department, e.position, e.branch_name || '', e.phone || '', e.status];
    }));
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'employees.csv';
    a.click();
  }
  document.addEventListener('DOMContentLoaded', function() {
    loadEmps();
    // Load branches and departments when modal opens
    document.querySelector('[onclick*="add-emp-modal"]')?.addEventListener('click', loadModalDropdowns);
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('add-emp-modal').style.display = 'none';
  });

  function loadModalDropdowns() {
    ABAY.api('/branches').then(function(d) {
      var sel = document.getElementById('emp-branch');
      if (!sel || !d || !d.data || !d.data.length) return;
      sel.innerHTML = '<option value="">Select branch...</option>';
      d.data.forEach(function(b) {
        sel.innerHTML += '<option value="' + (b.branch_name || b.name || '') + '">' + (b.branch_name || b.name || '') + '</option>';
      });
    }).catch(function() {});
    ABAY.api('/departments').then(function(d) {
      var sel = document.getElementById('emp-dept');
      if (!sel || !d || !d.data || !d.data.length) return;
      sel.innerHTML = '<option value="">Select department...</option>';
      d.data.forEach(function(dep) {
        sel.innerHTML += '<option value="' + dep.name + '">' + dep.name + '</option>';
      });
    }).catch(function() {});
  }

  function previewEmpPhoto(input) {
    if (!input.files || !input.files[0]) return;
    var file = input.files[0];
    if (file.size > 5 * 1024 * 1024) {
      ABAY.toast('Image must be under 5 MB', 'err');
      input.value = '';
      return;
    }
    var reader = new FileReader();
    reader.onload = function(e) {
      var prev = document.getElementById('emp-photo-preview');
      var lbl = document.getElementById('emp-photo-label');
      if (prev) {
        prev.src = e.target.result;
        prev.style.display = 'block';
      }
      if (lbl) lbl.textContent = file.name;
    };
    reader.readAsDataURL(file);
  }

  /* ── EDIT EMPLOYEE ─────────────────────────────────────────── */
  function editEmployee(eOrJson) {
    var e = (typeof eOrJson === 'string') ? JSON.parse(decodeURIComponent(eOrJson)) : eOrJson;
    document.getElementById('edit-emp-id').value = e.id || '';
    document.getElementById('edit-emp-fn').value = e.first_name || '';
    document.getElementById('edit-emp-ln').value = e.last_name || '';
    document.getElementById('edit-emp-phone').value = e.phone || '';
    document.getElementById('edit-emp-email').value = e.email || '';
    document.getElementById('edit-emp-dept').value = e.department || e.dept_name || '';
    document.getElementById('edit-emp-pos').value = e.position || '';
    document.getElementById('edit-emp-salary').value = e.basic_salary || '';
    document.getElementById('edit-emp-status').value = e.status || 'Active';
    document.getElementById('edit-emp-ok').style.display = 'none';
    document.getElementById('edit-emp-err').style.display = 'none';
    document.getElementById('edit-emp-modal').style.display = 'flex';
  }

  function submitEditEmployee() {
    var id = document.getElementById('edit-emp-id').value;
    var fn = document.getElementById('edit-emp-fn').value.trim();
    var ln = document.getElementById('edit-emp-ln').value.trim();
    var phone = document.getElementById('edit-emp-phone').value.trim();
    var email = document.getElementById('edit-emp-email').value.trim();
    var dept = document.getElementById('edit-emp-dept').value;
    var pos = document.getElementById('edit-emp-pos').value.trim();
    var salary = parseFloat(document.getElementById('edit-emp-salary').value) || 0;
    var status = document.getElementById('edit-emp-status').value;

    if (!fn || !ln) {
      showEmpEditErr('Name is required.');
      return;
    }
    if (!phone) {
      showEmpEditErr('Phone is required.');
      return;
    }

    ABAY.setBtn('edit-emp-btn', true);
    ABAY.api('/employees/update', {
      method: 'POST',
      body: JSON.stringify({
        id: id,
        first_name: fn,
        last_name: ln,
        phone: phone,
        email: email,
        department: dept,
        position: pos,
        basic_salary: salary,
        status: status
      })
    }).then(function(d) {
      ABAY.setBtn('edit-emp-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
      if (d && d.success) {
        document.getElementById('edit-emp-ok').textContent = fn + ' ' + ln + ' updated!';
        document.getElementById('edit-emp-ok').style.display = 'block';
        ABAY.toast(fn + ' ' + ln + ' updated!', 'ok');
        setTimeout(function() {
          document.getElementById('edit-emp-modal').style.display = 'none';
          loadEmps();
        }, 1400);
      } else {
        showEmpEditErr((d && d.message) || 'Update failed.');
      }
    }).catch(function() {
      ABAY.setBtn('edit-emp-btn', false, '<i class="fa-solid fa-save"></i> Save Changes');
      document.getElementById('edit-emp-ok').textContent = 'Demo: ' + fn + ' ' + ln + ' updated (DB offline).';
      document.getElementById('edit-emp-ok').style.display = 'block';
      ABAY.toast('Demo: Employee updated.', 'info');
      setTimeout(function() {
        document.getElementById('edit-emp-modal').style.display = 'none';
        loadEmps();
      }, 1400);
    });
  }

  function confirmDeleteEmployee(id, name) {
    if (!confirm('Deactivate employee "' + name + '"?\nThey will be set to Inactive.')) return;
    ABAY.api('/employees/delete', {
      method: 'POST',
      body: JSON.stringify({
        id: id
      })
    }).then(function(d) {
      if (d && d.success) {
        ABAY.toast(name + ' deactivated.', 'ok');
        _allEmps = _allEmps.filter(function(e) {
          return e.id != id;
        });
        filterEmps();
      } else {
        ABAY.toast((d && d.message) || 'Delete failed.', 'err');
      }
    }).catch(function() {
      ABAY.toast('Demo: ' + name + ' deleted (DB offline).', 'info');
      _allEmps = _allEmps.filter(function(e) {
        return e.id != id;
      });
      filterEmps();
    });
  }

  function showEmpEditErr(msg) {
    var el = document.getElementById('edit-emp-err');
    el.textContent = msg;
    el.style.display = 'block';
  }

  document.getElementById('edit-emp-modal').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      var m = document.getElementById('edit-emp-modal');
      if (m && m.style.display === 'flex') m.style.display = 'none';
    }
  });
</script>

<!-- EDIT EMPLOYEE MODAL -->
<div id="edit-emp-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:520px;box-shadow:0 24px 64px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;position:sticky;top:0;background:#fff;z-index:1;border-radius:18px 18px 0 0">
      <div>
        <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Edit Employee</div>
        <div style="font-size:.74rem;color:#94a3b8;margin-top:2px">Update employee information</div>
      </div>
      <button onclick="document.getElementById('edit-emp-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <input type="hidden" id="edit-emp-id">
      <div id="edit-emp-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div id="edit-emp-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.84rem;color:#991b1b"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">First Name *</label><input id="edit-emp-fn" type="text" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Last Name *</label><input id="edit-emp-ln" type="text" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Phone *</label><input id="edit-emp-phone" type="tel" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Email</label><input id="edit-emp-email" type="email" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Department</label>
          <select id="edit-emp-dept" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff">
            <option value="">Select…</option>
            <?php foreach (['Finance', 'Operations', 'IT', 'HR', 'Loans', 'Customer Service', 'Audit', 'Legal', 'Marketing', 'Security'] as $d): ?><option><?= $d ?></option><?php endforeach; ?>
          </select>
        </div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Position</label><input id="edit-emp-pos" type="text" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Basic Salary (ETB)</label><input id="edit-emp-salary" type="number" min="0" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Status</label>
          <select id="edit-emp-status" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff">
            <option>Active</option>
            <option>Inactive</option>
            <option>On Leave</option>
            <option>Suspended</option>
          </select>
        </div>
      </div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end;position:sticky;bottom:0;background:#fff;border-radius:0 0 18px 18px">
      <button onclick="document.getElementById('edit-emp-modal').style.display='none'" style="padding:10px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.86rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="edit-emp-btn" onclick="submitEditEmployee()" style="padding:10px 22px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.86rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-save"></i> Save Changes</button>
    </div>
  </div>
</div>