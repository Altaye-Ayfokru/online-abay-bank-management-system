﻿<?php
$pageTitle = 'Payroll — ' . APP_NAME;

// Build demo data if DB returned nothing
$payrollRows = $payroll ?? [];
if (empty($payrollRows)) {
  $payrollRows = [
    ['id' => 1, 'employee_number' => 'EMP001', 'name' => 'Yohannes Bekele', 'department' => 'Operations', 'position' => 'Branch Manager',  'basic_salary' => 25000, 'allowances' => 5000, 'deductions' => 4500, 'tax' => 3750, 'net_salary' => 21750, 'status' => 'Processed', 'pay_month' => date('Y-m')],
    ['id' => 2, 'employee_number' => 'EMP002', 'name' => 'Tigist Haile',   'department' => 'Customer Service', 'position' => 'Senior Teller', 'basic_salary' => 18000, 'allowances' => 3500, 'deductions' => 3100, 'tax' => 2700, 'net_salary' => 15700, 'status' => 'Processed', 'pay_month' => date('Y-m')],
    ['id' => 3, 'employee_number' => 'EMP003', 'name' => 'Solomon Girma',  'department' => 'Loans', 'position' => 'Loan Officer',     'basic_salary' => 20000, 'allowances' => 4000, 'deductions' => 3600, 'tax' => 3000, 'net_salary' => 17400, 'status' => 'Processed', 'pay_month' => date('Y-m')],
    ['id' => 4, 'employee_number' => 'EMP004', 'name' => 'Hanna Tadesse',  'department' => 'IT',  'position' => 'Sys Admin',         'basic_salary' => 22000, 'allowances' => 4500, 'deductions' => 3900, 'tax' => 3300, 'net_salary' => 19300, 'status' => 'Pending', 'pay_month' => date('Y-m')],
    ['id' => 5, 'employee_number' => 'EMP005', 'name' => 'Dawit Alemu',    'department' => 'Finance', 'position' => 'Accountant',    'basic_salary' => 16000, 'allowances' => 3000, 'deductions' => 2800, 'tax' => 2400, 'net_salary' => 13800, 'status' => 'Processed', 'pay_month' => date('Y-m')],
    ['id' => 6, 'employee_number' => 'EMP006', 'name' => 'Meron Getnet',   'department' => 'HR',  'position' => 'HR Officer',        'basic_salary' => 15000, 'allowances' => 2800, 'deductions' => 2600, 'tax' => 2250, 'net_salary' => 12950, 'status' => 'Pending', 'pay_month' => date('Y-m')],
  ];
}

$totalGross   = array_sum(array_map(fn($r) => ($r['basic_salary'] ?? 0) + ($r['allowances'] ?? 0), $payrollRows));
$totalNet     = array_sum(array_column($payrollRows, 'net_salary'));
$totalTax     = array_sum(array_column($payrollRows, 'tax'));
$totalDeduct  = array_sum(array_column($payrollRows, 'deductions'));
$pendingCount = count(array_filter($payrollRows, fn($r) => ($r['status'] ?? '') === 'Pending'));

$months = [];
for ($i = 0; $i < 6; $i++) {
  $months[] = date('F Y', strtotime("-$i months"));
}
?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Payroll Management</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span>
      <a href="<?= APP_URL ?>/employees">Employees</a><span class="sep">/</span><span>Payroll</span>
    </div>
  </div>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <select id="pay-month-sel" onchange="filterMonth(this.value)" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
      <?php foreach ($months as $m): ?>
        <option value="<?= htmlspecialchars($m) ?>" <?= $m === $months[0] ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-light btn-sm" onclick="exportPayrollCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <button id="process-all-btn" class="btn btn-primary btn-sm" onclick="processAllPayroll()"><i class="fa-solid fa-money-bill-wave"></i> Process All</button>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-coins"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Gross</div>
      <div class="stat-value" id="stat-gross"><?= 'ETB ' . number_format($totalGross) ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-wallet"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Net Pay</div>
      <div class="stat-value" id="stat-net"><?= 'ETB ' . number_format($totalNet) ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-receipt"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Tax</div>
      <div class="stat-value" id="stat-tax"><?= 'ETB ' . number_format($totalTax) ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Pending</div>
      <div class="stat-value" id="stat-pending"><?= $pendingCount ?></div>
    </div>
  </div>
</div>

<!-- Payslip Preview Modal -->
<div id="payslip-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:520px;box-shadow:0 24px 64px rgba(0,0,0,.28);max-height:90vh;overflow-y:auto">
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);padding:20px 24px;border-radius:18px 18px 0 0;color:#fff">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:.7rem;opacity:.65;font-weight:700;letter-spacing:1px;text-transform:uppercase">Abay Bank S.C.</div>
          <div style="font-size:1.1rem;font-weight:800;margin-top:3px">Pay Slip</div>
        </div>
        <button onclick="document.getElementById('payslip-modal').style.display='none'" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:.9rem">✕</button>
      </div>
    </div>
    <div style="padding:20px 24px" id="payslip-body"></div>
    <div style="padding:14px 24px 20px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="window.print()" style="padding:9px 18px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit"><i class="fa-solid fa-print" style="margin-right:5px"></i>Print</button>
      <button onclick="document.getElementById('payslip-modal').style.display='none'" style="padding:9px 18px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit">Close</button>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:7px"></i>Payroll — <span id="pay-month-title"><?= $months[0] ?></span></h3>
    <input type="search" id="pay-search" placeholder="Search employee..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:200px;outline:none" oninput="filterPayroll(this.value)">
  </div>
  <div class="table-responsive">
    <table class="data-table" id="payroll-table">
      <thead>
        <tr>
          <th>Employee ID</th>
          <th>Name</th>
          <th>Department</th>
          <th>Basic Salary</th>
          <th>Allowances</th>
          <th>Deductions</th>
          <th>Tax</th>
          <th>Net Salary</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="payroll-table-body">
        <?php foreach ($payrollRows as $row): ?>
          <?php
          $gross = ($row['basic_salary'] ?? 0) + ($row['allowances'] ?? 0);
          $statusColor = ($row['status'] ?? '') === 'Processed' ? 'success' : (($row['status'] ?? '') === 'Pending' ? 'warning' : 'info');
          ?>
          <tr data-name="<?= strtolower(htmlspecialchars($row['name'] ?? '')) ?>">
            <td><span style="font-family:monospace;font-size:.75rem;color:#475569"><?= htmlspecialchars($row['employee_number'] ?? '—') ?></span></td>
            <td style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($row['name'] ?? '—') ?></td>
            <td><span style="font-size:.77rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600"><?= htmlspecialchars($row['department'] ?? '—') ?></span></td>
            <td style="font-size:.82rem;font-weight:600">ETB <?= number_format($row['basic_salary'] ?? 0) ?></td>
            <td style="font-size:.82rem;color:#059669">ETB <?= number_format($row['allowances'] ?? 0) ?></td>
            <td style="font-size:.82rem;color:#ef4444">ETB <?= number_format($row['deductions'] ?? 0) ?></td>
            <td style="font-size:.82rem;color:#d97706">ETB <?= number_format($row['tax'] ?? 0) ?></td>
            <td style="font-size:.84rem;font-weight:800;color:#1B3A5C">ETB <?= number_format($row['net_salary'] ?? 0) ?></td>
            <td><span class="badge badge-<?= $statusColor ?>"><?= htmlspecialchars($row['status'] ?? '—') ?></span></td>
            <td>
              <div style="display:flex;gap:4px">
                <button onclick="viewPayslip(<?= htmlspecialchars(json_encode($row)) ?>)" style="padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="View Payslip"><i class="fa-solid fa-file-invoice" style="color:#007A8A"></i></button>
                <?php if (($row['status'] ?? '') === 'Pending'): ?>
                  <button onclick="processPayroll(<?= (int)($row['id'] ?? 0) ?>, this)" style="padding:4px 8px;border:none;border-radius:6px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Process Payment"><i class="fa-solid fa-money-bill-wave"></i></button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div style="padding:12px 20px;border-top:1px solid #f1f5f9;background:#f8fafc;border-radius:0 0 14px 14px">
    <div style="display:flex;justify-content:flex-end;gap:32px;font-size:.84rem">
      <span style="color:#94a3b8">Gross: <strong style="color:#1e293b">ETB <?= number_format($totalGross) ?></strong></span>
      <span style="color:#94a3b8">Tax: <strong style="color:#d97706">ETB <?= number_format($totalTax) ?></strong></span>
      <span style="color:#94a3b8">Total Deductions: <strong style="color:#ef4444">ETB <?= number_format($totalDeduct) ?></strong></span>
      <span style="color:#94a3b8">Net Payable: <strong style="color:#1B3A5C;font-size:.92rem">ETB <?= number_format($totalNet) ?></strong></span>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _payData = <?= json_encode($payrollRows) ?>;

  function filterPayroll(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#payroll-table-body tr').forEach(function(tr) {
      var name = tr.dataset.name || '';
      tr.style.display = (!q || name.includes(q)) ? '' : 'none';
    });
  }

  function viewPayslip(row) {
    var gross = (row.basic_salary || 0) + (row.allowances || 0);
    document.getElementById('payslip-body').innerHTML =
      '<div style="display:grid;gap:8px">' +
      '<div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.84rem;font-weight:700;color:#1B3A5C">' + (row.name || '—') + '</span><span style="font-size:.78rem;color:#94a3b8">' + (row.pay_month || '') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#64748b">Employee ID</span><span style="font-size:.81rem;font-weight:600;font-family:monospace">' + (row.employee_number || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#64748b">Department</span><span style="font-size:.81rem;font-weight:600">' + (row.department || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#64748b">Position</span><span style="font-size:.81rem;font-weight:600">' + (row.position || '—') + '</span></div>' +
      '<div style="margin-top:8px;background:#f8fafc;border-radius:10px;padding:14px">' +
      '<div style="font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px">Earnings</div>' +
      '<div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="font-size:.81rem;color:#475569">Basic Salary</span><span style="font-size:.81rem;font-weight:600;color:#059669">ETB ' + Number(row.basic_salary || 0).toLocaleString() + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="font-size:.81rem;color:#475569">Allowances</span><span style="font-size:.81rem;font-weight:600;color:#059669">ETB ' + Number(row.allowances || 0).toLocaleString() + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding-top:8px;border-top:1px solid #e2e8f0"><span style="font-size:.81rem;font-weight:700">Gross</span><span style="font-size:.81rem;font-weight:700;color:#1B3A5C">ETB ' + Number(gross).toLocaleString() + '</span></div>' +
      '</div>' +
      '<div style="background:#fff5f5;border-radius:10px;padding:14px">' +
      '<div style="font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px">Deductions</div>' +
      '<div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="font-size:.81rem;color:#475569">Income Tax</span><span style="font-size:.81rem;font-weight:600;color:#ef4444">ETB ' + Number(row.tax || 0).toLocaleString() + '</span></div>' +
      '<div style="display:flex;justify-content:space-between"><span style="font-size:.81rem;color:#475569">Other Deductions</span><span style="font-size:.81rem;font-weight:600;color:#ef4444">ETB ' + Number(row.deductions || 0).toLocaleString() + '</span></div>' +
      '</div>' +
      '<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:10px;padding:14px;text-align:center">' +
      '<div style="font-size:.68rem;color:rgba(255,255,255,.65);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Net Salary</div>' +
      '<div style="font-size:1.6rem;font-weight:900;color:#fff">ETB ' + Number(row.net_salary || 0).toLocaleString() + '</div>' +
      '</div>' +
      '</div>';
    document.getElementById('payslip-modal').style.display = 'flex';
  }

  function processPayroll(id, btn) {
    if (!confirm('Process payroll for this employee?')) return;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
    ABAY.api('/payroll/process', {
      method: 'POST',
      body: JSON.stringify({
        employee_payroll_id: id
      })
    }).then(function(d) {
      btn.closest('tr').querySelector('.badge').textContent = 'Processed';
      btn.closest('tr').querySelector('.badge').className = 'badge badge-success';
      btn.style.display = 'none';
      ABAY.toast('Payroll processed successfully!', 'ok');
    }).catch(function() {
      btn.disabled = false;
      btn.innerHTML = '<i class="fa-solid fa-money-bill-wave"></i>';
      ABAY.toast('Demo: Payroll processed (Database offline).', 'info');
      btn.closest('tr').querySelector('.badge').textContent = 'Processed';
      btn.closest('tr').querySelector('.badge').className = 'badge badge-success';
      btn.style.display = 'none';
    });
  }

  function processAllPayroll() {
    var pending = document.querySelectorAll('#payroll-table-body tr td:nth-child(9) .badge');
    var count = 0;
    pending.forEach(function(b) {
      if (b.textContent === 'Pending') count++;
    });
    if (!count) {
      ABAY.toast('No pending payroll to process.', 'info');
      return;
    }
    if (!confirm('Process payroll for ' + count + ' pending employee(s)?')) return;
    ABAY.setBtn('process-all-btn', true);
    ABAY.api('/payroll/process-all', {
      method: 'POST',
      body: JSON.stringify({
        month: document.getElementById('pay-month-sel').value
      })
    }).then(function(d) {
      ABAY.setBtn('process-all-btn', false, '<i class="fa-solid fa-money-bill-wave"></i> Process All');
      ABAY.toast('All payroll processed!', 'ok');
      document.querySelectorAll('#payroll-table-body tr td:nth-child(9) .badge').forEach(function(b) {
        b.textContent = 'Processed';
        b.className = 'badge badge-success';
      });
      document.querySelectorAll('#payroll-table-body tr td:nth-child(10) button:last-child').forEach(function(b) {
        b.style.display = 'none';
      });
    }).catch(function() {
      ABAY.setBtn('process-all-btn', false, '<i class="fa-solid fa-money-bill-wave"></i> Process All');
      ABAY.toast('Demo: All payroll processed (Database offline).', 'info');
      document.querySelectorAll('#payroll-table-body tr td:nth-child(9) .badge').forEach(function(b) {
        b.textContent = 'Processed';
        b.className = 'badge badge-success';
      });
      document.querySelectorAll('#payroll-table-body tr td:nth-child(10) button:last-child').forEach(function(b) {
        b.style.display = 'none';
      });
    });
  }

  function filterMonth(m) {
    document.getElementById('pay-month-title').textContent = m;
    ABAY.toast('Showing payroll for ' + m, 'info');
  }

  function exportPayrollCSV() {
    var rows = [
      ['ID', 'Name', 'Department', 'Basic', 'Allowances', 'Deductions', 'Tax', 'Net', 'Status']
    ];
    document.querySelectorAll('#payroll-table-body tr').forEach(function(tr) {
      if (tr.style.display === 'none') return;
      var cells = tr.querySelectorAll('td');
      if (cells.length > 8) rows.push([cells[0].textContent.trim(), cells[1].textContent.trim(), cells[2].textContent.trim(), cells[3].textContent.trim(), cells[4].textContent.trim(), cells[5].textContent.trim(), cells[6].textContent.trim(), cells[7].textContent.trim(), cells[8].textContent.trim()]);
    });
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'payroll.csv';
    a.click();
  }

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('payslip-modal').style.display = 'none';
  });
</script>