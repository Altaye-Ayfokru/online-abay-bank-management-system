﻿<?php

/** @var array $user */
$demo = [
  ['name' => 'Abebe Girma', 'dept' => 'Teller', 'branch' => 'HQ', 'kpi' => 94, 'rating' => 'Excellent', 'goal_hit' => 12, 'goal_total' => 13, 'trend' => '+4%', 'status' => 'Active'],
  ['name' => 'Tigist Haile', 'dept' => 'Loans', 'branch' => 'Bole', 'kpi' => 88, 'rating' => 'Good', 'goal_hit' => 10, 'goal_total' => 12, 'trend' => '+2%', 'status' => 'Active'],
  ['name' => 'Samuel Bekele', 'dept' => 'IT', 'branch' => 'HQ', 'kpi' => 91, 'rating' => 'Excellent', 'goal_hit' => 11, 'goal_total' => 12, 'trend' => '+6%', 'status' => 'Active'],
  ['name' => 'Meron Tesfaye', 'dept' => 'Customer Service', 'branch' => 'Piassa', 'kpi' => 76, 'rating' => 'Average', 'goal_hit' => 8, 'goal_total' => 12, 'trend' => '-1%', 'status' => 'Active'],
  ['name' => 'Dawit Alemu', 'dept' => 'HR', 'branch' => 'HQ', 'kpi' => 83, 'rating' => 'Good', 'goal_hit' => 9, 'goal_total' => 11, 'trend' => '+3%', 'status' => 'Active'],
  ['name' => 'Hana Mulugeta', 'dept' => 'Finance', 'branch' => 'Arada', 'kpi' => 79, 'rating' => 'Average', 'goal_hit' => 7, 'goal_total' => 10, 'trend' => '0%', 'status' => 'Active'],
  ['name' => 'Yonas Tadesse', 'dept' => 'Teller', 'branch' => 'Bole', 'kpi' => 96, 'rating' => 'Outstanding', 'goal_hit' => 13, 'goal_total' => 13, 'trend' => '+8%', 'status' => 'Active'],
  ['name' => 'Rahel Assefa', 'dept' => 'Loans', 'branch' => 'HQ', 'kpi' => 68, 'rating' => 'Needs Improvement', 'goal_hit' => 6, 'goal_total' => 12, 'trend' => '-3%', 'status' => 'Active'],
];
$ratings = ['Outstanding', 'Excellent', 'Good', 'Average', 'Needs Improvement'];
$depts   = ['Teller', 'Loans', 'IT', 'HR', 'Finance', 'Customer Service', 'Operations'];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-chart-bar" style="color:var(--primary)"></i> Employee Performance</h1>
    <p class="page-subtitle">Track KPIs, ratings, and goal achievement across all staff</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
    <button class="btn btn-primary" onclick="ABAY.toast('Performance report exported','success')"><i class="fa-solid fa-download"></i> Export</button>
  </div>
</div>

<!-- Summary Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#22c55e,#16a34a)"><i class="fa-solid fa-trophy"></i></div>
    <div class="stat-info">
      <div class="stat-value">3</div>
      <div class="stat-label">Outstanding</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#3b82f6,#2563eb)"><i class="fa-solid fa-star"></i></div>
    <div class="stat-info">
      <div class="stat-value">84%</div>
      <div class="stat-label">Avg KPI Score</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><i class="fa-solid fa-bullseye"></i></div>
    <div class="stat-info">
      <div class="stat-value">76%</div>
      <div class="stat-label">Goals Hit</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#ef4444,#dc2626)"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div class="stat-info">
      <div class="stat-value">1</div>
      <div class="stat-label">Needs Improvement</div>
    </div>
  </div>
</div>

<!-- Charts Row -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">KPI Distribution by Department</h3>
    </div>
    <div class="card-body"><canvas id="kpi-dept-chart" height="220"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Rating Breakdown</h3>
    </div>
    <div class="card-body"><canvas id="rating-chart" height="220"></canvas></div>
  </div>
</div>

<!-- Performance Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-table"></i> Performance Reviews</h3>
    <div class="card-tools">
      <select id="filter-dept" class="form-control form-control-sm" style="width:160px" onchange="filterPerf()">
        <option value="">All Departments</option>
        <?php foreach ($depts as $d): ?><option><?= htmlspecialchars($d) ?></option><?php endforeach; ?>
      </select>
      <select id="filter-rating" class="form-control form-control-sm" style="width:190px" onchange="filterPerf()">
        <option value="">All Ratings</option>
        <?php foreach ($ratings as $r): ?><option><?= htmlspecialchars($r) ?></option><?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table" id="perf-table">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Department</th>
            <th>Branch</th>
            <th>KPI Score</th>
            <th>Goals</th>
            <th>Trend</th>
            <th>Rating</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="perf-tbody">
          <?php foreach ($demo as $emp):
            $kpi = $emp['kpi'];
            $kpiColor = $kpi >= 90 ? '#22c55e' : ($kpi >= 75 ? '#3b82f6' : ($kpi >= 60 ? '#f59e0b' : '#ef4444'));
            $ratingClass = match ($emp['rating']) {
              'Outstanding' => 'badge-success',
              'Excellent' => 'badge-info',
              'Good' => 'badge-primary',
              'Average' => 'badge-warning',
              default => 'badge-danger'
            };
            $trendUp = str_starts_with($emp['trend'], '+');
          ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($emp['name'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($emp['name']) ?></div>
                  </div>
                </div>
              </td>
              <td><?= htmlspecialchars($emp['dept']) ?></td>
              <td><?= htmlspecialchars($emp['branch']) ?></td>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="flex:1;height:6px;background:#e5e7eb;border-radius:3px">
                    <div style="width:<?= $kpi ?>%;height:100%;background:<?= $kpiColor ?>;border-radius:3px"></div>
                  </div>
                  <span class="fw-semibold" style="color:<?= $kpiColor ?>;min-width:36px"><?= $kpi ?>%</span>
                </div>
              </td>
              <td><?= $emp['goal_hit'] ?>/<?= $emp['goal_total'] ?></td>
              <td>
                <span style="color:<?= $trendUp ? '#22c55e' : '#ef4444' ?>">
                  <i class="fa-solid <?= $trendUp ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down' ?>"></i>
                  <?= htmlspecialchars($emp['trend']) ?>
                </span>
              </td>
              <td><span class="badge <?= $ratingClass ?>"><?= htmlspecialchars($emp['rating']) ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="View Details" onclick="viewPerf(this)"><i class="fa-solid fa-eye"></i></button>
                  <button class="action-btn edit" data-tooltip="Edit Review" onclick="editPerf(this)"><i class="fa-solid fa-pen"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Detail Modal -->
<div class="modal-overlay" id="perf-detail-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <h3 class="modal-title">Performance Detail</h3>
      <button class="modal-close" onclick="document.getElementById('perf-detail-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" id="perf-detail-body">
      <!-- filled by JS -->
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterPerf() {
    const dept = document.getElementById('filter-dept').value.toLowerCase();
    const rating = document.getElementById('filter-rating').value.toLowerCase();
    document.querySelectorAll('#perf-tbody tr').forEach(tr => {
      const deptCell = tr.cells[1]?.textContent.toLowerCase() || '';
      const ratingCell = tr.cells[6]?.textContent.toLowerCase() || '';
      const show = (!dept || deptCell.includes(dept)) && (!rating || ratingCell.includes(rating));
      tr.style.display = show ? '' : 'none';
    });
  }

  function viewPerf(btn) {
    const tr = btn.closest('tr');
    const name = tr.cells[0].querySelector('.user-name').textContent;
    const dept = tr.cells[1].textContent.trim();
    const kpi = tr.cells[3].querySelector('span').textContent.trim();
    const rat = tr.cells[6].textContent.trim();
    document.getElementById('perf-detail-body').innerHTML = `
    <div style="text-align:center;padding:16px 0 24px">
      <div class="avatar" style="background:var(--primary);color:#fff;width:64px;height:64px;font-size:1.5rem;margin:0 auto 12px">${name.charAt(0)}</div>
      <h4>${name}</h4><p class="text-muted">${dept}</p>
    </div>
    <div class="form-grid-2">
      <div class="form-group"><label>KPI Score</label><p class="fw-semibold">${kpi}</p></div>
      <div class="form-group"><label>Rating</label><p class="fw-semibold">${rat}</p></div>
      <div class="form-group"><label>Goals Hit</label><p>${tr.cells[4].textContent.trim()}</p></div>
      <div class="form-group"><label>Trend</label><p>${tr.cells[5].textContent.trim()}</p></div>
    </div>`;
    document.getElementById('perf-detail-modal').classList.add('active');
  }

  function editPerf(btn) {
    ABAY.toast('Performance edit form coming soon', 'info');
  }

  // Charts
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    new Chart(document.getElementById('kpi-dept-chart'), {
      type: 'bar',
      data: {
        labels: ['Teller', 'Loans', 'IT', 'HR', 'Finance', 'Cust. Svc'],
        datasets: [{
          label: 'Avg KPI',
          data: [95, 78, 91, 83, 79, 76],
          backgroundColor: 'rgba(79,70,229,0.8)',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            min: 0,
            max: 100
          }
        }
      }
    });
    new Chart(document.getElementById('rating-chart'), {
      type: 'doughnut',
      data: {
        labels: ['Outstanding', 'Excellent', 'Good', 'Average', 'Needs Imp.'],
        datasets: [{
          data: [1, 2, 2, 2, 1],
          backgroundColor: ['#22c55e', '#3b82f6', '#6366f1', '#f59e0b', '#ef4444']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>