<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Dashboard — <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --navy:#1B3A5C;--teal:#007A8A;--gold:#C8A84B;--green:#2d6a4f;
  --bg:#f0f4f8;--surface:#fff;--border:#e2e8f0;
  --text:#1e293b;--text-muted:#64748b;
  --ok:#10b981;--warn:#f59e0b;--err:#ef4444;--info:#3b82f6;
}
[data-theme="dark"]{--bg:#0f172a;--surface:#1e293b;--border:#334155;--text:#f1f5f9;--text-muted:#94a3b8;}
html,body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

/* ── Top Bar ── */
.topbar{
  background:var(--navy);color:#fff;padding:0 24px;height:58px;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.2);
}
.tb-brand{display:flex;align-items:center;gap:11px;}
.tb-logo{display:flex;align-items:flex-end;gap:3px;background:rgba(255,255,255,.1);border-radius:7px;padding:5px 7px 7px;}
.tb-logo span{border-radius:2px 2px 0 0;display:block;}
.tb-lb1{width:4px;height:12px;background:var(--gold);}
.tb-lb2{width:4px;height:16px;background:#7ecfd8;}
.tb-lb3{width:4px;height:21px;background:#fff;}
.tb-lb4{width:4px;height:12px;background:#7ecfd8;}
.tb-name{font-size:.82rem;font-weight:700;opacity:.9;}
.tb-portal{font-size:.65rem;color:var(--gold);font-weight:600;letter-spacing:.08em;text-transform:uppercase;}
.tb-right{display:flex;align-items:center;gap:12px;}
.tb-greeting{font-size:.85rem;color:rgba(255,255,255,.75);}
.tb-greeting strong{color:#fff;}
.tb-btn{
  background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);
  color:#fff;padding:7px 14px;border-radius:8px;font-size:.8rem;font-weight:600;
  cursor:pointer;transition:.2s;font-family:inherit;display:flex;align-items:center;gap:6px;
  text-decoration:none;
}
.tb-btn:hover{background:rgba(255,255,255,.2);}
.tb-btn.danger:hover{background:rgba(239,68,68,.25);border-color:#ef4444;color:#fca5a5;}
.tb-av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--gold),#e8c86a);color:var(--navy);display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;}

/* ── Layout ── */
.portal-wrap{display:grid;grid-template-columns:240px 1fr;min-height:calc(100vh - 58px);}
@media(max-width:768px){.portal-wrap{grid-template-columns:1fr;}.emp-sidebar{display:none;}}

/* ── Employee Sidebar ── */
.emp-sidebar{background:var(--surface);border-right:1px solid var(--border);padding:20px 0;}
.emp-nav-section{padding:10px 20px 4px;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--text-muted);}
.emp-nav-link{
  display:flex;align-items:center;gap:10px;padding:10px 20px;color:var(--text-muted);
  font-size:.83rem;font-weight:500;text-decoration:none;border-left:3px solid transparent;
  transition:.2s;cursor:pointer;background:none;border-top:none;border-right:none;border-bottom:none;width:100%;text-align:left;font-family:inherit;
}
.emp-nav-link:hover{background:rgba(27,58,92,.05);color:var(--navy);}
.emp-nav-link.active{background:rgba(27,58,92,.08);color:var(--navy);border-left-color:var(--teal);font-weight:600;}
.emp-nav-link i{width:18px;text-align:center;font-size:.9rem;}

/* ── Main Content ── */
.emp-main{padding:24px;overflow-x:hidden;}
.emp-section{display:none;}
.emp-section.active{display:block;}

/* ── Page Header ── */
.page-hdr{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:24px;}
.page-hdr h1{font-size:1.4rem;font-weight:800;color:var(--navy);display:flex;align-items:center;gap:10px;}
.page-hdr p{font-size:.84rem;color:var(--text-muted);margin-top:3px;}

/* ── Cards ── */
.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px;}
.stat-card{background:var(--surface);border-radius:14px;padding:18px 20px;display:flex;align-items:center;gap:14px;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1px solid var(--border);}
.stat-ic{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;}
.stat-val{font-size:1.4rem;font-weight:800;color:var(--navy);line-height:1;}
.stat-lbl{font-size:.75rem;color:var(--text-muted);margin-top:3px;}

/* ── Cards ── */
.card{background:var(--surface);border-radius:14px;border:1px solid var(--border);box-shadow:0 2px 8px rgba(0,0,0,.06);margin-bottom:20px;}
.card-hdr{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid var(--border);}
.card-hdr h3{font-size:.95rem;font-weight:700;color:var(--navy);}
.card-body{padding:20px;}
.card-body.p0{padding:0;}

/* ── Table ── */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:.83rem;}
th{text-align:left;padding:10px 14px;background:#f8fafc;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);}
td{padding:12px 14px;border-bottom:1px solid var(--border);}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(27,58,92,.03);}

/* ── Badge ── */
.badge{display:inline-flex;align-items:center;padding:3px 10px;border-radius:99px;font-size:.73rem;font-weight:700;}
.badge-green{background:#dcfce7;color:#16a34a;}
.badge-red{background:#fee2e2;color:#dc2626;}
.badge-yellow{background:#fef9c3;color:#b45309;}
.badge-blue{background:#dbeafe;color:#1d4ed8;}
.badge-purple{background:#ede9fe;color:#7c3aed;}

/* ── Profile card ── */
.profile-pic{width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--gold),#e8c86a);color:var(--navy);display:flex;align-items:center;justify-content:center;font-size:2.2rem;font-weight:800;margin:0 auto 12px;}
.info-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:.84rem;}
.info-row:last-child{border-bottom:none;}
.info-label{color:var(--text-muted);font-weight:500;}
.info-val{font-weight:600;color:var(--text);}

/* ── Leave apply form ── */
.form-group{margin-bottom:14px;}
.form-label{display:block;font-size:.8rem;font-weight:600;color:var(--text);margin-bottom:5px;}
.form-control{width:100%;padding:10px 12px;border:2px solid var(--border);border-radius:9px;font-family:inherit;font-size:.88rem;outline:none;background:var(--surface);color:var(--text);transition:.2s;}
.form-control:focus{border-color:var(--teal);}
.btn-primary{background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff;border:none;padding:11px 22px;border-radius:9px;font-size:.87rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px;transition:.2s;}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(0,122,138,.3);}
.btn-outline{background:none;border:2px solid var(--border);color:var(--text);padding:9px 18px;border-radius:9px;font-size:.84rem;font-weight:600;cursor:pointer;font-family:inherit;transition:.2s;}
.btn-outline:hover{border-color:var(--teal);color:var(--teal);}

/* ── Grid ── */
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
@media(max-width:640px){.grid-2{grid-template-columns:1fr;}}
</style>
</head>
<body>

<!-- Top Bar -->
<div class="topbar">
  <div class="tb-brand">
    <div class="tb-logo">
      <span class="tb-lb1"></span><span class="tb-lb2"></span>
      <span class="tb-lb3"></span><span class="tb-lb4"></span>
    </div>
    <div>
      <div class="tb-name">Abay Bank S.C.</div>
      <div class="tb-portal">Employee Self-Service Portal</div>
    </div>
  </div>
  <div class="tb-right">
    <div class="tb-greeting">Welcome, <strong><?= htmlspecialchars($employee['first_name'] ?? $employee['name'] ?? 'Employee') ?></strong></div>
    <div class="tb-av"><?= strtoupper(substr($employee['first_name'] ?? $employee['name'] ?? 'E', 0, 1)) ?></div>
    <a href="<?= APP_URL ?>/employee/logout" class="tb-btn danger">
      <i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out
    </a>
  </div>
</div>

<div class="portal-wrap">

  <!-- Sidebar -->
  <aside class="emp-sidebar">
    <div class="emp-nav-section">My Portal</div>
    <button class="emp-nav-link active" onclick="showSection('dashboard')"><i class="fa-solid fa-gauge-high"></i> Dashboard</button>
    <button class="emp-nav-link" onclick="showSection('profile')"><i class="fa-solid fa-user-circle"></i> My Profile</button>

    <div class="emp-nav-section">Work & Pay</div>
    <button class="emp-nav-link" onclick="showSection('payslips')"><i class="fa-solid fa-receipt"></i> Payslips</button>
    <button class="emp-nav-link" onclick="showSection('attendance')"><i class="fa-solid fa-calendar-check"></i> Attendance</button>
    <button class="emp-nav-link" onclick="showSection('leave')"><i class="fa-solid fa-calendar-xmark"></i> Leave Requests</button>

    <div class="emp-nav-section">Development</div>
    <button class="emp-nav-link" onclick="showSection('performance')"><i class="fa-solid fa-chart-bar"></i> Performance</button>
    <button class="emp-nav-link" onclick="showSection('training')"><i class="fa-solid fa-graduation-cap"></i> Training</button>
  </aside>

  <!-- Main -->
  <main class="emp-main">

    <?php
    $emp = $employee ?? [];
    $empName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['name'] ?? 'Employee');
    $empId   = $emp['employee_number'] ?? $emp['employee_id'] ?? 'EMP-' . str_pad($emp['id'] ?? 1, 6, '0', STR_PAD_LEFT);
    $dept    = $emp['dept_name'] ?? $emp['department'] ?? 'Operations';
    $branch  = $emp['branch_name'] ?? $emp['branch'] ?? 'Head Office';
    $position= $emp['position'] ?? $emp['job_title'] ?? 'Staff';
    $salary  = $emp['basic_salary'] ?? 18500;
    $attendancePct = 95;
    $leaveBalance  = $emp['annual_leave_balance'] ?? 12;
    ?>

    <!-- ── DASHBOARD ── -->
    <section class="emp-section active" id="sec-dashboard">
      <div class="page-hdr">
        <div>
          <h1><i class="fa-solid fa-gauge-high" style="color:var(--teal)"></i> Dashboard</h1>
          <p>Good <?= (date('H')<12)?'morning':((date('H')<17)?'afternoon':'evening') ?>, <?= htmlspecialchars($empName) ?>! Here's your overview.</p>
        </div>
        <div style="text-align:right;font-size:.82rem;color:var(--text-muted)">
          <div><?= date('l, F j, Y') ?></div>
          <div><?= htmlspecialchars($position) ?> · <?= htmlspecialchars($dept) ?></div>
        </div>
      </div>

      <div class="stat-grid">
        <div class="stat-card">
          <div class="stat-ic" style="background:#dcfce7;color:#16a34a"><i class="fa-solid fa-calendar-check"></i></div>
          <div><div class="stat-val"><?= $attendancePct ?>%</div><div class="stat-lbl">Attendance Rate</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-calendar-xmark"></i></div>
          <div><div class="stat-val"><?= $leaveBalance ?></div><div class="stat-lbl">Leave Days Left</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-ic" style="background:#fef9c3;color:#b45309"><i class="fa-solid fa-receipt"></i></div>
          <div><div class="stat-val">ETB <?= number_format($salary) ?></div><div class="stat-lbl">Monthly Salary</div></div>
        </div>
        <div class="stat-card">
          <div class="stat-ic" style="background:#ede9fe;color:#7c3aed"><i class="fa-solid fa-chart-bar"></i></div>
          <div><div class="stat-val">88/100</div><div class="stat-lbl">KPI Score</div></div>
        </div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-hdr"><h3><i class="fa-solid fa-clock" style="color:var(--teal)"></i> Recent Attendance</h3></div>
          <div class="card-body p0">
            <table>
              <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Status</th></tr></thead>
              <tbody>
                <?php
                $days = [];
                for ($i = 0; $i < 5; $i++) {
                  $date = date('Y-m-d', strtotime("-$i days"));
                  $dow  = date('N', strtotime($date));
                  if ($dow >= 6) continue;
                  $days[] = $date;
                  if (count($days) >= 5) break;
                }
                $statuses = ['Present','Present','Late','Present','Present'];
                $ins  = ['08:02','07:58','09:14','08:05','08:01'];
                $outs = ['17:03','17:10','17:00','17:15','17:08'];
                foreach ($days as $k => $d):
                  $s = $statuses[$k] ?? 'Present';
                  $bc = $s==='Present'?'badge-green':($s==='Late'?'badge-yellow':'badge-red');
                ?>
                <tr>
                  <td><?= date('M j', strtotime($d)) ?></td>
                  <td><?= $ins[$k] ?? '08:00' ?></td>
                  <td><?= $outs[$k] ?? '17:00' ?></td>
                  <td><span class="badge <?= $bc ?>"><?= $s ?></span></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <div class="card-hdr"><h3><i class="fa-solid fa-bell" style="color:var(--gold)"></i> Notifications</h3></div>
          <div class="card-body">
            <?php
            $notifs = [
              ['Payslip for August 2026 is ready','fa-receipt','#dcfce7','#16a34a','2 hours ago'],
              ['Training: AML Compliance — Sep 1-3','fa-graduation-cap','#dbeafe','#1d4ed8','Yesterday'],
              ['Leave request approved','fa-circle-check','#dcfce7','#16a34a','2 days ago'],
              ['Performance review scheduled for Sep 15','fa-chart-bar','#ede9fe','#7c3aed','3 days ago'],
            ];
            foreach ($notifs as [$msg,$ico,$bg,$clr,$time]):
            ?>
            <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
              <div style="width:36px;height:36px;border-radius:9px;background:<?= $bg ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fa-solid <?= $ico ?>" style="color:<?= $clr ?>;font-size:.85rem"></i>
              </div>
              <div>
                <div style="font-size:.83rem;font-weight:600"><?= $msg ?></div>
                <div style="font-size:.75rem;color:var(--text-muted)"><?= $time ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Attendance chart -->
      <div class="card">
        <div class="card-hdr"><h3><i class="fa-solid fa-chart-line" style="color:var(--teal)"></i> Attendance This Month</h3></div>
        <div class="card-body"><canvas id="att-chart" height="100"></canvas></div>
      </div>
    </section>

    <!-- ── PROFILE ── -->
    <section class="emp-section" id="sec-profile">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-user-circle" style="color:var(--teal)"></i> My Profile</h1><p>View and update your personal information</p></div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-hdr"><h3>Personal Information</h3></div>
          <div class="card-body" style="text-align:center;padding-bottom:24px">
            <div class="profile-pic"><?= strtoupper(substr($empName, 0, 1)) ?></div>
            <h3 style="font-size:1.1rem;margin-bottom:4px"><?= htmlspecialchars($empName) ?></h3>
            <p style="color:var(--teal);font-size:.85rem;font-weight:600"><?= htmlspecialchars($position) ?></p>
            <p style="font-size:.8rem;color:var(--text-muted)"><?= htmlspecialchars($dept) ?> · <?= htmlspecialchars($branch) ?></p>
          </div>
          <div class="card-body" style="padding-top:0">
            <div class="info-row"><span class="info-label">Employee ID</span><span class="info-val" style="font-family:monospace"><?= htmlspecialchars($empId) ?></span></div>
            <div class="info-row"><span class="info-label">Full Name</span><span class="info-val"><?= htmlspecialchars($empName) ?></span></div>
            <div class="info-row"><span class="info-label">Department</span><span class="info-val"><?= htmlspecialchars($dept) ?></span></div>
            <div class="info-row"><span class="info-label">Branch</span><span class="info-val"><?= htmlspecialchars($branch) ?></span></div>
            <div class="info-row"><span class="info-label">Position</span><span class="info-val"><?= htmlspecialchars($position) ?></span></div>
            <div class="info-row"><span class="info-label">Email</span><span class="info-val"><?= htmlspecialchars($emp['email'] ?? 'employee@abaybank.com') ?></span></div>
            <div class="info-row"><span class="info-label">Phone</span><span class="info-val"><?= htmlspecialchars($emp['phone'] ?? '+251 9XX XXX XXX') ?></span></div>
            <div class="info-row"><span class="info-label">Joined</span><span class="info-val"><?= date('M j, Y', strtotime($emp['hire_date'] ?? '2022-01-15')) ?></span></div>
          </div>
        </div>
        <div>
          <div class="card" style="margin-bottom:16px">
            <div class="card-hdr"><h3>Change Password</h3></div>
            <div class="card-body">
              <form onsubmit="changePw(event)">
                <div class="form-group"><label class="form-label">Current Password</label>
                  <input type="password" class="form-control" id="pw-cur" placeholder="Current password"></div>
                <div class="form-group"><label class="form-label">New Password</label>
                  <input type="password" class="form-control" id="pw-new" placeholder="Min. 8 characters"></div>
                <div class="form-group"><label class="form-label">Confirm New Password</label>
                  <input type="password" class="form-control" id="pw-cf" placeholder="Repeat new password"></div>
                <button type="submit" class="btn-primary"><i class="fa-solid fa-lock"></i> Update Password</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── PAYSLIPS ── -->
    <section class="emp-section" id="sec-payslips">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-receipt" style="color:var(--teal)"></i> Payslips</h1><p>View and download your monthly payslips</p></div>
      </div>
      <!-- Summary -->
      <div class="stat-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
        <?php foreach ([
          ['Basic Salary','ETB '.number_format($salary),'fa-money-bill-wave','#dcfce7','#16a34a'],
          ['Transport','ETB 1,500','fa-car','#dbeafe','#1d4ed8'],
          ['Housing','ETB 2,000','fa-house','#fef9c3','#b45309'],
          ['Tax','ETB 2,850','fa-minus-circle','#fee2e2','#dc2626'],
          ['Net Pay','ETB '.number_format($salary+1500+2000-2850),'fa-circle-check','#dcfce7','#16a34a'],
        ] as [$l,$v,$i,$bg,$c]): ?>
        <div class="stat-card">
          <div class="stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
          <div><div class="stat-val" style="font-size:1rem"><?= $v ?></div><div class="stat-lbl"><?= $l ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="card">
        <div class="card-hdr"><h3>Payslip History</h3></div>
        <div class="card-body p0">
          <table>
            <thead><tr><th>Month</th><th>Gross Pay</th><th>Deductions</th><th>Net Pay</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              <?php for ($m = 0; $m < 6; $m++):
                $mo    = date('F Y', strtotime("-$m months"));
                $gross = $salary + 3500;
                $ded   = 2850;
                $net   = $gross - $ded;
              ?>
              <tr>
                <td class="fw-semibold"><?= $mo ?></td>
                <td>ETB <?= number_format($gross) ?></td>
                <td style="color:#ef4444">ETB <?= number_format($ded) ?></td>
                <td style="font-weight:700;color:#16a34a">ETB <?= number_format($net) ?></td>
                <td><span class="badge badge-green">Paid</span></td>
                <td><button onclick="alert('Downloading payslip for <?= $mo ?>...')" style="background:none;border:1px solid var(--border);padding:5px 12px;border-radius:6px;cursor:pointer;font-size:.78rem;color:var(--navy);font-family:inherit"><i class="fa-solid fa-download"></i> Download</button></td>
              </tr>
              <?php endfor; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ── ATTENDANCE ── -->
    <section class="emp-section" id="sec-attendance">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-calendar-check" style="color:var(--teal)"></i> My Attendance</h1><p>Track your daily attendance and punctuality</p></div>
      </div>
      <div class="stat-grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr))">
        <?php foreach ([
          ['Present','20','fa-circle-check','#dcfce7','#16a34a'],
          ['Late','1','fa-clock','#fef9c3','#b45309'],
          ['Absent','1','fa-circle-xmark','#fee2e2','#dc2626'],
          ['On Leave','0','fa-calendar-xmark','#dbeafe','#1d4ed8'],
          ['Rate','95%','fa-chart-pie','#ede9fe','#7c3aed'],
        ] as [$l,$v,$i,$bg,$c]): ?>
        <div class="stat-card">
          <div class="stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
          <div><div class="stat-val"><?= $v ?></div><div class="stat-lbl"><?= $l ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="card">
        <div class="card-hdr">
          <h3>Attendance Log</h3>
          <select class="form-control" style="width:150px;padding:6px 10px;font-size:.82rem" onchange="alert('Filter applied')">
            <option><?= date('F Y') ?></option>
            <option><?= date('F Y', strtotime('-1 month')) ?></option>
            <option><?= date('F Y', strtotime('-2 months')) ?></option>
          </select>
        </div>
        <div class="card-body p0">
          <table>
            <thead><tr><th>Date</th><th>Day</th><th>Check In</th><th>Check Out</th><th>Hours</th><th>Status</th></tr></thead>
            <tbody>
              <?php
              $check = [
                ['08:02','17:03','9h 01m','Present'],['07:58','17:10','9h 12m','Present'],
                ['09:14','17:00','7h 46m','Late'],['08:05','17:15','9h 10m','Present'],
                ['08:01','17:08','9h 07m','Present'],
              ];
              for ($i = 0; $i < 7; $i++):
                $date = date('Y-m-d', strtotime("-$i days"));
                $dow  = date('N', strtotime($date));
                if ($dow >= 6) continue;
                $ci = $check[$i % 5] ?? ['08:00','17:00','9h 00m','Present'];
                $bc = $ci[3]==='Present'?'badge-green':($ci[3]==='Late'?'badge-yellow':'badge-red');
              ?>
              <tr>
                <td><?= date('M j, Y', strtotime($date)) ?></td>
                <td style="color:var(--text-muted)"><?= date('D', strtotime($date)) ?></td>
                <td><?= $ci[0] ?></td>
                <td><?= $ci[1] ?></td>
                <td><?= $ci[2] ?></td>
                <td><span class="badge <?= $bc ?>"><?= $ci[3] ?></span></td>
              </tr>
              <?php endfor; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ── LEAVE ── -->
    <section class="emp-section" id="sec-leave">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-calendar-xmark" style="color:var(--teal)"></i> Leave Requests</h1><p>Apply for leave and track request status</p></div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-hdr"><h3>Leave Balance</h3></div>
          <div class="card-body">
            <?php foreach ([
              ['Annual Leave','12 days left','18 days total','#16a34a'],
              ['Sick Leave','8 days left','10 days total','#1d4ed8'],
              ['Maternity/Paternity','90 days','(if applicable)','#7c3aed'],
            ] as [$t,$rem,$tot,$c]): ?>
            <div style="margin-bottom:16px">
              <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                <span style="font-weight:600;font-size:.85rem"><?= $t ?></span>
                <span style="color:<?= $c ?>;font-weight:700;font-size:.85rem"><?= $rem ?></span>
              </div>
              <div style="height:7px;background:#f1f5f9;border-radius:3px">
                <div style="width:70%;height:100%;background:<?= $c ?>;border-radius:3px"></div>
              </div>
              <div style="font-size:.73rem;color:var(--text-muted);margin-top:3px"><?= $tot ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="card">
          <div class="card-hdr"><h3>Apply for Leave</h3></div>
          <div class="card-body">
            <form onsubmit="applyLeave(event)">
              <div class="form-group"><label class="form-label">Leave Type</label>
                <select class="form-control">
                  <option>Annual Leave</option><option>Sick Leave</option>
                  <option>Emergency Leave</option><option>Maternity/Paternity</option>
                </select>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                <div class="form-group"><label class="form-label">From Date</label>
                  <input type="date" class="form-control" min="<?= date('Y-m-d') ?>"></div>
                <div class="form-group"><label class="form-label">To Date</label>
                  <input type="date" class="form-control" min="<?= date('Y-m-d') ?>"></div>
              </div>
              <div class="form-group"><label class="form-label">Reason</label>
                <textarea class="form-control" rows="2" placeholder="Brief reason for leave..."></textarea>
              </div>
              <button type="submit" class="btn-primary"><i class="fa-solid fa-paper-plane"></i> Submit Request</button>
            </form>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-hdr"><h3>Leave History</h3></div>
        <div class="card-body p0">
          <table>
            <thead><tr><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Status</th><th>Applied</th></tr></thead>
            <tbody>
              <tr><td>Annual Leave</td><td>2026-07-14</td><td>2026-07-18</td><td>5</td><td><span class="badge badge-green">Approved</span></td><td>2026-07-08</td></tr>
              <tr><td>Sick Leave</td><td>2026-06-03</td><td>2026-06-04</td><td>2</td><td><span class="badge badge-green">Approved</span></td><td>2026-06-03</td></tr>
              <tr><td>Annual Leave</td><td>2026-09-08</td><td>2026-09-12</td><td>5</td><td><span class="badge badge-yellow">Pending</span></td><td>2026-08-20</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ── PERFORMANCE ── -->
    <section class="emp-section" id="sec-performance">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-chart-bar" style="color:var(--teal)"></i> My Performance</h1><p>View KPIs, ratings, and goal progress</p></div>
      </div>
      <div class="stat-grid">
        <?php foreach ([
          ['KPI Score','88/100','fa-bullseye','#dbeafe','#1d4ed8'],
          ['Rating','Good','fa-star','#fef9c3','#b45309'],
          ['Goals Hit','10/12','fa-circle-check','#dcfce7','#16a34a'],
          ['Trend','+4%','fa-arrow-trend-up','#dcfce7','#16a34a'],
        ] as [$l,$v,$i,$bg,$c]): ?>
        <div class="stat-card">
          <div class="stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
          <div><div class="stat-val"><?= $v ?></div><div class="stat-lbl"><?= $l ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="card">
        <div class="card-hdr"><h3>KPI Progress</h3></div>
        <div class="card-body"><canvas id="kpi-chart" height="90"></canvas></div>
      </div>
      <div class="card">
        <div class="card-hdr"><h3>Goal Tracker</h3></div>
        <div class="card-body">
          <?php foreach ([
            ['Customer Satisfaction Score','92%','92','#16a34a'],
            ['Transaction Processing Speed','85%','85','#1d4ed8'],
            ['Error Rate Reduction','78%','78','#b45309'],
            ['Training Completion','100%','100','#7c3aed'],
          ] as [$g,$p,$pct,$c]): ?>
          <div style="margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;margin-bottom:5px;font-size:.84rem">
              <span><?= $g ?></span><span style="font-weight:700;color:<?= $c ?>"><?= $p ?></span>
            </div>
            <div style="height:7px;background:#f1f5f9;border-radius:3px">
              <div style="width:<?= $pct ?>%;height:100%;background:<?= $c ?>;border-radius:3px"></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <!-- ── TRAINING ── -->
    <section class="emp-section" id="sec-training">
      <div class="page-hdr">
        <div><h1><i class="fa-solid fa-graduation-cap" style="color:var(--teal)"></i> Training</h1><p>Track and enroll in training programs</p></div>
      </div>
      <?php
      $programs = [
        ['Core Banking System Update','IT Department','2026-09-01','2026-09-03','In-Person','Upcoming','#dbeafe','#1d4ed8',0],
        ['AML & Compliance Refresher','Compliance Team','2026-08-10','2026-08-12','Online','Completed','#dcfce7','#16a34a',100],
        ['Customer Service Excellence','HR Department','2026-08-20','2026-08-21','Hybrid','In Progress','#fef9c3','#b45309',60],
      ];
      foreach ($programs as [$title,$trainer,$start,$end,$mode,$status,$bg,$c,$pct]):
      ?>
      <div class="card">
        <div class="card-body">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:12px">
            <div>
              <h4 style="font-size:.95rem;margin-bottom:4px"><?= $title ?></h4>
              <p style="font-size:.8rem;color:var(--text-muted)"><?= $trainer ?> · <?= $start ?> – <?= $end ?> · <?= $mode ?></p>
            </div>
            <span class="badge" style="background:<?= $bg ?>;color:<?= $c ?>"><?= $status ?></span>
          </div>
          <?php if ($pct > 0): ?>
          <div style="margin-bottom:8px">
            <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:4px">
              <span style="color:var(--text-muted)">Progress</span><span style="font-weight:700;color:<?= $c ?>"><?= $pct ?>%</span>
            </div>
            <div style="height:6px;background:#f1f5f9;border-radius:3px">
              <div style="width:<?= $pct ?>%;height:100%;background:<?= $c ?>;border-radius:3px"></div>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($status === 'Completed'): ?>
          <button onclick="alert('Downloading certificate...')" class="btn-outline" style="font-size:.78rem;padding:6px 14px"><i class="fa-solid fa-certificate"></i> Download Certificate</button>
          <?php elseif ($status === 'Upcoming'): ?>
          <button onclick="alert('Enrolled successfully!')" class="btn-primary" style="font-size:.78rem;padding:7px 16px"><i class="fa-solid fa-user-plus"></i> Enroll</button>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </section>

  </main>
</div>

<script>
function showSection(name) {
  document.querySelectorAll('.emp-section').forEach(function(s) { s.classList.remove('active'); });
  document.querySelectorAll('.emp-nav-link').forEach(function(l) { l.classList.remove('active'); });
  var sec = document.getElementById('sec-' + name);
  if (sec) sec.classList.add('active');
  event.currentTarget.classList.add('active');
}

function changePw(e) {
  e.preventDefault();
  var cur = document.getElementById('pw-cur').value;
  var nw  = document.getElementById('pw-new').value;
  var cf  = document.getElementById('pw-cf').value;
  if (!cur || !nw || !cf) { alert('Please fill all fields'); return; }
  if (nw !== cf) { alert('Passwords do not match'); return; }
  alert('Password changed successfully!');
  e.target.reset();
}

function applyLeave(e) {
  e.preventDefault();
  alert('Leave request submitted! You will be notified once it is reviewed.');
  e.target.reset();
}

// Charts
document.addEventListener('DOMContentLoaded', function() {
  if (!window.Chart) return;
  var attCtx = document.getElementById('att-chart');
  if (attCtx) {
    new Chart(attCtx, {
      type: 'bar',
      data: {
        labels: ['Mon','Tue','Wed','Thu','Fri','Mon','Tue','Wed','Thu','Fri'],
        datasets: [
          { label:'Present', data:[1,1,0,1,1,1,1,1,1,1], backgroundColor:'#22c55e', borderRadius:4 },
          { label:'Late',    data:[0,0,1,0,0,0,0,0,0,0], backgroundColor:'#f59e0b', borderRadius:4 }
        ]
      },
      options: { responsive:true, plugins:{ legend:{ position:'bottom' } }, scales:{ y:{ max:1, display:false } } }
    });
  }
  var kpiCtx = document.getElementById('kpi-chart');
  if (kpiCtx) {
    new Chart(kpiCtx, {
      type:'radar',
      data:{
        labels:['Customer Service','Accuracy','Speed','Teamwork','Communication','Compliance'],
        datasets:[{ label:'My KPI', data:[88,92,85,90,87,95], borderColor:'#007A8A', backgroundColor:'rgba(0,122,138,.15)', pointBackgroundColor:'#007A8A' }]
      },
      options:{ responsive:true, scales:{ r:{ min:0, max:100 } }, plugins:{ legend:{ display:false } } }
    });
  }
});
</script>
</body>
</html>
