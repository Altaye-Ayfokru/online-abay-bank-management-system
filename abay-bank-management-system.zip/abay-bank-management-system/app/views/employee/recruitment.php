﻿<?php

/** @var array $vacancies @var array $applications @var array $user */
$demoVacancies = $vacancies ?: [
  ['id' => 1, 'title' => 'Senior Teller', 'dept' => 'Operations', 'branch' => 'HQ', 'type' => 'Full-Time', 'deadline' => '2026-09-15', 'applicants' => 12, 'status' => 'Open'],
  ['id' => 2, 'title' => 'Loan Officer', 'dept' => 'Loans', 'branch' => 'Bole', 'type' => 'Full-Time', 'deadline' => '2026-09-01', 'applicants' => 8, 'status' => 'Open'],
  ['id' => 3, 'title' => 'IT Support Technician', 'dept' => 'IT', 'branch' => 'HQ', 'type' => 'Contract', 'deadline' => '2026-08-30', 'applicants' => 5, 'status' => 'Closed'],
  ['id' => 4, 'title' => 'Customer Service Rep', 'dept' => 'Customer Service', 'branch' => 'Piassa', 'type' => 'Full-Time', 'deadline' => '2026-10-01', 'applicants' => 20, 'status' => 'Open'],
  ['id' => 5, 'title' => 'HR Officer', 'dept' => 'HR', 'branch' => 'HQ', 'type' => 'Full-Time', 'deadline' => '2026-09-20', 'applicants' => 7, 'status' => 'Open'],
];
$demoApps = $applications ?: [
  ['name' => 'Abebe Tadesse', 'position' => 'Senior Teller', 'applied' => '2026-08-01', 'stage' => 'Interview', 'score' => 88, 'status' => 'Shortlisted'],
  ['name' => 'Tigist Bekele', 'position' => 'Loan Officer', 'applied' => '2026-07-28', 'stage' => 'Assessment', 'score' => 72, 'status' => 'In Review'],
  ['name' => 'Samuel Girma', 'position' => 'HR Officer', 'applied' => '2026-07-25', 'stage' => 'HR Round', 'score' => 91, 'status' => 'Shortlisted'],
  ['name' => 'Meron Haile', 'position' => 'Customer Service Rep', 'applied' => '2026-08-05', 'stage' => 'Applied', 'score' => 65, 'status' => 'Pending'],
  ['name' => 'Yonas Alemu', 'position' => 'IT Support Technician', 'applied' => '2026-07-20', 'stage' => 'Rejected', 'score' => 55, 'status' => 'Rejected'],
  ['name' => 'Hana Assefa', 'position' => 'Loan Officer', 'applied' => '2026-08-08', 'stage' => 'Offer', 'score' => 95, 'status' => 'Offered'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-user-plus" style="color:var(--primary)"></i> Recruitment</h1>
    <p class="page-subtitle">Manage job vacancies, applications, and hiring pipeline</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="openModal('vacancy-modal')"><i class="fa-solid fa-plus"></i> Post Vacancy</button>
    <button class="btn btn-primary" onclick="ABAY.toast('Recruitment report exported','success')"><i class="fa-solid fa-download"></i> Export</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#6366f1,#4f46e5)"><i class="fa-solid fa-briefcase"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count(array_filter($demoVacancies, fn($v) => $v['status'] === 'Open')) ?></div>
      <div class="stat-label">Open Vacancies</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#3b82f6,#2563eb)"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count($demoApps) ?></div>
      <div class="stat-label">Applications</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#22c55e,#16a34a)"><i class="fa-solid fa-check-circle"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count(array_filter($demoApps, fn($a) => $a['status'] === 'Shortlisted')) ?></div>
      <div class="stat-label">Shortlisted</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><i class="fa-solid fa-handshake"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count(array_filter($demoApps, fn($a) => $a['status'] === 'Offered')) ?></div>
      <div class="stat-label">Offers Made</div>
    </div>
  </div>
</div>

<!-- Tabs -->
<div class="card">
  <div class="card-header" style="padding-bottom:0">
    <div class="tab-group" id="recruit-tabs">
      <button class="tab-btn active" onclick="switchTab('vacancies')">Job Vacancies</button>
      <button class="tab-btn" onclick="switchTab('applications')">Applications</button>
      <button class="tab-btn" onclick="switchTab('pipeline')">Hiring Pipeline</button>
    </div>
  </div>

  <!-- Vacancies -->
  <div id="tab-vacancies" class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Position</th>
            <th>Department</th>
            <th>Branch</th>
            <th>Type</th>
            <th>Deadline</th>
            <th>Applicants</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoVacancies as $v): ?>
            <tr>
              <td class="fw-semibold"><?= htmlspecialchars($v['title']) ?></td>
              <td><?= htmlspecialchars($v['dept']) ?></td>
              <td><?= htmlspecialchars($v['branch']) ?></td>
              <td><span class="badge badge-secondary"><?= htmlspecialchars($v['type']) ?></span></td>
              <td><?= htmlspecialchars($v['deadline']) ?></td>
              <td><span class="badge badge-info"><?= $v['applicants'] ?></span></td>
              <td><span class="badge <?= $v['status'] === 'Open' ? 'badge-success' : 'badge-danger' ?>"><?= $v['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="View Applicants" onclick="ABAY.toast('Viewing applicants for <?= addslashes($v['title']) ?>','info')"><i class="fa-solid fa-users"></i></button>
                  <button class="action-btn edit" data-tooltip="Edit" onclick="ABAY.toast('Edit vacancy','info')"><i class="fa-solid fa-pen"></i></button>
                  <button class="action-btn delete" data-tooltip="Close Vacancy" onclick="ABAY.toast('Vacancy closed','warning')"><i class="fa-solid fa-xmark"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Applications -->
  <div id="tab-applications" class="card-body p-0" style="display:none">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Applicant</th>
            <th>Position Applied</th>
            <th>Applied On</th>
            <th>Stage</th>
            <th>Score</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoApps as $a):
            $sc = $a['score'];
            $sColor = $sc >= 85 ? '#22c55e' : ($sc >= 70 ? '#3b82f6' : '#f59e0b');
            $stClass = match ($a['status']) {
              'Shortlisted' => 'badge-success',
              'Offered' => 'badge-primary',
              'Rejected' => 'badge-danger',
              'In Review' => 'badge-info',
              default => 'badge-warning'
            };
          ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($a['name'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($a['name']) ?></div>
                  </div>
                </div>
              </td>
              <td><?= htmlspecialchars($a['position']) ?></td>
              <td><?= htmlspecialchars($a['applied']) ?></td>
              <td><span class="badge badge-secondary"><?= htmlspecialchars($a['stage']) ?></span></td>
              <td><span class="fw-semibold" style="color:<?= $sColor ?>"><?= $sc ?></span></td>
              <td><span class="badge <?= $stClass ?>"><?= htmlspecialchars($a['status']) ?></span></td>
              <td>
                <div class="table-actions">
                  <button class="action-btn view" data-tooltip="View CV" onclick="ABAY.toast('Opening CV','info')"><i class="fa-solid fa-file-lines"></i></button>
                  <button class="action-btn approve" data-tooltip="Advance" onclick="ABAY.toast('Applicant advanced','success')"><i class="fa-solid fa-arrow-right"></i></button>
                  <button class="action-btn delete" data-tooltip="Reject" onclick="ABAY.toast('Application rejected','warning')"><i class="fa-solid fa-xmark"></i></button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Pipeline -->
  <div id="tab-pipeline" class="card-body" style="display:none">
    <div style="display:flex;gap:16px;overflow-x:auto;padding-bottom:8px">
      <?php
      $stages = ['Applied' => '#6366f1', 'Assessment' => '#3b82f6', 'Interview' => '#f59e0b', 'HR Round' => '#22c55e', 'Offer' => '#10b981', 'Rejected' => '#ef4444'];
      foreach ($stages as $stage => $color):
        $stageApps = array_filter($demoApps, fn($a) => $a['stage'] === $stage);
      ?>
        <div style="min-width:180px;flex:1">
          <div style="background:<?= $color ?>;color:#fff;padding:8px 12px;border-radius:8px 8px 0 0;font-weight:600;font-size:.85rem;display:flex;justify-content:space-between">
            <?= $stage ?>
            <span style="background:rgba(255,255,255,.25);padding:2px 8px;border-radius:12px"><?= count($stageApps) ?></span>
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-top:none;border-radius:0 0 8px 8px;padding:8px;min-height:120px">
            <?php foreach ($stageApps as $a): ?>
              <div style="background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;font-size:.83rem">
                <div class="fw-semibold"><?= htmlspecialchars($a['name']) ?></div>
                <div class="text-muted" style="font-size:.78rem"><?= htmlspecialchars($a['position']) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Post Vacancy Modal -->
<div class="modal-overlay" id="vacancy-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:540px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-plus"></i> Post New Vacancy</h3>
      <button class="modal-close" onclick="document.getElementById('vacancy-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="submitVacancy(event)">
        <div class="form-grid-2">
          <div class="form-group form-group-full">
            <label class="form-label required">Position Title</label>
            <input type="text" class="form-control" placeholder="e.g. Senior Teller" required>
          </div>
          <div class="form-group">
            <label class="form-label">Department</label>
            <select class="form-control">
              <option>Operations</option>
              <option>Loans</option>
              <option>IT</option>
              <option>HR</option>
              <option>Finance</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Employment Type</label>
            <select class="form-control">
              <option>Full-Time</option>
              <option>Part-Time</option>
              <option>Contract</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Application Deadline</label>
            <input type="date" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Number of Positions</label>
            <input type="number" class="form-control" value="1" min="1">
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Job Description</label>
            <textarea class="form-control" rows="3" placeholder="Describe responsibilities and requirements..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('vacancy-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Post Vacancy</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function openModal(id) {
    document.getElementById(id).classList.add('active');
  }

  function switchTab(name) {
    ['vacancies', 'applications', 'pipeline'].forEach(t => {
      document.getElementById('tab-' + t).style.display = t === name ? '' : 'none';
    });
    document.querySelectorAll('#recruit-tabs .tab-btn').forEach((b, i) => {
      b.classList.toggle('active', ['vacancies', 'applications', 'pipeline'][i] === name);
    });
  }

  function submitVacancy(e) {
    e.preventDefault();
    document.getElementById('vacancy-modal').classList.remove('active');
    ABAY.toast('Vacancy posted successfully!', 'success');
  }
</script>