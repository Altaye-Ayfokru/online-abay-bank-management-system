﻿<?php

/** @var array $programs @var array $user */
$demoPrograms = $programs ?: [
  ['id' => 1, 'title' => 'Core Banking System Training', 'trainer' => 'IT Department', 'dept' => 'All Staff', 'start' => '2026-09-01', 'end' => '2026-09-03', 'hours' => 24, 'enrolled' => 45, 'completed' => 0, 'status' => 'Upcoming', 'mode' => 'In-Person'],
  ['id' => 2, 'title' => 'AML & Compliance Refresher', 'trainer' => 'Compliance Team', 'dept' => 'All Staff', 'start' => '2026-08-10', 'end' => '2026-08-12', 'hours' => 16, 'enrolled' => 82, 'completed' => 82, 'status' => 'Completed', 'mode' => 'Online'],
  ['id' => 3, 'title' => 'Customer Service Excellence', 'trainer' => 'HR Department', 'dept' => 'Teller & CS', 'start' => '2026-08-20', 'end' => '2026-08-21', 'hours' => 12, 'enrolled' => 30, 'completed' => 18, 'status' => 'In Progress', 'mode' => 'Hybrid'],
  ['id' => 4, 'title' => 'Loan Appraisal Techniques', 'trainer' => 'Credit Division', 'dept' => 'Loans', 'start' => '2026-09-10', 'end' => '2026-09-12', 'hours' => 20, 'enrolled' => 15, 'completed' => 0, 'status' => 'Upcoming', 'mode' => 'In-Person'],
  ['id' => 5, 'title' => 'Cybersecurity Awareness', 'trainer' => 'IT Department', 'dept' => 'All Staff', 'start' => '2026-07-15', 'end' => '2026-07-16', 'hours' => 8, 'enrolled' => 120, 'completed' => 118, 'status' => 'Completed', 'mode' => 'Online'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-graduation-cap" style="color:var(--primary)"></i> Training Programs</h1>
    <p class="page-subtitle">Manage employee training, schedules, and completion tracking</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="document.getElementById('enroll-modal').classList.add('active')"><i class="fa-solid fa-user-plus"></i> Enroll Employee</button>
    <button class="btn btn-primary" onclick="document.getElementById('add-training-modal').classList.add('active')"><i class="fa-solid fa-plus"></i> Add Program</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#6366f1,#4f46e5)"><i class="fa-solid fa-book-open"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count($demoPrograms) ?></div>
      <div class="stat-label">Total Programs</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><i class="fa-solid fa-spinner"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count(array_filter($demoPrograms, fn($p) => $p['status'] === 'In Progress')) ?></div>
      <div class="stat-label">In Progress</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#22c55e,#16a34a)"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count(array_filter($demoPrograms, fn($p) => $p['status'] === 'Completed')) ?></div>
      <div class="stat-label">Completed</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#3b82f6,#2563eb)"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= array_sum(array_column($demoPrograms, 'enrolled')) ?></div>
      <div class="stat-label">Total Enrollments</div>
    </div>
  </div>
</div>

<!-- Programs Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px;margin-bottom:24px">
  <?php foreach ($demoPrograms as $p):
    $statusColor = match ($p['status']) {
      'Completed' => '#22c55e',
      'In Progress' => '#f59e0b',
      default => '#3b82f6'
    };
    $pct = $p['enrolled'] > 0 ? round($p['completed'] / $p['enrolled'] * 100) : 0;
  ?>
    <div class="card" style="border-top:3px solid <?= $statusColor ?>">
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <h4 style="margin:0;font-size:.95rem;flex:1"><?= htmlspecialchars($p['title']) ?></h4>
          <span class="badge" style="background:<?= $statusColor ?>20;color:<?= $statusColor ?>;border:1px solid <?= $statusColor ?>40;white-space:nowrap;margin-left:8px"><?= $p['status'] ?></span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;font-size:.83rem">
          <div><i class="fa-solid fa-chalkboard-user text-muted"></i> <span><?= htmlspecialchars($p['trainer']) ?></span></div>
          <div><i class="fa-solid fa-users text-muted"></i> <span><?= htmlspecialchars($p['dept']) ?></span></div>
          <div><i class="fa-solid fa-calendar text-muted"></i> <span><?= $p['start'] ?></span></div>
          <div><i class="fa-solid fa-clock text-muted"></i> <span><?= $p['hours'] ?>h</span></div>
          <div><i class="fa-solid fa-laptop text-muted"></i> <span><?= htmlspecialchars($p['mode']) ?></span></div>
          <div><i class="fa-solid fa-person-chalkboard text-muted"></i> <span><?= $p['enrolled'] ?> enrolled</span></div>
        </div>
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;font-size:.8rem;margin-bottom:4px">
            <span class="text-muted">Completion</span>
            <span class="fw-semibold"><?= $pct ?>%</span>
          </div>
          <div style="height:6px;background:#e5e7eb;border-radius:3px">
            <div style="width:<?= $pct ?>%;height:100%;background:<?= $statusColor ?>;border-radius:3px;transition:.3s"></div>
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm btn-outline" onclick="ABAY.toast('Viewing <?= addslashes($p['title']) ?>','info')" style="flex:1">
            <i class="fa-solid fa-eye"></i> Details
          </button>
          <?php if ($p['status'] !== 'Completed'): ?>
            <button class="btn btn-sm btn-primary" onclick="ABAY.toast('Mark attendance recorded','success')" style="flex:1">
              <i class="fa-solid fa-check"></i> Mark
            </button>
          <?php else: ?>
            <button class="btn btn-sm btn-success" onclick="ABAY.toast('Certificate downloaded','success')" style="flex:1">
              <i class="fa-solid fa-certificate"></i> Certificate
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Completed Training Log -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-history"></i> Training History</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Program</th>
            <th>Trainer</th>
            <th>Dates</th>
            <th>Hours</th>
            <th>Enrolled</th>
            <th>Completed</th>
            <th>Mode</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($demoPrograms as $p):
            $sc = match ($p['status']) {
              'Completed' => 'badge-success',
              'In Progress' => 'badge-warning',
              default => 'badge-info'
            };
          ?>
            <tr>
              <td class="fw-semibold"><?= htmlspecialchars($p['title']) ?></td>
              <td><?= htmlspecialchars($p['trainer']) ?></td>
              <td class="text-muted" style="font-size:.83rem"><?= $p['start'] ?> – <?= $p['end'] ?></td>
              <td><?= $p['hours'] ?>h</td>
              <td><?= $p['enrolled'] ?></td>
              <td><?= $p['completed'] ?></td>
              <td><span class="badge badge-secondary"><?= htmlspecialchars($p['mode']) ?></span></td>
              <td><span class="badge <?= $sc ?>"><?= $p['status'] ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Training Modal -->
<div class="modal-overlay" id="add-training-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:540px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-plus"></i> Add Training Program</h3>
      <button class="modal-close" onclick="document.getElementById('add-training-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="submitTraining(event)">
        <div class="form-grid-2">
          <div class="form-group form-group-full">
            <label class="form-label required">Program Title</label>
            <input type="text" class="form-control" placeholder="Training name" required>
          </div>
          <div class="form-group">
            <label class="form-label">Trainer / Facilitator</label>
            <input type="text" class="form-control" placeholder="Name or department">
          </div>
          <div class="form-group">
            <label class="form-label">Mode</label>
            <select class="form-control">
              <option>In-Person</option>
              <option>Online</option>
              <option>Hybrid</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Start Date</label>
            <input type="date" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">End Date</label>
            <input type="date" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Total Hours</label>
            <input type="number" class="form-control" min="1" value="8">
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Target Department</label>
            <select class="form-control">
              <option>All Staff</option>
              <option>Teller</option>
              <option>Loans</option>
              <option>IT</option>
              <option>HR</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('add-training-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Program</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Enroll Modal -->
<div class="modal-overlay" id="enroll-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:420px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-user-plus"></i> Enroll Employee</h3>
      <button class="modal-close" onclick="document.getElementById('enroll-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="submitEnroll(event)">
        <div class="form-group">
          <label class="form-label">Employee</label>
          <select class="form-control">
            <option>-- Select Employee --</option>
            <option>Abebe Girma</option>
            <option>Tigist Haile</option>
            <option>Samuel Bekele</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Program</label>
          <select class="form-control">
            <?php foreach ($demoPrograms as $p): ?><option><?= htmlspecialchars($p['title']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('enroll-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Enroll</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function submitTraining(e) {
    e.preventDefault();
    document.getElementById('add-training-modal').classList.remove('active');
    ABAY.toast('Training program added!', 'success');
  }

  function submitEnroll(e) {
    e.preventDefault();
    document.getElementById('enroll-modal').classList.remove('active');
    ABAY.toast('Employee enrolled in training!', 'success');
  }
</script>