<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>403 Forbidden — Abay Bank</title>
<style>body{font-family:Inter,sans-serif;background:#f0f4f8;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
.box{background:#fff;border-radius:16px;padding:48px;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,.1);max-width:420px;}
.icon{font-size:3rem;margin-bottom:16px;}
h1{color:#1B3A5C;font-size:1.4rem;margin-bottom:8px;}
p{color:#64748b;margin-bottom:24px;}
a{background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;padding:12px 28px;border-radius:10px;text-decoration:none;font-weight:600;}</style></head>
<body><div class="box"><div class="icon">🔒</div><h1>Access Denied</h1><p>You do not have permission to access this page.</p>
<a href="<?= defined('APP_URL') ? APP_URL : '/' ?>/dashboard">Go to Dashboard</a></div></body></html>
