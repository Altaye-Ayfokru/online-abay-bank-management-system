<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>404 — Page Not Found · Abay Bank</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #0f2336, #1B3A5C);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }

    .card {
      background: #fff;
      border-radius: 24px;
      padding: 56px 48px;
      text-align: center;
      max-width: 480px;
      width: 100%;
      box-shadow: 0 32px 80px rgba(0, 0, 0, .35);
    }

    .icon-wrap {
      width: 88px;
      height: 88px;
      background: linear-gradient(135deg, #fee2e2, #fecaca);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 28px;
      font-size: 2.4rem;
      color: #dc2626;
    }

    .code {
      font-size: 5rem;
      font-weight: 900;
      color: #1B3A5C;
      line-height: 1;
      margin-bottom: 4px;
    }

    .code span {
      color: #C8A84B;
    }

    h1 {
      font-size: 1.5rem;
      font-weight: 800;
      color: #1B3A5C;
      margin-bottom: 12px;
    }

    p {
      font-size: .9rem;
      color: #64748b;
      line-height: 1.7;
      margin-bottom: 32px;
      max-width: 320px;
      margin-left: auto;
      margin-right: auto;
    }

    .actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 24px;
      border-radius: 10px;
      font-size: .88rem;
      font-weight: 700;
      text-decoration: none;
      transition: all .25s;
      font-family: 'Inter', sans-serif;
    }

    .btn-primary {
      background: linear-gradient(135deg, #1B3A5C, #007A8A);
      color: #fff;
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(27, 58, 92, .4);
    }

    .btn-ghost {
      background: #f1f5f9;
      color: #334155;
    }

    .btn-ghost:hover {
      background: #e2e8f0;
    }

    .divider {
      height: 1px;
      background: #f1f5f9;
      margin: 28px 0;
    }

    .quick-links {
      display: flex;
      gap: 8px;
      justify-content: center;
      flex-wrap: wrap;
    }

    .ql {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: .78rem;
      color: #64748b;
      padding: 6px 12px;
      background: #f8fafc;
      border-radius: 99px;
      text-decoration: none;
      transition: all .2s;
    }

    .ql:hover {
      background: #1B3A5C;
      color: #fff;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 9px;
      justify-content: center;
      margin-bottom: 32px;
    }

    .logo-bars {
      display: flex;
      align-items: flex-end;
      gap: 3px;
      background: #1B3A5C;
      border-radius: 8px;
      padding: 6px 8px 8px;
    }

    .logo-bars span {
      border-radius: 2px 2px 0 0;
      display: block;
    }

    .lb1 {
      width: 4px;
      height: 11px;
      background: #C8A84B;
    }

    .lb2 {
      width: 4px;
      height: 15px;
      background: #7ecfd8;
    }

    .lb3 {
      width: 4px;
      height: 19px;
      background: #fff;
    }

    .lb4 {
      width: 4px;
      height: 11px;
      background: #7ecfd8;
    }

    .logo-text .am {
      font-size: .85rem;
      font-weight: 800;
      color: #1B3A5C;
    }

    .logo-text .en {
      font-size: .55rem;
      color: #C8A84B;
      font-weight: 700;
      letter-spacing: .1em;
      text-transform: uppercase;
    }
  </style>
</head>

<body>
  <div class="card">
    <div class="logo">
      <div class="logo-bars"><span class="lb1"></span><span class="lb2"></span><span class="lb3"></span><span class="lb4"></span></div>
      <div class="logo-text">
        <div class="am">ዓባይ ባንክ</div>
        <div class="en">Abay Bank</div>
      </div>
    </div>
    <div class="icon-wrap"><i class="fa-solid fa-map-location-dot"></i></div>
    <div class="code">4<span>0</span>4</div>
    <h1>Page Not Found</h1>
    <p>The page you're looking for doesn't exist or has been moved. Double-check the URL or use one of the links below.</p>
    <div class="actions">
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/dashboard" class="btn btn-primary"><i class="fa-solid fa-gauge"></i> Go to Dashboard</a>
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/" class="btn btn-ghost"><i class="fa-solid fa-house"></i> Home</a>
    </div>
    <div class="divider"></div>
    <div class="quick-links">
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/customers" class="ql"><i class="fa-solid fa-users"></i> Customers</a>
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/transactions" class="ql"><i class="fa-solid fa-right-left"></i> Transactions</a>
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/loans" class="ql"><i class="fa-solid fa-file-invoice-dollar"></i> Loans</a>
      <a href="<?= defined('APP_URL') ? APP_URL : '' ?>/login" class="ql"><i class="fa-solid fa-lock"></i> Login</a>
    </div>
  </div>
</body>

</html>