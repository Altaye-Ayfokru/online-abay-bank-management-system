<!DOCTYPE html>
<html lang="am-ET">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>አባይ ባንክ — Abay Bank S.C. — Ethiopia's Trusted Banking Partner</title>
  <meta name="description" content="አባይ ባንክ ሻ.ኩ. — Abay Bank S.C. — NBE Licensed, 500+ branches, modern digital banking for every Ethiopian.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Noto+Sans+Ethiopic:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box
    }

    :root {
      --navy: #1B3A5C;
      --nd: #0f2336;
      --nm: #254d7a;
      --teal: #007A8A;
      --tl: #e0f5f7;
      --gold: #C8A84B;
      --gl: #e8c86a;
      --white: #fff;
      --off: #f8fafc;
      --g100: #f1f5f9;
      --g200: #e2e8f0;
      --g400: #94a3b8;
      --g600: #475569;
      --g700: #334155;
      --g800: #1e293b;
      --ok: #10b981;
      --err: #ef4444;
      --sh: 0 4px 24px rgba(0, 0, 0, .08);
      --sh-lg: 0 16px 48px rgba(0, 0, 0, .14);
      --sh-xl: 0 24px 64px rgba(0, 0, 0, .2);
      --r: 12px;
      --r-lg: 18px;
      --r-xl: 24px
    }

    html {
      scroll-behavior: smooth;
      font-size: 16px
    }

    body {
      font-family: 'Inter', sans-serif;
      color: var(--g800);
      background: #fff;
      overflow-x: hidden;
      line-height: 1.6
    }

    a {
      text-decoration: none;
      color: inherit
    }

    img {
      display: block;
      max-width: 100%
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 24px
    }

    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 26px;
      border-radius: 10px;
      font-size: .9rem;
      font-weight: 700;
      cursor: pointer;
      border: none;
      font-family: inherit;
      white-space: nowrap;
      transition: all .25s
    }

    .btn-lg {
      padding: 15px 34px;
      font-size: 1rem;
      border-radius: 12px
    }

    .btn-primary {
      background: linear-gradient(135deg, var(--navy), var(--nm));
      color: #fff;
      box-shadow: 0 4px 16px rgba(27, 58, 92, .35)
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 28px rgba(27, 58, 92, .45)
    }

    .btn-gold {
      background: linear-gradient(135deg, var(--gold), var(--gl));
      color: var(--nd);
      box-shadow: 0 4px 16px rgba(200, 168, 75, .4)
    }

    .btn-gold:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 28px rgba(200, 168, 75, .5)
    }

    .btn-outline {
      background: transparent;
      border: 2px solid var(--navy);
      color: var(--navy)
    }

    .btn-outline:hover {
      background: var(--navy);
      color: #fff
    }

    .btn-glass {
      background: rgba(255, 255, 255, .12);
      border: 1.5px solid rgba(255, 255, 255, .3);
      color: #fff;
      backdrop-filter: blur(10px)
    }

    .btn-glass:hover {
      background: rgba(255, 255, 255, .22);
      border-color: rgba(255, 255, 255, .5)
    }

    /* Topbar */
    .topbar {
      background: var(--nd);
      padding: 8px 0;
      font-size: .77rem;
      color: rgba(255, 255, 255, .68)
    }

    .topbar .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap
    }

    .tb-l,
    .tb-r {
      display: flex;
      align-items: center;
      gap: 18px
    }

    .topbar a {
      color: rgba(255, 255, 255, .68);
      display: flex;
      align-items: center;
      gap: 5px;
      transition: color .2s
    }

    .topbar a:hover {
      color: var(--gold)
    }

    .tb-lang {
      background: var(--gold);
      color: var(--nd);
      padding: 2px 10px;
      border-radius: 99px;
      font-weight: 700;
      font-size: .68rem;
      cursor: pointer;
      border: none;
      font-family: inherit
    }

    /* Navbar */
    .site-nav {
      background: rgba(255, 255, 255, .96);
      backdrop-filter: blur(20px);
      box-shadow: 0 1px 0 rgba(0, 0, 0, .06);
      position: sticky;
      top: 0;
      z-index: 999;
      transition: box-shadow .3s
    }

    .site-nav.scrolled {
      box-shadow: 0 4px 24px rgba(0, 0, 0, .12)
    }

    .nav-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 72px
    }

    .nav-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      flex-shrink: 0
    }

    .logo-mark {
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--navy);
      border-radius: 10px;
      padding: 7px 9px;
      transition: transform .3s;
      width: 42px;
      height: 42px;
      flex-shrink: 0
    }

    .logo-mark:hover {
      transform: scale(1.05)
    }

    .logo-mark span {
      border-radius: 2px 2px 0 0;
      display: block
    }

    .lm1 {
      width: 5px;
      height: 13px;
      background: var(--gold)
    }

    .lm2 {
      width: 5px;
      height: 18px;
      background: #7ecfd8
    }

    .lm3 {
      width: 5px;
      height: 24px;
      background: #fff
    }

    .lm4 {
      width: 5px;
      height: 13px;
      background: #7ecfd8
    }

    .logo-text .am {
      font-size: 1rem;
      font-weight: 800;
      color: var(--navy);
      font-family: 'Noto Sans Ethiopic', 'Nyala', 'Ebrima', sans-serif;
      line-height: 1.1
    }

    .logo-text .en {
      font-size: .6rem;
      color: var(--gold);
      font-weight: 700;
      letter-spacing: .12em;
      text-transform: uppercase
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 2px;
      list-style: none
    }

    .nav-links a {
      padding: 8px 13px;
      border-radius: 8px;
      font-size: .86rem;
      font-weight: 500;
      color: var(--g700);
      transition: all .2s;
      white-space: nowrap
    }

    .nav-links a:hover,
    .nav-links a.active {
      color: var(--navy);
      background: var(--g100)
    }

    .has-dd {
      position: relative
    }

    .dd-menu {
      position: absolute;
      top: calc(100%+10px);
      left: 0;
      background: #fff;
      border-radius: 14px;
      box-shadow: var(--sh-xl);
      min-width: 230px;
      padding: 8px;
      display: none;
      z-index: 100;
      border: 1px solid var(--g200);
      animation: fadeDown .2s ease
    }

    @keyframes fadeDown {
      from {
        opacity: 0;
        transform: translateY(-8px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    .has-dd:hover .dd-menu {
      display: block
    }

    .dd-menu a {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 9px;
      font-size: .84rem;
      color: var(--g700);
      transition: all .2s
    }

    .dd-menu a:hover {
      background: var(--off);
      color: var(--navy)
    }

    .dd-menu a i {
      width: 18px;
      color: var(--teal);
      font-size: .86rem
    }

    .nav-cta {
      display: flex;
      align-items: center;
      gap: 9px
    }

    .hamburger {
      display: none;
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1.4rem;
      color: var(--navy);
      padding: 6px
    }

    /* Hero */
    .hero {
      min-height: 96vh;
      background: var(--nd);
      position: relative;
      display: flex;
      align-items: center;
      overflow: hidden
    }

    .hero-bg {
      position: absolute;
      inset: 0;
      background: url('https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1800&q=60&auto=format')center/cover;
      opacity: .07
    }

    .hero-grad {
      position: absolute;
      inset: 0;
      background: linear-gradient(155deg, rgba(11, 30, 50, .97) 0%, rgba(27, 58, 92, .85) 50%, rgba(0, 90, 110, .7) 100%)
    }

    .hero-g1 {
      position: absolute;
      top: -150px;
      right: -100px;
      width: 600px;
      height: 600px;
      background: radial-gradient(circle, rgba(200, 168, 75, .14), transparent 70%);
      border-radius: 50%
    }

    .hero-g2 {
      position: absolute;
      bottom: -100px;
      left: -50px;
      width: 400px;
      height: 400px;
      background: radial-gradient(circle, rgba(0, 122, 138, .2), transparent 70%);
      border-radius: 50%
    }

    /* Particles */
    .particles {
      position: absolute;
      inset: 0;
      overflow: hidden;
      pointer-events: none
    }

    .particle {
      position: absolute;
      border-radius: 50%;
      animation: pfloat linear infinite
    }

    @keyframes pfloat {
      0% {
        transform: translateY(110vh) scale(0);
        opacity: 0
      }

      10% {
        opacity: .8
      }

      90% {
        opacity: .4
      }

      100% {
        transform: translateY(-80px) scale(1.2) rotate(720deg);
        opacity: 0
      }
    }

    .hero .container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 64px;
      align-items: center;
      position: relative;
      z-index: 2;
      padding: 100px 24px
    }

    .hero-tag {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      background: rgba(200, 168, 75, .18);
      border: 1px solid rgba(200, 168, 75, .35);
      color: var(--gold);
      padding: 6px 16px;
      border-radius: 99px;
      font-size: .72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 22px
    }

    .hero-tag .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--gold);
      animation: pdot 2s infinite
    }

    @keyframes pdot {

      0%,
      100% {
        opacity: 1;
        transform: scale(1)
      }

      50% {
        opacity: .4;
        transform: scale(.7)
      }
    }

    .hero-title {
      font-size: 3.2rem;
      font-weight: 900;
      color: #fff;
      line-height: 1.08;
      margin-bottom: 22px;
      letter-spacing: -.02em
    }

    .hero-title .accent {
      color: var(--gold);
      display: block
    }

    .hero-title .sub {
      font-size: 2.7rem
    }

    .hero-desc {
      font-size: 1.05rem;
      color: rgba(255, 255, 255, .75);
      line-height: 1.8;
      margin-bottom: 38px;
      max-width: 480px
    }

    .hero-desc strong {
      color: var(--gold);
      font-weight: 600
    }

    .hero-actions {
      display: flex;
      gap: 14px;
      flex-wrap: wrap;
      margin-bottom: 56px
    }

    .hero-stats {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      background: rgba(255, 255, 255, .06);
      border: 1px solid rgba(255, 255, 255, .1);
      border-radius: var(--r-lg);
      overflow: hidden;
      backdrop-filter: blur(8px)
    }

    .hero-stat {
      padding: 18px 14px;
      text-align: center;
      border-right: 1px solid rgba(255, 255, 255, .07)
    }

    .hero-stat:last-child {
      border-right: none
    }

    .hero-stat .n {
      font-size: 1.8rem;
      font-weight: 900;
      color: var(--gold);
      line-height: 1
    }

    .hero-stat .l {
      font-size: .65rem;
      color: rgba(255, 255, 255, .5);
      text-transform: uppercase;
      letter-spacing: .6px;
      margin-top: 4px
    }

    /* Hero visual */
    .hero-visual {
      position: relative;
      display: flex;
      justify-content: flex-end;
      align-items: center
    }

    .hero-img-main {
      width: 330px;
      height: 420px;
      object-fit: cover;
      border-radius: var(--r-xl);
      box-shadow: 0 32px 80px rgba(0, 0, 0, .6);
      border: 1px solid rgba(255, 255, 255, .1)
    }

    .hero-img-card {
      position: absolute;
      bottom: -20px;
      left: -40px;
      width: 185px;
      height: 125px;
      object-fit: cover;
      border-radius: var(--r-lg);
      box-shadow: 0 16px 40px rgba(0, 0, 0, .5);
      border: 3px solid rgba(15, 35, 54, .9)
    }

    .fb {
      position: absolute;
      background: rgba(255, 255, 255, .95);
      backdrop-filter: blur(12px);
      border-radius: var(--r);
      padding: 12px 16px;
      box-shadow: var(--sh-xl);
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: .8rem;
      font-weight: 700;
      color: var(--navy);
      border: 1px solid rgba(255, 255, 255, .4)
    }

    .fb1 {
      top: 30px;
      right: -20px;
      animation: bob 3s ease-in-out infinite
    }

    .fb2 {
      bottom: 80px;
      right: -24px;
      animation: bob 3s ease-in-out infinite .5s
    }

    @keyframes bob {

      0%,
      100% {
        transform: translateY(0)
      }

      50% {
        transform: translateY(-8px)
      }
    }

    .fb-ic {
      width: 34px;
      height: 34px;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: .95rem;
      flex-shrink: 0
    }

    .fb-green {
      background: #d1fae5;
      color: #059669
    }

    .fb-teal {
      background: var(--tl);
      color: var(--teal)
    }

    .fb-num {
      font-size: 1.05rem;
      font-weight: 900
    }

    .fb-lbl {
      font-size: .65rem;
      color: var(--g400)
    }

    /* Section commons */
    .section {
      padding: 90px 0
    }

    .sec-gray {
      background: var(--off)
    }

    .sec-navy {
      background: var(--nd)
    }

    .section-header {
      text-align: center;
      margin-bottom: 64px
    }

    .tag {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(200, 168, 75, .12);
      color: #92400e;
      border: 1px solid rgba(200, 168, 75, .28);
      padding: 5px 16px;
      border-radius: 99px;
      font-size: .71rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      margin-bottom: 14px
    }

    .section-title {
      font-size: 2.3rem;
      font-weight: 800;
      color: var(--navy);
      line-height: 1.2;
      margin-bottom: 14px;
      letter-spacing: -.02em
    }

    .section-desc {
      font-size: .96rem;
      color: var(--g600);
      max-width: 580px;
      margin: 0 auto;
      line-height: 1.78
    }

    .on-dark .section-title {
      color: #fff
    }

    .on-dark .section-desc {
      color: rgba(255, 255, 255, .68)
    }

    /* Quick services */
    .qs-wrap {
      background: #fff;
      position: relative;
      z-index: 10;
      margin-top: -44px
    }

    .qs-grid {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      background: #fff;
      border-radius: var(--r-lg);
      box-shadow: var(--sh-xl);
      overflow: hidden;
      border: 1px solid var(--g200)
    }

    .qs-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 24px 10px;
      cursor: pointer;
      transition: all .3s;
      border-right: 1px solid var(--g200);
      text-align: center;
      text-decoration: none;
      position: relative
    }

    .qs-item::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, var(--navy), var(--teal));
      transform: scaleX(0);
      transition: transform .3s
    }

    .qs-item:hover::after {
      transform: scaleX(1)
    }

    .qs-item:last-child {
      border-right: none
    }

    .qs-item:hover {
      background: var(--off);
      transform: translateY(-3px)
    }

    .qs-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: rgba(27, 58, 92, .08);
      color: var(--navy);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      transition: all .3s
    }

    .qs-item:hover .qs-icon {
      background: var(--navy);
      color: #fff;
      transform: scale(1.1)
    }

    .qs-label {
      font-size: .76rem;
      font-weight: 600;
      color: var(--g700);
      transition: color .3s
    }

    .qs-item:hover .qs-label {
      color: var(--navy)
    }

    /* Products */
    .products-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px
    }

    .p-card {
      background: #fff;
      border-radius: var(--r-lg);
      border: 1px solid var(--g200);
      overflow: hidden;
      transition: all .35s;
      position: relative
    }

    .p-card:hover {
      transform: translateY(-8px);
      box-shadow: var(--sh-xl);
      border-color: transparent
    }

    .p-card::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, var(--navy), var(--teal), var(--gold));
      opacity: 0;
      transition: opacity .35s
    }

    .p-card:hover::after {
      opacity: 1
    }

    .p-img-wrap {
      overflow: hidden
    }

    .p-img {
      width: 100%;
      height: 165px;
      object-fit: cover;
      transition: transform .4s
    }

    .p-card:hover .p-img {
      transform: scale(1.05)
    }

    .p-body {
      padding: 22px 20px
    }

    .p-icon {
      width: 46px;
      height: 46px;
      border-radius: 12px;
      background: rgba(27, 58, 92, .07);
      color: var(--navy);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      margin-bottom: 14px;
      transition: all .3s
    }

    .p-card:hover .p-icon {
      background: var(--navy);
      color: #fff
    }

    .p-card h3 {
      font-size: 1.02rem;
      font-weight: 700;
      color: var(--navy);
      margin-bottom: 7px
    }

    .p-card p {
      font-size: .83rem;
      color: var(--g600);
      line-height: 1.65;
      margin-bottom: 12px
    }

    .p-rate {
      display: flex;
      align-items: baseline;
      gap: 3px;
      margin-bottom: 12px
    }

    .p-rate .r {
      font-size: 1.8rem;
      font-weight: 900;
      color: var(--gold)
    }

    .p-rate .rl {
      font-size: .72rem;
      color: var(--g400)
    }

    .p-features {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 5px;
      margin-bottom: 16px
    }

    .p-features li {
      display: flex;
      align-items: center;
      gap: 7px;
      font-size: .8rem;
      color: var(--g700)
    }

    .p-features li i {
      color: var(--ok);
      font-size: .7rem
    }

    .p-link {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      color: var(--teal);
      font-size: .84rem;
      font-weight: 700;
      transition: gap .2s
    }

    .p-link:hover {
      gap: 10px
    }

    /* Stats band */
    .stats-band {
      background: linear-gradient(135deg, var(--navy), var(--teal));
      padding: 64px 0;
      position: relative;
      overflow: hidden
    }

    .stats-band::before {
      content: '';
      position: absolute;
      inset: 0;
      background: url('https://images.unsplash.com/photo-1560472355-536de3962603?w=1600&q=30&auto=format')center/cover;
      opacity: .05
    }

    .sb-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 2px;
      text-align: center;
      position: relative;
      z-index: 1
    }

    .sb-item {
      padding: 24px;
      border-right: 1px solid rgba(255, 255, 255, .1)
    }

    .sb-item:last-child {
      border-right: none
    }

    .sb-num {
      font-size: 3.2rem;
      font-weight: 900;
      color: #fff;
      line-height: 1
    }

    .sb-num .suf {
      color: var(--gold)
    }

    .sb-lbl {
      font-size: .78rem;
      color: rgba(255, 255, 255, .62);
      text-transform: uppercase;
      letter-spacing: .6px;
      margin-top: 8px
    }

    /* Digital banking */
    .digital-sec {
      background: var(--nd);
      padding: 100px 0;
      position: relative;
      overflow: hidden
    }

    .digital-sec::before {
      content: '';
      position: absolute;
      inset: 0;
      background: url('https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=1600&q=40&auto=format')center/cover;
      opacity: .05
    }

    .dig-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 80px;
      align-items: center;
      position: relative;
      z-index: 1
    }

    .dig-feats {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-top: 32px
    }

    .df {
      background: rgba(255, 255, 255, .06);
      border: 1px solid rgba(255, 255, 255, .09);
      border-radius: var(--r);
      padding: 18px;
      transition: all .3s
    }

    .df:hover {
      background: rgba(255, 255, 255, .1);
      border-color: rgba(200, 168, 75, .4);
      transform: translateY(-3px)
    }

    .df-ic {
      width: 40px;
      height: 40px;
      border-radius: 10px;
      background: rgba(200, 168, 75, .18);
      color: var(--gold);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      margin-bottom: 9px
    }

    .df h4 {
      font-size: .86rem;
      font-weight: 700;
      color: #fff;
      margin-bottom: 3px
    }

    .df p {
      font-size: .76rem;
      color: rgba(255, 255, 255, .5);
      line-height: 1.55;
      margin: 0
    }

    .phone-wrap {
      position: relative;
      display: flex;
      justify-content: center
    }

    .phone-img {
      width: 270px;
      border-radius: 28px;
      box-shadow: 0 32px 80px rgba(0, 0, 0, .7);
      border: 2px solid rgba(255, 255, 255, .08)
    }

    .pb {
      position: absolute;
      background: rgba(255, 255, 255, .95);
      backdrop-filter: blur(12px);
      border-radius: var(--r);
      padding: 11px 15px;
      box-shadow: var(--sh-xl);
      display: flex;
      align-items: center;
      gap: 9px;
      border: 1px solid rgba(255, 255, 255, .3)
    }

    .pb1 {
      bottom: 60px;
      left: -30px;
      animation: bob 3s ease-in-out infinite
    }

    .pb2 {
      top: 80px;
      right: -30px;
      animation: bob 3s ease-in-out infinite .7s
    }

    .pb-ic {
      width: 34px;
      height: 34px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      flex-shrink: 0
    }

    /* Why Abay */
    .why-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 72px;
      align-items: center
    }

    .why-img-wrap {
      position: relative
    }

    .why-img {
      width: 100%;
      height: 500px;
      object-fit: cover;
      border-radius: var(--r-xl);
      box-shadow: var(--sh-xl)
    }

    .why-badge {
      position: absolute;
      bottom: -18px;
      right: -18px;
      background: #fff;
      border-radius: var(--r-lg);
      padding: 16px 20px;
      box-shadow: var(--sh-xl);
      text-align: center;
      border: 1px solid var(--g200)
    }

    .why-badge .bn {
      font-size: 2.2rem;
      font-weight: 900;
      color: var(--gold)
    }

    .why-badge .bl {
      font-size: .72rem;
      color: var(--g600);
      font-weight: 600
    }

    .why-pts {
      display: flex;
      flex-direction: column;
      gap: 22px;
      margin-top: 30px
    }

    .why-pt {
      display: flex;
      gap: 16px;
      align-items: flex-start
    }

    .wp-ic {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: var(--tl);
      color: var(--teal);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      flex-shrink: 0;
      transition: all .3s
    }

    .why-pt:hover .wp-ic {
      background: var(--teal);
      color: #fff;
      transform: scale(1.1)
    }

    .wp-t h4 {
      font-size: .96rem;
      font-weight: 700;
      color: var(--navy);
      margin-bottom: 3px
    }

    .wp-t p {
      font-size: .83rem;
      color: var(--g600);
      line-height: 1.65;
      margin: 0
    }

    /* Team */
    .team-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 24px
    }

    .tm-card {
      background: #fff;
      border-radius: var(--r-lg);
      overflow: hidden;
      border: 1px solid var(--g200);
      transition: all .35s;
      text-align: center;
      position: relative
    }

    .tm-card:hover {
      transform: translateY(-8px);
      box-shadow: var(--sh-xl);
      border-color: transparent
    }

    .tm-card::before {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(to bottom, transparent 55%, rgba(27, 58, 92, .8));
      opacity: 0;
      transition: opacity .35s;
      z-index: 1
    }

    .tm-card:hover::before {
      opacity: 1
    }

    .tm-img {
      width: 100%;
      height: 240px;
      object-fit: cover;
      object-position: center top;
      transition: transform .4s;
      display: block
    }

    .tm-card:hover .tm-img {
      transform: scale(1.05)
    }

    .tm-body {
      padding: 16px;
      position: relative
    }

    .tm-card:hover .tm-body {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 2
    }

    .tm-body h4 {
      font-size: .92rem;
      font-weight: 700;
      color: var(--navy);
      margin-bottom: 2px;
      transition: color .3s
    }

    .tm-card:hover .tm-body h4,
    .tm-card:hover .tm-role,
    .tm-card:hover .tm-br {
      color: #fff
    }

    .tm-role {
      font-size: .77rem;
      color: var(--teal);
      font-weight: 600;
      transition: color .3s
    }

    .tm-br {
      font-size: .72rem;
      color: var(--g400);
      margin-top: 2px;
      transition: color .3s
    }

    .tm-social {
      display: flex;
      justify-content: center;
      gap: 7px;
      margin-top: 9px
    }

    .tm-social a {
      width: 28px;
      height: 28px;
      border-radius: 7px;
      background: var(--g100);
      color: var(--g600);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: .74rem;
      transition: all .2s
    }

    .tm-social a:hover,
    .tm-card:hover .tm-social a {
      background: var(--navy);
      color: #fff
    }

    /* Testimonials */
    .testi-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px
    }

    .ts-card {
      background: #fff;
      border-radius: var(--r-lg);
      border: 1px solid var(--g200);
      padding: 28px;
      transition: all .35s;
      position: relative;
      overflow: hidden
    }

    .ts-card::before {
      content: '\201C';
      position: absolute;
      top: 12px;
      right: 18px;
      font-size: 5rem;
      color: var(--g100);
      line-height: 1;
      font-family: Georgia, serif;
      transition: color .3s
    }

    .ts-card:hover {
      box-shadow: var(--sh-xl);
      border-color: transparent;
      transform: translateY(-5px)
    }

    .ts-card:hover::before {
      color: var(--tl)
    }

    .ts-stars {
      color: var(--gold);
      font-size: .82rem;
      margin-bottom: 10px;
      display: flex;
      gap: 2px
    }

    .ts-text {
      font-size: .87rem;
      color: var(--g600);
      line-height: 1.78;
      margin-bottom: 18px;
      font-style: italic;
      position: relative;
      z-index: 1
    }

    .ts-author {
      display: flex;
      align-items: center;
      gap: 11px
    }

    .ts-author img {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      object-fit: cover;
      flex-shrink: 0;
      border: 2px solid var(--g200)
    }

    .ts-name {
      font-size: .86rem;
      font-weight: 700;
      color: var(--navy)
    }

    .ts-loc {
      font-size: .74rem;
      color: var(--g400)
    }

    /* Branches */
    .br-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 18px
    }

    .br-card {
      background: #fff;
      border: 1px solid var(--g200);
      border-radius: var(--r);
      padding: 20px;
      display: flex;
      gap: 13px;
      align-items: flex-start;
      transition: all .3s
    }

    .br-card:hover {
      box-shadow: var(--sh-lg);
      border-color: var(--tl);
      transform: translateY(-3px)
    }

    .br-ic {
      width: 42px;
      height: 42px;
      border-radius: 10px;
      background: var(--tl);
      color: var(--teal);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      flex-shrink: 0;
      transition: all .3s
    }

    .br-card:hover .br-ic {
      background: var(--teal);
      color: #fff
    }

    .br-info h4 {
      font-size: .9rem;
      font-weight: 700;
      color: var(--navy);
      margin-bottom: 2px
    }

    .br-info p {
      font-size: .77rem;
      color: var(--g600);
      line-height: 1.5;
      margin: 0
    }

    .br-ph {
      font-size: .74rem;
      color: var(--teal);
      margin-top: 4px;
      font-weight: 600
    }

    .br-hr {
      font-size: .71rem;
      color: var(--g400);
      margin-top: 1px
    }

    /* Loan calculator */
    .calc-wrap {
      background: var(--nd);
      padding: 80px 0;
      position: relative;
      overflow: hidden
    }

    .calc-wrap::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse at 70% 50%, rgba(0, 122, 138, .15), transparent 60%)
    }

    .calc-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px;
      align-items: center;
      position: relative;
      z-index: 1
    }

    .calc-box {
      background: rgba(255, 255, 255, .06);
      border: 1px solid rgba(255, 255, 255, .1);
      border-radius: var(--r-xl);
      padding: 32px;
      backdrop-filter: blur(8px)
    }

    .calc-label {
      display: block;
      font-size: .72rem;
      font-weight: 700;
      color: rgba(255, 255, 255, .55);
      text-transform: uppercase;
      letter-spacing: .8px;
      margin-bottom: 8px
    }

    .calc-input {
      width: 100%;
      background: rgba(255, 255, 255, .1);
      border: 1.5px solid rgba(255, 255, 255, .18);
      border-radius: 9px;
      padding: 11px 14px;
      font-size: .9rem;
      color: #fff;
      font-family: inherit;
      outline: none;
      transition: border .2s;
      margin-bottom: 16px
    }

    .calc-input:focus {
      border-color: var(--gold)
    }

    .calc-range {
      width: 100%;
      margin-bottom: 16px;
      accent-color: var(--gold)
    }

    .calc-result {
      background: linear-gradient(135deg, var(--navy), var(--teal));
      border-radius: var(--r-lg);
      padding: 24px;
      text-align: center
    }

    .calc-emi-lbl {
      font-size: .7rem;
      color: rgba(255, 255, 255, .6);
      text-transform: uppercase;
      letter-spacing: .8px;
      margin-bottom: 6px
    }

    .calc-emi-val {
      font-size: 2.4rem;
      font-weight: 900;
      color: #fff;
      margin-bottom: 8px
    }

    .calc-breakdown {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 12px;
      margin-top: 16px
    }

    .calc-b-item {
      background: rgba(255, 255, 255, .1);
      border-radius: 9px;
      padding: 12px;
      text-align: center
    }

    .calc-b-lbl {
      font-size: .65rem;
      color: rgba(255, 255, 255, .55);
      text-transform: uppercase;
      letter-spacing: .5px;
      margin-bottom: 4px
    }

    .calc-b-val {
      font-size: .9rem;
      font-weight: 700;
      color: #fff
    }

    /* CTA */
    .cta-sec {
      background: linear-gradient(135deg, var(--navy), var(--teal));
      padding: 88px 0;
      text-align: center;
      position: relative;
      overflow: hidden
    }

    .cta-sec::before {
      content: '';
      position: absolute;
      inset: 0;
      background: url('https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1600&q=30&auto=format')center/cover;
      opacity: .07
    }

    .cta-inner {
      position: relative;
      z-index: 1
    }

    /* Footer */
    .footer {
      background: var(--nd);
      color: rgba(255, 255, 255, .6);
      padding: 72px 0 0
    }

    .footer-grid {
      display: grid;
      grid-template-columns: 2.2fr 1fr 1fr 1.1fr;
      gap: 44px;
      margin-bottom: 52px
    }

    .footer-brand p {
      font-size: .82rem;
      line-height: 1.78;
      max-width: 300px;
      margin: 14px 0 18px
    }

    .footer-social {
      display: flex;
      gap: 9px
    }

    .footer-social a {
      width: 36px;
      height: 36px;
      border-radius: 9px;
      background: rgba(255, 255, 255, .07);
      color: rgba(255, 255, 255, .5);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: .88rem;
      transition: all .25s
    }

    .footer-social a:hover {
      background: var(--gold);
      color: var(--nd);
      transform: translateY(-2px)
    }

    .footer-col h5 {
      font-size: .86rem;
      font-weight: 700;
      color: #fff;
      margin-bottom: 16px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, .08)
    }

    .footer-col ul {
      list-style: none
    }

    .footer-col ul li {
      margin-bottom: 10px
    }

    .footer-col ul li a {
      font-size: .81rem;
      color: rgba(255, 255, 255, .48);
      transition: color .2s;
      display: flex;
      align-items: center;
      gap: 6px
    }

    .footer-col ul li a:hover {
      color: var(--gold)
    }

    .footer-col ul li a i {
      width: 13px;
      color: var(--teal);
      font-size: .75rem
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, .07);
      padding: 20px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
      font-size: .74rem
    }

    .footer-bottom a {
      color: rgba(255, 255, 255, .32);
      transition: color .2s
    }

    .footer-bottom a:hover {
      color: var(--gold)
    }

    /* Mobile nav */
    .mobile-nav {
      display: none;
      position: fixed;
      inset: 0;
      background: var(--nd);
      z-index: 9998;
      padding: 0;
      overflow-y: auto;
      flex-direction: column
    }

    .mobile-nav.open {
      display: flex;
      animation: mnSlide .3s ease
    }

    @keyframes mnSlide {
      from {
        transform: translateX(100%)
      }

      to {
        transform: translateX(0)
      }
    }

    .mn-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 24px;
      border-bottom: 1px solid rgba(255, 255, 255, .08)
    }

    .mn-close {
      background: rgba(255, 255, 255, .08);
      border: none;
      color: #fff;
      width: 38px;
      height: 38px;
      border-radius: 9px;
      cursor: pointer;
      font-size: 1.1rem;
      display: flex;
      align-items: center;
      justify-content: center
    }

    .mn-body {
      padding: 16px 24px;
      display: flex;
      flex-direction: column;
      gap: 4px;
      flex: 1
    }

    .mn-link {
      color: rgba(255, 255, 255, .72);
      padding: 13px 16px;
      border-radius: 10px;
      font-weight: 500;
      font-size: .92rem;
      transition: all .2s;
      display: flex;
      align-items: center;
      gap: 10px
    }

    .mn-link:hover,
    .mn-link.active {
      background: rgba(255, 255, 255, .08);
      color: #fff
    }

    .mn-link i {
      width: 18px;
      text-align: center;
      color: var(--teal)
    }

    .mn-div {
      height: 1px;
      background: rgba(255, 255, 255, .08);
      margin: 8px 0
    }

    .mn-foot {
      padding: 20px 24px;
      display: flex;
      flex-direction: column;
      gap: 10px
    }

    /* Scroll animations */
    .fade-up {
      opacity: 0;
      transform: translateY(30px);
      transition: opacity .7s ease, transform .7s ease
    }

    .fade-up.visible {
      opacity: 1;
      transform: translateY(0)
    }

    .d1 {
      transition-delay: .1s
    }

    .d2 {
      transition-delay: .2s
    }

    .d3 {
      transition-delay: .3s
    }

    .d4 {
      transition-delay: .4s
    }

    .d5 {
      transition-delay: .5s
    }

    .d6 {
      transition-delay: .6s
    }

    /* Responsive */
    @media(max-width:1024px) {

      .hero .container,
      .dig-grid,
      .why-grid,
      .calc-grid {
        grid-template-columns: 1fr;
        gap: 40px;
        padding-top: 80px;
        padding-bottom: 80px
      }

      .hero-visual,
      .why-img-wrap,
      .phone-wrap {
        display: none
      }

      .products-grid,
      .team-grid {
        grid-template-columns: repeat(2, 1fr)
      }

      .footer-grid {
        grid-template-columns: 1fr 1fr
      }
    }

    @media(max-width:768px) {
      .hero-title {
        font-size: 2.2rem
      }

      .hero-title .sub {
        font-size: 1.9rem
      }

      .nav-links,
      .nav-cta {
        display: none
      }

      .hamburger {
        display: flex;
        align-items: center;
        justify-content: center
      }

      .qs-grid {
        grid-template-columns: repeat(3, 1fr)
      }

      .sb-grid,
      .testi-grid,
      .br-grid {
        grid-template-columns: 1fr 1fr
      }

      .products-grid,
      .team-grid,
      .calc-grid {
        grid-template-columns: 1fr
      }

      .section {
        padding: 60px 0
      }

      .dig-feats {
        grid-template-columns: 1fr
      }
    }

    @media(max-width:480px) {

      .qs-grid,
      .sb-grid,
      .testi-grid,
      .br-grid {
        grid-template-columns: 1fr
      }

      .hero-stats {
        grid-template-columns: 1fr 1fr
      }
    }
  </style>
</head>

<body>
  <!-- Particles -->
  <div class="particles" id="particles"></div>

  <!-- TOPBAR -->
  <div class="topbar">
    <div class="container">
      <div class="tb-l">
        <a href="tel:+251115570588"><i class="fa-solid fa-phone"></i> +251 115 570 588</a>
        <a href="mailto:info@abaybank.com.et"><i class="fa-solid fa-envelope"></i> info@abaybank.com.et</a>
        <a href="#branches"><i class="fa-solid fa-location-dot"></i> 500+ Branches</a>
      </div>
      <div class="tb-r">
        <a href="#"><i class="fa-solid fa-clock"></i> Mon-Sat: 8:00 AM-17:30 PM</a>
        <button class="tb-lang"><i class="fa-solid fa-globe"></i> áŠ áˆ›áˆ­áŠ›</button>
      </div>
    </div>
  </div>

  <!-- NAVBAR -->
  <nav class="site-nav" id="site-nav">
    <div class="container">
      <div class="nav-inner">
        <a href="<?= APP_URL ?>/" class="nav-logo">
          <div class="logo-mark"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="1" y="19" width="3.5" height="6" rx="1" fill="#C8A84B" />
              <rect x="6" y="14" width="3.5" height="11" rx="1" fill="#7ecfd8" />
              <rect x="11" y="8" width="3.5" height="17" rx="1" fill="#ffffff" />
              <rect x="16" y="12" width="3.5" height="13" rx="1" fill="#7ecfd8" />
              <rect x="21" y="16" width="3.5" height="9" rx="1" fill="#C8A84B" />
              <path d="M1 22.5 Q5 20 9 22.5 Q13 25 17 22.5 Q20 20.5 25 22.5" stroke="rgba(200,168,75,0.6)" stroke-width="1.2" fill="none" stroke-linecap="round" />
            </svg></div>
          <div class="logo-text">
            <div class="am">አባይ ባንክ</div>
            <div class="en">Abay Bank S.C.</div>
          </div>
        </a>
        <ul class="nav-links">
          <li><a href="<?= APP_URL ?>/" class="active">Home</a></li>
          <li class="has-dd">
            <a href="#products">Products <i class="fa-solid fa-chevron-down" style="font-size:.55rem;margin-left:2px"></i></a>
            <div class="dd-menu">
              <a href="<?= APP_URL ?>/online/apply"><i class="fa-solid fa-piggy-bank"></i> Savings Account</a>
              <a href="<?= APP_URL ?>/online/apply"><i class="fa-solid fa-briefcase"></i> Current Account</a>
              <a href="<?= APP_URL ?>/online/apply"><i class="fa-solid fa-lock"></i> Fixed Deposit</a>
              <a href="<?= APP_URL ?>/customer-portal/auth/login.php"><i class="fa-solid fa-hand-holding-dollar"></i> Personal Loans</a>
              <a href="<?= APP_URL ?>/customer-portal/auth/login.php"><i class="fa-solid fa-building"></i> Business Loans</a>
              <a href="<?= APP_URL ?>/customer-portal/auth/login.php"><i class="fa-solid fa-credit-card"></i> ATM &amp; Cards</a>
            </div>
          </li>
          <li class="has-dd">
            <a href="#about">About <i class="fa-solid fa-chevron-down" style="font-size:.55rem;margin-left:2px"></i></a>
            <div class="dd-menu">
              <a href="#about"><i class="fa-solid fa-building-columns"></i> Our Story</a>
              <a href="#team"><i class="fa-solid fa-users"></i> Leadership Team</a>
              <a href="#branches"><i class="fa-solid fa-location-dot"></i> Find a Branch</a>
              <a href="#calc"><i class="fa-solid fa-calculator"></i> Loan Calculator</a>
            </div>
          </li>
          <li><a href="#branches">Branches</a></li>
          <li><a href="#portals" style="color:var(--gold);font-weight:600"><i class="fa-solid fa-grid-2" style="font-size:.72rem"></i> Portals</a></li>
          <li><a href="<?= APP_URL ?>/atm"><i class="fa-solid fa-tv" style="font-size:.72rem"></i> ATM Sim</a></li>
          <li><a href="#footer">Contact</a></li>
        </ul>
        <div class="nav-cta">
          <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="btn btn-outline" style="padding:8px 14px;font-size:.8rem"><i class="fa-solid fa-user"></i> Customer</a>
          <a href="<?= APP_URL ?>/employee-portal/auth/login.php" class="btn btn-outline" style="padding:8px 14px;font-size:.8rem"><i class="fa-solid fa-id-badge"></i> Employee</a>
          <a href="<?= APP_URL ?>/login" class="btn btn-primary" style="padding:8px 14px;font-size:.8rem"><i class="fa-solid fa-lock"></i> Staff</a>
        </div>
        <button class="hamburger" id="hamburger" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
      </div>
    </div>
  </nav>

  <!-- HERO -->
  <section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-grad"></div>
    <div class="hero-g1"></div>
    <div class="hero-g2"></div>
    <div class="container">
      <div>
        <div class="hero-tag"><span class="dot"></span> NBE Licensed &middot; SWIFT: ABYAETAA &middot; Est. 2010</div>
        <h1 class="hero-title">Banking Built<span class="accent">for Every</span><span class="sub">Ethiopian</span></h1>
        <p class="hero-desc">Abay Bank S.C. delivers <strong>modern, accessible banking</strong> across Ethiopia â€” savings, loans, digital transfers, and more. Trusted by over <strong>2 million customers</strong> nationwide.</p>
        <div class="hero-actions">
          <a href="<?= APP_URL ?>/online/apply" class="btn btn-gold btn-lg"><i class="fa-solid fa-user-plus"></i> Open an Account</a>
          <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="btn btn-glass btn-lg"><i class="fa-solid fa-mobile-screen"></i> Online Banking</a>
        </div>
        <div class="hero-stats">
          <div class="hero-stat">
            <div class="n"><span class="counter" data-t="500">0</span>+</div>
            <div class="l">Branches</div>
          </div>
          <div class="hero-stat">
            <div class="n"><span class="counter" data-t="2">0</span>M+</div>
            <div class="l">Customers</div>
          </div>
          <div class="hero-stat">
            <div class="n" style="font-size:1.3rem">ETB 50B+</div>
            <div class="l">Total Assets</div>
          </div>
          <div class="hero-stat">
            <div class="n"><span class="counter" data-t="15">0</span>+</div>
            <div class="l">Years Service</div>
          </div>
        </div>
      </div>
      <div class="hero-visual">
        <img src="https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=700&q=85&auto=format&fit=crop" alt="Abay Bank Customer Service" class="hero-img-main" loading="eager">
        <img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&q=80&auto=format&fit=crop" alt="Banking" class="hero-img-card" loading="eager">
        <div class="fb fb1">
          <div class="fb-ic fb-green"><i class="fa-solid fa-arrow-trend-up"></i></div>
          <div>
            <div class="fb-num">ETB 1.2B</div>
            <div class="fb-lbl">Deposits Today</div>
          </div>
        </div>
        <div class="fb fb2">
          <div class="fb-ic fb-teal"><i class="fa-solid fa-shield-halved"></i></div>
          <div>
            <div class="fb-num">100%</div>
            <div class="fb-lbl">NBE Compliant</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- QUICK SERVICES -->
  <div class="qs-wrap">
    <div class="container">
      <div class="qs-grid">
        <a href="<?= APP_URL ?>/online/apply" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-piggy-bank"></i></div>
          <div class="qs-label">Open Account</div>
        </a>
        <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-right-left"></i></div>
          <div class="qs-label">Fund Transfer</div>
        </a>
        <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
          <div class="qs-label">Apply Loan</div>
        </a>
        <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-credit-card"></i></div>
          <div class="qs-label">ATM &amp; Cards</div>
        </a>
        <a href="<?= APP_URL ?>/atm" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-tv"></i></div>
          <div class="qs-label">ATM Simulator</div>
        </a>
        <a href="#branches" class="qs-item">
          <div class="qs-icon"><i class="fa-solid fa-location-dot"></i></div>
          <div class="qs-label">Find Branch</div>
        </a>
      </div>
    </div>
  </div>

  <!-- PRODUCTS -->
  <section class="section sec-gray" id="products">
    <div class="container">
      <div class="section-header fade-up">
        <div class="tag"><i class="fa-solid fa-layer-group"></i> Our Products</div>
        <h2 class="section-title">Complete Banking Solutions</h2>
        <p class="section-desc">From everyday savings to large business financing â€” Abay Bank has the right product for you.</p>
      </div>
      <div class="products-grid">
        <?php
        $products = [
          ['Savings Account',  'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=600&q=80&auto=format', 'fa-piggy-bank',         '7.5%', 'p.a. interest',   APP_URL . '/online/apply',  'Open Account', 'Free ATM card|Mobile banking|Min. ETB 100|24/7 ATM access'],
          ['Current Account',  'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&q=80&auto=format', 'fa-briefcase',          'No',   'minimum balance', APP_URL . '/online/apply',  'Open Account', 'Free cheque book|Overdraft facility|Corporate banking|Rel. manager'],
          ['Fixed Deposit',    'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=600&q=80&auto=format', 'fa-lock',               '12%',  'p.a. guaranteed', APP_URL . '/online/apply',  'Invest Now',   'Guaranteed returns|Flexible 3â€“60 months|Auto-renewal|Min. ETB 5,000'],
          ['Personal Loan',    'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&q=80&auto=format', 'fa-hand-holding-dollar', '12%',  'from p.a.',       APP_URL . '/customer-portal/auth/login.php', 'Apply Now',    'Up to ETB 500,000|12â€“60 month terms|Approval 48hrs|No hidden fees'],
          ['Business Loan',    'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=80&auto=format', 'fa-building',           '10.5%', 'from p.a.',       APP_URL . '/customer-portal/auth/login.php', 'Apply Now',    'Up to ETB 10,000,000|Collateral-flexible|Up to 10-year terms|SME priority'],
          ['Digital Banking',  'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600&q=80&auto=format', 'fa-mobile-screen',      '24/7', 'access anywhere', APP_URL . '/customer-portal/auth/login.php', 'Get Started',  'EthSwitch transfers|Telebirr & M-Pesa|Bill payments|Real-time alerts'],
        ];
        $delays = ['d1', 'd2', 'd3', 'd4', 'd5', 'd6'];
        foreach ($products as $i => [$title, $img, $icon, $rate, $rl, $link, $cta, $feats]):
          $fl = explode('|', $feats);
        ?>
          <div class="p-card fade-up <?= $delays[$i] ?>">
            <div class="p-img-wrap"><img src="<?= $img ?>" alt="<?= $title ?>" class="p-img" loading="lazy"></div>
            <div class="p-body">
              <div class="p-icon"><i class="fa-solid <?= $icon ?>"></i></div>
              <h3><?= $title ?></h3>
              <div class="p-rate"><span class="r"><?= $rate ?></span><span class="rl">&nbsp;<?= $rl ?></span></div>
              <ul class="p-features">
                <?php foreach ($fl as $f): ?><li><i class="fa-solid fa-circle-check"></i><?= $f ?></li><?php endforeach; ?>
              </ul>
              <a href="<?= $link ?>" class="p-link"><?= $cta ?> <i class="fa-solid fa-arrow-right"></i></a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- STATS BAND -->
  <div class="stats-band">
    <div class="container">
      <div class="sb-grid">
        <div class="sb-item fade-up">
          <div class="sb-num"><span class="counter" data-t="500">0</span><span class="suf">+</span></div>
          <div class="sb-lbl">Branch Offices</div>
        </div>
        <div class="sb-item fade-up d1">
          <div class="sb-num"><span class="counter" data-t="2">0</span><span class="suf">M+</span></div>
          <div class="sb-lbl">Happy Customers</div>
        </div>
        <div class="sb-item fade-up d2">
          <div class="sb-num">ETB 50<span class="suf">B+</span></div>
          <div class="sb-lbl">Total Assets</div>
        </div>
        <div class="sb-item fade-up d3">
          <div class="sb-num"><span class="counter" data-t="4500">0</span><span class="suf">+</span></div>
          <div class="sb-lbl">Staff Members</div>
        </div>
      </div>
    </div>
  </div>

  <!-- DIGITAL BANKING -->
  <section class="digital-sec">
    <div class="container">
      <div class="dig-grid">
        <div>
          <div class="tag on-dark" style="background:rgba(200,168,75,.15);color:var(--gold);border-color:rgba(200,168,75,.3)"><i class="fa-solid fa-mobile-screen"></i> Digital Banking</div>
          <h2 class="section-title on-dark fade-up" style="color:#fff;text-align:left;font-size:2rem">Bank From Anywhere<br>in Ethiopia</h2>
          <p style="color:rgba(255,255,255,.68);font-size:.95rem;line-height:1.8;margin-bottom:8px">Abay Bank's digital platform gives you full control 24/7. Transfer funds, pay bills, check balances â€” anytime, anywhere.</p>
          <div class="dig-feats">
            <?php foreach ([['fa-right-left', 'Instant Transfers', 'EthSwitch inter-bank transfers in seconds across all Ethiopian banks.'], ['fa-mobile-screen-button', 'Telebirr & M-Pesa', 'Integrated with all Ethiopian mobile money platforms.'], ['fa-shield-halved', 'Bank-Grade Security', '2FA, biometric login, and 256-bit encryption.'], ['fa-bell', 'Real-Time Alerts', 'Instant SMS & push notifications for every transaction.']] as [$ic, $ht, $hs]): ?>
              <div class="df fade-up">
                <div class="df-ic"><i class="fa-solid <?= $ic ?>"></i></div>
                <h4><?= $ht ?></h4>
                <p><?= $hs ?></p>
              </div>
            <?php endforeach; ?>
          </div>
          <div style="margin-top:28px;display:flex;gap:13px;flex-wrap:wrap">
            <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="btn btn-gold btn-lg"><i class="fa-solid fa-right-to-bracket"></i> Login Now</a>
            <a href="<?= APP_URL ?>/online/apply" class="btn btn-glass btn-lg"><i class="fa-solid fa-user-plus"></i> Open Account</a>
          </div>
        </div>
        <div class="phone-wrap">
          <img src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=500&q=85&auto=format&fit=crop" alt="Mobile Banking" class="phone-img" loading="lazy">
          <div class="pb pb1">
            <div class="pb-ic" style="background:#d1fae5;color:#059669"><i class="fa-solid fa-circle-check"></i></div>
            <div>
              <div style="font-size:.78rem;font-weight:700;color:var(--navy)">Transfer Complete</div>
              <div style="font-size:.67rem;color:var(--g400)">ETB 5,000 â†’ CBE</div>
            </div>
          </div>
          <div class="pb pb2">
            <div class="pb-ic" style="background:var(--tl);color:var(--teal)"><i class="fa-solid fa-wallet"></i></div>
            <div>
              <div style="font-size:.78rem;font-weight:700;color:var(--navy)">Balance</div>
              <div style="font-size:.67rem;color:var(--g400)">ETB 124,560.00</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- WHY ABAY -->
  <section class="section" id="about">
    <div class="container">
      <div class="why-grid">
        <div class="why-img-wrap fade-up">
          <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&q=85&auto=format&fit=crop" alt="Abay Bank Team" class="why-img" loading="lazy">
          <div class="why-badge">
            <div class="bn">15+</div>
            <div class="bl">Years of Banking<br>Excellence</div>
          </div>
        </div>
        <div>
          <div class="tag"><i class="fa-solid fa-award"></i> Why Choose Us</div>
          <h2 class="section-title fade-up" style="text-align:left">A Bank Built for<br>Ethiopians, By Ethiopians</h2>
          <p style="font-size:.94rem;color:var(--g600);line-height:1.8;margin-bottom:6px">Established in 2010, Abay Bank S.C. delivers modern, inclusive financial services across Ethiopia â€” from Addis Ababa's business districts to rural farming communities.</p>
          <div class="why-pts">
            <?php foreach ([['fa-shield-halved', 'Bank-Grade Security', 'Fully NBE licensed. SWIFT-enabled (ABYAETAA), EthSwitch-connected, biometric ATM authentication.'], ['fa-map-location-dot', '500+ Branches Nationwide', 'From Addis Ababa to Gambella, from Mekelle to Moyale â€” banking everywhere.'], ['fa-leaf', 'Community Focus', 'Special loans for farmers, SMEs & cooperatives. Financial literacy programs nationwide.'], ['fa-clock', '24/7 Customer Support', 'Dedicated support via phone, email, and in-branch around the clock.']] as [$ic, $ht, $hd]): ?>
              <div class="why-pt fade-up">
                <div class="wp-ic"><i class="fa-solid <?= $ic ?>"></i></div>
                <div class="wp-t">
                  <h4><?= $ht ?></h4>
                  <p><?= $hd ?></p>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TEAM -->
  <section class="section sec-gray" id="team">
    <div class="container">
      <div class="section-header fade-up">
        <div class="tag"><i class="fa-solid fa-users"></i> Our People</div>
        <h2 class="section-title">The Team Behind Abay Bank</h2>
        <p class="section-desc">Over 5,000 dedicated professionals across 500+ branches — committed to exceptional banking service every day.</p>
      </div>

      <!-- Static 4-card grid (desktop) -->
      <div class="team-grid">
        <?php
        $teamMembers = [
          ['Yohannes Bekele',  'Branch Manager',           'Bole Branch, Addis Ababa',     'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=85&auto=format&fit=crop&crop=face'],
          ['Tigist Haile',     'Senior Customer Officer',  'Kirkos Branch, Addis Ababa',   'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=85&auto=format&fit=crop&crop=face'],
          ['Solomon Girma',    'Senior Loan Officer',      'Bahir Dar Main Branch',        'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=85&auto=format&fit=crop&crop=face'],
          ['Hanna Tadesse',    'Head of Digital Banking',  'Head Office, Addis Ababa',     'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=85&auto=format&fit=crop&crop=face'],
        ];
        foreach ($teamMembers as $i => [$tn, $tr, $tb, $ti]): ?>
          <div class="tm-card fade-up d<?= $i + 1 ?>">
            <img src="<?= $ti ?>" alt="<?= $tn ?>" class="tm-img" loading="lazy"
              onerror="this.src='https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=80&auto=format'">
            <div class="tm-body">
              <h4><?= $tn ?></h4>
              <div class="tm-role"><?= $tr ?></div>
              <div class="tm-br"><i class="fa-solid fa-location-dot" style="color:var(--teal);margin-right:3px;font-size:.65rem"></i><?= $tb ?></div>
              <div class="tm-social">
                <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                <a href="#" aria-label="Email"><i class="fa-solid fa-envelope"></i></a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══════════════════════════════════════════════════════════
       ANIMATED PEOPLE GALLERY — infinite scroll marquee
  ═══════════════════════════════════════════════════════════ -->
  <section class="people-section" id="people-gallery">
    <div class="people-header container fade-up">
      <div class="tag" style="margin:0 auto 14px"><i class="fa-solid fa-camera"></i> Our Community</div>
      <h2 class="section-title" style="text-align:center;margin-bottom:8px">Real People. Real Impact.</h2>
      <p class="section-desc" style="text-align:center">Customers, entrepreneurs, farmers and families — all served by Abay Bank across Ethiopia.</p>
    </div>

    <!-- Row 1: scrolls left -->
    <div class="marquee-wrap" aria-hidden="true">
      <div class="marquee marquee-left">
        <?php
        $galleryRow1 = [
          ['Business owner at market', 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Bank branch exterior',    'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Professional woman',      'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Farmer in field',         'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Young entrepreneur',      'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Woman banking',           'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Busy city street',        'https://images.unsplash.com/photo-1508672019048-805c876b67e2?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Professional man',        'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Market vendor',           'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Office worker',           'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
        ];
        // Duplicate for seamless loop
        $row1All = array_merge($galleryRow1, $galleryRow1);
        foreach ($row1All as [$alt, $src]): ?>
          <div class="mq-card">
            <img src="<?= $src ?>" alt="<?= htmlspecialchars($alt) ?>" loading="lazy"
              onerror="this.parentElement.style.display='none'">
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Row 2: scrolls right (opposite) -->
    <div class="marquee-wrap" aria-hidden="true">
      <div class="marquee marquee-right">
        <?php
        $galleryRow2 = [
          ['Family at branch',        'https://images.unsplash.com/photo-1511895426328-dc8714191011?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Smiling employee',        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['ATM machine use',         'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Business meeting',        'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Young woman phone',       'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Construction site',       'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Student with tablet',     'https://images.unsplash.com/photo-1529390079861-591de354faf5?w=320&h=380&q=80&auto=format&fit=crop&crop=face'],
          ['Coffee ceremony',         'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Office team',             'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=320&h=380&q=80&auto=format&fit=crop'],
          ['Loan officer desk',       'https://images.unsplash.com/photo-1553484771-047a44eee27b?w=320&h=380&q=80&auto=format&fit=crop'],
        ];
        $row2All = array_merge($galleryRow2, $galleryRow2);
        foreach ($row2All as [$alt, $src]): ?>
          <div class="mq-card">
            <img src="<?= $src ?>" alt="<?= htmlspecialchars($alt) ?>" loading="lazy"
              onerror="this.parentElement.style.display='none'">
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Stats overlay strip -->
    <div class="people-stats container">
      <?php foreach (
        [
          ['2M+',   'Customers Served',   'fa-users'],
          ['500+',  'Branches Nationwide', 'fa-building'],
          ['ETB 50B+', 'Total Assets',     'fa-coins'],
          ['15+',   'Years of Service',   'fa-calendar-check'],
          ['5,000+', 'Staff Members',      'fa-id-badge'],
          ['98%',   'Customer Satisfaction', 'fa-heart'],
        ] as [$num, $label, $icon]
      ): ?>
        <div class="people-stat fade-up">
          <i class="fa-solid <?= $icon ?>"></i>
          <div class="ps-num"><?= $num ?></div>
          <div class="ps-lbl"><?= $label ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <style>
    /* ─── People Section ─────────────────────────────────────── */
    .people-section {
      background: var(--nd);
      padding: 80px 0 0;
      overflow: hidden;
      position: relative;
    }

    .people-header {
      margin-bottom: 48px;
    }

    .people-header .section-title {
      color: #fff;
    }

    .people-header .section-desc {
      color: rgba(255, 255, 255, .6);
    }

    /* Marquee wrapper — clips overflow */
    .marquee-wrap {
      overflow: hidden;
      margin-bottom: 14px;
      mask-image: linear-gradient(to right, transparent 0%, black 8%, black 92%, transparent 100%);
      -webkit-mask-image: linear-gradient(to right, transparent 0%, black 8%, black 92%, transparent 100%);
    }

    /* The scrolling track */
    .marquee {
      display: flex;
      gap: 14px;
      width: max-content;
      will-change: transform;
    }

    .marquee-left {
      animation: scrollLeft 40s linear infinite;
    }

    .marquee-right {
      animation: scrollRight 46s linear infinite;
    }

    /* Pause on hover */
    .marquee-wrap:hover .marquee {
      animation-play-state: paused;
    }

    @keyframes scrollLeft {
      0% {
        transform: translateX(0);
      }

      100% {
        transform: translateX(-50%);
      }
    }

    @keyframes scrollRight {
      0% {
        transform: translateX(-50%);
      }

      100% {
        transform: translateX(0);
      }
    }

    /* Individual photo cards */
    .mq-card {
      flex-shrink: 0;
      width: 220px;
      height: 280px;
      border-radius: 16px;
      overflow: hidden;
      border: 2px solid rgba(255, 255, 255, .08);
      box-shadow: 0 8px 32px rgba(0, 0, 0, .4);
      transition: transform .3s, border-color .3s;
    }

    .mq-card:hover {
      transform: scale(1.04);
      border-color: var(--gold);
      z-index: 1;
    }

    .mq-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
      display: block;
      transition: transform .4s;
    }

    .mq-card:hover img {
      transform: scale(1.06);
    }

    /* Stats strip */
    .people-stats {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 0;
      padding: 36px 0;
      border-top: 1px solid rgba(255, 255, 255, .08);
      margin-top: 14px;
    }

    .people-stat {
      text-align: center;
      padding: 14px 28px;
      border-right: 1px solid rgba(255, 255, 255, .1);
      flex: 1;
      min-width: 120px;
    }

    .people-stat:last-child {
      border-right: none;
    }

    .people-stat i {
      color: var(--gold);
      font-size: 1.1rem;
      margin-bottom: 7px;
      display: block;
    }

    .ps-num {
      font-size: 1.7rem;
      font-weight: 900;
      color: #fff;
      line-height: 1;
    }

    .ps-lbl {
      font-size: .68rem;
      color: rgba(255, 255, 255, .5);
      text-transform: uppercase;
      letter-spacing: .7px;
      margin-top: 4px;
    }

    @media (max-width: 768px) {
      .mq-card {
        width: 160px;
        height: 210px;
      }

      .people-stat {
        padding: 12px 16px;
        min-width: 100px;
      }

      .ps-num {
        font-size: 1.35rem;
      }
    }
  </style>

  <!-- LOAN CALCULATOR -->
  <section class="calc-wrap" id="calc">
    <div class="container">
      <div class="calc-grid">
        <div>
          <div class="tag on-dark" style="background:rgba(200,168,75,.15);color:var(--gold);border-color:rgba(200,168,75,.3)"><i class="fa-solid fa-calculator"></i> Loan Calculator</div>
          <h2 class="section-title on-dark fade-up" style="color:#fff;text-align:left;font-size:2rem">Calculate Your<br>Loan EMI Instantly</h2>
          <p style="color:rgba(255,255,255,.65);font-size:.93rem;line-height:1.8;margin-bottom:28px">Use our free EMI calculator to estimate your monthly payments before applying. Adjust loan amount, rate, and tenure to find the plan that works best for you.</p>
          <div class="calc-box">
            <label class="calc-label">Loan Amount (ETB)</label>
            <input type="number" id="calc-amount" class="calc-input" value="100000" min="1000" oninput="calcEMI()">
            <input type="range" id="calc-amount-range" class="calc-range" min="1000" max="5000000" step="1000" value="100000" oninput="document.getElementById('calc-amount').value=this.value;calcEMI()">
            <label class="calc-label">Interest Rate (% p.a.)</label>
            <input type="number" id="calc-rate" class="calc-input" value="12" min="1" max="30" step=".5" oninput="calcEMI()">
            <label class="calc-label">Loan Tenure (Months)</label>
            <input type="number" id="calc-tenure" class="calc-input" value="24" min="1" max="360" oninput="calcEMI()">
            <input type="range" id="calc-tenure-range" class="calc-range" min="1" max="360" step="1" value="24" oninput="document.getElementById('calc-tenure').value=this.value;calcEMI()">
          </div>
        </div>
        <div>
          <div class="calc-result" id="calc-result">
            <div class="calc-emi-lbl">Monthly EMI</div>
            <div class="calc-emi-val" id="calc-emi-val">ETB 0</div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.55);margin-top:4px">per month for <span id="calc-tenure-lbl">24</span> months</div>
            <div class="calc-breakdown">
              <div class="calc-b-item">
                <div class="calc-b-lbl">Principal</div>
                <div class="calc-b-val" id="calc-principal">â€”</div>
              </div>
              <div class="calc-b-item">
                <div class="calc-b-lbl">Interest</div>
                <div class="calc-b-val" id="calc-interest" style="color:#fbbf24">â€”</div>
              </div>
              <div class="calc-b-item">
                <div class="calc-b-lbl">Total Pay</div>
                <div class="calc-b-val" id="calc-total">â€”</div>
              </div>
            </div>
            <div style="margin-top:16px">
              <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="btn btn-gold" style="width:100%;justify-content:center"><i class="fa-solid fa-paper-plane"></i> Apply for This Loan</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="section">
    <div class="container">
      <div class="section-header fade-up">
        <div class="tag"><i class="fa-solid fa-star"></i> Customer Voices</div>
        <h2 class="section-title">What Our Customers Say</h2>
        <p class="section-desc">Over 2 million Ethiopians trust Abay Bank for daily banking and business financing.</p>
      </div>
      <div class="testi-grid">
        <?php foreach (
          [
            [5, 'Abay Bank helped me get a business loan that changed my life. My restaurant now employs 12 people. The process was fast and the loan officer truly understood my business.', 'Dawit Mekonnen', 'Restaurant Owner, Addis Ababa', 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=120&q=85&auto=format&fit=crop&crop=face'],
            [5, 'The mobile banking app is fantastic. I send money to my parents in Hawassa instantly. Abay Bank truly understands modern banking needs.', 'Selamawit Girma', 'Teacher, Hawassa', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&q=85&auto=format&fit=crop&crop=face'],
            [4, 'I have saved with Abay Bank for 8 years. The fixed deposit rates are the best and the staff at Bahir Dar branch treat you like family.', 'Abebe Worku', 'Government Employee, Bahir Dar', 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&q=85&auto=format&fit=crop&crop=face'],
          ] as $i => [$stars, $txt, $name, $loc, $img]
        ): ?>
          <div class="ts-card fade-up d<?= $i + 1 ?>">
            <div class="ts-stars"><?= str_repeat('<i class="fa-solid fa-star"></i>', $stars) . ($stars < 5 ? '<i class="fa-regular fa-star"></i>' : '') ?></div>
            <p class="ts-text">"<?= $txt ?>"</p>
            <div class="ts-author"><img src="<?= $img ?>" alt="<?= $name ?>" loading="lazy">
              <div>
                <div class="ts-name"><?= $name ?></div>
                <div class="ts-loc"><?= $loc ?></div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- BRANCHES -->
  <section class="section sec-gray" id="branches">
    <div class="container">
      <div class="section-header fade-up">
        <div class="tag"><i class="fa-solid fa-map-location-dot"></i> Our Network</div>
        <h2 class="section-title">500+ Branches Across Ethiopia</h2>
        <p class="section-desc">A growing network serving every major city and rural community.</p>
      </div>
      <div class="br-grid">
        <?php foreach (
          [
            ['Bole Main Branch', 'Bole Road, Addis Ababa', '+251 115 570 588', 'Monâ€“Sat 8:00â€“17:30'],
            ['Kirkos Branch', 'Kirkos Sub-city, Addis Ababa', '+251 115 571 234', 'Monâ€“Sat 8:00â€“17:30'],
            ['Bahir Dar Branch', 'Main Street, Bahir Dar, Amhara', '+251 582 206 789', 'Monâ€“Sat 8:00â€“17:00'],
            ['Hawassa Branch', 'Commercial Area, Hawassa, SNNPR', '+251 462 205 456', 'Monâ€“Sat 8:00â€“17:00'],
            ['Dire Dawa Branch', 'Sabian Area, Dire Dawa City', '+251 251 112 345', 'Monâ€“Sat 8:00â€“17:00'],
            ['Mekelle Branch', 'CBD, Mekelle, Tigray Region', '+251 344 409 876', 'Monâ€“Sat 8:00â€“17:00'],
            ['Alem Ketema Branch', 'Main Street, Alem Ketema, North Shewa', '+251 116 782 345', 'Mon-Sat 8:00-17:00'],
          ] as $i => [$bn, $ba, $bp, $bh]
        ): ?>
          <div class="br-card fade-up d<?= ($i % 3) + 1 ?>">
            <div class="br-ic"><i class="fa-solid fa-building-columns"></i></div>
            <div class="br-info">
              <h4><?= $bn ?></h4>
              <p><?= $ba ?></p>
              <div class="br-ph"><i class="fa-solid fa-phone"></i> <?= $bp ?></div>
              <div class="br-hr"><i class="fa-solid fa-clock"></i> <?= $bh ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <div style="text-align:center;margin-top:36px" class="fade-up">
        <a href="<?= APP_URL ?>/branches" class="btn btn-primary btn-lg"><i class="fa-solid fa-map-location-dot"></i> View All Branches</a>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta-sec">
    <div class="cta-inner">
      <div class="container">
        <div style="font-size:.74rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px" class="fade-up"><i class="fa-solid fa-star" style="margin-right:5px"></i>Get Started Today</div>
        <h2 style="font-size:2.6rem;font-weight:900;color:#fff;margin-bottom:14px;line-height:1.15;letter-spacing:-.02em" class="fade-up d1">Ready to Bank Smarter?</h2>
        <p style="font-size:1rem;color:rgba(255,255,255,.72);max-width:500px;margin:0 auto 38px;line-height:1.8" class="fade-up d2">Join over 2 million Ethiopians banking with confidence. Open your account in minutes.</p>
        <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap" class="fade-up d3">
          <a href="<?= APP_URL ?>/online/apply" class="btn btn-gold btn-lg"><i class="fa-solid fa-user-plus"></i> Open Account Online</a>
          <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="btn btn-glass btn-lg"><i class="fa-solid fa-right-to-bracket"></i> Login to Online Banking</a>
        </div>
      </div>
    </div>
  </section>

  <!-- PORTALS SECTION -->
  <section style="padding:80px 0;background:linear-gradient(180deg,#f0f4f8 0%,#fff 100%)" id="portals">
    <div class="container">
      <div class="section-badge fade-up">Access Portals</div>
      <h2 class="section-title fade-up d1">Choose Your Portal</h2>
      <p class="section-sub fade-up d2">Abay Bank offers dedicated digital portals for customers, employees, and staff â€” each tailored to your specific needs.</p>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:28px;margin-top:48px">

        <!-- Customer Portal -->
        <div class="fade-up d1" style="background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.1);border:1px solid #e2e8f0;transition:transform .3s,box-shadow .3s" onmouseover="this.style.transform='translateY(-8px)';this.style.boxShadow='0 20px 60px rgba(0,0,0,.15)'" onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 8px 40px rgba(0,0,0,.1)'">
          <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);padding:32px 28px;position:relative;overflow:hidden">
            <div style="position:absolute;top:-30px;right:-30px;width:120px;height:120px;background:rgba(255,255,255,.06);border-radius:50%"></div>
            <div style="position:absolute;bottom:-20px;left:-20px;width:80px;height:80px;background:rgba(200,168,75,.15);border-radius:50%"></div>
            <div style="width:60px;height:60px;background:rgba(255,255,255,.12);border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;position:relative;z-index:1">
              <i class="fa-solid fa-user" style="font-size:1.5rem;color:#fff"></i>
            </div>
            <h3 style="color:#fff;font-size:1.25rem;font-weight:800;margin-bottom:6px;position:relative;z-index:1">Customer Portal</h3>
            <p style="color:rgba(255,255,255,.75);font-size:.85rem;position:relative;z-index:1">Online banking for account holders</p>
          </div>
          <div style="padding:24px 28px">
            <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
              <?php foreach (['View account balances & statements', 'Transfer funds & pay bills', 'Apply for loans online', 'Download transaction receipts'] as $f): ?>
                <li style="display:flex;align-items:center;gap:10px;font-size:.84rem;color:#475569">
                  <i class="fa-solid fa-circle-check" style="color:#10b981;flex-shrink:0"></i> <?= $f ?>
                </li>
              <?php endforeach; ?>
            </ul>
            <a href="<?= APP_URL ?>/customer-portal/auth/login.php" style="display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;padding:13px 20px;border-radius:12px;font-weight:700;font-size:.9rem;text-decoration:none;transition:.2s;margin-bottom:10px" onmouseover="this.style.opacity='.9'" onmouseout="this.style.opacity='1'">
              <i class="fa-solid fa-right-to-bracket"></i> Sign In to Online Banking
            </a>
            <a href="<?= APP_URL ?>/online/apply" style="display:flex;align-items:center;justify-content:center;gap:8px;background:transparent;border:2px solid #e2e8f0;color:#475569;padding:11px 20px;border-radius:12px;font-weight:600;font-size:.85rem;text-decoration:none;transition:.2s" onmouseover="this.style.borderColor='#007A8A';this.style.color='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#475569'">
              <i class="fa-solid fa-user-plus"></i> Open New Account
            </a>
          </div>
        </div>

        <!-- Employee Portal -->
        <div class="fade-up d2" style="background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.1);border:2px solid #C8A84B;transition:transform .3s,box-shadow .3s;position:relative" onmouseover="this.style.transform='translateY(-8px)';this.style.boxShadow='0 20px 60px rgba(0,0,0,.15)'" onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 8px 40px rgba(0,0,0,.1)'">
          <div style="position:absolute;top:14px;right:14px;background:#C8A84B;color:#1B3A5C;font-size:.65rem;font-weight:800;padding:4px 12px;border-radius:99px;letter-spacing:.05em;z-index:2">NEW</div>
          <div style="background:linear-gradient(135deg,#1B3A5C,#2d6a4f);padding:32px 28px;position:relative;overflow:hidden">
            <div style="position:absolute;top:-30px;right:-30px;width:120px;height:120px;background:rgba(255,255,255,.06);border-radius:50%"></div>
            <div style="position:absolute;bottom:-20px;left:-20px;width:80px;height:80px;background:rgba(200,168,75,.15);border-radius:50%"></div>
            <div style="width:60px;height:60px;background:rgba(255,255,255,.12);border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;position:relative;z-index:1">
              <i class="fa-solid fa-id-badge" style="font-size:1.5rem;color:#C8A84B"></i>
            </div>
            <h3 style="color:#fff;font-size:1.25rem;font-weight:800;margin-bottom:6px;position:relative;z-index:1">Employee Portal</h3>
            <p style="color:rgba(255,255,255,.75);font-size:.85rem;position:relative;z-index:1">Self-service for Abay Bank staff</p>
          </div>
          <div style="padding:24px 28px">
            <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
              <?php foreach (['View payslips & salary history', 'Check attendance & apply for leave', 'Track performance reviews & KPIs', 'Enroll in training programs'] as $f): ?>
                <li style="display:flex;align-items:center;gap:10px;font-size:.84rem;color:#475569">
                  <i class="fa-solid fa-circle-check" style="color:#10b981;flex-shrink:0"></i> <?= $f ?>
                </li>
              <?php endforeach; ?>
            </ul>
            <a href="<?= APP_URL ?>/employee-portal/auth/login.php" style="display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#1B3A5C,#2d6a4f);color:#fff;padding:13px 20px;border-radius:12px;font-weight:700;font-size:.9rem;text-decoration:none;transition:.2s;margin-bottom:10px" onmouseover="this.style.opacity='.9'" onmouseout="this.style.opacity='1'">
              <i class="fa-solid fa-right-to-bracket"></i> Employee Sign In
            </a>
            <a href="<?= APP_URL ?>/employee-portal/auth/login.php?tab=signup" style="display:flex;align-items:center;justify-content:center;gap:8px;background:transparent;border:2px solid #C8A84B;color:#b45309;padding:11px 20px;border-radius:12px;font-weight:600;font-size:.85rem;text-decoration:none;transition:.2s" onmouseover="this.style.background='#fef9c3'" onmouseout="this.style.background='transparent'">
              <i class="fa-solid fa-user-plus"></i> Register New Account
            </a>
          </div>
        </div>

        <!-- Staff / Admin Portal -->
        <div class="fade-up d3" style="background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.1);border:1px solid #e2e8f0;transition:transform .3s,box-shadow .3s" onmouseover="this.style.transform='translateY(-8px)';this.style.boxShadow='0 20px 60px rgba(0,0,0,.15)'" onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 8px 40px rgba(0,0,0,.1)'">
          <div style="background:linear-gradient(135deg,#0f2336,#1B3A5C);padding:32px 28px;position:relative;overflow:hidden">
            <div style="position:absolute;top:-30px;right:-30px;width:120px;height:120px;background:rgba(255,255,255,.06);border-radius:50%"></div>
            <div style="position:absolute;bottom:-20px;left:-20px;width:80px;height:80px;background:rgba(0,122,138,.2);border-radius:50%"></div>
            <div style="width:60px;height:60px;background:rgba(255,255,255,.12);border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;position:relative;z-index:1">
              <i class="fa-solid fa-shield-halved" style="font-size:1.5rem;color:#007A8A"></i>
            </div>
            <h3 style="color:#fff;font-size:1.25rem;font-weight:800;margin-bottom:6px;position:relative;z-index:1">Staff Portal</h3>
            <p style="color:rgba(255,255,255,.75);font-size:.85rem;position:relative;z-index:1">Full management system for bank staff</p>
          </div>
          <div style="padding:24px 28px">
            <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
              <?php foreach (['Full customer & account management', 'Process transactions & approvals', 'Loan management & disbursement', 'Branches, reports & administration'] as $f): ?>
                <li style="display:flex;align-items:center;gap:10px;font-size:.84rem;color:#475569">
                  <i class="fa-solid fa-circle-check" style="color:#10b981;flex-shrink:0"></i> <?= $f ?>
                </li>
              <?php endforeach; ?>
            </ul>
            <a href="<?= APP_URL ?>/login" style="display:flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#0f2336,#1B3A5C);color:#fff;padding:13px 20px;border-radius:12px;font-weight:700;font-size:.9rem;text-decoration:none;transition:.2s;margin-bottom:10px" onmouseover="this.style.opacity='.9'" onmouseout="this.style.opacity='1'">
              <i class="fa-solid fa-lock"></i> Staff Sign In
            </a>
            <a href="<?= APP_URL ?>/admin/requests" style="display:flex;align-items:center;justify-content:center;gap:8px;background:rgba(239,68,68,.12);border:2px solid rgba(239,68,68,.3);color:#ef4444;padding:11px 20px;border-radius:12px;font-weight:700;font-size:.85rem;text-decoration:none;transition:.2s;margin-bottom:10px" onmouseover="this.style.background='rgba(239,68,68,.2)'" onmouseout="this.style.background='rgba(239,68,68,.12)'">
              <i class="fa-solid fa-inbox"></i> Pending Requests Inbox
            </a>
            <a href="<?= APP_URL ?>/atm" target="_blank" style="display:flex;align-items:center;justify-content:center;gap:8px;background:transparent;border:2px solid #e2e8f0;color:#475569;padding:11px 20px;border-radius:12px;font-weight:600;font-size:.85rem;text-decoration:none;transition:.2s" onmouseover="this.style.borderColor='#1B3A5C';this.style.color='#1B3A5C'" onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#475569'">
              <i class="fa-solid fa-tv"></i> ATM Simulator
            </a>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="footer" id="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div style="display:flex;align-items:center;gap:11px;margin-bottom:0">
            <div class="logo-mark"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <rect x="1" y="19" width="3.5" height="6" rx="1" fill="#C8A84B" />
                <rect x="6" y="14" width="3.5" height="11" rx="1" fill="#7ecfd8" />
                <rect x="11" y="8" width="3.5" height="17" rx="1" fill="#ffffff" />
                <rect x="16" y="12" width="3.5" height="13" rx="1" fill="#7ecfd8" />
                <rect x="21" y="16" width="3.5" height="9" rx="1" fill="#C8A84B" />
                <path d="M1 22.5 Q5 20 9 22.5 Q13 25 17 22.5 Q20 20.5 25 22.5" stroke="rgba(200,168,75,0.6)" stroke-width="1.2" fill="none" stroke-linecap="round" />
              </svg></div>
            <div class="logo-text">
              <div class="am" style="color:#fff">አባይ ባንክ</div>
              <div class="en">Abay Bank S.C.</div>
            </div>
          </div>
          <p>Ethiopia's growing financial partner â€” modern, accessible banking since 2010. NBE Licensed Â· SWIFT: ABYAETAA</p>
          <div class="footer-social">
            <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#" aria-label="Twitter"><i class="fa-brands fa-twitter"></i></a>
            <a href="#" aria-label="Telegram"><i class="fa-brands fa-telegram"></i></a>
            <a href="#" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
            <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
          </div>
        </div>
        <div class="footer-col">
          <h5>Products</h5>
          <ul>
            <?php foreach (['Savings Account', 'Current Account', 'Fixed Deposit', 'Personal Loans', 'Business Loans', 'ATM Cards'] as $p): ?>
              <li><a href="<?= APP_URL ?>/online/apply"><i class="fa-solid fa-arrow-right"></i><?= $p ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Quick Access</h5>
          <ul>
            <li><a href="<?= APP_URL ?>/online/apply"><i class="fa-solid fa-arrow-right"></i>Open Account Online</a></li>
            <li><a href="<?= APP_URL ?>/customer-portal/auth/login.php"><i class="fa-solid fa-arrow-right"></i>Online Banking</a></li>
            <li><a href="<?= APP_URL ?>/employee-portal/auth/login.php"><i class="fa-solid fa-arrow-right"></i>Employee Portal</a></li>
            <li><a href="<?= APP_URL ?>/login"><i class="fa-solid fa-arrow-right"></i>Staff Portal</a></li>
            <li><a href="<?= APP_URL ?>/atm"><i class="fa-solid fa-arrow-right"></i>ATM Simulator</a></li>
            <li><a href="#branches"><i class="fa-solid fa-arrow-right"></i>Find a Branch</a></li>
            <li><a href="#calc"><i class="fa-solid fa-arrow-right"></i>EMI Calculator</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Contact Us</h5>
          <ul>
            <li><a href="tel:+251115570588"><i class="fa-solid fa-phone"></i>+251 115 570 588</a></li>
            <li><a href="mailto:info@abaybank.com.et"><i class="fa-solid fa-envelope"></i>info@abaybank.com.et</a></li>
            <li><a href="#"><i class="fa-solid fa-location-dot"></i>Bole Road, Addis Ababa</a></li>
            <li><a href="#"><i class="fa-solid fa-clock"></i>Monâ€“Sat: 8:00â€“17:30</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="footer-bottom">
        <span>Â© <?= date('Y') ?> Abay Bank S.C. All rights reserved. NBE Licensed.</span>
        <div style="display:flex;gap:18px"><a href="#">Privacy Policy</a><a href="#">Terms of Service</a><a href="#">Accessibility</a></div>
      </div>
    </div>
  </footer>

  <!-- MOBILE NAV -->
  <div class="mobile-nav" id="mobile-nav">
    <div class="mn-head">
      <div style="display:flex;align-items:center;gap:11px">
        <div class="logo-mark"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect x="1" y="19" width="3.5" height="6" rx="1" fill="#C8A84B" />
            <rect x="6" y="14" width="3.5" height="11" rx="1" fill="#7ecfd8" />
            <rect x="11" y="8" width="3.5" height="17" rx="1" fill="#ffffff" />
            <rect x="16" y="12" width="3.5" height="13" rx="1" fill="#7ecfd8" />
            <rect x="21" y="16" width="3.5" height="9" rx="1" fill="#C8A84B" />
            <path d="M1 22.5 Q5 20 9 22.5 Q13 25 17 22.5 Q20 20.5 25 22.5" stroke="rgba(200,168,75,0.6)" stroke-width="1.2" fill="none" stroke-linecap="round" />
          </svg></div>
        <div style="color:#fff;font-weight:800;font-size:.95rem">አባይ ባንክ</div>
      </div>
      <button class="mn-close" id="mn-close"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="mn-body">
      <a href="<?= APP_URL ?>/" class="mn-link active"><i class="fa-solid fa-house"></i>Home</a>
      <a href="#products" class="mn-link" onclick="closeMN()"><i class="fa-solid fa-layer-group"></i>Products</a>
      <a href="#about" class="mn-link" onclick="closeMN()"><i class="fa-solid fa-building-columns"></i>About Us</a>
      <a href="#branches" class="mn-link" onclick="closeMN()"><i class="fa-solid fa-location-dot"></i>Branches</a>
      <a href="#portals" class="mn-link" onclick="closeMN()" style="color:var(--gold)"><i class="fa-solid fa-grid-2"></i>Our Portals</a>
      <a href="#calc" class="mn-link" onclick="closeMN()"><i class="fa-solid fa-calculator"></i>Loan Calculator</a>
      <a href="<?= APP_URL ?>/atm" class="mn-link"><i class="fa-solid fa-tv"></i>ATM Simulator</a>
      <div class="mn-div"></div>
      <a href="<?= APP_URL ?>/online/apply" class="mn-link" style="color:var(--gold)"><i class="fa-solid fa-user-plus"></i>Open Account</a>
      <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="mn-link"><i class="fa-solid fa-user"></i>Customer Portal</a>
      <a href="<?= APP_URL ?>/employee-portal/auth/login.php" class="mn-link"><i class="fa-solid fa-id-badge"></i>Employee Portal</a>
      <a href="<?= APP_URL ?>/login" class="mn-link"><i class="fa-solid fa-lock"></i>Staff Portal</a>
    </div>
    <div class="mn-foot">
      <a href="<?= APP_URL ?>/online/apply" class="btn btn-gold" style="justify-content:center"><i class="fa-solid fa-user-plus"></i>Open Account Now</a>
    </div>
  </div>

  <script>
    // â”€â”€ Particles â”€â”€
    (function() {
      var p = document.getElementById('particles');
      if (!p) return;
      var c = ['rgba(200,168,75,.3)', 'rgba(0,122,138,.25)', 'rgba(255,255,255,.1)'];
      for (var i = 0; i < 20; i++) {
        var d = document.createElement('div');
        var s = Math.random() * 12 + 4;
        d.className = 'particle';
        d.style.cssText = 'width:' + s + 'px;height:' + s + 'px;left:' + Math.random() * 100 + '%;background:' + c[i % c.length] + ';animation-duration:' + (Math.random() * 22 + 12) + 's;animation-delay:' + (Math.random() * 8) + 's;';
        p.appendChild(d);
      }
    })();

    // â”€â”€ Navbar scroll â”€â”€
    window.addEventListener('scroll', function() {
      document.getElementById('site-nav').classList.toggle('scrolled', scrollY > 10);
    });

    // â”€â”€ Mobile nav â”€â”€
    function closeMN() {
      document.getElementById('mobile-nav').classList.remove('open');
      document.body.style.overflow = '';
    }
    document.getElementById('hamburger').addEventListener('click', function() {
      document.getElementById('mobile-nav').classList.add('open');
      document.body.style.overflow = 'hidden';
    });
    document.getElementById('mn-close').addEventListener('click', closeMN);

    // â”€â”€ Counter animation â”€â”€
    function animateCounter(el) {
      var t = parseInt(el.dataset.t, 10);
      var d = 1600,
        s = Date.now();
      (function step() {
        var p = Math.min((Date.now() - s) / d, 1);
        var e = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(e * t).toLocaleString();
        if (p < 1) requestAnimationFrame(step);
      })();
    }
    // Hero counters â€” start immediately
    document.querySelectorAll('.hero-stats .counter').forEach(animateCounter);
    // Stats band counters â€” on scroll
    var sbObs = new IntersectionObserver(function(e) {
      e.forEach(function(en) {
        if (en.isIntersecting) {
          en.target.querySelectorAll('.counter').forEach(animateCounter);
          sbObs.unobserve(en.target);
        }
      });
    }, {
      threshold: .3
    });
    var sb = document.querySelector('.stats-band');
    if (sb) sbObs.observe(sb);

    // â”€â”€ Scroll fade-in â”€â”€
    var fadeObs = new IntersectionObserver(function(e) {
      e.forEach(function(en) {
        if (en.isIntersecting) en.target.classList.add('visible');
      });
    }, {
      threshold: .1,
      rootMargin: '0px 0px -40px 0px'
    });
    document.querySelectorAll('.fade-up').forEach(function(el) {
      fadeObs.observe(el);
    });

    // â”€â”€ EMI Calculator â”€â”€
    function calcEMI() {
      var P = parseFloat(document.getElementById('calc-amount').value) || 0;
      var r = parseFloat(document.getElementById('calc-rate').value) || 12;
      var n = parseInt(document.getElementById('calc-tenure').value) || 24;
      document.getElementById('calc-amount-range').value = P;
      document.getElementById('calc-tenure-range').value = n;
      document.getElementById('calc-tenure-lbl').textContent = n;
      if (P < 1) {
        document.getElementById('calc-emi-val').textContent = 'ETB 0';
        return;
      }
      var rm = r / 1200;
      var emi = rm > 0 ? P * rm * Math.pow(1 + rm, n) / (Math.pow(1 + rm, n) - 1) : P / n;
      var total = emi * n;
      var interest = total - P;
      var fmt = function(v) {
        return 'ETB ' + Math.round(v).toLocaleString();
      };
      document.getElementById('calc-emi-val').textContent = fmt(emi);
      document.getElementById('calc-principal').textContent = fmt(P);
      document.getElementById('calc-interest').textContent = fmt(interest);
      document.getElementById('calc-total').textContent = fmt(total);
    }
    calcEMI();
  </script>
</body>

</html>