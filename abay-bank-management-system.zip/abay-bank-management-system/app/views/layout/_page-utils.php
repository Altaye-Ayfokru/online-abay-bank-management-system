<script>
  // ── Page utilities available on every staff page ──
  var ABAY = window.ABAY || {};
  ABAY.url = function(path) {
    return '<?= APP_URL ?>' + '/' + path.replace(/^\//, '');
  };
  ABAY.api = function(endpoint, opts) {
    opts = opts || {};
    var token = localStorage.getItem('abay_token') || '';
    var defaults = {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': token ? 'Bearer ' + token : ''
      }
    };
    return fetch('<?= APP_URL ?>/api' + endpoint, Object.assign({}, defaults, opts, {
      headers: Object.assign({}, defaults.headers, (opts.headers || {}))
    })).then(function(r) {
      return r.json();
    }).catch(function() {
      return null;
    });
  };
  ABAY.toast = function(msg, type) {
    type = type || 'info';
    var icons = {
      ok: 'fa-circle-check',
      err: 'fa-circle-xmark',
      info: 'fa-circle-info',
      warn: 'fa-triangle-exclamation'
    };
    var colors = {
      ok: '#d1fae5|#a7f3d0|#065f46',
      err: '#fee2e2|#fecaca|#991b1b',
      info: '#dbeafe|#bfdbfe|#1e40af',
      warn: '#fef9c3|#fef08a|#92400e'
    };
    var c = (colors[type] || colors.info).split('|');
    var el = document.createElement('div');
    el.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;align-items:center;gap:8px;padding:12px 16px;background:' + c[0] + ';border:1px solid ' + c[1] + ';color:' + c[2] + ';border-radius:10px;font-size:.84rem;box-shadow:0 6px 24px rgba(0,0,0,.14);font-family:Inter,sans-serif;max-width:320px;animation:slideInT .3s ease';
    el.innerHTML = '<i class="fa-solid ' + icons[type] + '" style="flex-shrink:0"></i><span>' + msg + '</span>';
    if (!document.getElementById('abay-toast-style')) {
      var s = document.createElement('style');
      s.id = 'abay-toast-style';
      s.textContent = '@keyframes slideInT{from{transform:translateX(110%);opacity:0}to{transform:translateX(0);opacity:1}}';
      document.head.appendChild(s);
    }
    document.body.appendChild(el);
    setTimeout(function() {
      el.style.opacity = '0';
      el.style.transform = 'translateX(110%)';
      el.style.transition = 'all .4s';
      setTimeout(function() {
        el.remove();
      }, 400);
    }, 4000);
  };
  ABAY.confirm = function(msg, onYes) {
    if (window.confirm(msg)) onYes();
  };
  ABAY.fmtETB = function(n) {
    return 'ETB ' + Number(n || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };
  ABAY.fmtNum = function(n) {
    return Number(n || 0).toLocaleString();
  };
  ABAY.relTime = function(d) {
    var diff = Math.floor((Date.now() - new Date(d)) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    return Math.floor(diff / 86400) + 'd ago';
  };
  ABAY.badge = function(status) {
    var map = {
      'Active': 'success',
      'active': 'success',
      'Completed': 'success',
      'Verified': 'success',
      'Approved': 'success',
      'Disbursed': 'success',
      'Pending': 'warning',
      'pending': 'warning',
      'Under Review': 'warning',
      'Under_Review': 'warning',
      'Inactive': 'secondary',
      'inactive': 'secondary',
      'Frozen': 'secondary',
      'Suspended': 'danger',
      'Rejected': 'danger',
      'Overdue': 'danger',
      'Blocked': 'danger',
      'Locked': 'danger',
      'Closed': 'secondary'
    };
    return '<span class="badge badge-' + (map[status] || 'info') + '">' + status + '</span>';
  };
  ABAY.setBtn = function(id, loading, html) {
    var b = document.getElementById(id);
    if (!b) return;
    if (loading) {
      b.disabled = true;
      b.innerHTML = '<span style="width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin-b .6s linear infinite;display:inline-block;vertical-align:middle;margin-right:5px"></span>Processing...';
    } else {
      b.disabled = false;
      b.innerHTML = html || 'Submit';
    }
  };
  if (!document.getElementById('abay-spin-style')) {
    var ss = document.createElement('style');
    ss.id = 'abay-spin-style';
    ss.textContent = '@keyframes spin-b{to{transform:rotate(360deg)}}';
    document.head.appendChild(ss);
  }
</script>