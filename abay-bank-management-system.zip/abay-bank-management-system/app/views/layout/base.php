<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="<?= \Web\Core\Session::csrfToken() ?>">
  <title><?= \Web\Core\View::e($pageTitle ?? APP_NAME) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/variables.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/style.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/dashboard.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/tables.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/forms.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/animations.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/utilities.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/responsive.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/dark-mode.css">
  <link rel="stylesheet" href="<?= ASSET_URL ?>/css/brand.css">
  <?php if (!empty($extraCss)): foreach ((array)$extraCss as $css): ?>
      <link rel="stylesheet" href="<?= \Web\Core\View::e($css) ?>">
  <?php endforeach;
  endif; ?>
</head>

<body>
  <div class="toast-container" id="toast-container"></div>
  <div class="app-wrapper">

    <?php include VIEW_PATH . '/layout/sidebar.php'; ?>
    <div class="sidebar-backdrop" id="sidebar-backdrop"></div>

    <div class="main-content" id="main-content">
      <?php include VIEW_PATH . '/layout/navbar.php'; ?>

      <main class="page-content" id="page-content">
        <?php
        $fe = \Web\Core\Session::flash('error');
        $fs = \Web\Core\Session::flash('success');
        $fi = \Web\Core\Session::flash('info');
        ?>
        <?php if ($fe): ?><div class="alert alert-danger" style="margin:0 0 16px;display:flex;align-items:center;gap:10px"><i class="fa-solid fa-circle-xmark"></i><?= \Web\Core\View::e($fe) ?></div><?php endif; ?>
        <?php if ($fs): ?><div class="alert alert-success" style="margin:0 0 16px;display:flex;align-items:center;gap:10px"><i class="fa-solid fa-circle-check"></i><?= \Web\Core\View::e($fs) ?></div><?php endif; ?>
        <?php if ($fi): ?><div class="alert alert-info" style="margin:0 0 16px;display:flex;align-items:center;gap:10px"><i class="fa-solid fa-circle-info"></i><?= \Web\Core\View::e($fi) ?></div><?php endif; ?>

        <?= $content ?>

      </main>
    </div><!-- end main-content -->
  </div><!-- end app-wrapper -->

  <!-- PHP → JS bridge: BASE_URL + session — MUST come before app.js loads -->
  <script>
    window.BASE_URL = '<?= APP_URL ?>';
    window.ASSET_URL = '<?= ASSET_URL ?>';
    (function() {
      var phpUser = <?= json_encode($user ?? null) ?>;
      if (phpUser) {
        var expiry = Date.now() + 7200000;
        var token = btoa(JSON.stringify({
          id: phpUser.id,
          php_session: true,
          exp: expiry
        }));
        localStorage.setItem('abay_token', token);
        localStorage.setItem('abay_expiry', String(expiry));
        localStorage.setItem('abay_user', JSON.stringify({
          id: phpUser.id,
          name: phpUser.full_name || phpUser.username,
          role: phpUser.role,
          email: phpUser.email
        }));
      }
    })();
  </script>

  <!-- Core JS -->
  <script src="<?= ASSET_URL ?>/js/path-resolver.js"></script>
  <script src="<?= ASSET_URL ?>/js/helpers.js"></script>
  <script src="<?= ASSET_URL ?>/js/validation.js"></script>
  <script src="<?= ASSET_URL ?>/js/api.js"></script>
  <script src="<?= ASSET_URL ?>/js/auth.js"></script>
  <script src="<?= ASSET_URL ?>/js/notifications.js"></script>
  <script src="<?= ASSET_URL ?>/js/search.js"></script>
  <?php if (!empty($needsCharts)): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="<?= ASSET_URL ?>/js/charts.js"></script>
  <?php endif; ?>
  <script src="<?= ASSET_URL ?>/js/app.js"></script>
  <?php if (!empty($extraJs)): foreach ((array)$extraJs as $js): ?>
      <script src="<?= \Web\Core\View::e($js) ?>"></script>
  <?php endforeach;
  endif; ?>

  <!-- ABAY global alias — all views call ABAY.api(), ABAY.toast(), ABAY.badge(), ABAY.fmtNum() -->
  <script>
    // Set alias immediately so onclick handlers can use ABAY before DOMContentLoaded
    window.ABAY = window.AbayBank || {};
    document.addEventListener('DOMContentLoaded', function() {
      window.ABAY = window.AbayBank || {};
      if (window.AbayBank && typeof window.AbayBank.init === 'function') {
        window.AbayBank.init();
      }
    });
  </script>

  <?php if (!empty($pageScript)): ?>
    <script>
      <?= $pageScript ?>
    </script>
  <?php endif; ?>

</body>

</html>