<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= \Web\Core\Session::csrfToken() ?>">
<title><?= \Web\Core\View::e($pageTitle ?? APP_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?php if (!empty($extraCss)): foreach ((array)$extraCss as $css): ?>
<link rel="stylesheet" href="<?= \Web\Core\View::e($css) ?>">
<?php endforeach; endif; ?>
</head>
<body>
<?php
$fe = \Web\Core\Session::flash('error');
$fs = \Web\Core\Session::flash('success');
?>
<?= $content ?>

<!-- PHP session → customer-auth.js bridge -->
<script>
(function(){
  var c = <?= json_encode($customer ?? null) ?>;
  if (c) {
    var expiry = Date.now() + 7200000;
    var token  = btoa(JSON.stringify({customer_id: c.id, php_session: true, exp: expiry}));
    localStorage.setItem('abay_cust_token',  token);
    localStorage.setItem('abay_cust_user',   JSON.stringify(c));
    localStorage.setItem('abay_cust_expiry', String(expiry));
  }
})();
</script>
<?php if (!empty($extraJs)): foreach ((array)$extraJs as $js): ?>
<script src="<?= \Web\Core\View::e($js) ?>"></script>
<?php endforeach; endif; ?>
</body>
</html>
