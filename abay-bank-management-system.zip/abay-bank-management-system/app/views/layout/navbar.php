<?php

use Web\Core\View;
use Web\Core\Session;

$u         = Session::getUser();
$name      = htmlspecialchars($u['full_name'] ?? $u['username'] ?? 'User');
$role      = htmlspecialchars($u['role'] ?? 'Staff');
$av        = strtoupper(substr($u['full_name'] ?? $u['username'] ?? 'U', 0, 1));

// Admin profile photo
$adminPhoto = '';
if (!empty($u['photo_path'])) {
  $photoFile = BASE_PATH . '/public/uploads/profiles/' . basename($u['photo_path']);
  if (file_exists($photoFile)) {
    $adminPhoto = APP_URL . '/public/uploads/profiles/' . basename($u['photo_path']);
  }
}

// ── Live notification data — pending requests from both portals ──────────
$navNotifs      = [];
$navTotalPending = 0;
try {
  // Use the PageController's db helper if available, else connect directly
  $ndb = \App\Config\Database::getInstance()->getConnection();

  // Pending loan applications (customer portal)
  $rows = $ndb->query("SELECT CONCAT(c.first_name,' ',c.last_name) AS name, l.loan_number AS ref, l.loan_type AS sub, l.created_at FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE l.status='Pending' ORDER BY l.created_at DESC LIMIT 4")->fetchAll(\PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $navNotifs[] = ['icon' => 'fa-file-invoice-dollar', 'color' => '#7c3aed', 'title' => 'Loan Application', 'msg' => ($r['name'] ?? 'Customer') . ' — ' . ($r['sub'] ?? 'Loan') . ' (' . ($r['ref'] ?? '') . ')', 'time' => $r['created_at'], 'link' => APP_URL . '/loans/approval', 'type' => 'loan'];
  }

  // Pending appointments (customer portal)
  $rows = $ndb->query("SELECT CONCAT(c.first_name,' ',c.last_name) AS name, a.purpose AS sub, a.appointment_date, a.created_at FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id WHERE a.status='Pending' ORDER BY a.created_at DESC LIMIT 3")->fetchAll(\PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $navNotifs[] = ['icon' => 'fa-calendar-days', 'color' => '#0d9488', 'title' => 'Appointment', 'msg' => ($r['name'] ?? 'Customer') . ' — ' . ($r['sub'] ?? 'Visit') . ' on ' . ($r['appointment_date'] ?? ''), 'time' => $r['created_at'], 'link' => APP_URL . '/support/appointments', 'type' => 'appointment'];
  }

  // Pending leave requests (employee portal)
  $rows = $ndb->query("SELECT CONCAT(e.first_name,' ',e.last_name) AS name, lr.leave_type AS sub, lr.days, lr.created_at FROM leave_requests lr LEFT JOIN employees e ON e.id=lr.employee_id WHERE lr.status='Pending' ORDER BY lr.created_at DESC LIMIT 3")->fetchAll(\PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $navNotifs[] = ['icon' => 'fa-calendar-xmark', 'color' => '#f59e0b', 'title' => 'Leave Request', 'msg' => ($r['name'] ?? 'Employee') . ' — ' . ($r['sub'] ?? 'Leave') . ' (' . (int)($r['days'] ?? 0) . ' days)', 'time' => $r['created_at'], 'link' => APP_URL . '/employees/leave', 'type' => 'leave'];
  }

  // Open complaints (customer portal)
  $rows = $ndb->query("SELECT CONCAT(c.first_name,' ',c.last_name) AS name, co.priority, co.subject AS sub, co.ticket_no, co.created_at FROM complaints co LEFT JOIN customers c ON c.id=co.customer_id WHERE co.status='Open' ORDER BY FIELD(co.priority,'Urgent','High','Medium','Low'), co.created_at DESC LIMIT 3")->fetchAll(\PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $navNotifs[] = ['icon' => 'fa-headset', 'color' => '#ef4444', 'title' => 'Complaint (' . $r['priority'] . ')', 'msg' => ($r['name'] ?? 'Customer') . ' — ' . ($r['sub'] ?? 'Issue') . ' (' . ($r['ticket_no'] ?? '') . ')', 'time' => $r['created_at'], 'link' => APP_URL . '/support/complaints', 'type' => 'complaint'];
  }

  // KYC pending
  $rows = $ndb->query("SELECT CONCAT(first_name,' ',last_name) AS name, customer_number AS ref, kyc_status, created_at FROM customers WHERE kyc_status IN('Pending','Under_Review') ORDER BY created_at DESC LIMIT 3")->fetchAll(\PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $navNotifs[] = ['icon' => 'fa-id-card', 'color' => '#3b82f6', 'title' => 'KYC Verification', 'msg' => ($r['name'] ?? 'Customer') . ' — ID verification required (' . ($r['ref'] ?? '') . ')', 'time' => $r['created_at'], 'link' => APP_URL . '/customers/kyc', 'type' => 'kyc'];
  }

  // Sort by created_at desc, take top 8
  usort($navNotifs, fn($a, $b) => strtotime($b['time'] ?? '0') - strtotime($a['time'] ?? '0'));
  $navNotifs = array_slice($navNotifs, 0, 8);
  $navTotalPending = count($navNotifs);
} catch (\Throwable $_) {
  // DB offline — show demo notifications
  $navNotifs = [
    ['icon' => 'fa-file-invoice-dollar', 'color' => '#7c3aed', 'title' => 'Loan Application', 'msg' => 'Abebe Bekele — Personal Loan (LN-2026-001)', 'time' => date('Y-m-d H:i:s', time() - 300),  'link' => APP_URL . '/loans/approval',       'type' => 'loan'],
    ['icon' => 'fa-calendar-days',      'color' => '#0d9488', 'title' => 'Appointment',      'msg' => 'Meron Alemu — Loan Consultation on ' . date('Y-m-d', strtotime('+2 days')), 'time' => date('Y-m-d H:i:s', time() - 900),  'link' => APP_URL . '/support/appointments', 'type' => 'appointment'],
    ['icon' => 'fa-calendar-xmark',     'color' => '#f59e0b', 'title' => 'Leave Request',    'msg' => 'Yohannes Bekele — Annual Leave (5 days)', 'time' => date('Y-m-d H:i:s', time() - 3600), 'link' => APP_URL . '/employees/leave',     'type' => 'leave'],
    ['icon' => 'fa-headset',            'color' => '#ef4444', 'title' => 'Complaint (High)', 'msg' => 'Tigist Haile — Wrong debit amount (CMP-2026-001)', 'time' => date('Y-m-d H:i:s', time() - 1800), 'link' => APP_URL . '/support/complaints', 'type' => 'complaint'],
    ['icon' => 'fa-id-card',            'color' => '#3b82f6', 'title' => 'KYC Verification', 'msg' => 'Solomon Girma — ID verification required', 'time' => date('Y-m-d H:i:s', time() - 7200), 'link' => APP_URL . '/customers/kyc',       'type' => 'kyc'],
  ];
  $navTotalPending = count($navNotifs);
}

// Helper: relative time
function navAgo(string $dt): string
{
  try {
    $diff = time() - (new \DateTime($dt))->getTimestamp();
    if ($diff < 60)    return 'Just now';
    if ($diff < 3600)  return round($diff / 60) . 'm ago';
    if ($diff < 86400) return round($diff / 3600) . 'h ago';
    return (new \DateTime($dt))->format('d M');
  } catch (\Throwable) {
    return '';
  }
}

// Type colors for the source badge
$typeBadge = [
  'loan'        => ['Customer',  '#007A8A'],
  'appointment' => ['Customer',  '#007A8A'],
  'complaint'   => ['Customer',  '#007A8A'],
  'kyc'         => ['Customer',  '#007A8A'],
  'leave'       => ['Employee',  '#2d6a4f'],
  'task'        => ['Employee',  '#2d6a4f'],
];
?>
<header class="navbar" id="navbar">
  <div class="navbar-left">
    <button class="navbar-toggle" id="navbar-toggle" aria-label="Toggle sidebar">
      <i class="fa-solid fa-bars"></i>
    </button>
    <div class="navbar-search">
      <i class="fa-solid fa-search navbar-search-icon"></i>
      <input type="text" id="global-search" placeholder="Search customers, accounts, transactions…" autocomplete="off">
      <kbd style="font-size:.65rem;color:#94a3b8;background:#f1f5f9;padding:2px 6px;border-radius:4px;border:1px solid #e2e8f0;margin-left:6px;white-space:nowrap">Ctrl K</kbd>
    </div>
  </div>

  <div class="navbar-right">
    <!-- Theme toggle -->
    <button class="navbar-icon-btn" id="theme-toggle" aria-label="Toggle dark mode" title="Toggle theme">
      <i class="fa-solid fa-moon" id="theme-icon"></i>
    </button>

    <!-- Quick add -->
    <div class="navbar-dropdown-wrap">
      <button class="navbar-icon-btn navbar-add-btn" data-toggle="dropdown" aria-label="Quick add" title="Quick add">
        <i class="fa-solid fa-plus"></i>
      </button>
      <div class="dropdown-menu navbar-dropdown" id="quick-add-menu">
        <div class="dropdown-header">Quick Actions</div>
        <a href="<?= APP_URL ?>/customers/register" class="dropdown-item"><i class="fa-solid fa-user-plus"></i> New Customer</a>
        <a href="<?= APP_URL ?>/accounts/opening" class="dropdown-item"><i class="fa-solid fa-folder-open"></i> Open Account</a>
        <a href="<?= APP_URL ?>/transactions/deposit" class="dropdown-item"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
        <a href="<?= APP_URL ?>/transactions/withdrawal" class="dropdown-item"><i class="fa-solid fa-arrow-up"></i> Withdrawal</a>
        <a href="<?= APP_URL ?>/transactions/transfer" class="dropdown-item"><i class="fa-solid fa-right-left"></i> Transfer</a>
        <a href="<?= APP_URL ?>/loans/apply" class="dropdown-item"><i class="fa-solid fa-file-invoice-dollar"></i> Apply Loan</a>
        <div class="dropdown-divider"></div>
        <a href="<?= APP_URL ?>/admin/requests" class="dropdown-item" style="color:#ef4444">
          <i class="fa-solid fa-inbox" style="color:#ef4444"></i> Pending Requests
          <?php if ($navTotalPending > 0): ?><span style="background:#ef4444;color:#fff;font-size:.62rem;padding:1px 6px;border-radius:99px;font-weight:700;margin-left:auto"><?= $navTotalPending ?></span><?php endif; ?>
        </a>
      </div>
    </div>

    <!-- ── NOTIFICATIONS BELL ─────────────────────────────── -->
    <div class="navbar-dropdown-wrap" id="notif-wrap">
      <button class="navbar-icon-btn navbar-notif-btn" id="notif-bell-btn" data-toggle="dropdown"
        aria-label="Notifications" title="Pending requests from portals"
        style="position:relative">
        <i class="fa-solid fa-bell" style="font-size:1.05rem"></i>
        <?php if ($navTotalPending > 0): ?>
          <span id="notif-badge" style="
          position:absolute;top:-3px;right:-3px;
          min-width:18px;height:18px;padding:0 5px;
          background:#ef4444;color:#fff;
          font-size:.62rem;font-weight:800;
          border-radius:99px;border:2px solid #fff;
          display:flex;align-items:center;justify-content:center;
          line-height:1;animation:notif-pulse 2.5s infinite;
        "><?= $navTotalPending > 99 ? '99+' : $navTotalPending ?></span>
        <?php endif; ?>
      </button>

      <!-- Notifications Dropdown -->
      <div class="dropdown-menu navbar-dropdown navbar-notif-dropdown" id="notif-menu"
        style="width:380px;max-height:520px;overflow:hidden;display:flex;flex-direction:column">

        <!-- Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 16px 10px;border-bottom:1px solid #f1f5f9;flex-shrink:0">
          <div>
            <div style="font-size:.9rem;font-weight:800;color:#1e293b">Pending Requests</div>
            <div style="font-size:.72rem;color:#94a3b8;margin-top:1px">From Customer & Employee Portals</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <?php if ($navTotalPending > 0): ?>
              <span style="background:#ef444415;color:#ef4444;font-size:.68rem;font-weight:700;padding:2px 9px;border-radius:99px"><?= $navTotalPending ?> pending</span>
            <?php endif; ?>
            <a href="<?= APP_URL ?>/admin/requests" style="font-size:.74rem;color:#007A8A;font-weight:700;text-decoration:none;padding:4px 10px;background:#e0f5f7;border-radius:6px">
              View All <i class="fa-solid fa-arrow-right" style="font-size:.6rem"></i>
            </a>
          </div>
        </div>

        <!-- Source filter tabs -->
        <div style="display:flex;gap:4px;padding:8px 14px;border-bottom:1px solid #f1f5f9;flex-shrink:0">
          <button onclick="filterNotifs('all',this)" id="ntab-all"
            style="padding:4px 12px;border:1.5px solid #1B3A5C;border-radius:99px;font-size:.72rem;font-weight:700;cursor:pointer;font-family:inherit;background:#1B3A5C;color:#fff">
            All
          </button>
          <button onclick="filterNotifs('customer',this)" id="ntab-customer"
            style="padding:4px 12px;border:1.5px solid #e2e8f0;border-radius:99px;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit;background:#fff;color:#475569">
            <i class="fa-solid fa-user" style="font-size:.65rem;color:#007A8A"></i> Customer
          </button>
          <button onclick="filterNotifs('employee',this)" id="ntab-employee"
            style="padding:4px 12px;border:1.5px solid #e2e8f0;border-radius:99px;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit;background:#fff;color:#475569">
            <i class="fa-solid fa-id-badge" style="font-size:.65rem;color:#2d6a4f"></i> Employee
          </button>
        </div>

        <!-- Notification items -->
        <div id="notif-list" style="overflow-y:auto;flex:1">
          <?php if (empty($navNotifs)): ?>
            <div style="text-align:center;padding:36px 20px;color:#94a3b8">
              <i class="fa-solid fa-check-circle" style="font-size:2rem;display:block;margin-bottom:8px;color:#10b981"></i>
              <div style="font-size:.84rem;font-weight:600">All clear!</div>
              <div style="font-size:.76rem;margin-top:3px">No pending requests from any portal</div>
            </div>
          <?php else: ?>
            <?php foreach ($navNotifs as $n):
              $portal    = $typeBadge[$n['type'] ?? ''] ?? ['Portal', '#94a3b8'];
              $portalKey = $n['type'] === 'leave' || $n['type'] === 'task' ? 'employee' : 'customer';
            ?>
              <a href="<?= htmlspecialchars($n['link'] ?? APP_URL . '/admin/requests') ?>"
                class="notif-item notif-portal-<?= $portalKey ?>"
                style="display:flex;align-items:flex-start;gap:11px;padding:11px 16px;border-bottom:1px solid #f8fafc;transition:background .15s;text-decoration:none"
                onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
                <!-- Icon -->
                <div style="width:36px;height:36px;border-radius:10px;background:<?= $n['color'] ?? '#94a3b8' ?>15;color:<?= $n['color'] ?? '#94a3b8' ?>;display:flex;align-items:center;justify-content:center;font-size:.88rem;flex-shrink:0">
                  <i class="fa-solid <?= $n['icon'] ?? 'fa-bell' ?>"></i>
                </div>
                <!-- Content -->
                <div style="flex:1;min-width:0">
                  <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px;margin-bottom:2px">
                    <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap">
                      <span style="font-size:.78rem;font-weight:700;color:#1e293b"><?= htmlspecialchars($n['title'] ?? '') ?></span>
                      <span style="font-size:.63rem;font-weight:700;padding:1px 6px;border-radius:99px;background:<?= $portal[1] ?>15;color:<?= $portal[1] ?>">
                        <?= $portal[0] ?>
                      </span>
                    </div>
                    <span style="font-size:.67rem;color:#94a3b8;flex-shrink:0;white-space:nowrap"><?= navAgo($n['time'] ?? '') ?></span>
                  </div>
                  <div style="font-size:.75rem;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($n['msg'] ?? '') ?></div>
                </div>
                <!-- Arrow -->
                <i class="fa-solid fa-chevron-right" style="color:#cbd5e1;font-size:.6rem;margin-top:4px;flex-shrink:0"></i>
              </a>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <!-- Footer -->
        <div style="padding:10px 16px;border-top:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;background:#fafafa">
          <a href="<?= APP_URL ?>/admin/requests" style="font-size:.78rem;font-weight:700;color:#1B3A5C;text-decoration:none;display:flex;align-items:center;gap:5px">
            <i class="fa-solid fa-inbox"></i> Open Requests Inbox
          </a>
          <a href="<?= APP_URL ?>/notifications" style="font-size:.74rem;color:#94a3b8;text-decoration:none">
            System notifications <i class="fa-solid fa-arrow-right" style="font-size:.58rem"></i>
          </a>
        </div>
      </div>
    </div>

    <!-- User menu -->
    <div class="navbar-dropdown-wrap">
      <button class="navbar-user-btn" data-toggle="dropdown" aria-label="User menu">
        <div class="navbar-user-av" style="overflow:hidden;border-radius:50%">
          <?php if ($adminPhoto): ?>
            <img src="<?= $adminPhoto ?>" alt="<?= $name ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800;font-size:.85rem"><?= $av ?></span>
          <?php else: ?>
            <span style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800;font-size:.85rem"><?= $av ?></span>
          <?php endif; ?>
        </div>
        <div class="navbar-user-info">
          <div class="navbar-user-name" data-user-name><?= $name ?></div>
          <div class="navbar-user-role" data-user-role><?= $role ?></div>
        </div>
        <i class="fa-solid fa-chevron-down" style="font-size:.65rem;color:#94a3b8;margin-left:4px"></i>
      </button>
      <div class="dropdown-menu navbar-dropdown navbar-user-dropdown" id="user-menu">
        <div class="dropdown-header">
          <div style="font-weight:700;color:#1e293b"><?= $name ?></div>
          <div style="font-size:.74rem;color:#94a3b8"><?= htmlspecialchars($u['email'] ?? '') ?></div>
        </div>
        <a href="<?= APP_URL ?>/admin/profile" class="dropdown-item"><i class="fa-solid fa-user-cog"></i> Profile &amp; Settings</a>
        <a href="<?= APP_URL ?>/admin/security" class="dropdown-item"><i class="fa-solid fa-lock"></i> Change Password</a>
        <a href="<?= APP_URL ?>/admin/requests" class="dropdown-item">
          <i class="fa-solid fa-inbox"></i> Pending Requests
          <?php if ($navTotalPending > 0): ?><span style="background:#ef4444;color:#fff;font-size:.62rem;padding:1px 6px;border-radius:99px;font-weight:700;margin-left:auto"><?= $navTotalPending ?></span><?php endif; ?>
        </a>
        <div class="dropdown-divider"></div>
        <a href="http://localhost/abay-bank-management-system/employee-portal/" class="dropdown-item" target="_blank"><i class="fa-solid fa-id-badge"></i> Employee Portal</a>
        <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="dropdown-item" target="_blank"><i class="fa-solid fa-user"></i> Customer Portal</a>
        <div class="dropdown-divider"></div>
        <a href="<?= APP_URL ?>/logout" class="dropdown-item dropdown-danger"><i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out</a>
      </div>
    </div>
  </div>
</header>

<style>
  /* Bell pulse animation */
  @keyframes notif-pulse {

    0%,
    100% {
      box-shadow: 0 0 0 0 rgba(239, 68, 68, .5);
    }

    50% {
      box-shadow: 0 0 0 5px rgba(239, 68, 68, 0);
    }
  }

  /* Notification dropdown wider */
  .navbar-notif-dropdown {
    padding: 0 !important;
  }
</style>
<script>
(function() {
  'use strict';

  /* ─── 1. Dropdown toggle ────────────────────────────────────────
     Toggles .open on the next sibling .dropdown-menu.
     Stops propagation so the document-level close handler doesn't
     fire immediately and collapse the menu we just opened.         */
  document.querySelectorAll('[data-toggle="dropdown"]').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var menu = btn.nextElementSibling
                 || btn.parentElement.querySelector('.dropdown-menu');
      var isOpen = menu && menu.classList.contains('open');
      document.querySelectorAll('.navbar-dropdown.open').forEach(function(m) {
        m.classList.remove('open');
      });
      if (menu && !isOpen) menu.classList.add('open');
    });
  });

  /* ─── 2. Close dropdowns on outside click ──────────────────────
     Skip if the click was INSIDE an open dropdown so that links
     inside the notification panel can actually be followed.        */
  document.addEventListener('click', function(e) {
    if (e.target.closest && e.target.closest('.navbar-dropdown')) return;
    document.querySelectorAll('.navbar-dropdown.open').forEach(function(m) {
      m.classList.remove('open');
    });
  });

  /* ─── 3. Notification items — guaranteed navigation ────────────
     Belt-and-suspenders: explicitly navigate on click so no
     CSS or event-order issue can block the <a href>.               */
  document.addEventListener('DOMContentLoaded', function() {
    var notifList = document.getElementById('notif-list');
    if (!notifList) return;
    notifList.addEventListener('click', function(e) {
      var link = e.target.closest('a.notif-item');
      if (!link) return;
      e.stopPropagation();
      var href = link.getAttribute('href');
      if (href && href !== '#') {
        document.querySelectorAll('.navbar-dropdown.open').forEach(function(m) {
          m.classList.remove('open');
        });
        window.location.href = href;
      }
    });
  });

  /* ─── 4. Notification filter tabs ──────────────────────────────*/
  window.filterNotifs = function(type, btn) {
    if (window.event) window.event.stopPropagation();
    ['all','customer','employee'].forEach(function(t) {
      var b = document.getElementById('ntab-' + t);
      if (!b) return;
      if (t === type) {
        b.style.background = '#1B3A5C'; b.style.color = '#fff'; b.style.borderColor = '#1B3A5C';
      } else {
        b.style.background = '#fff'; b.style.color = '#475569'; b.style.borderColor = '#e2e8f0';
      }
    });
    document.querySelectorAll('#notif-list .notif-item').forEach(function(el) {
      el.style.display = (type === 'all' || el.classList.contains('notif-portal-' + type)) ? '' : 'none';
    });
  };

  /* ─── 5. Auto-refresh badge every 60s ──────────────────────────*/
  (function refreshBadge() {
    setTimeout(function() {
      var base = window.BASE_URL || '';
      fetch(base + '/api/pending-count', {
        credentials: 'include',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function(r) { return r.json(); })
        .then(function(d) {
          if (!d || typeof d.count !== 'number') return;
          var badge = document.getElementById('notif-badge');
          if (d.count > 0) {
            if (!badge) {
              badge = document.createElement('span');
              badge.id = 'notif-badge';
              badge.style.cssText = [
                'position:absolute','top:-3px','right:-3px','min-width:18px','height:18px',
                'padding:0 5px','background:#ef4444','color:#fff','font-size:.62rem',
                'font-weight:800','border-radius:99px','border:2px solid #fff',
                'display:flex','align-items:center','justify-content:center',
                'line-height:1','animation:notif-pulse 2.5s infinite'
              ].join(';');
              var bellBtn = document.getElementById('notif-bell-btn');
              if (bellBtn) bellBtn.appendChild(badge);
            }
            badge.textContent = d.count > 99 ? '99+' : String(d.count);
          } else if (badge) {
            badge.remove();
          }
        }).catch(function() {});
      refreshBadge();
    }, 60000);
  })();

  /* ─── 6. Theme toggle ───────────────────────────────────────── */
  var themeBtn = document.getElementById('theme-toggle');
  var themeIc  = document.getElementById('theme-icon');
  function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    if (themeIc) themeIc.className = t === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  }
  applyTheme(localStorage.getItem('abay_theme') || 'light');
  if (themeBtn) {
    themeBtn.addEventListener('click', function() {
      var next = (document.documentElement.getAttribute('data-theme') || 'light') === 'dark' ? 'light' : 'dark';
      localStorage.setItem('abay_theme', next);
      applyTheme(next);
    });
  }

  /* ─── 7. Global search Ctrl+K ────────────────────────────────── */
  document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      var s = document.getElementById('global-search');
      if (s) { s.focus(); s.select(); }
    }
  });

  /* ─── 8. Sidebar toggle (navbar hamburger) ──────────────────── */
  var navToggle = document.getElementById('navbar-toggle');
  if (navToggle) {
    navToggle.addEventListener('click', function() {
      var sb = document.getElementById('sidebar');
      var mc = document.getElementById('main-content');
      var bd = document.getElementById('sidebar-backdrop');
      if (!sb) return;
      if (window.innerWidth <= 768) {
        sb.classList.toggle('mobile-open');
        if (bd) bd.classList.toggle('show', sb.classList.contains('mobile-open'));
      } else {
        sb.classList.toggle('collapsed');
        if (mc) mc.classList.toggle('sidebar-collapsed');
        var ic = document.getElementById('collapse-ic');
        if (ic) ic.className = sb.classList.contains('collapsed')
          ? 'fa-solid fa-angles-right' : 'fa-solid fa-angles-left';
        localStorage.setItem('abay_sidebar', sb.classList.contains('collapsed') ? 'true' : 'false');
      }
    });
  }

  /* ─── 9. Restore sidebar collapsed state on load ─────────────── */
  (function() {
    var sb = document.getElementById('sidebar');
    var mc = document.getElementById('main-content');
    if (sb && localStorage.getItem('abay_sidebar') === 'true') {
      sb.classList.add('collapsed');
      if (mc) mc.classList.add('sidebar-collapsed');
      var ic = document.getElementById('collapse-ic');
      if (ic) ic.className = 'fa-solid fa-angles-right';
    }
  })();

})(); // end IIFE
</script>
