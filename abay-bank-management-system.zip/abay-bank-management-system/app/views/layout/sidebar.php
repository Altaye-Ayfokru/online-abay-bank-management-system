<?php

use Web\Core\Session;

$u    = Session::getUser();
$name = htmlspecialchars($u['full_name'] ?? $u['username'] ?? 'User');
$role = htmlspecialchars($u['role'] ?? 'Staff');
$av   = strtoupper(substr($u['full_name'] ?? $u['username'] ?? 'U', 0, 1));

$uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$base = parse_url(APP_URL, PHP_URL_PATH) ?? '';
if ($base && str_starts_with($uri, $base)) {
  $uri = substr($uri, strlen($base));
}
$uri = '/' . ltrim($uri, '/');

// Active check — PHP 8.2 compatible (no array_any)
$isActive = function (string ...$segs) use ($uri): bool {
  foreach ($segs as $s) {
    if ($uri === $s || str_starts_with($uri, rtrim($s, '/') . '/')) return true;
  }
  return false;
};

// Helpers
$navLink = function (string $href, string $icon, string $label) use ($uri, $isActive): string {
  $a = $isActive($href);
  return sprintf(
    '<a href="%s%s" class="sbi__link%s"><i class="fa-solid %s sbi__icon"></i><span class="sbi__label">%s</span></a>',
    APP_URL,
    $href,
    ($a ? ' sbi__link--active' : ''),
    $icon,
    $label
  );
};
$sub = fn(string $href, string $icon, string $label): string =>
sprintf(
  '<a href="%s%s" class="sbi__sub%s"><i class="fa-solid %s"></i> %s</a>',
  APP_URL,
  $href,
  ($uri === $href || str_starts_with($uri, rtrim($href, '/') . '/')  ? ' sbi__sub--active' : ''),
  $icon,
  $label
);
$group = function (string $icon, string $label, string $body, bool $open): string {
  return sprintf(
    '<div class="sbi__group%s"><button type="button" class="sbi__toggle"><i class="fa-solid %s sbi__icon"></i><span class="sbi__label">%s</span><i class="fa-solid fa-chevron-down sbi__chevron"></i></button><div class="sbi__submenu">%s</div></div>',
    ($open ? ' sbi__group--open' : ''),
    $icon,
    $label,
    $body
  );
};
?>
<style>
  /* ══ SIDEBAR SCOPED STYLES ══════════════════════════════════════
   All rules prefixed with #sidebar or .sbi__ so they can never
   be overridden by global stylesheets.
   Hard-coded hex values — no CSS variables, no inheritance risk.
═══════════════════════════════════════════════════════════════ */

  /* ── Shell ── */
  #sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 260px;
    background: #112740 !important;
    display: flex;
    flex-direction: column;
    z-index: 1000;
    overflow: hidden;
    transition: width .25s ease;
    box-shadow: 2px 0 12px rgba(0, 0, 0, .25);
  }

  #sidebar.collapsed {
    width: 68px;
  }

  /* ── Brand ── */
  .sbi__brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, .08);
    min-height: 64px;
    flex-shrink: 0;
  }

  .sbi__logo-bars {
    display: flex;
    align-items: flex-end;
    gap: 3px;
    background: rgba(255, 255, 255, .1);
    border-radius: 8px;
    padding: 6px 8px 8px;
    border: 1px solid rgba(255, 255, 255, .1);
  }

  .sbi__logo-bars span {
    border-radius: 2px 2px 0 0;
    display: block;
  }

  .sbi__lb1 {
    width: 5px;
    height: 12px;
    background: #C8A84B;
  }

  .sbi__lb2 {
    width: 5px;
    height: 17px;
    background: #7ecfd8;
  }

  .sbi__lb3 {
    width: 5px;
    height: 23px;
    background: #fff;
  }

  .sbi__lb4 {
    width: 5px;
    height: 12px;
    background: #7ecfd8;
  }

  .sbi__brand-text {
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    transition: opacity .25s;
  }

  .sbi__brand-am {
    font-size: .95rem;
    font-weight: 800;
    color: #fff;
    line-height: 1.2;
  }

  .sbi__brand-en {
    font-size: .55rem;
    color: #C8A84B;
    font-weight: 700;
    letter-spacing: .1em;
    text-transform: uppercase;
  }

  #sidebar.collapsed .sbi__brand-text {
    opacity: 0;
    width: 0;
    pointer-events: none;
  }

  .sbi__collapse-btn {
    background: rgba(255, 255, 255, .08);
    border: none;
    cursor: pointer;
    color: rgba(255, 255, 255, .6);
    width: 28px;
    height: 28px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .75rem;
    flex-shrink: 0;
    margin-left: auto;
    transition: all .2s;
  }

  .sbi__collapse-btn:hover {
    background: rgba(255, 255, 255, .18);
    color: #fff;
  }

  /* ── Scroll area ── */
  .sbi__scroll {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 8px 0 16px;
  }

  .sbi__scroll::-webkit-scrollbar {
    width: 3px;
  }

  .sbi__scroll::-webkit-scrollbar-track {
    background: transparent;
  }

  .sbi__scroll::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, .15);
    border-radius: 2px;
  }

  /* ── Section titles ── */
  .sbi__section {
    padding: 14px 20px 4px;
    font-size: 9.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .1em;
    color: rgba(255, 255, 255, .3);
    white-space: nowrap;
    overflow: hidden;
  }

  #sidebar.collapsed .sbi__section {
    opacity: 0;
    height: 0;
    padding: 0;
  }

  /* ── Nav link (plain, no submenu) ── */
  .sbi__link {
    display: flex !important;
    align-items: center;
    gap: 12px;
    padding: 10px 20px;
    color: rgba(255, 255, 255, .75) !important;
    text-decoration: none !important;
    font-size: .83rem;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    border-left: 3px solid transparent;
    transition: background .2s, color .2s, border-color .2s;
    background: transparent !important;
  }

  .sbi__link:hover {
    background: rgba(255, 255, 255, .07) !important;
    color: #fff !important;
  }

  .sbi__link--active {
    background: rgba(200, 168, 75, .14) !important;
    color: #e0c472 !important;
    border-left-color: #007A8A !important;
    font-weight: 600;
  }

  /* ── Toggle button (parent with submenu) ── */
  .sbi__toggle {
    display: flex !important;
    align-items: center;
    gap: 12px;
    padding: 10px 20px;
    color: rgba(255, 255, 255, .75);
    font-size: .83rem;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    border: none;
    border-left: 3px solid transparent;
    background: transparent !important;
    width: 100%;
    text-align: left;
    cursor: pointer;
    font-family: inherit;
    transition: background .2s, color .2s;
  }

  .sbi__toggle:hover {
    background: rgba(255, 255, 255, .07) !important;
    color: #fff;
  }

  .sbi__group--open>.sbi__toggle {
    color: #e0c472;
    background: rgba(200, 168, 75, .1) !important;
    border-left-color: #007A8A;
  }

  /* ── Chevron ── */
  .sbi__chevron {
    margin-left: auto !important;
    font-size: .6rem;
    color: rgba(255, 255, 255, .4);
    transition: transform .25s ease;
    flex-shrink: 0;
  }

  .sbi__group--open>.sbi__toggle .sbi__chevron {
    transform: rotate(180deg);
    color: #C8A84B;
  }

  #sidebar.collapsed .sbi__chevron {
    display: none;
  }

  /* ── Icons ── */
  .sbi__icon {
    width: 18px;
    text-align: center;
    font-size: .95rem;
    flex-shrink: 0;
    color: rgba(255, 255, 255, .55);
  }

  .sbi__link:hover .sbi__icon,
  .sbi__link--active .sbi__icon,
  .sbi__toggle:hover .sbi__icon,
  .sbi__group--open>.sbi__toggle .sbi__icon {
    color: #C8A84B;
  }

  /* ── Label (hidden when collapsed) ── */
  .sbi__label {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    transition: opacity .2s, width .2s;
  }

  #sidebar.collapsed .sbi__label {
    opacity: 0;
    width: 0;
    pointer-events: none;
  }

  /* ── Submenu ── */
  .sbi__submenu {
    display: none;
    background: rgba(0, 0, 0, .15);
    border-left: 2px solid rgba(0, 122, 138, .4);
    margin-left: 36px;
    border-radius: 0 0 8px 8px;
  }

  .sbi__group--open>.sbi__submenu {
    display: block;
  }

  #sidebar.collapsed .sbi__submenu {
    display: none !important;
  }

  .sbi__sub {
    display: flex !important;
    align-items: center;
    gap: 9px;
    padding: 8px 16px;
    color: rgba(255, 255, 255, .55) !important;
    font-size: .79rem;
    font-weight: 500;
    text-decoration: none !important;
    border-radius: 6px;
    margin: 2px 6px;
    transition: background .2s, color .2s;
    background: transparent !important;
  }

  .sbi__sub i {
    font-size: .75rem;
    color: rgba(255, 255, 255, .35);
    width: 14px;
    text-align: center;
  }

  .sbi__sub:hover {
    background: rgba(255, 255, 255, .08) !important;
    color: #fff !important;
  }

  .sbi__sub:hover i {
    color: #C8A84B;
  }

  .sbi__sub--active {
    color: #C8A84B !important;
    background: rgba(200, 168, 75, .1) !important;
  }

  .sbi__sub--active i {
    color: #C8A84B;
  }

  /* ── Badge ── */
  .sbi__badge {
    background: #ef4444;
    color: #fff;
    font-size: 9px;
    font-weight: 700;
    padding: 1px 6px;
    border-radius: 99px;
    margin-left: auto;
  }

  #sidebar.collapsed .sbi__badge {
    display: none;
  }

  /* ── Footer ── */
  .sbi__footer {
    padding: 12px 16px;
    border-top: 1px solid rgba(255, 255, 255, .07);
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
  }

  .sbi__avatar {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: linear-gradient(135deg, #C8A84B, #e8c86a);
    color: #1B3A5C;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .9rem;
    font-weight: 800;
    flex-shrink: 0;
  }

  .sbi__uinfo {
    flex: 1;
    min-width: 0;
    overflow: hidden;
  }

  .sbi__uname {
    font-size: .8rem;
    font-weight: 700;
    color: #fff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .sbi__urole {
    font-size: .67rem;
    color: rgba(255, 255, 255, .4);
  }

  #sidebar.collapsed .sbi__uinfo {
    display: none;
  }

  .sbi__logout {
    width: 28px;
    height: 28px;
    border-radius: 7px;
    background: rgba(255, 255, 255, .06);
    color: rgba(255, 255, 255, .4);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .8rem;
    transition: all .2s;
    text-decoration: none;
    flex-shrink: 0;
  }

  .sbi__logout:hover {
    background: #ef44441a;
    color: #ef4444;
  }

  #sidebar.collapsed .sbi__logout {
    display: none;
  }

  /* ── Main content offset ── */
  .main-content {
    margin-left: 260px;
    transition: margin-left .25s ease;
  }

  .main-content.sidebar-collapsed {
    margin-left: 68px;
  }

  @media(max-width:768px) {
    .main-content {
      margin-left: 0 !important;
    }

    #sidebar {
      transform: translateX(-100%);
      transition: transform .25s ease;
    }

    #sidebar.mobile-open {
      transform: translateX(0);
    }
  }
</style>

<aside id="sidebar">

  <!-- Brand -->
  <div class="sbi__brand">
    <div class="sbi__logo-bars">
      <span class="sbi__lb1"></span><span class="sbi__lb2"></span>
      <span class="sbi__lb3"></span><span class="sbi__lb4"></span>
    </div>
    <div class="sbi__brand-text">
      <div class="sbi__brand-am">ዓባይ ባንክ</div>
      <div class="sbi__brand-en">Abay Bank S.C.</div>
    </div>
    <button class="sbi__collapse-btn" id="sidebar-collapse-btn" type="button">
      <i class="fa-solid fa-angles-left" id="collapse-ic"></i>
    </button>
  </div>

  <div class="sbi__scroll">

    <!-- ── Main ── -->
    <div class="sbi__section">Main</div>
    <?= $navLink('/dashboard', 'fa-gauge-high', 'Dashboard') ?>

    <!-- ── Banking ── -->
    <div class="sbi__section">Banking</div>

    <?= $group(
      'fa-users',
      'Customers',
      $sub('/customers/overview', 'fa-chart-pie',  'Overview') .
        $sub('/customers',         'fa-list',        'Customer List') .
        $sub('/customers/register', 'fa-user-plus',   'Register Customer') .
        $sub('/customers/kyc',     'fa-id-card',     'KYC Management'),
      $isActive('/customers', '/customers/')
    ) ?>

    <?= $group(
      'fa-building-columns',
      'Accounts',
      $sub('/accounts/opening',       'fa-folder-open',   'Open Account') .
        $sub('/accounts/savings',       'fa-piggy-bank',    'Savings') .
        $sub('/accounts/current',       'fa-briefcase',     'Current') .
        $sub('/accounts/fixed-deposit', 'fa-lock',          'Fixed Deposits') .
        $sub('/accounts/statement',     'fa-file-lines',    'Statement') .
        $sub('/accounts/atm-cards',     'fa-credit-card',   'ATM Cards') .
        $sub('/accounts/cheques',       'fa-money-check',   'Cheques'),
      $isActive('/accounts/')
    ) ?>

    <?= $group(
      'fa-credit-card',
      'Cards',
      $sub('/cards',         'fa-credit-card', 'All Cards') .
        $sub('/cards/virtual', 'fa-layer-group', 'Virtual Cards') .
        $sub('/cards/apply',   'fa-plus-circle', 'Apply / Issue Card'),
      $isActive('/cards', '/cards/')
    ) ?>

    <?= $group(
      'fa-arrow-right-arrow-left',
      'Transactions',
      $sub('/transactions/deposit',    'fa-arrow-down',        'Deposit') .
        $sub('/transactions/withdrawal', 'fa-arrow-up',          'Withdrawal') .
        $sub('/transactions/transfer',   'fa-right-left',        'Fund Transfer') .
        $sub('/transactions/interbank',  'fa-globe',             'Inter-Bank') .
        $sub('/transactions',            'fa-clock-rotate-left', 'History') .
        $sub('/transactions/approval',   'fa-circle-check',      'Approvals'),
      $isActive('/transactions', '/transactions/')
    ) ?>

    <?= $group(
      'fa-paper-plane',
      'Send Money',
      $sub('/transfers/local',         'fa-building-columns', 'Local Transfer') .
        $sub('/transfers/international', 'fa-globe',            'International Wire'),
      $isActive('/transfers/')
    ) ?>

    <?= $group(
      'fa-file-invoice-dollar',
      'Loans',
      $sub('/loans',          'fa-list',            'Loan List') .
        $sub('/loans/apply',    'fa-plus-circle',     'Apply Loan') .
        $sub('/loans/approval', 'fa-circle-check',    'Approvals') .
        $sub('/loans/payment',  'fa-money-bill-wave', 'Payments'),
      $isActive('/loans', '/loans/')
    ) ?>

    <!-- ── Online & ATM ── -->
    <div class="sbi__section">Online &amp; ATM</div>
    <?= $navLink('/online/applications', 'fa-globe', 'Online Applications') ?>
    <?php
    // Pending request counts for badges (live from DB or demo)
    $sbPendingLoans = 0;
    $sbPendingLeave = 0;
    $sbPendingAppt = 0;
    $sbPendingKYC = 0;
    $sbPendingCompl = 0;
    try {
      global $router;
      if (class_exists('App\Config\Database')) {
        $db = \App\Config\Database::getInstance()->getConnection();
        $sbPendingLoans = (int)($db->query("SELECT COUNT(*) FROM loans WHERE status='Pending'")->fetchColumn() ?? 0);
        $sbPendingLeave = (int)($db->query("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'")->fetchColumn() ?? 0);
        $sbPendingAppt  = (int)($db->query("SELECT COUNT(*) FROM appointments WHERE status='Pending'")->fetchColumn() ?? 0);
        $sbPendingKYC   = (int)($db->query("SELECT COUNT(*) FROM customers WHERE kyc_status IN('Pending','Under_Review')")->fetchColumn() ?? 0);
        $sbPendingCompl = (int)($db->query("SELECT COUNT(*) FROM complaints WHERE status='Open'")->fetchColumn() ?? 0);
      }
    } catch (\Throwable $_) {
      $sbPendingLoans = 3;
      $sbPendingLeave = 2;
      $sbPendingAppt = 5;
      $sbPendingKYC = 8;
      $sbPendingCompl = 4;
    }
    $sbTotalPending = $sbPendingLoans + $sbPendingLeave + $sbPendingAppt + $sbPendingKYC + $sbPendingCompl;
    ?>
    <!-- Pending Requests Inbox -->
    <a href="<?= APP_URL ?>/admin/requests" class="sbi__link<?= str_contains($uri, '/admin/requests') ? ' sbi__link--active' : '' ?>" style="background:<?= $sbTotalPending > 0 ? 'rgba(239,68,68,.06)' : '' ?>">
      <i class="fa-solid fa-inbox sbi__icon" style="color:<?= $sbTotalPending > 0 ? '#ef4444' : 'inherit' ?>"></i>
      <span class="sbi__label" style="font-weight:<?= $sbTotalPending > 0 ? 700 : 400 ?>">Pending Requests</span>
      <?php if ($sbTotalPending > 0): ?>
        <span class="sbi__badge" style="background:#ef4444;color:#fff"><?= $sbTotalPending ?></span>
      <?php endif; ?>
    </a>
    <!-- Customer Portal external link -->
    <a href="<?= APP_URL ?>/customer-portal/auth/login.php" class="sbi__link" target="_blank">
      <i class="fa-solid fa-user sbi__icon"></i>
      <span class="sbi__label">Customer Portal</span>
      <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.55rem;opacity:.5;margin-left:auto"></i>
    </a>
    <a href="http://localhost/abay-bank-management-system/employee-portal/" class="sbi__link" target="_blank">
      <i class="fa-solid fa-id-badge sbi__icon"></i>
      <span class="sbi__label">Employee Portal</span>
      <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.55rem;opacity:.5;margin-left:auto"></i>
    </a>
    <a href="<?= APP_URL ?>/atm" class="sbi__link" target="_blank">
      <i class="fa-solid fa-tv sbi__icon"></i>
      <span class="sbi__label">ATM Simulator</span>
      <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.55rem;opacity:.5;margin-left:auto"></i>
    </a>

    <!-- ── Human Resources ── -->
    <div class="sbi__section">Human Resources</div>

    <?= $group(
      'fa-people-group',
      'Employees',
      $sub('/employees/dashboard',   'fa-gauge-high',     'My Dashboard') .
        $sub('/employees',             'fa-list',           'Employee List') .
        $sub('/admin/attendance',      'fa-calendar-check', 'Attendance') .
        $sub('/employees/leave',       'fa-calendar-xmark', 'Leave Requests') .
        $sub('/employees/payroll',     'fa-receipt',        'Payroll') .
        $sub('/employees/performance', 'fa-chart-bar',      'Performance') .
        $sub('/employees/recruitment', 'fa-user-plus',      'Recruitment') .
        $sub('/employees/training',    'fa-graduation-cap', 'Training'),
      $isActive('/employees', '/employees/')
    ) ?>

    <!-- ── Management ── -->
    <div class="sbi__section">Management</div>

    <?= $group(
      'fa-building',
      'Branches',
      $sub('/branches',             'fa-list',      'Branch List') .
        $sub('/branches/performance', 'fa-chart-bar', 'Performance'),
      $isActive('/branches', '/branches/')
    ) ?>

    <?= $group(
      'fa-chart-pie',
      'Reports',
      $sub('/reports',            'fa-gauge-high',          'Overview') .
        $sub('/reports/financial',  'fa-chart-line',          'Financial') .
        $sub('/reports/customers',  'fa-users',               'Customers') .
        $sub('/reports/loans',      'fa-file-invoice-dollar', 'Loans') .
        $sub('/reports/attendance', 'fa-calendar-check',      'Attendance'),
      $isActive('/reports/')
    ) ?>

    <!-- ── Support ── -->
    <div class="sbi__section">Support</div>
    <a href="<?= APP_URL ?>/support/complaints" class="sbi__link<?= $uri === '/support/complaints' ? ' sbi__link--active' : '' ?>">
      <i class="fa-solid fa-headset sbi__icon"></i>
      <span class="sbi__label">Complaints</span>
      <?php if ($sbPendingCompl > 0): ?><span class="sbi__badge" style="background:#ef4444;color:#fff"><?= $sbPendingCompl ?></span><?php endif; ?>
    </a>
    <a href="<?= APP_URL ?>/support/appointments" class="sbi__link<?= $uri === '/support/appointments' ? ' sbi__link--active' : '' ?>">
      <i class="fa-solid fa-calendar-days sbi__icon"></i>
      <span class="sbi__label">Appointments</span>
      <?php if ($sbPendingAppt > 0): ?><span class="sbi__badge" style="background:#0d9488;color:#fff"><?= $sbPendingAppt ?></span><?php endif; ?>
    </a>
    <a href="<?= APP_URL ?>/notifications" class="sbi__link<?= $uri === '/notifications' ? ' sbi__link--active' : '' ?>">
      <i class="fa-solid fa-bell sbi__icon"></i>
      <span class="sbi__label">Notifications</span>
      <span class="sbi__badge">3</span>
    </a>

    <!-- ── Administration ── -->
    <div class="sbi__section">Administration</div>

    <?= $group(
      'fa-gear',
      'Administration',
      $sub('/admin/profile',          'fa-user-circle',        'My Profile') .
        $sub('/admin/users',            'fa-users-cog',          'Users') .
        $sub('/admin/roles',            'fa-user-shield',        'Roles') .
        $sub('/admin/permissions',      'fa-key',                'Permissions') .
        $sub('/admin/audit',            'fa-file-shield',        'Audit Log') .
        $sub('/admin/security',         'fa-shield-halved',      'Security') .
        $sub('/admin/attendance',       'fa-calendar-check',     'Attendance Mgmt') .
        $sub('/admin/documents',        'fa-folder-open',        'Documents') .
        $sub('/admin/inventory',        'fa-boxes-stacked',      'Inventory') .
        $sub('/admin/backup',           'fa-database',           'Backup') .
        $sub('/admin/settings',         'fa-sliders',            'Settings') .
        $sub('/admin/app-settings',     'fa-mobile-screen',      'App Settings') .
        $sub('/admin/ip-settings',      'fa-network-wired',      'IP Settings') .
        $sub('/admin/payment-settings', 'fa-money-bill-transfer', 'Payment Settings'),
      $isActive('/admin/')
    ) ?>

  </div><!-- /sbi__scroll -->

  <!-- Footer -->
  <div class="sbi__footer">
    <div class="sbi__avatar"><?= $av ?></div>
    <div class="sbi__uinfo">
      <div class="sbi__uname"><?= $name ?></div>
      <div class="sbi__urole"><?= $role ?></div>
    </div>
    <a href="<?= APP_URL ?>/logout" class="sbi__logout" title="Logout">
      <i class="fa-solid fa-arrow-right-from-bracket"></i>
    </a>
  </div>

</aside>

<script>
  // ── Sidebar submenu toggle — runs inline, DOM node exists above ──
  (function() {
    var sidebar = document.getElementById('sidebar');
    if (!sidebar) return;

    // Click delegation: toggle button opens/closes submenu
    sidebar.addEventListener('click', function(e) {
      var btn = e.target.closest('.sbi__toggle');
      if (!btn) return;
      var group = btn.closest('.sbi__group');
      var wasOpen = group.classList.contains('sbi__group--open');
      // Close all
      sidebar.querySelectorAll('.sbi__group--open').forEach(function(g) {
        g.classList.remove('sbi__group--open');
      });
      // Open if was closed
      if (!wasOpen) group.classList.add('sbi__group--open');
    });

    // Collapse button
    var collapseBtn = document.getElementById('sidebar-collapse-btn');
    if (collapseBtn) {
      collapseBtn.addEventListener('click', function() {
        var sb = document.getElementById('sidebar');
        var mc = document.getElementById('main-content');
        if (!sb) return;
        sb.classList.toggle('collapsed');
        if (mc) mc.classList.toggle('sidebar-collapsed');
        var ic = document.getElementById('collapse-ic');
        if (ic) ic.className = sb.classList.contains('collapsed') ?
          'fa-solid fa-angles-right' :
          'fa-solid fa-angles-left';
        localStorage.setItem('abay_sidebar', sb.classList.contains('collapsed') ? 'true' : 'false');
      });
    }

    // Restore collapsed state
    if (localStorage.getItem('abay_sidebar') === 'true' && window.innerWidth > 768) {
      sidebar.classList.add('collapsed');
      var mc = document.getElementById('main-content');
      if (mc) mc.classList.add('sidebar-collapsed');
      var ic = document.getElementById('collapse-ic');
      if (ic) ic.className = 'fa-solid fa-angles-right';
    }
  })();
</script>