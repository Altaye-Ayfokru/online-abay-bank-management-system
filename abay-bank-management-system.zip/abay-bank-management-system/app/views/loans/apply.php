﻿<?php $pageTitle = 'Apply Loan — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Apply for Loan</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><a href="<?= APP_URL ?>/loans">Loans</a><span class="sep">/</span><span>Apply</span></div>
  </div>
  <a href="<?= APP_URL ?>/loans" class="btn btn-ghost btn-sm"><i class="fa-solid fa-arrow-left"></i> Back</a>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px">
  <div>
    <div id="loan-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:12px;padding:20px;margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:12px"><i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.5rem"></i>
        <div>
          <div style="font-weight:800;color:#065f46;font-size:1rem">Loan Application Submitted!</div>
          <div style="font-size:.84rem;color:#047857" id="loan-ok-msg"></div>
        </div>
      </div>
      <div style="margin-top:14px;display:flex;gap:10px">
        <button onclick="resetLoanForm()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-plus"></i> New Application</button>
        <a href="<?= APP_URL ?>/loans" class="btn btn-ghost btn-sm"><i class="fa-solid fa-list"></i> View All Loans</a>
      </div>
    </div>
    <div id="loan-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:13px;margin-bottom:16px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px">
      <i class="fa-solid fa-circle-xmark"></i><span id="loan-err-msg"></span>
    </div>

    <form id="loan-form" novalidate>
      <!-- Applicant -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header">
          <h3><i class="fa-solid fa-user" style="color:#1B3A5C;margin-right:7px"></i>Applicant Information</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Customer Name / ID <span style="color:#ef4444">*</span></label>
              <input type="text" id="loan-customer" placeholder="Search customer name or ID..." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'" oninput="lookupLoanCustomer(this.value)">
              <?php if (!empty($customers)): ?>
                <datalist id="customers-list">
                  <?php foreach ($customers as $c): ?>
                    <option value="<?= \Web\Core\View::e($c['name']) ?>" data-id="<?= $c['id'] ?>">
                      <?php endforeach; ?>>
                </datalist>
              <?php endif; ?>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Linked Account</label>
              <input type="text" id="loan-account" readonly placeholder="Auto-filled from customer" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
        </div>
      </div>

      <!-- Loan Details -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header">
          <h3><i class="fa-solid fa-file-invoice-dollar" style="color:#1B3A5C;margin-right:7px"></i>Loan Details</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Loan Type <span style="color:#ef4444">*</span></label>
              <select id="loan-type" onchange="setLoanDefaults()" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option value="">Select type...</option>
                <option value="Personal" data-rate="14" data-max="500000" data-maxterm="60">Personal Loan</option>
                <option value="Business" data-rate="11" data-max="5000000" data-maxterm="120">Business Loan</option>
                <option value="Mortgage" data-rate="9" data-max="20000000" data-maxterm="240">Mortgage Loan</option>
                <option value="Agricultural" data-rate="8" data-max="2000000" data-maxterm="84">Agricultural Loan</option>
                <option value="Student" data-rate="7" data-max="300000" data-maxterm="60">Student Loan</option>
                <option value="Emergency" data-rate="16" data-max="100000" data-maxterm="24">Emergency Loan</option>
              </select>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Loan Amount (ETB) <span style="color:#ef4444">*</span></label>
              <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden" id="amt-wrap">
                <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                <input type="number" id="loan-amount" min="1000" step="1000" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.87rem;outline:none;background:#fff" oninput="calcEMI()" onfocus="document.getElementById('amt-wrap').style.borderColor='#007A8A'" onblur="document.getElementById('amt-wrap').style.borderColor='#e2e8f0'">
              </div>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Interest Rate (% p.a.) <span style="color:#ef4444">*</span></label>
              <input type="number" id="loan-interest" value="12" step="0.5" min="1" max="30" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" oninput="calcEMI()" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Term (Months) <span style="color:#ef4444">*</span></label>
              <select id="loan-term" onchange="calcEMI()" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option value="6">6 Months</option>
                <option value="12">12 Months</option>
                <option value="24" selected>24 Months</option>
                <option value="36">36 Months</option>
                <option value="48">48 Months</option>
                <option value="60">60 Months</option>
                <option value="84">84 Months</option>
                <option value="120">120 Months</option>
              </select>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Repayment Mode</label>
              <select id="loan-repay" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option>Monthly EMI</option>
                <option>Quarterly</option>
                <option>Bullet</option>
              </select>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Disbursement To</label>
              <select id="loan-disburse" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option>Savings Account</option>
                <option>Current Account</option>
              </select>
            </div>
          </div>
          <div>
            <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Loan Purpose <span style="color:#ef4444">*</span></label>
            <textarea id="loan-purpose" rows="3" placeholder="Describe the purpose of the loan in detail (minimum 20 characters)..." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;resize:none;outline:none;font-family:inherit" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></textarea>
          </div>
        </div>
      </div>

      <!-- Collateral -->
      <div class="card" style="margin-bottom:18px">
        <div class="card-header">
          <h3><i class="fa-solid fa-shield-halved" style="color:#1B3A5C;margin-right:7px"></i>Collateral (Optional)</h3>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Collateral Type</label>
              <select id="loan-collateral" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                <option value="">None</option>
                <option>Real Estate</option>
                <option>Vehicle</option>
                <option>Fixed Deposit</option>
                <option>Business Assets</option>
                <option>Guarantor</option>
              </select>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Collateral Value (ETB)</label>
              <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden">
                <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                <input type="number" id="loan-collateral-val" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.87rem;outline:none;background:#fff">
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:12px;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" onclick="resetLoanForm()"><i class="fa-solid fa-rotate"></i> Reset</button>
        <button type="submit" id="loan-submit-btn" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border:none;color:#fff;padding:13px 32px;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i> Submit Application</button>
      </div>
    </form>
  </div>

  <!-- EMI Calculator + Products -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-calculator" style="color:#1B3A5C;margin-right:6px"></i>EMI Calculator</h4>
      </div>
      <div class="card-body">
        <div style="text-align:center;padding:16px 0;background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:12px;margin-bottom:16px">
          <div style="font-size:.68rem;color:rgba(255,255,255,.65);text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px">Monthly EMI</div>
          <div style="font-size:2rem;font-weight:900;color:#fff" id="emi-amount">—</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:9px">
          <?php foreach ([['Principal', 'emi-principal', '#1B3A5C'], ['Total Interest', 'emi-interest', '#ef4444'], ['Total Repayment', 'emi-total', '#007A8A'], ['Loan-to-Value', 'emi-ltv', '#C8A84B']] as [$l, $id, $c]): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
              <span style="font-size:.79rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
              <span style="font-size:.84rem;font-weight:700;color:<?= $c ?>" id="<?= $id ?>">—</span>
            </div>
          <?php endforeach; ?>
        </div>
        <div style="margin-top:16px"><canvas id="emi-chart" height="160"></canvas></div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-circle-info" style="color:#1B3A5C;margin-right:6px"></i>Loan Products</h4>
      </div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:10px">
        <?php foreach (
          [
            ['Personal', '14–18%', 'Up to ETB 500K', '60 months', '#dbeafe', '#1d4ed8'],
            ['Business', '10–15%', 'Up to ETB 5M', '120 months', '#dcfce7', '#15803d'],
            ['Mortgage', '8–12%', 'Up to ETB 20M', '240 months', '#fef3c7', '#92400e'],
            ['Agricultural', '7–10%', 'Up to ETB 2M', '84 months', '#f0fdf4', '#166534'],
          ] as [$n, $r, $m, $lt, $bg, $tc]
        ): ?>
          <div style="background:<?= $bg ?>;border-radius:9px;padding:11px 14px;cursor:pointer" onclick="document.getElementById('loan-type').value=<?= json_encode($n) ?>;setLoanDefaults()">
            <div style="font-size:.84rem;font-weight:700;color:<?= $tc ?>"><?= $n ?> Loan</div>
            <div style="font-size:.76rem;color:#64748b;margin-top:2px"><?= $r ?> &middot; <?= $m ?> &middot; <?= $lt ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _loanEmiChart = null;

  function lookupLoanCustomer(val) {
    if (val.length < 3) return;
    clearTimeout(window._lct);
    window._lct = setTimeout(function() {
      ABAY.api('/customers?search=' + encodeURIComponent(val) + '&per_page=5').then(function(d) {
        if (d && d.success && d.data && d.data[0]) {
          var c = d.data[0];
          document.getElementById('loan-account').value = c.account_number || (c.accounts && c.accounts[0] && c.accounts[0].account_number) || '';
        }
      }).catch(function() {});
    }, 600);
  }

  function setLoanDefaults() {
    var sel = document.getElementById('loan-type');
    var opt = sel.options[sel.selectedIndex];
    if (opt && opt.dataset.rate) {
      document.getElementById('loan-interest').value = opt.dataset.rate;
      calcEMI();
    }
  }

  function calcEMI() {
    var P = parseFloat(document.getElementById('loan-amount').value) || 0;
    var r = parseFloat(document.getElementById('loan-interest').value) || 12;
    var n = parseInt(document.getElementById('loan-term').value) || 24;
    if (P < 1) {
      ['emi-amount', 'emi-principal', 'emi-interest', 'emi-total', 'emi-ltv'].forEach(function(id) {
        document.getElementById(id).textContent = '—';
      });
      return;
    }
    var rm = r / 1200;
    var emi = rm > 0 ? P * rm * Math.pow(1 + rm, n) / (Math.pow(1 + rm, n) - 1) : P / n;
    var total = emi * n;
    var interest = total - P;
    document.getElementById('emi-amount').textContent = ABAY.fmtETB(Math.round(emi));
    document.getElementById('emi-principal').textContent = ABAY.fmtETB(P);
    document.getElementById('emi-interest').textContent = ABAY.fmtETB(Math.round(interest));
    document.getElementById('emi-total').textContent = ABAY.fmtETB(Math.round(total));
    document.getElementById('emi-ltv').textContent = (r) + '%';
    drawEmiChart(P, Math.round(interest));
  }

  function drawEmiChart(principal, interest) {
    if (typeof Chart === 'undefined') return;
    var ctx = document.getElementById('emi-chart').getContext('2d');
    if (_loanEmiChart) _loanEmiChart.destroy();
    _loanEmiChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Principal', 'Interest'],
        datasets: [{
          data: [principal, interest],
          backgroundColor: ['#1B3A5C', '#ef4444'],
          borderWidth: 3,
          borderColor: '#fff',
          hoverOffset: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: {
                size: 11
              },
              padding: 10
            }
          }
        }
      }
    });
  }

  function resetLoanForm() {
    document.getElementById('loan-form').reset();
    document.getElementById('loan-form').style.display = '';
    document.getElementById('loan-success').style.display = 'none';
    document.getElementById('loan-error').style.display = 'none';
    ['emi-amount', 'emi-principal', 'emi-interest', 'emi-total', 'emi-ltv'].forEach(function(id) {
      document.getElementById(id).textContent = '—';
    });
  }

  document.getElementById('loan-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var customer = document.getElementById('loan-customer').value.trim();
    var type = document.getElementById('loan-type').value;
    var amount = parseFloat(document.getElementById('loan-amount').value) || 0;
    var rate = parseFloat(document.getElementById('loan-interest').value) || 0;
    var term = parseInt(document.getElementById('loan-term').value) || 0;
    var purpose = document.getElementById('loan-purpose').value.trim();
    document.getElementById('loan-error').style.display = 'none';
    if (!customer) {
      document.getElementById('loan-err-msg').textContent = 'Customer name/ID is required.';
      document.getElementById('loan-error').style.display = 'flex';
      return;
    }
    if (!type) {
      document.getElementById('loan-err-msg').textContent = 'Please select a loan type.';
      document.getElementById('loan-error').style.display = 'flex';
      return;
    }
    if (amount < 1000) {
      document.getElementById('loan-err-msg').textContent = 'Minimum loan amount is ETB 1,000.';
      document.getElementById('loan-error').style.display = 'flex';
      return;
    }
    if (purpose.length < 20) {
      document.getElementById('loan-err-msg').textContent = 'Loan purpose must be at least 20 characters.';
      document.getElementById('loan-error').style.display = 'flex';
      return;
    }
    ABAY.setBtn('loan-submit-btn', true);
    ABAY.api('/loans', {
      method: 'POST',
      body: JSON.stringify({
        customer_name: customer,
        loan_type: type,
        amount: amount,
        interest_rate: rate,
        term_months: term,
        purpose: purpose,
        repayment_mode: document.getElementById('loan-repay').value,
        collateral_type: document.getElementById('loan-collateral').value,
        collateral_value: parseFloat(document.getElementById('loan-collateral-val').value) || 0
      })
    }).then(function(d) {
      ABAY.setBtn('loan-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i> Submit Application');
      if (d && d.success) {
        document.getElementById('loan-ok-msg').textContent = 'Loan application for ' + ABAY.fmtETB(amount) + ' submitted successfully. Ref: ' + (d.data && d.data.loan_number ? d.data.loan_number : 'N/A');
        document.getElementById('loan-success').style.display = 'block';
        document.getElementById('loan-form').style.display = 'none';
        ABAY.toast('Loan application submitted!', 'ok');
      } else {
        document.getElementById('loan-err-msg').textContent = (d && d.message) || 'Submission failed.';
        document.getElementById('loan-error').style.display = 'flex';
      }
    }).catch(function() {
      ABAY.setBtn('loan-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i> Submit Application');
      document.getElementById('loan-ok-msg').textContent = 'Demo: Loan application for ' + ABAY.fmtETB(amount) + ' submitted (Database offline). Ref: LN-DEMO-' + Date.now().toString(36).toUpperCase();
      document.getElementById('loan-success').style.display = 'block';
      document.getElementById('loan-form').style.display = 'none';
      ABAY.toast('Demo loan application recorded.', 'info');
    });
  });
</script>