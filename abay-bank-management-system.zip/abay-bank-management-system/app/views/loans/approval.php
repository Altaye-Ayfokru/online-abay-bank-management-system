﻿<?php

/** @var array $pending @var array $user */
$demoPending = $pending ?: [
  ['id' => 1, 'loan_id' => 'L-00041', 'customer_name' => 'Abebe Girma', 'loan_type' => 'Personal', 'amount' => 150000, 'interest_rate' => 12, 'term' => 36, 'purpose' => 'Home renovation and furniture purchase for newly constructed house', 'applied_at' => '2026-08-19', 'score' => 82, 'status' => 'Pending'],
  ['id' => 2, 'loan_id' => 'L-00042', 'customer_name' => 'Tigist Haile', 'loan_type' => 'Business', 'amount' => 2500000, 'interest_rate' => 10.5, 'term' => 60, 'purpose' => 'Expand retail grocery business — purchase additional inventory and storage equipment', 'applied_at' => '2026-08-18', 'score' => 91, 'status' => 'Pending'],
  ['id' => 3, 'loan_id' => 'L-00043', 'customer_name' => 'Samuel Bekele', 'loan_type' => 'Agricultural', 'amount' => 80000, 'interest_rate' => 8, 'term' => 24, 'purpose' => 'Purchase fertilizers, seeds, and irrigation equipment for 3-acre farm', 'applied_at' => '2026-08-17', 'score' => 75, 'status' => 'Pending'],
  ['id' => 4, 'loan_id' => 'L-00044', 'customer_name' => 'Meron Tesfaye', 'loan_type' => 'Personal', 'amount' => 50000, 'interest_rate' => 12, 'term' => 12, 'purpose' => 'Medical expenses for surgery', 'applied_at' => '2026-08-20', 'score' => 68, 'status' => 'Pending'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-circle-check" style="color:var(--primary)"></i> Loan Approvals</h1>
    <p class="page-subtitle">Review and process pending loan applications</p>
  </div>
  <div class="page-actions">
    <a href="<?= APP_URL ?>/loans" class="btn btn-outline"><i class="fa-solid fa-list"></i> All Loans</a>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoPending), 'Pending Approval', 'fa-clock', '#f59e0b'],
    ['ETB ' . number_format(array_sum(array_column($demoPending, 'amount'))), 'Total Requested', 'fa-money-bill-wave', '#6366f1'],
    ['2', 'High Priority', 'fa-triangle-exclamation', '#ef4444'],
    ['2', 'Within Policy', 'fa-shield-check', '#22c55e'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Approval Cards -->
<div style="display:flex;flex-direction:column;gap:20px">
  <?php foreach ($demoPending as $loan):
    $sc = $loan['score'];
    $sColor = $sc >= 85 ? '#22c55e' : ($sc >= 70 ? '#f59e0b' : '#ef4444');
    $sLabel = $sc >= 85 ? 'Low Risk' : ($sc >= 70 ? 'Medium Risk' : 'High Risk');
  ?>
    <div class="card">
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:20px">
          <div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
              <span class="fw-semibold" style="font-size:1rem"><?= htmlspecialchars($loan['customer_name']) ?></span>
              <span class="badge badge-warning"><?= $loan['loan_id'] ?></span>
            </div>
            <p class="text-muted" style="margin:0;font-size:.83rem">Applied on <?= $loan['applied_at'] ?></p>
          </div>
          <div style="text-align:right">
            <div style="font-size:1.4rem;font-weight:700;color:var(--primary)">ETB <?= number_format($loan['amount']) ?></div>
            <div class="text-muted" style="font-size:.83rem"><?= $loan['loan_type'] ?> · <?= $loan['term'] ?> months @ <?= $loan['interest_rate'] ?>%</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px">
          <div style="background:var(--surface);border-radius:10px;padding:14px">
            <div class="text-muted" style="font-size:.78rem;margin-bottom:4px">Purpose</div>
            <div style="font-size:.85rem"><?= htmlspecialchars($loan['purpose']) ?></div>
          </div>
          <div style="background:var(--surface);border-radius:10px;padding:14px">
            <div class="text-muted" style="font-size:.78rem;margin-bottom:4px">EMI (Monthly)</div>
            <div class="fw-semibold">ETB <?= number_format($loan['amount'] * ($loan['interest_rate'] / 1200) / (1 - pow(1 + $loan['interest_rate'] / 1200, -$loan['term'])), 2) ?></div>
          </div>
          <div style="background:var(--surface);border-radius:10px;padding:14px">
            <div class="text-muted" style="font-size:.78rem;margin-bottom:4px">Credit Score</div>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:48px;height:48px;border-radius:50%;border:3px solid <?= $sColor ?>;display:flex;align-items:center;justify-content:center;font-weight:700;color:<?= $sColor ?>"><?= $sc ?></div>
              <span style="color:<?= $sColor ?>;font-size:.83rem;font-weight:600"><?= $sLabel ?></span>
            </div>
          </div>
        </div>

        <div style="display:flex;gap:12px;justify-content:flex-end;flex-wrap:wrap">
          <button class="btn btn-outline" onclick="ABAY.toast('Opening full application for <?= addslashes($loan['customer_name']) ?>','info')">
            <i class="fa-solid fa-eye"></i> View Full Application
          </button>
          <button class="btn btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="rejectLoan('<?= $loan['loan_id'] ?>')">
            <i class="fa-solid fa-xmark"></i> Reject
          </button>
          <button class="btn btn-success" onclick="approveLoan('<?= $loan['loan_id'] ?>')">
            <i class="fa-solid fa-check"></i> Approve & Disburse
          </button>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function approveLoan(id) {
    if (confirm('Approve loan ' + id + '? Funds will be disbursed to the customer account.')) {
      ABAY.api('/loans/approve', {
          method: 'POST',
          body: JSON.stringify({
            loan_id: id
          })
        })
        .then(function(d) {
          if (d && d.success) {
            ABAY.toast('Loan ' + id + ' approved and disbursed!', 'ok');
            setTimeout(function() {
              location.reload();
            }, 1300);
          } else {
            ABAY.toast((d && d.message) || 'Approval failed', 'err');
          }
        }).catch(function() {
          ABAY.toast('Demo: Loan ' + id + ' approved', 'success');
          setTimeout(function() {
            location.reload();
          }, 1300);
        });
    }
  }

  function rejectLoan(id) {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;
    ABAY.api('/loans/reject', {
        method: 'POST',
        body: JSON.stringify({
          loan_id: id,
          reason: reason
        })
      })
      .then(function(d) {
        if (d && d.success) {
          ABAY.toast('Loan ' + id + ' rejected.', 'warning');
          setTimeout(function() {
            location.reload();
          }, 1300);
        } else {
          ABAY.toast((d && d.message) || 'Rejection failed', 'err');
        }
      }).catch(function() {
        ABAY.toast('Demo: Loan ' + id + ' rejected', 'warning');
        setTimeout(function() {
          location.reload();
        }, 1300);
      });
  }
</script>