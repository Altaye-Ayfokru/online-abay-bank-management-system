<?php $pageTitle = 'Loan Management — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Loan Management</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Loans</span></div>
  </div>
  <div style="display:flex;gap:var(--space-3)">
    <button class="btn btn-light btn-sm" onclick="exportLoansCSV()"><i class="fa-solid fa-file-csv"></i> Export</button>
    <a href="<?= APP_URL ?>/loans/apply" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> New Loan</a>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:var(--space-5)">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-file-invoice-dollar"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Loans</div>
      <div class="stat-value" id="ls-total">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Pending</div>
      <div class="stat-value" id="ls-pending">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Active</div>
      <div class="stat-value" id="ls-active">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div class="stat-content">
      <div class="stat-label">Overdue</div>
      <div class="stat-value" id="ls-overdue">—</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-coins"></i></div>
    <div class="stat-content">
      <div class="stat-label">Portfolio</div>
      <div class="stat-value" id="ls-portfolio">—</div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-file-invoice-dollar" style="color:#1B3A5C;margin-right:7px"></i>All Loans</h3>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <input type="search" id="loan-search" placeholder="Search loans..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:200px;outline:none" oninput="filterLoans(this.value)">
      <select id="loan-status-filter" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer" onchange="filterLoans()">
        <option value="">All Status</option>
        <option>Pending</option>
        <option>Approved</option>
        <option>Active</option>
        <option>Disbursed</option>
        <option>Completed</option>
        <option>Rejected</option>
        <option>Overdue</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Loan ID</th>
          <th>Customer</th>
          <th>Type</th>
          <th>Amount</th>
          <th>Rate</th>
          <th>Term</th>
          <th>EMI</th>
          <th>Outstanding</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="loans-tbody">
        <tr>
          <td colspan="10" style="text-align:center;padding:40px;color:#94a3b8"><i class="fa-solid fa-spinner fa-spin" style="font-size:1.4rem"></i>
            <div style="margin-top:8px;font-size:.84rem">Loading loans...</div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="loans-info">Loading...</div>
    <div id="loans-pagination" style="display:flex;gap:6px"></div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allLoans = [],
    _filtLoans = [],
    _lPage = 1,
    _lPer = 15;
  var demoLoans = [{
      id: 'LN-001',
      loan_number: 'LN-20260001',
      customer_name: 'Abebe Bekele',
      loan_type: 'Personal',
      amount: 150000,
      interest_rate: 12,
      term_months: 24,
      emi: 7050,
      outstanding: 126000,
      status: 'Active',
      created_at: '2025-06-01'
    },
    {
      id: 'LN-002',
      loan_number: 'LN-20260002',
      customer_name: 'Tigist Haile',
      loan_type: 'Business',
      amount: 500000,
      interest_rate: 10.5,
      term_months: 60,
      emi: 10750,
      outstanding: 450000,
      status: 'Active',
      created_at: '2025-07-15'
    },
    {
      id: 'LN-003',
      loan_number: 'LN-20260003',
      customer_name: 'Solomon Girma',
      loan_type: 'Agricultural',
      amount: 80000,
      interest_rate: 8,
      term_months: 36,
      emi: 2500,
      outstanding: 72000,
      status: 'Pending',
      created_at: '2026-01-10'
    },
    {
      id: 'LN-004',
      loan_number: 'LN-20260004',
      customer_name: 'Meron Alemu',
      loan_type: 'Personal',
      amount: 45000,
      interest_rate: 14,
      term_months: 12,
      emi: 4050,
      outstanding: 0,
      status: 'Completed',
      created_at: '2025-01-20'
    },
    {
      id: 'LN-005',
      loan_number: 'LN-20260005',
      customer_name: 'Dawit Mekonnen',
      loan_type: 'Business',
      amount: 2000000,
      interest_rate: 11,
      term_months: 120,
      emi: 27500,
      outstanding: 1900000,
      status: 'Disbursed',
      created_at: '2025-05-01'
    },
    {
      id: 'LN-006',
      loan_number: 'LN-20260006',
      customer_name: 'Hanna Getnet',
      loan_type: 'Personal',
      amount: 30000,
      interest_rate: 15,
      term_months: 18,
      emi: 1950,
      outstanding: 28000,
      status: 'Overdue',
      created_at: '2025-09-01'
    },
  ];

  function loadLoans() {
    ABAY.api('/loans?per_page=200').then(function(d) {
      var rows = (d && d.success && d.data && d.data.length) ? d.data : demoLoans;
      _allLoans = rows;
      updateLoanStats(rows);
      filterLoans();
    }).catch(function() {
      _allLoans = demoLoans;
      updateLoanStats(demoLoans);
      filterLoans();
    });
  }

  function updateLoanStats(rows) {
    var total = rows.length,
      pending = 0,
      active = 0,
      overdue = 0,
      portfolio = 0;
    rows.forEach(function(r) {
      if (r.status === 'Pending') pending++;
      if (r.status === 'Active' || r.status === 'Disbursed') active++;
      if (r.status === 'Overdue') overdue++;
      portfolio += parseFloat(r.outstanding || r.amount || 0);
    });
    document.getElementById('ls-total').textContent = ABAY.fmtNum(total);
    document.getElementById('ls-pending').textContent = ABAY.fmtNum(pending);
    document.getElementById('ls-active').textContent = ABAY.fmtNum(active);
    document.getElementById('ls-overdue').textContent = ABAY.fmtNum(overdue);
    document.getElementById('ls-portfolio').textContent = 'ETB ' + ABAY.fmtNum(Math.round(portfolio / 1000)) + 'K';
  }

  function filterLoans(q) {
    var search = (typeof q === 'string' ? q : document.getElementById('loan-search').value).toLowerCase();
    var status = document.getElementById('loan-status-filter').value;
    _filtLoans = _allLoans.filter(function(l) {
      var m = !search || (l.customer_name || '').toLowerCase().includes(search) || (l.loan_number || l.id || '').toLowerCase().includes(search);
      return m && (!status || l.status === status);
    });
    _lPage = 1;
    renderLoans();
  }

  function renderLoans() {
    var tbody = document.getElementById('loans-tbody');
    var total = _filtLoans.length;
    var start = (_lPage - 1) * _lPer;
    var slice = _filtLoans.slice(start, start + _lPer);
    if (!total) {
      tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;padding:40px;color:#94a3b8">No loans found</td></tr>';
      return;
    }
    tbody.innerHTML = slice.map(function(l) {
      var emi = l.emi || Math.round((l.amount * l.interest_rate / 1200 * (1 + l.interest_rate / 1200)) / ((Math.pow(1 + l.interest_rate / 1200, l.term_months || 12) - 1)));
      return '<tr>' +
        '<td><span style="font-family:monospace;font-size:.76rem;color:#475569;font-weight:600">' + (l.loan_number || l.id || '—') + '</span></td>' +
        '<td style="font-size:.83rem;font-weight:600;color:#1e293b">' + (l.customer_name || '—') + '</td>' +
        '<td><span style="font-size:.77rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600">' + (l.loan_type || l.type || '—') + '</span></td>' +
        '<td style="font-weight:700;font-size:.82rem">' + ABAY.fmtETB(l.amount || 0) + '</td>' +
        '<td style="font-size:.82rem">' + (l.interest_rate || 0) + '%</td>' +
        '<td style="font-size:.82rem">' + (l.term_months || 0) + ' mo</td>' +
        '<td style="font-size:.82rem">' + ABAY.fmtETB(emi) + '</td>' +
        '<td style="font-weight:700;font-size:.82rem;color:#ef4444">' + ABAY.fmtETB(l.outstanding || 0) + '</td>' +
        '<td>' + ABAY.badge(l.status || 'Active') + '</td>' +
        '<td><div style="display:flex;gap:5px">' +
        '<a href="<?= APP_URL ?>/loans/approval?id=' + (l.id || '') + '" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.74rem" title="Review"><i class="fa-solid fa-eye"></i></a>' +
        '<a href="<?= APP_URL ?>/loans/payment?id=' + (l.id || '') + '" class="btn btn-ghost btn-sm" style="padding:4px 8px;font-size:.74rem" title="Payment"><i class="fa-solid fa-money-bill-wave"></i></a>' +
        '</div></td>' +
        '</tr>';
    }).join('');
    document.getElementById('loans-info').textContent = 'Showing ' + (start + 1) + '–' + Math.min(start + _lPer, total) + ' of ' + total + ' loans';
    var pages = Math.ceil(total / _lPer);
    var pg = document.getElementById('loans-pagination');
    var html = '';
    for (var i = 1; i <= pages; i++) html += '<button onclick="_lPage=' + i + ';renderLoans()" style="width:30px;height:30px;border:1.5px solid ' + (_lPage === i ? '#007A8A' : '#e2e8f0') + ';background:' + (_lPage === i ? '#007A8A' : '#fff') + ';color:' + (_lPage === i ? '#fff' : '#475569') + ';border-radius:6px;cursor:pointer;font-size:.78rem;font-family:inherit">' + i + '</button>';
    pg.innerHTML = html;
  }

  function exportLoansCSV() {
    var rows = [
      ['Loan ID', 'Customer', 'Type', 'Amount', 'Rate', 'Term', 'Status']
    ].concat(
      _filtLoans.map(function(l) {
        return [l.loan_number || l.id, l.customer_name, l.loan_type || l.type, l.amount, l.interest_rate + '%', l.term_months + ' mo', l.status];
      })
    );
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'loans.csv';
    a.click();
  }

  document.addEventListener('DOMContentLoaded', loadLoans);
</script>