﻿<?php

/** @var array $loans @var array $user */
$demoLoans = $loans ?: [
  ['id' => 1, 'loan_id' => 'L-00001', 'customer_name' => 'Abebe Girma', 'loan_type' => 'Personal', 'principal' => 150000, 'outstanding' => 92400, 'emi' => 4500, 'next_due_date' => '2026-09-15', 'months_paid' => 15, 'total_months' => 36, 'status' => 'Active'],
  ['id' => 2, 'loan_id' => 'L-00002', 'customer_name' => 'Tigist Haile', 'loan_type' => 'Business', 'principal' => 2500000, 'outstanding' => 1820000, 'emi' => 52800, 'next_due_date' => '2026-09-01', 'months_paid' => 13, 'total_months' => 60, 'status' => 'Active'],
  ['id' => 3, 'loan_id' => 'L-00003', 'customer_name' => 'Samuel Bekele', 'loan_type' => 'Agricultural', 'principal' => 80000, 'outstanding' => 45200, 'emi' => 3700, 'next_due_date' => '2026-08-31', 'months_paid' => 10, 'total_months' => 24, 'status' => 'Overdue'],
  ['id' => 4, 'loan_id' => 'L-00004', 'customer_name' => 'Meron Tesfaye', 'loan_type' => 'Personal', 'principal' => 50000, 'outstanding' => 28000, 'emi' => 4600, 'next_due_date' => '2026-10-10', 'months_paid' => 5, 'total_months' => 12, 'status' => 'Active'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-money-bill-wave" style="color:var(--primary)"></i> Loan Payments</h1>
    <p class="page-subtitle">Process loan repayments and track outstanding balances</p>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($demoLoans), 'Active Loans', 'fa-file-invoice-dollar', '#6366f1'],
    ['ETB ' . number_format(array_sum(array_column($demoLoans, 'outstanding'))), 'Total Outstanding', 'fa-money-bill-wave', '#ef4444'],
    [count(array_filter($demoLoans, fn($l) => $l['status'] === 'Overdue')), 'Overdue', 'fa-triangle-exclamation', '#f59e0b'],
    ['ETB ' . number_format(array_sum(array_column($demoLoans, 'emi'))), 'Total EMI Due', 'fa-calendar', '#22c55e'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Payment Form + Loan List -->
<div class="grid-2" style="align-items:start">
  <!-- Make Payment -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title"><i class="fa-solid fa-money-bill"></i> Record Loan Payment</h3>
    </div>
    <div class="card-body">
      <form onsubmit="processPayment(event)">
        <div class="form-group">
          <label class="form-label required">Loan ID / Customer</label>
          <select class="form-control" id="pay-loan-id" onchange="fillLoanDetails(this)">
            <option value="">-- Select Loan --</option>
            <?php foreach ($demoLoans as $l): ?>
              <option value="<?= $l['loan_id'] ?>" data-emi="<?= $l['emi'] ?>" data-name="<?= htmlspecialchars($l['customer_name']) ?>" data-due="<?= $l['next_due_date'] ?>">
                <?= $l['loan_id'] ?> — <?= htmlspecialchars($l['customer_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div id="loan-info" style="display:none;background:var(--surface);border-radius:10px;padding:14px;margin-bottom:16px">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span class="text-muted">Customer</span><span class="fw-semibold" id="info-name">—</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span class="text-muted">Monthly EMI</span><span class="fw-semibold text-primary" id="info-emi">—</span>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span class="text-muted">Due Date</span><span id="info-due">—</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label required">Payment Amount (ETB)</label>
          <input type="number" id="pay-amount" class="form-control" placeholder="0.00" min="1" required>
        </div>
        <div class="form-group">
          <label class="form-label">Payment Method</label>
          <select class="form-control">
            <option>Cash</option>
            <option>Bank Transfer</option>
            <option>Cheque</option>
            <option>Account Deduction</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Payment Date</label>
          <input type="date" class="form-control" value="<?= date('Y-m-d') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Reference / Receipt No.</label>
          <input type="text" class="form-control" placeholder="Optional reference number">
        </div>
        <button type="submit" class="btn btn-primary w-100">
          <i class="fa-solid fa-check"></i> Process Payment
        </button>
      </form>
    </div>
  </div>

  <!-- Active Loans -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Active Loans</h3>
    </div>
    <div class="card-body p-0">
      <?php foreach ($demoLoans as $l):
        $pct = round(($l['months_paid'] / $l['total_months']) * 100);
        $bc = $l['status'] === 'Overdue' ? 'border-left:3px solid #ef4444' : 'border-left:3px solid var(--primary)';
      ?>
        <div style="padding:16px;border-bottom:1px solid var(--border);<?= $bc ?>">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <div>
              <span class="fw-semibold"><?= htmlspecialchars($l['customer_name']) ?></span>
              <span class="badge badge-secondary" style="margin-left:8px;font-size:.72rem"><?= $l['loan_id'] ?></span>
              <?php if ($l['status'] === 'Overdue'): ?>
                <span class="badge badge-danger" style="margin-left:4px;font-size:.72rem">OVERDUE</span>
              <?php endif; ?>
            </div>
            <span class="fw-semibold text-primary">ETB <?= number_format($l['outstanding']) ?></span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--text-muted);margin-bottom:8px">
            <span><?= $l['loan_type'] ?> · <?= $l['months_paid'] ?>/<?= $l['total_months'] ?> months</span>
            <span>Due <?= $l['next_due_date'] ?></span>
          </div>
          <div style="height:5px;background:#e5e7eb;border-radius:3px;margin-bottom:6px">
            <div style="width:<?= $pct ?>%;height:100%;background:<?= $l['status'] === 'Overdue' ? '#ef4444' : 'var(--primary)' ?>;border-radius:3px"></div>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:.78rem;color:var(--text-muted)">
            <span><?= $pct ?>% repaid</span>
            <span>EMI: ETB <?= number_format($l['emi']) ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function fillLoanDetails(sel) {
    const opt = sel.selectedOptions[0];
    const info = document.getElementById('loan-info');
    if (!opt.value) {
      info.style.display = 'none';
      return;
    }
    document.getElementById('info-name').textContent = opt.dataset.name;
    document.getElementById('info-emi').textContent = 'ETB ' + Number(opt.dataset.emi).toLocaleString();
    document.getElementById('info-due').textContent = opt.dataset.due;
    document.getElementById('pay-amount').value = opt.dataset.emi;
    info.style.display = '';
  }

  function processPayment(e) {
    e.preventDefault();
    const lid = document.getElementById('pay-loan-id').value;
    const amt = document.getElementById('pay-amount').value;
    if (!lid) {
      ABAY.toast('Please select a loan', 'warning');
      return;
    }
    ABAY.toast(`Payment of ETB ${Number(amt).toLocaleString()} recorded for ${lid}`, 'success');
    e.target.reset();
    document.getElementById('loan-info').style.display = 'none';
  }
</script>