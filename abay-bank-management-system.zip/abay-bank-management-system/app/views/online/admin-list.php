﻿<?php
$pageTitle = $pageTitle ?? 'Online Applications';
?>
<div class="page-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
  <div>
    <h1 class="page-title" style="font-size:1.5rem;font-weight:800;color:#1B3A5C;margin-bottom:4px">
      <i class="fa-solid fa-globe" style="color:#007A8A;margin-right:8px"></i>Online Account Applications
    </h1>
    <p style="color:#64748b;font-size:.88rem">Review and approve applications submitted through the online portal with Fayda verification</p>
  </div>
  <a href="<?= APP_URL ?>/online/apply" target="_blank" class="btn btn-primary" style="display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#007A8A,#1B3A5C);color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;font-size:.88rem">
    <i class="fa-solid fa-arrow-up-right-from-square"></i> View Public Form
  </a>
</div>

<!-- Stats -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;margin-bottom:24px">
  <?php
  $statsMap = [
    ['label'=>'Total',        'val'=>$stats['total'],        'ic'=>'fa-list',          'color'=>'#1B3A5C'],
    ['label'=>'Pending',      'val'=>$stats['pending'],      'ic'=>'fa-clock',         'color'=>'#f59e0b'],
    ['label'=>'Under Review', 'val'=>$stats['under_review'], 'ic'=>'fa-magnifying-glass','color'=>'#6366f1'],
    ['label'=>'Approved',     'val'=>$stats['approved'],     'ic'=>'fa-circle-check',  'color'=>'#10b981'],
    ['label'=>'Completed',    'val'=>$stats['completed'],    'ic'=>'fa-flag-checkered','color'=>'#007A8A'],
  ];
  foreach ($statsMap as $s): ?>
  <div style="background:#fff;border-radius:12px;padding:16px;box-shadow:0 1px 8px rgba(0,0,0,.07)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
      <span style="font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#64748b"><?= $s['label'] ?></span>
      <i class="fa-solid <?= $s['ic'] ?>" style="color:<?= $s['color'] ?>;font-size:.9rem"></i>
    </div>
    <div style="font-size:1.8rem;font-weight:800;color:#1e293b"><?= number_format($s['val']) ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Filter tabs -->
<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
  <?php foreach (['all'=>'All','Pending'=>'Pending','Under Review'=>'Under Review','Approved'=>'Approved','Completed'=>'Completed','Rejected'=>'Rejected'] as $k=>$v): ?>
  <a href="?status=<?= urlencode($k) ?>"
     style="padding:7px 16px;border-radius:20px;font-size:.8rem;font-weight:600;text-decoration:none;<?= $filter===$k?'background:#007A8A;color:#fff':'background:#fff;color:#64748b;border:1px solid #e2e8f0' ?>">
    <?= $v ?>
  </a>
  <?php endforeach; ?>
</div>

<!-- Table -->
<div style="background:#fff;border-radius:12px;box-shadow:0 1px 8px rgba(0,0,0,.07);overflow:hidden">
  <table style="width:100%;border-collapse:collapse">
    <thead>
      <tr style="background:#f8fafc;border-bottom:2px solid #e2e8f0">
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Reference</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Applicant</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Fayda</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Account Type</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Branch</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Status</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Date</th>
        <th style="padding:12px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#64748b">Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($applications)): ?>
      <tr><td colspan="8" style="padding:40px;text-align:center;color:#64748b"><i class="fa-solid fa-inbox fa-2x" style="margin-bottom:8px;display:block;opacity:.4"></i>No applications found</td></tr>
    <?php else: ?>
    <?php foreach ($applications as $a):
      $statusColors = ['Pending'=>'#f59e0b','Under Review'=>'#6366f1','Approved'=>'#10b981','Completed'=>'#007A8A','Rejected'=>'#ef4444'];
      $sc = $statusColors[$a['status']] ?? '#64748b';
    ?>
      <tr style="border-bottom:1px solid #f1f5f9;transition:.15s" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
        <td style="padding:12px 16px;font-family:monospace;font-size:.82rem;color:#007A8A;font-weight:600"><?= \Web\Core\View::e($a['ref_number']) ?></td>
        <td style="padding:12px 16px">
          <div style="font-weight:600;font-size:.88rem"><?= \Web\Core\View::e($a['first_name'].' '.$a['last_name']) ?></div>
          <div style="font-size:.75rem;color:#64748b"><?= \Web\Core\View::e($a['email']) ?></div>
        </td>
        <td style="padding:12px 16px">
          <?php if ($a['fayda_verified']): ?>
          <span style="background:rgba(16,185,129,.1);color:#047857;padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700;display:inline-flex;align-items:center;gap:4px">
            <i class="fa-solid fa-fingerprint"></i> Verified
          </span>
          <?php else: ?>
          <span style="background:rgba(239,68,68,.1);color:#dc2626;padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700">
            <i class="fa-solid fa-times"></i> Unverified
          </span>
          <?php endif; ?>
        </td>
        <td style="padding:12px 16px;font-size:.85rem"><?= \Web\Core\View::e($a['account_type']) ?></td>
        <td style="padding:12px 16px;font-size:.82rem;color:#64748b"><?= \Web\Core\View::e($a['branch_name'] ?? 'N/A') ?></td>
        <td style="padding:12px 16px">
          <span style="background:<?= $sc ?>20;color:<?= $sc ?>;padding:3px 12px;border-radius:20px;font-size:.75rem;font-weight:700"><?= $a['status'] ?></span>
        </td>
        <td style="padding:12px 16px;font-size:.78rem;color:#64748b"><?= date('d M Y', strtotime($a['created_at'])) ?></td>
        <td style="padding:12px 16px">
          <?php if (in_array($a['status'], ['Pending','Under Review'])): ?>
          <a href="<?= APP_URL ?>/online/review?id=<?= $a['id'] ?>"
             style="background:#007A8A;color:#fff;padding:5px 14px;border-radius:6px;text-decoration:none;font-size:.78rem;font-weight:600;display:inline-flex;align-items:center;gap:5px">
            <i class="fa-solid fa-eye"></i> Review
          </a>
          <?php else: ?>
          <a href="<?= APP_URL ?>/online/review?id=<?= $a['id'] ?>"
             style="background:#f1f5f9;color:#64748b;padding:5px 14px;border-radius:6px;text-decoration:none;font-size:.78rem;font-weight:600;display:inline-flex;align-items:center;gap:5px">
            <i class="fa-solid fa-magnifying-glass"></i> View
          </a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
