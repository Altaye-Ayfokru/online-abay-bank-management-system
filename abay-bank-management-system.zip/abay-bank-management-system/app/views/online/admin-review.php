﻿<?php $a = $app; ?>
<div style="max-width:900px;margin:0 auto">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
    <div>
      <a href="<?= APP_URL ?>/online/applications" style="font-size:.82rem;color:#007A8A;text-decoration:none;display:inline-flex;align-items:center;gap:6px;margin-bottom:6px">
        <i class="fa-solid fa-arrow-left"></i> Back to Applications
      </a>
      <h1 style="font-size:1.4rem;font-weight:800;color:#1B3A5C">Review Application</h1>
      <code style="font-size:.82rem;color:#007A8A"><?= \Web\Core\View::e($a['ref_number']) ?></code>
    </div>
    <?php
    $statusColors = ['Pending'=>'#f59e0b','Under Review'=>'#6366f1','Approved'=>'#10b981','Completed'=>'#007A8A','Rejected'=>'#ef4444'];
    $sc = $statusColors[$a['status']] ?? '#64748b';
    ?>
    <span style="background:<?= $sc ?>20;color:<?= $sc ?>;padding:8px 20px;border-radius:20px;font-size:.88rem;font-weight:700"><?= $a['status'] ?></span>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">

    <!-- Personal Info -->
    <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07)">
      <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#007A8A;margin-bottom:14px">Personal Information</div>
      <div style="display:grid;gap:10px">
        <?php $rows = [
          ['Name',        $a['first_name'].' '.$a['last_name']],
          ['Email',       $a['email']],
          ['Phone',       $a['phone']],
          ['Date of Birth',$a['date_of_birth']],
          ['Gender',      $a['gender']],
          ['Occupation',  $a['occupation']],
          ['Monthly Income', $a['monthly_income'] ? 'ETB '.number_format($a['monthly_income'],2) : 'N/A'],
          ['Address',     ($a['city']??'').' '.($a['subcity']??'').' '.($a['kebele']??'').' '.($a['region']??'')],
        ];
        foreach ($rows as [$label, $val]): ?>
        <div style="display:flex;gap:8px;font-size:.84rem">
          <span style="color:#64748b;min-width:110px;flex-shrink:0"><?= $label ?>:</span>
          <span style="font-weight:500;color:#1e293b"><?= \Web\Core\View::e($val) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ID & Account Info -->
    <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07)">
      <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#007A8A;margin-bottom:14px">Identity &amp; Account</div>
      <div style="display:grid;gap:10px">
        <?php $rows2 = [
          ['National ID',   $a['national_id']],
          ['Fayda ID',      $a['fayda_id']],
          ['Fayda Verified',$a['fayda_verified'] ? '✅ Yes ('.($a['fayda_verified_at']??'').')' : '❌ No'],
          ['Account Type',  $a['account_type']],
          ['Initial Deposit','ETB '.number_format($a['initial_deposit'],2)],
          ['Branch',        $a['branch_name']??'N/A'],
          ['Submitted',     date('d M Y H:i', strtotime($a['created_at']))],
          ['IP',            $a['ip_address']??'N/A'],
        ];
        foreach ($rows2 as [$label, $val]): ?>
        <div style="display:flex;gap:8px;font-size:.84rem">
          <span style="color:#64748b;min-width:110px;flex-shrink:0"><?= $label ?>:</span>
          <span style="font-weight:500;color:#1e293b"><?= \Web\Core\View::e($val) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Fayda Verification Logs -->
  <?php if (!empty($fayda)): ?>
  <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07);margin-bottom:20px">
    <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#007A8A;margin-bottom:14px">Fayda Verification Log</div>
    <?php foreach ($fayda as $f): ?>
    <div style="background:<?= $f['result']==='Verified'?'rgba(16,185,129,.06)':'rgba(239,68,68,.06)' ?>;border:1px solid <?= $f['result']==='Verified'?'rgba(16,185,129,.2)':'rgba(239,68,68,.2)' ?>;border-radius:10px;padding:14px;margin-bottom:10px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <span style="font-weight:700;font-size:.88rem;color:<?= $f['result']==='Verified'?'#047857':'#dc2626' ?>">
          <i class="fa-solid <?= $f['result']==='Verified'?'fa-circle-check':'fa-circle-xmark' ?>"></i> <?= $f['result'] ?>
        </span>
        <span style="font-size:.75rem;color:#64748b"><?= date('d M Y H:i:s', strtotime($f['created_at'])) ?></span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
        <div><div style="font-size:.7rem;color:#64748b">Face Score</div><div style="font-weight:700;color:#1e293b"><?= $f['face_match_score'] ?>%</div></div>
        <div><div style="font-size:.7rem;color:#64748b">ID Score</div><div style="font-weight:700;color:#1e293b"><?= $f['id_match_score'] ?>%</div></div>
        <div><div style="font-size:.7rem;color:#64748b">IP</div><div style="font-weight:600;color:#1e293b;font-size:.78rem"><?= $f['ip_address'] ?></div></div>
        <div><div style="font-size:.7rem;color:#64748b">Matched Name</div><div style="font-weight:600;color:#1e293b;font-size:.78rem"><?= \Web\Core\View::e($f['full_name']) ?></div></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Document uploads -->
  <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07);margin-bottom:20px">
    <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#007A8A;margin-bottom:14px">Uploaded Documents</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
      <?php foreach (['selfie_path'=>'Selfie','id_front_path'=>'ID Front','id_back_path'=>'ID Back'] as $field=>$label): ?>
      <div style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;text-align:center">
        <div style="padding:8px;background:#f8fafc;font-size:.78rem;font-weight:600;color:#64748b"><?= $label ?></div>
        <?php if (!empty($a[$field])): ?>
          <?php $ext = strtolower(pathinfo($a[$field], PATHINFO_EXTENSION)); ?>
          <?php if (in_array($ext, ['jpg','jpeg','png','gif'])): ?>
          <img src="<?= APP_URL . '/' . $a[$field] ?>" style="max-width:100%;max-height:160px;display:block;margin:0 auto;padding:8px">
          <?php else: ?>
          <div style="padding:20px;color:#64748b"><i class="fa-solid fa-file-pdf fa-2x"></i><br><small>PDF Document</small></div>
          <?php endif; ?>
        <?php else: ?>
        <div style="padding:20px;color:#94a3b8"><i class="fa-solid fa-image fa-2x"></i><br><small>Not uploaded</small></div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Action buttons -->
  <?php if (in_array($a['status'], ['Pending','Under Review'])): ?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">

    <!-- Approve -->
    <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07)">
      <div style="font-weight:700;font-size:.95rem;color:#047857;margin-bottom:14px"><i class="fa-solid fa-circle-check"></i> Approve &amp; Create Account</div>
      <form method="POST" action="<?= APP_URL ?>/online/approve" onsubmit="return confirm('Approve and create customer account?')">
        <?= \Web\Core\View::csrfField() ?>
        <input type="hidden" name="app_id" value="<?= $a['id'] ?>">
        <div style="margin-bottom:12px">
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Assign to Branch</label>
          <select name="branch_id" style="width:100%;padding:8px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.85rem">
            <?php foreach ($branches as $b): ?>
            <option value="<?= $b['id'] ?>" <?= $b['id']==$a['preferred_branch']?'selected':'' ?>>
              <?= \Web\Core\View::e($b['name']) ?> — <?= \Web\Core\View::e($b['city']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" style="width:100%;background:linear-gradient(135deg,#10b981,#047857);color:#fff;border:none;border-radius:8px;padding:10px;font-weight:700;cursor:pointer;font-size:.88rem">
          <i class="fa-solid fa-check"></i> Approve Application
        </button>
      </form>
    </div>

    <!-- Reject -->
    <div style="background:#fff;border-radius:12px;padding:20px;box-shadow:0 1px 8px rgba(0,0,0,.07)">
      <div style="font-weight:700;font-size:.95rem;color:#dc2626;margin-bottom:14px"><i class="fa-solid fa-circle-xmark"></i> Reject Application</div>
      <form method="POST" action="<?= APP_URL ?>/online/reject" onsubmit="return confirm('Reject this application?')">
        <?= \Web\Core\View::csrfField() ?>
        <input type="hidden" name="app_id" value="<?= $a['id'] ?>">
        <div style="margin-bottom:12px">
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Rejection Reason</label>
          <textarea name="reason" style="width:100%;padding:8px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.85rem;height:80px;resize:none" placeholder="e.g. Documents unclear, ID mismatch..." required></textarea>
        </div>
        <button type="submit" style="width:100%;background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;border:none;border-radius:8px;padding:10px;font-weight:700;cursor:pointer;font-size:.88rem">
          <i class="fa-solid fa-times"></i> Reject Application
        </button>
      </form>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
