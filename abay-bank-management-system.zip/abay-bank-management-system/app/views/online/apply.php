﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= \Web\Core\View::e($pageTitle ?? 'Open Account Online — Abay Bank') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--blue:#1B3A5C;--teal:#007A8A;--gold:#C8A84B;--green:#10b981;--red:#ef4444;--bg:#f1f5f9;--card:#fff;--text:#1e293b;--sub:#64748b;--border:#e2e8f0;--radius:12px}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
.top-nav{background:var(--blue);color:#fff;padding:14px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.3)}
.nav-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:#fff}
.logo-bars{display:flex;align-items:flex-end;gap:3px}
.b{border-radius:2px 2px 0 0}.b1{width:4px;height:12px;background:var(--gold)}.b2{width:4px;height:16px;background:var(--teal)}.b3{width:4px;height:20px;background:#fff}.b4{width:4px;height:12px;background:var(--teal)}
.nav-title{font-size:1rem;font-weight:700}.nav-sub{font-size:.7rem;opacity:.7}
.nav-links{display:flex;gap:16px;align-items:center}
.nav-links a{color:rgba(255,255,255,.8);text-decoration:none;font-size:.85rem;font-weight:500;transition:.2s}
.nav-links a:hover{color:#fff}
.hero{background:linear-gradient(135deg,var(--blue) 0%,var(--teal) 100%);color:#fff;padding:60px 24px 40px;text-align:center}
.hero h1{font-size:2rem;font-weight:800;margin-bottom:10px}
.hero p{font-size:1rem;opacity:.85;max-width:560px;margin:0 auto 28px}
.steps-row{display:flex;justify-content:center;gap:8px;flex-wrap:wrap}
.step{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:50px;padding:8px 18px;font-size:.78rem;font-weight:600;display:flex;align-items:center;gap:8px}
.step-num{background:var(--gold);color:var(--blue);border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.75rem}
.container{max-width:860px;margin:0 auto;padding:32px 16px 64px}
.card{background:var(--card);border-radius:var(--radius);box-shadow:0 2px 16px rgba(0,0,0,.07);overflow:hidden;margin-bottom:24px}
.card-header{background:var(--blue);color:#fff;padding:18px 24px;display:flex;align-items:center;gap:12px}
.card-header h2{font-size:1rem;font-weight:700}
.card-header i{font-size:1.1rem;color:var(--gold)}
.card-body{padding:24px}
.section-tag{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--teal);background:rgba(0,122,138,.08);padding:4px 10px;border-radius:20px;display:inline-block;margin-bottom:16px}
.form-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.form-grid.cols-3{grid-template-columns:repeat(3,1fr)}
.full{grid-column:1/-1}
.form-group{display:flex;flex-direction:column;gap:6px}
.form-label{font-size:.82rem;font-weight:600;color:var(--text)}
.req{color:var(--red);margin-left:2px}
.inp-wrap{position:relative}
.inp-ic{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--sub);font-size:.85rem}
.form-inp,.form-sel{width:100%;padding:10px 12px 10px 36px;border:1.5px solid var(--border);border-radius:8px;font-size:.88rem;font-family:inherit;color:var(--text);background:#fff;transition:.2s}
.form-inp:focus,.form-sel:focus{outline:none;border-color:var(--teal);box-shadow:0 0 0 3px rgba(0,122,138,.1)}
.form-inp.has-error,.form-sel.has-error{border-color:var(--red)}
.form-sel{padding-left:36px}
.err-msg{font-size:.75rem;color:var(--red);display:none}
.err-msg.show{display:block}
.hint{font-size:.73rem;color:var(--sub);margin-top:3px}
/* Fayda badge */
.fayda-badge{display:flex;align-items:center;gap:10px;background:linear-gradient(135deg,rgba(200,168,75,.1),rgba(0,122,138,.08));border:1.5px solid var(--gold);border-radius:10px;padding:14px 16px;margin-bottom:20px}
.fayda-icon{width:44px;height:44px;background:var(--blue);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--gold);font-size:1.3rem;flex-shrink:0}
.fayda-title{font-weight:700;font-size:.92rem;color:var(--blue)}
.fayda-sub{font-size:.75rem;color:var(--sub)}
/* Status indicator */
.fayda-status{display:flex;align-items:center;gap:6px;font-size:.78rem;padding:6px 12px;border-radius:20px;font-weight:600;margin-top:8px;width:fit-content}
.fayda-status.pending{background:rgba(234,179,8,.1);color:#b45309}
.fayda-status.verified{background:rgba(16,185,129,.1);color:#047857}
.fayda-status.failed{background:rgba(239,68,68,.1);color:var(--red)}
/* File upload */
.upload-zone{border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;cursor:pointer;transition:.2s;position:relative}
.upload-zone:hover{border-color:var(--teal);background:rgba(0,122,138,.03)}
.upload-zone.has-file{border-color:var(--green);background:rgba(16,185,129,.05)}
.upload-zone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer}
.upload-ic{font-size:1.6rem;color:var(--sub);margin-bottom:8px}
.upload-text{font-size:.8rem;color:var(--sub)}
.upload-preview{max-height:80px;max-width:120px;border-radius:6px;margin:0 auto;display:none}
/* Account type cards */
.acct-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.acct-card{border:2px solid var(--border);border-radius:10px;padding:16px;cursor:pointer;transition:.2s;text-align:center}
.acct-card:hover{border-color:var(--teal)}
.acct-card.selected{border-color:var(--teal);background:rgba(0,122,138,.05)}
.acct-card input{display:none}
.acct-ic{font-size:1.8rem;margin-bottom:8px}
.acct-name{font-weight:700;font-size:.9rem;margin-bottom:4px}
.acct-desc{font-size:.72rem;color:var(--sub)}
/* Submit */
.btn-submit{width:100%;background:linear-gradient(135deg,var(--teal),var(--blue));color:#fff;border:none;border-radius:10px;padding:14px;font-size:1rem;font-weight:700;cursor:pointer;transition:.2s;display:flex;align-items:center;justify-content:center;gap:10px;letter-spacing:.02em;margin-top:8px}
.btn-submit:hover{opacity:.92;transform:translateY(-1px);box-shadow:0 4px 16px rgba(0,122,138,.4)}
.btn-submit:disabled{opacity:.6;cursor:not-allowed;transform:none}
/* Alert */
.alert{padding:12px 16px;border-radius:8px;font-size:.85rem;display:flex;align-items:flex-start;gap:10px;margin-bottom:20px}
.alert-danger{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);color:#dc2626}
.alert-list{list-style:none;padding:0;margin:6px 0 0}
.alert-list li{font-size:.8rem;padding:2px 0;display:flex;align-items:center;gap:6px}
.alert-list li::before{content:"•";color:var(--red)}
.progress-bar{height:4px;background:rgba(0,122,138,.15);border-radius:2px;margin-bottom:28px;overflow:hidden}
.progress-fill{height:100%;background:linear-gradient(90deg,var(--teal),var(--gold));border-radius:2px;transition:width .4s ease}
@media(max-width:640px){.form-grid{grid-template-columns:1fr}.form-grid.cols-3{grid-template-columns:1fr}.acct-cards{grid-template-columns:1fr}}
</style>
</head>
<body>
<nav class="top-nav">
  <a href="<?= APP_URL ?>" class="nav-brand">
    <div class="logo-bars"><div class="b b1"></div><div class="b b2"></div><div class="b b3"></div><div class="b b4"></div></div>
    <div><div class="nav-title">ዓባይ ባንክ · Abay Bank</div><div class="nav-sub">Online Banking Services</div></div>
  </a>
  <div class="nav-links">
    <a href="<?= APP_URL ?>/customer/login"><i class="fa-solid fa-user"></i> Customer Login</a>
    <a href="<?= APP_URL ?>/atm"><i class="fa-solid fa-credit-card"></i> ATM</a>
    <a href="<?= APP_URL ?>/login"><i class="fa-solid fa-lock"></i> Staff Login</a>
  </div>
</nav>

<div class="hero">
  <h1><i class="fa-solid fa-building-columns" style="color:var(--gold)"></i> Open Your Account Online</h1>
  <p>Open a verified Abay Bank account from anywhere in Ethiopia using your Fayda National ID. No branch visit needed.</p>
  <div class="steps-row">
    <div class="step"><div class="step-num">1</div>Personal Details</div>
    <div class="step"><div class="step-num">2</div>Fayda Verification</div>
    <div class="step"><div class="step-num">3</div>Upload Documents</div>
    <div class="step"><div class="step-num">4</div>Account Created</div>
  </div>
</div>

<div class="container">
  <div class="progress-bar"><div class="progress-fill" id="progress" style="width:0%"></div></div>

  <?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <i class="fa-solid fa-circle-xmark" style="margin-top:2px"></i>
    <div>
      <strong>Please fix the following errors:</strong>
      <ul class="alert-list">
        <?php foreach ($errors as $field => $msg): ?>
        <li><?= \Web\Core\View::e($msg) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <?php endif; ?>

  <form method="POST" action="<?= APP_URL ?>/online/apply" enctype="multipart/form-data" id="apply-form" novalidate>
    <?= \Web\Core\View::csrfField() ?>

    <!-- Section 1: Personal Info -->
    <div class="card">
      <div class="card-header">
        <i class="fa-solid fa-user"></i>
        <h2>Personal Information</h2>
      </div>
      <div class="card-body">
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">First Name <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-user inp-ic"></i>
              <input type="text" name="first_name" class="form-inp <?= isset($errors['first_name']) ? 'has-error' : '' ?>"
                     placeholder="e.g. Abebe" value="<?= \Web\Core\View::e($old['first_name'] ?? '') ?>" required>
            </div>
            <?php if (isset($errors['first_name'])): ?><span class="err-msg show"><?= \Web\Core\View::e($errors['first_name']) ?></span><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Last Name <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-user inp-ic"></i>
              <input type="text" name="last_name" class="form-inp <?= isset($errors['last_name']) ? 'has-error' : '' ?>"
                     placeholder="e.g. Bekele" value="<?= \Web\Core\View::e($old['last_name'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-envelope inp-ic"></i>
              <input type="email" name="email" class="form-inp <?= isset($errors['email']) ? 'has-error' : '' ?>"
                     placeholder="abebe@email.com" value="<?= \Web\Core\View::e($old['email'] ?? '') ?>" required>
            </div>
            <?php if (isset($errors['email'])): ?><span class="err-msg show"><?= \Web\Core\View::e($errors['email']) ?></span><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Phone Number <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-phone inp-ic"></i>
              <input type="tel" name="phone" class="form-inp"
                     placeholder="09XXXXXXXX or +2519XXXXXXXX" value="<?= \Web\Core\View::e($old['phone'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Date of Birth <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-calendar inp-ic"></i>
              <input type="date" name="date_of_birth" class="form-inp"
                     value="<?= \Web\Core\View::e($old['date_of_birth'] ?? '') ?>"
                     max="<?= date('Y-m-d', strtotime('-18 years')) ?>" required>
            </div>
            <span class="hint">You must be at least 18 years old</span>
          </div>
          <div class="form-group">
            <label class="form-label">Gender <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-venus-mars inp-ic"></i>
              <select name="gender" class="form-sel" required>
                <option value="">Select gender</option>
                <option value="Male" <?= ($old['gender']??'')==='Male'?'selected':'' ?>>Male</option>
                <option value="Female" <?= ($old['gender']??'')==='Female'?'selected':'' ?>>Female</option>
                <option value="Other" <?= ($old['gender']??'')==='Other'?'selected':'' ?>>Other</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Section 2: Fayda National ID -->
    <div class="card">
      <div class="card-header">
        <i class="fa-solid fa-id-card"></i>
        <h2>Fayda National ID Verification</h2>
      </div>
      <div class="card-body">
        <div class="fayda-badge">
          <div class="fayda-icon"><i class="fa-solid fa-fingerprint"></i></div>
          <div>
            <div class="fayda-title">Fayda Digital Identity System</div>
            <div class="fayda-sub">Your identity is verified through Ethiopia's National ID System (Fayda). Your data is protected under NBE regulations.</div>
          </div>
        </div>
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">Fayda ID Number <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-fingerprint inp-ic"></i>
              <input type="text" name="fayda_id" id="fayda_id"
                     class="form-inp <?= isset($errors['fayda_id']) ? 'has-error' : '' ?>"
                     placeholder="e.g. FYD-1234567890123"
                     value="<?= \Web\Core\View::e($old['fayda_id'] ?? '') ?>"
                     style="text-transform:uppercase" required>
            </div>
            <span class="hint">Your 13-digit Fayda National Identification Number</span>
            <?php if (isset($errors['fayda_id'])): ?><span class="err-msg show"><?= \Web\Core\View::e($errors['fayda_id']) ?></span><?php endif; ?>
            <div id="fayda-status" class="fayda-status pending" style="display:none">
              <i class="fa-solid fa-circle-notch fa-spin"></i> Verifying with Fayda system...
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">National ID Number <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-id-badge inp-ic"></i>
              <input type="text" name="national_id"
                     class="form-inp <?= isset($errors['national_id']) ? 'has-error' : '' ?>"
                     placeholder="e.g. ET10000001"
                     value="<?= \Web\Core\View::e($old['national_id'] ?? '') ?>"
                     style="text-transform:uppercase" required>
            </div>
            <?php if (isset($errors['national_id'])): ?><span class="err-msg show"><?= \Web\Core\View::e($errors['national_id']) ?></span><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Occupation</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-briefcase inp-ic"></i>
              <input type="text" name="occupation" class="form-inp"
                     placeholder="e.g. Teacher, Merchant, Engineer"
                     value="<?= \Web\Core\View::e($old['occupation'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Monthly Income (ETB)</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-money-bill inp-ic"></i>
              <input type="number" name="monthly_income" class="form-inp" min="0" step="100"
                     placeholder="e.g. 8000"
                     value="<?= \Web\Core\View::e($old['monthly_income'] ?? '') ?>">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Section 3: Address -->
    <div class="card">
      <div class="card-header">
        <i class="fa-solid fa-location-dot"></i>
        <h2>Address Information</h2>
      </div>
      <div class="card-body">
        <div class="form-grid cols-3">
          <div class="form-group">
            <label class="form-label">Region</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-map inp-ic"></i>
              <select name="region" class="form-sel">
                <option value="">Select Region</option>
                <?php foreach (['Addis Ababa','Amhara','Oromia','SNNPR','Tigray','Somali','Afar','Benishangul-Gumuz','Gambela','Harari','Dire Dawa','Sidama','Southwest Ethiopia'] as $r): ?>
                <option value="<?= $r ?>" <?= ($old['region']??'')===$r?'selected':'' ?>><?= $r ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">City / Town</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-city inp-ic"></i>
              <input type="text" name="city" class="form-inp" placeholder="e.g. Addis Ababa"
                     value="<?= \Web\Core\View::e($old['city'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Sub City / Woreda</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-map-pin inp-ic"></i>
              <input type="text" name="subcity" class="form-inp" placeholder="Sub city or Woreda"
                     value="<?= \Web\Core\View::e($old['subcity'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Kebele</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-map-marker inp-ic"></i>
              <input type="text" name="kebele" class="form-inp" placeholder="Kebele number"
                     value="<?= \Web\Core\View::e($old['kebele'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group full">
            <label class="form-label">Full Address</label>
            <div class="inp-wrap">
              <i class="fa-solid fa-house inp-ic"></i>
              <input type="text" name="address" class="form-inp" placeholder="Street, house number..."
                     value="<?= \Web\Core\View::e($old['address'] ?? '') ?>">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Section 4: Account Type & Branch -->
    <div class="card">
      <div class="card-header">
        <i class="fa-solid fa-building-columns"></i>
        <h2>Account Type &amp; Preferred Branch</h2>
      </div>
      <div class="card-body">
        <div class="section-tag">Choose Account Type</div>
        <div class="acct-cards" id="acct-cards">
          <label class="acct-card <?= ($old['account_type']??'Savings')==='Savings'?'selected':'' ?>" onclick="selectAcct(this,'Savings')">
            <input type="radio" name="account_type" value="Savings" <?= ($old['account_type']??'Savings')==='Savings'?'checked':'' ?>>
            <div class="acct-ic">💰</div>
            <div class="acct-name">Savings Account</div>
            <div class="acct-desc">3.5% interest p.a. · Min balance ETB 100</div>
          </label>
          <label class="acct-card <?= ($old['account_type']??'')==='Current'?'selected':'' ?>" onclick="selectAcct(this,'Current')">
            <input type="radio" name="account_type" value="Current" <?= ($old['account_type']??'')==='Current'?'checked':'' ?>>
            <div class="acct-ic">🏦</div>
            <div class="acct-name">Current Account</div>
            <div class="acct-desc">Unlimited transactions · Business ready</div>
          </label>
          <label class="acct-card <?= ($old['account_type']??'')==='Fixed Deposit'?'selected':'' ?>" onclick="selectAcct(this,'Fixed Deposit')">
            <input type="radio" name="account_type" value="Fixed Deposit" <?= ($old['account_type']??'')==='Fixed Deposit'?'checked':'' ?>>
            <div class="acct-ic">🔒</div>
            <div class="acct-name">Fixed Deposit</div>
            <div class="acct-desc">Up to 8.5% interest · 3–36 months</div>
          </label>
        </div>

        <div class="form-grid" style="margin-top:20px">
          <div class="form-group">
            <label class="form-label">Preferred Branch <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-building inp-ic"></i>
              <select name="preferred_branch" class="form-sel" required>
                <option value="">Select Branch</option>
                <?php foreach ($branches as $b): ?>
                <option value="<?= $b['id'] ?>" <?= ($old['preferred_branch']??'')==$b['id']?'selected':'' ?>>
                  <?= \Web\Core\View::e($b['name']) ?> — <?= \Web\Core\View::e($b['city']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Initial Deposit (ETB) <span class="req">*</span></label>
            <div class="inp-wrap">
              <i class="fa-solid fa-money-bill-wave inp-ic"></i>
              <input type="number" name="initial_deposit" class="form-inp" min="100" step="50"
                     placeholder="Min. ETB 100"
                     value="<?= \Web\Core\View::e($old['initial_deposit'] ?? '500') ?>" required>
            </div>
            <span class="hint">Minimum initial deposit: ETB 100</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Section 5: Documents -->
    <div class="card">
      <div class="card-header">
        <i class="fa-solid fa-file-image"></i>
        <h2>Upload Documents</h2>
      </div>
      <div class="card-body">
        <div class="form-grid cols-3">
          <div class="form-group">
            <label class="form-label">Selfie Photo <span class="req">*</span></label>
            <label class="upload-zone" id="selfie-zone">
              <input type="file" name="selfie" accept="image/*" onchange="previewFile(this,'selfie-zone','selfie-preview')">
              <div class="upload-ic"><i class="fa-solid fa-camera"></i></div>
              <img id="selfie-preview" class="upload-preview">
              <div class="upload-text">Tap to take / upload selfie<br><small>JPG, PNG · Max 5MB</small></div>
            </label>
          </div>
          <div class="form-group">
            <label class="form-label">National ID — Front <span class="req">*</span></label>
            <label class="upload-zone" id="idfront-zone">
              <input type="file" name="id_front" accept="image/*,application/pdf" onchange="previewFile(this,'idfront-zone','idfront-preview')">
              <div class="upload-ic"><i class="fa-solid fa-id-card"></i></div>
              <img id="idfront-preview" class="upload-preview">
              <div class="upload-text">ID Front Side<br><small>JPG, PNG, PDF · Max 5MB</small></div>
            </label>
          </div>
          <div class="form-group">
            <label class="form-label">National ID — Back</label>
            <label class="upload-zone" id="idback-zone">
              <input type="file" name="id_back" accept="image/*" onchange="previewFile(this,'idback-zone','idback-preview')">
              <div class="upload-ic"><i class="fa-solid fa-address-card"></i></div>
              <img id="idback-preview" class="upload-preview">
              <div class="upload-text">ID Back Side<br><small>JPG, PNG · Max 5MB</small></div>
            </label>
          </div>
        </div>
      </div>
    </div>

    <!-- Submit -->
    <div class="card">
      <div class="card-body">
        <div style="background:rgba(0,122,138,.06);border:1px solid rgba(0,122,138,.15);border-radius:10px;padding:16px;margin-bottom:20px;font-size:.82rem;color:var(--sub)">
          <i class="fa-solid fa-shield-halved" style="color:var(--teal);margin-right:6px"></i>
          By submitting this form you agree to Abay Bank's <a href="#" style="color:var(--teal)">Terms &amp; Conditions</a> and
          <a href="#" style="color:var(--teal)">Privacy Policy</a>. Your data is protected under Ethiopian data protection law and NBE guidelines.
          Your Fayda National ID will be verified with the National ID Authority.
        </div>
        <button type="submit" class="btn-submit" id="submit-btn">
          <i class="fa-solid fa-paper-plane"></i>
          <span>Submit Application &amp; Verify Identity</span>
        </button>
      </div>
    </div>
  </form>
</div>

<script>
function selectAcct(el, type) {
  document.querySelectorAll('.acct-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  el.querySelector('input').checked = true;
  updateProgress();
}

function previewFile(input, zoneId, previewId) {
  const zone = document.getElementById(zoneId);
  const preview = document.getElementById(previewId);
  if (input.files && input.files[0]) {
    zone.classList.add('has-file');
    if (input.files[0].type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = e => {
        preview.src = e.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(input.files[0]);
    } else {
      preview.style.display = 'none';
      zone.querySelector('.upload-ic').innerHTML = '<i class="fa-solid fa-file-pdf"></i>';
    }
    zone.querySelector('.upload-text').innerHTML = '<strong>' + input.files[0].name + '</strong>';
    updateProgress();
  }
}

function updateProgress() {
  const fields = ['first_name','last_name','email','phone','date_of_birth','gender','fayda_id','national_id','account_type','preferred_branch','initial_deposit'];
  let filled = 0;
  fields.forEach(f => {
    const el = document.querySelector('[name="' + f + '"]');
    if (el && el.value) filled++;
  });
  const pct = Math.round((filled / fields.length) * 100);
  document.getElementById('progress').style.width = pct + '%';
}

document.querySelectorAll('.form-inp,.form-sel').forEach(el => {
  el.addEventListener('input', updateProgress);
  el.addEventListener('change', updateProgress);
});

// Simulate Fayda live verification on field blur
document.getElementById('fayda_id').addEventListener('blur', function() {
  const val = this.value.trim();
  const statusEl = document.getElementById('fayda-status');
  if (val.length >= 10) {
    statusEl.style.display = 'flex';
    statusEl.className = 'fayda-status pending';
    statusEl.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying with Fayda system...';
    setTimeout(() => {
      statusEl.className = 'fayda-status verified';
      statusEl.innerHTML = '<i class="fa-solid fa-circle-check"></i> Fayda ID format accepted — full verification on submission';
    }, 1800);
  } else if (val.length > 0) {
    statusEl.style.display = 'flex';
    statusEl.className = 'fayda-status failed';
    statusEl.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Fayda ID must be at least 10 characters';
  } else {
    statusEl.style.display = 'none';
  }
});

document.getElementById('apply-form').addEventListener('submit', function() {
  const btn = document.getElementById('submit-btn');
  btn.innerHTML = '<span style="width:20px;height:20px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:inline-block"></span><span>Submitting &amp; Verifying Identity...</span>';
  btn.disabled = true;
});
</script>
</body>
</html>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
