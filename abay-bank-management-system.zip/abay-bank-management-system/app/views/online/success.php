﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application Submitted — Abay Bank</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f1f5f9;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px}
.card{background:#fff;border-radius:16px;padding:40px;max-width:520px;width:100%;text-align:center;box-shadow:0 4px 32px rgba(0,0,0,.1)}
.icon-wrap{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#007A8A,#1B3A5C);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:2.2rem;color:#fff;box-shadow:0 4px 20px rgba(0,122,138,.4)}
.fayda-row{display:flex;align-items:center;gap:10px;background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.2);border-radius:10px;padding:12px 16px;margin:16px 0;text-align:left}
.fayda-row .sc{font-weight:800;font-size:1.1rem;color:#047857}
h1{font-size:1.5rem;font-weight:800;color:#1e293b;margin-bottom:8px}
p{color:#64748b;font-size:.9rem;margin-bottom:20px}
.ref-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;margin-bottom:20px}
.ref-label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#64748b;margin-bottom:4px}
.ref-value{font-size:1.1rem;font-weight:800;color:#1B3A5C;letter-spacing:.05em;font-family:monospace}
.steps{text-align:left;margin:20px 0}
.step-item{display:flex;gap:12px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #f1f5f9}
.step-ic{width:32px;height:32px;border-radius:50%;background:#1B3A5C;color:#C8A84B;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0;font-weight:800}
.step-title{font-size:.88rem;font-weight:600;color:#1e293b}
.step-sub{font-size:.75rem;color:#64748b}
.btn{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#007A8A,#1B3A5C);color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;font-size:.9rem;margin-top:16px}
</style>
</head>
<body>
<div class="card">
  <div class="icon-wrap">
    <?php if ($fayda_result['verified'] ?? false): ?>
    <i class="fa-solid fa-circle-check"></i>
    <?php else: ?>
    <i class="fa-solid fa-clock"></i>
    <?php endif; ?>
  </div>
  <h1>Application Submitted!</h1>
  <p>Your account opening application has been received. You will be notified via email and SMS once your account is activated.</p>

  <div class="ref-box">
    <div class="ref-label">Application Reference Number</div>
    <div class="ref-value"><?= \Web\Core\View::e($ref) ?></div>
  </div>

  <?php if ($fayda_result['verified'] ?? false): ?>
  <div class="fayda-row">
    <i class="fa-solid fa-fingerprint" style="font-size:1.4rem;color:#047857;flex-shrink:0"></i>
    <div>
      <div style="font-size:.82rem;font-weight:700;color:#047857">Fayda Identity Verified</div>
      <div style="font-size:.75rem;color:#64748b">
        Face score: <span class="sc"><?= $fayda_result['face_score'] ?>%</span> &nbsp;·&nbsp;
        ID match: <span class="sc"><?= $fayda_result['id_score'] ?>%</span>
      </div>
    </div>
    <i class="fa-solid fa-circle-check" style="color:#10b981;margin-left:auto;font-size:1.2rem"></i>
  </div>
  <?php else: ?>
  <div class="fayda-row" style="background:rgba(234,179,8,.08);border-color:rgba(234,179,8,.2)">
    <i class="fa-solid fa-exclamation-triangle" style="font-size:1.2rem;color:#b45309;flex-shrink:0"></i>
    <div>
      <div style="font-size:.82rem;font-weight:700;color:#b45309">Manual Verification Needed</div>
      <div style="font-size:.75rem;color:#64748b">A bank officer will review your documents within 1–2 business days.</div>
    </div>
  </div>
  <?php endif; ?>

  <div class="steps">
    <div class="step-item">
      <div class="step-ic">1</div>
      <div><div class="step-title">Application Received</div><div class="step-sub">Your application has been recorded in our system.</div></div>
    </div>
    <div class="step-item">
      <div class="step-ic">2</div>
      <div><div class="step-title">KYC Review</div><div class="step-sub">Our team verifies your Fayda ID and uploaded documents (1–2 business days).</div></div>
    </div>
    <div class="step-item">
      <div class="step-ic">3</div>
      <div><div class="step-title">Account Activation</div><div class="step-sub">You receive SMS/email with your account number and online banking credentials.</div></div>
    </div>
    <div class="step-item" style="border:none">
      <div class="step-ic">4</div>
      <div><div class="step-title">Start Banking</div><div class="step-sub">Use online banking, ATM, or visit any Abay Bank branch.</div></div>
    </div>
  </div>

  <a href="<?= APP_URL ?>/online/apply" class="btn">
    <i class="fa-solid fa-plus"></i> Open Another Account
  </a>
  &nbsp;
  <a href="<?= APP_URL ?>/customer/login" class="btn" style="background:linear-gradient(135deg,#C8A84B,#1B3A5C);margin-left:8px">
    <i class="fa-solid fa-user"></i> Customer Login
  </a>
</div>
</body>
</html>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
