﻿<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-calendar-check" style="color:var(--primary)"></i> Attendance Report</h1>
    <p class="page-subtitle">Employee attendance analysis and leave tracking</p>
  </div>
  <div class="page-actions">
    <input type="month" class="form-control form-control-sm" value="<?= date('Y-m') ?>" style="width:145px" onchange="ABAY.toast('Data refreshed','info')">
    <button class="btn btn-primary" onclick="ABAY.toast('Attendance report exported','success')"><i class="fa-solid fa-download"></i> Export</button>
  </div>
</div>

<!-- KPI -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <?php $kpis = [
    ['156', 'Total Staff', 'fa-people-group', '#6366f1'],
    ['148', 'Present Today', 'fa-circle-check', '#22c55e'],
    ['5', 'On Leave', 'fa-calendar-xmark', '#f59e0b'],
    ['3', 'Absent', 'fa-user-slash', '#ef4444'],
    ['94.8%', 'Attendance Rate', 'fa-chart-line', '#10b981'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Charts -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Weekly Attendance Trend</h3>
    </div>
    <div class="card-body"><canvas id="weekly-chart" height="240"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Attendance by Department</h3>
    </div>
    <div class="card-body"><canvas id="dept-chart" height="240"></canvas></div>
  </div>
</div>

<!-- Monthly Summary Table -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Monthly Attendance Summary</h3>
    <div class="card-tools">
      <input type="text" class="form-control form-control-sm" placeholder="Search employee..." style="width:200px" oninput="filterAttendance(this.value)">
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Department</th>
            <th>Work Days</th>
            <th>Present</th>
            <th>Absent</th>
            <th>Late</th>
            <th>Leave</th>
            <th>Rate</th>
          </tr>
        </thead>
        <tbody id="att-tbody">
          <?php
          $rows = [
            ['Abebe Girma', 'Teller', 22, 21, 1, 0, 0, 95],
            ['Tigist Haile', 'Loans', 22, 22, 0, 0, 0, 100],
            ['Samuel Bekele', 'IT', 22, 20, 0, 2, 0, 91],
            ['Meron Tesfaye', 'Customer Service', 22, 19, 1, 0, 2, 86],
            ['Dawit Alemu', 'HR', 22, 22, 0, 0, 0, 100],
            ['Hana Mulugeta', 'Finance', 22, 20, 2, 0, 0, 91],
            ['Yonas Tadesse', 'Teller', 22, 21, 0, 1, 0, 95],
            ['Rahel Assefa', 'Loans', 22, 18, 0, 0, 4, 82],
          ];
          foreach ($rows as [$n, $d, $wd, $p, $a, $l, $lv, $r]):
            $rColor = $r >= 95 ? '#22c55e' : ($r >= 85 ? '#3b82f6' : '#f59e0b');
          ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($n, 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= $n ?></div>
                  </div>
                </div>
              </td>
              <td><?= $d ?></td>
              <td><?= $wd ?></td>
              <td class="text-success fw-semibold"><?= $p ?></td>
              <td class="text-danger"><?= $a ?></td>
              <td class="text-warning"><?= $l ?></td>
              <td class="text-info"><?= $lv ?></td>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="flex:1;height:6px;background:#e5e7eb;border-radius:3px">
                    <div style="width:<?= $r ?>%;height:100%;background:<?= $rColor ?>;border-radius:3px"></div>
                  </div>
                  <span class="fw-semibold" style="color:<?= $rColor ?>;min-width:38px"><?= $r ?>%</span>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Leave Summary -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Leave Requests Summary</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Leave Type</th>
            <th>From</th>
            <th>To</th>
            <th>Days</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $leaves = [
            ['Meron Tesfaye', 'Annual Leave', '2026-08-18', '2026-08-21', 4, 'Approved'],
            ['Rahel Assefa', 'Sick Leave', '2026-08-19', '2026-08-22', 4, 'Approved'],
            ['Abebe Girma', 'Personal Leave', '2026-09-05', '2026-09-06', 2, 'Pending'],
            ['Hana Mulugeta', 'Annual Leave', '2026-09-15', '2026-09-19', 5, 'Pending'],
          ];
          foreach ($leaves as [$n, $t, $f, $to, $d, $s]):
            $sc = $s === 'Approved' ? 'badge-success' : ($s === 'Pending' ? 'badge-warning' : 'badge-danger');
          ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($n, 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= $n ?></div>
                  </div>
                </div>
              </td>
              <td><?= $t ?></td>
              <td><?= $f ?></td>
              <td><?= $to ?></td>
              <td><span class="badge badge-secondary"><?= $d ?> days</span></td>
              <td><span class="badge <?= $sc ?>"><?= $s ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterAttendance(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#att-tbody tr').forEach(tr => {
      tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;

    new Chart(document.getElementById('weekly-chart'), {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [{
            label: 'Present',
            data: [148, 151, 146, 153, 150, 42],
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34,197,94,.1)',
            fill: true,
            tension: .4
          },
          {
            label: 'Absent',
            data: [3, 2, 5, 1, 3, 8],
            borderColor: '#ef4444',
            tension: .4
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    new Chart(document.getElementById('dept-chart'), {
      type: 'bar',
      data: {
        labels: ['Teller', 'Loans', 'IT', 'HR', 'Finance', 'Cust. Svc'],
        datasets: [{
          label: 'Rate %',
          data: [96, 98, 93, 100, 91, 88],
          backgroundColor: 'rgba(99,102,241,.8)',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            min: 0,
            max: 100
          }
        }
      }
    });
  });
</script>