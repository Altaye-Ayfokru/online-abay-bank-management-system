﻿<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-users" style="color:var(--primary)"></i> Customer Report</h1>
    <p class="page-subtitle">Customer acquisition, segmentation, and behaviour analytics</p>
  </div>
  <div class="page-actions">
    <input type="month" class="form-control form-control-sm" value="<?= date('Y-m') ?>" style="width:145px">
    <button class="btn btn-outline" onclick="ABAY.toast('Printing report...','info')"><i class="fa-solid fa-print"></i> Print</button>
    <button class="btn btn-primary" onclick="ABAY.toast('Customer report exported','success')"><i class="fa-solid fa-file-excel"></i> Export</button>
  </div>
</div>

<!-- KPI Row -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(175px,1fr));margin-bottom:24px">
  <?php $kpis = [
    ['2,450', 'Total Customers', 'fa-users', '#6366f1', '+5.3%'],
    ['2,280', 'Active', 'fa-circle-check', '#22c55e', '+3.1%'],
    ['124', 'New (This Month)', 'fa-user-plus', '#3b82f6', '+18%'],
    ['1,980', 'KYC Verified', 'fa-id-card', '#10b981', '+2.4%'],
    ['170', 'Inactive', 'fa-user-slash', '#f59e0b', '-1.2%'],
  ];
  foreach ($kpis as [$val, $lbl, $ico, $clr, $chg]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $clr ?>20;color:<?= $clr ?>"><i class="fa-solid <?= $ico ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $val ?></div>
        <div class="stat-label"><?= $lbl ?></div>
        <div style="font-size:.77rem;color:<?= str_starts_with($chg, '+') ? '#22c55e' : '#ef4444' ?>;margin-top:3px"><?= $chg ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Charts -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Customer Growth (6 Months)</h3>
    </div>
    <div class="card-body"><canvas id="cust-growth-chart" height="230"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Customer by Account Type</h3>
    </div>
    <div class="card-body"><canvas id="acct-type-chart" height="230"></canvas></div>
  </div>
</div>

<!-- Branch Distribution -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Customers by Branch</h3>
    </div>
    <div class="card-body"><canvas id="branch-dist-chart" height="220"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">KYC Status</h3>
    </div>
    <div class="card-body"><canvas id="kyc-chart" height="220"></canvas></div>
  </div>
</div>

<!-- Top Customers Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fa-solid fa-crown" style="color:#f59e0b"></i> Top Customers by Balance</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Account Type</th>
            <th>Balance</th>
            <th>Branch</th>
            <th>Since</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $tops = [
            [1, 'Alemu Tadesse', 'Savings & Fixed', 'ETB 4,820,000', 'Bole', '2019-03-14', 'Active'],
            [2, 'Tigist Haile', 'Current', 'ETB 3,200,000', 'HQ', '2018-07-22', 'Active'],
            [3, 'Samuel Girma', 'Fixed Deposit', 'ETB 2,950,000', 'Piassa', '2020-01-05', 'Active'],
            [4, 'Meron Bekele', 'Savings', 'ETB 2,100,000', 'Arada', '2021-09-18', 'Active'],
            [5, 'Yonas Assefa', 'Current & Savings', 'ETB 1,850,000', 'Bole', '2017-11-30', 'Active'],
          ];
          foreach ($tops as [$r, $n, $t, $b, $br, $s, $st]): ?>
            <tr>
              <td><span class="badge badge-secondary">#<?= $r ?></span></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($n, 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($n) ?></div>
                  </div>
                </div>
              </td>
              <td><?= htmlspecialchars($t) ?></td>
              <td class="fw-semibold text-primary"><?= $b ?></td>
              <td><?= $br ?></td>
              <td class="text-muted"><?= $s ?></td>
              <td><span class="badge badge-success"><?= $st ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    const months = ['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

    new Chart(document.getElementById('cust-growth-chart'), {
      type: 'line',
      data: {
        labels: months,
        datasets: [{
          label: 'Total Customers',
          data: [2180, 2230, 2280, 2340, 2390, 2450],
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,.1)',
          fill: true,
          tension: .4,
          pointRadius: 4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });

    new Chart(document.getElementById('acct-type-chart'), {
      type: 'bar',
      data: {
        labels: ['Savings', 'Current', 'Fixed Deposit'],
        datasets: [{
          label: 'Customers',
          data: [1620, 530, 300],
          backgroundColor: ['#22c55e', '#3b82f6', '#f59e0b'],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });

    new Chart(document.getElementById('branch-dist-chart'), {
      type: 'doughnut',
      data: {
        labels: ['HQ', 'Bole', 'Piassa', 'Arada', 'Akaki', 'Other'],
        datasets: [{
          data: [620, 480, 340, 290, 240, 480],
          backgroundColor: ['#6366f1', '#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#10b981']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    new Chart(document.getElementById('kyc-chart'), {
      type: 'doughnut',
      data: {
        labels: ['Verified', 'Pending', 'Under Review', 'Rejected'],
        datasets: [{
          data: [1980, 310, 120, 40],
          backgroundColor: ['#22c55e', '#f59e0b', '#3b82f6', '#ef4444']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>