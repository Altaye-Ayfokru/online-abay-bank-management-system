﻿<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-chart-pie" style="color:var(--primary)"></i> Reports Dashboard</h1>
    <p class="page-subtitle">Key performance metrics and executive summary</p>
  </div>
  <div class="page-actions">
    <select class="form-control form-control-sm" id="report-period" onchange="loadReportData()" style="width:150px">
      <option value="today">Today</option>
      <option value="week">This Week</option>
      <option value="month" selected>This Month</option>
      <option value="quarter">This Quarter</option>
      <option value="year">This Year</option>
    </select>
    <button class="btn btn-primary" onclick="ABAY.toast('Dashboard exported to PDF','success')"><i class="fa-solid fa-download"></i> Export PDF</button>
  </div>
</div>

<!-- KPI Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#22c55e,#16a34a)"><i class="fa-solid fa-arrow-trend-up"></i></div>
    <div class="stat-info">
      <div class="stat-value">ETB 8.4M</div>
      <div class="stat-label">Total Deposits</div>
      <div style="font-size:.78rem;color:#22c55e;margin-top:4px"><i class="fa-solid fa-arrow-up"></i> +12.5% vs last month</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#ef4444,#dc2626)"><i class="fa-solid fa-arrow-trend-down"></i></div>
    <div class="stat-info">
      <div class="stat-value">ETB 6.1M</div>
      <div class="stat-label">Total Withdrawals</div>
      <div style="font-size:.78rem;color:#ef4444;margin-top:4px"><i class="fa-solid fa-arrow-up"></i> +8.3% vs last month</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#3b82f6,#2563eb)"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-value">2,450</div>
      <div class="stat-label">Total Customers</div>
      <div style="font-size:.78rem;color:#22c55e;margin-top:4px"><i class="fa-solid fa-arrow-up"></i> +124 new this month</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><i class="fa-solid fa-file-invoice-dollar"></i></div>
    <div class="stat-info">
      <div class="stat-value">ETB 32.7M</div>
      <div class="stat-label">Loan Portfolio</div>
      <div style="font-size:.78rem;color:#22c55e;margin-top:4px"><i class="fa-solid fa-arrow-up"></i> +5.2% growth</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#6366f1,#4f46e5)"><i class="fa-solid fa-building"></i></div>
    <div class="stat-info">
      <div class="stat-value">9</div>
      <div class="stat-label">Active Branches</div>
      <div style="font-size:.78rem;color:var(--text-muted);margin-top:4px">Addis Ababa & regions</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:linear-gradient(135deg,#10b981,#059669)"><i class="fa-solid fa-percent"></i></div>
    <div class="stat-info">
      <div class="stat-value">94.2%</div>
      <div class="stat-label">Loan Recovery Rate</div>
      <div style="font-size:.78rem;color:#22c55e;margin-top:4px"><i class="fa-solid fa-arrow-up"></i> +1.3% improvement</div>
    </div>
  </div>
</div>

<!-- Charts Row 1 -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Monthly Deposits vs Withdrawals</h3>
    </div>
    <div class="card-body"><canvas id="deposit-chart" height="240"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Customer Growth</h3>
    </div>
    <div class="card-body"><canvas id="customer-chart" height="240"></canvas></div>
  </div>
</div>

<!-- Charts Row 2 -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Loan Portfolio by Type</h3>
    </div>
    <div class="card-body"><canvas id="loan-type-chart" height="220"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Transaction Volume (Daily)</h3>
    </div>
    <div class="card-body"><canvas id="txn-volume-chart" height="220"></canvas></div>
  </div>
</div>

<!-- Quick Reports Links -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Quick Access Reports</h3>
  </div>
  <div class="card-body">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px">
      <?php
      $links = [
        ['Financial Report',    '/reports/financial',  'fa-chart-line',    '#22c55e'],
        ['Customer Report',     '/reports/customers',  'fa-users',         '#3b82f6'],
        ['Loan Report',         '/reports/loans',      'fa-file-invoice-dollar', '#f59e0b'],
        ['Attendance Report',   '/reports/attendance', 'fa-calendar-check', '#6366f1'],
        ['Branch Performance',  '/branches/performance', 'fa-building',     '#10b981'],
        ['Transaction History', '/transactions',       'fa-clock-rotate-left', '#ef4444'],
      ];
      foreach ($links as [$label, $href, $icon, $color]):
      ?>
        <a href="<?= APP_URL . $href ?>" class="card" style="text-decoration:none;border:2px solid <?= $color ?>20;transition:.2s;display:flex;align-items:center;gap:12px;padding:16px" onmouseover="this.style.borderColor='<?= $color ?>'" onmouseout="this.style.borderColor='<?= $color ?>20'">
          <div style="width:40px;height:40px;border-radius:10px;background:<?= $color ?>20;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fa-solid <?= $icon ?>" style="color:<?= $color ?>"></i>
          </div>
          <span class="fw-semibold" style="color:var(--text)"><?= $label ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function loadReportData() {
    ABAY.toast('Report data refreshed', 'info');
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    const months = ['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

    new Chart(document.getElementById('deposit-chart'), {
      type: 'bar',
      data: {
        labels: months,
        datasets: [{
            label: 'Deposits',
            data: [5.2, 6.1, 7.4, 6.8, 7.9, 8.4],
            backgroundColor: 'rgba(34,197,94,.8)',
            borderRadius: 5
          },
          {
            label: 'Withdrawals',
            data: [3.9, 4.8, 5.6, 5.1, 5.9, 6.1],
            backgroundColor: 'rgba(239,68,68,.7)',
            borderRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    new Chart(document.getElementById('customer-chart'), {
      type: 'line',
      data: {
        labels: months,
        datasets: [{
          label: 'Customers',
          data: [2180, 2230, 2280, 2340, 2390, 2450],
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59,130,246,.1)',
          fill: true,
          tension: .4,
          pointRadius: 4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: false
          }
        }
      }
    });

    new Chart(document.getElementById('loan-type-chart'), {
      type: 'doughnut',
      data: {
        labels: ['Personal', 'Business', 'Agricultural', 'Mortgage', 'Student'],
        datasets: [{
          data: [35, 28, 18, 12, 7],
          backgroundColor: ['#6366f1', '#3b82f6', '#22c55e', '#f59e0b', '#ef4444']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    new Chart(document.getElementById('txn-volume-chart'), {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
          label: 'Transactions',
          data: [420, 580, 510, 640, 720, 380, 290],
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,.12)',
          fill: true,
          tension: .4,
          pointRadius: 4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  });
</script>