﻿<?php $pageTitle = 'Financial Report — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Financial Report</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Financial Report</span></div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-light btn-sm" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
    <button class="btn btn-outline-primary btn-sm" onclick="exportReportCSV()"><i class="fa-solid fa-file-excel"></i> Export</button>
  </div>
</div>

<!-- Filter Bar -->
<div class="card" style="margin-bottom:20px">
  <div class="card-body" style="padding:14px 20px">
    <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:8px"><label style="font-size:.82rem;font-weight:600;color:#374151">From:</label>
        <input type="date" id="report-from" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.83rem;background:#fff;cursor:pointer;outline:none">
      </div>
      <div style="display:flex;align-items:center;gap:8px"><label style="font-size:.82rem;font-weight:600;color:#374151">To:</label>
        <input type="date" id="report-to" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.83rem;background:#fff;cursor:pointer;outline:none">
      </div>
      <select id="report-branch" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.83rem;background:#fff;cursor:pointer">
        <option value="">All Branches</option><?php foreach (['Bole', 'Kirkos', 'Arada', 'Bahir Dar', 'Hawassa', 'Dire Dawa'] as $b): ?><option><?= $b ?></option><?php endforeach; ?>
      </select>
      <button onclick="generateReport()" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;padding:9px 18px;font-size:.84rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-chart-bar"></i>Generate Report</button>
      <div style="margin-left:auto;display:flex;gap:6px">
        <?php foreach ([[7, '7d'], [30, '30d'], [90, '3m'], [365, '1yr']] as [$days, $lbl]): ?>
          <button onclick="setRange(<?= $days ?>)" style="padding:6px 12px;border:1.5px solid #e2e8f0;border-radius:7px;background:#fff;font-size:.78rem;font-weight:600;cursor:pointer;font-family:inherit;transition:all .2s" onmouseover="this.style.background='#f1f5f9'" onmouseout="this.style.background='#fff'"><?= $lbl ?></button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- KPI Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-arrow-down"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Deposits</div>
      <div class="stat-value" id="rpt-deposits"><?= $etb($s['total_deposits'] ?? 57800000) ?></div>
      <div class="stat-change up"><i class="fa-solid fa-arrow-up"></i> 8.7%</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-arrow-up"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Withdrawals</div>
      <div class="stat-value" id="rpt-withdrawals"><?= $etb($s['total_withdrawals'] ?? 25600000) ?></div>
      <div class="stat-change down"><i class="fa-solid fa-arrow-up"></i> 3.2%</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-file-invoice-dollar"></i></div>
    <div class="stat-content">
      <div class="stat-label">Loans Disbursed</div>
      <div class="stat-value" id="rpt-loans">ETB 89.5M</div>
      <div class="stat-change up"><i class="fa-solid fa-arrow-up"></i> 12.1%</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-chart-line"></i></div>
    <div class="stat-content">
      <div class="stat-label">Net Revenue</div>
      <div class="stat-value" id="rpt-revenue">ETB 10.7M</div>
      <div class="stat-change up"><i class="fa-solid fa-arrow-up"></i> 9.1%</div>
    </div>
  </div>
</div>

<!-- Charts -->
<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px;margin-bottom:22px">
  <div class="card">
    <div class="card-header">
      <h4><i class="fa-solid fa-chart-area" style="color:#1B3A5C;margin-right:6px"></i>Monthly Cash Flow</h4>
    </div>
    <div class="card-body">
      <div style="height:290px"><canvas id="cashflow-chart"></canvas></div>
    </div>
  </div>
  <div class="card">
    <div class="card-header">
      <h4><i class="fa-solid fa-chart-pie" style="color:#1B3A5C;margin-right:6px"></i>Revenue Breakdown</h4>
    </div>
    <div class="card-body">
      <div style="height:290px"><canvas id="revenue-pie"></canvas></div>
    </div>
  </div>
</div>

<!-- Summary Table -->
<div class="card">
  <div class="card-header">
    <h4><i class="fa-solid fa-table" style="color:#1B3A5C;margin-right:6px"></i>Monthly Summary</h4>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Month</th>
          <th>Deposits</th>
          <th>Withdrawals</th>
          <th>Loans</th>
          <th>Repayments</th>
          <th>Revenue</th>
          <th>Net Profit</th>
        </tr>
      </thead>
      <tbody id="report-tbody">
        <tr>
          <td colspan="7" style="text-align:center;padding:40px;color:#94a3b8">Generate a report to see monthly summary</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  // Set default dates
  var today = new Date();
  var y = today.getFullYear();
  document.getElementById('report-to').value = today.toISOString().split('T')[0];
  document.getElementById('report-from').value = y + '-01-01';

  function setRange(days) {
    var t = new Date(),
      f = new Date(t - days * 86400000);
    document.getElementById('report-to').value = t.toISOString().split('T')[0];
    document.getElementById('report-from').value = f.toISOString().split('T')[0];
    generateReport();
  }

  function generateReport() {
    var from = document.getElementById('report-from').value;
    var to = document.getElementById('report-to').value;
    ABAY.api('/reports/financial?from=' + from + '&to=' + to).then(function(d) {
      var data = (d && d.success && d.data) ? d.data : {
        monthly: getDemoMonthly()
      };
      renderReportTable(data.monthly || getDemoMonthly());
    }).catch(function() {
      renderReportTable(getDemoMonthly());
    });
  }

  function getDemoMonthly() {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return months.map(function(m, i) {
      var dep = (1.2 + i * 0.14) * 1e9,
        wd = (0.9 + i * 0.1) * 1e9,
        loans = (0.5 + i * 0.08) * 1e9,
        rep = (0.3 + i * 0.05) * 1e9;
      return {
        month: m,
        deposits: dep,
        withdrawals: wd,
        loans: loans,
        repayments: rep,
        revenue: (dep - wd) * 0.04,
        net_profit: (dep - wd) * 0.025
      };
    });
  }

  function renderReportTable(rows) {
    document.getElementById('report-tbody').innerHTML = rows.map(function(r) {
      return '<tr>' +
        '<td style="font-weight:600">' + r.month + '</td>' +
        '<td style="color:#059669;font-weight:600">' + ABAY.fmtETB(r.deposits) + '</td>' +
        '<td style="color:#ef4444;font-weight:600">' + ABAY.fmtETB(r.withdrawals) + '</td>' +
        '<td>' + ABAY.fmtETB(r.loans) + '</td>' +
        '<td>' + ABAY.fmtETB(r.repayments) + '</td>' +
        '<td style="color:#007A8A;font-weight:600">' + ABAY.fmtETB(r.revenue) + '</td>' +
        '<td style="color:#1B3A5C;font-weight:700">' + ABAY.fmtETB(r.net_profit) + '</td>' +
        '</tr>';
    }).join('');
  }

  function exportReportCSV() {
    var rows = [
      ['Month', 'Deposits', 'Withdrawals', 'Loans', 'Revenue', 'Net Profit']
    ];
    document.querySelectorAll('#report-tbody tr').forEach(function(tr) {
      var cells = tr.querySelectorAll('td');
      if (cells.length > 1) rows.push(Array.from(cells).map(function(td) {
        return td.textContent.trim();
      }));
    });
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'financial-report.csv';
    a.click();
  }

  document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;
    Chart.defaults.font.family = "'Inter',sans-serif";
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    new Chart(document.getElementById('cashflow-chart'), {
      type: 'bar',
      data: {
        labels: months,
        datasets: [{
            label: 'Deposits (ETB B)',
            data: [1.2, 1.4, 1.1, 1.6, 1.8, 2.1, 1.9, 2.4, 2.2, 2.6, 2.3, 2.8],
            backgroundColor: 'rgba(16,185,129,.75)',
            borderRadius: 5
          },
          {
            label: 'Withdrawals (ETB B)',
            data: [0.9, 1.0, 0.8, 1.1, 1.3, 1.5, 1.4, 1.8, 1.6, 1.9, 1.7, 2.0],
            backgroundColor: 'rgba(239,68,68,.65)',
            borderRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: {
                size: 11
              },
              padding: 12
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0,0,0,.04)'
            },
            ticks: {
              callback: function(v) {
                return 'ETB ' + v + 'B';
              }
            }
          }
        }
      }
    });
    new Chart(document.getElementById('revenue-pie'), {
      type: 'doughnut',
      data: {
        labels: ['Interest Income', 'Fee Income', 'FX Gains', 'Other'],
        datasets: [{
          data: [58, 22, 12, 8],
          backgroundColor: ['#1B3A5C', '#007A8A', '#C8A84B', '#10b981'],
          borderWidth: 3,
          borderColor: '#fff',
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: {
                size: 11
              },
              padding: 12
            }
          }
        }
      }
    });
    generateReport();
  });
</script>