﻿<?php

/** @var array $user */ ?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-file-invoice-dollar" style="color:var(--primary)"></i> Loan Report</h1>
    <p class="page-subtitle">Loan portfolio analysis, recovery rates, and disbursement trends</p>
  </div>
  <div class="page-actions">
    <select class="form-control form-control-sm" style="width:150px">
      <option>This Month</option>
      <option>This Quarter</option>
      <option>This Year</option>
    </select>
    <button class="btn btn-primary" onclick="ABAY.toast('Loan report exported','success')"><i class="fa-solid fa-download"></i> Export</button>
  </div>
</div>

<!-- KPI Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(175px,1fr));margin-bottom:24px">
  <?php $kpis = [
    ['124', 'Active Loans', 'fa-file-invoice-dollar', '#6366f1'],
    ['ETB 32.7M', 'Total Portfolio', 'fa-money-bill-wave', '#22c55e'],
    ['ETB 2.8M', 'Disbursed (Month)', 'fa-arrow-right-from-bracket', '#3b82f6'],
    ['94.2%', 'Recovery Rate', 'fa-percent', '#10b981'],
    ['ETB 1.9M', 'Overdue Amount', 'fa-triangle-exclamation', '#ef4444'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Charts -->
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Disbursement vs Repayment (6 Months)</h3>
    </div>
    <div class="card-body"><canvas id="disbursement-chart" height="240"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Loan Portfolio by Type</h3>
    </div>
    <div class="card-body"><canvas id="loan-portfolio-chart" height="240"></canvas></div>
  </div>
</div>
<div class="grid-2" style="margin-bottom:24px">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Loan Status Overview</h3>
    </div>
    <div class="card-body"><canvas id="loan-status-chart" height="220"></canvas></div>
  </div>
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Overdue Aging</h3>
    </div>
    <div class="card-body"><canvas id="overdue-chart" height="220"></canvas></div>
  </div>
</div>

<!-- Loan Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Active Loan Summary</h3>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Loan ID</th>
            <th>Customer</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Outstanding</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Recovery</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $loans = [
            ['L-00001', 'Abebe Girma', 'Personal', 'ETB 150,000', 'ETB 92,400', '2026-09-15', 'Current', '88%'],
            ['L-00002', 'Tigist Haile', 'Business', 'ETB 2,500,000', 'ETB 1,820,000', '2026-09-01', 'Current', '72%'],
            ['L-00003', 'Samuel Bekele', 'Agricultural', 'ETB 80,000', 'ETB 45,200', '2026-08-31', 'Overdue', '56%'],
            ['L-00004', 'Meron Tesfaye', 'Personal', 'ETB 50,000', 'ETB 28,000', '2026-10-10', 'Current', '44%'],
            ['L-00005', 'Dawit Alemu', 'Mortgage', 'ETB 5,000,000', 'ETB 4,200,000', '2026-09-20', 'Current', '16%'],
          ];
          foreach ($loans as [$id, $n, $t, $a, $o, $d, $s, $r]):
            $sc = $s === 'Overdue' ? 'badge-danger' : ($s === 'Current' ? 'badge-success' : 'badge-warning');
          ?>
            <tr>
              <td class="fw-semibold text-primary"><?= $id ?></td>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($n, 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= $n ?></div>
                  </div>
                </div>
              </td>
              <td><span class="badge badge-info"><?= $t ?></span></td>
              <td class="fw-semibold"><?= $a ?></td>
              <td class="text-warning"><?= $o ?></td>
              <td><?= $d ?></td>
              <td><span class="badge <?= $sc ?>"><?= $s ?></span></td>
              <td>
                <div style="display:flex;align-items:center;gap:6px">
                  <div style="flex:1;height:5px;background:#e5e7eb;border-radius:3px">
                    <div style="width:<?= $r ?>;height:100%;background:#22c55e;border-radius:3px"></div>
                  </div>
                  <span style="font-size:.8rem"><?= $r ?></span>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    const months = ['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

    new Chart(document.getElementById('disbursement-chart'), {
      type: 'bar',
      data: {
        labels: months,
        datasets: [{
            label: 'Disbursed',
            data: [2.1, 2.8, 3.2, 2.6, 3.0, 2.8],
            backgroundColor: 'rgba(99,102,241,.8)',
            borderRadius: 5
          },
          {
            label: 'Repaid',
            data: [1.8, 2.2, 2.7, 2.4, 2.6, 2.5],
            backgroundColor: 'rgba(34,197,94,.7)',
            borderRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        },
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    new Chart(document.getElementById('loan-portfolio-chart'), {
      type: 'doughnut',
      data: {
        labels: ['Personal', 'Business', 'Agricultural', 'Mortgage', 'Student'],
        datasets: [{
          data: [35, 28, 18, 12, 7],
          backgroundColor: ['#6366f1', '#3b82f6', '#22c55e', '#f59e0b', '#ef4444']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    new Chart(document.getElementById('loan-status-chart'), {
      type: 'bar',
      data: {
        labels: ['Active', 'Pending', 'Overdue', 'Completed', 'Rejected'],
        datasets: [{
          label: 'Loans',
          data: [80, 18, 15, 40, 12],
          backgroundColor: ['#22c55e', '#f59e0b', '#ef4444', '#3b82f6', '#6b7280'],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });

    new Chart(document.getElementById('overdue-chart'), {
      type: 'bar',
      data: {
        labels: ['1-30 Days', '31-60 Days', '61-90 Days', '>90 Days'],
        datasets: [{
          label: 'Amount (ETB M)',
          data: [0.8, 0.5, 0.4, 0.2],
          backgroundColor: ['#f59e0b', '#ef4444', '#dc2626', '#991b1b'],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
  });
</script>