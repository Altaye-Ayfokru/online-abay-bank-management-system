﻿<?php

/** @var array $appointments @var array $user */
$demoApps = $appointments ?: [
  ['id' => 1, 'customer_name' => 'Abebe Girma', 'branch_name' => 'HQ', 'appointment_date' => '2026-08-22', 'appointment_time' => '09:00', 'purpose' => 'Account Opening', 'status' => 'Confirmed', 'officer' => 'Tigist H.'],
  ['id' => 2, 'customer_name' => 'Samuel Bekele', 'branch_name' => 'Bole', 'appointment_date' => '2026-08-22', 'appointment_time' => '10:30', 'purpose' => 'Loan Consultation', 'status' => 'Confirmed', 'officer' => 'Dawit A.'],
  ['id' => 3, 'customer_name' => 'Meron Tesfaye', 'branch_name' => 'Piassa', 'appointment_date' => '2026-08-22', 'appointment_time' => '14:00', 'purpose' => 'KYC Verification', 'status' => 'Pending', 'officer' => 'TBD'],
  ['id' => 4, 'customer_name' => 'Hana Mulugeta', 'branch_name' => 'HQ', 'appointment_date' => '2026-08-23', 'appointment_time' => '09:30', 'purpose' => 'Investment Advisory', 'status' => 'Pending', 'officer' => 'TBD'],
  ['id' => 5, 'customer_name' => 'Yonas Tadesse', 'branch_name' => 'Arada', 'appointment_date' => '2026-08-25', 'appointment_time' => '11:00', 'purpose' => 'Complaint Follow-up', 'status' => 'Confirmed', 'officer' => 'Rahel A.'],
  ['id' => 6, 'customer_name' => 'Rahel Assefa', 'branch_name' => 'HQ', 'appointment_date' => '2026-08-19', 'appointment_time' => '15:00', 'purpose' => 'Account Closing', 'status' => 'Completed', 'officer' => 'Abebe G.'],
];
$today = date('Y-m-d');
$todayApps = array_filter($demoApps, fn($a) => $a['appointment_date'] === $today);
$upcomingApps = array_filter($demoApps, fn($a) => $a['appointment_date'] > $today);
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-calendar-days" style="color:var(--primary)"></i> Appointments</h1>
    <p class="page-subtitle">Schedule and manage customer appointments across all branches</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-primary" onclick="document.getElementById('appt-modal').classList.add('active')">
      <i class="fa-solid fa-plus"></i> New Appointment
    </button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:24px">
  <?php $kpis = [
    [count($todayApps), 'Today', 'fa-calendar-day', '#6366f1'],
    [count($upcomingApps), 'Upcoming', 'fa-calendar-check', '#3b82f6'],
    [count(array_filter($demoApps, fn($a) => $a['status'] === 'Pending')), 'Pending Confirm', 'fa-clock', '#f59e0b'],
    [count(array_filter($demoApps, fn($a) => $a['status'] === 'Completed')), 'Completed', 'fa-circle-check', '#22c55e'],
  ];
  foreach ($kpis as [$v, $l, $i, $c]): ?>
    <div class="stat-card">
      <div class="stat-icon" style="background:<?= $c ?>20;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $v ?></div>
        <div class="stat-label"><?= $l ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Today's Schedule -->
<?php if (!empty($todayApps)): ?>
  <div class="card" style="margin-bottom:24px;border-left:4px solid var(--primary)">
    <div class="card-header">
      <h3 class="card-title"><i class="fa-solid fa-calendar-day" style="color:var(--primary)"></i> Today's Schedule — <?= date('D, M j, Y') ?></h3>
      <span class="badge badge-primary"><?= count($todayApps) ?> appointments</span>
    </div>
    <div class="card-body" style="padding:0">
      <?php foreach ($todayApps as $a):
        $sc = match ($a['status']) {
          'Confirmed' => 'badge-success',
          'Pending' => 'badge-warning',
          default => 'badge-info'
        };
      ?>
        <div style="display:flex;align-items:center;gap:16px;padding:14px 20px;border-bottom:1px solid var(--border)">
          <div style="background:var(--primary);color:#fff;padding:8px 12px;border-radius:8px;font-weight:700;font-size:.9rem;white-space:nowrap">
            <?= $a['appointment_time'] ?>
          </div>
          <div style="flex:1">
            <div class="fw-semibold"><?= htmlspecialchars($a['customer_name']) ?></div>
            <div class="text-muted" style="font-size:.82rem"><?= htmlspecialchars($a['purpose']) ?> · <?= htmlspecialchars($a['branch_name']) ?></div>
          </div>
          <div style="font-size:.82rem;color:var(--text-muted)">
            <i class="fa-solid fa-user-tie"></i> <?= htmlspecialchars($a['officer']) ?>
          </div>
          <span class="badge <?= $sc ?>"><?= $a['status'] ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<!-- All Appointments Table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">All Appointments</h3>
    <div class="card-tools">
      <input type="text" class="form-control form-control-sm" placeholder="Search..." style="width:200px" oninput="filterAppts(this.value)">
      <select class="form-control form-control-sm" style="width:140px" onchange="filterApptStatus(this.value)">
        <option value="">All Status</option>
        <option>Confirmed</option>
        <option>Pending</option>
        <option>Completed</option>
        <option>Cancelled</option>
      </select>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Customer</th>
            <th>Branch</th>
            <th>Date & Time</th>
            <th>Purpose</th>
            <th>Officer</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="appts-tbody">
          <?php foreach ($demoApps as $a):
            $sc = match ($a['status']) {
              'Confirmed' => 'badge-success',
              'Pending' => 'badge-warning',
              'Completed' => 'badge-info',
              default => 'badge-danger'
            };
          ?>
            <tr>
              <td>
                <div class="cell-user">
                  <div class="avatar avatar-sm" style="background:var(--primary);color:#fff"><?= strtoupper(substr($a['customer_name'], 0, 1)) ?></div>
                  <div class="user-details">
                    <div class="user-name"><?= htmlspecialchars($a['customer_name']) ?></div>
                  </div>
                </div>
              </td>
              <td><?= htmlspecialchars($a['branch_name']) ?></td>
              <td>
                <div><?= $a['appointment_date'] ?></div>
                <div class="text-muted" style="font-size:.8rem"><?= $a['appointment_time'] ?></div>
              </td>
              <td><?= htmlspecialchars($a['purpose']) ?></td>
              <td><?= htmlspecialchars($a['officer']) ?></td>
              <td><span class="badge <?= $sc ?>"><?= $a['status'] ?></span></td>
              <td>
                <div class="table-actions">
                  <?php if ($a['status'] === 'Pending'): ?>
                    <button class="action-btn approve" data-tooltip="Confirm" onclick="ABAY.toast('Appointment confirmed','success')"><i class="fa-solid fa-check"></i></button>
                  <?php endif; ?>
                  <?php if (in_array($a['status'], ['Pending', 'Confirmed'])): ?>
                    <button class="action-btn edit" data-tooltip="Reschedule" onclick="ABAY.toast('Reschedule appointment','info')"><i class="fa-solid fa-calendar-pen"></i></button>
                    <button class="action-btn delete" data-tooltip="Cancel" onclick="ABAY.toast('Appointment cancelled','warning')"><i class="fa-solid fa-xmark"></i></button>
                  <?php endif; ?>
                  <?php if ($a['status'] === 'Confirmed'): ?>
                    <button class="action-btn view" data-tooltip="Mark Done" onclick="ABAY.toast('Appointment marked as completed','success')"><i class="fa-solid fa-circle-check"></i></button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- New Appointment Modal -->
<div class="modal-overlay" id="appt-modal" onclick="if(event.target===this)this.classList.remove('active')">
  <div class="modal" style="max-width:500px">
    <div class="modal-header">
      <h3 class="modal-title"><i class="fa-solid fa-calendar-plus"></i> New Appointment</h3>
      <button class="modal-close" onclick="document.getElementById('appt-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form onsubmit="saveAppt(event)">
        <div class="form-grid-2">
          <div class="form-group form-group-full">
            <label class="form-label required">Customer Name</label>
            <input type="text" class="form-control" placeholder="Customer full name" required>
          </div>
          <div class="form-group">
            <label class="form-label">Branch</label>
            <select class="form-control">
              <option>HQ</option>
              <option>Bole</option>
              <option>Piassa</option>
              <option>Arada</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Purpose</label>
            <select class="form-control">
              <option>Account Opening</option>
              <option>Loan Consultation</option>
              <option>KYC Verification</option>
              <option>Investment Advisory</option>
              <option>Complaint Follow-up</option>
              <option>General Inquiry</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label required">Date</label>
            <input type="date" class="form-control" required min="<?= $today ?>">
          </div>
          <div class="form-group">
            <label class="form-label required">Time</label>
            <input type="time" class="form-control" required>
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Assigned Officer</label>
            <input type="text" class="form-control" placeholder="Assign officer (optional)">
          </div>
          <div class="form-group form-group-full">
            <label class="form-label">Notes</label>
            <textarea class="form-control" rows="2" placeholder="Any special notes..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" onclick="document.getElementById('appt-modal').classList.remove('active')">Cancel</button>
          <button type="submit" class="btn btn-primary">Book Appointment</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function filterAppts(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#appts-tbody tr').forEach(tr => {
      tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  }

  function filterApptStatus(s) {
    s = s.toLowerCase();
    document.querySelectorAll('#appts-tbody tr').forEach(tr => {
      tr.style.display = !s || tr.cells[5].textContent.toLowerCase().includes(s) ? '' : 'none';
    });
  }

  function saveAppt(e) {
    e.preventDefault();
    var form = e.target;
    var fields = form.querySelectorAll('input,select,textarea');
    var custName = '',
      branch = '',
      purpose = 'General Inquiry',
      date = '',
      time = '',
      officer = '',
      notes = '';
    fields.forEach(function(f) {
      var p = f.placeholder || '';
      if (f.type === 'text' && p.includes('full name')) custName = f.value.trim();
      else if (f.tagName === 'SELECT' && f.querySelector('[value=""]')) {
        if (!branch) branch = f.value;
        else purpose = f.value;
      } else if (f.type === 'date') date = f.value;
      else if (f.type === 'time') time = f.value;
      else if (p.includes('fficer')) officer = f.value.trim();
      else if (f.tagName === 'TEXTAREA') notes = f.value.trim();
    });
    if (!custName || !date || !time) {
      ABAY.toast('Customer name, date and time are required.', 'err');
      return;
    }
    var btn = form.querySelector('[type="submit"]');
    ABAY.setBtn(btn, true, 'Booking…');
    ABAY.api('/appointments', {
      method: 'POST',
      body: JSON.stringify({
        customer_name: custName,
        branch: branch,
        purpose: purpose,
        appointment_date: date,
        appointment_time: time,
        officer: officer,
        notes: notes
      })
    }).then(function(d) {
      ABAY.setBtn(btn, false, 'Book Appointment');
      if (d && d.success) {
        document.getElementById('appt-modal').classList.remove('active');
        ABAY.toast('Appointment booked for ' + custName + ' on ' + date, 'success');
        setTimeout(function() {
          location.reload();
        }, 1200);
      } else {
        ABAY.toast((d && d.message) || 'Failed to book appointment.', 'err');
      }
    }).catch(function() {
      ABAY.setBtn(btn, false, 'Book Appointment');
      document.getElementById('appt-modal').classList.remove('active');
      ABAY.toast('Demo: Appointment for ' + custName + ' on ' + date + ' recorded.', 'info');
    });
  }
</script>