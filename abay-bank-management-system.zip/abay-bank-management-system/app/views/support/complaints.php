﻿<?php
$pageTitle = 'Complaints — ' . APP_NAME;

$complaintRows = $complaints ?? [];
if (empty($complaintRows)) {
  $complaintRows = [
    ['id' => 1, 'ref_number' => 'CMP-001', 'customer_name' => 'Abebe Bekele', 'category' => 'ATM Issue', 'subject' => 'ATM swallowed my card at Bole branch', 'assigned_to' => 'Yohannes B.', 'priority' => 'High',  'status' => 'Open',       'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
    ['id' => 2, 'ref_number' => 'CMP-002', 'customer_name' => 'Tigist Haile', 'category' => 'Online Banking', 'subject' => 'Cannot login to mobile app', 'assigned_to' => 'Hanna T.', 'priority' => 'Medium', 'status' => 'In Progress', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 3, 'ref_number' => 'CMP-003', 'customer_name' => 'Solomon Girma', 'category' => 'Transfer',    'subject' => 'Transfer delayed for 3 days', 'assigned_to' => 'Solomon G.', 'priority' => 'High', 'status' => 'Resolved',  'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
    ['id' => 4, 'ref_number' => 'CMP-004', 'customer_name' => 'Meron Alemu',  'category' => 'Charges',     'subject' => 'Unexpected charges on account', 'assigned_to' => 'Tigist H.', 'priority' => 'Low', 'status' => 'Open',       'created_at' => date('Y-m-d H:i:s', strtotime('-4 hours'))],
    ['id' => 5, 'ref_number' => 'CMP-005', 'customer_name' => 'Dawit Mekonnen', 'category' => 'Loan',       'subject' => 'Loan approval taking too long', 'assigned_to' => 'Dawit A.', 'priority' => 'Medium', 'status' => 'In Progress', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
    ['id' => 6, 'ref_number' => 'CMP-006', 'customer_name' => 'Hanna Getnet', 'category' => 'Account',     'subject' => 'Account wrongly suspended', 'assigned_to' => 'Meron G.', 'priority' => 'High', 'status' => 'Resolved',  'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))],
  ];
}

$total      = count($complaintRows);
$open       = count(array_filter($complaintRows, fn($r) => ($r['status'] ?? '') === 'Open'));
$inProgress = count(array_filter($complaintRows, fn($r) => ($r['status'] ?? '') === 'In Progress'));
$resolved   = count(array_filter($complaintRows, fn($r) => ($r['status'] ?? '') === 'Resolved'));
?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Complaint Management</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Complaints</span>
    </div>
  </div>
  <button class="btn btn-primary btn-sm" onclick="document.getElementById('new-complaint-modal').style.display='flex'"><i class="fa-solid fa-plus"></i> Log Complaint</button>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-comment-dots"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Complaints</div>
      <div class="stat-value"><?= $total ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Open</div>
      <div class="stat-value"><?= $open ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-gear"></i></div>
    <div class="stat-content">
      <div class="stat-label">In Progress</div>
      <div class="stat-value"><?= $inProgress ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Resolved</div>
      <div class="stat-value"><?= $resolved ?></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-comment-dots" style="color:#1B3A5C;margin-right:7px"></i>All Complaints</h3>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <input type="search" id="comp-search" placeholder="Search complaints..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:200px;outline:none" oninput="filterComps(this.value)">
      <select id="comp-status-filter" onchange="filterComps()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
        <option value="">All Status</option>
        <option>Open</option>
        <option>In Progress</option>
        <option>Resolved</option>
        <option>Closed</option>
      </select>
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Ref. No.</th>
          <th>Customer</th>
          <th>Category</th>
          <th>Subject</th>
          <th>Assigned To</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Submitted</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="complaints-tbody">
        <?php foreach ($complaintRows as $row): ?>
          <?php
          $sc = match ($row['status'] ?? '') {
            'Resolved' => 'success',
            'Closed' => 'secondary',
            'Open' => 'warning',
            'In Progress' => 'info',
            default => 'secondary'
          };
          $pc = match ($row['priority'] ?? '') {
            'High' => 'danger',
            'Medium' => 'warning',
            'Low' => 'info',
            default => 'secondary'
          };
          $diff = time() - strtotime($row['created_at'] ?? 'now');
          $ago  = $diff < 3600 ? round($diff / 60) . 'm ago' : ($diff < 86400 ? round($diff / 3600) . 'h ago' : round($diff / 86400) . 'd ago');
          ?>
          <tr data-subject="<?= strtolower(htmlspecialchars($row['subject'] ?? '')) ?>" data-status="<?= htmlspecialchars($row['status'] ?? '') ?>">
            <td><span style="font-family:monospace;font-size:.76rem;color:#475569;font-weight:600"><?= htmlspecialchars($row['ref_number'] ?? '—') ?></span></td>
            <td style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($row['customer_name'] ?? '—') ?></td>
            <td><span style="font-size:.76rem;background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:6px;font-weight:600"><?= htmlspecialchars($row['category'] ?? '—') ?></span></td>
            <td style="font-size:.81rem;color:#475569;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?= htmlspecialchars($row['subject'] ?? '') ?>"><?= htmlspecialchars($row['subject'] ?? '—') ?></td>
            <td style="font-size:.81rem"><?= htmlspecialchars($row['assigned_to'] ?? 'Unassigned') ?></td>
            <td><span class="badge badge-<?= $pc ?>"><?= htmlspecialchars($row['priority'] ?? '—') ?></span></td>
            <td><span class="badge badge-<?= $sc ?>"><?= htmlspecialchars($row['status'] ?? '—') ?></span></td>
            <td style="font-size:.77rem;color:#94a3b8"><?= $ago ?></td>
            <td>
              <div style="display:flex;gap:4px">
                <button onclick="viewComplaint(<?= htmlspecialchars(json_encode($row)) ?>)" style="padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="View Details"><i class="fa-solid fa-eye" style="color:#007A8A"></i></button>
                <?php if (in_array($row['status'] ?? '', ['Open', 'In Progress'])): ?>
                  <button onclick="resolveComplaint(<?= (int)($row['id'] ?? 0) ?>,this)" style="padding:4px 8px;border:none;border-radius:6px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Resolve"><i class="fa-solid fa-check"></i></button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- View Complaint Modal -->
<div id="view-complaint-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:500px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Complaint Details</div>
      <button onclick="document.getElementById('view-complaint-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px" id="complaint-detail-body"></div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <div style="flex:1"><label style="font-size:.77rem;font-weight:600;color:#374151;display:block;margin-bottom:4px">Response / Update</label><textarea id="comp-response" rows="2" placeholder="Add a response or update..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-size:.84rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea></div>
      <div style="display:flex;flex-direction:column;justify-content:flex-end;gap:8px">
        <button onclick="sendCompResponse()" style="padding:9px 16px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.84rem;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap"><i class="fa-solid fa-paper-plane" style="margin-right:5px"></i>Send</button>
        <button onclick="document.getElementById('view-complaint-modal').style.display='none'" style="padding:9px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.84rem;font-weight:600;cursor:pointer;font-family:inherit">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- New Complaint Modal -->
<div id="new-complaint-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Log New Complaint</div>
      <button onclick="document.getElementById('new-complaint-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px">
      <div id="comp-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#065f46"></div>
      <div id="comp-err" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:11px;margin-bottom:12px;font-size:.84rem;color:#991b1b"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Customer Name *</label><input id="comp-cust" type="text" placeholder="Customer name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Category *</label><select id="comp-cat" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
            <option value="">Select...</option>
            <option>ATM Issue</option>
            <option>Online Banking</option>
            <option>Transfer</option>
            <option>Charges</option>
            <option>Loan</option>
            <option>Account</option>
            <option>Card</option>
            <option>Other</option>
          </select></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Priority</label><select id="comp-priority" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
            <option>Low</option>
            <option selected>Medium</option>
            <option>High</option>
          </select></div>
        <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Assign To</label><input id="comp-assign" type="text" placeholder="Staff name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      </div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Subject *</label><input id="comp-subject" type="text" placeholder="Brief description of the complaint" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
      <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Details</label><textarea id="comp-details" rows="3" placeholder="Full details of the complaint..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea></div>
    </div>
    <div style="padding:13px 22px 18px;border-top:1px solid #f1f5f9;display:flex;gap:10px;justify-content:flex-end">
      <button onclick="document.getElementById('new-complaint-modal').style.display='none'" style="padding:10px 16px;background:#f1f5f9;color:#374151;border:none;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;font-family:inherit">Cancel</button>
      <button id="comp-submit-btn" onclick="submitComplaint()" style="padding:10px 20px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:8px;font-size:.85rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px"><i class="fa-solid fa-paper-plane"></i>Log Complaint</button>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _currentCompId = null;

  function filterComps(q) {
    q = typeof q === 'string' ? q.toLowerCase() : document.getElementById('comp-search').value.toLowerCase();
    var status = document.getElementById('comp-status-filter').value;
    document.querySelectorAll('#complaints-tbody tr').forEach(function(tr) {
      var subj = tr.dataset.subject || '';
      var s = tr.dataset.status || '';
      tr.style.display = ((!q || subj.includes(q)) && (!status || s === status)) ? '' : 'none';
    });
  }

  function viewComplaint(row) {
    _currentCompId = row.id;
    var priorityColors = {
      High: '#fee2e2|#dc2626',
      Medium: '#fef3c7|#d97706',
      Low: '#dbeafe|#2563eb'
    };
    var [pbg, pc] = (priorityColors[row.priority] || '#f1f5f9|#475569').split('|');
    document.getElementById('complaint-detail-body').innerHTML =
      '<div style="display:flex;flex-direction:column;gap:10px">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><span style="font-family:monospace;font-size:.82rem;color:#475569;font-weight:600">' + (row.ref_number || '—') + '</span><div style="display:flex;gap:7px">' +
      '<span class="badge badge-' + (row.status === 'Resolved' ? 'success' : row.status === 'In Progress' ? 'info' : 'warning') + '">' + (row.status || '—') + '</span>' +
      '<span style="font-size:.75rem;padding:2px 8px;border-radius:6px;font-weight:700;background:' + pbg + ';color:' + pc + '">' + (row.priority || '—') + '</span>' +
      '</div></div>' +
      '<div style="background:#f8fafc;border-radius:9px;padding:13px">' +
      '<div style="font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:9px">Complaint Details</div>' +
      '<div style="display:grid;gap:7px">' +
      '<div style="display:flex;justify-content:space-between"><span style="font-size:.79rem;color:#64748b">Customer</span><span style="font-size:.81rem;font-weight:600">' + (row.customer_name || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between"><span style="font-size:.79rem;color:#64748b">Category</span><span style="font-size:.81rem;font-weight:600">' + (row.category || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between"><span style="font-size:.79rem;color:#64748b">Assigned To</span><span style="font-size:.81rem;font-weight:600">' + (row.assigned_to || 'Unassigned') + '</span></div>' +
      '</div></div>' +
      '<div style="background:#eff6ff;border-radius:9px;padding:13px"><div style="font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px">Subject</div>' +
      '<div style="font-size:.86rem;color:#1e293b;font-weight:600">' + (row.subject || '—') + '</div></div>' +
      '</div>';
    document.getElementById('view-complaint-modal').style.display = 'flex';
  }

  function sendCompResponse() {
    var resp = document.getElementById('comp-response').value.trim();
    if (!resp) {
      if (window.ABAY) ABAY.toast('Please enter a response.', 'err');
      return;
    }
    // Fixed: remove :id from URL — complaint_id is sent in body. Was: /complaints/:id/respond
    var base = window.BASE_URL || '';
    fetch(base + '/api/complaints/respond', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
        },
        body: JSON.stringify({
          complaint_id: _currentCompId,
          response: resp
        })
      })
      .then(function(r) {
        return r.json();
      })
      .then(function(d) {
        if (window.ABAY) ABAY.toast('Response sent!', 'ok');
        document.getElementById('comp-response').value = '';
      })
      .catch(function() {
        if (window.ABAY) ABAY.toast('Demo: Response recorded.', 'info');
        document.getElementById('comp-response').value = '';
      });
  }

  function resolveComplaint(id, btn) {
    if (!confirm('Mark this complaint as Resolved?')) return;
    btn.disabled = true;
    // Fixed: POST to /complaints/resolve with id in body. Was: PUT /complaints/:id/resolve
    var base = window.BASE_URL || '';
    fetch(base + '/api/complaints/resolve', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer ' + (localStorage.getItem('abay_token') || '')
        },
        body: JSON.stringify({
          id: id,
          complaint_id: id,
          resolution: 'Resolved by staff'
        })
      })
      .then(function(r) {
        return r.json();
      })
      .then(function() {
        var tr = btn.closest('tr');
        var badge = tr.querySelector('.badge');
        if (badge) {
          badge.textContent = 'Resolved';
          badge.className = 'badge badge-success';
        }
        tr.querySelector('td:last-child').innerHTML = '<span style="font-size:.75rem;color:#94a3b8">—</span>';
        if (window.ABAY) ABAY.toast('Complaint resolved!', 'ok');
      })
      .catch(function() {
        var tr = btn.closest('tr');
        var badge = tr.querySelector('.badge');
        if (badge) {
          badge.textContent = 'Resolved';
          badge.className = 'badge badge-success';
        }
        tr.querySelector('td:last-child').innerHTML = '<span style="font-size:.75rem;color:#94a3b8">—</span>';
        if (window.ABAY) ABAY.toast('Demo: Complaint resolved.', 'info');
      });
  }

  function submitComplaint() {
    var cust = document.getElementById('comp-cust').value.trim();
    var cat = document.getElementById('comp-cat').value;
    var subj = document.getElementById('comp-subject').value.trim();
    document.getElementById('comp-err').style.display = 'none';
    if (!cust || !cat || !subj) {
      document.getElementById('comp-err').textContent = 'Customer, category and subject are required.';
      document.getElementById('comp-err').style.display = 'block';
      return;
    }
    ABAY.setBtn('comp-submit-btn', true);
    ABAY.api('/complaints', {
      method: 'POST',
      body: JSON.stringify({
        customer_name: cust,
        category: cat,
        subject: subj,
        priority: document.getElementById('comp-priority').value,
        assigned_to: document.getElementById('comp-assign').value,
        details: document.getElementById('comp-details').value
      })
    }).then(function(d) {
      ABAY.setBtn('comp-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Log Complaint');
      if (d && d.success) {
        document.getElementById('comp-ok').textContent = 'Complaint logged successfully! Ref: ' + (d.data && d.data.ref_number ? d.data.ref_number : 'N/A');
        document.getElementById('comp-ok').style.display = 'block';
        ABAY.toast('Complaint logged!', 'ok');
        setTimeout(function() {
          document.getElementById('new-complaint-modal').style.display = 'none';
          location.reload();
        }, 1500);
      } else {
        document.getElementById('comp-err').textContent = (d && d.message) || 'Failed to log complaint.';
        document.getElementById('comp-err').style.display = 'block';
      }
    }).catch(function() {
      ABAY.setBtn('comp-submit-btn', false, '<i class="fa-solid fa-paper-plane"></i>Log Complaint');
      document.getElementById('comp-ok').textContent = 'Demo: Complaint logged (Database offline). Ref: CMP-' + Date.now().toString(36).toUpperCase();
      document.getElementById('comp-ok').style.display = 'block';
      ABAY.toast('Demo complaint logged.', 'info');
      setTimeout(function() {
        document.getElementById('new-complaint-modal').style.display = 'none';
      }, 1500);
    });
  }
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      document.getElementById('new-complaint-modal').style.display = 'none';
      document.getElementById('view-complaint-modal').style.display = 'none';
    }
  });
</script>