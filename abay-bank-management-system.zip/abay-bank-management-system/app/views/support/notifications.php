﻿<?php
$pageTitle = 'Notifications — ' . APP_NAME;

// Use PHP data if available, else demo
$notifRows = $notifs ?? [];
if (empty($notifRows)) {
  $notifRows = [
    ['id' => 1, 'type' => 'transaction', 'icon' => 'fa-arrow-down',     'color' => '#10b981', 'title' => 'Deposit Received',             'message' => 'ETB 45,000 deposited to account 0001-10-100001 by Abebe Bekele', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-5 min'))],
    ['id' => 2, 'type' => 'loan',      'icon' => 'fa-circle-check',    'color' => '#007A8A', 'title' => 'Loan Application Approved',    'message' => 'Loan #LN-20260001 for ETB 150,000 has been approved by Branch Manager', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-15 min'))],
    ['id' => 3, 'type' => 'alert',     'icon' => 'fa-shield-halved',   'color' => '#ef4444', 'title' => 'Failed Login Attempt',         'message' => '5 failed login attempts from IP 192.168.1.105 for user "teller"', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-32 min'))],
    ['id' => 4, 'type' => 'system',    'icon' => 'fa-gear',             'color' => '#1B3A5C', 'title' => 'System Maintenance Scheduled', 'message' => 'Scheduled maintenance on Sunday 2:00 AM – 4:00 AM EAT. Brief downtime expected.', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
    ['id' => 5, 'type' => 'employee',  'icon' => 'fa-user-clock',      'color' => '#f59e0b', 'title' => 'Leave Request Pending',        'message' => 'Tigist Haile has submitted a 5-day annual leave request starting Aug 25', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
    ['id' => 6, 'type' => 'transaction', 'icon' => 'fa-triangle-exclamation', 'color' => '#f59e0b', 'title' => 'Overdue Loan Alert',     'message' => 'Account 1000-0048 — Loan payment overdue by 15 days. EMI: ETB 7,050', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))],
    ['id' => 7, 'type' => 'system',    'icon' => 'fa-building-columns', 'color' => '#1B3A5C', 'title' => 'Branch EOD Report Ready',    'message' => 'Bahir Dar branch end-of-day report for August 21, 2026 is now available', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-4 hours'))],
    ['id' => 8, 'type' => 'loan',      'icon' => 'fa-hourglass-half',  'color' => '#f59e0b', 'title' => 'Loan Awaiting Approval',      'message' => '47 loan applications are pending manager approval. Oldest: 3 days ago.', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours'))],
    ['id' => 9, 'type' => 'employee',  'icon' => 'fa-user-plus',       'color' => '#3b82f6', 'title' => 'New Employee Registered',     'message' => 'Bereket Tadesse (EMP020) has been added to HR department at Kirkos branch', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-6 hours'))],
    ['id' => 10, 'type' => 'alert',    'icon' => 'fa-lock',             'color' => '#ef4444', 'title' => 'Account Frozen',             'message' => 'Customer account 0005-10-100006 has been frozen due to suspicious activity', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
  ];
}

$total   = count($notifRows);
$unread  = count(array_filter($notifRows, fn($r) => !($r['is_read'] ?? 0)));
$alerts  = count(array_filter($notifRows, fn($r) => ($r['type'] ?? '') === 'alert'));
$read    = $total - $unread;

function relTime(string $dt): string
{
  $diff = time() - strtotime($dt);
  if ($diff < 60) return 'Just now';
  if ($diff < 3600) return round($diff / 60) . 'm ago';
  if ($diff < 86400) return round($diff / 3600) . 'h ago';
  return round($diff / 86400) . 'd ago';
}
?>
<div class="page-header">
  <div class="page-header-left">
    <h1>Notifications</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Notifications</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" onclick="markAllRead()"><i class="fa-solid fa-check-double"></i> Mark All Read</button>
    <button class="btn btn-ghost btn-sm" onclick="clearAllNotifs()" style="color:#ef4444"><i class="fa-solid fa-trash"></i> Clear All</button>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-bell"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total</div>
      <div class="stat-value" id="notif-total"><?= $total ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-circle"></i></div>
    <div class="stat-content">
      <div class="stat-label">Unread</div>
      <div class="stat-value" id="notif-unread"><?= $unread ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div class="stat-content">
      <div class="stat-label">Alerts</div>
      <div class="stat-value"><?= $alerts ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-check"></i></div>
    <div class="stat-content">
      <div class="stat-label">Read</div>
      <div class="stat-value" id="notif-read"><?= $read ?></div>
    </div>
  </div>
</div>

<!-- Filter tabs -->
<div style="display:flex;gap:8px;margin-bottom:18px;flex-wrap:wrap">
  <button class="btn btn-primary btn-sm" id="filter-all" onclick="filterNotif('all',this)">All (<?= $total ?>)</button>
  <button class="btn btn-ghost btn-sm" id="filter-transaction" onclick="filterNotif('transaction',this)"><i class="fa-solid fa-money-bill-wave"></i> Transactions</button>
  <button class="btn btn-ghost btn-sm" id="filter-loan" onclick="filterNotif('loan',this)"><i class="fa-solid fa-file-invoice-dollar"></i> Loans</button>
  <button class="btn btn-ghost btn-sm" id="filter-alert" onclick="filterNotif('alert',this)"><i class="fa-solid fa-triangle-exclamation"></i> Security Alerts</button>
  <button class="btn btn-ghost btn-sm" id="filter-system" onclick="filterNotif('system',this)"><i class="fa-solid fa-gear"></i> System</button>
  <button class="btn btn-ghost btn-sm" id="filter-employee" onclick="filterNotif('employee',this)"><i class="fa-solid fa-people-group"></i> HR</button>
</div>

<!-- Notification list -->
<div class="card" id="notifications-container">
  <div id="notif-full-list" style="display:flex;flex-direction:column">
    <?php foreach ($notifRows as $row): ?>
      <?php
      $isRead = (bool)($row['is_read'] ?? 0);
      $ago = relTime($row['created_at'] ?? 'now');
      ?>
      <div class="notif-item" data-id="<?= (int)($row['id'] ?? 0) ?>" data-type="<?= htmlspecialchars($row['type'] ?? 'system') ?>" data-read="<?= $isRead ? '1' : '0' ?>"
        style="display:flex;align-items:flex-start;gap:14px;padding:16px 20px;border-bottom:1px solid #f1f5f9;transition:background .15s;background:<?= $isRead ? '#fff' : '#f0fbfc' ?>;cursor:pointer"
        onclick="markRead(<?= (int)($row['id'] ?? 0) ?>,this)"
        onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='<?= $isRead ? '#fff' : '#f0fbfc' ?>'">
        <!-- Icon -->
        <div style="width:40px;height:40px;border-radius:10px;background:<?= htmlspecialchars($row['color'] ?? '#1B3A5C') ?>1a;color:<?= htmlspecialchars($row['color'] ?? '#1B3A5C') ?>;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0">
          <i class="fa-solid <?= htmlspecialchars($row['icon'] ?? 'fa-bell') ?>"></i>
        </div>
        <!-- Content -->
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
            <div style="font-size:.86rem;font-weight:<?= $isRead ? '600' : '800' ?>;color:#1e293b"><?= htmlspecialchars($row['title'] ?? 'Notification') ?></div>
            <div style="display:flex;align-items:center;gap:8px;flex-shrink:0">
              <span style="font-size:.72rem;color:#94a3b8"><?= $ago ?></span>
              <?php if (!$isRead): ?>
                <span style="width:8px;height:8px;border-radius:50%;background:#007A8A;flex-shrink:0"></span>
              <?php endif; ?>
            </div>
          </div>
          <div style="font-size:.82rem;color:#64748b;margin-top:3px;line-height:1.5"><?= htmlspecialchars($row['message'] ?? '') ?></div>
          <div style="display:flex;align-items:center;gap:12px;margin-top:8px">
            <span style="font-size:.7rem;font-weight:700;padding:2px 8px;border-radius:99px;background:<?= htmlspecialchars($row['color'] ?? '#1B3A5C') ?>1a;color:<?= htmlspecialchars($row['color'] ?? '#1B3A5C') ?>;text-transform:uppercase;letter-spacing:.5px"><?= ucfirst(htmlspecialchars($row['type'] ?? 'system')) ?></span>
            <?php if (!$isRead): ?>
              <button onclick="event.stopPropagation();markRead(<?= (int)($row['id'] ?? 0) ?>,this.closest('.notif-item'))" style="font-size:.72rem;color:#007A8A;font-weight:600;background:none;border:none;cursor:pointer;font-family:inherit;padding:0">Mark as read</button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div style="padding:12px 20px;font-size:.8rem;color:#94a3b8;border-top:1px solid #f1f5f9" id="notif-info">
    Showing <?= $total ?> notifications
  </div>
</div>

<!-- Send Notification Panel -->
<div class="card" style="margin-top:20px">
  <div class="card-header">
    <h3><i class="fa-solid fa-paper-plane" style="color:#1B3A5C;margin-right:7px"></i>Send Notification</h3>
  </div>
  <div class="card-body">
    <div id="send-ok" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:8px;padding:11px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:14px">
      <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Target Audience</label>
        <select id="send-target" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
          <option>All Users</option>
          <option>All Customers</option>
          <option>All Employees</option>
          <option>Branch Managers</option>
        </select>
      </div>
      <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Channel</label>
        <select id="send-channel" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
          <option>In-App</option>
          <option>Email</option>
          <option>SMS</option>
          <option>All Channels</option>
        </select>
      </div>
      <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Priority</label>
        <select id="send-priority" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;background:#fff;cursor:pointer">
          <option>Normal</option>
          <option>High</option>
          <option>Urgent</option>
        </select>
      </div>
    </div>
    <div style="margin-bottom:12px"><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Title *</label>
      <input type="text" id="send-title" placeholder="Notification title..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
    </div>
    <div style="margin-bottom:16px"><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Message *</label>
      <textarea id="send-message" rows="3" placeholder="Write your notification message..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:.85rem;width:100%;resize:none;outline:none;font-family:inherit" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></textarea>
    </div>
    <button id="send-btn" onclick="sendNotification()" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:9px;padding:11px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px"><i class="fa-solid fa-paper-plane"></i> Send Notification</button>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _activeFilter = 'all';

  function filterNotif(type, btn) {
    _activeFilter = type;
    // Update buttons
    document.querySelectorAll('[id^="filter-"]').forEach(function(b) {
      b.className = 'btn btn-ghost btn-sm';
    });
    if (btn) btn.className = 'btn btn-primary btn-sm';
    // Filter items
    var items = document.querySelectorAll('.notif-item');
    var shown = 0;
    items.forEach(function(item) {
      var show = type === 'all' || item.dataset.type === type;
      item.style.display = show ? '' : 'none';
      if (show) shown++;
    });
    document.getElementById('notif-info').textContent = 'Showing ' + shown + ' notification' + (shown !== 1 ? 's' : '');
  }

  function markRead(id, item) {
    if (!item || item.dataset.read === '1') return;
    item.dataset.read = '1';
    item.style.background = '#fff';
    item.onmouseout = function() {
      this.style.background = '#fff';
    };
    var dot = item.querySelector('[style*="border-radius:50%;background:#007A8A"]');
    if (dot) dot.remove();
    var readBtn = item.querySelector('button[onclick*="markRead"]');
    if (readBtn) readBtn.remove();
    // Update title weight
    var title = item.querySelector('[style*="font-weight"]');
    if (title) title.style.fontWeight = '600';
    // Update counts
    var unreadEl = document.getElementById('notif-unread');
    var readEl = document.getElementById('notif-read');
    if (unreadEl) unreadEl.textContent = Math.max(0, parseInt(unreadEl.textContent) - 1);
    if (readEl) readEl.textContent = parseInt(readEl.textContent) + 1;
    // API call
    ABAY.api('/notifications/' + id + '/read', {
      method: 'PUT',
      body: JSON.stringify({})
    }).catch(function() {});
  }

  function markAllRead() {
    document.querySelectorAll('.notif-item[data-read="0"]').forEach(function(item) {
      markRead(item.dataset.id, item);
    });
    ABAY.toast('All notifications marked as read.', 'ok');
    ABAY.api('/notifications/read-all', {
      method: 'PUT',
      body: JSON.stringify({})
    }).catch(function() {});
  }

  function clearAllNotifs() {
    if (!confirm('Clear all notifications? This cannot be undone.')) return;
    document.getElementById('notif-full-list').innerHTML =
      '<div style="text-align:center;padding:48px;color:#94a3b8"><i class="fa-solid fa-bell-slash" style="font-size:2rem;margin-bottom:12px;display:block"></i>No notifications</div>';
    document.getElementById('notif-total').textContent = '0';
    document.getElementById('notif-unread').textContent = '0';
    document.getElementById('notif-read').textContent = '0';
    document.getElementById('notif-info').textContent = 'No notifications';
    ABAY.toast('All notifications cleared.', 'info');
  }

  function sendNotification() {
    var title = document.getElementById('send-title').value.trim();
    var msg = document.getElementById('send-message').value.trim();
    if (!title || !msg) {
      ABAY.toast('Title and message are required.', 'err');
      return;
    }
    ABAY.setBtn('send-btn', true);
    ABAY.api('/notifications/send', {
      method: 'POST',
      body: JSON.stringify({
        title: title,
        message: msg,
        target: document.getElementById('send-target').value,
        channel: document.getElementById('send-channel').value,
        priority: document.getElementById('send-priority').value
      })
    }).then(function(d) {
      ABAY.setBtn('send-btn', false, '<i class="fa-solid fa-paper-plane"></i> Send Notification');
      document.getElementById('send-ok').textContent = 'Notification sent to ' + document.getElementById('send-target').value + ' via ' + document.getElementById('send-channel').value + '.';
      document.getElementById('send-ok').style.display = 'block';
      document.getElementById('send-title').value = '';
      document.getElementById('send-message').value = '';
      ABAY.toast('Notification sent!', 'ok');
    }).catch(function() {
      ABAY.setBtn('send-btn', false, '<i class="fa-solid fa-paper-plane"></i> Send Notification');
      document.getElementById('send-ok').textContent = 'Demo: Notification queued (Database offline). Would send to ' + document.getElementById('send-target').value + '.';
      document.getElementById('send-ok').style.display = 'block';
      ABAY.toast('Demo notification queued.', 'info');
    });
  }
</script>