<?php

/** @var array $pending @var array $user */
$demoPending = $pending ?: [
  ['id' => 1, 'txn_id' => 'TXN-00482', 'account_number' => '1000012345678', 'type' => 'Transfer Out', 'amount' => 250000, 'description' => 'Wire to Commercial Bank Ethiopia', 'created_at' => date('Y-m-d H:i:s', time() - 300), 'created_by' => 'teller_abebe', 'status' => 'Pending'],
  ['id' => 2, 'txn_id' => 'TXN-00481', 'account_number' => '1000098765432', 'type' => 'Withdrawal', 'amount' => 150000, 'description' => 'Counter withdrawal — manager approval required', 'created_at' => date('Y-m-d H:i:s', time() - 600), 'created_by' => 'teller_tigist', 'status' => 'Pending'],
  ['id' => 3, 'txn_id' => 'TXN-00480', 'account_number' => '1000011223344', 'type' => 'Deposit', 'amount' => 500000, 'description' => 'Cash deposit — large amount flagged for AML', 'created_at' => date('Y-m-d H:i:s', time() - 900), 'created_by' => 'teller_samuel', 'status' => 'Pending'],
];
?>
<div class="page-header">
  <div>
    <h1 class="page-title"><i class="fa-solid fa-circle-check" style="color:var(--primary)"></i> Transaction Approvals</h1>
    <p class="page-subtitle">Review and approve high-value or flagged transactions</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-outline" onclick="approveAll()"><i class="fa-solid fa-check-double"></i> Approve All</button>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(165px,1fr));margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon" style="background:#f59e0b20;color:#f59e0b"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= count($demoPending) ?></div>
      <div class="stat-label">Pending</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#ef444420;color:#ef4444"><i class="fa-solid fa-money-bill-wave"></i></div>
    <div class="stat-info">
      <div class="stat-value">ETB <?= number_format(array_sum(array_column($demoPending, 'amount'))) ?></div>
      <div class="stat-label">Total Amount</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#22c55e20;color:#22c55e"><i class="fa-solid fa-circle-check"></i></div>
    <div class="stat-info">
      <div class="stat-value">24</div>
      <div class="stat-label">Approved Today</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#6366f120;color:#6366f1"><i class="fa-solid fa-shield-halved"></i></div>
    <div class="stat-info">
      <div class="stat-value">1</div>
      <div class="stat-label">AML Flagged</div>
    </div>
  </div>
</div>

<!-- Pending Transactions -->
<div style="display:flex;flex-direction:column;gap:16px">
  <?php foreach ($demoPending as $txn):
    $typeIcon = match ($txn['type']) {
      'Deposit' => 'fa-arrow-down',
      'Withdrawal' => 'fa-arrow-up',
      default => 'fa-right-left'
    };
    $typeColor = match ($txn['type']) {
      'Deposit' => '#22c55e',
      'Withdrawal' => '#ef4444',
      default => '#3b82f6'
    };
    $aml = str_contains(strtolower($txn['description']), 'aml');
  ?>
    <div class="card" style="border-left:4px solid <?= $typeColor ?><?= $aml ? ' border:2px solid #ef4444' : '' ?>">
      <?php if ($aml): ?>
        <div style="background:#ef444415;padding:8px 20px;display:flex;align-items:center;gap:8px;font-size:.83rem;color:#ef4444;border-bottom:1px solid #ef444430">
          <i class="fa-solid fa-shield-halved"></i> <strong>AML Flag:</strong> Large cash deposit requires enhanced due diligence
        </div>
      <?php endif; ?>
      <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:16px">
          <div>
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
              <div style="width:36px;height:36px;border-radius:10px;background:<?= $typeColor ?>20;display:flex;align-items:center;justify-content:center">
                <i class="fa-solid <?= $typeIcon ?>" style="color:<?= $typeColor ?>"></i>
              </div>
              <div>
                <span class="fw-semibold"><?= $txn['type'] ?></span>
                <span class="badge badge-warning" style="margin-left:8px"><?= $txn['txn_id'] ?></span>
              </div>
            </div>
            <p class="text-muted" style="margin:0;font-size:.83rem"><?= htmlspecialchars($txn['description']) ?></p>
          </div>
          <div style="text-align:right">
            <div style="font-size:1.5rem;font-weight:700;color:<?= $typeColor ?>">ETB <?= number_format($txn['amount']) ?></div>
            <div class="text-muted" style="font-size:.82rem">Acct: <?= htmlspecialchars($txn['account_number']) ?></div>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div class="text-muted" style="font-size:.82rem">
            <i class="fa-solid fa-user"></i> <?= htmlspecialchars($txn['created_by']) ?>
            &nbsp;·&nbsp;
            <i class="fa-solid fa-clock"></i> <?= $txn['created_at'] ?>
          </div>
          <div style="display:flex;gap:10px">
            <button class="btn btn-outline" onclick="ABAY.toast('Viewing transaction details','info')">
              <i class="fa-solid fa-eye"></i> Details
            </button>
            <button class="btn btn-outline" style="color:#ef4444;border-color:#ef4444" onclick="rejectTxn('<?= $txn['txn_id'] ?>')">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
            <button class="btn btn-success" onclick="approveTxn('<?= $txn['txn_id'] ?>')">
              <i class="fa-solid fa-check"></i> Approve
            </button>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>

  <?php if (empty($demoPending)): ?>
    <div class="card">
      <div class="card-body" style="text-align:center;padding:48px">
        <i class="fa-solid fa-circle-check" style="font-size:3rem;color:#22c55e;display:block;margin-bottom:12px"></i>
        <h3>All Clear!</h3>
        <p class="text-muted">No transactions pending approval.</p>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  function approveTxn(id) {
    if (!confirm('Approve transaction ' + id + '?')) return;
    ABAY.api('/transactions/approve', {method:'POST',body:JSON.stringify({transaction_id:id})})
      .then(function(d){if(d&&d.success){ABAY.toast('Transaction '+id+' approved','ok');setTimeout(function(){location.reload();},1200);}else{ABAY.toast((d&&d.message)||'Failed','err');}})
      .catch(function(){ABAY.toast('Demo: Txn '+id+' approved','success');setTimeout(function(){location.reload();},1200);});
  }
  function rejectTxn(id) {
    var r=prompt('Reason for rejection:'); if(!r) return;
    ABAY.toast('Transaction '+id+' rejected','warning'); setTimeout(function(){location.reload();},1000);
  }
  function approveAll() {
    if (!confirm('Approve ALL pending transactions? This cannot be undone.')) return;
    ABAY.api('/transactions/approve',{method:'POST',body:JSON.stringify({action:'approve_all'})})
      .then(function(){ABAY.toast('All approved','success');setTimeout(function(){location.reload();},1300);})
      .catch(function(){ABAY.toast('Demo: All approved','success');setTimeout(function(){location.reload();},1300);});
  }
</script>
