<?php $pageTitle = 'Cash Deposit — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-arrow-down" style="color:#10b981;margin-right:8px"></i>Cash Deposit</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span>
      <a href="<?= APP_URL ?>/transactions">Transactions</a><span class="sep">/</span><span>Deposit</span>
    </div>
  </div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-arrow-down" style="color:#10b981;margin-right:7px"></i>Deposit Form</h3>
    </div>
    <div class="card-body">
      <div id="dep-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:16px;margin-bottom:18px;display:none">
        <div style="display:flex;align-items:center;gap:10px">
          <i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.3rem"></i>
          <div>
            <div style="font-weight:700;color:#065f46">Deposit Successful!</div>
            <div style="font-size:.84rem;color:#047857" id="dep-success-msg"></div>
          </div>
        </div>
        <div style="margin-top:12px;display:flex;gap:8px">
          <button onclick="resetDepositForm()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-plus"></i> New Deposit</button>
          <a href="<?= APP_URL ?>/transactions" class="btn btn-ghost btn-sm"><i class="fa-solid fa-list"></i> View All</a>
        </div>
      </div>
      <div id="dep-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:14px;margin-bottom:18px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px">
        <i class="fa-solid fa-circle-xmark"></i><span id="dep-error-msg"></span>
      </div>

      <form id="deposit-form" novalidate>
        <!-- Account lookup -->
        <div style="background:#f8fafc;border-radius:10px;padding:16px;margin-bottom:18px">
          <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-building-columns" style="color:#007A8A;margin-right:5px"></i>Account Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Account Number <span style="color:#ef4444">*</span></label>
              <input type="text" id="dep-account" name="dep-account" class="form-control" placeholder="Enter account number..." oninput="lookupAccount(this.value)" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;outline:none;transition:border .2s" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Account Holder</label>
              <input type="text" id="dep-holder" class="form-control" readonly placeholder="Auto-filled on lookup" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <div id="account-info-box" style="display:none;margin-top:14px;background:linear-gradient(135deg,#d1fae5,#a7f3d0);border-radius:10px;padding:14px 16px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
              <div>
                <div style="font-size:.65rem;color:#065f46;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Account Type</div>
                <div style="font-weight:700;color:#059669" id="acc-type">—</div>
              </div>
              <div>
                <div style="font-size:.65rem;color:#065f46;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Current Balance</div>
                <div style="font-weight:800;font-size:1.2rem;color:#059669" id="acc-balance">—</div>
              </div>
              <div>
                <div style="font-size:.65rem;color:#065f46;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Status</div><span class="badge badge-success badge-dot" id="acc-status">Active</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Deposit details -->
        <div style="background:#f8fafc;border-radius:10px;padding:16px;margin-bottom:18px">
          <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-coins" style="color:#007A8A;margin-right:5px"></i>Deposit Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Deposit Type <span style="color:#ef4444">*</span></label>
              <select name="deposit-type" id="dep-type" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#fff;cursor:pointer">
                <option>Cash</option>
                <option>Cheque</option>
                <option>Bank Transfer</option>
                <option>Mobile Money</option>
              </select>
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Amount (ETB) <span style="color:#ef4444">*</span></label>
              <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden;transition:border .2s" id="dep-amount-wrap">
                <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                <input type="number" id="dep-amount" name="dep-amount" min="1" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.88rem;outline:none;background:#fff" oninput="updateDepPreview()" onfocus="document.getElementById('dep-amount-wrap').style.borderColor='#007A8A'" onblur="document.getElementById('dep-amount-wrap').style.borderColor='#e2e8f0'">
              </div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Transaction Date</label>
              <input type="datetime-local" id="dep-date" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#fff">
            </div>
            <div>
              <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Reference No.</label>
              <input type="text" id="dep-ref" readonly placeholder="Auto-generated" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <div>
            <label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Narration / Description</label>
            <textarea id="dep-narration" rows="2" placeholder="Purpose of deposit..." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;resize:none;outline:none;font-family:inherit" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></textarea>
          </div>
        </div>

        <div style="display:flex;gap:12px;justify-content:flex-end">
          <button type="button" class="btn btn-ghost" onclick="resetDepositForm()"><i class="fa-solid fa-rotate"></i> Reset</button>
          <button type="submit" id="dep-btn" class="btn btn-success btn-lg" style="background:linear-gradient(135deg,#059669,#10b981);border:none;color:#fff;padding:12px 28px;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-arrow-down"></i> Process Deposit</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Summary Panel -->
  <div style="display:flex;flex-direction:column;gap:18px">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:6px"></i>Transaction Summary</h4>
      </div>
      <div class="card-body">
        <div style="display:flex;flex-direction:column;gap:10px">
          <?php foreach ([['Account', 'sum-account', '—'], ['Customer', 'sum-customer', '—'], ['Deposit Amount', 'sum-amount', 'ETB 0.00'], ['Current Balance', 'sum-balance', '—'], ['New Balance', 'sum-new', '—'], ['Date & Time', 'sum-date', '—']] as [$l, $id, $d]): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
              <span style="font-size:.79rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
              <span style="font-size:.82rem;font-weight:600;color:#1e293b" id="<?= $id ?>"><?= $d ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-chart-line" style="color:#1B3A5C;margin-right:6px"></i>Today's Deposits</h4>
      </div>
      <div class="card-body" style="text-align:center">
        <div style="font-size:.72rem;color:#94a3b8;margin-bottom:6px">Total Deposited Today</div>
        <div style="font-size:1.6rem;font-weight:900;color:#059669;margin:4px 0" id="today-total">ETB <?= number_format((float)($todayDeposits ?? 1250000), 2) ?></div>
        <div style="font-size:.74rem;color:#94a3b8"><?= number_format((int)($todayTxns ?? 234)) ?> transactions</div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-circle-info" style="color:#1B3A5C;margin-right:6px"></i>Guidelines</h4>
      </div>
      <div class="card-body">
        <ul style="padding-left:16px;display:flex;flex-direction:column;gap:7px;list-style:disc;font-size:.8rem;color:#64748b">
          <li>Minimum deposit: ETB 1</li>
          <li>Cash deposits processed immediately</li>
          <li>Cheque deposits: 1-2 clearing days</li>
          <li>Daily cash limit: ETB 500,000</li>
          <li>Above ETB 1M: Manager verification required</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _depAccount = null;

  function generateRef() {
    return 'DEP-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substr(2, 4).toUpperCase();
  }

  function lookupAccount(val) {
    if (val.length < 4) return;
    clearTimeout(window._lookupTimer);
    window._lookupTimer = setTimeout(function() {
      ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
        var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
        if (!acc) {
          // Demo fallback
          acc = {
            account_number: val,
            account_type: 'Savings',
            balance: 84500,
            status: 'Active',
            customer_name: 'Demo Customer'
          };
        }
        fillAccount(acc);
      }).catch(function() {
        fillAccount({
          account_number: val,
          account_type: 'Savings',
          balance: 84500,
          status: 'Active',
          customer_name: 'Demo Customer'
        });
      });
    }, 500);
  }

  function fillAccount(acc) {
    _depAccount = acc;
    document.getElementById('dep-holder').value = acc.customer_name || acc.holder || '—';
    document.getElementById('acc-type').textContent = acc.account_type || 'Savings';
    document.getElementById('acc-balance').textContent = ABAY.fmtETB(acc.balance || 0);
    document.getElementById('acc-status').textContent = acc.status || 'Active';
    document.getElementById('account-info-box').style.display = 'block';
    document.getElementById('sum-account').textContent = acc.account_number || '—';
    document.getElementById('sum-customer').textContent = acc.customer_name || '—';
    document.getElementById('sum-balance').textContent = ABAY.fmtETB(acc.balance || 0);
    document.getElementById('dep-ref').value = generateRef();
    var now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('dep-date').value = now.toISOString().slice(0, 16);
    updateDepPreview();
  }

  function updateDepPreview() {
    var amt = parseFloat(document.getElementById('dep-amount').value) || 0;
    document.getElementById('sum-amount').textContent = ABAY.fmtETB(amt);
    if (_depAccount) {
      var newBal = (_depAccount.balance || 0) + amt;
      document.getElementById('sum-new').textContent = ABAY.fmtETB(newBal);
      document.getElementById('sum-date').textContent = new Date().toLocaleString('en-ET');
    }
  }

  function resetDepositForm() {
    _depAccount = null;
    document.getElementById('deposit-form').reset();
    document.getElementById('account-info-box').style.display = 'none';
    document.getElementById('dep-holder').value = '';
    document.getElementById('dep-ref').value = '';
    document.getElementById('dep-success').style.display = 'none';
    document.getElementById('dep-error').style.display = 'none';
    ['sum-account', 'sum-customer', 'sum-amount', 'sum-balance', 'sum-new', 'sum-date'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) el.textContent = id === 'sum-amount' ? 'ETB 0.00' : '—';
    });
  }

  document.getElementById('deposit-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var acc = document.getElementById('dep-account').value.trim();
    var amt = parseFloat(document.getElementById('dep-amount').value) || 0;
    var desc = document.getElementById('dep-narration').value.trim() || 'Cash Deposit';
    var ref = document.getElementById('dep-ref').value || generateRef();
    document.getElementById('dep-error').style.display = 'none';
    if (!acc) {
      document.getElementById('dep-error-msg').textContent = 'Account number is required.';
      document.getElementById('dep-error').style.display = 'flex';
      return;
    }
    if (amt < 1) {
      document.getElementById('dep-error-msg').textContent = 'Please enter a valid amount (minimum ETB 1).';
      document.getElementById('dep-error').style.display = 'flex';
      return;
    }
    ABAY.setBtn('dep-btn', true);
    ABAY.api('/transactions/deposit', {
      method: 'POST',
      body: JSON.stringify({
        account_number: acc,
        amount: amt,
        description: desc,
        reference: ref
      })
    }).then(function(d) {
      ABAY.setBtn('dep-btn', false, '<i class="fa-solid fa-arrow-down"></i> Process Deposit');
      if (d && d.success) {
        document.getElementById('dep-success-msg').textContent = 'ETB ' + amt.toFixed(2) + ' deposited to ' + acc + '. Reference: ' + (d.data && d.data.reference ? d.data.reference : ref);
        document.getElementById('dep-success').style.display = 'block';
        document.getElementById('deposit-form').style.display = 'none';
        ABAY.toast('Deposit of ' + ABAY.fmtETB(amt) + ' successful!', 'ok');
      } else {
        document.getElementById('dep-error-msg').textContent = (d && d.message) || 'Deposit failed. Please try again.';
        document.getElementById('dep-error').style.display = 'flex';
      }
    }).catch(function() {
      ABAY.setBtn('dep-btn', false, '<i class="fa-solid fa-arrow-down"></i> Process Deposit');
      // Demo mode
      document.getElementById('dep-success-msg').textContent = 'Demo: ETB ' + amt.toFixed(2) + ' deposited to ' + acc + '. Reference: ' + ref + ' (Database offline — demo mode)';
      document.getElementById('dep-success').style.display = 'block';
      document.getElementById('deposit-form').style.display = 'none';
      ABAY.toast('Demo deposit recorded.', 'info');
    });
  });
</script>