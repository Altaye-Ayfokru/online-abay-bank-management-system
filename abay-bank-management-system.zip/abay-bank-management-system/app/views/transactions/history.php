﻿<?php
$pageTitle = 'Transaction History — ' . APP_NAME;

// Use PHP data from controller, or demo data
$txRows = $transactions ?? [];
if (empty($txRows)) {
  $txRows = [
    ['id' => 'TXN001', 'reference' => 'DEP-A1B2C3', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 min')), 'account_number' => '0001-10-100001', 'customer_name' => 'Abebe Bekele',   'type' => 'Deposit',     'amount' => 15000, 'status' => 'Completed', 'description' => 'Cash deposit', 'channel' => 'Counter'],
    ['id' => 'TXN002', 'reference' => 'WDR-B2C3D4', 'created_at' => date('Y-m-d H:i:s', strtotime('-18 min')), 'account_number' => '0001-20-100002', 'customer_name' => 'Tigist Haile',    'type' => 'Withdrawal',  'amount' => 5000,  'status' => 'Completed', 'description' => 'ATM withdrawal', 'channel' => 'ATM'],
    ['id' => 'TXN003', 'reference' => 'TRF-C3D4E5', 'created_at' => date('Y-m-d H:i:s', strtotime('-32 min')), 'account_number' => '0001-10-100001', 'customer_name' => 'Abebe Bekele',   'type' => 'Transfer Out', 'amount' => 8200,  'status' => 'Completed', 'description' => 'Fund transfer to Tigist H.', 'channel' => 'Online'],
    ['id' => 'TXN004', 'reference' => 'DEP-D4E5F6', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour')),  'account_number' => '0002-10-100003', 'customer_name' => 'Solomon Girma',  'type' => 'Deposit',     'amount' => 22500, 'status' => 'Pending',  'description' => 'Salary deposit', 'channel' => 'Counter'],
    ['id' => 'TXN005', 'reference' => 'TRF-E5F6G7', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours')), 'account_number' => '0003-20-100004', 'customer_name' => 'Meron Alemu',    'type' => 'Transfer In', 'amount' => 12000, 'status' => 'Completed', 'description' => 'Received from Dawit M.', 'channel' => 'Online'],
    ['id' => 'TXN006', 'reference' => 'WDR-F6G7H8', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours')), 'account_number' => '0002-20-100005', 'customer_name' => 'Dawit Mekonnen', 'type' => 'Withdrawal',  'amount' => 3200,  'status' => 'Completed', 'description' => 'Counter withdrawal', 'channel' => 'Counter'],
    ['id' => 'TXN007', 'reference' => 'DEP-G7H8I9', 'created_at' => date('Y-m-d H:i:s', strtotime('-4 hours')), 'account_number' => '0004-10-100006', 'customer_name' => 'Hanna Getnet',   'type' => 'Deposit',     'amount' => 45000, 'status' => 'Completed', 'description' => 'Business revenue', 'channel' => 'Counter'],
    ['id' => 'TXN008', 'reference' => 'LNP-H8I9J0', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours')), 'account_number' => '0003-10-100007', 'customer_name' => 'Yared Gebre',    'type' => 'Loan Payment', 'amount' => 7050,  'status' => 'Completed', 'description' => 'EMI payment LN-001', 'channel' => 'Online'],
    ['id' => 'TXN009', 'reference' => 'IBT-I9J0K1', 'created_at' => date('Y-m-d H:i:s', strtotime('-6 hours')), 'account_number' => '0001-20-100002', 'customer_name' => 'Tigist Haile',   'type' => 'Transfer Out', 'amount' => 25000, 'status' => 'Completed', 'description' => 'Inter-bank transfer to CBE', 'channel' => 'Online'],
    ['id' => 'TXN010', 'reference' => 'DEP-J0K1L2', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')),   'account_number' => '0005-10-100008', 'customer_name' => 'Bereket Tadesse', 'type' => 'Deposit',     'amount' => 100000, 'status' => 'Completed', 'description' => 'Initial deposit', 'channel' => 'Counter'],
  ];
}

// Compute stats from data
$totalCount = count($txRows);
$totalDeposits = array_sum(array_map(fn($r) => in_array($r['type'], ['Deposit', 'Transfer In']) ? ($r['amount'] ?? 0) : 0, $txRows));
$totalWithdrawals = array_sum(array_map(fn($r) => in_array($r['type'], ['Withdrawal', 'Transfer Out']) ? ($r['amount'] ?? 0) : 0, $txRows));
$totalTransfers = array_sum(array_map(fn($r) => $r['type'] === 'Transfer Out' ? ($r['amount'] ?? 0) : 0, $txRows));
$pendingCount = count(array_filter($txRows, fn($r) => ($r['status'] ?? '') === 'Pending'));

function txRelTime(string $dt): string
{
  $d = time() - strtotime($dt);
  if ($d < 60) return 'Just now';
  if ($d < 3600) return round($d / 60) . 'm ago';
  if ($d < 86400) return round($d / 3600) . 'h ago';
  return date('d M, H:i', strtotime($dt));
}
?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-clock-rotate-left" style="color:#1B3A5C;margin-right:8px"></i>Transaction History</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Transactions</span>
    </div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <button class="btn btn-light btn-sm" onclick="exportTxnCSV()"><i class="fa-solid fa-file-csv"></i> Export CSV</button>
    <button class="btn btn-light btn-sm" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
    <a href="<?= APP_URL ?>/transactions/deposit" class="btn btn-success btn-sm"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
    <a href="<?= APP_URL ?>/transactions/withdrawal" class="btn btn-danger btn-sm"><i class="fa-solid fa-arrow-up"></i> Withdraw</a>
    <a href="<?= APP_URL ?>/transactions/transfer" class="btn btn-primary btn-sm"><i class="fa-solid fa-right-left"></i> Transfer</a>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon blue"><i class="fa-solid fa-list"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Transactions</div>
      <div class="stat-value"><?= number_format($totalCount) ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green"><i class="fa-solid fa-arrow-down"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Deposits</div>
      <div class="stat-value" style="font-size:1.1rem">ETB <?= number_format($totalDeposits / 1000, 1) ?>K</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon red"><i class="fa-solid fa-arrow-up"></i></div>
    <div class="stat-content">
      <div class="stat-label">Total Withdrawals</div>
      <div class="stat-value" style="font-size:1.1rem">ETB <?= number_format($totalWithdrawals / 1000, 1) ?>K</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon teal"><i class="fa-solid fa-right-left"></i></div>
    <div class="stat-content">
      <div class="stat-label">Transfers</div>
      <div class="stat-value" style="font-size:1.1rem">ETB <?= number_format($totalTransfers / 1000, 1) ?>K</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon yellow"><i class="fa-solid fa-hourglass-half"></i></div>
    <div class="stat-content">
      <div class="stat-label">Pending</div>
      <div class="stat-value"><?= $pendingCount ?></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3><i class="fa-solid fa-list" style="color:#1B3A5C;margin-right:7px"></i>All Transactions</h3>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <input type="search" id="txn-search" placeholder="Search ref, account, customer..." style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;width:220px;outline:none" oninput="filterTxns()">
      <select id="txn-type-filter" onchange="filterTxns()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
        <option value="">All Types</option>
        <option>Deposit</option>
        <option>Withdrawal</option>
        <option>Transfer Out</option>
        <option>Transfer In</option>
        <option>Loan Payment</option>
      </select>
      <select id="txn-status-filter" onchange="filterTxns()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
        <option value="">All Status</option>
        <option>Completed</option>
        <option>Pending</option>
        <option>Failed</option>
      </select>
      <input type="date" id="txn-date-from" onchange="filterTxns()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
      <input type="date" id="txn-date-to" onchange="filterTxns()" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-size:.84rem;background:#fff;cursor:pointer">
    </div>
  </div>
  <div class="table-responsive">
    <table class="data-table" id="txn-table">
      <thead>
        <tr>
          <th>Reference</th>
          <th>Date & Time</th>
          <th>Account</th>
          <th>Customer</th>
          <th>Type</th>
          <th>Amount (ETB)</th>
          <th>Channel</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="txn-tbody">
        <?php foreach ($txRows as $t): ?>
          <?php
          $typeColor = match ($t['type'] ?? '') {
            'Deposit', 'Transfer In' => 'success',
            'Withdrawal', 'Transfer Out' => 'danger',
            'Loan Payment' => 'warning',
            default => 'info'
          };
          $statusColor = match ($t['status'] ?? '') {
            'Completed' => 'success',
            'Pending' => 'warning',
            'Failed' => 'danger',
            default => 'info'
          };
          $ago = txRelTime($t['created_at'] ?? 'now');
          $isCredit = in_array($t['type'] ?? '', ['Deposit', 'Transfer In']);
          ?>
          <tr data-ref="<?= strtolower(htmlspecialchars($t['reference'] ?? '')) ?>"
            data-account="<?= strtolower(htmlspecialchars($t['account_number'] ?? '')) ?>"
            data-customer="<?= strtolower(htmlspecialchars($t['customer_name'] ?? '')) ?>"
            data-type="<?= htmlspecialchars($t['type'] ?? '') ?>"
            data-status="<?= htmlspecialchars($t['status'] ?? '') ?>"
            data-date="<?= htmlspecialchars(substr($t['created_at'] ?? '', 0, 10)) ?>">
            <td>
              <span style="font-family:monospace;font-size:.76rem;color:#475569;font-weight:600"><?= htmlspecialchars($t['reference'] ?? '—') ?></span>
            </td>
            <td>
              <div style="font-size:.82rem;color:#1e293b"><?= date('d M Y', strtotime($t['created_at'] ?? 'now')) ?></div>
              <div style="font-size:.72rem;color:#94a3b8"><?= $ago ?></div>
            </td>
            <td style="font-size:.82rem;font-family:monospace"><?= htmlspecialchars($t['account_number'] ?? '—') ?></td>
            <td style="font-size:.83rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($t['customer_name'] ?? '—') ?></td>
            <td><span class="badge badge-<?= $typeColor ?>"><?= htmlspecialchars($t['type'] ?? '—') ?></span></td>
            <td>
              <span style="font-weight:700;font-size:.84rem;color:<?= $isCredit ? '#059669' : '#dc2626' ?>">
                <?= $isCredit ? '+' : '-' ?> <?= number_format((float)($t['amount'] ?? 0), 2) ?>
              </span>
            </td>
            <td style="font-size:.8rem;color:#475569"><?= htmlspecialchars($t['channel'] ?? 'Counter') ?></td>
            <td><span class="badge badge-<?= $statusColor ?>"><?= htmlspecialchars($t['status'] ?? '—') ?></span></td>
            <td>
              <div style="display:flex;gap:4px">
                <button onclick="viewTxn(<?= htmlspecialchars(json_encode($t)) ?>)" style="padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:6px;background:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="View Details"><i class="fa-solid fa-eye" style="color:#007A8A"></i></button>
                <?php if (($t['status'] ?? '') === 'Pending'): ?>
                  <button onclick="approveTxn('<?= htmlspecialchars($t['reference'] ?? '') ?>',this)" style="padding:4px 8px;border:none;border-radius:6px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;cursor:pointer;font-size:.73rem;font-family:inherit" title="Approve"><i class="fa-solid fa-check"></i></button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #f1f5f9;flex-wrap:wrap;gap:8px">
    <div style="font-size:.8rem;color:#94a3b8" id="txn-info">Showing <?= $totalCount ?> transaction<?= $totalCount !== 1 ? 's' : '' ?></div>
  </div>
</div>

<!-- Transaction Detail Modal -->
<div id="txn-detail-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);z-index:1050;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:18px;width:100%;max-width:480px;box-shadow:0 24px 64px rgba(0,0,0,.28)">
    <div style="padding:18px 22px 14px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.98rem;font-weight:800;color:#1B3A5C">Transaction Details</div>
      <button onclick="document.getElementById('txn-detail-modal').style.display='none'" style="width:30px;height:30px;border:none;background:#f1f5f9;border-radius:7px;cursor:pointer;font-size:.88rem;color:#64748b">✕</button>
    </div>
    <div style="padding:18px 22px" id="txn-detail-body"></div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _allTxns = <?= json_encode($txRows) ?>;

  function filterTxns() {
    var search = document.getElementById('txn-search').value.toLowerCase();
    var type = document.getElementById('txn-type-filter').value;
    var status = document.getElementById('txn-status-filter').value;
    var dfrom = document.getElementById('txn-date-from').value;
    var dto = document.getElementById('txn-date-to').value;
    var rows = document.querySelectorAll('#txn-tbody tr');
    var shown = 0;
    rows.forEach(function(tr) {
      var ref = tr.dataset.ref || '';
      var acc = tr.dataset.account || '';
      var cust = tr.dataset.customer || '';
      var t = tr.dataset.type || '';
      var s = tr.dataset.status || '';
      var d = tr.dataset.date || '';
      var matchSearch = !search || ref.includes(search) || acc.includes(search) || cust.includes(search);
      var matchType = !type || t === type;
      var matchStatus = !status || s === status;
      var matchFrom = !dfrom || d >= dfrom;
      var matchTo = !dto || d <= dto;
      var show = matchSearch && matchType && matchStatus && matchFrom && matchTo;
      tr.style.display = show ? '' : 'none';
      if (show) shown++;
    });
    document.getElementById('txn-info').textContent = 'Showing ' + shown + ' transaction' + (shown !== 1 ? 's' : '');
  }

  function viewTxn(t) {
    var typeColor = ['Deposit', 'Transfer In'].includes(t.type) ? '#059669' : '#dc2626';
    var isCredit = ['Deposit', 'Transfer In'].includes(t.type);
    document.getElementById('txn-detail-body').innerHTML =
      '<div style="display:flex;flex-direction:column;gap:12px">' +
      '<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:12px;padding:16px;text-align:center">' +
      '<div style="font-size:.68rem;color:rgba(255,255,255,.6);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">' + (t.type || 'Transaction') + '</div>' +
      '<div style="font-size:2rem;font-weight:900;color:' + (isCredit ? '#6ee7b7' : '#fca5a5') + '">' + (isCredit ? '+' : '-') + ' ETB ' + Number(t.amount || 0).toLocaleString('en-ET', {
        minimumFractionDigits: 2
      }) + '</div>' +
      '<div style="font-size:.76rem;color:rgba(255,255,255,.55);margin-top:4px">' + (t.description || '') + '</div>' +
      '</div>' +
      '<div style="display:flex;flex-direction:column;gap:9px">' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#94a3b8">Reference</span><span style="font-size:.82rem;font-weight:700;font-family:monospace">' + (t.reference || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#94a3b8">Account</span><span style="font-size:.82rem;font-weight:600;font-family:monospace">' + (t.account_number || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#94a3b8">Customer</span><span style="font-size:.82rem;font-weight:600">' + (t.customer_name || '—') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#94a3b8">Date & Time</span><span style="font-size:.82rem">' + (t.created_at || '—').replace('T', ' ') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9"><span style="font-size:.79rem;color:#94a3b8">Channel</span><span style="font-size:.82rem">' + (t.channel || 'Counter') + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;padding:8px 0"><span style="font-size:.79rem;color:#94a3b8">Status</span><span class="badge badge-' + (t.status === 'Completed' ? 'success' : t.status === 'Pending' ? 'warning' : 'danger') + '">' + (t.status || '—') + '</span></div>' +
      '</div></div>';
    document.getElementById('txn-detail-modal').style.display = 'flex';
  }

  function approveTxn(ref, btn) {
    if (!confirm('Approve transaction ' + ref + '?')) return;
    btn.disabled = true;
    ABAY.api('/transactions/approve', {
      method: 'PUT',
      body: JSON.stringify({
        reference: ref
      })
    }).then(function(d) {
      var tr = btn.closest('tr');
      var statusBadge = tr.querySelector('.badge:last-of-type');
      if (statusBadge) {
        statusBadge.textContent = 'Completed';
        statusBadge.className = 'badge badge-success';
      }
      btn.remove();
      ABAY.toast('Transaction approved!', 'ok');
    }).catch(function() {
      btn.disabled = false;
      ABAY.toast('Demo: Transaction approved (Database offline).', 'info');
      var tr = btn.closest('tr');
      var statusBadge = tr.querySelector('td:nth-child(8) .badge');
      if (statusBadge) {
        statusBadge.textContent = 'Completed';
        statusBadge.className = 'badge badge-success';
      }
      btn.remove();
    });
  }

  function exportTxnCSV() {
    var rows = [
      ['Reference', 'Date', 'Account', 'Customer', 'Type', 'Amount', 'Status', 'Channel']
    ];
    document.querySelectorAll('#txn-tbody tr').forEach(function(tr) {
      if (tr.style.display === 'none') return;
      var cells = tr.querySelectorAll('td');
      if (cells.length > 7) rows.push([
        cells[0].textContent.trim(), cells[1].textContent.replace(/\s+/g, ' ').trim(),
        cells[2].textContent.trim(), cells[3].textContent.trim(),
        cells[4].textContent.trim(), cells[5].textContent.trim(),
        cells[7].textContent.trim(), cells[6].textContent.trim()
      ]);
    });
    var csv = rows.map(function(r) {
      return r.map(function(v) {
        return '"' + v + '"';
      }).join(',');
    }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'transactions.csv';
    a.click();
  }

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('txn-detail-modal').style.display = 'none';
  });
</script>