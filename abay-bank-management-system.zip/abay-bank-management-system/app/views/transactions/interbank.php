﻿<?php
// Staff inter-bank transfer page
$dbMode = !empty($dbOnline) ? '' : '<span style="background:rgba(234,179,8,.1);color:#b45309;padding:2px 8px;border-radius:10px;font-size:.72rem;font-weight:600;margin-left:8px"><i class="fa-solid fa-exclamation-triangle"></i> Demo Mode</span>';
?>
<div class="page-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
  <div>
    <h1 style="font-size:1.5rem;font-weight:800;color:#1B3A5C;margin-bottom:4px">
      <i class="fa-solid fa-globe" style="color:#007A8A;margin-right:8px"></i>Inter-Bank Transfer
      <?= $dbMode ?>
    </h1>
    <p style="color:#64748b;font-size:.88rem">Transfer funds to any Ethiopian bank via EthSwitch network</p>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 380px;gap:24px;align-items:start">

  <!-- Transfer Form -->
  <div style="background:#fff;border-radius:14px;box-shadow:0 2px 16px rgba(0,0,0,.07);overflow:hidden">
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;padding:18px 24px;display:flex;align-items:center;gap:12px">
      <i class="fa-solid fa-right-left fa-lg" style="color:#C8A84B"></i>
      <div>
        <div style="font-weight:700;font-size:1rem">New Inter-Bank Transfer</div>
        <div style="font-size:.72rem;opacity:.75">EthSwitch · NBE Regulated · Fees Apply</div>
      </div>
    </div>
    <form id="ibt-form" style="padding:24px">
      <?= \Web\Core\View::csrfField() ?>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
        <!-- Source Account -->
        <div style="grid-column:1/-1">
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Source Account <span style="color:#ef4444">*</span></label>
          <select name="source_account_id" id="src-account" required
                  style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem"
                  onchange="updateBalance(this)">
            <option value="">— Select account —</option>
            <?php foreach ($accounts as $a): ?>
            <option value="<?= $a['id'] ?>" data-balance="<?= $a['balance'] ?>" data-type="<?= $a['account_type'] ?>">
              <?= \Web\Core\View::e($a['account_number']) ?> · <?= \Web\Core\View::e($a['customer_name']) ?> · <?= $a['account_type'] ?> · ETB <?= number_format($a['balance'],2) ?>
            </option>
            <?php endforeach; ?>
          </select>
          <div id="src-balance-bar" style="margin-top:6px;padding:8px 12px;background:#f8fafc;border-radius:6px;font-size:.8rem;color:#64748b;display:none">
            Available Balance: <strong id="src-balance-val" style="color:#1B3A5C">—</strong>
          </div>
        </div>

        <!-- Destination Bank -->
        <div>
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Destination Bank <span style="color:#ef4444">*</span></label>
          <div style="position:relative">
            <i class="fa-solid fa-building-columns" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.85rem"></i>
            <select name="dest_bank_code" id="dest-bank" required
                    style="width:100%;padding:10px 12px 10px 36px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem">
              <option value="">— Select bank —</option>
              <?php foreach ($banks as $code => $name): ?>
              <option value="<?= $code ?>"><?= \Web\Core\View::e($name) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Destination Account Number -->
        <div>
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Destination Account No. <span style="color:#ef4444">*</span></label>
          <div style="position:relative">
            <i class="fa-solid fa-hashtag" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.85rem"></i>
            <input type="text" name="dest_account_number" id="dest-acct" required
                   placeholder="e.g. 1000012345678"
                   style="width:100%;padding:10px 12px 10px 36px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem">
          </div>
        </div>

        <!-- Beneficiary Name -->
        <div style="grid-column:1/-1">
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Beneficiary Name</label>
          <div style="position:relative">
            <i class="fa-solid fa-user" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.85rem"></i>
            <input type="text" name="dest_account_name" placeholder="Account holder name"
                   style="width:100%;padding:10px 12px 10px 36px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem">
          </div>
        </div>

        <!-- Amount -->
        <div>
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Amount (ETB) <span style="color:#ef4444">*</span></label>
          <div style="position:relative">
            <i class="fa-solid fa-money-bill" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.85rem"></i>
            <input type="number" name="amount" id="transfer-amount" required min="1" step="0.01"
                   placeholder="e.g. 5000"
                   style="width:100%;padding:10px 12px 10px 36px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem"
                   oninput="calcFee()">
          </div>
        </div>

        <!-- Purpose -->
        <div>
          <label style="font-size:.82rem;font-weight:600;color:#64748b;display:block;margin-bottom:6px">Purpose / Narration</label>
          <div style="position:relative">
            <i class="fa-solid fa-pen" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.85rem"></i>
            <input type="text" name="purpose" placeholder="e.g. Business payment, Rent"
                   style="width:100%;padding:10px 12px 10px 36px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.88rem">
          </div>
        </div>
      </div>

      <!-- Fee preview -->
      <div id="fee-bar" style="background:linear-gradient(135deg,rgba(0,122,138,.06),rgba(27,58,92,.04));border:1.5px solid rgba(0,122,138,.15);border-radius:10px;padding:14px 16px;margin-bottom:16px;display:none">
        <div style="font-size:.78rem;font-weight:700;color:#007A8A;margin-bottom:10px"><i class="fa-solid fa-receipt"></i> Transfer Summary</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:.82rem">
          <div style="color:#64748b">Transfer Amount:</div><div style="font-weight:600;text-align:right" id="fee-amount">—</div>
          <div style="color:#64748b">Service Fee (0.5%):</div><div style="font-weight:600;text-align:right;color:#f59e0b" id="fee-val">—</div>
          <div style="color:#64748b;font-weight:700;border-top:1px solid #e2e8f0;padding-top:6px">Total Deducted:</div>
          <div style="font-weight:800;text-align:right;color:#1B3A5C;border-top:1px solid #e2e8f0;padding-top:6px" id="fee-total">—</div>
        </div>
      </div>

      <!-- Warning -->
      <div style="background:rgba(239,68,68,.05);border:1px solid rgba(239,68,68,.15);border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:.78rem;color:#64748b">
        <i class="fa-solid fa-triangle-exclamation" style="color:#f59e0b;margin-right:4px"></i>
        Please verify destination account details carefully. Inter-bank transfers are <strong>irreversible</strong> once processed via EthSwitch.
      </div>

      <button type="button" id="ibt-submit-btn" onclick="submitIBT()"
              style="width:100%;background:linear-gradient(135deg,#007A8A,#1B3A5C);color:#fff;border:none;border-radius:10px;padding:13px;font-size:.95rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px">
        <i class="fa-solid fa-paper-plane"></i> Send Transfer
      </button>
    </form>
  </div>

  <!-- Recent Transfers sidebar -->
  <div>
    <div style="background:#fff;border-radius:14px;box-shadow:0 2px 16px rgba(0,0,0,.07);overflow:hidden">
      <div style="padding:16px 20px;border-bottom:2px solid #f1f5f9;font-weight:700;font-size:.92rem;color:#1B3A5C">
        <i class="fa-solid fa-clock-rotate-left" style="color:#007A8A;margin-right:6px"></i>Recent Transfers
      </div>
      <div style="padding:16px;max-height:480px;overflow-y:auto">
        <?php if (empty($recent)): ?>
        <div style="text-align:center;color:#94a3b8;padding:30px 0;font-size:.85rem">
          <i class="fa-solid fa-inbox fa-2x" style="margin-bottom:8px;display:block;opacity:.4"></i>No transfers yet
        </div>
        <?php else: ?>
        <?php foreach ($recent as $t): ?>
        <div style="border:1px solid #f1f5f9;border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
            <div>
              <div style="font-size:.82rem;font-weight:700;color:#1e293b"><?= \Web\Core\View::e($t['dest_bank_name']) ?></div>
              <div style="font-size:.72rem;color:#64748b;font-family:monospace"><?= \Web\Core\View::e($t['dest_account_number']) ?></div>
            </div>
            <span style="background:<?= $t['status']==='Completed'?'rgba(16,185,129,.1)':'rgba(239,68,68,.1)' ?>;color:<?= $t['status']==='Completed'?'#047857':'#dc2626' ?>;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700">
              <?= $t['status'] ?>
            </span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:.78rem">
            <span style="color:#64748b"><?= date('d M Y', strtotime($t['created_at'])) ?></span>
            <strong style="color:#1B3A5C">ETB <?= number_format($t['amount'],2) ?></strong>
          </div>
          <div style="font-size:.7rem;color:#94a3b8;margin-top:4px;font-family:monospace"><?= \Web\Core\View::e($t['reference']) ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Success Modal -->
<div id="ibt-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:none;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:16px;padding:32px;max-width:400px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div id="modal-icon" style="font-size:2.5rem;margin-bottom:12px"></div>
    <div id="modal-title" style="font-size:1.2rem;font-weight:800;margin-bottom:8px"></div>
    <div id="modal-body" style="font-size:.85rem;color:#64748b;margin-bottom:20px"></div>
    <div id="modal-receipt" style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:20px;text-align:left;font-size:.82rem;display:none"></div>
    <button onclick="closeModal()" style="background:linear-gradient(135deg,#007A8A,#1B3A5C);color:#fff;border:none;border-radius:8px;padding:10px 28px;font-weight:700;cursor:pointer;font-size:.9rem">Close</button>
  </div>
</div>

<script>
function updateBalance(sel) {
  const opt = sel.options[sel.selectedIndex];
  const bal = opt.dataset.balance;
  const bar = document.getElementById('src-balance-bar');
  if (bal !== undefined) {
    document.getElementById('src-balance-val').textContent = 'ETB ' + Number(bal).toLocaleString('en-ET',{minimumFractionDigits:2});
    bar.style.display = 'block';
  } else { bar.style.display = 'none'; }
  calcFee();
}

function calcFee() {
  const amount = parseFloat(document.getElementById('transfer-amount').value);
  const bar = document.getElementById('fee-bar');
  if (!amount || amount < 1) { bar.style.display = 'none'; return; }
  const fee = Math.min(500, Math.max(10, Math.round(amount * 0.005 * 100)/100));
  const total = amount + fee;
  document.getElementById('fee-amount').textContent = 'ETB ' + amount.toLocaleString('en-ET',{minimumFractionDigits:2});
  document.getElementById('fee-val').textContent    = 'ETB ' + fee.toLocaleString('en-ET',{minimumFractionDigits:2});
  document.getElementById('fee-total').textContent  = 'ETB ' + total.toLocaleString('en-ET',{minimumFractionDigits:2});
  bar.style.display = 'block';
}

async function submitIBT() {
  const form = document.getElementById('ibt-form');
  const data = Object.fromEntries(new FormData(form));
  if (!data.source_account_id || !data.dest_bank_code || !data.dest_account_number || !data.amount) {
    showModal('err','Missing Fields','Please fill all required fields.');
    return;
  }
  const btn = document.getElementById('ibt-submit-btn');
  btn.innerHTML = '<span style="width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite;display:inline-block"></span> Processing...';
  btn.disabled = true;

  try {
    const body = new URLSearchParams(data);
    const r    = await fetch('<?= APP_URL ?>/api/interbank/transfer', {
      method: 'POST', body,
      headers: {'X-Requested-With':'XMLHttpRequest'}
    });
    const res = await r.json();
    btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Transfer';
    btn.disabled  = false;

    if (res.success) {
      const receipt = `
        <div style="display:grid;gap:6px">
          <div style="display:flex;justify-content:space-between"><span style="color:#64748b">Reference:</span><strong style="font-family:monospace;font-size:.78rem;color:#007A8A">${res.reference}</strong></div>
          <div style="display:flex;justify-content:space-between"><span style="color:#64748b">EthSwitch Ref:</span><strong style="font-family:monospace;font-size:.78rem">${res.ethswitch}</strong></div>
          <div style="display:flex;justify-content:space-between"><span style="color:#64748b">Destination Bank:</span><strong>${res.dest_bank}</strong></div>
          <div style="display:flex;justify-content:space-between"><span style="color:#64748b">Amount:</span><strong>ETB ${Number(res.amount).toLocaleString('en-ET',{minimumFractionDigits:2})}</strong></div>
          <div style="display:flex;justify-content:space-between"><span style="color:#64748b">Fee:</span><strong>ETB ${Number(res.fee).toLocaleString('en-ET',{minimumFractionDigits:2})}</strong></div>
          <div style="display:flex;justify-content:space-between;border-top:1px solid #e2e8f0;padding-top:6px"><span style="color:#64748b">New Balance:</span><strong style="color:#1B3A5C">ETB ${Number(res.new_balance).toLocaleString('en-ET',{minimumFractionDigits:2})}</strong></div>
        </div>`;
      showModal('ok','Transfer Successful', res.message, receipt);
      form.reset();
      document.getElementById('fee-bar').style.display='none';
      document.getElementById('src-balance-bar').style.display='none';
    } else {
      showModal('err','Transfer Failed', res.message || 'An error occurred.');
    }
  } catch(e) {
    btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Transfer';
    btn.disabled  = false;
    showModal('err','Error', 'Connection error. Please try again.');
  }
}

function showModal(type, title, body, receipt='') {
  document.getElementById('modal-icon').innerHTML = type==='ok'
    ? '<i class="fa-solid fa-circle-check" style="color:#10b981"></i>'
    : '<i class="fa-solid fa-circle-xmark" style="color:#ef4444"></i>';
  document.getElementById('modal-title').textContent  = title;
  document.getElementById('modal-title').style.color  = type==='ok'?'#047857':'#dc2626';
  document.getElementById('modal-body').textContent   = body;
  const rec = document.getElementById('modal-receipt');
  if (receipt) { rec.innerHTML = receipt; rec.style.display='block'; } else { rec.style.display='none'; }
  document.getElementById('ibt-modal').style.display='flex';
}
function closeModal() { document.getElementById('ibt-modal').style.display='none'; }
</script>
<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
