<?php $pageTitle = 'Fund Transfer — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-right-left" style="color:#007A8A;margin-right:8px"></i>Fund Transfer</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span>
      <a href="<?= APP_URL ?>/transactions">Transactions</a><span class="sep">/</span><span>Transfer</span>
    </div>
  </div>
</div>

<!-- Transfer Type Tabs -->
<div style="display:flex;gap:10px;margin-bottom:22px;flex-wrap:wrap">
  <?php foreach ([['internal', 'fa-building-columns', 'Internal Transfer', 'Between Abay Bank accounts'], ['interbranch', 'fa-building', 'Inter-Branch', 'Different branch accounts'], ['interbank', 'fa-globe', 'Inter-Bank', 'EthSwitch & SWIFT'], ['scheduled', 'fa-clock', 'Scheduled', 'Future / recurring']] as [$type, $ic, $lbl, $sub]): ?>
    <button onclick="setTab('<?= $type ?>')" id="tab-<?= $type ?>" class="btn <?= $type === 'internal' ? 'btn-primary' : 'btn-ghost' ?>" style="display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 18px;min-width:140px;text-align:left">
      <div style="display:flex;align-items:center;gap:7px;font-weight:700"><i class="fa-solid <?= $ic ?>"></i><?= $lbl ?></div>
      <div style="font-size:.7rem;opacity:.75;font-weight:400"><?= $sub ?></div>
    </button>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px">
  <div class="card">
    <div class="card-header" id="txf-header">
      <h3><i class="fa-solid fa-right-left" style="color:#007A8A;margin-right:7px"></i>Transfer Details</h3>
    </div>
    <div class="card-body">
      <div id="txf-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:16px;margin-bottom:18px">
        <div style="display:flex;align-items:center;gap:10px"><i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.3rem"></i>
          <div>
            <div style="font-weight:700;color:#065f46">Transfer Successful!</div>
            <div style="font-size:.84rem;color:#047857" id="txf-ok-msg"></div>
          </div>
        </div>
        <div style="margin-top:10px"><button onclick="resetTxfForm()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-plus"></i> New Transfer</button></div>
      </div>
      <div id="txf-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin-bottom:16px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px">
        <i class="fa-solid fa-circle-xmark"></i><span id="txf-err-msg"></span>
      </div>
      <form id="transfer-form" novalidate>
        <!-- From Account -->
        <div style="background:#f8fafc;border-radius:10px;padding:15px;margin-bottom:15px">
          <div style="font-size:.71rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-arrow-right" style="color:#007A8A;margin-right:5px"></i>From Account</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Source Account <span style="color:#ef4444">*</span></label>
              <input type="text" id="from-account" placeholder="Account number..." oninput="lookupFrom(this.value)" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Account Holder</label>
              <input type="text" id="from-holder" readonly placeholder="Auto-filled" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <div id="from-balance-box" style="display:none;margin-top:10px;background:#e0f5f7;border-radius:8px;padding:10px 13px;font-size:.84rem">
            Available Balance: <strong style="color:#007A8A" id="from-bal-label">—</strong>
          </div>
        </div>
        <!-- To Account -->
        <div style="background:#f8fafc;border-radius:10px;padding:15px;margin-bottom:15px">
          <div style="font-size:.71rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-arrow-left" style="color:#007A8A;margin-right:5px"></i>To Account</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Destination Account <span style="color:#ef4444">*</span></label>
              <input type="text" id="to-account" placeholder="Account number..." oninput="lookupTo(this.value)" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Beneficiary Name</label>
              <input type="text" id="to-holder" readonly placeholder="Auto-filled" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <!-- Interbank extra fields -->
          <div id="interbank-fields" style="display:none;margin-top:13px">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px;margin-bottom:13px">
              <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Destination Bank</label>
                <select id="dest-bank" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                  <option value="">Select bank...</option>
                  <?php foreach (['Commercial Bank of Ethiopia (CBE)', 'Dashen Bank', 'Awash Bank', 'Bank of Abyssinia', 'Wegagen Bank', 'NIB International Bank', 'Oromia Bank', 'Zemen Bank', 'Berhan Bank', 'Enat Bank', 'United Bank (Hibret)'] as $bk): ?>
                    <option><?= $bk ?></option><?php endforeach; ?>
                </select>
              </div>
              <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Account Holder Name <span style="color:#ef4444">*</span></label>
                <input type="text" id="dest-holder-name" placeholder="Beneficiary full name" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;outline:none">
              </div>
            </div>
          </div>
          <!-- Scheduled extra fields -->
          <div id="scheduled-fields" style="display:none;margin-top:13px">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px">
              <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Transfer Date <span style="color:#ef4444">*</span></label>
                <input type="date" id="sched-date" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff">
              </div>
              <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Frequency</label>
                <select id="sched-freq" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#fff;cursor:pointer">
                  <option>One-time</option>
                  <option>Daily</option>
                  <option>Weekly</option>
                  <option>Monthly</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <!-- Amount -->
        <div style="background:#f8fafc;border-radius:10px;padding:15px;margin-bottom:15px">
          <div style="font-size:.71rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-coins" style="color:#007A8A;margin-right:5px"></i>Transfer Amount</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px;margin-bottom:13px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (ETB) <span style="color:#ef4444">*</span></label>
              <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden" id="txf-amt-wrap">
                <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                <input type="number" id="transfer-amount" min="1" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.87rem;outline:none;background:#fff" oninput="updateTxfPreview()" onfocus="document.getElementById('txf-amt-wrap').style.borderColor='#007A8A'" onblur="document.getElementById('txf-amt-wrap').style.borderColor='#e2e8f0'">
              </div>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Transfer Fee</label>
              <input type="text" id="txf-fee-display" readonly style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;background:#f8fafc;color:#475569" value="ETB 0.00 (Internal)">
            </div>
          </div>
          <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:4px">Narration</label>
            <textarea id="txf-narration" rows="2" placeholder="Transfer description..." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.87rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea>
          </div>
        </div>
        <div style="display:flex;gap:12px;justify-content:flex-end">
          <button type="button" class="btn btn-ghost" onclick="resetTxfForm()"><i class="fa-solid fa-rotate"></i> Reset</button>
          <button type="submit" id="txf-btn" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border:none;color:#fff;padding:12px 28px;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-right-left"></i> Process Transfer</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Right panel -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:6px"></i>Transfer Summary</h4>
      </div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:9px">
        <?php foreach ([['From', 'tr-from', '—'], ['To', 'tr-to', '—'], ['Amount', 'tr-amount', 'ETB 0.00'], ['Fee', 'tr-fee', 'ETB 0.00'], ['Total Debit', 'tr-total', 'ETB 0.00']] as [$l, $id, $d]): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.79rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
            <span style="font-size:.82rem;font-weight:600;color:<?= $id === 'tr-total' ? '#ef4444' : '#1e293b' ?>" id="<?= $id ?>"><?= $d ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-users" style="color:#1B3A5C;margin-right:6px"></i>Recent Beneficiaries</h4>
      </div>
      <div class="card-body" style="padding:0">
        <?php foreach ([['Tigist Haile', '2000-10-100001', 'TH', '#1B3A5C'], ['Solomon Girma', '3000-10-100002', 'SG', '#007A8A'], ['Meron Alemu', '4000-10-100003', 'MA', '#C8A84B']] as [$bn, $bacc, $ini, $clr]): ?>
          <button onclick="setTo('<?= $bacc ?>','<?= $bn ?>')" style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:none;border:none;border-bottom:1px solid #f1f5f9;cursor:pointer;width:100%;text-align:left;transition:background .2s;font-family:inherit" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
            <div style="width:34px;height:34px;border-radius:50%;background:<?= $clr ?>;color:#fff;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;flex-shrink:0"><?= $ini ?></div>
            <div>
              <div style="font-size:.84rem;font-weight:600;color:#1e293b"><?= $bn ?></div>
              <div style="font-size:.73rem;color:#94a3b8"><?= $bacc ?></div>
            </div>
            <i class="fa-solid fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.8rem"></i>
          </button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _fromAcc = null,
    _curTab = 'internal';
  var tabFees = {
    internal: 0,
    interbranch: 10,
    interbank: 25,
    scheduled: 0
  };

  function setTab(tab) {
    _curTab = tab;
    ['internal', 'interbranch', 'interbank', 'scheduled'].forEach(function(t) {
      var b = document.getElementById('tab-' + t);
      b.className = 'btn ' + (t === tab ? 'btn-primary' : 'btn-ghost');
      b.style.minWidth = '140px';
    });
    document.getElementById('interbank-fields').style.display = tab === 'interbank' ? 'block' : 'none';
    document.getElementById('scheduled-fields').style.display = tab === 'scheduled' ? 'block' : 'none';
    var feeMap = {
      internal: 'ETB 0.00 (Internal)',
      interbranch: 'ETB 10.00 (Inter-Branch)',
      interbank: 'ETB 25.00 (EthSwitch)',
      scheduled: 'ETB 0.00'
    };
    document.getElementById('txf-fee-display').value = feeMap[tab] || 'ETB 0.00';
    updateTxfPreview();
  }

  function lookupFrom(val) {
    if (val.length < 4) return;
    clearTimeout(window._fromTimer);
    window._fromTimer = setTimeout(function() {
      ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
        var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
        if (!acc) acc = {
          account_number: val,
          account_type: 'Savings',
          balance: 84500,
          customer_name: 'Demo Customer'
        };
        _fromAcc = acc;
        document.getElementById('from-holder').value = acc.customer_name || '—';
        document.getElementById('from-bal-label').textContent = ABAY.fmtETB(acc.balance || 0);
        document.getElementById('from-balance-box').style.display = 'block';
        document.getElementById('tr-from').textContent = val;
        updateTxfPreview();
      }).catch(function() {
        _fromAcc = {
          account_number: val,
          balance: 84500,
          customer_name: 'Demo Customer'
        };
        document.getElementById('from-holder').value = 'Demo Customer';
        document.getElementById('from-bal-label').textContent = ABAY.fmtETB(84500);
        document.getElementById('from-balance-box').style.display = 'block';
        document.getElementById('tr-from').textContent = val;
      });
    }, 500);
  }

  function lookupTo(val) {
    if (val.length < 4) return;
    clearTimeout(window._toTimer);
    window._toTimer = setTimeout(function() {
      ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
        var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
        if (acc) {
          document.getElementById('to-holder').value = acc.customer_name || '—';
          document.getElementById('tr-to').textContent = val;
        } else {
          document.getElementById('to-holder').value = '';
        }
      }).catch(function() {});
    }, 500);
  }

  function setTo(acc, name) {
    document.getElementById('to-account').value = acc;
    document.getElementById('to-holder').value = name;
    document.getElementById('tr-to').textContent = acc;
  }

  function updateTxfPreview() {
    var amt = parseFloat(document.getElementById('transfer-amount').value) || 0;
    var fee = tabFees[_curTab] || 0;
    document.getElementById('tr-amount').textContent = ABAY.fmtETB(amt);
    document.getElementById('tr-fee').textContent = ABAY.fmtETB(fee);
    document.getElementById('tr-total').textContent = ABAY.fmtETB(amt + fee);
  }

  function resetTxfForm() {
    _fromAcc = null;
    document.getElementById('transfer-form').reset();
    document.getElementById('transfer-form').style.display = '';
    document.getElementById('txf-success').style.display = 'none';
    document.getElementById('txf-error').style.display = 'none';
    document.getElementById('from-balance-box').style.display = 'none';
    document.getElementById('from-holder').value = '';
    document.getElementById('to-holder').value = '';
    ['tr-from', 'tr-to'].forEach(function(id) {
      document.getElementById(id).textContent = '—';
    });
    ['tr-amount', 'tr-fee', 'tr-total'].forEach(function(id) {
      document.getElementById(id).textContent = 'ETB 0.00';
    });
    setTab('internal');
  }

  document.getElementById('transfer-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var from = document.getElementById('from-account').value.trim();
    var to = document.getElementById('to-account').value.trim();
    var amt = parseFloat(document.getElementById('transfer-amount').value) || 0;
    var desc = document.getElementById('txf-narration').value || 'Fund Transfer';
    document.getElementById('txf-error').style.display = 'none';
    if (!from) {
      document.getElementById('txf-err-msg').textContent = 'Source account is required.';
      document.getElementById('txf-error').style.display = 'flex';
      return;
    }
    if (!to) {
      document.getElementById('txf-err-msg').textContent = 'Destination account is required.';
      document.getElementById('txf-error').style.display = 'flex';
      return;
    }
    if (from === to) {
      document.getElementById('txf-err-msg').textContent = 'Source and destination accounts must differ.';
      document.getElementById('txf-error').style.display = 'flex';
      return;
    }
    if (amt < 1) {
      document.getElementById('txf-err-msg').textContent = 'Please enter a valid amount.';
      document.getElementById('txf-error').style.display = 'flex';
      return;
    }
    ABAY.setBtn('txf-btn', true);
    var payload = {
      from_account_number: from,
      to_account_number: to,
      amount: amt,
      description: desc,
      type: _curTab
    };
    if (_curTab === 'interbank') {
      payload.dest_bank = document.getElementById('dest-bank').value;
      payload.dest_holder = document.getElementById('dest-holder-name').value;
    }
    ABAY.api('/transactions/transfer', {
      method: 'POST',
      body: JSON.stringify(payload)
    }).then(function(d) {
      ABAY.setBtn('txf-btn', false, '<i class="fa-solid fa-right-left"></i> Process Transfer');
      if (d && d.success) {
        document.getElementById('txf-ok-msg').textContent = ABAY.fmtETB(amt) + ' transferred from ' + from + ' to ' + to + '. Ref: ' + (d.data && d.data.reference ? d.data.reference : 'N/A');
        document.getElementById('txf-success').style.display = 'block';
        document.getElementById('transfer-form').style.display = 'none';
        ABAY.toast('Transfer of ' + ABAY.fmtETB(amt) + ' completed!', 'ok');
      } else {
        document.getElementById('txf-err-msg').textContent = (d && d.message) || 'Transfer failed.';
        document.getElementById('txf-error').style.display = 'flex';
      }
    }).catch(function() {
      ABAY.setBtn('txf-btn', false, '<i class="fa-solid fa-right-left"></i> Process Transfer');
      document.getElementById('txf-ok-msg').textContent = 'Demo: ' + ABAY.fmtETB(amt) + ' transferred from ' + from + ' to ' + to + ' (Database offline)';
      document.getElementById('txf-success').style.display = 'block';
      document.getElementById('transfer-form').style.display = 'none';
      ABAY.toast('Demo transfer recorded.', 'info');
    });
  });
</script>