<?php $pageTitle = 'Cash Withdrawal — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-arrow-up" style="color:#ef4444;margin-right:8px"></i>Cash Withdrawal</h1>
    <div class="breadcrumb">
      <a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span>
      <a href="<?= APP_URL ?>/transactions">Transactions</a><span class="sep">/</span><span>Withdrawal</span>
    </div>
  </div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px">
  <div class="card">
    <div class="card-header">
      <h3><i class="fa-solid fa-arrow-up" style="color:#ef4444;margin-right:7px"></i>Withdrawal Form</h3>
    </div>
    <div class="card-body">
      <div id="wd-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:16px;margin-bottom:18px">
        <div style="display:flex;align-items:center;gap:10px"><i class="fa-solid fa-circle-check" style="color:#059669;font-size:1.3rem"></i>
          <div>
            <div style="font-weight:700;color:#065f46">Withdrawal Successful!</div>
            <div style="font-size:.84rem;color:#047857" id="wd-success-msg"></div>
          </div>
        </div>
        <div style="margin-top:10px"><button onclick="resetWdForm()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-plus"></i> New Withdrawal</button></div>
      </div>
      <div id="wd-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin-bottom:16px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px">
        <i class="fa-solid fa-circle-xmark"></i><span id="wd-error-msg"></span>
      </div>
      <form id="wd-form" novalidate>
        <div style="background:#f8fafc;border-radius:10px;padding:16px;margin-bottom:16px">
          <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-building-columns" style="color:#007A8A;margin-right:5px"></i>Account Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Account Number <span style="color:#ef4444">*</span></label>
              <input type="text" id="wd-account" class="form-control" placeholder="Enter account number..." oninput="wdLookup(this.value)" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'">
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Account Holder</label>
              <input type="text" id="wd-holder" readonly placeholder="Auto-filled" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <div id="wd-acc-info" style="display:none;margin-top:12px;background:linear-gradient(135deg,#fff7ed,#fed7aa);border-radius:10px;padding:12px 14px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
              <div>
                <div style="font-size:.64rem;color:#92400e;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Account Type</div>
                <div style="font-weight:700;color:#c2410c" id="wd-acc-type">—</div>
              </div>
              <div>
                <div style="font-size:.64rem;color:#92400e;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Available Balance</div>
                <div style="font-weight:800;font-size:1.15rem;color:#c2410c" id="wd-acc-bal">—</div>
              </div>
              <div>
                <div style="font-size:.64rem;color:#92400e;font-weight:700;text-transform:uppercase;letter-spacing:.5px">Status</div><span id="wd-acc-status" style="font-weight:700;color:#c2410c">Active</span>
              </div>
            </div>
          </div>
        </div>
        <div style="background:#f8fafc;border-radius:10px;padding:16px;margin-bottom:16px">
          <div style="font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px"><i class="fa-solid fa-coins" style="color:#007A8A;margin-right:5px"></i>Withdrawal Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Withdrawal Type</label>
              <select id="wd-type" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#fff;cursor:pointer">
                <option>Cash</option>
                <option>Cheque</option>
              </select>
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Amount (ETB) <span style="color:#ef4444">*</span></label>
              <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden" id="wd-amt-wrap">
                <span style="padding:0 12px;background:#f1f5f9;color:#64748b;font-size:.84rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                <input type="number" id="wd-amount" min="100" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 13px;font-size:.88rem;outline:none;background:#fff" oninput="updateWdPreview()" onfocus="document.getElementById('wd-amt-wrap').style.borderColor='#ef4444'" onblur="document.getElementById('wd-amt-wrap').style.borderColor='#e2e8f0'">
              </div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">ID Presented</label>
              <input type="text" id="wd-id" placeholder="National ID / Passport No." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;outline:none">
            </div>
            <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Teller ID</label>
              <input type="text" readonly value="<?= \Web\Core\View::e($user['id'] ?? 'TELL-001') ?>" style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;background:#f8fafc;color:#475569">
            </div>
          </div>
          <div><label style="display:block;font-size:.79rem;font-weight:600;color:#374151;margin-bottom:5px">Narration</label>
            <textarea id="wd-narration" rows="2" placeholder="Reason for withdrawal..." style="border:1.5px solid #e2e8f0;border-radius:9px;padding:10px 13px;font-size:.88rem;width:100%;resize:none;outline:none;font-family:inherit"></textarea>
          </div>
        </div>
        <div id="large-wd-warn" style="display:none;background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:14px;margin-bottom:16px">
          <div style="display:flex;align-items:center;gap:9px"><i class="fa-solid fa-triangle-exclamation" style="color:#d97706;font-size:1.1rem"></i>
            <div>
              <div style="font-weight:700;color:#92400e;font-size:.86rem">Large Withdrawal Alert</div>
              <div style="font-size:.8rem;color:#92400e">Withdrawals above ETB 100,000 require Branch Manager approval. Proceed only with authorization code.</div>
            </div>
          </div>
          <div style="margin-top:10px"><label style="font-size:.79rem;font-weight:600;color:#92400e">Manager Authorization Code</label><input type="text" id="wd-auth-code" placeholder="Enter authorization code" style="margin-top:5px;border:1.5px solid #fde68a;border-radius:8px;padding:9px 12px;font-size:.86rem;width:100%;background:#fff;outline:none"></div>
        </div>
        <div style="display:flex;gap:12px;justify-content:flex-end">
          <button type="button" class="btn btn-ghost" onclick="resetWdForm()"><i class="fa-solid fa-rotate"></i> Reset</button>
          <button type="submit" id="wd-btn" style="background:linear-gradient(135deg,#dc2626,#ef4444);border:none;color:#fff;padding:12px 28px;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-arrow-up"></i> Process Withdrawal</button>
        </div>
      </form>
    </div>
  </div>

  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:6px"></i>Summary</h4>
      </div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:9px">
        <?php foreach ([['Account', 'wd-sum-acc', '—'], ['Customer', 'wd-sum-cust', '—'], ['Available Balance', 'wd-sum-bal', '—'], ['Withdrawal Amount', 'wd-sum-amt', 'ETB 0.00'], ['After Withdrawal', 'wd-sum-new', '—']] as [$l, $id, $d]): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.79rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
            <span style="font-size:.82rem;font-weight:600;color:#1e293b" id="<?= $id ?>"><?= $d ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h4><i class="fa-solid fa-circle-info" style="color:#1B3A5C;margin-right:6px"></i>Guidelines</h4>
      </div>
      <div class="card-body">
        <ul style="padding-left:16px;list-style:disc;font-size:.8rem;color:#64748b;display:flex;flex-direction:column;gap:6px">
          <li>Minimum withdrawal: ETB 100</li>
          <li>Daily ATM limit: ETB 10,000</li>
          <li>Over-counter limit: ETB 500,000</li>
          <li>Above ETB 100,000: Manager approval required</li>
          <li>Customer must present valid ID</li>
          <li>Multiples of ETB 100 for cash</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
  var _wdAccount = null;

  function wdLookup(val) {
    if (val.length < 4) return;
    clearTimeout(window._wdTimer);
    window._wdTimer = setTimeout(function() {
      ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
        var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
        if (!acc) acc = {
          account_number: val,
          account_type: 'Savings',
          balance: 84500,
          status: 'Active',
          customer_name: 'Demo Customer'
        };
        _wdAccount = acc;
        document.getElementById('wd-holder').value = acc.customer_name || '—';
        document.getElementById('wd-acc-type').textContent = acc.account_type || 'Savings';
        document.getElementById('wd-acc-bal').textContent = ABAY.fmtETB(acc.balance || 0);
        document.getElementById('wd-acc-status').textContent = acc.status || 'Active';
        document.getElementById('wd-acc-info').style.display = 'block';
        document.getElementById('wd-sum-acc').textContent = acc.account_number;
        document.getElementById('wd-sum-cust').textContent = acc.customer_name || '—';
        document.getElementById('wd-sum-bal').textContent = ABAY.fmtETB(acc.balance || 0);
      }).catch(function() {
        _wdAccount = {
          account_number: val,
          account_type: 'Savings',
          balance: 84500,
          status: 'Active',
          customer_name: 'Demo Customer'
        };
        document.getElementById('wd-holder').value = 'Demo Customer';
        document.getElementById('wd-acc-type').textContent = 'Savings';
        document.getElementById('wd-acc-bal').textContent = ABAY.fmtETB(84500);
        document.getElementById('wd-acc-status').textContent = 'Active';
        document.getElementById('wd-acc-info').style.display = 'block';
      });
    }, 500);
  }

  function updateWdPreview() {
    var amt = parseFloat(document.getElementById('wd-amount').value) || 0;
    document.getElementById('wd-sum-amt').textContent = ABAY.fmtETB(amt);
    if (_wdAccount) {
      var newBal = (_wdAccount.balance || 0) - amt;
      document.getElementById('wd-sum-new').textContent = ABAY.fmtETB(Math.max(0, newBal));
    }
    document.getElementById('large-wd-warn').style.display = amt > 100000 ? 'block' : 'none';
  }

  function resetWdForm() {
    _wdAccount = null;
    document.getElementById('wd-form').reset();
    document.getElementById('wd-form').style.display = '';
    document.getElementById('wd-success').style.display = 'none';
    document.getElementById('wd-error').style.display = 'none';
    document.getElementById('wd-acc-info').style.display = 'none';
    document.getElementById('wd-holder').value = '';
    ['wd-sum-acc', 'wd-sum-cust', 'wd-sum-bal', 'wd-sum-new'].forEach(function(id) {
      document.getElementById(id).textContent = '—';
    });
    document.getElementById('wd-sum-amt').textContent = 'ETB 0.00';
    document.getElementById('large-wd-warn').style.display = 'none';
  }

  document.getElementById('wd-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var acc = document.getElementById('wd-account').value.trim();
    var amt = parseFloat(document.getElementById('wd-amount').value) || 0;
    var desc = document.getElementById('wd-narration').value || 'Cash Withdrawal';
    document.getElementById('wd-error').style.display = 'none';
    if (!acc) {
      document.getElementById('wd-error-msg').textContent = 'Account number is required.';
      document.getElementById('wd-error').style.display = 'flex';
      return;
    }
    if (amt < 100) {
      document.getElementById('wd-error-msg').textContent = 'Minimum withdrawal is ETB 100.';
      document.getElementById('wd-error').style.display = 'flex';
      return;
    }
    if (_wdAccount && amt > _wdAccount.balance) {
      document.getElementById('wd-error-msg').textContent = 'Insufficient balance. Available: ' + ABAY.fmtETB(_wdAccount.balance);
      document.getElementById('wd-error').style.display = 'flex';
      return;
    }
    ABAY.setBtn('wd-btn', true);
    ABAY.api('/transactions/withdrawal', {
      method: 'POST',
      body: JSON.stringify({
        account_number: acc,
        amount: amt,
        description: desc
      })
    }).then(function(d) {
      ABAY.setBtn('wd-btn', false, '<i class="fa-solid fa-arrow-up"></i> Process Withdrawal');
      if (d && d.success) {
        document.getElementById('wd-success-msg').textContent = ABAY.fmtETB(amt) + ' withdrawn from ' + acc + '. Ref: ' + (d.data && d.data.reference ? d.data.reference : 'N/A');
        document.getElementById('wd-success').style.display = 'block';
        document.getElementById('wd-form').style.display = 'none';
        ABAY.toast('Withdrawal of ' + ABAY.fmtETB(amt) + ' processed!', 'ok');
      } else {
        document.getElementById('wd-error-msg').textContent = (d && d.message) || 'Withdrawal failed.';
        document.getElementById('wd-error').style.display = 'flex';
      }
    }).catch(function() {
      ABAY.setBtn('wd-btn', false, '<i class="fa-solid fa-arrow-up"></i> Process Withdrawal');
      document.getElementById('wd-success-msg').textContent = 'Demo: ' + ABAY.fmtETB(amt) + ' withdrawn from ' + acc + ' (Database offline)';
      document.getElementById('wd-success').style.display = 'block';
      document.getElementById('wd-form').style.display = 'none';
      ABAY.toast('Demo withdrawal recorded.', 'info');
    });
  });
</script>