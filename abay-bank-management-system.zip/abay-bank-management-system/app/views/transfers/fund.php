<?php $pageTitle = 'Fund Transfer — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-right-left" style="color:#1B3A5C;margin-right:8px"></i>Fund Transfer</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Fund Transfer</span></div>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <a href="<?= APP_URL ?>/transfers/local" class="btn btn-ghost btn-sm"><i class="fa-solid fa-building-columns"></i> Local</a>
    <a href="<?= APP_URL ?>/transfers/international" class="btn btn-ghost btn-sm"><i class="fa-solid fa-globe"></i> International</a>
  </div>
</div>
<?php
// Re-use the transfer view
$_GET['view'] = 'fund';
include VIEW_PATH . '/transactions/transfer.php';
