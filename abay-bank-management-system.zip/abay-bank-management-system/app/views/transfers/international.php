<?php $pageTitle = 'International Transfer — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-globe" style="color:#1B3A5C;margin-right:8px"></i>International Transfer</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>International Transfer</span></div>
  </div>
  <a href="<?= APP_URL ?>/transfers/local" class="btn btn-ghost btn-sm"><i class="fa-solid fa-building-columns"></i> Local Transfer</a>
</div>

<!-- Method Tabs -->
<div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
  <?php foreach([
    ['swift',     'fa-globe',        'SWIFT Wire',    'International bank','#ede9fe','#5b21b6'],
    ['wu',        'fa-money-bill-transfer','Western Union','Cash pickup WW',  '#fef9c3','#854d0e'],
    ['wise',      'fa-right-left',   'Wise',           'Low-fee multi-currency','#dcfce7','#16a34a'],
    ['payoneer',  'fa-credit-card',  'Payoneer',       'Business payments','#fee2e2','#dc2626'],
  ] as $i => [$t,$ic,$lbl,$sub,$bg,$tc]): ?>
  <button onclick="setIntlTab('<?= $t ?>')" id="itab-<?= $t ?>" class="btn <?= $i===0?'btn-primary':'btn-ghost' ?>" style="display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 18px;min-width:148px;text-align:left">
    <div style="display:flex;align-items:center;gap:7px;font-weight:700"><i class="fa-solid <?= $ic ?>"></i><?= $lbl ?></div>
    <div style="font-size:.7rem;opacity:.75;font-weight:400"><?= $sub ?></div>
  </button>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px">
  <div>

    <!-- SWIFT Wire Panel -->
    <div id="ipanel-swift">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-globe" style="color:#5b21b6;margin-right:7px"></i>SWIFT Wire Transfer</h3>
          <span style="background:#ede9fe;color:#5b21b6;padding:4px 10px;border-radius:6px;font-size:.74rem;font-weight:700">1–3 Business Days</span>
        </div>
        <div class="card-body">
          <div id="swift-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <div id="swift-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin-bottom:14px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px"><i class="fa-solid fa-circle-xmark"></i><span id="swift-err-msg"></span></div>
          <form id="swift-form">
            <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:14px">
              <div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:11px"><i class="fa-solid fa-user" style="color:#5b21b6;margin-right:4px"></i>Beneficiary Information</div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Bank Name *</label><input type="text" id="swift-bank" placeholder="Beneficiary bank name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'"></div>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">SWIFT / BIC Code *</label><input type="text" id="swift-code" placeholder="e.g. DEUTDEDB" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none;text-transform:uppercase" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'"></div>
              </div>
              <div style="margin-bottom:12px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Holder Name *</label><input type="text" id="swift-holder" placeholder="Full legal name of account holder" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account / IBAN *</label><input type="text" id="swift-iban" placeholder="Account number or IBAN" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'"></div>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Country *</label>
                  <select id="swift-country" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
                    <option value="">Select country...</option>
                    <?php foreach(['United States','United Kingdom','Germany','France','Netherlands','UAE','Saudi Arabia','China','India','Japan','Canada','Australia','South Africa','Kenya','Uganda'] as $c): ?><option><?= $c ?></option><?php endforeach; ?>
                  </select>
                </div>
              </div>
            </div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:14px">
              <div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:11px"><i class="fa-solid fa-money-bill-transfer" style="color:#5b21b6;margin-right:4px"></i>Transfer Details</div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account (Abay) *</label><input type="text" id="swift-from" placeholder="Your Abay Bank account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'"></div>
                <div style="display:grid;grid-template-columns:2fr 1fr;gap:8px">
                  <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount *</label><input type="number" id="swift-amount" min="1" step="0.01" placeholder="0.00" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#5b21b6'" onblur="this.style.borderColor='#e2e8f0'" oninput="calcSwiftFee()"></div>
                  <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Currency</label>
                    <select id="swift-currency" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer" onchange="calcSwiftFee()">
                      <option>USD</option><option>EUR</option><option>GBP</option><option>AED</option><option>SAR</option>
                    </select>
                  </div>
                </div>
              </div>
              <div id="swift-fee-box" style="display:none;background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:10px;padding:13px;margin-bottom:12px;color:#fff;text-align:center">
                <div style="font-size:.68rem;opacity:.65;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">Total Including Wire Fee (USD 25)</div>
                <div style="font-size:1.6rem;font-weight:900" id="swift-total-display">USD 0.00</div>
              </div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Transfer Purpose *</label>
                <select id="swift-purpose" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
                  <option>Business Payment</option><option>Personal Transfer</option><option>Education</option><option>Medical</option><option>Property Purchase</option><option>Import Payment</option><option>Salary/Wages</option><option>Other</option>
                </select>
              </div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="button" class="btn btn-ghost" onclick="document.getElementById('swift-form').reset();document.getElementById('swift-fee-box').style.display='none'"><i class="fa-solid fa-rotate"></i> Reset</button>
              <button type="submit" id="swift-btn" style="background:linear-gradient(135deg,#5b21b6,#7c3aed);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-globe"></i>Send Wire Transfer</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Western Union Panel -->
    <div id="ipanel-wu" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-money-bill-transfer" style="color:#854d0e;margin-right:7px"></i>Western Union — Cash Pickup Worldwide</h3>
          <span style="background:#fef9c3;color:#854d0e;padding:4px 10px;border-radius:6px;font-size:.74rem;font-weight:700">Minutes – Hours</span>
        </div>
        <div class="card-body">
          <div id="wu-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="wu-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account *</label><input type="text" id="wu-from" placeholder="Your account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Destination Country *</label>
                <select id="wu-country" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
                  <option value="">Select country...</option>
                  <?php foreach(['United States','United Kingdom','Germany','UAE','Saudi Arabia','Kenya','Uganda','South Africa','Canada','Australia'] as $c): ?><option><?= $c ?></option><?php endforeach; ?>
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Recipient First Name *</label><input type="text" id="wu-fname" placeholder="First name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Recipient Last Name *</label><input type="text" id="wu-lname" placeholder="Last name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (USD) *</label><div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden"><span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">$</span><input type="number" id="wu-amount" min="1" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none"></div></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Purpose</label><select id="wu-purpose" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer"><option>Family Support</option><option>Business</option><option>Education</option><option>Medical</option></select></div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="wu-btn" style="background:linear-gradient(135deg,#92400e,#d97706);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send via Western Union</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Wise Panel -->
    <div id="ipanel-wise" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3 style="display:flex;align-items:center;gap:8px"><span style="font-weight:900;font-size:1.1rem;color:#16a34a">wise</span>Low-Fee Multi-Currency Transfer</h3>
          <span style="background:#dcfce7;color:#16a34a;padding:4px 10px;border-radius:6px;font-size:.74rem;font-weight:700">~0.5% Fee</span>
        </div>
        <div class="card-body">
          <div id="wise-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="wise-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account *</label><input type="text" id="wise-from" placeholder="Your account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#16a34a'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Recipient Email / Phone *</label><input type="text" id="wise-to" placeholder="recipient@email.com" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#16a34a'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:grid;grid-template-columns:2fr 1fr;gap:12px;margin-bottom:14px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount *</label><input type="number" id="wise-amount" min="1" placeholder="0.00" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#16a34a'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Currency</label><select id="wise-currency" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer"><option>USD</option><option>EUR</option><option>GBP</option><option>ETB</option></select></div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="wise-btn" style="background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send via Wise</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Payoneer Panel -->
    <div id="ipanel-payoneer" style="display:none">
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-credit-card" style="color:#dc2626;margin-right:7px"></i>Payoneer — Global Business Payments</h3>
          <span style="background:#fee2e2;color:#dc2626;padding:4px 10px;border-radius:6px;font-size:.74rem;font-weight:700">1% Fee · Min $50</span>
        </div>
        <div class="card-body">
          <div id="pay-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="pay-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account *</label><input type="text" id="pay-from" placeholder="Your account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#dc2626'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Payoneer Email *</label><input type="email" id="pay-email" placeholder="recipient@payoneer.com" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#dc2626'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (USD) * · Min $50</label><div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden"><span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">$</span><input type="number" id="pay-amount" min="50" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none"></div></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Purpose</label><select id="pay-purpose" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer"><option>Freelance Payment</option><option>Business Payment</option><option>Service Fee</option><option>Other</option></select></div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="pay-btn" style="background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send via Payoneer</button>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div><!-- end left col -->

  <!-- Info Panel -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none">
      <div class="card-body">
        <div style="font-size:.68rem;opacity:.6;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px">Wire Reference</div>
        <div style="font-size:.9rem;font-weight:700">Abay Bank S.C.</div>
        <div style="font-size:.8rem;opacity:.75;margin-top:4px">SWIFT: ABYAETAA</div>
        <div style="font-size:.8rem;opacity:.75">Correspondent: Standard Chartered</div>
        <div style="height:1px;background:rgba(255,255,255,.15);margin:12px 0"></div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <?php foreach([['USD Fee','$25 per wire'],['EUR Fee','€23 per wire'],['GBP Fee','£20 per wire'],['Processing','1–3 business days'],['Max Transfer','$50,000/day']] as [$k,$v]): ?>
          <div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;opacity:.65"><?= $k ?></span><span style="font-size:.78rem;font-weight:700"><?= $v ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-circle-info" style="color:#1B3A5C;margin-right:6px"></i>Transfer Guides</h4></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:8px;font-size:.82rem">
        <?php foreach(['SWIFT: Requires 8-11 character BIC code','Western Union: Recipient picks up cash at WU agent','Wise: Uses mid-market exchange rate','Payoneer: Business accounts only, min $50','All international transfers subject to NBE regulations'] as $tip): ?>
        <div style="display:flex;align-items:flex-start;gap:7px;color:#475569"><i class="fa-solid fa-circle-dot" style="color:#007A8A;margin-top:3px;font-size:.7rem;flex-shrink:0"></i><?= $tip ?></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-link" style="color:#1B3A5C;margin-right:6px"></i>Related</h4></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:8px">
        <a href="<?= APP_URL ?>/transfers/local" style="display:flex;align-items:center;gap:9px;padding:9px;border:1.5px solid #e2e8f0;border-radius:8px;text-decoration:none;font-size:.82rem;font-weight:600;color:#1e293b;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-building-columns" style="color:#007A8A"></i>Local Transfer (ETB)</a>
        <a href="<?= APP_URL ?>/transactions/interbank" style="display:flex;align-items:center;gap:9px;padding:9px;border:1.5px solid #e2e8f0;border-radius:8px;text-decoration:none;font-size:.82rem;font-weight:600;color:#1e293b;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-globe" style="color:#5b21b6"></i>Interbank Transfer</a>
        <a href="<?= APP_URL ?>/transactions" style="display:flex;align-items:center;gap:9px;padding:9px;border:1.5px solid #e2e8f0;border-radius:8px;text-decoration:none;font-size:.82rem;font-weight:600;color:#1e293b;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-list" style="color:#1B3A5C"></i>Transaction History</a>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
function setIntlTab(tab) {
  ['swift','wu','wise','payoneer'].forEach(function(t) {
    var btn = document.getElementById('itab-' + t);
    var panel = document.getElementById('ipanel-' + t);
    btn.className = 'btn ' + (t === tab ? 'btn-primary' : 'btn-ghost');
    btn.style.cssText += 'display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 18px;min-width:148px;text-align:left';
    if (panel) panel.style.display = t === tab ? 'block' : 'none';
  });
}

function calcSwiftFee() {
  var amt = parseFloat(document.getElementById('swift-amount').value) || 0;
  var box = document.getElementById('swift-fee-box');
  var disp = document.getElementById('swift-total-display');
  var cur = document.getElementById('swift-currency').value || 'USD';
  if (amt > 0) { box.style.display = 'block'; disp.textContent = cur + ' ' + (amt + 25).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  else { box.style.display = 'none'; }
}

function submitIntlForm(formId, btnId, successId, buildPayload) {
  var payload = buildPayload();
  if (!payload) return;
  ABAY.setBtn(btnId, true);
  ABAY.api('/transactions/transfer', { method: 'POST', body: JSON.stringify(payload) }).then(function(d) {
    ABAY.setBtn(btnId, false, document.getElementById(btnId).textContent || 'Send');
    var el = document.getElementById(successId);
    if (d && d.success) { el.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:6px"></i>Transfer submitted! Ref: ' + (d.data && d.data.reference ? d.data.reference : 'N/A'); el.style.display = 'block'; ABAY.toast('International transfer submitted!', 'ok'); }
    else { ABAY.toast((d && d.message) || 'Transfer failed.', 'err'); }
  }).catch(function() {
    ABAY.setBtn(btnId, false, document.getElementById(btnId).textContent || 'Send');
    var el = document.getElementById(successId);
    el.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:6px"></i>Demo: Transfer recorded (Database offline). Ref: INTL-' + Date.now().toString(36).toUpperCase();
    el.style.display = 'block'; ABAY.toast('Demo international transfer recorded.', 'info');
  });
}

document.getElementById('swift-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var bank = document.getElementById('swift-bank').value.trim(), code = document.getElementById('swift-code').value.trim().toUpperCase(),
      holder = document.getElementById('swift-holder').value.trim(), iban = document.getElementById('swift-iban').value.trim(),
      country = document.getElementById('swift-country').value, from = document.getElementById('swift-from').value.trim(),
      amt = parseFloat(document.getElementById('swift-amount').value) || 0, cur = document.getElementById('swift-currency').value,
      purpose = document.getElementById('swift-purpose').value;
  if (!bank || !code || !holder || !iban || !country || !from || amt < 1) { document.getElementById('swift-err-msg').textContent = 'All fields are required.'; document.getElementById('swift-error').style.display = 'flex'; return; }
  if (code.length < 8) { document.getElementById('swift-err-msg').textContent = 'SWIFT/BIC code must be 8–11 characters.'; document.getElementById('swift-error').style.display = 'flex'; return; }
  document.getElementById('swift-error').style.display = 'none';
  submitIntlForm('swift-form','swift-btn','swift-success', function() { return { type: 'SWIFT', from_account: from, bank_name: bank, swift_code: code, beneficiary: holder, account_iban: iban, country: country, amount: amt, currency: cur, purpose: purpose, channel: 'SWIFT' }; });
});

['wu','wise','payoneer'].forEach(function(t) {
  var form = document.getElementById(t + '-form');
  if (!form) return;
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    submitIntlForm(t+'-form', t+'-btn', t+'-success', function() {
      return { type: t.toUpperCase(), from_account: document.getElementById(t+'-from')||'', amount: parseFloat((document.getElementById(t+'-amount')||{}).value)||0, channel: t };
    });
  });
});
</script>
