<?php $pageTitle = 'Local Transfer — ' . APP_NAME; ?>
<div class="page-header">
  <div class="page-header-left">
    <h1><i class="fa-solid fa-building-columns" style="color:#1B3A5C;margin-right:8px"></i>Local Transfer</h1>
    <div class="breadcrumb"><a href="<?= APP_URL ?>/dashboard">Dashboard</a><span class="sep">/</span><span>Local Transfer</span></div>
  </div>
  <a href="<?= APP_URL ?>/transfers/international" class="btn btn-ghost btn-sm"><i class="fa-solid fa-globe"></i> International Transfer</a>
</div>

<!-- Transfer Method Tabs -->
<div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
  <?php foreach([
    ['internal',  'fa-building-columns','Internal Transfer','Between Abay Bank accounts','#dbeafe','#1d4ed8'],
    ['ethswitch', 'fa-bolt',            'EthSwitch',        'Real-time inter-bank ETB',  '#d1fae5','#059669'],
    ['telebirr',  'fa-mobile-screen',   'Telebirr',         'Ethio Telecom mobile money','#fed7aa','#ea580c'],
    ['mpesa',     'fa-sim-card',        'M-Pesa',           'M-Pesa mobile wallet',      '#d1fae5','#047857'],
  ] as [$t,$ic,$lbl,$sub,$bg,$tc]): ?>
  <button onclick="setLocalTab('<?= $t ?>')" id="ltab-<?= $t ?>" class="btn <?= $t==='internal'?'btn-primary':'btn-ghost' ?>" style="display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 18px;min-width:148px;text-align:left;position:relative">
    <div style="display:flex;align-items:center;gap:7px;font-weight:700"><i class="fa-solid <?= $ic ?>"></i><?= $lbl ?></div>
    <div style="font-size:.7rem;opacity:.75;font-weight:400"><?= $sub ?></div>
  </button>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:22px">
  <div>
    <!-- Internal Transfer Panel -->
    <div id="lpanel-internal">
      <div class="card">
        <div class="card-header"><h3><i class="fa-solid fa-building-columns" style="color:#1B3A5C;margin-right:7px"></i>Internal Transfer — Abay Bank to Abay Bank</h3></div>
        <div class="card-body">
          <div id="int-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:16px;margin-bottom:16px"></div>
          <div id="int-error" style="display:none;background:#fee2e2;border:1px solid #fecaca;border-radius:10px;padding:12px;margin-bottom:14px;color:#991b1b;font-size:.84rem;display:flex;align-items:center;gap:8px"><i class="fa-solid fa-circle-xmark"></i><span id="int-err-msg"></span></div>
          <form id="int-form">
            <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:14px">
              <div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:11px"><i class="fa-solid fa-arrow-right" style="color:#007A8A;margin-right:4px"></i>From Account</div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Number *</label>
                  <input type="text" id="int-from" placeholder="Source account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'" oninput="lookupIntFrom(this.value)"></div>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Holder</label>
                  <input type="text" id="int-from-holder" readonly placeholder="Auto-filled" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#f8fafc;color:#475569"></div>
              </div>
              <div id="int-from-bal" style="display:none;margin-top:10px;background:#e0f5f7;border-radius:8px;padding:9px 12px;font-size:.84rem">Available: <strong style="color:#007A8A" id="int-from-bal-val">—</strong></div>
            </div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:14px">
              <div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:11px"><i class="fa-solid fa-arrow-left" style="color:#007A8A;margin-right:4px"></i>To Account</div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Number *</label>
                  <input type="text" id="int-to" placeholder="Destination account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'" oninput="lookupIntTo(this.value)"></div>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Beneficiary Name</label>
                  <input type="text" id="int-to-holder" readonly placeholder="Auto-filled" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#f8fafc;color:#475569"></div>
              </div>
            </div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:14px">
              <div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:11px"><i class="fa-solid fa-coins" style="color:#007A8A;margin-right:4px"></i>Amount & Purpose</div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (ETB) *</label>
                  <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden" id="int-amt-wrap">
                    <span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;font-weight:600;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span>
                    <input type="number" id="int-amount" min="1" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none" onfocus="document.getElementById('int-amt-wrap').style.borderColor='#007A8A'" onblur="document.getElementById('int-amt-wrap').style.borderColor='#e2e8f0'" oninput="updateIntPreview()">
                  </div>
                </div>
                <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Transfer Fee</label>
                  <input type="text" readonly value="ETB 0.00 (Free - Internal)" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#f8fafc;color:#475569"></div>
              </div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Purpose</label>
                <input type="text" id="int-purpose" placeholder="e.g. Business payment, salary, loan repayment" value="Fund Transfer" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="button" class="btn btn-ghost" onclick="resetIntForm()"><i class="fa-solid fa-rotate"></i> Reset</button>
              <button type="submit" id="int-btn" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send Transfer</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- EthSwitch Panel -->
    <div id="lpanel-ethswitch" style="display:none">
      <div class="card">
        <div class="card-header"><h3><i class="fa-solid fa-bolt" style="color:#059669;margin-right:7px"></i>EthSwitch — Real-Time Inter-Bank Transfer</h3></div>
        <div class="card-body">
          <div id="eth-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="eth-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account (Abay) *</label><input type="text" id="eth-from" placeholder="Your account number" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Destination Bank *</label>
                <select id="eth-bank" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#fff;cursor:pointer">
                  <option value="">Select bank...</option>
                  <?php foreach(['Commercial Bank of Ethiopia (CBE)','Dashen Bank','Awash Bank','Bank of Abyssinia','Wegagen Bank','NIB International Bank','Oromia Bank','Zemen Bank','Berhan Bank','Enat Bank','Tsedey Bank'] as $bk): ?>
                  <option><?= $bk ?></option><?php endforeach; ?>
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Destination Account *</label><input type="text" id="eth-to" placeholder="Recipient account" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Account Holder Name *</label><input type="text" id="eth-holder" placeholder="Beneficiary name" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (ETB) *</label>
                <div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden"><span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span><input type="number" id="eth-amount" min="1" step="0.01" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none"></div>
              </div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">EthSwitch Fee</label><input type="text" readonly value="ETB 15.00 (flat fee)" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#f8fafc;color:#475569"></div>
            </div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="eth-btn" style="background:linear-gradient(135deg,#059669,#10b981);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-bolt"></i>Send via EthSwitch</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Telebirr Panel -->
    <div id="lpanel-telebirr" style="display:none">
      <div class="card">
        <div class="card-header"><h3><i class="fa-solid fa-mobile-screen" style="color:#ea580c;margin-right:7px"></i>Telebirr — Mobile Money Transfer</h3></div>
        <div class="card-body">
          <div id="tel-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="tel-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account *</label><input type="text" id="tel-from" placeholder="Your account number" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Telebirr Phone Number *</label><input type="tel" id="tel-phone" placeholder="+251 912 345 678" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (ETB) *</label><div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden"><span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span><input type="number" id="tel-amount" min="1" max="50000" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none"></div></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Telebirr Fee</label><input type="text" readonly value="ETB 5.00 · Limit: 50,000/day" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;background:#f8fafc;color:#475569"></div>
            </div>
            <div style="margin-bottom:14px"><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Note</label><input type="text" id="tel-note" placeholder="Optional note" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="tel-btn" style="background:linear-gradient(135deg,#ea580c,#f97316);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send via Telebirr</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- M-Pesa Panel -->
    <div id="lpanel-mpesa" style="display:none">
      <div class="card">
        <div class="card-header"><h3><i class="fa-solid fa-sim-card" style="color:#047857;margin-right:7px"></i>M-Pesa Ethiopia</h3></div>
        <div class="card-body">
          <div id="mp-success" style="display:none;background:#d1fae5;border:1px solid #a7f3d0;border-radius:10px;padding:14px;margin-bottom:14px;font-size:.84rem;color:#065f46"></div>
          <form id="mp-form">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">From Account *</label><input type="text" id="mp-from" placeholder="Your account number" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
              <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">M-Pesa Phone *</label><input type="tel" id="mp-phone" placeholder="+251 912 345 678" style="border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:.86rem;width:100%;outline:none" onfocus="this.style.borderColor='#007A8A'" onblur="this.style.borderColor='#e2e8f0'"></div>
            </div>
            <div><label style="display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:4px">Amount (ETB) *</label><div style="display:flex;align-items:center;border:1.5px solid #e2e8f0;border-radius:8px;overflow:hidden;margin-bottom:12px"><span style="padding:0 11px;background:#f1f5f9;color:#64748b;font-size:.83rem;height:42px;display:flex;align-items:center;border-right:1.5px solid #e2e8f0">ETB</span><input type="number" id="mp-amount" min="10" placeholder="0.00" style="flex:1;border:none;padding:10px 12px;font-size:.86rem;outline:none"></div></div>
            <div style="display:flex;gap:12px;justify-content:flex-end">
              <button type="submit" id="mp-btn" style="background:linear-gradient(135deg,#047857,#10b981);color:#fff;border:none;border-radius:10px;padding:12px 28px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:8px"><i class="fa-solid fa-paper-plane"></i>Send via M-Pesa</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Summary Panel -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-receipt" style="color:#1B3A5C;margin-right:6px"></i>Transfer Summary</h4></div>
      <div class="card-body" id="transfer-summary" style="display:flex;flex-direction:column;gap:9px">
        <?php foreach([['From','—','sum-from'],['To','—','sum-to'],['Amount','ETB 0.00','sum-amount'],['Fee','ETB 0.00','sum-fee'],['Total','ETB 0.00','sum-total']] as [$l,$d,$id]): ?>
        <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9">
          <span style="font-size:.79rem;color:#94a3b8;font-weight:600"><?= $l ?></span>
          <span style="font-size:.82rem;font-weight:700;color:<?= $id==='sum-total'?'#ef4444':'#1e293b' ?>" id="<?= $id ?>"><?= $d ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Recent Transactions -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-clock-rotate-left" style="color:#1B3A5C;margin-right:6px"></i>Recent Transfers</h4><a href="<?= APP_URL ?>/transactions" style="font-size:.76rem;color:#007A8A;font-weight:700;text-decoration:none">View All</a></div>
      <div class="card-body" style="padding:0">
        <?php
        $recentTxns = $recentTxns ?? [];
        if (empty($recentTxns)) $recentTxns = [
          ['reference'=>'TRF-A1B2','type'=>'Transfer Out','amount'=>8200,'created_at'=>date('Y-m-d H:i:s',strtotime('-32 min')),'status'=>'Completed'],
          ['reference'=>'TRF-B2C3','type'=>'Transfer In','amount'=>12000,'created_at'=>date('Y-m-d H:i:s',strtotime('-2 hours')),'status'=>'Completed'],
          ['reference'=>'IBT-C3D4','type'=>'Transfer Out','amount'=>25000,'created_at'=>date('Y-m-d H:i:s',strtotime('-4 hours')),'status'=>'Completed'],
        ];
        foreach ($recentTxns as $t):
          $isIn = ($t['type']??'')==='Transfer In';
          $d = time()-strtotime($t['created_at']??'now');
          $ago = $d<3600?round($d/60).'m ago':round($d/3600).'h ago';
        ?>
        <div style="display:flex;align-items:center;gap:11px;padding:11px 16px;border-bottom:1px solid #f8fafc">
          <div style="width:34px;height:34px;border-radius:9px;background:<?= $isIn?'#d1fae5':'#fee2e2' ?>;color:<?= $isIn?'#059669':'#dc2626' ?>;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0"><i class="fa-solid <?= $isIn?'fa-arrow-down':'fa-arrow-up' ?>"></i></div>
          <div style="flex:1"><div style="font-size:.8rem;font-weight:600;color:#1e293b"><?= htmlspecialchars($t['reference']??'—') ?></div><div style="font-size:.7rem;color:#94a3b8"><?= $ago ?></div></div>
          <div style="font-size:.82rem;font-weight:700;color:<?= $isIn?'#059669':'#dc2626' ?>"><?= $isIn?'+':'-' ?> ETB <?= number_format($t['amount']??0) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="card">
      <div class="card-header"><h4><i class="fa-solid fa-link" style="color:#1B3A5C;margin-right:6px"></i>Transfer Options</h4></div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:9px">
        <a href="<?= APP_URL ?>/transfers/international" style="display:flex;align-items:center;gap:10px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-globe" style="color:#5b21b6;width:18px"></i><div><div style="font-size:.83rem;font-weight:700;color:#1e293b">International Wire</div><div style="font-size:.72rem;color:#94a3b8">SWIFT, Western Union, Wise</div></div><i class="fa-solid fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.8rem"></i></a>
        <a href="<?= APP_URL ?>/transactions/interbank" style="display:flex;align-items:center;gap:10px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-building" style="color:#007A8A;width:18px"></i><div><div style="font-size:.83rem;font-weight:700;color:#1e293b">Staff Interbank</div><div style="font-size:.72rem;color:#94a3b8">Admin interbank transfer</div></div><i class="fa-solid fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.8rem"></i></a>
        <a href="<?= APP_URL ?>/transactions" style="display:flex;align-items:center;gap:10px;padding:10px;border:1.5px solid #e2e8f0;border-radius:9px;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#007A8A'" onmouseout="this.style.borderColor='#e2e8f0'"><i class="fa-solid fa-list" style="color:#1B3A5C;width:18px"></i><div><div style="font-size:.83rem;font-weight:700;color:#1e293b">Transaction History</div><div style="font-size:.72rem;color:#94a3b8">All transfers & transactions</div></div><i class="fa-solid fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.8rem"></i></a>
      </div>
    </div>
  </div>
</div>

<?php include VIEW_PATH . '/layout/_page-utils.php'; ?>
<script>
var _curLocalTab = 'internal';

function setLocalTab(tab) {
  _curLocalTab = tab;
  ['internal','ethswitch','telebirr','mpesa'].forEach(function(t) {
    var btn = document.getElementById('ltab-' + t);
    var panel = document.getElementById('lpanel-' + t);
    if (btn) btn.className = 'btn ' + (t === tab ? 'btn-primary' : 'btn-ghost') + ' ' + btn.className.replace('btn-primary','').replace('btn-ghost','').trim();
    btn.className = 'btn ' + (t === tab ? 'btn-primary' : 'btn-ghost');
    btn.style.flexDirection = 'column'; btn.style.alignItems = 'flex-start'; btn.style.gap = '2px'; btn.style.padding = '12px 18px'; btn.style.minWidth = '148px'; btn.style.textAlign = 'left';
    if (panel) panel.style.display = t === tab ? 'block' : 'none';
  });
}

function lookupIntFrom(val) {
  if (val.length < 4) return;
  clearTimeout(window._iltf);
  window._iltf = setTimeout(function() {
    ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
      var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
      if (!acc) acc = { account_number: val, customer_name: 'Demo Customer', balance: 84500 };
      document.getElementById('int-from-holder').value = acc.customer_name || '—';
      document.getElementById('int-from-bal-val').textContent = ABAY.fmtETB(acc.balance || 0);
      document.getElementById('int-from-bal').style.display = 'block';
      document.getElementById('sum-from').textContent = val;
    }).catch(function() { document.getElementById('int-from-holder').value = 'Demo Customer'; document.getElementById('int-from-bal').style.display = 'block'; });
  }, 500);
}

function lookupIntTo(val) {
  if (val.length < 4) return;
  clearTimeout(window._iltt);
  window._iltt = setTimeout(function() {
    ABAY.api('/accounts?account_number=' + encodeURIComponent(val)).then(function(d) {
      var acc = d && d.success && d.data ? (Array.isArray(d.data) ? d.data[0] : d.data) : null;
      if (acc) { document.getElementById('int-to-holder').value = acc.customer_name || '—'; document.getElementById('sum-to').textContent = val; }
    }).catch(function() {});
  }, 500);
}

function updateIntPreview() {
  var amt = parseFloat(document.getElementById('int-amount').value) || 0;
  document.getElementById('sum-amount').textContent = ABAY.fmtETB(amt);
  document.getElementById('sum-fee').textContent = 'ETB 0.00';
  document.getElementById('sum-total').textContent = ABAY.fmtETB(amt);
}

function resetIntForm() {
  document.getElementById('int-form').reset();
  document.getElementById('int-from-bal').style.display = 'none';
  document.getElementById('int-from-holder').value = '';
  document.getElementById('int-to-holder').value = '';
  ['sum-from','sum-to'].forEach(function(id) { document.getElementById(id).textContent = '—'; });
  document.getElementById('sum-amount').textContent = 'ETB 0.00';
  document.getElementById('sum-total').textContent = 'ETB 0.00';
  document.getElementById('int-success').style.display = 'none';
  document.getElementById('int-error').style.display = 'none';
}

function submitLocalForm(formId, btnId, successId, errId, errMsgId, apiEndpoint, buildPayload) {
  document.getElementById(errId).style.display = 'none';
  var payload = buildPayload();
  if (!payload) return;
  ABAY.setBtn(btnId, true);
  ABAY.api(apiEndpoint, { method: 'POST', body: JSON.stringify(payload) }).then(function(d) {
    ABAY.setBtn(btnId, false, document.getElementById(btnId).dataset.label || 'Send');
    if (d && d.success) {
      var el = document.getElementById(successId);
      el.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:6px"></i>Transfer of ETB ' + (payload.amount || 0).toFixed(2) + ' sent successfully! Ref: ' + (d.data && d.data.reference ? d.data.reference : 'N/A');
      el.style.display = 'block'; ABAY.toast('Transfer completed!', 'ok');
    } else { document.getElementById(errMsgId).textContent = (d && d.message) || 'Transfer failed.'; document.getElementById(errId).style.display = 'flex'; }
  }).catch(function() {
    ABAY.setBtn(btnId, false, document.getElementById(btnId).dataset.label || 'Send');
    var el = document.getElementById(successId);
    el.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:6px"></i>Demo: Transfer recorded (Database offline). Ref: TRF-' + Date.now().toString(36).toUpperCase();
    el.style.display = 'block'; ABAY.toast('Demo transfer recorded.', 'info');
  });
}

document.getElementById('int-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var from = document.getElementById('int-from').value.trim(), to = document.getElementById('int-to').value.trim(), amt = parseFloat(document.getElementById('int-amount').value) || 0, purpose = document.getElementById('int-purpose').value;
  if (!from || !to || amt < 1) { document.getElementById('int-err-msg').textContent = 'All fields are required.'; document.getElementById('int-error').style.display = 'flex'; return; }
  if (from === to) { document.getElementById('int-err-msg').textContent = 'Source and destination must differ.'; document.getElementById('int-error').style.display = 'flex'; return; }
  submitLocalForm('int-form','int-btn','int-success','int-error','int-err-msg','/transactions/transfer',function() { return { from_account_number: from, to_account_number: to, amount: amt, description: purpose }; });
});

document.getElementById('eth-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var from = document.getElementById('eth-from').value.trim(), bank = document.getElementById('eth-bank').value, to = document.getElementById('eth-to').value.trim(), holder = document.getElementById('eth-holder').value.trim(), amt = parseFloat(document.getElementById('eth-amount').value) || 0;
  if (!from || !bank || !to || !holder || amt < 1) { ABAY.toast('All fields are required.', 'err'); return; }
  submitLocalForm('eth-form','eth-btn','eth-success','eth-success','eth-success','/transactions/transfer', function() { return { from_account_number: from, to_account_number: to, to_bank: bank, beneficiary: holder, amount: amt, description: 'EthSwitch transfer', channel: 'EthSwitch' }; });
});

document.getElementById('tel-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var from = document.getElementById('tel-from').value.trim(), phone = document.getElementById('tel-phone').value.trim(), amt = parseFloat(document.getElementById('tel-amount').value) || 0;
  if (!phone || amt < 1) { ABAY.toast('Phone and amount are required.', 'err'); return; }
  submitLocalForm('tel-form','tel-btn','tel-success','tel-success','tel-success','/transactions/transfer', function() { return { from_account_number: from, to_phone: phone, amount: amt, description: 'Telebirr transfer', channel: 'Telebirr' }; });
});

document.getElementById('mp-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var from = document.getElementById('mp-from').value.trim(), phone = document.getElementById('mp-phone').value.trim(), amt = parseFloat(document.getElementById('mp-amount').value) || 0;
  if (!phone || amt < 1) { ABAY.toast('Phone and amount are required.', 'err'); return; }
  submitLocalForm('mp-form','mp-btn','mp-success','mp-success','mp-success','/transactions/transfer', function() { return { from_account_number: from, to_phone: phone, amount: amt, description: 'M-Pesa transfer', channel: 'M-Pesa' }; });
});
</script>
