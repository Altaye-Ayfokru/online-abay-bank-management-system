<?php
/**
 * Bootstrap — Abay Bank
 * Sets up CORS, headers, session, and helpers
 */
declare(strict_types=1);

/* ── CORS ── */
$allowedOrigins = explode(',', $_ENV['ALLOWED_ORIGINS'] ?? 'http://localhost');
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins, true) || ($_ENV['APP_ENV'] === 'development')) {
    header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
}
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/* ── Timezone ── */
date_default_timezone_set('Africa/Addis_Ababa');

/* ── Session ── */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 7200,
        'path'     => '/',
        'secure'   => ($_ENV['APP_ENV'] !== 'development'),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}
