<?php

/**
 * Database Configuration — Abay Bank
 */

declare(strict_types=1);

namespace App\Config;

use PDO;
use PDOException;

class Database
{
  private static ?PDO $instance = null;

  public static function connect(): PDO
  {
    if (self::$instance !== null) {
      return self::$instance;
    }

    $host    = $_ENV['DB_HOST']     ?? 'localhost';
    $port    = $_ENV['DB_PORT']     ?? '3306';
    $db      = $_ENV['DB_DATABASE'] ?? 'abay_bank';
    $user    = $_ENV['DB_USERNAME'] ?? 'root';
    $pass    = $_ENV['DB_PASSWORD'] ?? '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";

    $options = [
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES   => false,
      PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
      PDO::ATTR_PERSISTENT         => false,
    ];

    try {
      self::$instance = new PDO($dsn, $user, $pass, $options);
    } catch (PDOException $e) {
      throw new \RuntimeException('DB connection failed: ' . $e->getMessage(), 0, $e);
    }

    return self::$instance;
  }

  /** Execute a prepared query and return the statement */
  public static function query(string $sql, array $params = []): \PDOStatement
  {
    $stmt = self::connect()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
  }

  public static function lastInsertId(): string
  {
    return self::connect()->lastInsertId();
  }

  public static function beginTransaction(): void
  {
    self::connect()->beginTransaction();
  }
  public static function commit(): void
  {
    self::connect()->commit();
  }
  public static function rollback(): void
  {
    self::connect()->rollBack();
  }

  /**
   * Compatibility shim: getInstance()->getConnection()
   * Used by PageController, Auth.php, OnlineApplicationController
   */
  public static function getInstance(): static
  {
    return new static();
  }

  public function getConnection(): PDO
  {
    return self::connect();
  }
}
