<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;
use App\Models\AccountModel;

class AccountController
{
    private AccountModel $model;

    public function __construct() { $this->model = new AccountModel(); }

    /* GET /api/accounts */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page']    ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $filters = array_intersect_key($_GET, array_flip(['type','status','branch_id','search']));
        Response::success($this->model->paginate($page, $perPage, $filters));
    }

    /* POST /api/accounts */
    public function store(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'customer_id'    => 'required|integer',
            'branch_id'      => 'required|integer',
            'account_type'   => 'required|in:Savings,Current,Fixed Deposit',
            'initial_deposit'=> 'required|numeric|min_val:0',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $accountNo = $this->generateAccountNumber($data['account_type'], (int)$data['branch_id']);
        $data['account_number'] = $accountNo;
        $data['created_by']     = JwtHelper::getUserId();

        $id = $this->model->create($data);

        /* Record initial deposit transaction */
        if ((float)($data['initial_deposit'] ?? 0) > 0) {
            Database::query(
                "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,NOW())",
                [$id, 'INIT-' . uniqid(), 'Deposit', (float)$data['initial_deposit'],
                 0, (float)$data['initial_deposit'], 'Initial Deposit', 'Completed', JwtHelper::getUserId()]
            );
        }
        Response::success(['account_id' => $id, 'account_number' => $accountNo], 'Account opened successfully.', 201);
    }

    /* GET /api/accounts/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $account = $this->model->findById($id);
        if (!$account) { Response::error('Account not found.', 404); return; }
        Response::success($account);
    }

    /* PUT /api/accounts/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE accounts SET interest_rate=?, min_balance=?, overdraft_limit=?, updated_at=NOW() WHERE id=?",
            [(float)($data['interest_rate'] ?? 0), (float)($data['min_balance'] ?? 100),
             (float)($data['overdraft_limit'] ?? 0), $id]
        );
        Response::success(null, 'Account updated.');
    }

    /* PUT /api/accounts/{id}/freeze */
    public function freeze(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $this->model->freeze($id);
        Response::success(null, 'Account frozen.');
    }

    /* PUT /api/accounts/{id}/unfreeze */
    public function unfreeze(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $this->model->unfreeze($id);
        Response::success(null, 'Account unfrozen.');
    }

    /* GET /api/accounts/{id}/statement */
    public function statement(int $id): void
    {
        JwtHelper::requireAuth();
        $from = $_GET['from'] ?? date('Y-m-01');
        $to   = $_GET['to']   ?? date('Y-m-d');
        Response::success($this->model->statement($id, $from, $to));
    }

    /* GET /api/accounts/{id}/balance */
    public function balance(int $id): void
    {
        JwtHelper::requireAuth();
        Response::success(['balance' => $this->model->balance($id)]);
    }

    private function generateAccountNumber(string $type, int $branchId): string
    {
        $prefix = match($type) {
            'Savings'       => '1',
            'Current'       => '2',
            'Fixed Deposit' => '3',
            default         => '9',
        };
        $seq = (int)Database::query("SELECT COUNT(*)+1 AS seq FROM accounts")->fetchColumn();
        return $prefix . str_pad((string)$branchId, 3, '0', STR_PAD_LEFT) . str_pad((string)$seq, 9, '0', STR_PAD_LEFT);
    }
}
