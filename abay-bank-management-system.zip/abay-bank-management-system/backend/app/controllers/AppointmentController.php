<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class AppointmentController
{
    /* GET /api/appointments */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $date  = $_GET['date']   ?? date('Y-m-d');
        $rows  = Database::query(
            "SELECT a.*, CONCAT(COALESCE(c.first_name,''),' ',COALESCE(c.last_name,'')) AS customer_name, b.name AS branch_name
             FROM appointments a
             LEFT JOIN customers c ON a.customer_id=c.id
             LEFT JOIN branches  b ON a.branch_id=b.id
             WHERE a.appointment_date >= ?
             ORDER BY a.appointment_date, a.appointment_time
             LIMIT 100", [$date]
        )->fetchAll();
        Response::success($rows);
    }

    /* POST /api/appointments */
    public function store(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'service_type'      => 'required',
            'appointment_date'  => 'required|date',
            'appointment_time'  => 'required',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        Database::query(
            "INSERT INTO appointments (customer_id, customer_name, service_type, appointment_date, appointment_time,
             branch_id, assigned_staff, notes, status, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,NOW())",
            [
                (int)($data['customer_id'] ?? 0), $data['customer_name'] ?? null,
                $data['service_type'], $data['appointment_date'], $data['appointment_time'],
                (int)($data['branch_id'] ?? 0), (int)($data['assigned_staff'] ?? 0),
                $data['notes'] ?? null, 'Pending', JwtHelper::getUserId(),
            ]
        );
        Response::success(['appointment_id' => (int)Database::lastInsertId()], 'Appointment booked.', 201);
    }

    /* PUT /api/appointments/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE appointments SET status=?, notes=?, updated_at=NOW() WHERE id=?",
            [$data['status'] ?? 'Confirmed', $data['notes'] ?? null, $id]
        );
        Response::success(null, 'Appointment updated.');
    }
}
