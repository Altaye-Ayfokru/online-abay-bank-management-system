<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class AttendanceController
{
    /* GET /api/attendance */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $date = $_GET['date'] ?? date('Y-m-d');
        $rows = Database::query(
            "SELECT a.*, CONCAT(e.first_name,' ',e.last_name) AS employee_name,
                    d.name AS department_name, b.name AS branch_name
             FROM attendance a
             LEFT JOIN employees e ON a.employee_id=e.id
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches b ON e.branch_id=b.id
             WHERE a.date=?
             ORDER BY e.first_name", [$date]
        )->fetchAll();

        $summary = [
            'present' => count(array_filter($rows, fn($r) => $r['status'] === 'Present')),
            'absent'  => count(array_filter($rows, fn($r) => $r['status'] === 'Absent')),
            'late'    => count(array_filter($rows, fn($r) => $r['status'] === 'Late')),
            'total'   => count($rows),
        ];
        Response::success(['data' => $rows, 'summary' => $summary]);
    }

    /* POST /api/attendance/checkin */
    public function checkIn(): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $empId = (int)($data['employee_id'] ?? 0);
        if (!$empId) { Response::error('Employee ID required.', 400); return; }

        $today = date('Y-m-d');
        $now   = date('H:i:s');
        $lateThreshold = '08:15:00';

        $exists = Database::query("SELECT id FROM attendance WHERE employee_id=? AND date=?", [$empId, $today])->fetch();
        if ($exists) { Response::error('Check-in already recorded for today.', 409); return; }

        $status = $now > $lateThreshold ? 'Late' : 'Present';
        Database::query(
            "INSERT INTO attendance (employee_id, date, check_in, status, recorded_by, created_at)
             VALUES (?,?,?,?,?,NOW())",
            [$empId, $today, $now, $status, JwtHelper::getUserId()]
        );
        Response::success(['check_in' => $now, 'status' => $status], 'Check-in recorded.', 201);
    }

    /* POST /api/attendance/checkout */
    public function checkOut(): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $empId = (int)($data['employee_id'] ?? 0);
        if (!$empId) { Response::error('Employee ID required.', 400); return; }

        $today = date('Y-m-d');
        $now   = date('H:i:s');

        $record = Database::query(
            "SELECT id FROM attendance WHERE employee_id=? AND date=? AND check_out IS NULL", [$empId, $today]
        )->fetch();

        if (!$record) { Response::error('No active check-in found for today.', 404); return; }

        $overtime = $now > '17:00:00'
            ? round((strtotime($now) - strtotime('17:00:00')) / 3600, 2) : 0;

        Database::query(
            "UPDATE attendance SET check_out=?, overtime_hrs=? WHERE id=?",
            [$now, $overtime, $record['id']]
        );
        Response::success(['check_out' => $now, 'overtime_hrs' => $overtime], 'Check-out recorded.');
    }

    /* GET /api/attendance/report */
    public function report(): void
    {
        JwtHelper::requireAuth();
        $month = $_GET['month'] ?? date('Y-m');
        $rows  = Database::query(
            "SELECT e.employee_number, CONCAT(e.first_name,' ',e.last_name) AS name,
                    COUNT(CASE WHEN a.status='Present' THEN 1 END) AS present_days,
                    COUNT(CASE WHEN a.status='Absent'  THEN 1 END) AS absent_days,
                    COUNT(CASE WHEN a.status='Late'    THEN 1 END) AS late_days,
                    SUM(a.overtime_hrs) AS total_overtime,
                    COUNT(a.id) AS recorded_days
             FROM employees e
             LEFT JOIN attendance a ON a.employee_id=e.id AND DATE_FORMAT(a.date,'%Y-%m')=?
             WHERE e.status='Active'
             GROUP BY e.id
             ORDER BY e.first_name", [$month]
        )->fetchAll();
        Response::success($rows);
    }
}
