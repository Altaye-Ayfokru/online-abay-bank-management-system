<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class AuditController
{
    /* GET /api/audit */
    public function index(): void
    {
        JwtHelper::requireRole(['Admin', 'Auditor', 'Manager']);
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 50));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE 1=1"; $params = [];

        if (!empty($_GET['user_id']))    { $where .= " AND al.user_id=?";     $params[] = (int)$_GET['user_id']; }
        if (!empty($_GET['event_type'])) { $where .= " AND al.event_type=?";  $params[] = $_GET['event_type']; }
        if (!empty($_GET['from']))       { $where .= " AND DATE(al.created_at)>=?"; $params[] = $_GET['from']; }
        if (!empty($_GET['to']))         { $where .= " AND DATE(al.created_at)<=?"; $params[] = $_GET['to']; }

        $total = (int)Database::query("SELECT COUNT(*) FROM audit_logs al {$where}", $params)->fetchColumn();
        $sql   = "SELECT al.*, u.username, u.email
                  FROM audit_logs al LEFT JOIN users u ON al.user_id=u.id
                  {$where} ORDER BY al.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;
        Response::paginated(Database::query($sql, $params)->fetchAll(), $total, $page, $perPage);
    }
}
