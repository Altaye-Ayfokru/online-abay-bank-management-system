<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;
use App\Models\UserModel;

class AuthController
{
  private UserModel $userModel;

  public function __construct()
  {
    $this->userModel = new UserModel();
  }

  /* POST /api/auth/login */
  public function login(): void
  {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    $errors = Validator::validate($data, [
      'username' => 'required|min:3',
      'password' => 'required|min:6',
    ]);
    if ($errors) {
      Response::error('Validation failed.', 422, $errors);
      return;
    }

    $user = $this->userModel->findByUsername($data['username']);

    if (!$user || !password_verify($data['password'], $user['password'])) {
      $this->trackFailedAttempt($data['username']);
      Response::error('Invalid username or password.', 401);
      return;
    }

    if ($user['status'] === 'Locked') {
      Response::error('Account is locked. Please contact admin.', 403);
      return;
    }
    if ($user['status'] !== 'Active') {
      Response::error('Account is inactive. Please contact admin.', 403);
      return;
    }

    /* Clear failed attempts */
    $this->userModel->clearFailedAttempts((int)$user['id']);
    $this->userModel->updateLastLogin((int)$user['id']);

    /* Log audit */
    $this->logAudit((int)$user['id'], 'Login', 'User logged in successfully');

    $roleName = $user['role_name'] ?? $user['role'] ?? 'Staff';

    $token = JwtHelper::generate([
      'user_id' => (int)$user['id'],
      'role'    => $roleName,
      'branch'  => (int)($user['branch_id'] ?? 0),
    ]);

    Response::success([
      'token'      => $token,
      'expires_in' => 7200,
      'user'       => [
        'id'        => (int)$user['id'],
        'username'  => $user['username'],
        'full_name' => $user['full_name'] ?? $user['username'],
        'email'     => $user['email'],
        'role'      => $roleName,
        'role_name' => $roleName,
        'branch_id' => (int)($user['branch_id'] ?? 0),
        'status'    => $user['status'],
        'last_login_at' => $user['last_login_at'],
      ],
    ], 'Login successful.');
  }

  /* POST /api/auth/logout */
  public function logout(): void
  {
    $userId = JwtHelper::getUserId();
    if ($userId) {
      $this->logAudit($userId, 'Logout', 'User logged out');
    }
    Response::success(null, 'Logged out successfully.');
  }

  /* POST /api/auth/forgot-password */
  public function forgotPassword(): void
  {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    $errors = Validator::validate($data, ['email' => 'required|email']);
    if ($errors) {
      Response::error('Validation failed.', 422, $errors);
      return;
    }

    $user = $this->userModel->findByEmail($data['email']);
    /* Always return success to prevent user enumeration */
    Response::success(null, 'If this email is registered, a reset link will be sent.');
  }

  /* POST /api/auth/reset-password */
  public function resetPassword(): void
  {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    $errors = Validator::validate($data, [
      'token'    => 'required',
      'password' => 'required|min:8',
    ]);
    if ($errors) {
      Response::error('Validation failed.', 422, $errors);
      return;
    }
    Response::success(null, 'Password reset successfully.');
  }

  /* PUT /api/auth/change-password */
  public function changePassword(): void
  {
    $userId = JwtHelper::requireAuth();
    $data   = json_decode(file_get_contents('php://input'), true) ?? [];
    $errors = Validator::validate($data, [
      'current_password' => 'required',
      'new_password'     => 'required|min:8',
    ]);
    if ($errors) {
      Response::error('Validation failed.', 422, $errors);
      return;
    }

    $user = $this->userModel->findById($userId);
    if (!$user || !password_verify($data['current_password'], $user['password'])) {
      Response::error('Current password is incorrect.', 400);
      return;
    }

    $hash = password_hash($data['new_password'], PASSWORD_BCRYPT, ['cost' => 12]);
    $this->userModel->updatePassword($userId, $hash);
    $this->logAudit($userId, 'Password Change', 'User changed their password');
    Response::success(null, 'Password changed successfully.');
  }

  /* POST /api/auth/refresh */
  public function refresh(): void
  {
    $userId = JwtHelper::requireAuth();
    $user   = $this->userModel->findById($userId);
    if (!$user) {
      Response::error('User not found.', 404);
      return;
    }

    $token = JwtHelper::generate([
      'user_id' => $user['id'],
      'role'    => $user['role'],
      'branch'  => $user['branch_id'],
    ]);
    Response::success(['token' => $token, 'expires_in' => 7200]);
  }

  private function trackFailedAttempt(string $username): void
  {
    $user = $this->userModel->findByUsername($username);
    if (!$user) return;
    $attempts = (int)($user['failed_attempts'] ?? 0) + 1;
    $this->userModel->incrementFailedAttempts((int)$user['id'], $attempts);
    if ($attempts >= 5) {
      $this->userModel->lockAccount((int)$user['id']);
      $this->logAudit((int)$user['id'], 'Account Locked', "Account locked after {$attempts} failed attempts");
    }
  }

  private function logAudit(int $userId, string $event, string $description): void
  {
    Database::query(
      "INSERT INTO audit_logs (user_id, event_type, description, ip_address, created_at)
             VALUES (?, ?, ?, ?, NOW())",
      [$userId, $event, $description, $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']
    );
  }
}
