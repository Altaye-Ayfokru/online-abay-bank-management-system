<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class BackupController
{
    /* POST /api/backup/create */
    public function create(): void
    {
        JwtHelper::requireRole(['Admin']);
        $dbName  = $_ENV['DB_DATABASE'] ?? 'abay_bank';
        $dbUser  = $_ENV['DB_USERNAME'] ?? 'root';
        $dbPass  = $_ENV['DB_PASSWORD'] ?? '';
        $dbHost  = $_ENV['DB_HOST']     ?? 'localhost';
        $backupDir = ROOT_PATH . '/backend/storage/backups/';
        $filename  = 'backup_' . date('Ymd_His') . '.sql';
        $filepath  = $backupDir . $filename;

        /* Record as in-progress */
        Database::query(
            "INSERT INTO backups (filename, file_size, type, status, created_by, created_at) VALUES (?,0,'Manual','In Progress',?,NOW())",
            [$filename, JwtHelper::getUserId()]
        );
        $backupId = (int)Database::lastInsertId();
        $start = microtime(true);

        /* Execute mysqldump */
        $passArg = $dbPass ? "-p" . escapeshellarg($dbPass) : '';
        $cmd = sprintf(
            'mysqldump -h %s -u %s %s %s > %s 2>&1',
            escapeshellarg($dbHost), escapeshellarg($dbUser), $passArg,
            escapeshellarg($dbName), escapeshellarg($filepath)
        );
        exec($cmd, $output, $exitCode);
        $duration = (int)(microtime(true) - $start);
        $size     = file_exists($filepath) ? filesize($filepath) : 0;
        $status   = ($exitCode === 0 && $size > 0) ? 'Completed' : 'Failed';

        Database::query(
            "UPDATE backups SET file_size=?, status=?, duration_s=?, path=? WHERE id=?",
            [$size, $status, $duration, $filepath, $backupId]
        );

        if ($status === 'Completed') {
            Response::success(['filename' => $filename, 'size' => $size, 'duration' => $duration], 'Backup completed successfully.');
        } else {
            Response::error('Backup failed. Check server logs.', 500);
        }
    }

    /* GET /api/backup/list */
    public function list(): void
    {
        JwtHelper::requireRole(['Admin']);
        $rows = Database::query(
            "SELECT b.*, u.username AS created_by_name FROM backups b
             LEFT JOIN users u ON b.created_by=u.id
             ORDER BY b.created_at DESC LIMIT 50"
        )->fetchAll();
        Response::success($rows);
    }

    /* POST /api/backup/restore */
    public function restore(): void
    {
        JwtHelper::requireRole(['Admin']);
        $data     = json_decode(file_get_contents('php://input'), true) ?? [];
        $backupId = (int)($data['backup_id'] ?? 0);

        if (!$backupId) { Response::error('Backup ID required.', 400); return; }

        $backup = Database::query("SELECT * FROM backups WHERE id=? AND status='Completed'", [$backupId])->fetch();
        if (!$backup) { Response::error('Backup not found.', 404); return; }

        /* Log the restore action */
        Database::query(
            "INSERT INTO audit_logs (user_id, event_type, description, ip_address, created_at)
             VALUES (?,?,?,?,NOW())",
            [JwtHelper::getUserId(), 'Database Restore', "Restore initiated from backup: {$backup['filename']}", $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']
        );

        Response::success(null, 'Database restore initiated. System will restart shortly.');
    }
}
