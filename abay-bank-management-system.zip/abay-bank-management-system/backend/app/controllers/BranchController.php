<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class BranchController
{
    /* GET /api/branches */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $rows = Database::query(
            "SELECT b.*, COUNT(DISTINCT e.id) AS staff_count, COUNT(DISTINCT c.id) AS customer_count,
                    COALESCE(SUM(a.balance),0) AS total_balance
             FROM branches b
             LEFT JOIN employees e  ON e.branch_id=b.id AND e.status='Active'
             LEFT JOIN customers c  ON c.branch_id=b.id AND c.deleted_at IS NULL
             LEFT JOIN accounts a   ON a.branch_id=b.id AND a.status='Active'
             WHERE b.status != 'Inactive'
             GROUP BY b.id
             ORDER BY b.name"
        )->fetchAll();
        Response::success($rows);
    }

    /* POST /api/branches */
    public function store(): void
    {
        JwtHelper::requireRole(['Admin']);
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'name'   => 'required|min:3',
            'city'   => 'required',
            'region' => 'required',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $code = 'BR-' . str_pad(
            (string)((int)Database::query("SELECT COUNT(*)+1 AS c FROM branches")->fetchColumn()),
            3, '0', STR_PAD_LEFT
        );

        Database::query(
            "INSERT INTO branches (code, name, city, region, address, phone, email, opened_date, status, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,NOW())",
            [$code, $data['name'], $data['city'], $data['region'],
             $data['address'] ?? null, $data['phone'] ?? null, $data['email'] ?? null,
             $data['opened_date'] ?? date('Y-m-d'), 'Active']
        );
        Response::success(['branch_id' => (int)Database::lastInsertId(), 'code' => $code], 'Branch created.', 201);
    }

    /* GET /api/branches/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $branch = Database::query("SELECT * FROM branches WHERE id=?", [$id])->fetch();
        if (!$branch) { Response::error('Branch not found.', 404); return; }

        $branch['staff']    = Database::query("SELECT COUNT(*) FROM employees WHERE branch_id=? AND status='Active'", [$id])->fetchColumn();
        $branch['customers']= Database::query("SELECT COUNT(*) FROM customers WHERE branch_id=? AND deleted_at IS NULL", [$id])->fetchColumn();
        $branch['accounts'] = Database::query("SELECT COUNT(*) FROM accounts WHERE branch_id=? AND status='Active'", [$id])->fetchColumn();
        $branch['balance']  = Database::query("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE branch_id=? AND status='Active'", [$id])->fetchColumn();

        Response::success($branch);
    }

    /* PUT /api/branches/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE branches SET name=?, city=?, region=?, address=?, phone=?, email=?, updated_at=NOW() WHERE id=?",
            [$data['name'], $data['city'], $data['region'],
             $data['address'] ?? null, $data['phone'] ?? null, $data['email'] ?? null, $id]
        );
        Response::success(null, 'Branch updated.');
    }
}
