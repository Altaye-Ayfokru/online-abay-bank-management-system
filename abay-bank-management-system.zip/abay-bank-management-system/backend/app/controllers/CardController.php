<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class CardController
{
    /* GET /api/cards */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $rows = Database::query(
            "SELECT ac.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, a.account_number
             FROM atm_cards ac
             LEFT JOIN customers c ON ac.customer_id=c.id
             LEFT JOIN accounts  a ON ac.account_id=a.id
             ORDER BY ac.created_at DESC LIMIT 100"
        )->fetchAll();
        Response::success($rows);
    }

    /* POST /api/cards */
    public function issue(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'account_id'  => 'required|integer',
            'customer_id' => 'required|integer',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $lastFour  = str_pad((string)rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $cardNo    = '**** **** **** ' . $lastFour;
        $expiry    = date('Y-m-d', strtotime('+3 years'));
        $cvvHash   = password_hash((string)rand(100, 999), PASSWORD_BCRYPT);
        $pinHash   = password_hash('0000', PASSWORD_BCRYPT); /* Default PIN */

        Database::query(
            "INSERT INTO atm_cards (account_id, customer_id, card_number, card_type, expiry_date, cvv_hash, pin_hash,
             daily_limit, status, issued_date, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [
                (int)$data['account_id'], (int)$data['customer_id'],
                $cardNo, $data['card_type'] ?? 'Visa Debit',
                $expiry, $cvvHash, $pinHash,
                (float)($data['daily_limit'] ?? 10000), 'Pending', date('Y-m-d'),
                JwtHelper::getUserId(),
            ]
        );
        Response::success(['card_id' => (int)Database::lastInsertId(), 'last_four' => $lastFour], 'Card issued successfully.', 201);
    }

    /* PUT /api/cards/{id}/block */
    public function block(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE atm_cards SET status='Blocked', blocked_at=NOW(), blocked_reason=? WHERE id=?",
            [$data['reason'] ?? 'Blocked by admin', $id]
        );
        Response::success(null, 'Card blocked successfully.');
    }

    /* PUT /api/cards/{id}/activate */
    public function activate(int $id): void
    {
        JwtHelper::requireAuth();
        Database::query("UPDATE atm_cards SET status='Active' WHERE id=?", [$id]);
        Response::success(null, 'Card activated.');
    }
}
