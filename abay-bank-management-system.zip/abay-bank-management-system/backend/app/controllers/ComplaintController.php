<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class ComplaintController
{
    /* GET /api/complaints */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE 1=1"; $params = [];
        if (!empty($_GET['status']))   { $where .= " AND c.status=?";   $params[] = $_GET['status']; }
        if (!empty($_GET['priority'])) { $where .= " AND c.priority=?"; $params[] = $_GET['priority']; }

        $total = (int)Database::query("SELECT COUNT(*) FROM complaints c {$where}", $params)->fetchColumn();
        $sql   = "SELECT c.*, CONCAT(cu.first_name,' ',cu.last_name) AS customer_name
                  FROM complaints c LEFT JOIN customers cu ON c.customer_id=cu.id
                  {$where} ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;
        Response::paginated(Database::query($sql, $params)->fetchAll(), $total, $page, $perPage);
    }

    /* POST /api/complaints */
    public function store(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'category'    => 'required',
            'subject'     => 'required|min:5',
            'description' => 'required|min:20',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        Database::query(
            "INSERT INTO complaints (customer_id, category, subject, description, priority, status, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,NOW())",
            [
                (int)($data['customer_id'] ?? 0), $data['category'], $data['subject'],
                $data['description'], $data['priority'] ?? 'Medium', 'Open', JwtHelper::getUserId(),
            ]
        );
        Response::success(['complaint_id' => (int)Database::lastInsertId()], 'Complaint logged.', 201);
    }

    /* PUT /api/complaints/{id}/resolve */
    public function resolve(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE complaints SET status='Resolved', resolution=?, resolved_at=NOW(), updated_at=NOW() WHERE id=?",
            [$data['resolution'] ?? 'Resolved by support team', $id]
        );
        Response::success(null, 'Complaint resolved.');
    }
}
