<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;
use App\Models\CustomerModel;

class CustomerController
{
    private CustomerModel $model;

    public function __construct()
    {
        $this->model = new CustomerModel();
    }

    /* GET /api/customers */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page     = max(1, (int)($_GET['page']    ?? 1));
        $perPage  = min(100, (int)($_GET['per_page'] ?? 10));
        $search   = trim($_GET['search'] ?? '');
        $status   = trim($_GET['status'] ?? '');
        $branchId = (int)($_GET['branch_id'] ?? 0);

        $result = $this->model->paginate($page, $perPage, $search, $status, $branchId);
        Response::success($result);
    }

    /* POST /api/customers */
    public function store(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'first_name'   => 'required|min:2|alpha',
            'last_name'    => 'required|min:2|alpha',
            'email'        => 'required|email',
            'phone'        => 'required|phone',
            'national_id'  => 'required|min:6',
            'branch_id'    => 'required|integer',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        /* Check duplicates */
        if ($this->model->emailExists($data['email'])) {
            Response::error('Email address already registered.', 409); return;
        }
        if ($this->model->nationalIdExists($data['national_id'])) {
            Response::error('National ID already registered.', 409); return;
        }

        Database::beginTransaction();
        try {
            $customerId = $this->model->create($data);

            /* Auto-create account if account_type provided */
            if (!empty($data['account_type'])) {
                $accountNo = $this->generateAccountNumber($data['account_type'], $data['branch_id']);
                Database::query(
                    "INSERT INTO accounts (customer_id, branch_id, account_number, account_type, balance, status, created_at)
                     VALUES (?, ?, ?, ?, ?, 'Active', NOW())",
                    [$customerId, $data['branch_id'], $accountNo, $data['account_type'], (float)($data['initial_deposit'] ?? 0)]
                );
            }

            Database::commit();
            Response::success(['customer_id' => $customerId], 'Customer registered successfully.', 201);
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Registration failed. Please try again.', 500);
        }
    }

    /* GET /api/customers/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $customer = $this->model->findWithDetails($id);
        if (!$customer) { Response::error('Customer not found.', 404); return; }
        Response::success($customer);
    }

    /* PUT /api/customers/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'first_name' => 'required|min:2',
            'last_name'  => 'required|min:2',
            'email'      => 'required|email',
            'phone'      => 'required|phone',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $affected = $this->model->update($id, $data);
        if (!$affected) { Response::error('Customer not found or no changes.', 404); return; }
        Response::success(null, 'Customer updated successfully.');
    }

    /* DELETE /api/customers/{id} */
    public function destroy(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $this->model->softDelete($id);
        Response::success(null, 'Customer deleted successfully.');
    }

    /* PUT /api/customers/{id}/kyc */
    public function updateKyc(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $status = in_array($data['kyc_status'] ?? '', ['Pending','Verified','Rejected'], true)
            ? $data['kyc_status'] : null;
        if (!$status) { Response::error('Invalid KYC status.', 400); return; }

        Database::query(
            "UPDATE customers SET kyc_status=?, kyc_verified_at=?, kyc_verified_by=?, updated_at=NOW() WHERE id=?",
            [$status, $status==='Verified' ? date('Y-m-d H:i:s') : null, JwtHelper::getUserId(), $id]
        );
        Response::success(null, "KYC status updated to {$status}.");
    }

    private function generateAccountNumber(string $type, int $branchId): string
    {
        $prefix = match($type) {
            'Savings'       => '1',
            'Current'       => '2',
            'Fixed Deposit' => '3',
            default         => '9',
        };
        $sequence = Database::query("SELECT COUNT(*)+1 AS seq FROM accounts")->fetchColumn();
        return $prefix . str_pad((string)$branchId, 3, '0', STR_PAD_LEFT) . str_pad((string)$sequence, 9, '0', STR_PAD_LEFT);
    }
}
