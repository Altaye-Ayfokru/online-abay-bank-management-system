<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Services\TransactionService;
use App\Services\TransferService;
use App\Services\KYCService;
use App\Services\NotificationService;
use PDO;

/**
 * CustomerPortalController
 * Handles all self-service customer portal API calls.
 * Uses session-based auth for customers (separate from staff JWT).
 */
class CustomerPortalController
{
    private PDO $db;
    private int $customerId = 0;
    private int $customerUserId = 0;

    public function __construct()
    {
        $conn = Database::getInstance()->getConnection();
        $this->db = $conn;
        $this->authCustomer();
    }

    /* ─── Auth guard ─── */
    private function authCustomer(): void
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $token  = str_replace('Bearer ', '', $header);
        if (empty($token)) {
            Response::error('Unauthorized. Please login.', 401);
            exit;
        }
        $payload = JwtHelper::verify($token);
        if (!$payload || empty($payload['customer_id'])) {
            Response::error('Invalid or expired session.', 401);
            exit;
        }
        $this->customerId     = (int)$payload['customer_id'];
        $this->customerUserId = (int)($payload['user_id'] ?? 0);
    }

    /* ─── Customer login (separate from staff) ─── */
    public function login(): void
    {
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $username = trim($data['username'] ?? '');
        $password = $data['password'] ?? '';

        if (!$username || !$password) {
            Response::error('Username and password are required.', 422);
            return;
        }

        $user = $this->db->query(
            "SELECT cu.*, c.first_name, c.last_name, c.email AS cust_email,
                    c.kyc_status, c.status AS cust_status
             FROM customer_users cu
             JOIN customers c ON c.id = cu.customer_id
             WHERE cu.username = '" . $this->db->quote($username) . "'
                OR cu.email = '" . $this->db->quote($username) . "'"
        )->fetch(PDO::FETCH_ASSOC);

        if (!$user || !password_verify($password, $user['password'])) {
            // Track failed attempt
            $attempts = (int)($user['failed_attempts'] ?? 0) + 1;
            if ($user) {
                $lock = $attempts >= 5 ? ", is_locked=1, locked_until=DATE_ADD(NOW(), INTERVAL 15 MINUTE)" : '';
                $this->db->prepare("UPDATE customer_users SET failed_attempts=:a{$lock} WHERE id=:id")
                    ->execute([':a' => $attempts, ':id' => $user['id']]);
            }
            Response::error('Invalid username or password.', 401);
            return;
        }

        if ($user['is_locked'] && strtotime($user['locked_until']) > time()) {
            Response::error('Account temporarily locked. Please try again later.', 423);
            return;
        }

        if ($user['cust_status'] !== 'Active') {
            Response::error('Your account is ' . $user['cust_status'] . '. Please contact support.', 403);
            return;
        }

        // Reset failed attempts
        $this->db->prepare("UPDATE customer_users SET failed_attempts=0, is_locked=0, last_login_at=NOW(), last_login_ip=:ip WHERE id=:id")
            ->execute([':ip' => $_SERVER['REMOTE_ADDR'] ?? null, ':id' => $user['id']]);

        $token = JwtHelper::generate([
            'customer_id' => $user['customer_id'],
            'user_id'     => $user['id'],
            'portal'      => 'customer',
        ]);

        Response::success([
            'token'       => $token,
            'expires_in'  => 7200,
            'customer'    => [
                'id'         => $user['customer_id'],
                'name'       => $user['first_name'] . ' ' . $user['last_name'],
                'username'   => $user['username'],
                'email'      => $user['cust_email'],
                'kyc_status' => $user['kyc_status'],
            ],
        ], 'Login successful.');
    }

    /* ─── Dashboard overview ─── */
    public function dashboard(): void
    {
        $accounts = $this->db->query(
            "SELECT id, account_number, account_type, balance, status
             FROM accounts WHERE customer_id={$this->customerId} AND status='Active'"
        )->fetchAll(PDO::FETCH_ASSOC);

        $totalBalance = array_sum(array_column($accounts, 'balance'));

        $recentTxns = $this->db->query(
            "SELECT t.* FROM transactions t
             JOIN accounts a ON a.id = t.account_id
             WHERE a.customer_id = {$this->customerId}
             ORDER BY t.created_at DESC LIMIT 5"
        )->fetchAll(PDO::FETCH_ASSOC);

        $activeLoan = $this->db->query(
            "SELECT COUNT(*) AS count, COALESCE(SUM(outstanding),0) AS total
             FROM loans WHERE customer_id={$this->customerId} AND status IN('Active','Disbursed')"
        )->fetch(PDO::FETCH_ASSOC);

        $notifications = $this->db->query(
            "SELECT * FROM notifications WHERE user_id={$this->customerUserId} AND is_read=0
             ORDER BY created_at DESC LIMIT 5"
        )->fetchAll(PDO::FETCH_ASSOC);

        Response::success([
            'accounts'         => $accounts,
            'total_balance'    => (float)$totalBalance,
            'recent_transactions' => $recentTxns,
            'active_loans'     => $activeLoan,
            'unread_notifications' => count($notifications),
            'notifications'    => $notifications,
        ]);
    }

    /* ─── My accounts ─── */
    public function myAccounts(): void
    {
        $accounts = $this->db->query(
            "SELECT a.*, b.branch_name
             FROM accounts a
             LEFT JOIN branches b ON b.id = a.branch_id
             WHERE a.customer_id = {$this->customerId}
             ORDER BY a.opened_date DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
        Response::success($accounts);
    }

    /* ─── Account statement ─── */
    public function statement(int $accountId): void
    {
        // Verify account belongs to this customer
        $account = $this->db->query(
            "SELECT * FROM accounts WHERE id={$accountId} AND customer_id={$this->customerId}"
        )->fetch(PDO::FETCH_ASSOC);
        if (!$account) { Response::error('Account not found.', 404); return; }

        $from = $_GET['from'] ?? date('Y-m-01');
        $to   = $_GET['to']   ?? date('Y-m-t');

        $transactions = $this->db->query(
            "SELECT * FROM transactions
             WHERE account_id={$accountId}
               AND DATE(created_at) BETWEEN '{$from}' AND '{$to}'
             ORDER BY created_at DESC"
        )->fetchAll(PDO::FETCH_ASSOC);

        Response::success([
            'account'      => $account,
            'from'         => $from,
            'to'           => $to,
            'transactions' => $transactions,
            'total_credit' => array_sum(array_column(array_filter($transactions, fn($t) => in_array($t['type'], ['Deposit','Transfer In','Loan Disbursement'])), 'amount')),
            'total_debit'  => array_sum(array_column(array_filter($transactions, fn($t) => in_array($t['type'], ['Withdrawal','Transfer Out','Loan Repayment'])), 'amount')),
        ]);
    }

    /* ─── Transfer (own / internal) ─── */
    public function transfer(): void
    {
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $svc    = new TransferService($this->db);
        $type   = $data['transfer_type'] ?? 'own';
        $amount = (float)($data['amount'] ?? 0);
        $fromId = (int)($data['from_account_id'] ?? 0);

        if ($type === 'own') {
            $result = $svc->ownTransfer($fromId, (int)($data['to_account_id'] ?? 0), $amount, $data['description'] ?? '', $this->customerId);
        } else {
            $result = $svc->internalTransfer($fromId, $data['to_account_number'] ?? '', $amount, $data['description'] ?? '', $this->customerId);
        }
        if ($result['success']) Response::success($result, $result['message']);
        else Response::error($result['message'], 422);
    }

    /* ─── Beneficiaries ─── */
    public function beneficiaries(): void
    {
        $list = $this->db->query("SELECT * FROM beneficiaries WHERE customer_id={$this->customerId} ORDER BY is_favorite DESC, nickname")->fetchAll(PDO::FETCH_ASSOC);
        Response::success($list);
    }

    public function addBeneficiary(): void
    {
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $svc    = new TransferService($this->db);
        $result = $svc->saveBeneficiary($this->customerId, $data);
        if ($result['success']) Response::success($result, $result['message']);
        else Response::error($result['message'], 422);
    }

    public function deleteBeneficiary(int $id): void
    {
        $this->db->prepare("DELETE FROM beneficiaries WHERE id=:id AND customer_id=:cid")->execute([':id'=>$id,':cid'=>$this->customerId]);
        Response::success([], 'Beneficiary removed.');
    }

    /* ─── My loans ─── */
    public function myLoans(): void
    {
        $loans = $this->db->query(
            "SELECT l.*, a.account_number FROM loans l
             LEFT JOIN accounts a ON a.id=l.account_id
             WHERE l.customer_id={$this->customerId} ORDER BY l.created_at DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
        Response::success($loans);
    }

    /* ─── My cards ─── */
    public function myCards(): void
    {
        $cards = $this->db->query(
            "SELECT c.*, a.account_number, a.account_type FROM atm_cards c
             JOIN accounts a ON a.id=c.account_id
             WHERE a.customer_id={$this->customerId}"
        )->fetchAll(PDO::FETCH_ASSOC);
        Response::success($cards);
    }

    /* ─── KYC document upload ─── */
    public function uploadDocument(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { Response::error('POST required.', 405); return; }
        $kycSvc = new KYCService($this->db);
        $docType = $_POST['doc_type'] ?? 'Other';
        if (empty($_FILES['document'])) { Response::error('No file uploaded.', 422); return; }
        $result = $kycSvc->uploadDocument($this->customerId, $docType, $_FILES['document']);
        if ($result['success']) Response::success($result, $result['message']);
        else Response::error($result['message'], 422);
    }

    /* ─── Cheque book request ─── */
    public function requestChequeBook(): void
    {
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $accountId = (int)($data['account_id'] ?? 0);
        // Verify account ownership
        $account = $this->db->query("SELECT * FROM accounts WHERE id={$accountId} AND customer_id={$this->customerId} AND account_type='Current'")->fetch(PDO::FETCH_ASSOC);
        if (!$account) { Response::error('Current account not found.', 404); return; }

        $bookNo = 'CB' . date('Ymd') . str_pad((string)$accountId, 4, '0', STR_PAD_LEFT);
        $this->db->prepare("INSERT INTO cheque_books (account_id,customer_id,book_number,start_leaf,end_leaf,status) VALUES (:a,:c,:b,1,25,'Requested')")
            ->execute([':a'=>$accountId,':c'=>$this->customerId,':b'=>$bookNo]);
        Response::success(['book_number'=>$bookNo,'leaves'=>25], 'Cheque book requested. It will be ready within 3-5 business days.');
    }

    /* ─── Profile ─── */
    public function profile(): void
    {
        $customer = $this->db->query(
            "SELECT c.*, k.kyc_status AS kyc_level, k.fayda_id,
                    cu.username, cu.email AS portal_email, cu.last_login_at, cu.two_fa_enabled
             FROM customers c
             LEFT JOIN kyc_records k ON k.customer_id=c.id
             LEFT JOIN customer_users cu ON cu.customer_id=c.id
             WHERE c.id={$this->customerId}"
        )->fetch(PDO::FETCH_ASSOC);
        if (!$customer) { Response::error('Profile not found.', 404); return; }
        unset($customer['password']);
        Response::success($customer);
    }

    /* ─── Notifications ─── */
    public function notifications(): void
    {
        $notifs = $this->db->query(
            "SELECT * FROM notifications WHERE user_id={$this->customerUserId}
             ORDER BY created_at DESC LIMIT 50"
        )->fetchAll(PDO::FETCH_ASSOC);
        Response::success($notifs);
    }
}
