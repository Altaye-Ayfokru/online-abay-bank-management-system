<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class DashboardController
{
    /* GET /api/dashboard/stats */
    public function stats(): void
    {
        JwtHelper::requireAuth();
        $today = date('Y-m-d');
        $month = date('Y-m');

        $totalCustomers  = (int)Database::query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL AND status='Active'")->fetchColumn();
        $totalAccounts   = (int)Database::query("SELECT COUNT(*) FROM accounts WHERE status='Active'")->fetchColumn();
        $totalEmployees  = (int)Database::query("SELECT COUNT(*) FROM employees WHERE status='Active'")->fetchColumn();
        $totalBranches   = (int)Database::query("SELECT COUNT(*) FROM branches WHERE status='Active'")->fetchColumn();

        $todayDeposits   = (float)Database::query(
            "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Deposit' AND status='Completed' AND DATE(created_at)=?", [$today]
        )->fetchColumn();
        $todayWithdrawals = (float)Database::query(
            "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Withdrawal' AND status='Completed' AND DATE(created_at)=?", [$today]
        )->fetchColumn();
        $todayTxnCount   = (int)Database::query(
            "SELECT COUNT(*) FROM transactions WHERE DATE(created_at)=?", [$today]
        )->fetchColumn();

        $activeLoans     = (int)Database::query("SELECT COUNT(*) FROM loans WHERE status='Active'")->fetchColumn();
        $pendingLoans    = (int)Database::query("SELECT COUNT(*) FROM loans WHERE status='Pending'")->fetchColumn();

        $monthRevenue    = (float)Database::query(
            "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type IN ('Deposit','Interest Credit') AND status='Completed' AND DATE_FORMAT(created_at,'%Y-%m')=?", [$month]
        )->fetchColumn();

        $attPresent      = (int)Database::query(
            "SELECT COUNT(*) FROM attendance WHERE date=? AND status='Present'", [$today]
        )->fetchColumn();
        $attTotal        = (int)Database::query(
            "SELECT COUNT(*) FROM attendance WHERE date=?", [$today]
        )->fetchColumn();

        Response::success([
            'customers'         => $totalCustomers,
            'accounts'          => $totalAccounts,
            'employees'         => $totalEmployees,
            'branches'          => $totalBranches,
            'today_deposits'    => $todayDeposits,
            'today_withdrawals' => $todayWithdrawals,
            'today_transactions'=> $todayTxnCount,
            'active_loans'      => $activeLoans,
            'pending_loans'     => $pendingLoans,
            'monthly_revenue'   => $monthRevenue,
            'attendance_present'=> $attPresent,
            'attendance_total'  => $attTotal,
            'attendance_rate'   => $attTotal > 0 ? round(($attPresent / $attTotal) * 100, 1) : 0,
        ]);
    }

    /* GET /api/dashboard/charts */
    public function charts(): void
    {
        JwtHelper::requireAuth();
        $months = [];
        $deposits = []; $withdrawals = [];
        for ($i = 11; $i >= 0; $i--) {
            $m = date('Y-m', strtotime("-{$i} months"));
            $months[]     = date('M Y', strtotime("-{$i} months"));
            $deposits[]   = (float)Database::query(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Deposit' AND status='Completed' AND DATE_FORMAT(created_at,'%Y-%m')=?", [$m]
            )->fetchColumn();
            $withdrawals[] = (float)Database::query(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Withdrawal' AND status='Completed' AND DATE_FORMAT(created_at,'%Y-%m')=?", [$m]
            )->fetchColumn();
        }
        Response::success(['labels' => $months, 'deposits' => $deposits, 'withdrawals' => $withdrawals]);
    }

    /* GET /api/dashboard/activities */
    public function recentActivities(): void
    {
        JwtHelper::requireAuth();
        $activities = Database::query(
            "SELECT al.event_type, al.description, al.created_at, CONCAT(u.username) AS user
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id=u.id
             ORDER BY al.created_at DESC LIMIT 20"
        )->fetchAll();
        Response::success($activities);
    }
}
