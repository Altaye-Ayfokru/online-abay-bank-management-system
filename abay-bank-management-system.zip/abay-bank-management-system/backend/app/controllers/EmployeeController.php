<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class EmployeeController
{
    /* GET /api/employees */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page']    ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE e.status != 'Terminated'";
        $params  = [];

        if (!empty($_GET['department_id'])) { $where .= " AND e.department_id=?"; $params[] = (int)$_GET['department_id']; }
        if (!empty($_GET['branch_id']))     { $where .= " AND e.branch_id=?";     $params[] = (int)$_GET['branch_id']; }
        if (!empty($_GET['search'])) {
            $like = "%{$_GET['search']}%";
            $where .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.email LIKE ? OR e.employee_number LIKE ?)";
            $params = array_merge($params, [$like, $like, $like, $like]);
        }

        $total = (int)Database::query("SELECT COUNT(*) FROM employees e {$where}", $params)->fetchColumn();
        $sql   = "SELECT e.*, d.name AS department_name, b.name AS branch_name
                  FROM employees e
                  LEFT JOIN departments d ON e.department_id=d.id
                  LEFT JOIN branches b    ON e.branch_id=b.id
                  {$where} ORDER BY e.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;

        Response::paginated(Database::query($sql, $params)->fetchAll(), $total, $page, $perPage);
    }

    /* POST /api/employees */
    public function store(): void
    {
        JwtHelper::requireRole(['Admin', 'HR Officer']);
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'first_name'    => 'required|min:2',
            'last_name'     => 'required|min:2',
            'email'         => 'required|email',
            'phone'         => 'required|phone',
            'national_id'   => 'required|min:6',
            'branch_id'     => 'required|integer',
            'position'      => 'required|min:3',
            'basic_salary'  => 'required|numeric',
            'join_date'     => 'required|date',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        Database::query(
            "INSERT INTO employees (first_name, last_name, email, phone, national_id, department_id, branch_id,
             position, employment_type, basic_salary, transport_allow, housing_allow, join_date, status, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [
                $data['first_name'], $data['last_name'], $data['email'], $data['phone'],
                $data['national_id'], (int)($data['department_id'] ?? 0), (int)$data['branch_id'],
                $data['position'], $data['employment_type'] ?? 'Permanent',
                (float)$data['basic_salary'],
                (float)($data['transport_allow'] ?? 0), (float)($data['housing_allow'] ?? 0),
                $data['join_date'], 'Active',
            ]
        );
        Response::success(['employee_id' => (int)Database::lastInsertId()], 'Employee added successfully.', 201);
    }

    /* GET /api/employees/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $emp = Database::query(
            "SELECT e.*, d.name AS department_name, b.name AS branch_name
             FROM employees e
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches b    ON e.branch_id=b.id
             WHERE e.id=?", [$id]
        )->fetch();
        if (!$emp) { Response::error('Employee not found.', 404); return; }
        $emp['recent_attendance'] = Database::query(
            "SELECT * FROM attendance WHERE employee_id=? ORDER BY date DESC LIMIT 30", [$id]
        )->fetchAll();
        Response::success($emp);
    }

    /* PUT /api/employees/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'HR Officer']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE employees SET first_name=?, last_name=?, phone=?, position=?, basic_salary=?,
             department_id=?, branch_id=?, updated_at=NOW() WHERE id=?",
            [
                $data['first_name'], $data['last_name'], $data['phone'], $data['position'],
                (float)$data['basic_salary'], (int)($data['department_id'] ?? 0),
                (int)$data['branch_id'], $id,
            ]
        );
        Response::success(null, 'Employee updated successfully.');
    }

    /* DELETE /api/employees/{id} — soft terminate */
    public function destroy(int $id): void
    {
        JwtHelper::requireRole(['Admin']);
        Database::query(
            "UPDATE employees SET status='Terminated', terminate_date=CURDATE(), updated_at=NOW() WHERE id=?", [$id]
        );
        Response::success(null, 'Employee terminated.');
    }
}
