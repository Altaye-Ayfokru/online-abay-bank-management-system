<?php

/**
 * HomeController — Public endpoints for home page (no auth required)
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;

class HomeController
{
  private ?\PDO $db;

  public function __construct()
  {
    try {
      $this->db = Database::getInstance()->getConnection();
    } catch (\Throwable $e) {
      $this->db = null; // DB offline — return static fallback data
    }
  }

  /**
   * GET /api/health
   */
  public function health(): void
  {
    Response::success([
      'version' => '1.0.0',
      'time'    => date('Y-m-d H:i:s'),
      'php'     => PHP_VERSION,
      'db'      => $this->db !== null ? 'connected' : 'offline',
    ], 'Abay Bank API is running.');
  }

  /**
   * GET /api/home/stats
   * Returns public statistics for the home page (no auth needed).
   */
  public function stats(): void
  {
    // Static fallback values (shown when DB is offline)
    $data = [
      'customers'        => 2000000,
      'branches'         => 350,
      'atms'             => 500,
      'years'            => 15,
      'employees'        => 5000,
      'total_assets_etb' => 45000000000,   // ETB 45 billion
      'loans_approved'   => 12000,
      'branches_list'    => $this->staticBranches(),
    ];

    if ($this->db !== null) {
      try {
        // Customers
        $row = $this->db->query("SELECT COUNT(*) AS cnt FROM customers WHERE status='Active'")->fetch(\PDO::FETCH_ASSOC);
        if (!empty($row['cnt'])) $data['customers'] = (int)$row['cnt'];

        // Branches
        $row = $this->db->query("SELECT COUNT(*) AS cnt FROM branches WHERE status='Active'")->fetch(\PDO::FETCH_ASSOC);
        if (!empty($row['cnt'])) $data['branches'] = (int)$row['cnt'];

        // Employees
        $row = $this->db->query("SELECT COUNT(*) AS cnt FROM employees WHERE status='Active'")->fetch(\PDO::FETCH_ASSOC);
        if (!empty($row['cnt'])) $data['employees'] = (int)$row['cnt'];

        // Total assets (sum of all account balances)
        $row = $this->db->query("SELECT COALESCE(SUM(balance),0) AS total FROM accounts WHERE status='Active'")->fetch(\PDO::FETCH_ASSOC);
        if (!empty($row['total'])) $data['total_assets_etb'] = (float)$row['total'];

        // Active loans
        $row = $this->db->query("SELECT COUNT(*) AS cnt FROM loans WHERE status IN ('Active','Disbursed')")->fetch(\PDO::FETCH_ASSOC);
        if (!empty($row['cnt'])) $data['loans_approved'] = (int)$row['cnt'];

        // Live branch list
        $branches = $this->db->query(
          "SELECT branch_name, city, address, phone FROM branches WHERE status='Active' ORDER BY branch_name LIMIT 20"
        )->fetchAll(\PDO::FETCH_ASSOC);
        if (!empty($branches)) $data['branches_list'] = $branches;
      } catch (\Throwable $e) {
        // DB error — keep static fallback, don't expose error message
      }
    }

    Response::success($data, 'Home stats loaded successfully.');
  }

  private function staticBranches(): array
  {
    return [
      ['branch_name' => 'Addis Ababa Main Branch',  'addr' => 'Bole Road, Addis Ababa — Mon–Fri 8AM–5PM'],
      ['branch_name' => 'Bole Sub-City Branch',     'addr' => 'Bole Sub City, Woreda 03, Addis Ababa'],
      ['branch_name' => 'Kirkos Branch',            'addr' => 'Kirkos Sub City, Woreda 02, Addis Ababa'],
      ['branch_name' => 'Arada Branch',             'addr' => 'Arada Sub City, Woreda 07, Addis Ababa'],
      ['branch_name' => 'Bahir Dar Branch',         'addr' => 'Kebele 07, Bahir Dar, Amhara Region'],
      ['branch_name' => 'Hawassa Branch',           'addr' => 'Piazza Area, Hawassa, SNNPR'],
      ['branch_name' => 'Dire Dawa Branch',         'addr' => 'Kezira, Dire Dawa'],
      ['branch_name' => 'Mekelle Branch',           'addr' => 'Ayder Area, Mekelle, Tigray'],
      ['branch_name' => 'Jimma Branch',             'addr' => 'Jimma Town Centre, Oromia Region'],
    ];
  }
}
