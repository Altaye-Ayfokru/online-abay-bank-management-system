<?php
declare(strict_types=1);
namespace App\Controllers;
use App\Config\Database;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use PDO;

class InventoryController {
    private PDO $db;
    public function __construct() {
        AuthMiddleware::handle();
        $this->db = Database::getInstance()->getConnection();
    }

    public function index(): void {
        $cat    = $_GET['category'] ?? null;
        $branch = $_GET['branch_id'] ?? null;
        $where  = '1=1';
        if ($cat)    $where .= " AND category='" . $this->db->quote($cat) . "'";
        if ($branch) $where .= " AND branch_id={$branch}";
        $rows = $this->db->query("SELECT i.*,b.branch_name FROM inventory i LEFT JOIN branches b ON b.id=i.branch_id WHERE {$where} ORDER BY i.name LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
        $summary = $this->db->query("SELECT category,COUNT(*) AS count,SUM(total_cost) AS value FROM inventory GROUP BY category")->fetchAll(PDO::FETCH_ASSOC);
        Response::success(['items'=>$rows,'summary'=>$summary,'total'=>count($rows)]);
    }

    public function store(): void {
        $d = json_decode(file_get_contents('php://input'),true)??[];
        $num = 'AST-'.date('Y').'-'.str_pad((string)rand(1,9999),4,'0',STR_PAD_LEFT);
        $s = $this->db->prepare("INSERT INTO inventory (asset_number,name,category,brand,model,serial_number,quantity,unit_cost,total_cost,location,branch_id,purchase_date,warranty_until,condition,status,notes) VALUES (:n,:nm,:c,:br,:mo,:sn,:q,:uc,:tc,:loc,:bid,:pd,:wu,:con,:st,:no)");
        $s->execute([':n'=>$num,':nm'=>$d['name'],':c'=>$d['category'],':br'=>$d['brand']??null,':mo'=>$d['model']??null,':sn'=>$d['serial_number']??null,':q'=>$d['quantity']??1,':uc'=>$d['unit_cost']??0,':tc'=>($d['unit_cost']??0)*($d['quantity']??1),':loc'=>$d['location']??null,':bid'=>$d['branch_id']??null,':pd'=>$d['purchase_date']??null,':wu'=>$d['warranty_until']??null,':con'=>$d['condition']??'New',':st'=>$d['status']??'Available',':no'=>$d['notes']??null]);
        Response::success(['id'=>(int)$this->db->lastInsertId(),'asset_number'=>$num],'Asset added.');
    }

    public function show(int $id): void {
        $row = $this->db->query("SELECT i.*,b.branch_name FROM inventory i LEFT JOIN branches b ON b.id=i.branch_id WHERE i.id={$id}")->fetch(PDO::FETCH_ASSOC);
        if (!$row) { Response::error('Asset not found.',404); return; }
        Response::success($row);
    }

    public function update(int $id): void {
        $d = json_decode(file_get_contents('php://input'),true)??[];
        $this->db->prepare("UPDATE inventory SET name=:n,category=:c,condition=:con,status=:s,location=:l,notes=:no,updated_at=NOW() WHERE id=:id")->execute([':n'=>$d['name'],':c'=>$d['category'],':con'=>$d['condition']??'Good',':s'=>$d['status']??'Available',':l'=>$d['location']??null,':no'=>$d['notes']??null,':id'=>$id]);
        Response::success([],'Asset updated.');
    }

    public function destroy(int $id): void {
        $this->db->prepare("UPDATE inventory SET status='Disposed' WHERE id=:id")->execute([':id'=>$id]);
        Response::success([],'Asset disposed.');
    }
}
