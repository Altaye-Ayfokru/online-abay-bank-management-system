<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class LeaveController
{
    /* GET /api/leaves */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE 1=1"; $params = [];

        if (!empty($_GET['status']))      { $where .= " AND lr.status=?";      $params[] = $_GET['status']; }
        if (!empty($_GET['employee_id'])) { $where .= " AND lr.employee_id=?"; $params[] = (int)$_GET['employee_id']; }

        $total = (int)Database::query("SELECT COUNT(*) FROM leave_requests lr {$where}", $params)->fetchColumn();
        $sql   = "SELECT lr.*, CONCAT(e.first_name,' ',e.last_name) AS employee_name,
                         d.name AS department_name
                  FROM leave_requests lr
                  LEFT JOIN employees   e ON lr.employee_id=e.id
                  LEFT JOIN departments d ON e.department_id=d.id
                  {$where} ORDER BY lr.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;
        Response::paginated(Database::query($sql, $params)->fetchAll(), $total, $page, $perPage);
    }

    /* POST /api/leaves */
    public function apply(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'employee_id' => 'required|integer',
            'leave_type'  => 'required|in:Annual,Sick,Maternity,Paternity,Emergency,Unpaid,Compassionate',
            'from_date'   => 'required|date',
            'to_date'     => 'required|date',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        if (strtotime($data['to_date']) < strtotime($data['from_date'])) {
            Response::error('End date must be after start date.', 400); return;
        }

        Database::query(
            "INSERT INTO leave_requests (employee_id, leave_type, from_date, to_date, reason, status, created_at)
             VALUES (?,?,?,?,?,?,NOW())",
            [
                (int)$data['employee_id'], $data['leave_type'],
                $data['from_date'], $data['to_date'],
                $data['reason'] ?? null, 'Pending',
            ]
        );
        Response::success(['leave_id' => (int)Database::lastInsertId()], 'Leave request submitted.', 201);
    }

    /* PUT /api/leaves/{id}/approve */
    public function approve(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager', 'HR Officer']);
        $leave = Database::query("SELECT * FROM leave_requests WHERE id=? AND status='Pending'", [$id])->fetch();
        if (!$leave) { Response::error('Leave request not found or already processed.', 404); return; }

        Database::beginTransaction();
        try {
            Database::query(
                "UPDATE leave_requests SET status='Approved', approved_by=?, approved_at=NOW() WHERE id=?",
                [JwtHelper::getUserId(), $id]
            );
            /* Mark attendance as Leave for the days */
            $from = new \DateTime($leave['from_date']);
            $to   = new \DateTime($leave['to_date']);
            $interval = new \DateInterval('P1D');
            $range = new \DatePeriod($from, $interval, $to->modify('+1 day'));
            foreach ($range as $date) {
                $d = $date->format('Y-m-d');
                $exists = Database::query(
                    "SELECT id FROM attendance WHERE employee_id=? AND date=?",
                    [(int)$leave['employee_id'], $d]
                )->fetch();
                if (!$exists) {
                    Database::query(
                        "INSERT INTO attendance (employee_id, date, status, note, created_at) VALUES (?,?,?,?,NOW())",
                        [(int)$leave['employee_id'], $d, 'Leave', $leave['leave_type'] . ' leave']
                    );
                } else {
                    Database::query(
                        "UPDATE attendance SET status='Leave', note=? WHERE id=?",
                        [$leave['leave_type'] . ' leave', $exists['id']]
                    );
                }
            }
            Database::commit();
            Response::success(null, 'Leave approved successfully.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Failed to approve leave.', 500);
        }
    }

    /* PUT /api/leaves/{id}/reject */
    public function reject(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager', 'HR Officer']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE leave_requests SET status='Rejected', reject_reason=?, approved_by=?, approved_at=NOW() WHERE id=?",
            [$data['reason'] ?? 'Does not meet criteria', JwtHelper::getUserId(), $id]
        );
        Response::success(null, 'Leave request rejected.');
    }
}
