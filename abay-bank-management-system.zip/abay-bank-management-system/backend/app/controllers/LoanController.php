<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class LoanController
{
    /* GET /api/loans */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page']    ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE 1=1";
        $params  = [];

        if (!empty($_GET['status']))      { $where .= " AND l.status=?";        $params[] = $_GET['status']; }
        if (!empty($_GET['type']))        { $where .= " AND l.loan_type=?";     $params[] = $_GET['type']; }
        if (!empty($_GET['customer_id'])) { $where .= " AND l.customer_id=?";   $params[] = (int)$_GET['customer_id']; }

        $total = (int)Database::query("SELECT COUNT(*) FROM loans l {$where}", $params)->fetchColumn();
        $sql = "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name,
                       a.account_number, b.name AS branch_name
                FROM loans l
                LEFT JOIN customers c ON l.customer_id=c.id
                LEFT JOIN accounts a  ON l.account_id=a.id
                LEFT JOIN branches b  ON l.branch_id=b.id
                {$where} ORDER BY l.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;

        Response::paginated(Database::query($sql, $params)->fetchAll(), $total, $page, $perPage);
    }

    /* POST /api/loans */
    public function apply(): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'customer_id' => 'required|integer',
            'account_id'  => 'required|integer',
            'loan_type'   => 'required',
            'amount'      => 'required|numeric|min_val:1000',
            'interest_rate' => 'required|numeric',
            'term_months' => 'required|integer',
            'purpose'     => 'required|min:20',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $emi = $this->calcEmi((float)$data['amount'], (float)$data['interest_rate'], (int)$data['term_months']);

        Database::query(
            "INSERT INTO loans (customer_id, account_id, branch_id, loan_type, amount, interest_rate, term_months, emi, purpose,
             collateral_type, collateral_value, outstanding, status, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [
                (int)$data['customer_id'], (int)$data['account_id'],
                (int)($data['branch_id'] ?? JwtHelper::fromRequest()?->branch ?? 1),
                $data['loan_type'], (float)$data['amount'], (float)$data['interest_rate'],
                (int)$data['term_months'], $emi, $data['purpose'],
                $data['collateral_type'] ?? null, (float)($data['collateral_value'] ?? 0),
                (float)$data['amount'], 'Pending', JwtHelper::getUserId(),
            ]
        );

        $loanId = (int)Database::lastInsertId();
        $this->generateSchedule($loanId, (float)$data['amount'], (float)$data['interest_rate'], (int)$data['term_months'], $emi);

        Response::success(['loan_id' => $loanId], 'Loan application submitted successfully.', 201);
    }

    /* GET /api/loans/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $loan = Database::query(
            "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, a.account_number, b.name AS branch_name
             FROM loans l
             LEFT JOIN customers c ON l.customer_id=c.id
             LEFT JOIN accounts a  ON l.account_id=a.id
             LEFT JOIN branches b  ON l.branch_id=b.id
             WHERE l.id=?", [$id]
        )->fetch();
        if (!$loan) { Response::error('Loan not found.', 404); return; }
        $loan['schedule'] = Database::query("SELECT * FROM loan_schedules WHERE loan_id=? ORDER BY installment_no", [$id])->fetchAll();
        Response::success($loan);
    }

    /* PUT /api/loans/{id}/approve */
    public function approve(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager', 'Loan Officer']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $loan = Database::query("SELECT * FROM loans WHERE id=? AND status='Pending'", [$id])->fetch();
        if (!$loan) { Response::error('Loan not found or not pending.', 404); return; }

        $approvedAmount = (float)($data['approved_amount'] ?? $loan['amount']);
        Database::beginTransaction();
        try {
            Database::query(
                "UPDATE loans SET status='Approved', approved_amount=?, approved_by=?, approved_at=NOW(), updated_at=NOW() WHERE id=?",
                [$approvedAmount, JwtHelper::getUserId(), $id]
            );
            Database::commit();
            Response::success(null, 'Loan approved successfully.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Approval failed.', 500);
        }
    }

    /* PUT /api/loans/{id}/reject */
    public function reject(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager', 'Loan Officer']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE loans SET status='Rejected', rejection_reason=?, approved_by=?, approved_at=NOW(), updated_at=NOW() WHERE id=? AND status='Pending'",
            [$data['reason'] ?? 'Does not meet criteria', JwtHelper::getUserId(), $id]
        );
        Response::success(null, 'Loan rejected.');
    }

    /* POST /api/loans/{id}/payment */
    public function payment(int $id): void
    {
        JwtHelper::requireAuth();
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, ['amount' => 'required|numeric|min_val:1']);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $loan = Database::query("SELECT * FROM loans WHERE id=? AND status='Active'", [$id])->fetch();
        if (!$loan) { Response::error('Loan not found or not active.', 404); return; }

        $amount = (float)$data['amount'];
        Database::beginTransaction();
        try {
            Database::query(
                "UPDATE loans SET outstanding=outstanding-?, paid_amount=paid_amount+?, updated_at=NOW() WHERE id=?",
                [$amount, $amount, $id]
            );
            /* Mark schedule installment paid */
            $due = Database::query(
                "SELECT id FROM loan_schedules WHERE loan_id=? AND status IN ('Due','Upcoming') ORDER BY installment_no LIMIT 1",
                [$id]
            )->fetch();
            if ($due) {
                Database::query(
                    "UPDATE loan_schedules SET status='Paid', paid_date=CURDATE(), paid_amount=? WHERE id=?",
                    [$amount, $due['id']]
                );
            }
            /* Close loan if fully paid */
            $updated = Database::query("SELECT outstanding FROM loans WHERE id=?", [$id])->fetch();
            if ((float)$updated['outstanding'] <= 0) {
                Database::query("UPDATE loans SET status='Completed', actual_close_date=CURDATE() WHERE id=?", [$id]);
            }
            Database::commit();
            Response::success(['outstanding' => $updated['outstanding'] ?? 0], 'Payment recorded successfully.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Payment failed.', 500);
        }
    }

    /* GET /api/loans/{id}/schedule */
    public function schedule(int $id): void
    {
        JwtHelper::requireAuth();
        $schedule = Database::query("SELECT * FROM loan_schedules WHERE loan_id=? ORDER BY installment_no", [$id])->fetchAll();
        Response::success($schedule);
    }

    /* POST /api/loans/calculate-emi */
    public function calculateEmi(): void
    {
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $p = (float)($data['principal'] ?? 0);
        $r = (float)($data['rate'] ?? 0);
        $n = (int)($data['months'] ?? 0);
        if (!$p || !$r || !$n) { Response::error('Principal, rate, and months are required.', 400); return; }
        $emi      = $this->calcEmi($p, $r, $n);
        $total    = $emi * $n;
        $interest = $total - $p;
        Response::success(['emi' => round($emi, 2), 'total' => round($total, 2), 'interest' => round($interest, 2)]);
    }

    private function calcEmi(float $p, float $ratePercent, int $n): float
    {
        $r = $ratePercent / 100 / 12;
        if ($r == 0) return $p / $n;
        return $p * $r * pow(1 + $r, $n) / (pow(1 + $r, $n) - 1);
    }

    private function generateSchedule(int $loanId, float $p, float $rate, int $n, float $emi): void
    {
        $r   = $rate / 100 / 12;
        $bal = $p;
        for ($i = 1; $i <= $n; $i++) {
            $interest  = round($bal * $r, 2);
            $principal = round($emi - $interest, 2);
            $bal       = round($bal - $principal, 2);
            $dueDate   = date('Y-m-d', strtotime("+{$i} months"));
            Database::query(
                "INSERT INTO loan_schedules (loan_id, installment_no, due_date, emi_amount, principal, interest, balance, status)
                 VALUES (?,?,?,?,?,?,?,?)",
                [$loanId, $i, $dueDate, round($emi, 2), $principal, $interest, max(0, $bal), $i === 1 ? 'Due' : 'Upcoming']
            );
        }
    }
}
