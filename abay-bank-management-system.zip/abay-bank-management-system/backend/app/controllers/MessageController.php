<?php
declare(strict_types=1);
namespace App\Controllers;
use App\Config\Database;
use App\Helpers\Response;
use App\Middleware\AuthMiddleware;
use PDO;

class MessageController {
    private PDO $db;
    private int $userId;
    public function __construct() {
        $payload = AuthMiddleware::handle();
        $this->db = Database::getInstance()->getConnection();
        $this->userId = (int)($payload['user_id'] ?? 0);
    }

    public function index(): void {
        $box  = $_GET['box'] ?? 'inbox';
        $col  = $box === 'sent' ? 'from_user_id' : 'to_user_id';
        $rows = $this->db->query("SELECT m.*,u.username AS sender_name FROM messages m JOIN users u ON u.id=m.from_user_id WHERE m.{$col}={$this->userId} ORDER BY m.created_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        $unread = (int)$this->db->query("SELECT COUNT(*) FROM messages WHERE to_user_id={$this->userId} AND is_read=0")->fetchColumn();
        Response::success(['messages'=>$rows,'unread'=>$unread]);
    }

    public function send(): void {
        $d = json_decode(file_get_contents('php://input'),true)??[];
        if (empty($d['to_user_id'])||empty($d['subject'])||empty($d['body'])) { Response::error('Required: to_user_id, subject, body.',422); return; }
        $s = $this->db->prepare("INSERT INTO messages (from_user_id,to_user_id,subject,body,parent_id) VALUES (:f,:t,:s,:b,:p)");
        $s->execute([':f'=>$this->userId,':t'=>$d['to_user_id'],':s'=>$d['subject'],':b'=>$d['body'],':p'=>$d['parent_id']??null]);
        Response::success(['id'=>(int)$this->db->lastInsertId()],'Message sent.');
    }

    public function show(int $id): void {
        $msg = $this->db->query("SELECT m.*,u.username AS sender FROM messages m JOIN users u ON u.id=m.from_user_id WHERE m.id={$id} AND (m.to_user_id={$this->userId} OR m.from_user_id={$this->userId})")->fetch(PDO::FETCH_ASSOC);
        if (!$msg) { Response::error('Message not found.',404); return; }
        if ($msg['to_user_id'] == $this->userId && !$msg['is_read']) {
            $this->db->prepare("UPDATE messages SET is_read=1,read_at=NOW() WHERE id=:id")->execute([':id'=>$id]);
        }
        Response::success($msg);
    }

    public function markRead(int $id): void {
        $this->db->prepare("UPDATE messages SET is_read=1,read_at=NOW() WHERE id=:id AND to_user_id=:uid")->execute([':id'=>$id,':uid'=>$this->userId]);
        Response::success([],'Marked as read.');
    }
}
