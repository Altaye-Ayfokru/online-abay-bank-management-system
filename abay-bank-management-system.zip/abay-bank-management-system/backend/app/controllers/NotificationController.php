<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class NotificationController
{
    /* GET /api/notifications */
    public function index(): void
    {
        $userId = JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(50, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;

        $total = (int)Database::query(
            "SELECT COUNT(*) FROM notifications WHERE user_id=? OR user_id IS NULL", [$userId]
        )->fetchColumn();

        $rows = Database::query(
            "SELECT * FROM notifications WHERE user_id=? OR user_id IS NULL
             ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [$userId, $perPage, $offset]
        )->fetchAll();

        $unread = (int)Database::query(
            "SELECT COUNT(*) FROM notifications WHERE (user_id=? OR user_id IS NULL) AND is_read=0", [$userId]
        )->fetchColumn();

        Response::paginated($rows, $total, $page, $perPage);
    }

    /* PUT /api/notifications/{id}/read */
    public function markRead(int $id): void
    {
        $userId = JwtHelper::requireAuth();
        Database::query(
            "UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=? AND (user_id=? OR user_id IS NULL)",
            [$id, $userId]
        );
        Response::success(null, 'Notification marked as read.');
    }

    /* PUT /api/notifications/read-all */
    public function markAllRead(): void
    {
        $userId = JwtHelper::requireAuth();
        Database::query(
            "UPDATE notifications SET is_read=1, read_at=NOW() WHERE (user_id=? OR user_id IS NULL) AND is_read=0",
            [$userId]
        );
        Response::success(null, 'All notifications marked as read.');
    }

    /* POST /api/notifications/send */
    public function send(): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($data['title']) || empty($data['body'])) {
            Response::error('Title and body are required.', 400); return;
        }

        /* Send to specific user or broadcast (user_id = NULL means all) */
        $userId = isset($data['user_id']) ? (int)$data['user_id'] : null;
        Database::query(
            "INSERT INTO notifications (user_id, type, title, body, channel, priority, sent_by, created_at)
             VALUES (?,?,?,?,?,?,?,NOW())",
            [
                $userId, $data['type'] ?? 'system', $data['title'], $data['body'],
                $data['channel'] ?? 'In-App', $data['priority'] ?? 'Normal',
                JwtHelper::getUserId(),
            ]
        );
        Response::success(null, 'Notification sent successfully.', 201);
    }
}
