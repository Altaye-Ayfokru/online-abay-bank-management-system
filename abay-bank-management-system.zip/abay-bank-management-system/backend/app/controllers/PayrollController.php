<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class PayrollController
{
    /* GET /api/payroll */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $period = $_GET['period'] ?? date('Y-m');
        $rows   = Database::query(
            "SELECT p.*, CONCAT(e.first_name,' ',e.last_name) AS employee_name,
                    d.name AS department_name, b.name AS branch_name
             FROM payroll p
             LEFT JOIN employees e ON p.employee_id=e.id
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches b ON e.branch_id=b.id
             WHERE p.pay_period=?
             ORDER BY e.first_name", [$period]
        )->fetchAll();
        Response::success($rows);
    }

    /* POST /api/payroll/process */
    public function process(): void
    {
        JwtHelper::requireRole(['Admin', 'HR Officer']);
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $period = $data['period'] ?? date('Y-m');
        $empIds = $data['employee_ids'] ?? [];

        $employees = $empIds
            ? Database::query("SELECT * FROM employees WHERE id IN (" . implode(',', array_fill(0, count($empIds), '?')) . ") AND status='Active'", array_map('intval', $empIds))->fetchAll()
            : Database::query("SELECT * FROM employees WHERE status='Active'")->fetchAll();

        $processed = 0;
        foreach ($employees as $emp) {
            $gross = (float)$emp['basic_salary'] + (float)$emp['transport_allow'] + (float)$emp['housing_allow'] + (float)$emp['other_allowances'];
            $pension = round($gross * 0.07, 2);
            $tax     = round($this->calcTax($gross), 2);
            $total_deductions = $pension + $tax;
            $net = round($gross - $total_deductions, 2);

            $exists = Database::query("SELECT id FROM payroll WHERE employee_id=? AND pay_period=?", [(int)$emp['id'], $period])->fetch();
            if ($exists) {
                Database::query(
                    "UPDATE payroll SET gross_salary=?, pension=?, income_tax=?, total_deductions=?, net_salary=?, status='Processed', processed_by=?, updated_at=NOW() WHERE id=?",
                    [$gross, $pension, $tax, $total_deductions, $net, JwtHelper::getUserId(), $exists['id']]
                );
            } else {
                Database::query(
                    "INSERT INTO payroll (employee_id, pay_period, basic_salary, transport_allow, housing_allow, other_allowances,
                     gross_salary, pension, income_tax, total_deductions, net_salary, status, processed_by, created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
                    [$emp['id'], $period, $emp['basic_salary'], $emp['transport_allow'], $emp['housing_allow'],
                     $emp['other_allowances'], $gross, $pension, $tax, $total_deductions, $net,
                     'Processed', JwtHelper::getUserId()]
                );
            }
            $processed++;
        }
        Response::success(['processed' => $processed, 'period' => $period], "Payroll processed for {$processed} employees.");
    }

    /* GET /api/payroll/{id}/slip */
    public function payslip(int $id): void
    {
        JwtHelper::requireAuth();
        $slip = Database::query(
            "SELECT p.*, CONCAT(e.first_name,' ',e.last_name) AS employee_name,
                    e.employee_number, d.name AS department_name, b.name AS branch_name
             FROM payroll p
             LEFT JOIN employees e ON p.employee_id=e.id
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches b ON e.branch_id=b.id
             WHERE p.id=?", [$id]
        )->fetch();
        if (!$slip) { Response::error('Payslip not found.', 404); return; }
        Response::success($slip);
    }

    private function calcTax(float $gross): float
    {
        if ($gross <= 600)   return 0;
        if ($gross <= 1650)  return ($gross - 600) * 0.10;
        if ($gross <= 3200)  return 105 + ($gross - 1650) * 0.15;
        if ($gross <= 5250)  return 337.5 + ($gross - 3200) * 0.20;
        if ($gross <= 7800)  return 747.5 + ($gross - 5250) * 0.25;
        if ($gross <= 10900) return 1385 + ($gross - 7800) * 0.30;
        return 2315 + ($gross - 10900) * 0.35;
    }
}
