<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class ReportController
{
    /* GET /api/reports/financial */
    public function financial(): void
    {
        JwtHelper::requireRole(['Admin', 'Manager', 'Auditor']);
        $from  = $_GET['from'] ?? date('Y-01-01');
        $to    = $_GET['to']   ?? date('Y-m-d');
        $month = date('Y-m');

        $deposits    = (float)Database::query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Deposit' AND status='Completed' AND DATE(created_at) BETWEEN ? AND ?", [$from,$to])->fetchColumn();
        $withdrawals = (float)Database::query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Withdrawal' AND status='Completed' AND DATE(created_at) BETWEEN ? AND ?", [$from,$to])->fetchColumn();
        $transfers   = (float)Database::query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Transfer Out' AND status='Completed' AND DATE(created_at) BETWEEN ? AND ?", [$from,$to])->fetchColumn();
        $loansDisbursed = (float)Database::query("SELECT COALESCE(SUM(approved_amount),0) FROM loans WHERE status IN ('Active','Completed') AND disbursed_date BETWEEN ? AND ?", [$from,$to])->fetchColumn();
        $loansCollected = (float)Database::query("SELECT COALESCE(SUM(paid_amount),0) FROM loans WHERE disbursed_date BETWEEN ? AND ?", [$from,$to])->fetchColumn();
        $netCashFlow = $deposits - $withdrawals;

        /* Monthly breakdown for chart */
        $monthly = [];
        $d = new \DateTime($from);
        $end = new \DateTime($to);
        while ($d <= $end) {
            $m = $d->format('Y-m');
            $monthly[] = [
                'month'      => $d->format('M Y'),
                'deposits'   => (float)Database::query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Deposit' AND status='Completed' AND DATE_FORMAT(created_at,'%Y-%m')=?", [$m])->fetchColumn(),
                'withdrawals'=> (float)Database::query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='Withdrawal' AND status='Completed' AND DATE_FORMAT(created_at,'%Y-%m')=?", [$m])->fetchColumn(),
            ];
            $d->modify('+1 month');
        }

        Response::success([
            'summary'        => compact('deposits','withdrawals','transfers','loansDisbursed','loansCollected','netCashFlow'),
            'monthly'        => $monthly,
            'period'         => ['from' => $from, 'to' => $to],
        ]);
    }

    /* GET /api/reports/customers */
    public function customers(): void
    {
        JwtHelper::requireAuth();
        $total    = (int)Database::query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL")->fetchColumn();
        $active   = (int)Database::query("SELECT COUNT(*) FROM customers WHERE status='Active' AND deleted_at IS NULL")->fetchColumn();
        $newMonth = (int)Database::query("SELECT COUNT(*) FROM customers WHERE DATE_FORMAT(created_at,'%Y-%m')=?", [date('Y-m')])->fetchColumn();
        $byBranch = Database::query("SELECT b.name, COUNT(c.id) AS count FROM customers c LEFT JOIN branches b ON c.branch_id=b.id WHERE c.deleted_at IS NULL GROUP BY b.id ORDER BY count DESC")->fetchAll();
        Response::success(compact('total','active','newMonth','byBranch'));
    }

    /* GET /api/reports/loans */
    public function loans(): void
    {
        JwtHelper::requireAuth();
        $portfolio   = (float)Database::query("SELECT COALESCE(SUM(outstanding),0) FROM loans WHERE status='Active'")->fetchColumn();
        $active      = (int)Database::query("SELECT COUNT(*) FROM loans WHERE status='Active'")->fetchColumn();
        $pending     = (int)Database::query("SELECT COUNT(*) FROM loans WHERE status='Pending'")->fetchColumn();
        $overdue     = (int)Database::query("SELECT COUNT(*) FROM loan_schedules WHERE status='Overdue'")->fetchColumn();
        $byType      = Database::query("SELECT loan_type, COUNT(*) AS count, SUM(amount) AS total FROM loans GROUP BY loan_type")->fetchAll();
        Response::success(compact('portfolio','active','pending','overdue','byType'));
    }

    /* GET /api/reports/transactions */
    public function transactions(): void
    {
        JwtHelper::requireAuth();
        $from = $_GET['from'] ?? date('Y-m-01');
        $to   = $_GET['to']   ?? date('Y-m-d');
        $rows = Database::query(
            "SELECT DATE(created_at) AS date, type, COUNT(*) AS count, SUM(amount) AS total
             FROM transactions WHERE DATE(created_at) BETWEEN ? AND ? AND status='Completed'
             GROUP BY DATE(created_at), type ORDER BY date DESC", [$from,$to]
        )->fetchAll();
        Response::success($rows);
    }

    /* GET /api/reports/attendance */
    public function attendance(): void
    {
        JwtHelper::requireAuth();
        $month = $_GET['month'] ?? date('Y-m');
        $rows  = Database::query(
            "SELECT DATE_FORMAT(date,'%Y-%m-%d') AS date,
                    SUM(status='Present') AS present, SUM(status='Absent') AS absent, SUM(status='Late') AS late
             FROM attendance WHERE DATE_FORMAT(date,'%Y-%m')=?
             GROUP BY date ORDER BY date", [$month]
        )->fetchAll();
        Response::success($rows);
    }

    /* GET /api/reports/branch */
    public function branch(): void
    {
        JwtHelper::requireAuth();
        $rows = Database::query(
            "SELECT b.name, b.code,
                    COUNT(DISTINCT c.id)  AS customers,
                    COUNT(DISTINCT e.id)  AS staff,
                    COALESCE(SUM(a.balance),0) AS total_balance
             FROM branches b
             LEFT JOIN customers c ON c.branch_id=b.id AND c.deleted_at IS NULL
             LEFT JOIN employees e ON e.branch_id=b.id AND e.status='Active'
             LEFT JOIN accounts  a ON a.branch_id=b.id AND a.status='Active'
             GROUP BY b.id ORDER BY total_balance DESC"
        )->fetchAll();
        Response::success($rows);
    }
}
