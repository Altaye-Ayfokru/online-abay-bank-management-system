<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class RoleController
{
    /* GET /api/roles */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $roles = Database::query(
            "SELECT r.*, COUNT(u.id) AS user_count FROM roles r
             LEFT JOIN users u ON u.role_id=r.id AND u.deleted_at IS NULL
             GROUP BY r.id ORDER BY r.id"
        )->fetchAll();
        Response::success($roles);
    }

    /* POST /api/roles */
    public function store(): void
    {
        JwtHelper::requireRole(['Admin']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($data['name'])) { Response::error('Role name required.', 400); return; }
        Database::query("INSERT INTO roles (name, description, created_at) VALUES (?,?,NOW())",
            [$data['name'], $data['description'] ?? null]);
        Response::success(['role_id' => (int)Database::lastInsertId()], 'Role created.', 201);
    }

    /* PUT /api/roles/{id}/permissions */
    public function updatePermissions(int $id): void
    {
        JwtHelper::requireRole(['Admin']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $perms = $data['permissions'] ?? [];

        Database::beginTransaction();
        try {
            Database::query("DELETE FROM permissions WHERE role_id=?", [$id]);
            foreach ($perms as $module => $actions) {
                foreach ($actions as $action => $granted) {
                    if ($granted) {
                        Database::query(
                            "INSERT IGNORE INTO permissions (role_id, module, action, created_at) VALUES (?,?,?,NOW())",
                            [$id, $module, $action]
                        );
                    }
                }
            }
            Database::commit();
            Response::success(null, 'Permissions updated successfully.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Failed to update permissions.', 500);
        }
    }
}
