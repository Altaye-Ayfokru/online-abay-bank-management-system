<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;

class SettingsController
{
    /* GET /api/settings */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $rows = Database::query("SELECT * FROM settings ORDER BY `group`, `key`")->fetchAll();
        /* Group by category */
        $grouped = [];
        foreach ($rows as $r) {
            $grouped[$r['group']][$r['key']] = [
                'value' => $this->cast($r['value'], $r['type']),
                'label' => $r['label'],
                'type'  => $r['type'],
            ];
        }
        Response::success($grouped);
    }

    /* PUT /api/settings */
    public function update(): void
    {
        JwtHelper::requireRole(['Admin']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        foreach ($data as $key => $value) {
            Database::query(
                "UPDATE settings SET value=?, updated_by=? WHERE `key`=?",
                [(string)$value, JwtHelper::getUserId(), $key]
            );
        }
        Response::success(null, 'Settings updated successfully.');
    }

    private function cast(mixed $value, string $type): mixed
    {
        return match($type) {
            'integer' => (int)$value,
            'decimal' => (float)$value,
            'boolean' => (bool)(int)$value,
            'json'    => json_decode($value ?? '{}', true),
            default   => $value,
        };
    }
}
