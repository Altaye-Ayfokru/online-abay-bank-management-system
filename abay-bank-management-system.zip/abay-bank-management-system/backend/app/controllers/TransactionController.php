<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;

class TransactionController
{
    /* GET /api/transactions */
    public function index(): void
    {
        JwtHelper::requireAuth();
        $page    = max(1, (int)($_GET['page']    ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset  = ($page - 1) * $perPage;
        $where   = "WHERE 1=1";
        $params  = [];

        if (!empty($_GET['account_id'])) { $where .= " AND t.account_id=?";  $params[] = (int)$_GET['account_id']; }
        if (!empty($_GET['type']))       { $where .= " AND t.type=?";         $params[] = $_GET['type']; }
        if (!empty($_GET['status']))     { $where .= " AND t.status=?";       $params[] = $_GET['status']; }
        if (!empty($_GET['from']))       { $where .= " AND DATE(t.created_at)>=?"; $params[] = $_GET['from']; }
        if (!empty($_GET['to']))         { $where .= " AND DATE(t.created_at)<=?"; $params[] = $_GET['to']; }

        $countSql = "SELECT COUNT(*) FROM transactions t {$where}";
        $total = (int)Database::query($countSql, $params)->fetchColumn();

        $sql = "SELECT t.*, a.account_number, CONCAT(c.first_name,' ',c.last_name) AS customer_name
                FROM transactions t
                LEFT JOIN accounts a ON t.account_id = a.id
                LEFT JOIN customers c ON a.customer_id = c.id
                {$where} ORDER BY t.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;
        $rows = Database::query($sql, $params)->fetchAll();

        Response::success([
            'data'        => $rows,
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ]);
    }

    /* POST /api/transactions/deposit */
    public function deposit(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'account_id' => 'required|integer',
            'amount'     => 'required|numeric|min:1',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $account = Database::query("SELECT * FROM accounts WHERE id=? AND status='Active'", [$data['account_id']])->fetch();
        if (!$account) { Response::error('Account not found or inactive.', 404); return; }

        Database::beginTransaction();
        try {
            $ref = $this->generateRef('DEP');
            $amount = (float)$data['amount'];

            Database::query(
                "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,NOW())",
                [$data['account_id'], $ref, 'Deposit', $amount, $account['balance'],
                 $account['balance'] + $amount, $data['description'] ?? 'Cash Deposit',
                 'Completed', JwtHelper::getUserId()]
            );
            Database::query("UPDATE accounts SET balance=balance+?, updated_at=NOW() WHERE id=?", [$amount, $data['account_id']]);
            Database::commit();

            Response::success(['reference' => $ref, 'new_balance' => $account['balance'] + $amount], 'Deposit processed successfully.', 201);
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Deposit failed. Please try again.', 500);
        }
    }

    /* POST /api/transactions/withdrawal */
    public function withdrawal(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'account_id' => 'required|integer',
            'amount'     => 'required|numeric|min:100',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        $account = Database::query("SELECT * FROM accounts WHERE id=? AND status='Active'", [$data['account_id']])->fetch();
        if (!$account) { Response::error('Account not found or inactive.', 404); return; }

        $amount = (float)$data['amount'];
        if ($account['balance'] < $amount) { Response::error('Insufficient balance.', 400); return; }

        /* Large withdrawal requires approval */
        $status = $amount > 100000 ? 'Pending' : 'Completed';

        Database::beginTransaction();
        try {
            $ref = $this->generateRef('WDR');
            Database::query(
                "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,NOW())",
                [$data['account_id'], $ref, 'Withdrawal', $amount, $account['balance'],
                 $account['balance'] - $amount, $data['description'] ?? 'Cash Withdrawal', $status, JwtHelper::getUserId()]
            );
            if ($status === 'Completed') {
                Database::query("UPDATE accounts SET balance=balance-?, updated_at=NOW() WHERE id=?", [$amount, $data['account_id']]);
            }
            Database::commit();

            $msg = $status === 'Pending' ? 'Withdrawal pending manager approval.' : 'Withdrawal processed successfully.';
            Response::success(['reference' => $ref, 'status' => $status], $msg, 201);
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Withdrawal failed.', 500);
        }
    }

    /* POST /api/transactions/transfer */
    public function transfer(): void
    {
        JwtHelper::requireAuth();
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'from_account_id' => 'required|integer',
            'to_account_id'   => 'required|integer',
            'amount'          => 'required|numeric|min:1',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        if ($data['from_account_id'] === $data['to_account_id']) {
            Response::error('Source and destination accounts cannot be the same.', 400); return;
        }

        $from = Database::query("SELECT * FROM accounts WHERE id=? AND status='Active'", [$data['from_account_id']])->fetch();
        $to   = Database::query("SELECT * FROM accounts WHERE id=? AND status='Active'", [$data['to_account_id']])->fetch();

        if (!$from) { Response::error('Source account not found or inactive.', 404); return; }
        if (!$to)   { Response::error('Destination account not found or inactive.', 404); return; }

        $amount = (float)$data['amount'];
        if ($from['balance'] < $amount) { Response::error('Insufficient balance.', 400); return; }

        Database::beginTransaction();
        try {
            $ref = $this->generateRef('TRF');
            $now = date('Y-m-d H:i:s');
            $userId = JwtHelper::getUserId();

            Database::query(
                "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?)",
                [$data['from_account_id'], $ref, 'Transfer Out', $amount, $from['balance'],
                 $from['balance'] - $amount, "Transfer to account #{$to['account_number']}", 'Completed', $userId, $now]
            );
            Database::query(
                "INSERT INTO transactions (account_id, reference, type, amount, balance_before, balance_after, description, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?)",
                [$data['to_account_id'], $ref, 'Transfer In', $amount, $to['balance'],
                 $to['balance'] + $amount, "Transfer from account #{$from['account_number']}", 'Completed', $userId, $now]
            );
            Database::query("UPDATE accounts SET balance=balance-?, updated_at=NOW() WHERE id=?", [$amount, $data['from_account_id']]);
            Database::query("UPDATE accounts SET balance=balance+?, updated_at=NOW() WHERE id=?", [$amount, $data['to_account_id']]);
            Database::commit();

            Response::success(['reference' => $ref], 'Transfer completed successfully.', 201);
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Transfer failed.', 500);
        }
    }

    /* PUT /api/transactions/{id}/approve */
    public function approve(int $id): void
    {
        JwtHelper::requireRole(['Admin', 'Manager']);
        $txn = Database::query("SELECT * FROM transactions WHERE id=?", [$id])->fetch();
        if (!$txn || $txn['status'] !== 'Pending') { Response::error('Transaction not found or already processed.', 404); return; }

        Database::beginTransaction();
        try {
            Database::query("UPDATE transactions SET status='Completed', approved_by=?, approved_at=NOW() WHERE id=?",
                [JwtHelper::getUserId(), $id]);
            /* Apply balance change for pending withdrawal */
            if ($txn['type'] === 'Withdrawal') {
                Database::query("UPDATE accounts SET balance=balance-?, updated_at=NOW() WHERE id=?",
                    [(float)$txn['amount'], $txn['account_id']]);
            }
            Database::commit();
            Response::success(null, 'Transaction approved.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Approval failed.', 500);
        }
    }

    /* PUT /api/transactions/{id}/reverse */
    public function reverse(int $id): void
    {
        JwtHelper::requireRole(['Admin']);
        $txn = Database::query("SELECT * FROM transactions WHERE id=?", [$id])->fetch();
        if (!$txn || $txn['status'] !== 'Completed') { Response::error('Cannot reverse this transaction.', 400); return; }

        Database::beginTransaction();
        try {
            Database::query("UPDATE transactions SET status='Reversed', reversed_by=?, reversed_at=NOW() WHERE id=?",
                [JwtHelper::getUserId(), $id]);
            $amount = (float)$txn['amount'];
            if ($txn['type'] === 'Deposit') {
                Database::query("UPDATE accounts SET balance=balance-?, updated_at=NOW() WHERE id=?", [$amount, $txn['account_id']]);
            } elseif ($txn['type'] === 'Withdrawal') {
                Database::query("UPDATE accounts SET balance=balance+?, updated_at=NOW() WHERE id=?", [$amount, $txn['account_id']]);
            }
            Database::commit();
            Response::success(null, 'Transaction reversed.');
        } catch (\Exception $e) {
            Database::rollback();
            Response::error('Reversal failed.', 500);
        }
    }

    /* GET /api/transactions/{id} */
    public function show(int $id): void
    {
        JwtHelper::requireAuth();
        $txn = Database::query(
            "SELECT t.*, a.account_number, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM transactions t
             LEFT JOIN accounts a ON t.account_id=a.id
             LEFT JOIN customers c ON a.customer_id=c.id
             WHERE t.id=?", [$id]
        )->fetch();
        if (!$txn) { Response::error('Transaction not found.', 404); return; }
        Response::success($txn);
    }

    private function generateRef(string $prefix): string
    {
        return $prefix . '-' . strtoupper(substr(uniqid('', true), -8)) . '-' . date('Ymd');
    }
}
