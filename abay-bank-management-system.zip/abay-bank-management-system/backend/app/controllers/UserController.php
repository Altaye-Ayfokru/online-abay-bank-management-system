<?php
declare(strict_types=1);
namespace App\Controllers;

use App\Config\Database;
use App\Helpers\Response;
use App\Helpers\JwtHelper;
use App\Helpers\Validator;
use App\Models\UserModel;

class UserController
{
    private UserModel $model;
    public function __construct() { $this->model = new UserModel(); }

    /* GET /api/users */
    public function index(): void
    {
        JwtHelper::requireRole(['Admin']);
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $search  = trim($_GET['search'] ?? '');
        Response::success($this->model->paginate($page, $perPage, $search));
    }

    /* POST /api/users */
    public function store(): void
    {
        JwtHelper::requireRole(['Admin']);
        $data   = json_decode(file_get_contents('php://input'), true) ?? [];
        $errors = Validator::validate($data, [
            'username' => 'required|min:3',
            'email'    => 'required|email',
            'password' => 'required|min:8',
            'role_id'  => 'required|integer',
        ]);
        if ($errors) { Response::error('Validation failed.', 422, $errors); return; }

        if ($this->model->findByUsername($data['username'])) {
            Response::error('Username already taken.', 409); return;
        }
        if ($this->model->findByEmail($data['email'])) {
            Response::error('Email already registered.', 409); return;
        }

        $id = $this->model->create($data);
        Response::success(['user_id' => $id], 'User created successfully.', 201);
    }

    /* PUT /api/users/{id} */
    public function update(int $id): void
    {
        JwtHelper::requireRole(['Admin']);
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        Database::query(
            "UPDATE users SET email=?, role_id=?, branch_id=?, status=?, updated_at=NOW() WHERE id=?",
            [$data['email'], (int)$data['role_id'], (int)($data['branch_id'] ?? 0), $data['status'] ?? 'Active', $id]
        );
        Response::success(null, 'User updated.');
    }

    /* DELETE /api/users/{id} */
    public function destroy(int $id): void
    {
        JwtHelper::requireRole(['Admin']);
        if ($id === JwtHelper::getUserId()) {
            Response::error('You cannot delete your own account.', 400); return;
        }
        Database::query("UPDATE users SET deleted_at=NOW(), status='Inactive' WHERE id=?", [$id]);
        Response::success(null, 'User deleted.');
    }
}
