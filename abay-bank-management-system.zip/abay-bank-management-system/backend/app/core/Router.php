<?php
declare(strict_types=1);
namespace App\Core;

class Router
{
    private array $routes = [];

    private function add(string $method, string $path, string $handler): void
    {
        $this->routes[] = compact('method', 'path', 'handler');
    }

    public function get(string $p, string $h):    void { $this->add('GET',    $p, $h); }
    public function post(string $p, string $h):   void { $this->add('POST',   $p, $h); }
    public function put(string $p, string $h):    void { $this->add('PUT',    $p, $h); }
    public function patch(string $p, string $h):  void { $this->add('PATCH',  $p, $h); }
    public function delete(string $p, string $h): void { $this->add('DELETE', $p, $h); }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri    = rtrim($uri, '/') ?: '/';

        /* ── Strip project subdirectory prefix ──
         * When XAMPP serves from /abay-bank-management-system/,
         * the URI is /abay-bank-management-system/api/... 
         * We only need /api/... for routing. */
        $apiPos = strpos($uri, '/api/');
        if ($apiPos !== false) {
            $uri = substr($uri, $apiPos);
        } elseif ($uri === '/api') {
            $uri = '/api';
        }

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) continue;
            $pattern = preg_replace('/\{[a-z_]+\}/', '([^/]+)', $route['path']);
            $pattern = '#^' . $pattern . '$#';

            if (preg_match($pattern, $uri, $matches)) {
                array_shift($matches);
                [$class, $action] = explode('@', $route['handler']);
                $fqn = 'App\\Controllers\\' . $class;

                if (!class_exists($fqn)) {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => "Controller {$class} not found."]);
                    return;
                }
                $controller = new $fqn();
                if (!method_exists($controller, $action)) {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => "Method {$action} not found in {$class}."]);
                    return;
                }

                $params = array_map(fn($p) => ctype_digit($p) ? (int)$p : $p, $matches);
                $controller->$action(...$params);
                return;
            }
        }

        http_response_code(404);
        echo json_encode(['success' => false, 'message' => "Route {$method} {$uri} not found."]);
    }
}
