<?php
declare(strict_types=1);
namespace App\Helpers;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JwtHelper
{
    private static string $algo = 'HS256';

    private static function secret(): string
    {
        return $_ENV['JWT_SECRET'] ?? 'abay-bank-super-secret-key-2025';
    }

    public static function generate(array $payload, int $expireSeconds = 7200): string
    {
        $now = time();
        return JWT::encode(array_merge($payload, [
            'iat' => $now,
            'nbf' => $now,
            'exp' => $now + $expireSeconds,
            'iss' => 'abay-bank',
        ]), self::secret(), self::$algo);
    }

    public static function decode(string $token): ?object
    {
        try {
            return JWT::decode($token, new Key(self::secret(), self::$algo));
        } catch (\Exception) {
            return null;
        }
    }

    public static function fromRequest(): ?object
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (str_starts_with($header, 'Bearer ')) {
            return self::decode(substr($header, 7));
        }
        return null;
    }

    /** Require valid token; returns user_id or sends 401 */
    public static function requireAuth(): int
    {
        $payload = self::fromRequest();
        if (!$payload) {
            Response::error('Unauthorized. Please login.', 401);
            exit;
        }
        return (int)$payload->user_id;
    }

    /** Require specific role(s) */
    public static function requireRole(array $roles): int
    {
        $payload = self::fromRequest();
        if (!$payload) {
            Response::error('Unauthorized.', 401);
            exit;
        }
        if (!in_array($payload->role ?? '', $roles, true)) {
            Response::error('Forbidden. Insufficient permissions.', 403);
            exit;
        }
        return (int)$payload->user_id;
    }

    public static function getUserId(): ?int
    {
        $p = self::fromRequest();
        return $p ? (int)$p->user_id : null;
    }

    public static function getRole(): ?string
    {
        $p = self::fromRequest();
        return $p ? ($p->role ?? null) : null;
    }
}
