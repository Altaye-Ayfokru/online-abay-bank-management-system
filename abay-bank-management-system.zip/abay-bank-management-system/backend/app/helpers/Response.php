<?php
declare(strict_types=1);
namespace App\Helpers;

class Response
{
    public static function success(mixed $data = null, string $message = 'Success', int $code = 200): void
    {
        http_response_code($code);
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data'    => $data,
            'timestamp' => date('Y-m-d\TH:i:s\Z'),
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function error(string $message = 'Error', int $code = 400, mixed $errors = null): void
    {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'errors'  => $errors,
            'timestamp' => date('Y-m-d\TH:i:s\Z'),
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function paginated(array $data, int $total, int $page, int $perPage): void
    {
        self::success([
            'items'       => $data,
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => (int)ceil($total / max(1, $perPage)),
            'from'        => (($page - 1) * $perPage) + 1,
            'to'          => min($total, $page * $perPage),
        ]);
    }
}
