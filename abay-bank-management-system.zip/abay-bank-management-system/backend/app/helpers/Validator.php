<?php
declare(strict_types=1);
namespace App\Helpers;

class Validator
{
    /**
     * Validate $data against $rules.
     * Rules format: 'required|min:8|email'
     * Returns array of errors, or empty array if valid.
     */
    public static function validate(array $data, array $rules): array
    {
        $errors = [];
        foreach ($rules as $field => $ruleString) {
            $value    = $data[$field] ?? null;
            $ruleList = explode('|', $ruleString);

            foreach ($ruleList as $rule) {
                [$ruleName, $param] = array_pad(explode(':', $rule, 2), 2, null);
                $error = self::check($field, $value, $ruleName, $param);
                if ($error) {
                    $errors[$field][] = $error;
                    break; // stop on first error per field
                }
            }
        }
        return $errors;
    }

    private static function check(string $field, mixed $value, string $rule, ?string $param): ?string
    {
        $label = ucwords(str_replace('_', ' ', $field));

        return match($rule) {
            'required' => (is_null($value) || $value === '' || $value === [])
                ? "{$label} is required."
                : null,

            'min' => (!is_null($value) && strlen((string)$value) < (int)$param)
                ? "{$label} must be at least {$param} characters."
                : null,

            'max' => (!is_null($value) && strlen((string)$value) > (int)$param)
                ? "{$label} must not exceed {$param} characters."
                : null,

            'email' => (!is_null($value) && !filter_var($value, FILTER_VALIDATE_EMAIL))
                ? "{$label} must be a valid email address."
                : null,

            'numeric' => (!is_null($value) && !is_numeric($value))
                ? "{$label} must be a number."
                : null,

            'integer' => (!is_null($value) && !filter_var($value, FILTER_VALIDATE_INT))
                ? "{$label} must be an integer."
                : null,

            'alpha' => (!is_null($value) && !preg_match('/^[\pL\s\-]+$/u', (string)$value))
                ? "{$label} must contain letters only."
                : null,

            'phone' => (!is_null($value) && !preg_match('/^(\+251|0)[0-9]{9}$/', preg_replace('/[\s\-]/','',(string)$value)))
                ? "{$label} must be a valid Ethiopian phone number."
                : null,

            'url' => (!is_null($value) && !filter_var($value, FILTER_VALIDATE_URL))
                ? "{$label} must be a valid URL."
                : null,

            'date' => (!is_null($value) && !strtotime((string)$value))
                ? "{$label} must be a valid date."
                : null,

            'boolean' => (!is_null($value) && !is_bool($value) && !in_array($value, [0, 1, '0', '1', true, false], true))
                ? "{$label} must be a boolean value."
                : null,

            'in' => (!is_null($value) && !in_array($value, explode(',', $param ?? ''), true))
                ? "{$label} must be one of: {$param}."
                : null,

            'min_val' => (!is_null($value) && is_numeric($value) && (float)$value < (float)$param)
                ? "{$label} must be at least {$param}."
                : null,

            'max_val' => (!is_null($value) && is_numeric($value) && (float)$value > (float)$param)
                ? "{$label} must not exceed {$param}."
                : null,

            default => null,
        };
    }
}
