<?php
declare(strict_types=1);
namespace App\Middleware;

use App\Helpers\JwtHelper;
use App\Helpers\Response;

class AuthMiddleware
{
    public static function handle(array $allowedRoles = []): int
    {
        $payload = JwtHelper::fromRequest();

        if (!$payload) {
            Response::error('Unauthorized. Please provide a valid token.', 401);
            exit;
        }

        if (!empty($allowedRoles) && !in_array($payload->role ?? '', $allowedRoles, true)) {
            Response::error('Forbidden. You do not have permission to access this resource.', 403);
            exit;
        }

        return (int)$payload->user_id;
    }

    public static function rateLimit(string $key, int $maxRequests = 60, int $windowSeconds = 60): void
    {
        /* Simple in-memory rate limiting using APCu if available */
        if (!function_exists('apcu_fetch')) return;

        $count = (int)apcu_fetch($key, $success);
        if (!$success) {
            apcu_store($key, 1, $windowSeconds);
            return;
        }
        if ($count >= $maxRequests) {
            Response::error('Too many requests. Please try again later.', 429);
            exit;
        }
        apcu_inc($key);
    }
}
