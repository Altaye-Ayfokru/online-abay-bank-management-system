<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class AccountModel
{
    private string $table = 'accounts';

    public function findById(int $id): ?array
    {
        $r = Database::query(
            "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, b.name AS branch_name
             FROM {$this->table} a
             LEFT JOIN customers c ON a.customer_id=c.id
             LEFT JOIN branches  b ON a.branch_id=b.id
             WHERE a.id=?", [$id]
        )->fetch();
        return $r ?: null;
    }

    public function findByNumber(string $number): ?array
    {
        $r = Database::query(
            "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM {$this->table} a
             LEFT JOIN customers c ON a.customer_id=c.id
             WHERE a.account_number=?", [$number]
        )->fetch();
        return $r ?: null;
    }

    public function forCustomer(int $customerId): array
    {
        return Database::query(
            "SELECT * FROM {$this->table} WHERE customer_id=? ORDER BY created_at DESC", [$customerId]
        )->fetchAll();
    }

    public function paginate(int $page, int $perPage, array $filters = []): array
    {
        $offset = ($page - 1) * $perPage;
        $where  = "WHERE 1=1";
        $params = [];

        if (!empty($filters['type']))      { $where .= " AND a.account_type=?"; $params[] = $filters['type']; }
        if (!empty($filters['status']))    { $where .= " AND a.status=?";        $params[] = $filters['status']; }
        if (!empty($filters['branch_id'])) { $where .= " AND a.branch_id=?";    $params[] = (int)$filters['branch_id']; }
        if (!empty($filters['search'])) {
            $like = "%{$filters['search']}%";
            $where .= " AND (a.account_number LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)";
            $params = array_merge($params, [$like, $like, $like]);
        }

        $total = (int)Database::query(
            "SELECT COUNT(*) FROM {$this->table} a LEFT JOIN customers c ON a.customer_id=c.id {$where}", $params
        )->fetchColumn();

        $sql = "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, b.name AS branch_name
                FROM {$this->table} a
                LEFT JOIN customers c ON a.customer_id=c.id
                LEFT JOIN branches  b ON a.branch_id=b.id
                {$where} ORDER BY a.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;

        return [
            'data'        => Database::query($sql, $params)->fetchAll(),
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }

    public function create(array $data): int
    {
        Database::query(
            "INSERT INTO {$this->table}
             (customer_id, branch_id, account_number, account_type, currency, balance, interest_rate,
              min_balance, overdraft_limit, status, opened_date, fd_duration, fd_maturity_date, fd_interest_rate, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [
                (int)$data['customer_id'], (int)$data['branch_id'], $data['account_number'],
                $data['account_type'], $data['currency'] ?? 'ETB',
                (float)($data['initial_deposit'] ?? 0),
                (float)($data['interest_rate']   ?? 0),
                (float)($data['min_balance']     ?? 100),
                (float)($data['overdraft_limit'] ?? 0),
                'Active', date('Y-m-d'),
                $data['fd_duration']      ?? null,
                $data['fd_maturity_date'] ?? null,
                $data['fd_interest_rate'] ?? null,
                $data['created_by'] ?? null,
            ]
        );
        return (int)Database::lastInsertId();
    }

    public function updateBalance(int $id, float $amount): void
    {
        Database::query("UPDATE {$this->table} SET balance=balance+?, updated_at=NOW() WHERE id=?", [$amount, $id]);
    }

    public function freeze(int $id): void
    {
        Database::query("UPDATE {$this->table} SET status='Frozen', updated_at=NOW() WHERE id=?", [$id]);
    }

    public function unfreeze(int $id): void
    {
        Database::query("UPDATE {$this->table} SET status='Active', updated_at=NOW() WHERE id=?", [$id]);
    }

    public function close(int $id): void
    {
        Database::query("UPDATE {$this->table} SET status='Closed', closed_date=CURDATE(), updated_at=NOW() WHERE id=?", [$id]);
    }

    public function statement(int $id, string $from, string $to): array
    {
        return Database::query(
            "SELECT * FROM transactions WHERE account_id=? AND DATE(created_at) BETWEEN ? AND ? ORDER BY created_at DESC",
            [$id, $from, $to]
        )->fetchAll();
    }

    public function balance(int $id): float
    {
        $r = Database::query("SELECT balance FROM {$this->table} WHERE id=?", [$id])->fetch();
        return $r ? (float)$r['balance'] : 0.0;
    }
}
