<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class AppointmentModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $f = []): array {
        $where = '1=1';
        if (!empty($f['date']))        $where .= " AND a.appointment_date='{$f['date']}'";
        if (!empty($f['status']))      $where .= " AND a.status='{$f['status']}'";
        if (!empty($f['branch_id']))   $where .= " AND a.branch_id={$f['branch_id']}";
        if (!empty($f['customer_id'])) $where .= " AND a.customer_id={$f['customer_id']}";
        return $this->db->query("SELECT a.*,CONCAT(c.first_name,' ',c.last_name) AS customer_name,b.branch_name FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id LEFT JOIN branches b ON b.id=a.branch_id WHERE {$where} ORDER BY a.appointment_date,a.appointment_time LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT * FROM appointments WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function create(array $d): int {
        $s = $this->db->prepare("INSERT INTO appointments (customer_id,branch_id,appointment_date,appointment_time,purpose,notes) VALUES (:c,:b,:d,:t,:p,:n)");
        $s->execute([':c'=>$d['customer_id']??null,':b'=>$d['branch_id'],':d'=>$d['date'],':t'=>$d['time'],':p'=>$d['purpose'],':n'=>$d['notes']??null]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $d): bool {
        return $this->db->prepare("UPDATE appointments SET status=:s,notes=:n WHERE id=:id")->execute([':s'=>$d['status'],':n'=>$d['notes']??null,':id'=>$id]);
    }

    public function today(): array {
        return $this->db->query("SELECT a.*,CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM appointments a LEFT JOIN customers c ON c.id=a.customer_id WHERE a.appointment_date=CURDATE() ORDER BY a.appointment_time")->fetchAll(PDO::FETCH_ASSOC);
    }
}
