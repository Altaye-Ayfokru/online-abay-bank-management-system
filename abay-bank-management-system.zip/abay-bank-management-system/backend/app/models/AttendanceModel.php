<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class AttendanceModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function forEmployee(int $empId, ?string $month = null): array {
        $where = "employee_id={$empId}";
        if ($month) $where .= " AND DATE_FORMAT(date,'%Y-%m')='{$month}'";
        return $this->db->query("SELECT * FROM attendance WHERE {$where} ORDER BY date DESC")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function todayAll(): array {
        return $this->db->query("SELECT a.*,CONCAT(e.first_name,' ',e.last_name) AS employee_name,e.employee_number FROM attendance a JOIN employees e ON e.id=a.employee_id WHERE a.date=CURDATE()")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function checkIn(int $empId): array {
        $existing = $this->db->query("SELECT * FROM attendance WHERE employee_id={$empId} AND date=CURDATE()")->fetch(PDO::FETCH_ASSOC);
        if ($existing) return ['success'=>false,'message'=>'Already checked in today.'];
        $time   = date('H:i:s');
        $status = $time > '08:15:00' ? 'Late' : 'Present';
        $this->db->prepare("INSERT INTO attendance (employee_id,date,check_in,status) VALUES (:e,CURDATE(),:t,:s)")->execute([':e'=>$empId,':t'=>$time,':s'=>$status]);
        return ['success'=>true,'message'=>"Checked in at {$time}",'status'=>$status];
    }

    public function checkOut(int $empId): array {
        $rec = $this->db->query("SELECT * FROM attendance WHERE employee_id={$empId} AND date=CURDATE()")->fetch(PDO::FETCH_ASSOC);
        if (!$rec) return ['success'=>false,'message'=>'No check-in record for today.'];
        if ($rec['check_out']) return ['success'=>false,'message'=>'Already checked out.'];
        $time = date('H:i:s');
        $ot   = $time > '17:00:00' ? round((strtotime($time)-strtotime('17:00:00'))/3600, 2) : 0;
        $this->db->prepare("UPDATE attendance SET check_out=:t,overtime_hrs=:ot WHERE id=:id")->execute([':t'=>$time,':ot'=>$ot,':id'=>$rec['id']]);
        return ['success'=>true,'message'=>"Checked out at {$time}",'overtime_hours'=>$ot];
    }

    public function summary(int $empId, string $month): array {
        return $this->db->query("SELECT status,COUNT(*) AS count FROM attendance WHERE employee_id={$empId} AND DATE_FORMAT(date,'%Y-%m')='{$month}' GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
    }
}
