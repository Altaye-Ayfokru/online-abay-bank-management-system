<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class AuditModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $f = [], int $page = 1, int $perPage = 50): array {
        $offset = ($page - 1) * $perPage;
        $where  = '1=1';
        if (!empty($f['user_id']))    $where .= " AND a.user_id={$f['user_id']}";
        if (!empty($f['event_type'])) $where .= " AND a.event_type='{$f['event_type']}'";
        if (!empty($f['from']))       $where .= " AND DATE(a.created_at)>='{$f['from']}'";
        if (!empty($f['to']))         $where .= " AND DATE(a.created_at)<='{$f['to']}'";
        $total = $this->db->query("SELECT COUNT(*) FROM audit_logs a WHERE {$where}")->fetchColumn();
        $rows  = $this->db->query("SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE {$where} ORDER BY a.created_at DESC LIMIT {$perPage} OFFSET {$offset}")->fetchAll(PDO::FETCH_ASSOC);
        return ['data'=>$rows,'total'=>(int)$total,'page'=>$page,'per_page'=>$perPage,'pages'=>ceil($total/$perPage)];
    }

    public function loginAttempts(int $limit = 100): array {
        return $this->db->query("SELECT * FROM login_attempts ORDER BY created_at DESC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function activeSessions(): array {
        return $this->db->query("SELECT s.*,u.username,u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.is_active=1 AND s.expires_at>NOW() ORDER BY s.last_activity DESC")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function killSession(string $sessionId): bool {
        return $this->db->prepare("UPDATE sessions SET is_active=0 WHERE id=:id")->execute([':id'=>$sessionId]);
    }

    public function eventTypes(): array {
        return $this->db->query("SELECT DISTINCT event_type FROM audit_logs ORDER BY event_type")->fetchAll(PDO::FETCH_COLUMN);
    }
}
