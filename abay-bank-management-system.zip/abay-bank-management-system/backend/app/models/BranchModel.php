<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class BranchModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(): array {
        return $this->db->query(
            "SELECT b.*, COUNT(DISTINCT a.id) AS employee_count,
                    COUNT(DISTINCT ac.id) AS account_count
             FROM branches b
             LEFT JOIN employees a ON a.branch_id=b.id AND a.status='Active'
             LEFT JOIN accounts ac ON ac.branch_id=b.id AND ac.status='Active'
             GROUP BY b.id ORDER BY b.branch_name"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT * FROM branches WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function create(array $d): int {
        $s = $this->db->prepare("INSERT INTO branches (branch_name,branch_code,city,address,phone,email,manager_name,status) VALUES (:n,:c,:ci,:a,:p,:e,:m,:s)");
        $s->execute([':n'=>$d['branch_name'],':c'=>$d['branch_code'],':ci'=>$d['city'],':a'=>$d['address'],':p'=>$d['phone'],':e'=>$d['email']??null,':m'=>$d['manager_name']??null,':s'=>$d['status']??'Active']);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $d): bool {
        $s = $this->db->prepare("UPDATE branches SET branch_name=:n,city=:ci,address=:a,phone=:p,email=:e,status=:s WHERE id=:id");
        return $s->execute([':n'=>$d['branch_name'],':ci'=>$d['city'],':a'=>$d['address'],':p'=>$d['phone'],':e'=>$d['email']??null,':s'=>$d['status']??'Active',':id'=>$id]);
    }

    public function performance(int $branchId): array {
        $row = $this->db->query("SELECT COALESCE(SUM(balance),0) AS total_deposits, COUNT(*) AS accounts FROM accounts WHERE branch_id={$branchId} AND status='Active'")->fetch(PDO::FETCH_ASSOC);
        $loans = $this->db->query("SELECT COUNT(*) AS count, COALESCE(SUM(outstanding),0) AS portfolio FROM loans WHERE branch_id={$branchId}")->fetch(PDO::FETCH_ASSOC);
        return array_merge($row, $loans);
    }
}
