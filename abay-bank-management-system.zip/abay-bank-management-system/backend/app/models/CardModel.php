<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class CardModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $filters = []): array {
        $where = '1=1';
        if (!empty($filters['customer_id'])) $where .= " AND c.customer_id={$filters['customer_id']}";
        if (!empty($filters['status']))      $where .= " AND c.status='{$filters['status']}'";
        return $this->db->query(
            "SELECT c.*, CONCAT(cu.first_name,' ',cu.last_name) AS holder_name, a.account_number
             FROM atm_cards c
             JOIN accounts a ON a.id=c.account_id
             JOIN customers cu ON cu.id=a.customer_id
             WHERE {$where} ORDER BY c.issued_date DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT * FROM atm_cards WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function forCustomer(int $customerId): array {
        return $this->db->query(
            "SELECT c.* FROM atm_cards c JOIN accounts a ON a.id=c.account_id WHERE a.customer_id={$customerId}"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function issue(array $d): int {
        $cardNumber = '5' . str_pad((string)rand(0, 999999999999999), 15, '0', STR_PAD_LEFT);
        $s = $this->db->prepare("INSERT INTO atm_cards (account_id,card_number,card_type,expiry_date,status,issued_date) VALUES (:a,:n,:t,:e,'Active',CURDATE())");
        $s->execute([':a'=>$d['account_id'],':n'=>$cardNumber,':t'=>$d['card_type']??'Debit',':e'=>date('Y-m-t', strtotime('+3 years'))]);
        return (int)$this->db->lastInsertId();
    }

    public function block(int $id): bool {
        return $this->db->prepare("UPDATE atm_cards SET status='Blocked' WHERE id=:id")->execute([':id'=>$id]);
    }

    public function activate(int $id): bool {
        return $this->db->prepare("UPDATE atm_cards SET status='Active' WHERE id=:id")->execute([':id'=>$id]);
    }
}
