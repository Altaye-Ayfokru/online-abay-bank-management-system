<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class ComplaintModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $f = []): array {
        $where = '1=1';
        if (!empty($f['status'])) $where .= " AND c.status='{$f['status']}'";
        if (!empty($f['customer_id'])) $where .= " AND c.customer_id={$f['customer_id']}";
        return $this->db->query("SELECT c.*,CONCAT(cu.first_name,' ',cu.last_name) AS customer_name FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id WHERE {$where} ORDER BY c.created_at DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT c.*,CONCAT(cu.first_name,' ',cu.last_name) AS customer_name FROM complaints c LEFT JOIN customers cu ON cu.id=c.customer_id WHERE c.id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function create(array $d): int {
        $s = $this->db->prepare("INSERT INTO complaints (customer_id,subject,description,category,priority,channel) VALUES (:c,:s,:d,:cat,:p,:ch)");
        $s->execute([':c'=>$d['customer_id']??null,':s'=>$d['subject'],':d'=>$d['description'],':cat'=>$d['category']??'General',':p'=>$d['priority']??'Normal',':ch'=>$d['channel']??'Online']);
        return (int)$this->db->lastInsertId();
    }

    public function resolve(int $id, string $resolution, int $staffId): bool {
        return $this->db->prepare("UPDATE complaints SET status='Resolved',resolution=:r,resolved_by=:by,resolved_at=NOW() WHERE id=:id")->execute([':r'=>$resolution,':by'=>$staffId,':id'=>$id]);
    }

    public function stats(): array {
        return $this->db->query("SELECT status, COUNT(*) AS count FROM complaints GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
    }
}
