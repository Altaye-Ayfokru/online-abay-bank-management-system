<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class CustomerModel
{
    private string $table = 'customers';

    public function paginate(int $page, int $perPage, string $search = '', string $status = '', int $branchId = 0): array
    {
        $offset = ($page - 1) * $perPage;
        $where  = "WHERE c.deleted_at IS NULL";
        $params = [];

        if ($search) {
            $like = "%{$search}%";
            $where .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.national_id LIKE ?)";
            $params = array_merge($params, [$like, $like, $like, $like, $like]);
        }
        if ($status)   { $where .= " AND c.status=?";    $params[] = $status; }
        if ($branchId) { $where .= " AND c.branch_id=?"; $params[] = $branchId; }

        $total = (int)Database::query(
            "SELECT COUNT(*) FROM {$this->table} c {$where}", $params
        )->fetchColumn();

        $sql = "SELECT c.id, c.first_name, c.last_name, CONCAT(c.first_name,' ',c.last_name) AS full_name,
                       c.email, c.phone, c.national_id, c.status, c.kyc_status, c.created_at,
                       b.name AS branch_name, COUNT(DISTINCT a.id) AS account_count
                FROM {$this->table} c
                LEFT JOIN branches b ON c.branch_id=b.id
                LEFT JOIN accounts a ON a.customer_id=c.id
                {$where}
                GROUP BY c.id
                ORDER BY c.created_at DESC
                LIMIT ? OFFSET ?";
        $params[] = $perPage;
        $params[] = $offset;

        return [
            'data'        => Database::query($sql, $params)->fetchAll(),
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }

    public function findWithDetails(int $id): ?array
    {
        $customer = Database::query(
            "SELECT c.*, b.name AS branch_name
             FROM {$this->table} c
             LEFT JOIN branches b ON c.branch_id=b.id
             WHERE c.id=? AND c.deleted_at IS NULL", [$id]
        )->fetch();
        if (!$customer) return null;

        $customer['accounts'] = Database::query(
            "SELECT * FROM accounts WHERE customer_id=? ORDER BY created_at DESC", [$id]
        )->fetchAll();

        $customer['loans'] = Database::query(
            "SELECT * FROM loans WHERE customer_id=? ORDER BY created_at DESC", [$id]
        )->fetchAll();

        return $customer;
    }

    public function create(array $data): int
    {
        Database::query(
            "INSERT INTO {$this->table}
             (first_name, last_name, email, phone, national_id, date_of_birth, gender,
              address, city, region, branch_id, occupation, status, kyc_status, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,'Retail','Active','Pending',NOW())",
            [
                $data['first_name'], $data['last_name'], $data['email'],
                $data['phone'], $data['national_id'], $data['date_of_birth'] ?? null,
                $data['gender'] ?? null, $data['address'] ?? null,
                $data['city'] ?? null, $data['region'] ?? null, (int)$data['branch_id'],
            ]
        );
        return (int)Database::lastInsertId();
    }

    public function update(int $id, array $data): int
    {
        $stmt = Database::query(
            "UPDATE {$this->table}
             SET first_name=?, last_name=?, email=?, phone=?, address=?, city=?, region=?, updated_at=NOW()
             WHERE id=? AND deleted_at IS NULL",
            [$data['first_name'], $data['last_name'], $data['email'], $data['phone'],
             $data['address'] ?? null, $data['city'] ?? null, $data['region'] ?? null, $id]
        );
        return $stmt->rowCount();
    }

    public function softDelete(int $id): void
    {
        Database::query("UPDATE {$this->table} SET deleted_at=NOW(), status='Deleted' WHERE id=?", [$id]);
    }

    public function emailExists(string $email, ?int $excludeId = null): bool
    {
        $sql    = "SELECT COUNT(*) FROM {$this->table} WHERE email=? AND deleted_at IS NULL";
        $params = [$email];
        if ($excludeId) { $sql .= " AND id!=?"; $params[] = $excludeId; }
        return (int)Database::query($sql, $params)->fetchColumn() > 0;
    }

    public function nationalIdExists(string $nationalId, ?int $excludeId = null): bool
    {
        $sql    = "SELECT COUNT(*) FROM {$this->table} WHERE national_id=? AND deleted_at IS NULL";
        $params = [$nationalId];
        if ($excludeId) { $sql .= " AND id!=?"; $params[] = $excludeId; }
        return (int)Database::query($sql, $params)->fetchColumn() > 0;
    }
}
