<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class EmployeeModel
{
    private string $table = 'employees';

    public function findById(int $id): ?array
    {
        $r = Database::query(
            "SELECT e.*, d.name AS department_name, b.name AS branch_name
             FROM {$this->table} e
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches    b ON e.branch_id=b.id
             WHERE e.id=? AND e.status != 'Terminated'",
            [$id]
        )->fetch();
        return $r ?: null;
    }

    public function findByUserId(int $userId): ?array
    {
        $r = Database::query(
            "SELECT * FROM {$this->table} WHERE user_id=?", [$userId]
        )->fetch();
        return $r ?: null;
    }

    public function all(array $filters = []): array
    {
        $where  = "WHERE e.status != 'Terminated'";
        $params = [];
        if (!empty($filters['branch_id']))     { $where .= " AND e.branch_id=?";     $params[] = (int)$filters['branch_id']; }
        if (!empty($filters['department_id'])) { $where .= " AND e.department_id=?"; $params[] = (int)$filters['department_id']; }
        if (!empty($filters['status']))        { $where .= " AND e.status=?";         $params[] = $filters['status']; }

        return Database::query(
            "SELECT e.*, d.name AS department_name, b.name AS branch_name
             FROM {$this->table} e
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches    b ON e.branch_id=b.id
             {$where} ORDER BY e.first_name",
            $params
        )->fetchAll();
    }

    public function payrollData(): array
    {
        return Database::query(
            "SELECT e.id, e.first_name, e.last_name, e.basic_salary,
                    e.transport_allow, e.housing_allow, e.other_allowances,
                    d.name AS department, b.name AS branch
             FROM {$this->table} e
             LEFT JOIN departments d ON e.department_id=d.id
             LEFT JOIN branches    b ON e.branch_id=b.id
             WHERE e.status='Active' ORDER BY e.first_name"
        )->fetchAll();
    }

    public function headcount(): array
    {
        return Database::query(
            "SELECT d.name AS department, COUNT(e.id) AS count
             FROM {$this->table} e
             LEFT JOIN departments d ON e.department_id=d.id
             WHERE e.status='Active'
             GROUP BY d.id ORDER BY count DESC"
        )->fetchAll();
    }
}
