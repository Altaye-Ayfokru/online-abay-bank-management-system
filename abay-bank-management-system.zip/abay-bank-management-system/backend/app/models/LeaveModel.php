<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class LeaveModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $f = []): array {
        $where = '1=1';
        if (!empty($f['employee_id'])) $where .= " AND l.employee_id={$f['employee_id']}";
        if (!empty($f['status']))      $where .= " AND l.status='{$f['status']}'";
        return $this->db->query("SELECT l.*,CONCAT(e.first_name,' ',e.last_name) AS employee_name,e.employee_number FROM leave_requests l JOIN employees e ON e.id=l.employee_id WHERE {$where} ORDER BY l.created_at DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT * FROM leave_requests WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function apply(array $d): int {
        $days = max(1, (int)((strtotime($d['end_date'])-strtotime($d['start_date']))/86400)+1);
        $s = $this->db->prepare("INSERT INTO leave_requests (employee_id,leave_type,start_date,end_date,days_requested,reason) VALUES (:e,:t,:s,:en,:d,:r)");
        $s->execute([':e'=>$d['employee_id'],':t'=>$d['leave_type'],':s'=>$d['start_date'],':en'=>$d['end_date'],':d'=>$days,':r'=>$d['reason']??null]);
        return (int)$this->db->lastInsertId();
    }

    public function approve(int $id, int $approverId): bool {
        return $this->db->prepare("UPDATE leave_requests SET status='Approved',approved_by=:a,approved_at=NOW() WHERE id=:id")->execute([':a'=>$approverId,':id'=>$id]);
    }

    public function reject(int $id, int $approverId, string $reason = ''): bool {
        return $this->db->prepare("UPDATE leave_requests SET status='Rejected',approved_by=:a,approved_at=NOW(),rejection_reason=:r WHERE id=:id")->execute([':a'=>$approverId,':r'=>$reason,':id'=>$id]);
    }

    public function balance(int $empId): array {
        $taken = $this->db->query("SELECT leave_type,SUM(days_requested) AS taken FROM leave_requests WHERE employee_id={$empId} AND status='Approved' AND YEAR(start_date)=YEAR(NOW()) GROUP BY leave_type")->fetchAll(PDO::FETCH_ASSOC);
        $types = $this->db->query("SELECT code,name,days_per_year FROM leave_types WHERE is_active=1")->fetchAll(PDO::FETCH_ASSOC);
        $takenMap = array_column($taken,'taken','leave_type');
        foreach ($types as &$t) { $t['used']=$takenMap[$t['code']]??0; $t['remaining']=$t['days_per_year']-($takenMap[$t['code']]??0); }
        return $types;
    }
}
