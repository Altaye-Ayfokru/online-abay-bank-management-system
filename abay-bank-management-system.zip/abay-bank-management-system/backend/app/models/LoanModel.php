<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class LoanModel
{
    private string $table = 'loans';

    public function findById(int $id): ?array
    {
        $r = Database::query(
            "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name,
                    a.account_number, b.name AS branch_name
             FROM {$this->table} l
             LEFT JOIN customers c ON l.customer_id=c.id
             LEFT JOIN accounts  a ON l.account_id=a.id
             LEFT JOIN branches  b ON l.branch_id=b.id
             WHERE l.id=?", [$id]
        )->fetch();
        return $r ?: null;
    }

    public function forCustomer(int $customerId): array
    {
        return Database::query(
            "SELECT * FROM {$this->table} WHERE customer_id=? ORDER BY created_at DESC", [$customerId]
        )->fetchAll();
    }

    public function pending(): array
    {
        return Database::query(
            "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM {$this->table} l
             LEFT JOIN customers c ON l.customer_id=c.id
             WHERE l.status='Pending'
             ORDER BY l.created_at ASC"
        )->fetchAll();
    }

    public function overdue(): array
    {
        return Database::query(
            "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM {$this->table} l
             LEFT JOIN customers c ON l.customer_id=c.id
             WHERE l.status='Active' AND l.next_due_date < CURDATE()"
        )->fetchAll();
    }

    public function portfolioSummary(): array
    {
        $row = Database::query(
            "SELECT
                COUNT(*) AS total,
                SUM(status='Active')    AS active,
                SUM(status='Pending')   AS pending,
                SUM(status='Completed') AS completed,
                SUM(status='Rejected')  AS rejected,
                SUM(status='Defaulted') AS defaulted,
                COALESCE(SUM(outstanding),0) AS total_outstanding,
                COALESCE(SUM(amount),0)      AS total_disbursed
             FROM {$this->table}"
        )->fetch();
        return $row ?: [];
    }

    public function updateOutstanding(int $id, float $paidAmount): void
    {
        Database::query(
            "UPDATE {$this->table}
             SET outstanding = outstanding - ?,
                 paid_amount = paid_amount + ?,
                 updated_at  = NOW()
             WHERE id = ?",
            [$paidAmount, $paidAmount, $id]
        );
        /* Auto-close if fully paid */
        $loan = Database::query("SELECT outstanding FROM {$this->table} WHERE id=?", [$id])->fetch();
        if ($loan && (float)$loan['outstanding'] <= 0) {
            Database::query(
                "UPDATE {$this->table} SET status='Completed', actual_close_date=CURDATE() WHERE id=?",
                [$id]
            );
        }
    }
}
