<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class NotificationModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function forUser(int $userId, int $limit = 50): array {
        return $this->db->query("SELECT * FROM notifications WHERE user_id={$userId} ORDER BY created_at DESC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function unreadCount(int $userId): int {
        return (int)$this->db->query("SELECT COUNT(*) FROM notifications WHERE user_id={$userId} AND is_read=0")->fetchColumn();
    }

    public function markRead(int $id, int $userId): bool {
        return $this->db->prepare("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=:id AND user_id=:uid")->execute([':id'=>$id,':uid'=>$userId]);
    }

    public function markAllRead(int $userId): bool {
        return $this->db->prepare("UPDATE notifications SET is_read=1, read_at=NOW() WHERE user_id=:uid AND is_read=0")->execute([':uid'=>$userId]);
    }

    public function create(array $d): int {
        $s = $this->db->prepare("INSERT INTO notifications (user_id,type,title,body,priority) VALUES (:u,:t,:ti,:b,:p)");
        $s->execute([':u'=>$d['user_id'],':t'=>$d['type'],':ti'=>$d['title'],':b'=>$d['body'],':p'=>$d['priority']??'Normal']);
        return (int)$this->db->lastInsertId();
    }
}
