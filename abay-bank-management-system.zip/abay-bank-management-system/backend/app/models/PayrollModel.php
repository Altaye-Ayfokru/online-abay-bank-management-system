<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class PayrollModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(array $f = []): array {
        $where = '1=1';
        if (!empty($f['month'])) $where .= " AND p.pay_month='{$f['month']}'";
        if (!empty($f['employee_id'])) $where .= " AND p.employee_id={$f['employee_id']}";
        return $this->db->query("SELECT p.*,CONCAT(e.first_name,' ',e.last_name) AS employee_name,e.employee_number FROM payroll p JOIN employees e ON e.id=p.employee_id WHERE {$where} ORDER BY p.pay_month DESC,e.first_name LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findSlip(int $empId, string $month): array|false {
        return $this->db->query("SELECT p.*,CONCAT(e.first_name,' ',e.last_name) AS name,e.position,e.employee_number,b.branch_name FROM payroll p JOIN employees e ON e.id=p.employee_id LEFT JOIN branches b ON b.id=e.branch_id WHERE p.employee_id={$empId} AND p.pay_month='{$month}'")->fetch(PDO::FETCH_ASSOC);
    }

    public function processMonthly(string $month, int $processedBy): array {
        $employees = $this->db->query("SELECT * FROM employees WHERE status='Active'")->fetchAll(PDO::FETCH_ASSOC);
        $count = 0;
        foreach ($employees as $emp) {
            $basic  = (float)$emp['basic_salary'];
            $trans  = (float)($emp['transport_allow'] ?? $basic*0.10);
            $house  = (float)($emp['housing_allow']  ?? $basic*0.15);
            $gross  = $basic + $trans + $house;
            $tax    = $this->calcIncomeTax($gross);
            $pension = $gross * 0.07;  // employee pension 7%
            $net    = $gross - $tax - $pension;
            // Upsert payroll record
            $s = $this->db->prepare("INSERT INTO payroll (employee_id,pay_month,basic_salary,transport_allowance,housing_allowance,gross_salary,income_tax,pension_employee,net_salary,status,processed_by) VALUES (:e,:m,:b,:t,:h,:g,:tax,:pen,:n,'Processed',:pb) ON DUPLICATE KEY UPDATE gross_salary=:g,net_salary=:n,status='Processed'");
            $s->execute([':e'=>$emp['id'],':m'=>$month,':b'=>$basic,':t'=>$trans,':h'=>$house,':g'=>$gross,':tax'=>$tax,':pen'=>$pension,':n'=>$net,':pb'=>$processedBy]);
            $count++;
        }
        return ['success'=>true,'message'=>"Payroll processed for {$count} employees.",'month'=>$month,'count'=>$count];
    }

    private function calcIncomeTax(float $gross): float {
        // Ethiopia progressive tax brackets (ETB/month)
        if ($gross <= 600)    return 0;
        if ($gross <= 1650)   return ($gross - 600) * 0.10;
        if ($gross <= 3200)   return 105 + ($gross - 1650) * 0.15;
        if ($gross <= 5250)   return 337.5 + ($gross - 3200) * 0.20;
        if ($gross <= 7800)   return 747.5 + ($gross - 5250) * 0.25;
        if ($gross <= 10900)  return 1385 + ($gross - 7800) * 0.30;
        return 2315 + ($gross - 10900) * 0.35;
    }
}
