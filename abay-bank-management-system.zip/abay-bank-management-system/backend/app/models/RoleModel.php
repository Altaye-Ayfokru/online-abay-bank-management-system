<?php
declare(strict_types=1);
namespace App\Models;
use PDO;

class RoleModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function all(): array {
        return $this->db->query("SELECT r.*, COUNT(DISTINCT u.id) AS user_count FROM roles r LEFT JOIN users u ON u.role_id=r.id GROUP BY r.id ORDER BY r.id")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): array|false {
        return $this->db->query("SELECT * FROM roles WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    }

    public function permissions(int $roleId): array {
        return $this->db->query("SELECT * FROM permissions WHERE role_id={$roleId}")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(array $d): int {
        $s = $this->db->prepare("INSERT INTO roles (role_name,description) VALUES (:n,:d)");
        $s->execute([':n'=>$d['role_name'],':d'=>$d['description']??null]);
        return (int)$this->db->lastInsertId();
    }

    public function updatePermissions(int $roleId, array $permissions): bool {
        $this->db->prepare("DELETE FROM permissions WHERE role_id=:rid")->execute([':rid'=>$roleId]);
        $s = $this->db->prepare("INSERT INTO permissions (role_id, module, can_view, can_create, can_edit, can_delete) VALUES (:r,:m,:v,:c,:e,:d)");
        foreach ($permissions as $p) {
            $s->execute([':r'=>$roleId,':m'=>$p['module'],':v'=>$p['can_view']??1,':c'=>$p['can_create']??0,':e'=>$p['can_edit']??0,':d'=>$p['can_delete']??0]);
        }
        return true;
    }
}
