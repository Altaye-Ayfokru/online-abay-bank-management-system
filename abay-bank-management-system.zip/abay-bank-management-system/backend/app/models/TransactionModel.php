<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class TransactionModel
{
    private string $table = 'transactions';

    public function findById(int $id): ?array
    {
        $r = Database::query(
            "SELECT t.*, a.account_number, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM {$this->table} t
             LEFT JOIN accounts  a ON t.account_id=a.id
             LEFT JOIN customers c ON a.customer_id=c.id
             WHERE t.id=?", [$id]
        )->fetch();
        return $r ?: null;
    }

    public function forAccount(int $accountId, string $from = '', string $to = '', int $limit = 50): array
    {
        $where  = "WHERE t.account_id=?";
        $params = [$accountId];
        if ($from) { $where .= " AND DATE(t.created_at)>=?"; $params[] = $from; }
        if ($to)   { $where .= " AND DATE(t.created_at)<=?"; $params[] = $to; }

        return Database::query(
            "SELECT * FROM {$this->table} t {$where} ORDER BY t.created_at DESC LIMIT ?",
            array_merge($params, [$limit])
        )->fetchAll();
    }

    public function dailySummary(string $date): array
    {
        $types = Database::query(
            "SELECT type, COUNT(*) AS count, COALESCE(SUM(amount),0) AS total
             FROM {$this->table}
             WHERE DATE(created_at)=? AND status='Completed'
             GROUP BY type",
            [$date]
        )->fetchAll();

        $pending = (int)Database::query(
            "SELECT COUNT(*) FROM {$this->table} WHERE DATE(created_at)=? AND status='Pending'", [$date]
        )->fetchColumn();

        return ['by_type' => $types, 'pending' => $pending, 'date' => $date];
    }

    public function pending(): array
    {
        return Database::query(
            "SELECT t.*, a.account_number, CONCAT(c.first_name,' ',c.last_name) AS customer_name
             FROM {$this->table} t
             LEFT JOIN accounts  a ON t.account_id=a.id
             LEFT JOIN customers c ON a.customer_id=c.id
             WHERE t.status='Pending'
             ORDER BY t.created_at ASC"
        )->fetchAll();
    }

    public function monthlyVolume(string $month): array
    {
        return Database::query(
            "SELECT DATE(created_at) AS date,
                    SUM(type='Deposit')    AS deposits,
                    SUM(type='Withdrawal') AS withdrawals,
                    SUM(type LIKE 'Transfer%') AS transfers,
                    COUNT(*) AS total_count
             FROM {$this->table}
             WHERE DATE_FORMAT(created_at,'%Y-%m')=? AND status='Completed'
             GROUP BY DATE(created_at)
             ORDER BY date",
            [$month]
        )->fetchAll();
    }
}
