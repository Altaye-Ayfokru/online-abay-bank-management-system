<?php
declare(strict_types=1);
namespace App\Models;

use App\Config\Database;

class UserModel
{
    private string $table = 'users';

    public function findById(int $id): ?array
    {
        $r = Database::query("SELECT * FROM {$this->table} WHERE id=? AND deleted_at IS NULL", [$id])->fetch();
        return $r ?: null;
    }

    public function findByUsername(string $username): ?array
    {
        $r = Database::query(
            "SELECT u.*, r.name AS role_name FROM {$this->table} u
             LEFT JOIN roles r ON u.role_id=r.id
             WHERE u.username=? AND u.deleted_at IS NULL", [$username]
        )->fetch();
        return $r ?: null;
    }

    public function findByEmail(string $email): ?array
    {
        $r = Database::query(
            "SELECT * FROM {$this->table} WHERE email=? AND deleted_at IS NULL", [$email]
        )->fetch();
        return $r ?: null;
    }

    public function create(array $data): int
    {
        $hash = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
        Database::query(
            "INSERT INTO {$this->table} (username, email, password, role_id, branch_id, status, created_at)
             VALUES (?,?,?,?,?,'Active',NOW())",
            [$data['username'], $data['email'], $hash, (int)$data['role_id'], (int)($data['branch_id'] ?? 0)]
        );
        return (int)Database::lastInsertId();
    }

    public function updatePassword(int $id, string $hash): void
    {
        Database::query(
            "UPDATE {$this->table} SET password=?, password_changed_at=NOW(), updated_at=NOW() WHERE id=?",
            [$hash, $id]
        );
    }

    public function updateLastLogin(int $id): void
    {
        Database::query(
            "UPDATE {$this->table} SET last_login_at=NOW(), failed_attempts=0 WHERE id=?", [$id]
        );
    }

    public function incrementFailedAttempts(int $id, int $attempts): void
    {
        Database::query(
            "UPDATE {$this->table} SET failed_attempts=?, updated_at=NOW() WHERE id=?", [$attempts, $id]
        );
    }

    public function clearFailedAttempts(int $id): void
    {
        Database::query(
            "UPDATE {$this->table} SET failed_attempts=0 WHERE id=?", [$id]
        );
    }

    public function lockAccount(int $id): void
    {
        Database::query(
            "UPDATE {$this->table} SET status='Locked', updated_at=NOW() WHERE id=?", [$id]
        );
    }

    public function paginate(int $page, int $perPage, string $search = ''): array
    {
        $offset = ($page - 1) * $perPage;
        $where  = "WHERE u.deleted_at IS NULL";
        $params = [];
        if ($search) {
            $like = "%{$search}%";
            $where .= " AND (u.username LIKE ? OR u.email LIKE ?)";
            $params = [$like, $like];
        }
        $total = (int)Database::query("SELECT COUNT(*) FROM {$this->table} u {$where}", $params)->fetchColumn();
        $sql   = "SELECT u.id, u.username, u.email, u.status, u.last_login_at, r.name AS role, b.name AS branch
                  FROM {$this->table} u
                  LEFT JOIN roles r ON u.role_id=r.id
                  LEFT JOIN branches b ON u.branch_id=b.id
                  {$where} ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $perPage; $params[] = $offset;
        return ['data' => Database::query($sql, $params)->fetchAll(), 'total' => $total];
    }
}
