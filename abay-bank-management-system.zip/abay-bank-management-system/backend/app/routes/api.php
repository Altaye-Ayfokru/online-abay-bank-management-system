<?php

/**
 * API Routes — Abay Bank Management System
 * IMPORTANT: Specific routes must be registered BEFORE wildcard {id} routes.
 */

declare(strict_types=1);

namespace App\Routes;

use App\Core\Router;

$router = new Router();

/* ── Public Home Stats (no auth) ── */
$router->get('/api/health',       'HomeController@health');
$router->get('/api/home/stats',   'HomeController@stats');

/* ── Customer Portal (customer JWT) ── */
$router->post('/api/customer/login',                        'CustomerPortalController@login');
$router->get('/api/customer/dashboard',                    'CustomerPortalController@dashboard');
$router->get('/api/customer/accounts',                     'CustomerPortalController@myAccounts');
$router->get('/api/customer/accounts/{id}/statement',      'CustomerPortalController@statement');
$router->post('/api/customer/transfer',                     'CustomerPortalController@transfer');
$router->get('/api/customer/beneficiaries',                'CustomerPortalController@beneficiaries');
$router->post('/api/customer/beneficiaries',                'CustomerPortalController@addBeneficiary');
$router->delete('/api/customer/beneficiaries/{id}',         'CustomerPortalController@deleteBeneficiary');
$router->get('/api/customer/loans',                        'CustomerPortalController@myLoans');
$router->get('/api/customer/cards',                        'CustomerPortalController@myCards');
$router->post('/api/customer/kyc/upload',                   'CustomerPortalController@uploadDocument');
$router->post('/api/customer/cheque-book',                  'CustomerPortalController@requestChequeBook');
$router->get('/api/customer/profile',                      'CustomerPortalController@profile');
$router->get('/api/customer/notifications',                'CustomerPortalController@notifications');

/* ── Authentication ── */
$router->post('/api/auth/login',           'AuthController@login');
$router->post('/api/auth/logout',          'AuthController@logout');
$router->post('/api/auth/refresh',         'AuthController@refresh');
$router->post('/api/auth/forgot-password', 'AuthController@forgotPassword');
$router->post('/api/auth/reset-password',  'AuthController@resetPassword');
$router->put('/api/auth/change-password', 'AuthController@changePassword');

/* ── Dashboard ── */
$router->get('/api/dashboard/stats',       'DashboardController@stats');
$router->get('/api/dashboard/charts',      'DashboardController@charts');
$router->get('/api/dashboard/activities',  'DashboardController@recentActivities');

/* ── Customers ── */
$router->get('/api/customers',          'CustomerController@index');
$router->post('/api/customers',          'CustomerController@store');
$router->get('/api/customers/{id}',     'CustomerController@show');
$router->put('/api/customers/{id}',     'CustomerController@update');
$router->delete('/api/customers/{id}',     'CustomerController@destroy');
$router->put('/api/customers/{id}/kyc', 'CustomerController@updateKyc');

/* ── Accounts ── */
$router->get('/api/accounts',                  'AccountController@index');
$router->post('/api/accounts',                  'AccountController@store');
$router->get('/api/accounts/{id}',             'AccountController@show');
$router->put('/api/accounts/{id}',             'AccountController@update');
$router->put('/api/accounts/{id}/freeze',      'AccountController@freeze');
$router->put('/api/accounts/{id}/unfreeze',    'AccountController@unfreeze');
$router->get('/api/accounts/{id}/statement',   'AccountController@statement');
$router->get('/api/accounts/{id}/balance',     'AccountController@balance');

/* ── Transactions ── */
$router->post('/api/transactions/deposit',        'TransactionController@deposit');
$router->post('/api/transactions/withdrawal',     'TransactionController@withdrawal');
$router->post('/api/transactions/transfer',       'TransactionController@transfer');
$router->get('/api/transactions',                'TransactionController@index');
$router->get('/api/transactions/{id}',           'TransactionController@show');
$router->put('/api/transactions/{id}/approve',   'TransactionController@approve');
$router->put('/api/transactions/{id}/reverse',   'TransactionController@reverse');

/* ── Loans — specific routes BEFORE {id} wildcard ── */
$router->post('/api/loans/calculate-emi',   'LoanController@calculateEmi');
$router->get('/api/loans',                 'LoanController@index');
$router->post('/api/loans',                 'LoanController@apply');
$router->get('/api/loans/{id}',            'LoanController@show');
$router->put('/api/loans/{id}/approve',    'LoanController@approve');
$router->put('/api/loans/{id}/reject',     'LoanController@reject');
$router->post('/api/loans/{id}/payment',    'LoanController@payment');
$router->get('/api/loans/{id}/schedule',   'LoanController@schedule');

/* ── Employees ── */
$router->get('/api/employees',          'EmployeeController@index');
$router->post('/api/employees',          'EmployeeController@store');
$router->get('/api/employees/{id}',     'EmployeeController@show');
$router->put('/api/employees/{id}',     'EmployeeController@update');
$router->delete('/api/employees/{id}',     'EmployeeController@destroy');

/* ── Attendance ── */
$router->get('/api/attendance',          'AttendanceController@index');
$router->post('/api/attendance/checkin',  'AttendanceController@checkIn');
$router->post('/api/attendance/checkout', 'AttendanceController@checkOut');
$router->get('/api/attendance/report',   'AttendanceController@report');

/* ── Leave ── */
$router->get('/api/leaves',              'LeaveController@index');
$router->post('/api/leaves',              'LeaveController@apply');
$router->put('/api/leaves/{id}/approve', 'LeaveController@approve');
$router->put('/api/leaves/{id}/reject',  'LeaveController@reject');

/* ── Payroll ── */
$router->get('/api/payroll',             'PayrollController@index');
$router->post('/api/payroll/process',     'PayrollController@process');
$router->get('/api/payroll/{id}/slip',   'PayrollController@payslip');

/* ── Branches ── */
$router->get('/api/branches',            'BranchController@index');
$router->post('/api/branches',            'BranchController@store');
$router->get('/api/branches/{id}',       'BranchController@show');
$router->put('/api/branches/{id}',       'BranchController@update');

/* ── Reports ── */
$router->get('/api/reports/financial',      'ReportController@financial');
$router->get('/api/reports/customers',      'ReportController@customers');
$router->get('/api/reports/loans',          'ReportController@loans');
$router->get('/api/reports/transactions',   'ReportController@transactions');
$router->get('/api/reports/attendance',     'ReportController@attendance');
$router->get('/api/reports/branch',         'ReportController@branch');

/* ── Notifications — read-all BEFORE {id} ── */
$router->put('/api/notifications/read-all',      'NotificationController@markAllRead');
$router->get('/api/notifications',               'NotificationController@index');
$router->put('/api/notifications/{id}/read',     'NotificationController@markRead');
$router->post('/api/notifications/send',          'NotificationController@send');

/* ── Complaints ── */
$router->get('/api/complaints',                  'ComplaintController@index');
$router->post('/api/complaints',                  'ComplaintController@store');
$router->put('/api/complaints/{id}/resolve',     'ComplaintController@resolve');

/* ── Appointments ── */
$router->get('/api/appointments',                'AppointmentController@index');
$router->post('/api/appointments',                'AppointmentController@store');
$router->put('/api/appointments/{id}',           'AppointmentController@update');

/* ── ATM Cards ── */
$router->get('/api/cards',                       'CardController@index');
$router->post('/api/cards',                       'CardController@issue');
$router->put('/api/cards/{id}/block',            'CardController@block');
$router->put('/api/cards/{id}/activate',         'CardController@activate');

/* ── Users & Roles ── */
$router->get('/api/users',                       'UserController@index');
$router->post('/api/users',                       'UserController@store');
$router->put('/api/users/{id}',                  'UserController@update');
$router->delete('/api/users/{id}',                  'UserController@destroy');
$router->get('/api/roles',                       'RoleController@index');
$router->post('/api/roles',                       'RoleController@store');
$router->put('/api/roles/{id}/permissions',      'RoleController@updatePermissions');

/* ── Audit ── */
$router->get('/api/audit',                          'AuditController@index');
$router->get('/api/audit/login-attempts',           'AuditController@loginAttempts');
$router->get('/api/audit/sessions',                 'AuditController@sessions');
$router->delete('/api/audit/sessions/{id}',         'AuditController@killSession');

/* ── Transfers (dedicated endpoint) ── */
$router->get('/api/transfers',                     'TransactionController@transferList');
$router->get('/api/transfers/{id}',                'TransactionController@transferDetail');

/* ── Beneficiaries (admin view) ── */
$router->get('/api/beneficiaries',                 'CustomerController@beneficiaries');

/* ── KYC ── */
$router->get('/api/kyc',                           'CustomerController@kycList');
$router->put('/api/kyc/{id}/approve',              'CustomerController@approveKyc');
$router->put('/api/kyc/{id}/reject',               'CustomerController@rejectKyc');
$router->post('/api/kyc/{id}/upload',               'CustomerController@uploadDocument');

/* ── Cheque Books ── */
$router->get('/api/cheque-books',                  'CardController@chequeBooks');
$router->post('/api/cheque-books',                  'CardController@issueChequeBook');
$router->put('/api/cheque-books/{id}/issue',       'CardController@issueChequeBook');

/* ── Cheques ── */
$router->get('/api/cheques',                       'CardController@cheques');
$router->post('/api/cheques',                       'CardController@createCheque');
$router->put('/api/cheques/{id}/stop',             'CardController@stopCheque');

/* ── Exchange Rates ── */
$router->get('/api/exchange-rates',                'SettingsController@exchangeRates');
$router->post('/api/exchange-rates',                'SettingsController@updateExchangeRate');

/* ── Fixed Deposits ── */
$router->get('/api/fixed-deposits',                'AccountController@fixedDeposits');
$router->post('/api/fixed-deposits',                'AccountController@createFD');
$router->get('/api/fixed-deposits/{id}',           'AccountController@showFD');

/* ── Inventory ── */
$router->get('/api/inventory',                     'InventoryController@index');
$router->post('/api/inventory',                     'InventoryController@store');
$router->get('/api/inventory/{id}',                'InventoryController@show');
$router->put('/api/inventory/{id}',                'InventoryController@update');
$router->delete('/api/inventory/{id}',              'InventoryController@destroy');

/* ── Messages ── */
$router->get('/api/messages',                      'MessageController@index');
$router->post('/api/messages',                      'MessageController@send');
$router->get('/api/messages/{id}',                 'MessageController@show');
$router->put('/api/messages/{id}/read',            'MessageController@markRead');

/* ── Account Applications (KYC onboarding) ── */
$router->get('/api/applications',                  'CustomerController@applications');
$router->post('/api/applications',                  'CustomerController@createApplication');
$router->get('/api/applications/{id}',             'CustomerController@showApplication');
$router->put('/api/applications/{id}/approve',     'CustomerController@approveApplication');
$router->put('/api/applications/{id}/reject',      'CustomerController@rejectApplication');

/* ── Announcements ── */
$router->get('/api/announcements',                 'NotificationController@announcements');
$router->post('/api/announcements',                 'NotificationController@createAnnouncement');

/* ── Reports (extended) ── */
$router->get('/api/reports/payroll',                'ReportController@payroll');
$router->get('/api/reports/daily-transactions',     'ReportController@dailyTransactions');
$router->get('/api/reports/customer-growth',        'ReportController@customerGrowth');

/* ── Settings ── */
$router->get('/api/settings',                       'SettingsController@index');
$router->put('/api/settings',                       'SettingsController@update');

/* ── Backup ── */
$router->post('/api/backup/create',                 'BackupController@create');
$router->get('/api/backup/list',                   'BackupController@list');
$router->post('/api/backup/restore',                'BackupController@restore');

return $router;

/* ── Inter-Bank Transfers (EthSwitch) ── */
$router->get('/api/interbank/transfers',         'InterbankController@index');
$router->post('/api/interbank/transfer',          'InterbankController@create');
$router->get('/api/interbank/transfers/{id}',    'InterbankController@show');
$router->put('/api/interbank/transfers/{id}/reverse', 'InterbankController@reverse');

/* ── Online Account Applications ── */
$router->get('/api/online/applications',                  'OnlineApplicationApiController@index');
$router->get('/api/online/applications/{id}',             'OnlineApplicationApiController@show');
$router->put('/api/online/applications/{id}/approve',     'OnlineApplicationApiController@approve');
$router->put('/api/online/applications/{id}/reject',      'OnlineApplicationApiController@reject');

/* ── Biometric Records ── */
$router->get('/api/biometrics/{customer_id}',    'BiometricController@index');
$router->post('/api/biometrics/enroll',           'BiometricController@enroll');
$router->delete('/api/biometrics/{id}',           'BiometricController@revoke');

/* ── ATM Sessions ── */
$router->get('/api/atm/sessions',                'AtmController@sessions');
$router->get('/api/atm/sessions/{id}',           'AtmController@session');
