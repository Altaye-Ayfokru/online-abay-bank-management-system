<?php
declare(strict_types=1);
namespace App\Services;

use PDO;
use PDOException;

class AccountService
{
    private PDO $db;
    private AuditService $audit;
    private NotificationService $notify;

    public function __construct(PDO $db)
    {
        $this->db     = $db;
        $this->audit  = new AuditService($db);
        $this->notify = new NotificationService($db);
    }

    /**
     * Open a new account for an existing verified customer.
     */
    public function openAccount(array $data, ?int $staffId = null): array
    {
        $required = ['customer_id', 'branch_id', 'account_type'];
        foreach ($required as $f) {
            if (empty($data[$f])) {
                return ['success' => false, 'message' => "Missing required field: {$f}"];
            }
        }

        try {
            $this->db->beginTransaction();

            // Verify customer exists and is active
            $customer = $this->db->query(
                "SELECT * FROM customers WHERE id = {$data['customer_id']} AND status = 'Active'"
            )->fetch(PDO::FETCH_ASSOC);
            if (!$customer) {
                $this->db->rollBack();
                return ['success' => false, 'message' => 'Customer not found or not active.'];
            }

            // Generate account number: AB + branch_code(3) + type_code(1) + sequence(9)
            $accountNumber = $this->generateAccountNumber((int)$data['branch_id'], $data['account_type']);

            $stmt = $this->db->prepare(
                "INSERT INTO accounts
                    (customer_id, branch_id, account_number, account_type,
                     balance, interest_rate, status, opened_date)
                 VALUES (:cid,:bid,:num,:type,:bal,:rate,'Active',CURDATE())"
            );
            $stmt->execute([
                ':cid'  => $data['customer_id'],
                ':bid'  => $data['branch_id'],
                ':num'  => $accountNumber,
                ':type' => $data['account_type'],
                ':bal'  => $data['initial_deposit'] ?? 0.00,
                ':rate' => $this->getInterestRate($data['account_type']),
            ]);
            $accountId = (int)$this->db->lastInsertId();

            // If initial deposit > 0, record as a transaction
            if (!empty($data['initial_deposit']) && (float)$data['initial_deposit'] > 0) {
                $txnService = new TransactionService($this->db);
                // We're already inside a transaction; call the private helper directly
                $ref = $txnService->generateRef('DEP');
                $stmt = $this->db->prepare(
                    "INSERT INTO transactions
                        (account_id, reference, type, amount, balance_before, balance_after, description, status)
                     VALUES (:aid,:ref,'Deposit',:amt,0,:ba,'Account Opening Deposit','Completed')"
                );
                $stmt->execute([
                    ':aid' => $accountId,
                    ':ref' => $ref,
                    ':amt' => (float)$data['initial_deposit'],
                    ':ba'  => (float)$data['initial_deposit'],
                ]);
            }

            $this->audit->log($staffId, 'Account Opened', "Account {$accountNumber} opened for customer #{$data['customer_id']}");
            $this->db->commit();

            // Notify customer
            $this->notify->notify(
                (int)$customer['user_id'] ?? 0,
                'account',
                'Account Opened Successfully',
                "Your {$data['account_type']} account {$accountNumber} has been opened.",
                'Normal'
            );

            return [
                'success'        => true,
                'message'        => 'Account opened successfully.',
                'account_id'     => $accountId,
                'account_number' => $accountNumber,
            ];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            error_log('AccountService::openAccount error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Failed to open account.'];
        }
    }

    /**
     * Close an account (sets status to Closed after zero-balance check).
     */
    public function closeAccount(int $accountId, string $reason, ?int $staffId = null): array
    {
        try {
            $this->db->beginTransaction();
            $account = $this->db->query(
                "SELECT * FROM accounts WHERE id = {$accountId} FOR UPDATE"
            )->fetch(PDO::FETCH_ASSOC);

            if (!$account) { $this->db->rollBack(); return ['success' => false, 'message' => 'Account not found.']; }
            if ((float)$account['balance'] !== 0.0) {
                $this->db->rollBack();
                return ['success' => false, 'message' => 'Account balance must be zero before closing. Current balance: ETB ' . number_format((float)$account['balance'], 2)];
            }

            $this->db->prepare("UPDATE accounts SET status='Closed', closed_date=CURDATE(), closure_reason=:r WHERE id=:id")
                ->execute([':r' => $reason, ':id' => $accountId]);

            $this->audit->log($staffId, 'Account Closed', "Account #{$accountId} closed. Reason: {$reason}");
            $this->db->commit();
            return ['success' => true, 'message' => 'Account closed successfully.'];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            return ['success' => false, 'message' => 'Failed to close account.'];
        }
    }

    private function generateAccountNumber(int $branchId, string $accountType): string
    {
        $typeCode = match($accountType) {
            'Savings'      => '1',
            'Current'      => '2',
            'Fixed Deposit'=> '3',
            default        => '9',
        };
        $branchCode = str_pad((string)$branchId, 3, '0', STR_PAD_LEFT);
        // Get next sequence for this branch+type
        $result = $this->db->query(
            "SELECT COUNT(*)+1 AS seq FROM accounts
             WHERE branch_id={$branchId} AND account_type='{$accountType}'"
        )->fetch(PDO::FETCH_ASSOC);
        $seq = str_pad((string)($result['seq'] ?? 1), 9, '0', STR_PAD_LEFT);
        return "{$typeCode}00{$branchCode}{$seq}";
    }

    private function getInterestRate(string $accountType): float
    {
        return match($accountType) {
            'Savings'       => 3.5,
            'Fixed Deposit' => 8.5,
            default         => 0.0,
        };
    }
}
