<?php
declare(strict_types=1);
namespace App\Services;

use PDO;

/**
 * AuditService — records every significant action into audit_logs.
 * Intentionally lightweight so it can be called from any service/controller.
 */
class AuditService
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function log(
        ?int $userId,
        string $eventType,
        string $description,
        ?string $ipAddress = null,
        ?array $meta = null
    ): void {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO audit_logs (user_id, event_type, description, ip_address, meta)
                 VALUES (:uid, :type, :desc, :ip, :meta)"
            );
            $stmt->execute([
                ':uid'  => $userId,
                ':type' => $eventType,
                ':desc' => $description,
                ':ip'   => $ipAddress ?? ($_SERVER['REMOTE_ADDR'] ?? null),
                ':meta' => $meta ? json_encode($meta) : null,
            ]);
        } catch (\Throwable $e) {
            // Never let audit failure break the main flow
            error_log('AuditService::log failed: ' . $e->getMessage());
        }
    }

    public function logLogin(int $userId, string $username, string $status): void
    {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO login_attempts (username, ip_address, user_agent, status, user_id)
                 VALUES (:u, :ip, :ua, :s, :uid)"
            );
            $stmt->execute([
                ':u'   => $username,
                ':ip'  => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                ':ua'  => $_SERVER['HTTP_USER_AGENT'] ?? null,
                ':s'   => $status,
                ':uid' => $userId,
            ]);
        } catch (\Throwable $e) {
            error_log('AuditService::logLogin failed: ' . $e->getMessage());
        }
    }
}
