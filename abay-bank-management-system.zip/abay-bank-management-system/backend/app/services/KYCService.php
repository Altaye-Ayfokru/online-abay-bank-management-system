<?php
declare(strict_types=1);
namespace App\Services;

use PDO;

class KYCService
{
    private PDO $db;
    private AuditService $audit;
    private NotificationService $notify;

    public function __construct(PDO $db)
    {
        $this->db     = $db;
        $this->audit  = new AuditService($db);
        $this->notify = new NotificationService($db);
    }

    /**
     * Verify Fayda/National ID.
     * In production this would call the Fayda API.
     * For this academic project it simulates the check.
     */
    public function verifyIdentity(int $customerId, string $idType, string $idNumber): array
    {
        // Simulate Fayda verification (academic — in production use real API)
        $isValid = $this->simulateFaydaCheck($idNumber);

        $status = $isValid ? 'Success' : 'Failed';
        $score  = $isValid ? 95.0 : 30.0;

        $stmt = $this->db->prepare(
            "INSERT INTO identity_verifications
                (customer_id, verification_type, reference_id, status, score, verified_at)
             VALUES (:cid,:type,:ref,:st,:sc,:at)
             ON DUPLICATE KEY UPDATE status=:st, score=:sc, verified_at=:at"
        );
        $stmt->execute([
            ':cid'  => $customerId,
            ':type' => $idType === 'Fayda' ? 'Fayda' : 'Manual',
            ':ref'  => $idNumber,
            ':st'   => $status,
            ':sc'   => $score,
            ':at'   => $isValid ? date('Y-m-d H:i:s') : null,
        ]);

        if ($isValid) {
            $this->updateKYCStatus($customerId, 'Under_Review', null, $idType, $idNumber);
        }

        return [
            'success'  => $isValid,
            'status'   => $status,
            'score'    => $score,
            'message'  => $isValid ? 'Identity verified successfully.' : 'Identity could not be verified.',
        ];
    }

    /**
     * Upload a KYC document.
     */
    public function uploadDocument(int $customerId, string $docType, array $file): array
    {
        $allowedMimes = ['image/jpeg', 'image/png', 'application/pdf'];
        $maxSize      = 5 * 1024 * 1024; // 5 MB

        if (!in_array($file['type'], $allowedMimes)) {
            return ['success' => false, 'message' => 'Only JPEG, PNG, and PDF files are allowed.'];
        }
        if ($file['size'] > $maxSize) {
            return ['success' => false, 'message' => 'File size must not exceed 5 MB.'];
        }

        $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'kyc_' . $customerId . '_' . $docType . '_' . time() . '.' . strtolower($ext);
        $dir      = ROOT_PATH . '/backend/storage/uploads/kyc/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $path = $dir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $path)) {
            return ['success' => false, 'message' => 'Failed to save file. Check server write permissions.'];
        }

        $stmt = $this->db->prepare(
            "INSERT INTO customer_documents
                (customer_id, doc_type, filename, original_name, file_size, mime_type, path, status)
             VALUES (:cid,:type,:fname,:orig,:size,:mime,:path,'Pending')"
        );
        $stmt->execute([
            ':cid'   => $customerId,
            ':type'  => $docType,
            ':fname' => $filename,
            ':orig'  => $file['name'],
            ':size'  => $file['size'],
            ':mime'  => $file['type'],
            ':path'  => '/storage/uploads/kyc/' . $filename,
        ]);

        return ['success' => true, 'message' => 'Document uploaded successfully.', 'filename' => $filename];
    }

    /**
     * Approve KYC for a customer.
     */
    public function approveKYC(int $customerId, int $reviewerId): array
    {
        $this->updateKYCStatus($customerId, 'Verified', $reviewerId);
        $this->db->prepare("UPDATE customers SET kyc_status='Verified' WHERE id=:id")->execute([':id' => $customerId]);
        $this->audit->log($reviewerId, 'KYC Approved', "Customer #{$customerId} KYC approved by staff #{$reviewerId}");
        $this->notify->notify(0, 'kyc', 'KYC Verified', 'Your identity has been verified. You can now access all banking services.', 'Normal');
        return ['success' => true, 'message' => 'KYC approved.'];
    }

    public function rejectKYC(int $customerId, int $reviewerId, string $reason): array
    {
        $this->updateKYCStatus($customerId, 'Rejected', $reviewerId, null, null, $reason);
        $this->db->prepare("UPDATE customers SET kyc_status='Rejected' WHERE id=:id")->execute([':id' => $customerId]);
        $this->audit->log($reviewerId, 'KYC Rejected', "Customer #{$customerId} KYC rejected. Reason: {$reason}");
        return ['success' => true, 'message' => 'KYC rejected.'];
    }

    private function updateKYCStatus(
        int $customerId, string $status, ?int $verifier = null,
        ?string $idType = null, ?string $idNum = null, ?string $reason = null
    ): void {
        $stmt = $this->db->prepare(
            "INSERT INTO kyc_records
                (customer_id, id_type, national_id, kyc_status, verified_by, verified_at, rejection_reason)
             VALUES (:cid,:idt,:idn,:st,:vb,:vat,:reason)
             ON DUPLICATE KEY UPDATE
                kyc_status=:st, verified_by=:vb, verified_at=:vat, rejection_reason=:reason"
        );
        $stmt->execute([
            ':cid'    => $customerId,
            ':idt'    => $idType ?? 'National_ID',
            ':idn'    => $idNum,
            ':st'     => $status,
            ':vb'     => $verifier,
            ':vat'    => $verifier ? date('Y-m-d H:i:s') : null,
            ':reason' => $reason,
        ]);
    }

    /** Academic simulation of Fayda API response */
    private function simulateFaydaCheck(string $idNumber): bool
    {
        // All IDs starting with FYD- or ET1 pass (demo mode)
        return str_starts_with($idNumber, 'FYD-')
            || str_starts_with($idNumber, 'ET1')
            || str_starts_with($idNumber, 'ET2')
            || strlen($idNumber) >= 10;
    }
}
