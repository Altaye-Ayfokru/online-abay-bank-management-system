<?php
declare(strict_types=1);
namespace App\Services;

use PDO;
use PDOException;

class LoanService
{
    private PDO $db;
    private TransactionService $txn;
    private AuditService $audit;
    private NotificationService $notify;

    public function __construct(PDO $db)
    {
        $this->db     = $db;
        $this->txn    = new TransactionService($db);
        $this->audit  = new AuditService($db);
        $this->notify = new NotificationService($db);
    }

    /**
     * Calculate EMI using standard reducing-balance formula.
     * EMI = P * r * (1+r)^n / ((1+r)^n - 1)
     */
    public function calculateEMI(float $principal, float $annualRate, int $termMonths): array
    {
        if ($termMonths <= 0 || $principal <= 0) {
            return ['success' => false, 'message' => 'Invalid parameters.'];
        }
        $r = ($annualRate / 100) / 12;
        if ($r === 0.0) {
            $emi = $principal / $termMonths;
        } else {
            $emi = $principal * $r * pow(1 + $r, $termMonths) / (pow(1 + $r, $termMonths) - 1);
        }
        $totalPayable = $emi * $termMonths;
        $totalInterest = $totalPayable - $principal;

        return [
            'success'        => true,
            'emi'            => round($emi, 2),
            'total_payable'  => round($totalPayable, 2),
            'total_interest' => round($totalInterest, 2),
            'principal'      => $principal,
            'rate'           => $annualRate,
            'term_months'    => $termMonths,
        ];
    }

    /**
     * Approve a loan application and (optionally) disburse immediately.
     */
    public function approveLoan(int $loanId, float $approvedAmount, ?int $officerId = null, bool $disburseNow = false): array
    {
        try {
            $this->db->beginTransaction();

            $loan = $this->db->query("SELECT * FROM loans WHERE id={$loanId} FOR UPDATE")->fetch(PDO::FETCH_ASSOC);
            if (!$loan) { $this->db->rollBack(); return ['success' => false, 'message' => 'Loan not found.']; }
            if ($loan['status'] !== 'Pending') { $this->db->rollBack(); return ['success' => false, 'message' => "Loan is already {$loan['status']}."]; }

            $emiData = $this->calculateEMI($approvedAmount, (float)$loan['interest_rate'], (int)$loan['term_months']);

            $this->db->prepare(
                "UPDATE loans SET status='Approved', approved_amount=:amt, emi=:emi,
                    approved_by=:by, approved_at=NOW(), outstanding=:amt WHERE id=:id"
            )->execute([':amt' => $approvedAmount, ':emi' => $emiData['emi'], ':by' => $officerId, ':id' => $loanId]);

            // Write approval step
            $this->db->prepare(
                "INSERT INTO loan_approvals (loan_id, step, action, actor_id, note)
                 VALUES (:lid, 2, 'Approved', :uid, 'Loan approved')"
            )->execute([':lid' => $loanId, ':uid' => $officerId]);

            if ($disburseNow && !empty($loan['account_id'])) {
                $result = $this->disburse($loanId, (int)$loan['account_id'], $approvedAmount, $officerId);
                if (!$result['success']) {
                    $this->db->rollBack();
                    return $result;
                }
            }

            $this->audit->log($officerId, 'Loan Approval', "Loan #{$loanId} approved for ETB {$approvedAmount}");
            $this->db->commit();
            return ['success' => true, 'message' => 'Loan approved.', 'emi' => $emiData['emi']];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            return ['success' => false, 'message' => 'Approval failed.'];
        }
    }

    /**
     * Disburse loan funds to account (inside an already-open DB transaction).
     */
    public function disburse(int $loanId, int $accountId, float $amount, ?int $staffId): array
    {
        // Credit the disbursement to the customer's account
        $ref = $this->txn->generateRef('DIS');
        $stmt = $this->db->prepare(
            "SELECT balance FROM accounts WHERE id=:id FOR UPDATE"
        );
        $stmt->execute([':id' => $accountId]);
        $account = $stmt->fetch(PDO::FETCH_ASSOC);
        $before = (float)($account['balance'] ?? 0);
        $after  = $before + $amount;

        $this->db->prepare("UPDATE accounts SET balance=:b WHERE id=:id")->execute([':b' => $after, ':id' => $accountId]);
        $this->db->prepare(
            "INSERT INTO transactions
                (account_id, reference, type, amount, balance_before, balance_after, description, status)
             VALUES (:aid,:ref,'Loan Disbursement',:amt,:bb,:ba,'Loan disbursement','Completed')"
        )->execute([':aid' => $accountId, ':ref' => $ref, ':amt' => $amount, ':bb' => $before, ':ba' => $after]);

        $this->db->prepare(
            "UPDATE loans SET status='Disbursed', disbursed_date=CURDATE(), next_due_date=DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
             WHERE id=:id"
        )->execute([':id' => $loanId]);

        return ['success' => true, 'reference' => $ref];
    }

    /**
     * Process a loan repayment.
     */
    public function makePayment(int $loanId, int $fromAccountId, float $amount, ?int $staffId = null): array
    {
        try {
            $this->db->beginTransaction();

            $loan = $this->db->query("SELECT * FROM loans WHERE id={$loanId} FOR UPDATE")->fetch(PDO::FETCH_ASSOC);
            if (!$loan || !in_array($loan['status'], ['Active', 'Disbursed'])) {
                $this->db->rollBack();
                return ['success' => false, 'message' => 'Loan not found or not active.'];
            }

            // Withdraw from account
            $withdrawal = $this->txn->withdraw(
                $fromAccountId, $amount,
                "Loan repayment for loan #{$loanId}", $staffId
            );
            if (!$withdrawal['success']) {
                $this->db->rollBack();
                return $withdrawal;
            }

            // Update loan outstanding
            $newOutstanding = max(0, (float)$loan['outstanding'] - $amount);
            $newPaid        = (float)$loan['paid_amount'] + $amount;
            $newStatus      = $newOutstanding <= 0 ? 'Completed' : 'Active';
            $nextDue        = date('Y-m-d', strtotime('+1 month'));

            $this->db->prepare(
                "UPDATE loans SET outstanding=:out, paid_amount=:paid, status=:st, next_due_date=:nd WHERE id=:id"
            )->execute([':out' => $newOutstanding, ':paid' => $newPaid, ':st' => $newStatus, ':nd' => $nextDue, ':id' => $loanId]);

            $this->audit->log($staffId, 'Loan Payment', "Payment ETB {$amount} for loan #{$loanId}. Outstanding: ETB {$newOutstanding}");
            $this->db->commit();

            return [
                'success'         => true,
                'message'         => 'Payment recorded.',
                'paid'            => $amount,
                'outstanding'     => $newOutstanding,
                'loan_status'     => $newStatus,
            ];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            return ['success' => false, 'message' => 'Payment failed.'];
        }
    }
}
