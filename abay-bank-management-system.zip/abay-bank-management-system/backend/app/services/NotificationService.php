<?php
declare(strict_types=1);
namespace App\Services;

use PDO;

class NotificationService
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Create an in-app notification for a user.
     */
    public function notify(
        int $userId,
        string $type,
        string $title,
        string $body,
        string $priority = 'Normal',
        ?string $link = null
    ): void {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO notifications (user_id, type, title, body, priority, link)
                 VALUES (:uid, :type, :title, :body, :pri, :link)"
            );
            $stmt->execute([
                ':uid'   => $userId,
                ':type'  => $type,
                ':title' => $title,
                ':body'  => $body,
                ':pri'   => $priority,
                ':link'  => $link,
            ]);
        } catch (\Throwable $e) {
            error_log('NotificationService::notify failed: ' . $e->getMessage());
        }
    }

    /**
     * Notify multiple users at once.
     */
    public function notifyMany(array $userIds, string $type, string $title, string $body): void
    {
        foreach ($userIds as $uid) {
            $this->notify((int)$uid, $type, $title, $body);
        }
    }

    /**
     * Transaction alert helper — used after every financial transaction.
     */
    public function transactionAlert(int $userId, string $txnType, float $amount, string $accountNo): void
    {
        $amtFormatted = 'ETB ' . number_format($amount, 2);
        $this->notify(
            $userId,
            'transaction',
            ucfirst($txnType) . ' Processed',
            "{$amtFormatted} {$txnType} on account ending {$this->last4($accountNo)} was successful.",
            'Normal'
        );
    }

    private function last4(string $accountNo): string
    {
        return '...' . substr($accountNo, -4);
    }
}
