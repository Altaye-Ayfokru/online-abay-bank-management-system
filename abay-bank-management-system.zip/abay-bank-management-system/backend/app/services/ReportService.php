<?php
declare(strict_types=1);
namespace App\Services;

use PDO;

class ReportService
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function financialSummary(?string $from = null, ?string $to = null): array
    {
        $from = $from ?? date('Y-m-01');
        $to   = $to   ?? date('Y-m-t');

        $row = $this->db->query(
            "SELECT
                COALESCE(SUM(CASE WHEN type='Deposit'     THEN amount END),0) AS total_deposits,
                COALESCE(SUM(CASE WHEN type='Withdrawal'  THEN amount END),0) AS total_withdrawals,
                COALESCE(SUM(CASE WHEN type='Transfer Out'THEN amount END),0) AS total_transfers,
                COALESCE(SUM(CASE WHEN type='Loan Disbursement' THEN amount END),0) AS total_disbursements,
                COALESCE(SUM(CASE WHEN type='Loan Repayment'    THEN amount END),0) AS total_repayments,
                COUNT(*) AS total_transactions
             FROM transactions
             WHERE DATE(created_at) BETWEEN '{$from}' AND '{$to}'
               AND status='Completed'"
        )->fetch(PDO::FETCH_ASSOC);

        $totalBalance = $this->db->query(
            "SELECT COALESCE(SUM(balance),0) AS total FROM accounts WHERE status='Active'"
        )->fetchColumn();

        $row['total_balance']      = (float)$totalBalance;
        $row['period_from']        = $from;
        $row['period_to']          = $to;
        $row['net_cash_flow']      = (float)$row['total_deposits'] - (float)$row['total_withdrawals'];

        return $row;
    }

    public function loanPortfolio(): array
    {
        return $this->db->query(
            "SELECT
                COUNT(*) AS total_loans,
                COALESCE(SUM(amount),0)        AS total_principal,
                COALESCE(SUM(outstanding),0)   AS total_outstanding,
                COALESCE(SUM(paid_amount),0)   AS total_collected,
                COUNT(CASE WHEN status='Active'    THEN 1 END) AS active,
                COUNT(CASE WHEN status='Completed' THEN 1 END) AS completed,
                COUNT(CASE WHEN status='Pending'   THEN 1 END) AS pending,
                COUNT(CASE WHEN status='Rejected'  THEN 1 END) AS rejected,
                AVG(interest_rate) AS avg_rate
             FROM loans"
        )->fetch(PDO::FETCH_ASSOC);
    }

    public function customerGrowth(): array
    {
        return $this->db->query(
            "SELECT
                DATE_FORMAT(created_at,'%Y-%m') AS month,
                COUNT(*) AS new_customers
             FROM customers
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
             GROUP BY month ORDER BY month ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function dailyTransactions(int $days = 30): array
    {
        return $this->db->query(
            "SELECT
                DATE(created_at) AS date,
                COUNT(*) AS count,
                COALESCE(SUM(CASE WHEN type='Deposit'    THEN amount END),0) AS deposits,
                COALESCE(SUM(CASE WHEN type='Withdrawal' THEN amount END),0) AS withdrawals,
                COALESCE(SUM(CASE WHEN type LIKE 'Transfer%' THEN amount END),0) AS transfers
             FROM transactions
             WHERE status='Completed' AND created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
             GROUP BY DATE(created_at) ORDER BY date ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function attendanceSummary(?string $month = null): array
    {
        $month = $month ?? date('Y-m');
        return $this->db->query(
            "SELECT
                COUNT(*) AS total_records,
                COUNT(CASE WHEN status='Present' THEN 1 END) AS present,
                COUNT(CASE WHEN status='Absent'  THEN 1 END) AS absent,
                COUNT(CASE WHEN status='Late'    THEN 1 END) AS late,
                ROUND(COUNT(CASE WHEN status='Present' THEN 1 END)*100.0/NULLIF(COUNT(*),0),1) AS rate
             FROM attendance
             WHERE DATE_FORMAT(date,'%Y-%m')='{$month}'"
        )->fetch(PDO::FETCH_ASSOC);
    }
}
