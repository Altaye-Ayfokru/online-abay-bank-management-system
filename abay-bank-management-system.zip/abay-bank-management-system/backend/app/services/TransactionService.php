<?php
declare(strict_types=1);
namespace App\Services;

use PDO;
use PDOException;

/**
 * TransactionService
 *
 * Every financial operation (deposit, withdrawal, transfer) runs inside
 * a DB transaction so partial failures are impossible:
 *
 *   BEGIN
 *     validate → debit/credit accounts → write transaction record → audit
 *   COMMIT
 *
 *   IF ANY STEP FAILS → ROLLBACK EVERYTHING
 */
class TransactionService
{
    private PDO $db;
    private AuditService $audit;
    private NotificationService $notify;

    public function __construct(PDO $db)
    {
        $this->db     = $db;
        $this->audit  = new AuditService($db);
        $this->notify = new NotificationService($db);
    }

    // ─────────────────────────────────────────────────────────
    //  DEPOSIT
    // ─────────────────────────────────────────────────────────
    public function deposit(int $accountId, float $amount, string $description, ?int $staffId = null): array
    {
        if ($amount <= 0) {
            return ['success' => false, 'message' => 'Deposit amount must be greater than zero.'];
        }

        try {
            $this->db->beginTransaction();

            $account = $this->lockAccount($accountId);
            if (!$account) {
                $this->db->rollBack();
                return ['success' => false, 'message' => 'Account not found.'];
            }
            if ($account['status'] !== 'Active') {
                $this->db->rollBack();
                return ['success' => false, 'message' => "Account is {$account['status']}. Cannot deposit."];
            }

            $balanceBefore = (float)$account['balance'];
            $balanceAfter  = $balanceBefore + $amount;

            $this->updateBalance($accountId, $balanceAfter);
            $ref = $this->generateRef('DEP');
            $txnId = $this->writeTransaction(
                $accountId, $ref, 'Deposit', $amount, $balanceBefore, $balanceAfter, $description
            );

            $this->audit->log($staffId, 'Transaction', "Deposit ETB {$amount} on account #{$accountId}");
            $this->db->commit();

            // Notify customer (fire-and-forget after commit)
            $this->notify->transactionAlert(
                (int)$account['user_id_fk'], 'Deposit', $amount, $account['account_number']
            );

            return [
                'success'        => true,
                'message'        => 'Deposit successful.',
                'transaction_id' => $txnId,
                'reference'      => $ref,
                'balance_before' => $balanceBefore,
                'balance_after'  => $balanceAfter,
            ];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            error_log('TransactionService::deposit error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Transaction failed. Please try again.'];
        }
    }

    // ─────────────────────────────────────────────────────────
    //  WITHDRAWAL
    // ─────────────────────────────────────────────────────────
    public function withdraw(int $accountId, float $amount, string $description, ?int $staffId = null): array
    {
        if ($amount <= 0) {
            return ['success' => false, 'message' => 'Withdrawal amount must be greater than zero.'];
        }

        try {
            $this->db->beginTransaction();

            $account = $this->lockAccount($accountId);
            if (!$account) { $this->db->rollBack(); return ['success' => false, 'message' => 'Account not found.']; }
            if ($account['status'] !== 'Active') { $this->db->rollBack(); return ['success' => false, 'message' => "Account is {$account['status']}."]; }

            $balanceBefore = (float)$account['balance'];

            // Minimum balance check
            $minBalance = 500.00;
            if (($balanceBefore - $amount) < $minBalance) {
                $this->db->rollBack();
                return ['success' => false, 'message' => "Insufficient funds. Minimum balance ETB {$minBalance} must be maintained."];
            }

            $balanceAfter = $balanceBefore - $amount;
            $this->updateBalance($accountId, $balanceAfter);
            $ref   = $this->generateRef('WDR');
            $txnId = $this->writeTransaction(
                $accountId, $ref, 'Withdrawal', $amount, $balanceBefore, $balanceAfter, $description
            );

            $this->audit->log($staffId, 'Transaction', "Withdrawal ETB {$amount} from account #{$accountId}");
            $this->db->commit();

            $this->notify->transactionAlert(
                (int)$account['user_id_fk'], 'Withdrawal', $amount, $account['account_number']
            );

            return [
                'success'        => true,
                'message'        => 'Withdrawal successful.',
                'transaction_id' => $txnId,
                'reference'      => $ref,
                'balance_before' => $balanceBefore,
                'balance_after'  => $balanceAfter,
            ];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            error_log('TransactionService::withdraw error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Transaction failed. Please try again.'];
        }
    }

    // ─────────────────────────────────────────────────────────
    //  TRANSFER  (bulletproof: both debit+credit in one DB txn)
    // ─────────────────────────────────────────────────────────
    public function transfer(
        int $fromAccountId,
        int $toAccountId,
        float $amount,
        string $description,
        ?int $initiatedBy = null
    ): array {
        if ($amount <= 0) return ['success' => false, 'message' => 'Transfer amount must be positive.'];
        if ($fromAccountId === $toAccountId) return ['success' => false, 'message' => 'Cannot transfer to the same account.'];

        try {
            $this->db->beginTransaction();

            // Lock both accounts (always lock lower ID first to prevent deadlock)
            $ids    = [$fromAccountId, $toAccountId];
            $first  = min($ids);
            $second = max($ids);
            $this->lockAccount($first);
            $this->lockAccount($second);

            $sender   = $this->getAccount($fromAccountId);
            $receiver = $this->getAccount($toAccountId);

            if (!$sender)   { $this->db->rollBack(); return ['success' => false, 'message' => 'Sender account not found.']; }
            if (!$receiver) { $this->db->rollBack(); return ['success' => false, 'message' => 'Receiver account not found.']; }
            if ($sender['status'] !== 'Active')   { $this->db->rollBack(); return ['success' => false, 'message' => "Sender account is {$sender['status']}."]; }
            if ($receiver['status'] !== 'Active') { $this->db->rollBack(); return ['success' => false, 'message' => "Receiver account is {$receiver['status']}."]; }

            $senderBefore   = (float)$sender['balance'];
            $receiverBefore = (float)$receiver['balance'];
            $minBalance     = 500.00;

            if (($senderBefore - $amount) < $minBalance) {
                $this->db->rollBack();
                return ['success' => false, 'message' => "Insufficient funds. Available: ETB " . number_format($senderBefore - $minBalance, 2)];
            }

            $senderAfter   = $senderBefore - $amount;
            $receiverAfter = $receiverBefore + $amount;

            // Debit sender
            $this->updateBalance($fromAccountId, $senderAfter);
            $debitRef = $this->generateRef('TRF');
            $debitId  = $this->writeTransaction(
                $fromAccountId, $debitRef, 'Transfer Out', $amount,
                $senderBefore, $senderAfter,
                "Transfer to {$receiver['account_number']}: {$description}"
            );

            // Credit receiver
            $this->updateBalance($toAccountId, $receiverAfter);
            $creditRef = $this->generateRef('TRF');
            $creditId  = $this->writeTransaction(
                $toAccountId, $creditRef, 'Transfer In', $amount,
                $receiverBefore, $receiverAfter,
                "Transfer from {$sender['account_number']}: {$description}"
            );

            // Write to transfers table for audit trail
            $transferRef = 'XFER-' . strtoupper(substr(uniqid(), -8));
            $stmt = $this->db->prepare(
                "INSERT INTO transfers
                    (reference, from_account_id, to_account_id, amount, description,
                     debit_txn_id, credit_txn_id, initiated_by, status, completed_at)
                 VALUES (:ref,:from,:to,:amt,:desc,:deb,:cred,:by,'Completed',NOW())"
            );
            $stmt->execute([
                ':ref'  => $transferRef,
                ':from' => $fromAccountId,
                ':to'   => $toAccountId,
                ':amt'  => $amount,
                ':desc' => $description,
                ':deb'  => $debitId,
                ':cred' => $creditId,
                ':by'   => $initiatedBy,
            ]);
            $transferId = (int)$this->db->lastInsertId();

            $this->audit->log($initiatedBy, 'Transfer', "Transfer ETB {$amount} from #{$fromAccountId} to #{$toAccountId}");
            $this->db->commit();

            // Notify both parties after successful commit
            $this->notify->transactionAlert((int)$sender['user_id_fk'],   'Transfer Out', $amount, $sender['account_number']);
            $this->notify->transactionAlert((int)$receiver['user_id_fk'], 'Transfer In',  $amount, $receiver['account_number']);

            return [
                'success'       => true,
                'message'       => 'Transfer successful.',
                'transfer_id'   => $transferId,
                'reference'     => $transferRef,
                'debit_ref'     => $debitRef,
                'credit_ref'    => $creditRef,
                'sender_balance'   => $senderAfter,
                'receiver_balance' => $receiverAfter,
            ];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            error_log('TransactionService::transfer error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Transfer failed. No funds were moved.'];
        }
    }

    // ─────────────────────────────────────────────────────────
    //  REVERSAL
    // ─────────────────────────────────────────────────────────
    public function reverse(int $transactionId, ?int $staffId = null): array
    {
        try {
            $this->db->beginTransaction();

            $txn = $this->db->query("SELECT * FROM transactions WHERE id = {$transactionId} FOR UPDATE")->fetch(PDO::FETCH_ASSOC);
            if (!$txn) { $this->db->rollBack(); return ['success' => false, 'message' => 'Transaction not found.']; }
            if ($txn['status'] !== 'Completed') { $this->db->rollBack(); return ['success' => false, 'message' => 'Only completed transactions can be reversed.']; }

            $account = $this->lockAccount((int)$txn['account_id']);
            $balance = (float)$account['balance'];
            $amount  = (float)$txn['amount'];

            // Reverse: flip the direction
            if ($txn['type'] === 'Deposit' || $txn['type'] === 'Transfer In') {
                $newBalance = $balance - $amount;
            } else {
                $newBalance = $balance + $amount;
            }

            $this->updateBalance((int)$txn['account_id'], $newBalance);

            // Mark original as Reversed
            $this->db->prepare("UPDATE transactions SET status='Reversed' WHERE id = :id")->execute([':id' => $transactionId]);

            // Write reversal transaction
            $ref   = $this->generateRef('REV');
            $revId = $this->writeTransaction(
                (int)$txn['account_id'], $ref, 'Reversal', $amount, $balance, $newBalance,
                "Reversal of transaction #{$transactionId} ref {$txn['reference']}"
            );

            $this->audit->log($staffId, 'Reversal', "Transaction #{$transactionId} reversed by staff #{$staffId}");
            $this->db->commit();

            return ['success' => true, 'message' => 'Transaction reversed.', 'reversal_id' => $revId, 'reference' => $ref];

        } catch (PDOException $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            return ['success' => false, 'message' => 'Reversal failed.'];
        }
    }

    // ─────────────────────────────────────────────────────────
    //  PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────
    private function lockAccount(int $id): array|false
    {
        return $this->db->query(
            "SELECT a.*, c.user_id AS user_id_fk
             FROM accounts a
             LEFT JOIN customers c ON c.id = a.customer_id
             WHERE a.id = {$id} FOR UPDATE"
        )->fetch(PDO::FETCH_ASSOC);
    }

    private function getAccount(int $id): array|false
    {
        return $this->db->query(
            "SELECT a.*, c.user_id AS user_id_fk
             FROM accounts a
             LEFT JOIN customers c ON c.id = a.customer_id
             WHERE a.id = {$id}"
        )->fetch(PDO::FETCH_ASSOC);
    }

    private function updateBalance(int $accountId, float $balance): void
    {
        $stmt = $this->db->prepare("UPDATE accounts SET balance = :b WHERE id = :id");
        $stmt->execute([':b' => $balance, ':id' => $accountId]);
    }

    private function writeTransaction(
        int $accountId, string $ref, string $type, float $amount,
        float $before, float $after, string $desc, string $status = 'Completed'
    ): int {
        $stmt = $this->db->prepare(
            "INSERT INTO transactions
                (account_id, reference, type, amount, balance_before, balance_after, description, status)
             VALUES (:aid, :ref, :type, :amt, :bb, :ba, :desc, :st)"
        );
        $stmt->execute([
            ':aid'  => $accountId, ':ref' => $ref,   ':type' => $type,
            ':amt'  => $amount,    ':bb'  => $before, ':ba'  => $after,
            ':desc' => $desc,      ':st'  => $status,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function generateRef(string $prefix): string
    {
        return $prefix . '-' . strtoupper(substr(uniqid(), -8)) . '-' . date('Ymd');
    }
}
