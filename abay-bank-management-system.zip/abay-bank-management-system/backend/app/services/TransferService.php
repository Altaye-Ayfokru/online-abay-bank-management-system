<?php
declare(strict_types=1);
namespace App\Services;

use PDO;

/**
 * TransferService — delegates to TransactionService for the actual
 * atomic debit+credit, but adds transfer-specific logic:
 * beneficiary validation, transfer limits, fee calculation.
 */
class TransferService
{
    private PDO $db;
    private TransactionService $txn;
    private AuditService $audit;

    public function __construct(PDO $db)
    {
        $this->db    = $db;
        $this->txn   = new TransactionService($db);
        $this->audit = new AuditService($db);
    }

    /**
     * Own-account transfer (same customer, different accounts).
     */
    public function ownTransfer(int $fromId, int $toId, float $amount, string $desc, int $customerId): array
    {
        // Verify both accounts belong to this customer
        $count = $this->db->query(
            "SELECT COUNT(*) FROM accounts
             WHERE id IN ({$fromId},{$toId}) AND customer_id={$customerId}"
        )->fetchColumn();
        if ((int)$count !== 2) {
            return ['success' => false, 'message' => 'Both accounts must belong to you.'];
        }
        return $this->txn->transfer($fromId, $toId, $amount, $desc, $customerId);
    }

    /**
     * Internal Abay Bank transfer (any two accounts in the system).
     */
    public function internalTransfer(int $fromId, int $toAccountNumber, float $amount, string $desc, int $initiatedBy): array
    {
        // Look up receiver by account number
        $receiver = $this->db->query(
            "SELECT id FROM accounts WHERE account_number='{$toAccountNumber}' AND status='Active'"
        )->fetch(PDO::FETCH_ASSOC);
        if (!$receiver) {
            return ['success' => false, 'message' => 'Destination account not found or inactive.'];
        }
        $fee = $this->calculateFee('Internal', $amount);
        if ($fee > 0) {
            // Deduct fee from sender (simple: reduce effective transfer or charge separately)
        }
        $result = $this->txn->transfer($fromId, (int)$receiver['id'], $amount, $desc, $initiatedBy);
        $result['fee'] = $fee;
        return $result;
    }

    /**
     * Save a beneficiary for a customer.
     */
    public function saveBeneficiary(int $customerId, array $data): array
    {
        $stmt = $this->db->prepare(
            "INSERT INTO beneficiaries
                (customer_id, nickname, account_number, account_name, bank_name, bank_code, account_type)
             VALUES (:cid,:nick,:acct,:name,:bank,:code,:type)"
        );
        $stmt->execute([
            ':cid'  => $customerId,
            ':nick' => $data['nickname'],
            ':acct' => $data['account_number'],
            ':name' => $data['account_name'],
            ':bank' => $data['bank_name'] ?? 'Abay Bank',
            ':code' => $data['bank_code'] ?? null,
            ':type' => $data['account_type'] ?? null,
        ]);
        return ['success' => true, 'message' => 'Beneficiary saved.', 'id' => (int)$this->db->lastInsertId()];
    }

    private function calculateFee(string $type, float $amount): float
    {
        return match($type) {
            'Internal'    => 0.0,
            'InterBranch' => min(50.0, $amount * 0.001),
            'RTGS'        => 100.0,
            'EFT'         => 25.0,
            default       => 0.0,
        };
    }
}
