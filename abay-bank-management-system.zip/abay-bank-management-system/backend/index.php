<?php

/**
 * Abay Bank Management System — Backend Entry Point
 * PHP 8.0+ | MVC Architecture
 */

declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH',  ROOT_PATH . '/backend/app');
define('START_TIME', microtime(true));

/* ── Autoloader (vendor) ── */
require_once ROOT_PATH . '/vendor/autoload.php';

/* ── Manually require app classes ── */
require_once APP_PATH . '/config/Database.php';
require_once APP_PATH . '/helpers/Response.php';
require_once APP_PATH . '/helpers/JwtHelper.php';
require_once APP_PATH . '/helpers/Validator.php';
require_once APP_PATH . '/middleware/AuthMiddleware.php';
require_once APP_PATH . '/core/Router.php';
require_once APP_PATH . '/models/UserModel.php';
require_once APP_PATH . '/models/AccountModel.php';
require_once APP_PATH . '/models/CustomerModel.php';
require_once APP_PATH . '/models/EmployeeModel.php';
require_once APP_PATH . '/models/LoanModel.php';
require_once APP_PATH . '/models/TransactionModel.php';

/* ── Auto-require all controllers ── */
foreach (glob(APP_PATH . '/controllers/*.php') as $controllerFile) {
  require_once $controllerFile;
}

/* Auto-load all controllers */
foreach (glob(APP_PATH . '/controllers/*.php') as $controller) {
  require_once $controller;
}

/* ── Environment ── */
$dotenv = Dotenv\Dotenv::createImmutable(ROOT_PATH);
$dotenv->safeLoad();

/* ── Error handling ── */
$env = $_ENV['APP_ENV'] ?? 'production';
if ($env === 'development') {
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
} else {
  error_reporting(0);
  ini_set('display_errors', '0');
}

/* ── Bootstrap (CORS, headers, session) ── */
require_once APP_PATH . '/config/Bootstrap.php';

/* ── Route ── */
$router = require_once APP_PATH . '/routes/api.php';
$router->dispatch();
