# Abay Bank — Customer Self-Service Portal

A complete standalone PHP portal for Abay Bank customers — online banking, transfers, loans, KYC, and more.

## Access URL
```
http://localhost/abay-bank-management-system/customer-portal/
```

## Demo Credentials

| Username | Password | Account Type |
|---|---|---|
| `abebe.bekele` | `Customer@1234` | Savings + Fixed Deposit |
| `tigist.haile` | `Customer@1234` | Savings |
| `solomon.girma` | `Customer@1234` | Current + Savings |

> **Demo mode**: Works without a database. All pages show realistic data using built-in fallbacks.  
> **Live mode**: Connects to the shared `abay_bank` MySQL database automatically.

## Setup (with database)

1. Import the main system schema and seed data:
   ```sql
   SOURCE /path/to/abay-bank-management-system/database/schema.sql;
   SOURCE /path/to/abay-bank-management-system/database/seed.sql;
   ```
2. Copy `.env.example` to `.env` in the project root and fill in your DB credentials
3. Ensure `customer-portal/uploads/` is writable:
   ```bash
   chmod -R 755 customer-portal/uploads/
   ```
4. Visit `http://localhost/abay-bank-management-system/customer-portal/`

## Features

| Section | Pages |
|---|---|
| **Auth** | Sign In, Sign Up, Forgot Password |
| **Dashboard** | Balance cards, Quick actions, Transaction chart, Recent activity |
| **Profile** | View, Edit, Photo Upload, Change Password, Security settings |
| **Accounts** | List all accounts, Account details & mini-statement |
| **Transactions** | Full history, Filter by type/date, Transaction detail receipt |
| **Transfers** | Abay Bank transfer, Own account transfer |
| **Deposits** | Deposit request & history |
| **Withdrawals** | Withdrawal request & history |
| **Loans** | Active loans, Apply for loan, Repayment schedule |
| **Statements** | Monthly statement download (PDF-ready) |
| **KYC** | Document status, Upload supporting documents |
| **Cards** | ATM/Debit card status, request new card |
| **Appointments** | Book branch appointment, upcoming appointments |
| **Complaints** | Submit complaint, track ticket status with bank responses |
| **Notifications** | List all, mark read/unread, filter unread |
| **Beneficiaries** | Add/remove saved transfer recipients, live account verify |
| **Messages** | Inbox, Sent, Compose to bank departments |
| **Settings** | Password change, 2FA toggles, Notification prefs, Preferences, Sessions |

## API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `api/transfers/validate-account.php` | GET | Verify account number, return holder name |
| `api/accounts/balance.php` | GET | Get account balance (authenticated) |
| `api/dashboard/statistics.php` | GET | Full dashboard stats + monthly chart data |
| `api/notifications/unread.php` | GET | Unread notification count for badge |

## Structure

```
customer-portal/
├── index.php                  ← Entry point (redirect to dashboard or login)
├── .htaccess                  ← Security headers, block sensitive dirs
├── README.md
│
├── auth/
│   ├── login.php              ← Sign in + Sign up tabs
│   ├── logout.php
│   └── forgot-password.php
│
├── config/
│   ├── config.php             ← Bootstrap, constants, helpers
│   ├── constants.php          ← CP_NAME, CP_BASE_URL, CP_BASE_PATH
│   └── database.php           ← CP_Database class (static, PDO)
│
├── middleware/
│   ├── auth.php               ← cp_guard(), cp_is_logged_in(), cp_customer()
│   └── csrf.php               ← cp_csrf_field(), cp_csrf_check()
│
├── includes/
│   ├── header.php             ← HTML head + topbar + sidebar open
│   ├── sidebar.php            ← Full navigation sidebar with live balance
│   ├── footer.php             ← Scripts + HTML close
│   ├── alerts.php             ← Alert components
│   └── functions.php          ← cp_e(), cp_etb(), cp_badge(), cp_ago(), cp_date(),
│                                 cp_full_name(), cp_initials(), cp_avatar(),
│                                 cp_demo_accounts(), cp_demo_transactions(),
│                                 cp_loan_schedule()
│
├── customer/
│   ├── dashboard.php
│   ├── profile/               ← index, edit, upload-photo, security
│   ├── accounts/              ← index, details
│   ├── transactions/          ← index, details
│   ├── transfers/             ← index, abay-bank, own-account
│   ├── deposits/              ← index
│   ├── withdrawals/           ← index
│   ├── loans/                 ← index, application, repayment
│   ├── statements/            ← index
│   ├── kyc/                   ← index, upload-document
│   ├── cards/                 ← index
│   ├── appointments/          ← index
│   ├── complaints/            ← index, create
│   ├── notifications/         ← index
│   ├── beneficiaries/         ← index
│   ├── messages/              ← index
│   └── settings/              ← index
│
├── api/
│   ├── transfers/validate-account.php
│   ├── accounts/balance.php
│   ├── dashboard/statistics.php
│   └── notifications/unread.php
│
├── assets/
│   ├── css/
│   │   ├── main.css           ← Base styles (cp- prefix)
│   │   ├── sidebar.css        ← Sidebar layout
│   │   └── dashboard.css      ← Dashboard cards & charts
│   └── js/
│       ├── app.js             ← CP global object: toast, confirm, modal, api
│       └── dashboard.js       ← Charts, balance refresh, quick actions
│
└── uploads/
    ├── .htaccess              ← Blocks PHP execution in uploads
    ├── profiles/              ← Customer profile photos
    ├── kyc/                   ← KYC identity documents
    └── documents/             ← Complaint attachments, general docs
```

## Technical Notes

| Detail | Value |
|---|---|
| **Session key** | `cp_session` |
| **DB class** | `CP_Database` (static, PDO, shares `abay_bank` DB) |
| **Auth helper** | `cp_guard()` — returns `$customer` array or redirects to login |
| **CSS prefix** | All classes start with `cp-` to avoid conflicts with main app |
| **JS object** | `CP` — `CP.toast()`, `CP.confirm()`, `CP.openModal()`, `CP.api()` |
| **Upload limit** | 5 MB per file (PDF, JPG, PNG, WEBP) |
| **PHP version** | 8.0+ required |

## Security

- Session-based authentication with 2-hour timeout
- CSRF protection on all POST forms via `cp_csrf_field()` / `cp_csrf_check()`
- Passwords hashed with `password_hash()` (bcrypt, `PASSWORD_DEFAULT`)
- File uploads: MIME type validation, size limits, PHP execution blocked in `uploads/`
- Input sanitization via `cp_e()` (`htmlspecialchars`, `ENT_QUOTES`, `UTF-8`)
- Sensitive directories (`config/`, `middleware/`, `includes/`) blocked via `.htaccess`
- Security headers: `X-Content-Type-Options`, `X-Frame-Options`, `X-XSS-Protection`, `Referrer-Policy`
- `credentials: 'include'` on all fetch/AJAX calls

## Connecting to the Home Page

The home page (`app/views/home/index.php`) links to this portal in three places:

- **Navbar** — "Customer" button → `customer-portal/auth/login.php`
- **Hero** — "Online Banking" button → `customer-portal/auth/login.php`
- **Portals section** — "Sign In to Online Banking" → `customer-portal/auth/login.php`
