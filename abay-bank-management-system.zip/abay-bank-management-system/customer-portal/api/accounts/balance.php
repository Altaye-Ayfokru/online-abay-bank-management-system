<?php
/**
 * API: Get account balance
 * GET /api/accounts/balance.php?account_id=X
 * Returns: { success, data: { balance, available_balance, currency, account_number } }
 */
require_once dirname(__DIR__, 2) . '/config/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store');

if (!cp_is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$customer = cp_customer();
$custId   = (int)($customer['id'] ?? 0);
$accId    = (int)($_GET['account_id'] ?? 0);

if (!$accId) {
    echo json_encode(['success' => false, 'message' => 'account_id is required']);
    exit;
}

// Verify the account belongs to this customer
$rows = CP_Database::query(
    "SELECT id, account_number, account_type, balance, available_balance, currency, status
     FROM accounts WHERE id=? AND customer_id=? LIMIT 1",
    [$accId, $custId]
);

if ($rows) {
    $a = $rows[0];
    if ($a['status'] !== 'Active') {
        echo json_encode(['success' => false, 'message' => 'Account is not active']);
        exit;
    }
    echo json_encode([
        'success' => true,
        'data'    => [
            'balance'           => (float)($a['balance'] ?? 0),
            'available_balance' => (float)($a['available_balance'] ?? $a['balance'] ?? 0),
            'currency'          => $a['currency'] ?? 'ETB',
            'account_number'    => $a['account_number'] ?? '',
            'account_type'      => $a['account_type']   ?? '',
            'formatted'         => 'ETB ' . number_format((float)($a['balance'] ?? 0), 2),
        ],
    ]);
    exit;
}

// Demo fallback
$demoAccounts = cp_demo_accounts($custId);
foreach ($demoAccounts as $a) {
    if ((int)($a['id'] ?? 0) === $accId) {
        echo json_encode(['success' => true, 'data' => ['balance' => (float)$a['balance'], 'available_balance' => (float)$a['balance'], 'currency' => 'ETB', 'account_number' => $a['account_number'], 'account_type' => $a['account_type'], 'formatted' => 'ETB ' . number_format((float)$a['balance'], 2)]]);
        exit;
    }
}

http_response_code(404);
echo json_encode(['success' => false, 'message' => 'Account not found']);
