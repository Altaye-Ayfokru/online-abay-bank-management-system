<?php
/**
 * API: Dashboard statistics
 * GET /api/dashboard/statistics.php
 * Returns: { success, data: { total_balance, accounts, recent_transactions, ... } }
 */
require_once dirname(__DIR__, 2) . '/config/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store');

if (!cp_is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$customer = cp_customer();
$custId   = (int)($customer['id'] ?? 0);

// Total balance
$balRow    = CP_Database::query("SELECT SUM(balance) AS total FROM accounts WHERE customer_id=? AND status='Active'", [$custId]);
$totalBal  = (float)($balRow[0]['total'] ?? 0);

// Account count
$accCount  = CP_Database::query("SELECT COUNT(*) AS cnt FROM accounts WHERE customer_id=?", [$custId]);
$accounts  = (int)($accCount[0]['cnt'] ?? 0);

// Active loans
$loanRow   = CP_Database::query("SELECT COUNT(*) AS cnt, SUM(outstanding_balance) AS os FROM loans WHERE customer_id=? AND status='Active'", [$custId]);
$loanCount = (int)($loanRow[0]['cnt'] ?? 0);
$loanOS    = (float)($loanRow[0]['os'] ?? 0);

// Transactions this month
$txnRow    = CP_Database::query("SELECT COUNT(*) AS cnt, SUM(CASE WHEN t.type IN ('Deposit','Transfer In') THEN t.amount ELSE 0 END) AS income, SUM(CASE WHEN t.type NOT IN ('Deposit','Transfer In') THEN t.amount ELSE 0 END) AS expense FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND MONTH(t.created_at)=MONTH(NOW()) AND YEAR(t.created_at)=YEAR(NOW())", [$custId]);
$txnCount  = (int)($txnRow[0]['cnt'] ?? 0);
$income    = (float)($txnRow[0]['income'] ?? 0);
$expense   = (float)($txnRow[0]['expense'] ?? 0);

// Monthly chart data (last 6 months)
$monthlyData = [];
for ($i = 5; $i >= 0; $i--) {
    $mo   = date('Y-m', strtotime("-$i months"));
    $label= date('M Y', strtotime("-$i months"));
    $row  = CP_Database::query("SELECT SUM(CASE WHEN t.type IN ('Deposit','Transfer In') THEN t.amount ELSE 0 END) AS inc, SUM(CASE WHEN t.type NOT IN ('Deposit','Transfer In') THEN t.amount ELSE 0 END) AS exp FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND DATE_FORMAT(t.created_at,'%Y-%m')=?", [$custId, $mo]);
    $monthlyData[] = ['month' => $label, 'income' => (float)($row[0]['inc'] ?? 0), 'expense' => (float)($row[0]['exp'] ?? 0)];
}

// Recent transactions
$recentTxns = CP_Database::query("SELECT t.type, t.amount, t.description, t.created_at FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? ORDER BY t.created_at DESC LIMIT 5", [$custId]) ?: [];

// Pending KYC docs
$kycPending = CP_Database::query("SELECT COUNT(*) AS cnt FROM customer_documents WHERE customer_id=? AND status='Pending'", [$custId]);
$kycCount   = (int)($kycPending[0]['cnt'] ?? 0);

// Unread notifications
$notifRow   = CP_Database::query("SELECT COUNT(*) AS cnt FROM notifications WHERE customer_id=? AND is_read=0", [$custId]);
$notifCount = (int)($notifRow[0]['cnt'] ?? 0);

// Demo fallback values if DB returns nothing
if ($totalBal === 0.0 && $accounts === 0) {
    $demoAccounts = cp_demo_accounts($custId);
    $totalBal     = array_sum(array_column($demoAccounts, 'balance'));
    $accounts     = count($demoAccounts);
    $txnCount     = 8;
    $income       = 45000;
    $expense      = 12500;
    $notifCount   = 2;
    $monthlyData  = array_map(fn($i) => ['month' => date('M Y', strtotime("-$i months")), 'income' => rand(20000, 80000), 'expense' => rand(5000, 25000)], range(5, 0));
}

echo json_encode([
    'success' => true,
    'data'    => [
        'total_balance'       => $totalBal,
        'total_balance_fmt'   => 'ETB ' . number_format($totalBal, 2),
        'accounts'            => $accounts,
        'active_loans'        => $loanCount,
        'loan_outstanding'    => $loanOS,
        'transactions_month'  => $txnCount,
        'income_month'        => $income,
        'expense_month'       => $expense,
        'unread_notifications'=> $notifCount,
        'kyc_pending_docs'    => $kycCount,
        'kyc_status'          => $customer['kyc_status'] ?? 'Pending',
        'monthly_chart'       => $monthlyData,
        'recent_transactions' => $recentTxns,
    ],
]);
