<?php
/**
 * API: Get unread notification count
 * GET /api/notifications/unread.php
 * Returns: { success, count }
 * Used by the sidebar/topbar to show the notification badge
 */
require_once dirname(__DIR__, 2) . '/config/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, max-age=0');

if (!cp_is_logged_in()) {
    // Return 0 rather than 401 — avoids console errors on public pages
    echo json_encode(['success' => true, 'count' => 0]);
    exit;
}

$customer = cp_customer();
$custId   = (int)($customer['id'] ?? 0);

$row = CP_Database::query(
    "SELECT COUNT(*) AS cnt FROM notifications WHERE customer_id=? AND is_read=0",
    [$custId]
);

$count = (int)($row[0]['cnt'] ?? 0);

// If no DB result, return a demo count of 2 so the badge shows in demo mode
if ($row === false || $row === null) {
    $count = 2;
}

echo json_encode(['success' => true, 'count' => $count]);
