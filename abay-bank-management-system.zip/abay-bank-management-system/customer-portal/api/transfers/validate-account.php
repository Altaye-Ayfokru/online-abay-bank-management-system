<?php
/**
 * API: Validate account number for transfers
 * GET /api/transfers/validate-account.php?account_number=XXXX
 * Returns: { success, data: { customer_name, account_type, bank } }
 */
require_once dirname(__DIR__, 2) . '/config/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store');

// Must be logged in
if (!cp_is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Only GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$accNo = trim($_GET['account_number'] ?? '');
if (!$accNo) {
    echo json_encode(['success' => false, 'message' => 'account_number is required']);
    exit;
}

// Sanitize — only digits allowed
if (!preg_match('/^\d{6,20}$/', $accNo)) {
    echo json_encode(['success' => false, 'message' => 'Invalid account number format']);
    exit;
}

// Look up in DB
$rows = CP_Database::query(
    "SELECT a.account_number, a.account_type, c.first_name, c.last_name, c.middle_name
     FROM accounts a
     JOIN customers c ON c.id = a.customer_id
     WHERE a.account_number = ? AND a.status = 'Active'
     LIMIT 1",
    [$accNo]
);

if ($rows) {
    $r    = $rows[0];
    $name = trim(($r['first_name'] ?? '') . ' ' . ($r['middle_name'] ? $r['middle_name'] . ' ' : '') . ($r['last_name'] ?? ''));
    echo json_encode([
        'success' => true,
        'data'    => [
            'customer_name' => $name ?: 'Account Holder',
            'account_type'  => $r['account_type'] ?? 'Savings',
            'bank'          => 'Abay Bank S.C.',
        ],
    ]);
    exit;
}

// Demo fallback — mask real data but still return plausible response for testing
$demoAccounts = ['1000012345678', '1000098765432', '1000055512345'];
if (in_array($accNo, $demoAccounts)) {
    $demoNames = ['1000012345678' => 'Abebe Bekele', '1000098765432' => 'Tigist Haile', '1000055512345' => 'Solomon Girma'];
    echo json_encode(['success' => true, 'data' => ['customer_name' => $demoNames[$accNo], 'account_type' => 'Savings', 'bank' => 'Abay Bank S.C.']]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Account not found or inactive']);
