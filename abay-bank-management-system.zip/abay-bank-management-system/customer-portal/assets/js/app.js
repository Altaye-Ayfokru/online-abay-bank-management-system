/* ============================================================
   ABAY BANK — Customer Portal Core JS
   ============================================================ */
'use strict';

const CP = {
  baseUrl: document.querySelector('meta[name="cp-base-url"]')?.content || '/customer-portal',

  toast(msg, type='info', duration=3500) {
    const colors={success:'#22c55e',danger:'#ef4444',warning:'#f59e0b',info:'#3b82f6',ok:'#22c55e',err:'#ef4444'};
    const icons={success:'fa-circle-check',danger:'fa-circle-xmark',warning:'fa-triangle-exclamation',info:'fa-circle-info',ok:'fa-circle-check',err:'fa-circle-xmark'};
    let c=document.getElementById('cp-toast-container');
    if (!c){c=document.createElement('div');c.id='cp-toast-container';c.style.cssText='position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';document.body.appendChild(c);}
    const t=document.createElement('div');
    const clr=colors[type]||colors.info, ic=icons[type]||icons.info;
    t.style.cssText=`background:#fff;border-left:4px solid ${clr};border-radius:10px;padding:13px 16px;box-shadow:0 8px 32px rgba(0,0,0,.14);min-width:260px;max-width:360px;display:flex;align-items:center;gap:10px;font-size:.85rem;font-weight:500;pointer-events:all;transform:translateX(120%);transition:transform .3s;`;
    t.innerHTML=`<i class="fa-solid ${ic}" style="color:${clr};font-size:1rem;flex-shrink:0"></i><span>${msg}</span>`;
    c.appendChild(t);
    requestAnimationFrame(()=>{t.style.transform='translateX(0)';});
    setTimeout(()=>{t.style.transform='translateX(120%)';setTimeout(()=>t.remove(),350);},duration);
  },

  setBtn(id, loading, label='') {
    const btn=typeof id==='string'?document.getElementById(id):id;
    if (!btn) return;
    if (loading){btn._orig=btn.innerHTML;btn.disabled=true;btn.innerHTML=`<i class="fa-solid fa-spinner" style="animation:cp-spin 1s linear infinite"></i> ${label||'Loading…'}`;}
    else{btn.disabled=false;btn.innerHTML=label||btn._orig||'Submit';}
  },

  confirm(msg, onOk, opts={}) {
    const ov=document.createElement('div');
    ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9998;display:flex;align-items:center;justify-content:center;padding:20px;';
    ov.innerHTML=`<div style="background:#fff;border-radius:16px;padding:28px 28px 20px;max-width:420px;width:100%;box-shadow:0 24px 64px rgba(0,0,0,.2)"><div style="font-size:1rem;font-weight:700;color:#1e293b;margin-bottom:10px">${opts.title||'Confirm'}</div><p style="font-size:.87rem;color:#64748b;margin-bottom:20px">${msg}</p><div style="display:flex;gap:10px;justify-content:flex-end"><button id="cp-cf-cancel" style="padding:9px 20px;border-radius:9px;border:2px solid #e2e8f0;background:none;cursor:pointer;font-size:.86rem;font-weight:600">Cancel</button><button id="cp-cf-ok" style="padding:9px 20px;border-radius:9px;border:none;background:${opts.danger?'#ef4444':'#1B3A5C'};color:#fff;cursor:pointer;font-size:.86rem;font-weight:700">${opts.okLabel||'Confirm'}</button></div></div>`;
    document.body.appendChild(ov);
    ov.querySelector('#cp-cf-cancel').onclick=()=>ov.remove();
    ov.querySelector('#cp-cf-ok').onclick=()=>{ov.remove();onOk();};
    ov.onclick=e=>{if(e.target===ov)ov.remove();};
  },

  openModal(id){document.getElementById(id)?.classList.add('open');},
  closeModal(id){document.getElementById(id)?.classList.remove('open');},

  async api(endpoint, opts={}) {
    const defaults={credentials:'include',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'}};
    try{const r=await fetch(this.baseUrl+'/api'+endpoint,{...defaults,...opts,headers:{...defaults.headers,...(opts.headers||{})}});return await r.json();}
    catch{return null;}
  },

  formatETB(n){return 'ETB '+Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2});},
  formatNum(n){return Number(n||0).toLocaleString();},

  init() {
    this.initSidebar();
    this.initModals();
    this.startClock();
    this.highlightNav();
  },

  initSidebar() {
    const sb=document.getElementById('cp-sidebar');
    const bd=document.getElementById('cp-sb-backdrop');
    const hb=document.getElementById('cp-hamburger');
    hb?.addEventListener('click',()=>{sb?.classList.toggle('open');bd?.classList.toggle('show');});
    bd?.addEventListener('click',()=>{sb?.classList.remove('open');bd?.classList.remove('show');});
  },

  initModals() {
    document.querySelectorAll('.cp-modal-overlay').forEach(ov=>{
      ov.addEventListener('click',e=>{if(e.target===ov)ov.classList.remove('open');});
    });
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape')document.querySelectorAll('.cp-modal-overlay.open').forEach(m=>m.classList.remove('open'));
    });
  },

  startClock() {
    const el=document.getElementById('cp-clock');
    if (!el) return;
    const update=()=>{el.textContent=new Date().toLocaleTimeString('en-ET',{hour:'2-digit',minute:'2-digit'});};
    update(); setInterval(update,30000);
  },

  highlightNav() {
    const path=window.location.pathname;
    document.querySelectorAll('.cp-sb-link').forEach(a=>{
      const href=a.getAttribute('href')||'';
      const rel=href.replace(/^.*customer-portal/,'');
      if(rel&&path.includes(rel)&&rel.length>2)a.classList.add('active');
    });
  }
};

// Add spinner keyframe style
const cpStyle=document.createElement('style');
cpStyle.textContent='@keyframes cp-spin{to{transform:rotate(360deg);}}';
document.head.appendChild(cpStyle);

document.addEventListener('DOMContentLoaded',()=>CP.init());
