/* Customer Portal Dashboard JS */
'use strict';

document.addEventListener('DOMContentLoaded', function() {
  if (!window.Chart) return;

  // Balance/Transaction chart
  const ctx = document.getElementById('balance-chart');
  if (ctx) {
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Mar','Apr','May','Jun','Jul','Aug'],
        datasets: [
          {label:'Balance (ETB K)',data:[120,135,128,155,142,157],borderColor:'#007A8A',backgroundColor:'rgba(0,122,138,.1)',fill:true,tension:.4,pointRadius:4},
          {label:'Spending (ETB K)',data:[8,12,9,15,10,8.5],borderColor:'#C8A84B',backgroundColor:'rgba(200,168,75,.08)',fill:true,tension:.4,pointRadius:4}
        ]
      },
      options:{responsive:true,plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:false}}}
    });
  }

  // Transaction type pie
  const ctx2 = document.getElementById('txn-type-chart');
  if (ctx2) {
    new Chart(ctx2,{type:'doughnut',data:{labels:['Deposits','Withdrawals','Transfers','Loans'],datasets:[{data:[45,25,20,10],backgroundColor:['#22c55e','#ef4444','#3b82f6','#f59e0b']}]},options:{responsive:true,plugins:{legend:{position:'bottom'}}}});
  }
});
