<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/csrf.php';
$sent=false; $error=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
    cp_csrf_check();
    $email = trim($_POST['email']??'');
    if (!filter_var($email,FILTER_VALIDATE_EMAIL)) { $error='Please enter a valid email address.'; }
    else { $sent=true; /* In production: send reset email */ }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Forgot Password — <?= CP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#1B3A5C,#007A8A);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;}
.box{background:#fff;border-radius:20px;padding:44px;max-width:440px;width:100%;box-shadow:0 24px 80px rgba(0,0,0,.25);}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:28px;}
.bars{display:flex;align-items:flex-end;gap:3px;background:#f1f5f9;border-radius:8px;padding:6px 8px 8px;}
.b{border-radius:2px 2px 0 0;display:block;}
.b1{width:5px;height:14px;background:#C8A84B;}.b2{width:5px;height:19px;background:#007A8A;}.b3{width:5px;height:24px;background:#1B3A5C;}.b4{width:5px;height:14px;background:#007A8A;}
h2{font-size:1.45rem;font-weight:800;color:#1B3A5C;margin-bottom:6px;}
p{font-size:.85rem;color:#64748b;margin-bottom:22px;line-height:1.6;}
.fg{margin-bottom:16px;}.lbl{display:block;font-size:.8rem;font-weight:600;color:#374151;margin-bottom:5px;}
.inp-w{position:relative;}.ic{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.88rem;pointer-events:none;}
.inp{width:100%;padding:11px 13px 11px 38px;border:2px solid #e2e8f0;border-radius:10px;font-size:.88rem;font-family:inherit;outline:none;transition:.2s;}
.inp:focus{border-color:#007A8A;box-shadow:0 0 0 3px rgba(0,122,138,.1);}
.btn{width:100%;padding:13px;background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;border:none;border-radius:11px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:9px;}
.alert-err{background:#fee2e2;border:1px solid #fecaca;color:#991b1b;padding:11px 14px;border-radius:9px;font-size:.84rem;margin-bottom:16px;}
.success-box{text-align:center;padding:20px 0;}
.back{text-align:center;margin-top:18px;font-size:.82rem;color:#64748b;}
.back a{color:#007A8A;font-weight:600;}
</style>
</head>
<body>
<div class="box">
  <div class="brand">
    <div class="bars"><span class="b b1"></span><span class="b b2"></span><span class="b b3"></span><span class="b b4"></span></div>
    <div><div style="font-size:.85rem;font-weight:800;color:#1B3A5C">Abay Bank</div><div style="font-size:.65rem;color:#007A8A;font-weight:600;text-transform:uppercase;letter-spacing:.08em">Online Banking</div></div>
  </div>
  <?php if ($sent): ?>
  <div class="success-box">
    <i class="fa-solid fa-envelope-circle-check" style="font-size:3rem;color:#22c55e;display:block;margin-bottom:14px"></i>
    <h2>Check Your Email</h2>
    <p>If that email is registered, we've sent password reset instructions. Check your inbox and spam folder.</p>
    <a href="<?= CP_BASE_URL ?>/auth/login.php" class="btn" style="text-decoration:none;margin-top:8px"><i class="fa-solid fa-arrow-left"></i> Back to Sign In</a>
  </div>
  <?php else: ?>
  <h2>Forgot Password?</h2>
  <p>Enter your registered email and we'll send a password reset link.</p>
  <?php if ($error): ?><div class="alert-err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST">
    <?= cp_csrf_field() ?>
    <div class="fg"><label class="lbl">Email Address</label>
      <div class="inp-w"><i class="fa-solid fa-envelope ic"></i><input type="email" name="email" class="inp" placeholder="yourname@email.com" required></div></div>
    <button type="submit" class="btn"><i class="fa-solid fa-paper-plane"></i> Send Reset Link</button>
  </form>
  <div class="back"><a href="<?= CP_BASE_URL ?>/auth/login.php"><i class="fa-solid fa-arrow-left"></i> Back to Sign In</a></div>
  <?php endif; ?>
</div>
</body>
</html>
