<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once dirname(__DIR__) . '/middleware/csrf.php';

if (cp_is_logged_in()) { header('Location: ' . CP_BASE_URL . '/customer/dashboard.php'); exit; }

$error   = cp_get_flash('danger');
$success = cp_get_flash('success');
$tab     = $_GET['tab'] ?? 'signin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cp_csrf_check();
    $action = $_POST['_action'] ?? 'signin';

    /* ── SIGN IN ── */
    if ($action === 'signin') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        if (!$username || !$password) { $error='Username and password are required.'; }
        else {
            $customer = null;
            $db = CP_Database::get();
            if ($db) {
                try {
                    // Try customer_users table (online banking accounts)
                    $row = CP_Database::queryOne(
                        "SELECT cu.*, c.first_name, c.last_name, c.customer_number, c.phone,
                                c.email AS cust_email, c.kyc_status, c.status AS cust_status,
                                c.date_of_birth, c.gender, c.address, c.branch_id, c.id AS customer_id,
                                c.national_id, c.photo_path
                         FROM customer_users cu
                         JOIN customers c ON c.id = cu.customer_id
                         WHERE (cu.username=? OR cu.email=?) AND c.status='Active'
                         LIMIT 1",
                        [$username, $username]
                    );
                    if ($row && password_verify($password, $row['password_hash'] ?? $row['password'] ?? '')) {
                        $customer = $row;
                        $customer['id'] = $row['customer_id'];
                        CP_Database::execute("UPDATE customer_users SET last_login=NOW() WHERE id=?", [$row['id']]);
                    }
                } catch (Throwable) {}
            }
            // Demo fallback
            if (!$customer) {
                $demos = [
                    'abebe.bekele' => ['id'=>1,'customer_number'=>'CUST-A1B2C3D','first_name'=>'Abebe','last_name'=>'Bekele','email'=>'abebe.bekele@email.com','phone'=>'+251911234567','kyc_status'=>'Verified','status'=>'Active','date_of_birth'=>'1990-05-15','gender'=>'Male','address'=>'Bole Sub-City','branch_id'=>3 /* Alem Ketema */,'national_id'=>'ET12345678','photo_path'=>null],
                    'tigist.haile' => ['id'=>2,'customer_number'=>'CUST-E4F5G6H','first_name'=>'Tigist','last_name'=>'Haile','email'=>'tigist.haile@email.com','phone'=>'+251912345678','kyc_status'=>'Verified','status'=>'Active','date_of_birth'=>'1988-08-22','gender'=>'Female','address'=>'Kirkos Sub-City','branch_id'=>2,'national_id'=>'ET23456789','photo_path'=>null],
                    'solomon.girma'=> ['id'=>3,'customer_number'=>'CUST-I7J8K9L','first_name'=>'Solomon','last_name'=>'Girma','email'=>'solomon.girma@email.com','phone'=>'+251933456789','kyc_status'=>'Pending','status'=>'Active','date_of_birth'=>'1992-03-10','gender'=>'Male','address'=>'Arada Sub-City','branch_id'=>3 /* Alem Ketema */,'national_id'=>'ET34567890','photo_path'=>null],
                ];
                $pwds = ['abebe.bekele'=>'Customer@1234','tigist.haile'=>'Customer@1234','solomon.girma'=>'Customer@1234'];
                $key  = strtolower(trim($username));
                if (isset($demos[$key]) && $pwds[$key] === $password) $customer = $demos[$key];
            }
            if ($customer) {
                cp_login_customer($customer);
                $redir = $_SESSION['cp_redirect_after'] ?? CP_BASE_URL . '/customer/dashboard.php';
                unset($_SESSION['cp_redirect_after']);
                header('Location: ' . $redir); exit;
            } else {
                $error = 'Invalid username or password. Use the demo credentials below.';
                $tab   = 'signin';
            }
        }
    }

    /* ── SIGN UP ── */
    if ($action === 'signup') {
        $tab       = 'signup';
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName  = trim($_POST['last_name']  ?? '');
        $phone     = trim($_POST['phone']      ?? '');
        $email     = trim($_POST['email']      ?? '');
        $username  = strtolower(trim($_POST['username'] ?? ''));
        $password  = $_POST['password']        ?? '';
        $confirm   = $_POST['confirm_password']?? '';
        $dob       = trim($_POST['dob']        ?? '');
        $gender    = trim($_POST['gender']     ?? '');
        $national  = trim($_POST['national_id']?? '');

        $errs = [];
        if (!$firstName)  $errs[] = 'First name required.';
        if (!$lastName)   $errs[] = 'Last name required.';
        if (!$phone)      $errs[] = 'Phone number required.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Valid email required.';
        if (strlen($username) < 4) $errs[] = 'Username must be 4+ characters.';
        if (strlen($password) < 8) $errs[] = 'Password must be 8+ characters.';
        if ($password !== $confirm) $errs[] = 'Passwords do not match.';

        if ($errs) { $error = implode(' ', $errs); }
        else {
            $db = CP_Database::get();
            if ($db) {
                // Check phone uniqueness in customers
                $exists = CP_Database::queryOne("SELECT id FROM customers WHERE phone=? LIMIT 1", [$phone]);
                if ($exists) { $error = 'Phone number already registered.'; }
                else {
                    // Create customer record
                    $custNo = 'CUST-' . strtoupper(substr(uniqid('',true),-7));
                    CP_Database::execute(
                        "INSERT INTO customers (customer_number,first_name,last_name,phone,email,date_of_birth,gender,national_id,kyc_status,status,created_at)
                         VALUES (?,?,?,?,?,?,?,?,'Pending','Active',NOW())",
                        [$custNo,$firstName,$lastName,$phone,$email,$dob?:null,$gender,$national?:null]
                    );
                    $custId = CP_Database::lastId();
                    // Create customer_users account
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    CP_Database::execute(
                        "INSERT INTO customer_users (customer_id,username,email,password_hash,created_at) VALUES (?,?,?,?,NOW())",
                        [$custId,$username,$email,$hash]
                    );
                    cp_flash('success', "Account created for {$firstName}! Please sign in.");
                    header('Location: ' . CP_BASE_URL . '/auth/login.php'); exit;
                }
            } else {
                // Demo mode
                cp_flash('success', "Demo: Account for {$firstName} {$lastName} created! Sign in with demo credentials.");
                header('Location: ' . CP_BASE_URL . '/auth/login.php'); exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Sign In — <?= CP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{--navy:#1B3A5C;--teal:#007A8A;--gold:#C8A84B;}
html,body{height:100%;font-family:'Inter',sans-serif;}
body{display:flex;min-height:100vh;background:#f0f4f8;align-items:center;justify-content:center;padding:16px;}
.wrap{display:flex;max-width:1060px;width:100%;background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 24px 80px rgba(27,58,92,.22);}
/* Left */
.left{flex:1.15;background:linear-gradient(160deg,#1B3A5C,#007A8A);padding:52px 44px;color:#fff;display:flex;flex-direction:column;justify-content:space-between;position:relative;overflow:hidden;}
.left::before{content:'';position:absolute;top:-100px;right:-100px;width:380px;height:380px;background:radial-gradient(circle,rgba(200,168,75,.18),transparent 70%);border-radius:50%;}
.left::after{content:'';position:absolute;bottom:-80px;left:-60px;width:280px;height:280px;background:radial-gradient(circle,rgba(0,122,138,.2),transparent 70%);border-radius:50%;}
.logo-row{display:flex;align-items:center;gap:13px;margin-bottom:32px;position:relative;z-index:2;}
.logo-bars{display:flex;align-items:flex-end;gap:4px;background:rgba(255,255,255,.12);border-radius:10px;padding:8px 10px 10px;}
.b{border-radius:2px 2px 0 0;display:block;}
.b1{width:6px;height:18px;background:#C8A84B;}.b2{width:6px;height:24px;background:#7ecfd8;}.b3{width:6px;height:30px;background:#fff;}.b4{width:6px;height:18px;background:#7ecfd8;}
.logo-am{font-size:1.05rem;font-weight:800;}.logo-en{font-size:.72rem;color:#C8A84B;font-weight:600;letter-spacing:.1em;text-transform:uppercase;}
.headline{font-size:2rem;font-weight:800;line-height:1.2;margin-bottom:14px;position:relative;z-index:2;}
.headline span{color:#C8A84B;}
.sub{font-size:.88rem;opacity:.8;line-height:1.7;margin-bottom:32px;position:relative;z-index:2;}
.feats{display:flex;flex-direction:column;gap:11px;position:relative;z-index:2;}
.feat{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:12px 14px;}
.feat-ic{width:34px;height:34px;background:#C8A84B;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#1B3A5C;font-size:.85rem;flex-shrink:0;}
.left-foot{font-size:.72rem;opacity:.45;margin-top:28px;position:relative;z-index:2;}
/* Right */
.right{flex:1;padding:44px;display:flex;flex-direction:column;justify-content:center;overflow-y:auto;max-height:100vh;}
.form-tag{font-size:.7rem;font-weight:700;color:var(--teal);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:9px;}
.tabs{display:flex;background:#f1f5f9;border-radius:12px;padding:4px;margin-bottom:22px;gap:4px;}
.tab{flex:1;padding:10px;border:none;background:none;border-radius:9px;font-size:.87rem;font-weight:600;cursor:pointer;color:#64748b;transition:.2s;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:7px;}
.tab.active{background:#fff;color:var(--navy);box-shadow:0 1px 4px rgba(0,0,0,.1);}
.demo-box{background:linear-gradient(135deg,#e0f5f7,#f0fafb);border:1px solid #b3e4e9;border-radius:12px;padding:13px 15px;margin-bottom:18px;}
.demo-title{font-size:.7rem;font-weight:700;color:var(--teal);text-transform:uppercase;letter-spacing:.8px;margin-bottom:9px;}
.demo-row{display:grid;grid-template-columns:140px 1fr 1fr;gap:8px;padding:6px 8px;border-radius:7px;cursor:pointer;font-size:.8rem;align-items:center;transition:.2s;}
.demo-row:hover{background:rgba(0,122,138,.1);}
.dr-role{font-weight:700;color:var(--navy);}.dr-user{color:#475569;}.dr-pass{font-family:monospace;color:var(--teal);font-size:.78rem;}
.alert-err{display:flex;align-items:flex-start;gap:9px;padding:11px 14px;border-radius:9px;font-size:.84rem;margin-bottom:16px;background:#fee2e2;border:1px solid #fecaca;color:#991b1b;}
.alert-ok{display:flex;align-items:flex-start;gap:9px;padding:11px 14px;border-radius:9px;font-size:.84rem;margin-bottom:16px;background:#dcfce7;border:1px solid #a7f3d0;color:#065f46;}
.fg{margin-bottom:14px;}
.lbl{display:block;font-size:.8rem;font-weight:600;color:#374151;margin-bottom:5px;}
.inp-w{position:relative;}
.inp-ic{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.88rem;pointer-events:none;}
.inp{width:100%;padding:11px 13px 11px 38px;border:2px solid #e2e8f0;border-radius:10px;font-size:.88rem;font-family:inherit;outline:none;transition:.2s;}
.inp:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(0,122,138,.1);}
.inp-noi{padding-left:13px;}
.eye-btn{position:absolute;right:11px;top:50%;transform:translateY(-50%);background:none;border:none;color:#94a3b8;cursor:pointer;}
.form-row2{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.hint{font-size:.72rem;color:#94a3b8;margin-top:3px;}
.foot-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;font-size:.82rem;}
.foot-row a{color:var(--teal);font-weight:600;}
.btn-submit{width:100%;padding:13px;background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff;border:none;border-radius:11px;font-size:.95rem;font-weight:700;cursor:pointer;transition:.3s;display:flex;align-items:center;justify-content:center;gap:9px;font-family:inherit;}
.btn-submit:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,122,138,.35);}
.btn-submit:disabled{opacity:.65;cursor:not-allowed;transform:none;}
.switch-ln{text-align:center;font-size:.82rem;color:#64748b;margin-top:14px;}
.switch-ln a{color:var(--teal);font-weight:600;}
.str-bar{height:4px;background:#e2e8f0;border-radius:2px;margin-top:6px;overflow:hidden;}
.str-fill{height:100%;border-radius:2px;transition:.3s;}
.portal-links{display:flex;justify-content:center;gap:16px;margin-top:20px;padding-top:16px;border-top:1px solid #f1f5f9;font-size:.79rem;}
.portal-links a{color:#94a3b8;display:flex;align-items:center;gap:5px;text-decoration:none;}
.portal-links a:hover{color:var(--navy);}
@keyframes spin{to{transform:rotate(360deg);}}
@media(max-width:800px){.left{display:none;}.right{padding:32px 24px;}}
</style>
</head>
<body>
<div class="wrap">

  <!-- Left panel -->
  <div class="left">
    <div>
      <div class="logo-row">
        <div class="logo-bars"><span class="b b1"></span><span class="b b2"></span><span class="b b3"></span><span class="b b4"></span></div>
        <div><div class="logo-am">ዓባይ ባንክ</div><div class="logo-en">Abay Bank S.C.</div></div>
      </div>
      <h1 class="headline">Your Bank,<br><span>Anytime.</span><br>Anywhere.</h1>
      <p class="sub">Manage your accounts, transfer funds, pay bills, apply for loans — all in one secure, modern banking portal.</p>
      <div class="feats">
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-shield-halved"></i></div><span style="font-size:.8rem;font-weight:500">Bank-grade security &amp; encryption</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-right-left"></i></div><span style="font-size:.8rem;font-weight:500">Instant transfers — Abay, EthSwitch, Telebirr</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-file-lines"></i></div><span style="font-size:.8rem;font-weight:500">Statements, receipts &amp; loan schedules</span></div>
        <div class="feat"><div class="feat-ic"><i class="fa-solid fa-id-card"></i></div><span style="font-size:.8rem;font-weight:500">Fayda / National ID KYC verification</span></div>
      </div>
    </div>
    <div class="left-foot">© <?= date('Y') ?> Abay Bank S.C. &middot; NBE Licensed &middot; SWIFT: ABYAETAA &middot; Customer Portal v1.0</div>
  </div>

  <!-- Right panel -->
  <div class="right">
    <div class="form-tag"><i class="fa-solid fa-user"></i> &nbsp;Customer Online Banking</div>

    <div class="tabs" id="auth-tabs">
      <button class="tab <?= $tab==='signin'?'active':'' ?>" onclick="switchTab('signin')" id="tab-si"><i class="fa-solid fa-right-to-bracket"></i> Sign In</button>
      <button class="tab <?= $tab==='signup'?'active':'' ?>" onclick="switchTab('signup')" id="tab-su"><i class="fa-solid fa-user-plus"></i> Open Account</button>
    </div>

    <!-- Demo credentials -->
    <div class="demo-box" id="demo-box" <?= $tab==='signup'?'style="display:none"':'' ?>>
      <div class="demo-title"><i class="fa-solid fa-circle-info"></i> Demo Credentials — click to fill</div>
      <div class="demo-row" onclick="fill('abebe.bekele','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings + Current</span><span class="dr-user">abebe.bekele</span><span class="dr-pass">Customer@1234</span></div>
      <div class="demo-row" onclick="fill('tigist.haile','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings + Loan</span><span class="dr-user">tigist.haile</span><span class="dr-pass">Customer@1234</span></div>
      <div class="demo-row" onclick="fill('solomon.girma','Customer@1234')"><span class="dr-role"><i class="fa-solid fa-user"></i> Savings</span><span class="dr-user">solomon.girma</span><span class="dr-pass">Customer@1234</span></div>
    </div>

    <?php if ($error): ?><div class="alert-err"><i class="fa-solid fa-circle-xmark"></i><span><?= htmlspecialchars($error) ?></span></div><?php endif; ?>
    <?php if ($success): ?><div class="alert-ok"><i class="fa-solid fa-circle-check"></i><span><?= htmlspecialchars($success) ?></span></div><?php endif; ?>

    <!-- SIGN IN -->
    <div id="panel-si" <?= $tab==='signup'?'style="display:none"':'' ?>>
      <h2 style="font-size:1.5rem;font-weight:800;color:var(--navy);margin-bottom:4px">Welcome Back</h2>
      <p style="font-size:.84rem;color:#64748b;margin-bottom:20px">Sign in to your online banking account</p>
      <form method="POST" id="si-form">
        <?= cp_csrf_field() ?>
        <input type="hidden" name="_action" value="signin">
        <div class="fg"><label class="lbl">Username / Email</label>
          <div class="inp-w"><i class="fa-solid fa-user inp-ic"></i><input type="text" name="username" id="si-user" class="inp" placeholder="Enter username or email" required autocomplete="username"></div></div>
        <div class="fg"><label class="lbl">Password</label>
          <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i><input type="password" name="password" id="si-pass" class="inp" placeholder="Your password" required autocomplete="current-password">
          <button type="button" class="eye-btn" onclick="togglePw('si-pass',this)"><i class="fa-solid fa-eye"></i></button></div></div>
        <div class="foot-row">
          <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:.82rem"><input type="checkbox" name="remember"> Remember me</label>
          <a href="<?= CP_BASE_URL ?>/auth/forgot-password.php">Forgot password?</a>
        </div>
        <button type="submit" class="btn-submit" id="si-btn"><i class="fa-solid fa-right-to-bracket"></i> Sign In</button>
      </form>
      <div class="switch-ln">No account? <a href="#" onclick="switchTab('signup');return false">Open one now — it's free</a></div>
    </div>

    <!-- SIGN UP / OPEN ACCOUNT -->
    <div id="panel-su" <?= $tab==='signin'?'style="display:none"':'' ?>>
      <h2 style="font-size:1.4rem;font-weight:800;color:var(--navy);margin-bottom:4px">Open Your Account</h2>
      <p style="font-size:.84rem;color:#64748b;margin-bottom:18px">Register for Abay Bank Online Banking in minutes</p>
      <form method="POST" id="su-form">
        <?= cp_csrf_field() ?>
        <input type="hidden" name="_action" value="signup">
        <div class="form-row2">
          <div class="fg"><label class="lbl">First Name *</label><div class="inp-w"><i class="fa-solid fa-user inp-ic"></i><input type="text" name="first_name" class="inp" placeholder="Abebe" required value="<?= htmlspecialchars($_POST['first_name']??'') ?>"></div></div>
          <div class="fg"><label class="lbl">Last Name *</label><div class="inp-w"><i class="fa-solid fa-user inp-ic"></i><input type="text" name="last_name" class="inp" placeholder="Girma" required value="<?= htmlspecialchars($_POST['last_name']??'') ?>"></div></div>
        </div>
        <div class="form-row2">
          <div class="fg"><label class="lbl">Phone *</label><div class="inp-w"><i class="fa-solid fa-phone inp-ic"></i><input type="tel" name="phone" class="inp" placeholder="+251 9XX XXX XXX" required></div></div>
          <div class="fg"><label class="lbl">Email *</label><div class="inp-w"><i class="fa-solid fa-envelope inp-ic"></i><input type="email" name="email" class="inp" placeholder="yourname@email.com" required></div></div>
        </div>
        <div class="form-row2">
          <div class="fg"><label class="lbl">Date of Birth</label><input type="date" name="dob" class="inp inp-noi" max="<?= date('Y-m-d',strtotime('-18 years')) ?>"></div>
          <div class="fg"><label class="lbl">Gender</label><select name="gender" class="inp inp-noi"><option value="">Select…</option><option>Male</option><option>Female</option></select></div>
        </div>
        <div class="fg"><label class="lbl">National ID (Optional)</label><div class="inp-w"><i class="fa-solid fa-id-card inp-ic"></i><input type="text" name="national_id" class="inp" placeholder="ET12345678"></div></div>
        <div class="fg"><label class="lbl">Username *</label><div class="inp-w"><i class="fa-solid fa-at inp-ic"></i><input type="text" name="username" class="inp" placeholder="firstname.lastname" required minlength="4"></div></div>
        <div class="fg"><label class="lbl">Password *</label>
          <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i><input type="password" name="password" id="su-pass" class="inp" placeholder="Min. 8 characters" required minlength="8" oninput="checkStr(this.value)">
          <button type="button" class="eye-btn" onclick="togglePw('su-pass',this)"><i class="fa-solid fa-eye"></i></button></div>
          <div class="str-bar"><div class="str-fill" id="str-fill" style="width:0%"></div></div></div>
        <div class="fg"><label class="lbl">Confirm Password *</label>
          <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i><input type="password" name="confirm_password" id="su-cf" class="inp" placeholder="Repeat password" required oninput="checkMatch()"></div>
          <div class="hint" id="match-msg"></div></div>
        <button type="submit" class="btn-submit" id="su-btn"><i class="fa-solid fa-user-plus"></i> Create Account</button>
      </form>
      <div class="switch-ln">Already have an account? <a href="#" onclick="switchTab('signin');return false">Sign In</a></div>
    </div>

    <div class="portal-links">
      <a href="/abay-bank-management-system/"><i class="fa-solid fa-house"></i> Home</a>
      <a href="/abay-bank-management-system/employee-portal/"><i class="fa-solid fa-id-badge"></i> Employee Portal</a>
      <a href="/abay-bank-management-system/login"><i class="fa-solid fa-shield-halved"></i> Staff Portal</a>
    </div>
  </div>
</div>
<script>
function switchTab(t){
  var isSi=t==='signin';
  document.getElementById('panel-si').style.display=isSi?'':'none';
  document.getElementById('panel-su').style.display=isSi?'none':'';
  document.getElementById('demo-box').style.display=isSi?'':'none';
  document.getElementById('tab-si').className='tab'+(isSi?' active':'');
  document.getElementById('tab-su').className='tab'+(!isSi?' active':'');
}
function fill(u,p){document.getElementById('si-user').value=u;document.getElementById('si-pass').value=p;}
function togglePw(id,btn){var i=document.getElementById(id);i.type=i.type==='password'?'text':'password';btn.querySelector('i').className='fa-solid '+(i.type==='password'?'fa-eye':'fa-eye-slash');}
function checkStr(v){var s=0;if(v.length>=8)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^a-zA-Z0-9]/.test(v))s++;var c=['','#ef4444','#f59e0b','#3b82f6','#22c55e'][s]||'';document.getElementById('str-fill').style.cssText='width:'+(s*25)+'%;background:'+c;}
function checkMatch(){var pw=document.getElementById('su-pass').value,cf=document.getElementById('su-cf').value,el=document.getElementById('match-msg');if(!cf){el.textContent='';return;}el.textContent=pw===cf?'✓ Passwords match':'✗ Do not match';el.style.color=pw===cf?'#22c55e':'#ef4444';}
document.getElementById('si-form').addEventListener('submit',function(){var b=document.getElementById('si-btn');b.disabled=true;b.innerHTML='<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Signing in…';});
document.getElementById('su-form').addEventListener('submit',function(e){if(document.getElementById('su-pass').value!==document.getElementById('su-cf').value){e.preventDefault();alert('Passwords do not match');return;}var b=document.getElementById('su-btn');b.disabled=true;b.innerHTML='<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Creating…';});
</script>
</body>
</html>
