<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
cp_logout();
cp_flash('success', 'You have been signed out successfully.');
header('Location: ' . CP_BASE_URL . '/auth/login.php'); exit;
