<?php
/** Abay Bank — Customer Portal Bootstrap */
error_reporting(E_ALL);
ini_set('display_errors', '1'); // show errors in dev
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs/error.log');

require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(CP_SESSION_NAME);
    session_set_cookie_params(['lifetime'=>CP_SESSION_TIMEOUT,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
if (empty($_SESSION['_cp_init'])) {
    session_regenerate_id(true);
    $_SESSION['_cp_init'] = true;
}
date_default_timezone_set('Africa/Addis_Ababa');
require_once __DIR__ . '/../includes/functions.php';
