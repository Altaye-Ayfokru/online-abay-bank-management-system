<?php
/**
 * Abay Bank — Customer Portal Constants
 */
define('CP_VERSION',    '1.0.0');
define('CP_NAME',       'Abay Bank Customer Portal');
define('CP_BASE_URL',   'http://localhost/abay-bank-management-system/customer-portal');
define('CP_BASE_PATH',  dirname(__DIR__));
define('CP_UPLOAD_PATH', CP_BASE_PATH . '/uploads');
define('CP_ASSET_URL',   CP_BASE_URL  . '/assets');

// Session
define('CP_SESSION_NAME',    'cp_session');
define('CP_SESSION_TIMEOUT', 7200); // 2 hours

// Upload limits
define('CP_MAX_FILE_SIZE',  10 * 1024 * 1024); // 10 MB
define('CP_ALLOWED_IMAGES', ['image/jpeg','image/png','image/webp','image/gif']);
define('CP_ALLOWED_DOCS',   ['application/pdf','image/jpeg','image/png','image/webp']);

// Transaction limits
define('CP_DAILY_TRANSFER_LIMIT', 500000);
define('CP_MIN_DEPOSIT',          100);
define('CP_MIN_WITHDRAWAL',       100);

// Loan types
define('CP_LOAN_TYPES', ['Personal Loan','Business Loan','Agricultural Loan','Mortgage Loan','Student Loan']);
