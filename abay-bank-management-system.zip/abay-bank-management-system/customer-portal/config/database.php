<?php
/**
 * Abay Bank — Customer Portal Database (shares abay_bank DB)
 */
class CP_Database {
    private static ?PDO $instance = null;

    public static function connect(): PDO {
        if (self::$instance) return self::$instance;
        $env = [];
        $envFile = dirname(__DIR__, 2) . '/.env';
        if (file_exists($envFile)) {
            foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                if (str_starts_with(trim($line), '#') || !str_contains($line, '=')) continue;
                [$k, $v] = explode('=', $line, 2);
                $env[trim($k)] = trim($v, " \t\"'");
            }
        }
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $env['DB_HOST'] ?? 'localhost',
            $env['DB_PORT'] ?? '3306',
            $env['DB_DATABASE'] ?? 'abay_bank'
        );
        self::$instance = new PDO($dsn,
            $env['DB_USERNAME'] ?? 'root',
            $env['DB_PASSWORD'] ?? '',
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
        );
        return self::$instance;
    }

    public static function get(): ?PDO {
        try { return self::connect(); } catch (Throwable) { return null; }
    }

    public static function query(string $sql, array $p = []): array {
        $db = self::get(); if (!$db) return [];
        try { $s=$db->prepare($sql); $s->execute($p); return $s->fetchAll(); } catch (Throwable) { return []; }
    }

    public static function queryOne(string $sql, array $p = []): ?array {
        $r = self::query($sql, $p); return $r[0] ?? null;
    }

    public static function execute(string $sql, array $p = []): bool {
        $db = self::get(); if (!$db) return false;
        try { return $db->prepare($sql)->execute($p); } catch (Throwable) { return false; }
    }

    public static function lastId(): int {
        $db = self::get(); return $db ? (int)$db->lastInsertId() : 0;
    }

    public static function isOnline(): bool { return self::get() !== null; }
}
