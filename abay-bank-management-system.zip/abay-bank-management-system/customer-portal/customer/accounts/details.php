<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$accId      = (int)($_GET['id'] ?? 0);
$pageTitle  = 'Account Details — ' . CP_NAME;
$breadcrumb = [['label'=>'Accounts','url'=>CP_BASE_URL.'/customer/accounts/index.php'],['label'=>'Details']];
$needsCharts = true;

$account = CP_Database::queryOne(
    "SELECT a.*, COALESCE(b.name,'--') AS branch_name FROM accounts a LEFT JOIN branches b ON b.id=a.branch_id WHERE a.id=? AND a.customer_id=?",
    [$accId, $custId]
) ?? (cp_demo_accounts($custId)[0] ?? []);

$txns = CP_Database::query(
    "SELECT * FROM transactions WHERE account_id=? ORDER BY created_at DESC LIMIT 20",
    [$accId]
) ?: cp_demo_transactions($custId, 10);

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-building-columns" style="color:var(--teal)"></i> Account Details</h1><p><?= cp_e($account['account_number']??'') ?></p></div>
  <div class="cp-page-actions">
    <a href="<?= CP_BASE_URL ?>/customer/accounts/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
    <a href="<?= CP_BASE_URL ?>/customer/statements/index.php?account=<?= $accId ?>" class="cp-btn cp-btn-primary"><i class="fa-solid fa-file-lines"></i> Statement</a>
  </div>
</div>
<!-- Account card -->
<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:16px;padding:24px 28px;margin-bottom:24px;color:#fff">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px">
    <div>
      <div style="font-size:.73rem;opacity:.65;font-weight:700;text-transform:uppercase;margin-bottom:8px"><?= cp_e($account['account_type']??'Savings') ?> Account</div>
      <div style="font-size:1.8rem;font-weight:800;margin-bottom:6px"><?= cp_etb((float)($account['balance']??0)) ?></div>
      <div style="font-size:.83rem;font-family:monospace;opacity:.75"><?= cp_e($account['account_number']??'') ?></div>
    </div>
    <div style="text-align:right">
      <div style="margin-bottom:8px"><?= cp_badge($account['status']??'Active') ?></div>
      <div style="font-size:.78rem;opacity:.65"><?= cp_e($account['branch_name']??'') ?></div>
      <div style="font-size:.78rem;opacity:.65">Opened: <?= cp_date($account['opened_date']??'') ?></div>
    </div>
  </div>
  <div style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap">
    <a href="<?= CP_BASE_URL ?>/customer/transfers/index.php" class="cp-btn cp-btn-gold cp-btn-sm"><i class="fa-solid fa-right-left"></i> Transfer</a>
    <a href="<?= CP_BASE_URL ?>/customer/deposits/index.php" class="cp-btn cp-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:none"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
    <a href="<?= CP_BASE_URL ?>/customer/withdrawals/index.php" class="cp-btn cp-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:none"><i class="fa-solid fa-arrow-up"></i> Withdraw</a>
  </div>
</div>
<div class="cp-grid-2">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Account Information</h3></div>
    <div class="cp-card-body">
      <?php foreach ([['Account Number',$account['account_number']??'—'],['Account Type',$account['account_type']??'—'],['Currency',$account['currency']??'ETB'],['Branch',$account['branch_name']??'—'],['Status',$account['status']??'—'],['Opened',cp_date($account['opened_date']??'')]] as [$l,$v]): ?>
      <div class="cp-info-row"><span class="cp-info-label"><?= $l ?></span><span class="cp-info-val"><?= cp_e($v) ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Balance History</h3></div>
    <div class="cp-card-body"><canvas id="bal-chart" height="200"></canvas></div>
  </div>
</div>
<!-- Recent transactions -->
<div class="cp-card">
  <div class="cp-card-hdr"><h3>Recent Transactions</h3><a href="<?= CP_BASE_URL ?>/customer/transactions/index.php?account=<?= $accId ?>" class="cp-btn cp-btn-outline cp-btn-sm">View All</a></div>
  <div class="cp-card-body p0">
    <table class="cp-table">
      <thead><tr><th>Date</th><th>Description</th><th>Type</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach (array_slice($txns,0,8) as $t):
          $isC=in_array($t['type']??'',['Deposit','Transfer In','Loan Disbursement']);
        ?>
        <tr>
          <td style="font-size:.8rem;color:var(--muted)"><?= cp_date($t['created_at']??'','d M H:i') ?></td>
          <td><?= cp_e($t['description']??$t['type']??'—') ?></td>
          <td><?= cp_badge($t['type']??'—') ?></td>
          <td class="fw-7" style="color:<?= $isC?'#16a34a':'#dc2626' ?>"><?= ($isC?'+':'-').cp_etb(abs((float)($t['amount']??0))) ?></td>
          <td><?= cp_badge($t['status']??'Completed') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $pageScript = "document.addEventListener('DOMContentLoaded',function(){if(!window.Chart)return;new Chart(document.getElementById('bal-chart'),{type:'line',data:{labels:['Mar','Apr','May','Jun','Jul','Aug'],datasets:[{label:'Balance',data:[120000,135000,128000,155000,142000,".((float)($account['balance']??157000))."],borderColor:'#007A8A',backgroundColor:'rgba(0,122,138,.1)',fill:true,tension:.4,pointRadius:4}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:false}}}});});"; ?>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
