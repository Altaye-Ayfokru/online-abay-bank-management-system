<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$pageTitle  = 'My Accounts — ' . CP_NAME;
$breadcrumb = [['label' => 'My Accounts']];
$custId     = (int)($customer['id'] ?? 0);

$accounts = CP_Database::query(
  "SELECT a.*, COALESCE(b.name,'--') AS branch_name FROM accounts a LEFT JOIN branches b ON b.id=a.branch_id WHERE a.customer_id=? ORDER BY a.opened_date ASC",
  [$custId]
) ?: cp_demo_accounts($custId);

$totalBalance = array_sum(array_column($accounts, 'balance'));
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-building-columns" style="color:var(--teal)"></i> My Accounts</h1>
    <p>View and manage your bank accounts</p>
  </div>
</div>
<!-- Total -->
<div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:16px;padding:20px 24px;margin-bottom:24px;color:#fff;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
  <div>
    <div style="font-size:.72rem;opacity:.65;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">Total Portfolio Balance</div>
    <div style="font-size:2rem;font-weight:800"><?= cp_etb($totalBalance) ?></div>
    <div style="font-size:.8rem;opacity:.6;margin-top:3px"><?= count($accounts) ?> account<?= count($accounts) !== 1 ? 's' : '' ?></div>
  </div>
  <a href="<?= CP_BASE_URL ?>/customer/statements/index.php" class="cp-btn cp-btn-gold"><i class="fa-solid fa-file-lines"></i> Get Statement</a>
</div>
<!-- Account cards -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(310px,1fr));gap:20px;margin-bottom:24px">
  <?php foreach ($accounts as $acc): ?>
    <div class="cp-card" style="border-top:4px solid var(--teal)">
      <div class="cp-card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px">
          <div>
            <div style="font-size:.72rem;color:var(--muted);font-weight:700;text-transform:uppercase;margin-bottom:4px"><?= cp_e($acc['account_type'] ?? 'Savings') ?> Account</div>
            <div style="font-size:.85rem;font-family:monospace;font-weight:600"><?= cp_e($acc['account_number'] ?? '') ?></div>
          </div>
          <span><?= cp_badge($acc['status'] ?? 'Active') ?></span>
        </div>
        <div style="margin-bottom:16px">
          <div style="font-size:.72rem;color:var(--muted);margin-bottom:3px">Available Balance</div>
          <div style="font-size:1.6rem;font-weight:800;color:var(--navy)"><?= cp_etb((float)($acc['balance'] ?? 0)) ?></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.78rem;color:var(--muted);margin-bottom:14px">
          <span><i class="fa-solid fa-building" style="margin-right:4px"></i><?= cp_e($acc['branch_name'] ?? '—') ?></span>
          <span>Opened <?= cp_date($acc['opened_date'] ?? '') ?></span>
        </div>
        <div style="display:flex;gap:8px">
          <a href="<?= CP_BASE_URL ?>/customer/accounts/details.php?id=<?= (int)($acc['id'] ?? 0) ?>" class="cp-btn cp-btn-primary cp-btn-sm" style="flex:1;justify-content:center"><i class="fa-solid fa-eye"></i> Details</a>
          <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php?account=<?= (int)($acc['id'] ?? 0) ?>" class="cp-btn cp-btn-outline cp-btn-sm" style="flex:1;justify-content:center"><i class="fa-solid fa-list"></i> Transactions</a>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>