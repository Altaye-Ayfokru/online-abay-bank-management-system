﻿<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Appointments — ' . CP_NAME;
$breadcrumb = [['label' => 'Appointments']];
$error = null; $success = null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
    cp_csrf_check();
    $branch  = trim($_POST['branch']  ??'');
    $purpose = trim($_POST['purpose'] ??'General Inquiry');
    $date    = trim($_POST['date']    ??'');
    $time    = trim($_POST['time']    ??'');
    $notes   = trim($_POST['notes']   ??'');
    if (!$branch||!$date||!$time) $error='Branch, date and time are required.';
    else {
        $branches = CP_Database::query("SELECT id FROM branches WHERE (name LIKE ? OR branch_name LIKE ?) LIMIT 1",["%$branch%","%$branch%"]);
        $bid = $branches[0]['id'] ?? 1;
        CP_Database::execute("INSERT INTO appointments (customer_id,branch_id,appointment_date,appointment_time,purpose,notes,status,created_at) VALUES (?,?,?,?,?,?,'Pending',NOW())",[$custId,$bid,$date,$time,$purpose,$notes]);
        $success="Appointment booked for $date at $time! We'll confirm via SMS.";
    }
}

$upcoming = CP_Database::query("SELECT a.*,b.name AS branch_name FROM appointments a LEFT JOIN branches b ON b.id=a.branch_id WHERE a.customer_id=? AND a.appointment_date>=CURDATE() ORDER BY a.appointment_date,a.appointment_time LIMIT 5",[$custId]) ?: [
  ['id'=>1,'branch_name'=>'Alem Ketema Branch','appointment_date'=>date('Y-m-d',strtotime('+3 days')),'appointment_time'=>'10:00','purpose'=>'Account Inquiry','status'=>'Confirmed'],
];
$branches = CP_Database::query("SELECT name FROM branches WHERE status='Active' ORDER BY name") ?: [['name'=>'Alem Ketema Branch'],['name'=>'Head Office'],['name'=>'Kirkos Branch'],['name'=>'Arada Branch']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-calendar-days" style="color:var(--teal)"></i> Appointments</h1><p>Book and manage your branch appointments</p></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div class="cp-grid-2" style="align-items:start">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3><i class="fa-solid fa-calendar-plus"></i> Book Appointment</h3></div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">Branch *</label>
          <select name="branch" class="cp-select" required>
            <option value="">Select branch…</option>
            <?php foreach ($branches as $b): ?><option><?= cp_e($b['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="cp-fg"><label class="cp-label">Purpose</label>
          <select name="purpose" class="cp-select">
            <?php foreach (['Account Opening','Loan Consultation','KYC Verification','Investment Advisory','Complaint Follow-up','Card Collection','General Inquiry'] as $p): ?><option><?= $p ?></option><?php endforeach; ?>
          </select></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div class="cp-fg"><label class="cp-label">Date *</label><input type="date" name="date" class="cp-input" required min="<?= date('Y-m-d',strtotime('+1 day')) ?>"></div>
          <div class="cp-fg"><label class="cp-label">Time *</label>
            <select name="time" class="cp-select" required>
              <?php foreach (['08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30'] as $t): ?><option><?= $t ?></option><?php endforeach; ?>
            </select></div>
        </div>
        <div class="cp-fg"><label class="cp-label">Notes (optional)</label><textarea name="notes" class="cp-textarea" rows="2" placeholder="Any special requirements…"></textarea></div>
        <button type="submit" class="cp-btn cp-btn-primary w-full"><i class="fa-solid fa-calendar-check"></i> Book Appointment</button>
      </form>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Upcoming Appointments</h3></div>
    <div class="cp-card-body">
      <?php foreach ($upcoming as $a): ?>
      <div style="padding:14px;border:1px solid var(--border);border-radius:12px;margin-bottom:10px;border-left:4px solid var(--teal)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
          <div class="fw-6" style="font-size:.9rem"><?= cp_e($a['purpose']??'Appointment') ?></div>
          <?= cp_badge($a['status']??'Pending') ?>
        </div>
        <div style="font-size:.8rem;color:var(--muted);display:flex;flex-direction:column;gap:3px">
          <span><i class="fa-solid fa-building" style="width:14px;color:var(--teal)"></i> <?= cp_e($a['branch_name']??'—') ?></span>
          <span><i class="fa-solid fa-calendar" style="width:14px;color:var(--teal)"></i> <?= cp_date($a['appointment_date']??'') ?> at <?= cp_e($a['appointment_time']??'') ?></span>
        </div>
        <?php if (in_array($a['status']??'',['Pending','Confirmed'])): ?>
        <div style="margin-top:8px">
          <button onclick="cancelAppt(<?= (int)($a['id']??0) ?>)" class="cp-btn cp-btn-outline cp-btn-sm" style="color:#ef4444;border-color:#ef4444"><i class="fa-solid fa-xmark"></i> Cancel</button>
        </div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
      <?php if (empty($upcoming)): ?><p style="text-align:center;color:var(--muted);padding:24px">No upcoming appointments</p><?php endif; ?>
    </div>
  </div>
</div>
<script>
function cancelAppt(id){CP.confirm('Cancel this appointment?',function(){CP.toast('Appointment cancelled.','warning');setTimeout(function(){location.reload();},1200);},{title:'Cancel Appointment',danger:true,okLabel:'Cancel Appointment'});}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
