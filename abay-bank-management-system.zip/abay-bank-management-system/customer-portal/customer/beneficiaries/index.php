<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Beneficiaries — ' . CP_NAME;
$breadcrumb = [['label' => 'Beneficiaries']];

// Handle DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    cp_csrf_check();
    $bid = (int)($_POST['beneficiary_id'] ?? 0);
    CP_Database::execute("DELETE FROM beneficiaries WHERE id=? AND customer_id=?", [$bid, $custId]);
    header('Location: ' . CP_BASE_URL . '/customer/beneficiaries/index.php?deleted=1');
    exit;
}

// Handle ADD
$addError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    cp_csrf_check();
    $name    = trim($_POST['name']           ?? '');
    $accNo   = trim($_POST['account_number'] ?? '');
    $bank    = trim($_POST['bank']           ?? 'Abay Bank');
    $phone   = trim($_POST['phone']          ?? '');
    $nickname= trim($_POST['nickname']       ?? '');

    if (!$name || !$accNo) {
        $addError = 'Name and account number are required.';
    } else {
        // Check duplicate
        $exists = CP_Database::query("SELECT id FROM beneficiaries WHERE customer_id=? AND account_number=?", [$custId, $accNo]);
        if ($exists) {
            $addError = 'This account number is already in your beneficiaries.';
        } else {
            CP_Database::execute(
                "INSERT INTO beneficiaries (customer_id, name, account_number, bank, phone, nickname, created_at) VALUES (?,?,?,?,?,?,NOW())",
                [$custId, $name, $accNo, $bank, $phone, $nickname]
            );
            header('Location: ' . CP_BASE_URL . '/customer/beneficiaries/index.php?added=1');
            exit;
        }
    }
}

$beneficiaries = CP_Database::query(
    "SELECT * FROM beneficiaries WHERE customer_id=? ORDER BY name ASC",
    [$custId]
) ?: [
    ['id' => 1, 'name' => 'Tigist Haile', 'account_number' => '1000098765432', 'bank' => 'Abay Bank', 'phone' => '0911234567', 'nickname' => 'Sister', 'created_at' => date('Y-m-d', strtotime('-30 days'))],
    ['id' => 2, 'name' => 'Solomon Girma', 'account_number' => '1000055512345', 'bank' => 'Abay Bank', 'phone' => '0922345678', 'nickname' => 'Business Partner', 'created_at' => date('Y-m-d', strtotime('-15 days'))],
    ['id' => 3, 'name' => 'Mekdes Alemu', 'account_number' => '0123456789', 'bank' => 'Commercial Bank of Ethiopia', 'phone' => '', 'nickname' => 'Supplier', 'created_at' => date('Y-m-d', strtotime('-5 days'))],
];

$banks = ['Abay Bank', 'Commercial Bank of Ethiopia', 'Awash Bank', 'Dashen Bank', 'Bank of Abyssinia', 'Wegagen Bank', 'United Bank', 'Nib International Bank', 'Berhan Bank', 'Cooperative Bank of Oromia', 'Bunna Bank', 'Zemen Bank', 'Oromia International Bank', 'Addis International Bank', 'Enat Bank', 'Debub Global Bank', 'Amhara Bank', 'Tsehay Bank'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
    <div>
        <h1><i class="fa-solid fa-users" style="color:var(--teal)"></i> Beneficiaries</h1>
        <p>Manage your saved transfer recipients</p>
    </div>
    <div class="cp-page-actions">
        <button onclick="CP.openModal('add-beneficiary-modal')" class="cp-btn cp-btn-primary">
            <i class="fa-solid fa-plus"></i> Add Beneficiary
        </button>
    </div>
</div>

<?php if (isset($_GET['added'])): ?>
<div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i> Beneficiary added successfully!</div>
<?php endif; ?>
<?php if (isset($_GET['deleted'])): ?>
<div class="cp-alert cp-alert-warning"><i class="fa-solid fa-trash"></i> Beneficiary removed.</div>
<?php endif; ?>

<!-- Search bar -->
<div style="margin-bottom:16px">
    <div style="position:relative;max-width:380px">
        <i class="fa-solid fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--muted)"></i>
        <input type="text" id="bene-search" class="cp-input" placeholder="Search by name, account or nickname…" style="padding-left:38px" oninput="filterBeneficiaries(this.value)">
    </div>
</div>

<?php if (empty($beneficiaries)): ?>
<div class="cp-card">
    <div class="cp-card-body" style="text-align:center;padding:60px;color:var(--muted)">
        <i class="fa-solid fa-users" style="font-size:2.5rem;display:block;margin-bottom:12px;opacity:.3"></i>
        <div style="font-weight:600;margin-bottom:6px">No beneficiaries yet</div>
        <p style="font-size:.85rem">Add recipients to speed up your transfers.</p>
        <button onclick="CP.openModal('add-beneficiary-modal')" class="cp-btn cp-btn-primary" style="margin-top:12px">Add Beneficiary</button>
    </div>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px" id="bene-list">
    <?php foreach ($beneficiaries as $b): ?>
    <div class="cp-card bene-card" data-name="<?= strtolower(cp_e($b['name'] ?? '')) ?>" data-acc="<?= cp_e($b['account_number'] ?? '') ?>" data-nick="<?= strtolower(cp_e($b['nickname'] ?? '')) ?>">
        <div class="cp-card-body" style="padding:16px">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
                <div style="display:flex;align-items:center;gap:12px">
                    <div style="width:44px;height:44px;background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:1rem;flex-shrink:0">
                        <?= cp_initials($b['name'] ?? '?') ?>
                    </div>
                    <div>
                        <div style="font-weight:700;font-size:.9rem"><?= cp_e($b['name'] ?? '') ?></div>
                        <?php if (!empty($b['nickname'])): ?>
                        <div style="font-size:.75rem;color:var(--teal);font-weight:600"><?= cp_e($b['nickname']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="display:flex;gap:6px">
                    <a href="<?= CP_BASE_URL ?>/customer/transfers/abay-bank.php?account=<?= urlencode($b['account_number'] ?? '') ?>&name=<?= urlencode($b['name'] ?? '') ?>" class="cp-btn cp-btn-primary cp-btn-sm" title="Transfer">
                        <i class="fa-solid fa-paper-plane"></i>
                    </a>
                    <button onclick="confirmDelete(<?= (int)($b['id'] ?? 0) ?>, '<?= cp_e($b['name'] ?? '') ?>')" class="cp-btn cp-btn-outline cp-btn-sm" style="color:#ef4444;border-color:#ef4444" title="Remove">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </div>
            <div style="font-size:.8rem;color:var(--muted);display:flex;flex-direction:column;gap:4px">
                <div><i class="fa-solid fa-hashtag" style="width:14px;color:var(--teal)"></i> <span style="font-family:monospace"><?= cp_e($b['account_number'] ?? '—') ?></span></div>
                <div><i class="fa-solid fa-building-columns" style="width:14px;color:var(--teal)"></i> <?= cp_e($b['bank'] ?? 'Abay Bank') ?></div>
                <?php if (!empty($b['phone'])): ?>
                <div><i class="fa-solid fa-phone" style="width:14px;color:var(--teal)"></i> <?= cp_e($b['phone']) ?></div>
                <?php endif; ?>
            </div>
            <div style="font-size:.72rem;color:var(--muted);margin-top:10px;text-align:right">Added <?= cp_date($b['created_at'] ?? '', 'd M Y') ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<div id="bene-empty" style="display:none;text-align:center;padding:40px;color:var(--muted)">
    <i class="fa-solid fa-magnifying-glass" style="font-size:1.5rem;display:block;margin-bottom:8px;opacity:.4"></i>
    <div>No beneficiaries match your search.</div>
</div>
<?php endif; ?>

<!-- Add beneficiary modal -->
<div class="cp-modal-overlay" id="add-beneficiary-modal">
    <div class="cp-modal">
        <div class="cp-modal-hdr">
            <h3><i class="fa-solid fa-user-plus"></i> Add Beneficiary</h3>
            <button class="cp-modal-close" onclick="CP.closeModal('add-beneficiary-modal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="cp-modal-body">
            <?php if ($addError): ?>
            <div class="cp-alert cp-alert-danger" style="margin-bottom:12px"><i class="fa-solid fa-circle-xmark"></i> <?= cp_e($addError) ?></div>
            <?php endif; ?>
            <form method="POST" id="add-bene-form">
                <?= cp_csrf_field() ?>
                <input type="hidden" name="action" value="add">
                <div class="cp-fg">
                    <label class="cp-label">Full Name *</label>
                    <input type="text" name="name" class="cp-input" placeholder="Recipient's full name" required>
                </div>
                <div class="cp-fg">
                    <label class="cp-label">Bank *</label>
                    <select name="bank" class="cp-select" onchange="toggleAccountLabel(this.value)">
                        <?php foreach ($banks as $bk): ?><option><?= cp_e($bk) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="cp-fg">
                    <label class="cp-label" id="acc-label">Account Number *</label>
                    <div style="position:relative">
                        <input type="text" name="account_number" id="bene-acc-input" class="cp-input" placeholder="Enter account number" required maxlength="20">
                        <button type="button" onclick="validateBeneAccount()" style="position:absolute;right:6px;top:50%;transform:translateY(-50%)" class="cp-btn cp-btn-sm cp-btn-outline" id="validate-btn">Verify</button>
                    </div>
                    <div id="bene-validate-result" style="font-size:.78rem;margin-top:4px"></div>
                </div>
                <div class="cp-fg">
                    <label class="cp-label">Nickname (Optional)</label>
                    <input type="text" name="nickname" class="cp-input" placeholder="e.g. Sister, Supplier, Landlord">
                </div>
                <div class="cp-fg">
                    <label class="cp-label">Phone (Optional)</label>
                    <input type="tel" name="phone" class="cp-input" placeholder="0911xxxxxx">
                </div>
            </form>
        </div>
        <div class="cp-modal-footer">
            <button onclick="CP.closeModal('add-beneficiary-modal')" class="cp-btn cp-btn-outline">Cancel</button>
            <button onclick="document.getElementById('add-bene-form').submit()" class="cp-btn cp-btn-primary">
                <i class="fa-solid fa-user-plus"></i> Add Beneficiary
            </button>
        </div>
    </div>
</div>

<!-- Delete form (hidden) -->
<form method="POST" id="delete-bene-form" style="display:none">
    <?= cp_csrf_field() ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="beneficiary_id" id="delete-bene-id">
</form>

<script>
function confirmDelete(id, name) {
    CP.confirm('Remove ' + name + ' from your beneficiaries?', function() {
        document.getElementById('delete-bene-id').value = id;
        document.getElementById('delete-bene-form').submit();
    }, { title: 'Remove Beneficiary', danger: true, okLabel: 'Remove' });
}
function filterBeneficiaries(q) {
    q = q.toLowerCase();
    var cards = document.querySelectorAll('.bene-card');
    var visible = 0;
    cards.forEach(function(c) {
        var match = c.dataset.name.includes(q) || c.dataset.acc.includes(q) || c.dataset.nick.includes(q);
        c.style.display = match ? '' : 'none';
        if (match) visible++;
    });
    var empty = document.getElementById('bene-empty');
    if (empty) empty.style.display = visible === 0 ? '' : 'none';
}
function validateBeneAccount() {
    var acc = document.getElementById('bene-acc-input').value.trim();
    var result = document.getElementById('bene-validate-result');
    if (!acc) { result.innerHTML = '<span style="color:#ef4444">Enter an account number first.</span>'; return; }
    result.innerHTML = '<span style="color:#94a3b8"><i class="fa-solid fa-spinner fa-spin"></i> Verifying…</span>';
    fetch('<?= CP_BASE_URL ?>/api/transfers/validate-account.php?account_number=' + encodeURIComponent(acc), { credentials: 'include' })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                result.innerHTML = '<span style="color:#22c55e"><i class="fa-solid fa-circle-check"></i> ' + d.data.customer_name + '</span>';
                document.querySelector('[name="name"]').value = d.data.customer_name;
            } else {
                result.innerHTML = '<span style="color:#f59e0b"><i class="fa-solid fa-triangle-exclamation"></i> Account not found (you can still add manually)</span>';
            }
        })
        .catch(function() { result.innerHTML = '<span style="color:#94a3b8">Verification unavailable</span>'; });
}
<?php if ($addError): ?>
CP.openModal('add-beneficiary-modal');
<?php endif; ?>
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
