<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'My Cards — ' . CP_NAME;
$breadcrumb = [['label' => 'Cards']];

$cards = CP_Database::query(
    "SELECT c.*, a.account_number FROM atm_cards c JOIN accounts a ON a.id=c.account_id WHERE a.customer_id=? ORDER BY c.issued_date DESC",
    [$custId]
) ?: [
  ['id'=>1,'card_number'=>'4321 **** **** 1234','card_type'=>'Visa Debit','issued_date'=>'2024-01-15','expiry_date'=>'2027-01-31','status'=>'Active','daily_limit'=>50000,'account_number'=>'1000012345678'],
  ['id'=>2,'card_number'=>'5123 **** **** 5678','card_type'=>'Mastercard Virtual','issued_date'=>'2024-06-01','expiry_date'=>'2025-06-30','status'=>'Active','daily_limit'=>100000,'account_number'=>'1000012345678'],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-credit-card" style="color:var(--teal)"></i> My Cards</h1><p>Manage your debit and virtual cards</p></div>
  <div class="cp-page-actions">
    <button onclick="CP.openModal('request-card-modal')" class="cp-btn cp-btn-primary"><i class="fa-solid fa-plus"></i> Request New Card</button>
  </div>
</div>

<!-- Card display -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:24px;margin-bottom:28px">
  <?php foreach ($cards as $card):
    $isActive = ($card['status']??'') === 'Active';
  ?>
  <div>
    <!-- Card front -->
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:18px;padding:24px;color:#fff;position:relative;overflow:hidden;box-shadow:0 12px 32px rgba(27,58,92,.35);aspect-ratio:1.6/1;display:flex;flex-direction:column;justify-content:space-between" id="card-<?= $card['id'] ?>">
      <div style="position:absolute;top:-40px;right:-40px;width:160px;height:160px;background:rgba(255,255,255,.06);border-radius:50%"></div>
      <div style="position:absolute;bottom:-30px;left:-30px;width:120px;height:120px;background:rgba(200,168,75,.1);border-radius:50%"></div>
      <div style="display:flex;justify-content:space-between;align-items:flex-start;position:relative;z-index:1">
        <div>
          <div style="font-size:.7rem;opacity:.6;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">Abay Bank</div>
          <div style="font-size:.82rem;font-weight:600;color:#C8A84B"><?= cp_e($card['card_type']??'Debit Card') ?></div>
        </div>
        <div style="background:rgba(255,255,255,.15);border-radius:8px;padding:6px 10px;font-size:.72rem;font-weight:700"><?= $isActive?'● ACTIVE':'○ INACTIVE' ?></div>
      </div>
      <div style="position:relative;z-index:1">
        <div style="font-size:1.05rem;font-weight:700;font-family:monospace;letter-spacing:.12em;margin-bottom:12px"><?= cp_e($card['card_number']??'**** **** **** ****') ?></div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div><div style="font-size:.6rem;opacity:.55;text-transform:uppercase">Account</div><div style="font-size:.75rem;font-family:monospace"><?= cp_e($card['account_number']??'') ?></div></div>
          <div style="text-align:right"><div style="font-size:.6rem;opacity:.55;text-transform:uppercase">Expires</div><div style="font-size:.82rem;font-family:monospace"><?= cp_date($card['expiry_date']??'','m/Y') ?></div></div>
          <div style="font-size:1.4rem;opacity:.5"><i class="fa-brands fa-cc-visa"></i></div>
        </div>
      </div>
    </div>
    <!-- Card actions -->
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
      <?php if ($isActive): ?>
      <button onclick="blockCard(<?= $card['id'] ?>,'<?= cp_e($card['card_number']) ?>')" class="cp-btn cp-btn-outline cp-btn-sm" style="color:#ef4444;border-color:#ef4444;flex:1"><i class="fa-solid fa-ban"></i> Block</button>
      <?php else: ?>
      <button onclick="unblockCard(<?= $card['id'] ?>)" class="cp-btn cp-btn-outline cp-btn-sm" style="flex:1"><i class="fa-solid fa-lock-open"></i> Unblock</button>
      <?php endif; ?>
      <button onclick="CP.toast('Card limit update coming soon','info')" class="cp-btn cp-btn-outline cp-btn-sm" style="flex:1"><i class="fa-solid fa-sliders"></i> Limit: <?= cp_etb((float)($card['daily_limit']??50000)) ?>/day</button>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Card request modal -->
<div class="cp-modal-overlay" id="request-card-modal">
  <div class="cp-modal">
    <div class="cp-modal-hdr"><h3><i class="fa-solid fa-credit-card"></i> Request New Card</h3><button class="cp-modal-close" onclick="CP.closeModal('request-card-modal')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="cp-modal-body">
      <form onsubmit="submitCardRequest(event)">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">Card Type</label>
          <select class="cp-select"><option>Visa Debit</option><option>Mastercard Debit</option><option>Virtual Card</option></select></div>
        <div class="cp-fg"><label class="cp-label">Link to Account</label>
          <select class="cp-select">
            <?php foreach (CP_Database::query("SELECT id,account_number,account_type FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId) as $a): ?>
            <option><?= cp_e($a['account_number']) ?> · <?= cp_e($a['account_type']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="cp-fg"><label class="cp-label">Delivery Address</label><textarea class="cp-textarea" rows="2" placeholder="Card delivery address…"><?= cp_e($customer['address']??'') ?></textarea></div>
        <div class="cp-alert cp-alert-info" style="font-size:.82rem"><i class="fa-solid fa-circle-info"></i><div>Card issuance takes 3–5 business days. A fee of ETB 50 applies.</div></div>
      </form>
    </div>
    <div class="cp-modal-footer">
      <button onclick="CP.closeModal('request-card-modal')" class="cp-btn cp-btn-outline">Cancel</button>
      <button onclick="submitCardRequest()" class="cp-btn cp-btn-primary">Submit Request</button>
    </div>
  </div>
</div>
<script>
function blockCard(id,num){CP.confirm('Block card ending '+num.slice(-4)+'? You will not be able to use it.',function(){CP.toast('Card blocked. Contact branch to unblock.','warning');},{title:'Block Card',danger:true,okLabel:'Block Card'});}
function unblockCard(id){CP.confirm('Unblock this card?',function(){CP.toast('Card unblock request submitted.','success');},{title:'Unblock Card',okLabel:'Unblock'});}
function submitCardRequest(e){if(e)e.preventDefault();CP.closeModal('request-card-modal');CP.toast('Card request submitted! You will be notified when ready.','success');}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
