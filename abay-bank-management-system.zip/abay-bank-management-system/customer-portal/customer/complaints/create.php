<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'New Complaint — ' . CP_NAME;
$breadcrumb = [['label' => 'Complaints', 'url' => CP_BASE_URL . '/customer/complaints/index.php'], ['label' => 'New Complaint']];
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  cp_csrf_check();
  $category    = trim($_POST['category']    ?? '');
  $subject     = trim($_POST['subject']     ?? '');
  $description = trim($_POST['description'] ?? '');
  $priority    = trim($_POST['priority']    ?? 'Medium');
  $channel     = trim($_POST['channel']     ?? 'Portal');

  if (!$category || !$subject || !$description) {
    $error = 'Category, subject and description are required.';
  } else {
    // Handle file attachment
    $attachUrl = null;
    if (!empty($_FILES['attachment']['name'])) {
      $file = $_FILES['attachment'];
      $allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
      if (in_array($file['type'], $allowed) && $file['size'] <= 5 * 1024 * 1024) {
        $dir = CP_BASE_PATH . '/uploads/documents/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $fn  = 'complaint_' . $custId . '_' . time() . '.' . $ext;
        if (move_uploaded_file($file['tmp_name'], $dir . $fn)) {
          $attachUrl = CP_BASE_URL . '/uploads/documents/' . $fn;
        }
      }
    }

    // Generate ticket number
    $ticketNo = 'CMP-' . date('Y') . '-' . str_pad(rand(100, 9999), 4, '0', STR_PAD_LEFT);
    $inserted = CP_Database::execute(
      "INSERT INTO complaints (customer_id, ticket_no, category, subject, description, priority, channel, attachment, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,'Open',NOW(),NOW())",
      [$custId, $ticketNo, $category, $subject, $description, $priority, $channel, $attachUrl]
    );
    if ($inserted !== false) {
      // Notify admin about new complaint
      cp_notify_admin(
        'complaint',
        "New Complaint: $ticketNo",
        "[$priority] $subject — $category",
        $custId
      );
      $success = "Complaint submitted successfully! Your ticket number is <strong>$ticketNo</strong>. We will respond within 3 business days.";
    } else {
      // Demo mode — just show success
      $success = "Complaint submitted (demo mode)! Ticket: <strong>$ticketNo</strong>";
    }
  }
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-pen-to-square" style="color:var(--teal)"></i> Submit Complaint</h1>
    <p>Describe your issue and we will resolve it promptly</p>
  </div>
  <div class="cp-page-actions">
    <a href="<?= CP_BASE_URL ?>/customer/complaints/index.php" class="cp-btn cp-btn-outline">
      <i class="fa-solid fa-arrow-left"></i> Back to Complaints
    </a>
  </div>
</div>

<?php if ($error): ?>
  <div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= cp_e($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
  <div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i> <?= $success ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;align-items:start">
  <!-- Form -->
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3>Complaint Details</h3>
    </div>
    <div class="cp-card-body">
      <form method="POST" enctype="multipart/form-data" id="complaint-form">
        <?= cp_csrf_field() ?>
        <div class="cp-grid-2">
          <div class="cp-fg">
            <label class="cp-label">Category *</label>
            <select name="category" class="cp-select" required>
              <option value="">Select category…</option>
              <?php foreach (['Account Issue', 'Transaction Issue', 'Card Issue', 'Loan Issue', 'Online Banking', 'Branch Service', 'Staff Conduct', 'Charges & Fees', 'KYC/Documentation', 'Other'] as $cat): ?>
                <option value="<?= cp_e($cat) ?>" <?= (($_POST['category'] ?? '') === $cat) ? 'selected' : '' ?>><?= $cat ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="cp-fg">
            <label class="cp-label">Priority</label>
            <select name="priority" class="cp-select">
              <?php foreach (['Low' => 'Low', 'Medium' => 'Medium (Default)', 'High' => 'High', 'Urgent' => 'Urgent'] as $val => $label): ?>
                <option value="<?= $val ?>" <?= (($_POST['priority'] ?? 'Medium') === $val) ? 'selected' : '' ?>><?= $label ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="cp-fg">
          <label class="cp-label">Subject *</label>
          <input type="text" name="subject" class="cp-input" placeholder="Brief title of your complaint…" maxlength="120" value="<?= cp_e($_POST['subject'] ?? '') ?>" required>
        </div>
        <div class="cp-fg">
          <label class="cp-label">Description *</label>
          <textarea name="description" class="cp-textarea" rows="6" placeholder="Please describe your issue in detail — include dates, amounts, account numbers, and what happened…" required><?= cp_e($_POST['description'] ?? '') ?></textarea>
          <div style="font-size:.72rem;color:var(--muted);margin-top:3px">Be as specific as possible to help us resolve your issue faster.</div>
        </div>
        <div class="cp-fg">
          <label class="cp-label">Preferred Contact Channel</label>
          <select name="channel" class="cp-select">
            <option>Portal</option>
            <option>Email</option>
            <option>Phone</option>
            <option>SMS</option>
          </select>
        </div>
        <div class="cp-fg">
          <label class="cp-label">Attach Supporting File <span style="color:var(--muted)">(Optional — PDF/JPG/PNG, max 5 MB)</span></label>
          <div class="cp-upload-zone" id="drop-zone" onclick="document.getElementById('attach-file').click()">
            <i class="fa-solid fa-cloud-arrow-up" style="font-size:1.6rem;color:var(--teal);margin-bottom:8px"></i>
            <div style="font-size:.85rem;font-weight:600">Click or drag file here</div>
            <div style="font-size:.75rem;color:var(--muted)" id="file-name">No file chosen</div>
          </div>
          <input type="file" name="attachment" id="attach-file" accept=".pdf,.jpg,.jpeg,.png,.webp" style="display:none" onchange="showFile(this)">
        </div>
        <div style="display:flex;gap:10px;margin-top:4px">
          <button type="button" onclick="window.location='<?= CP_BASE_URL ?>/customer/complaints/index.php'" class="cp-btn cp-btn-outline" style="flex:1">Cancel</button>
          <button type="submit" class="cp-btn cp-btn-primary" style="flex:2" id="submit-btn">
            <i class="fa-solid fa-paper-plane"></i> Submit Complaint
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Sidebar info -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="cp-card">
      <div class="cp-card-hdr">
        <h3>Our Commitment</h3>
      </div>
      <div class="cp-card-body">
        <?php foreach ([['fa-clock', 'Response Time', 'Within 3 business days'], ['fa-shield-halved', 'Confidentiality', 'All complaints are handled with strict privacy'], ['fa-rotate', 'Follow-up', 'We will update you on every status change'], ['fa-phone', 'Escalation', 'You can call 8397 for urgent issues']] as [$icon, $title, $desc]): ?>
          <div style="display:flex;gap:10px;margin-bottom:14px;align-items:flex-start">
            <div style="width:32px;height:32px;background:#007A8A15;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fa-solid <?= $icon ?>" style="color:var(--teal);font-size:.82rem"></i>
            </div>
            <div>
              <div style="font-size:.83rem;font-weight:700"><?= $title ?></div>
              <div style="font-size:.75rem;color:var(--muted)"><?= $desc ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="cp-card">
      <div class="cp-card-hdr">
        <h3>Priority Guide</h3>
      </div>
      <div class="cp-card-body">
        <?php foreach ([['Urgent', '#ef4444', 'Unauthorized transaction, account locked'], ['High', '#f97316', 'Wrong debit, card blocked unexpectedly'], ['Medium', '#f59e0b', 'Service delays, incorrect statements'], ['Low', '#22c55e', 'General feedback, suggestions']] as [$p, $c, $ex]): ?>
          <div style="margin-bottom:10px">
            <span style="font-size:.75rem;font-weight:700;color:<?= $c ?>;background:<?= $c ?>15;padding:2px 8px;border-radius:20px"><?= $p ?></span>
            <div style="font-size:.75rem;color:var(--muted);margin-top:3px"><?= $ex ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
  function showFile(input) {
    var fn = document.getElementById('file-name');
    if (fn && input.files && input.files[0]) {
      fn.textContent = input.files[0].name + ' (' + (input.files[0].size / 1024).toFixed(1) + ' KB)';
      document.getElementById('drop-zone').style.borderColor = 'var(--teal)';
    }
  }
  var dz = document.getElementById('drop-zone');
  if (dz) {
    dz.addEventListener('dragover', function(e) {
      e.preventDefault();
      dz.style.borderColor = 'var(--teal)';
    });
    dz.addEventListener('dragleave', function() {
      dz.style.borderColor = '';
    });
    dz.addEventListener('drop', function(e) {
      e.preventDefault();
      var input = document.getElementById('attach-file');
      input.files = e.dataTransfer.files;
      showFile(input);
    });
  }
  document.getElementById('complaint-form').addEventListener('submit', function() {
    CP.setBtn('submit-btn', true, '<i class="fa-solid fa-spinner fa-spin"></i> Submitting…');
  });
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>