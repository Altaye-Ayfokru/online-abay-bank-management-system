<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Complaints — ' . CP_NAME;
$breadcrumb = [['label' => 'Complaints']];

$filter = $_GET['status'] ?? 'all';
$where  = $filter !== 'all' ? "AND c.status=?" : '';
$params = $filter !== 'all' ? [$custId, $filter] : [$custId];
$complaints = CP_Database::query(
    "SELECT c.* FROM complaints c WHERE c.customer_id=? $where ORDER BY c.created_at DESC",
    $params
) ?: [
    ['id' => 1, 'ticket_no' => 'CMP-2024-001', 'category' => 'Account Issue', 'subject' => 'Unable to access online banking', 'status' => 'Resolved', 'priority' => 'High', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days')), 'updated_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
    ['id' => 2, 'ticket_no' => 'CMP-2024-002', 'category' => 'Transaction Issue', 'subject' => 'Wrong amount debited', 'status' => 'Open', 'priority' => 'Urgent', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')), 'updated_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 3, 'ticket_no' => 'CMP-2024-003', 'category' => 'Card Issue', 'subject' => 'ATM card not working', 'status' => 'In Progress', 'priority' => 'Medium', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days')), 'updated_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
];

$counts = ['all' => count($complaints), 'Open' => 0, 'In Progress' => 0, 'Resolved' => 0, 'Closed' => 0];
foreach ($complaints as $c) {
    $st = $c['status'] ?? 'Open';
    if (isset($counts[$st])) $counts[$st]++;
}

$priorityColors = ['Urgent' => '#ef4444', 'High' => '#f97316', 'Medium' => '#f59e0b', 'Low' => '#22c55e'];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
    <div>
        <h1><i class="fa-solid fa-headset" style="color:var(--teal)"></i> Complaints &amp; Feedback</h1>
        <p>Track your submitted complaints and service requests</p>
    </div>
    <div class="cp-page-actions">
        <a href="<?= CP_BASE_URL ?>/customer/complaints/create.php" class="cp-btn cp-btn-primary">
            <i class="fa-solid fa-plus"></i> New Complaint
        </a>
    </div>
</div>

<!-- Status summary tabs -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px">
    <?php foreach (['all' => 'All', 'Open' => 'Open', 'In Progress' => 'In Progress', 'Resolved' => 'Resolved', 'Closed' => 'Closed'] as $key => $label): ?>
    <a href="?status=<?= $key ?>" class="cp-btn <?= $filter === $key ? 'cp-btn-primary' : 'cp-btn-outline' ?> cp-btn-sm">
        <?= $label ?> <span style="background:rgba(255,255,255,.25);border-radius:20px;padding:0 7px;font-size:.75rem;margin-left:4px"><?= $counts[$key] ?? 0 ?></span>
    </a>
    <?php endforeach; ?>
</div>

<!-- Complaints list -->
<div class="cp-card">
    <div class="cp-card-body p0">
        <?php if (empty($complaints)): ?>
        <div style="text-align:center;padding:60px;color:var(--muted)">
            <i class="fa-solid fa-headset" style="font-size:2.5rem;display:block;margin-bottom:12px;opacity:.3"></i>
            <div style="font-weight:600;margin-bottom:6px">No complaints found</div>
            <p style="font-size:.85rem">You haven't submitted any complaints yet.</p>
            <a href="<?= CP_BASE_URL ?>/customer/complaints/create.php" class="cp-btn cp-btn-primary" style="margin-top:12px">Submit a Complaint</a>
        </div>
        <?php else: ?>
        <div class="cp-table-wrap">
            <table class="cp-table">
                <thead>
                    <tr>
                        <th>Ticket No.</th>
                        <th>Category</th>
                        <th>Subject</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Last Update</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($complaints as $c): ?>
                    <tr>
                        <td><span style="font-family:monospace;font-weight:700;color:var(--primary);font-size:.82rem"><?= cp_e($c['ticket_no'] ?? '#' . $c['id']) ?></span></td>
                        <td><span style="font-size:.8rem"><?= cp_e($c['category'] ?? '—') ?></span></td>
                        <td style="max-width:220px">
                            <div style="font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= cp_e($c['subject'] ?? '—') ?></div>
                        </td>
                        <td>
                            <?php $pc = $priorityColors[$c['priority'] ?? 'Medium'] ?? '#94a3b8'; ?>
                            <span style="font-size:.75rem;font-weight:700;color:<?= $pc ?>;background:<?= $pc ?>15;padding:2px 8px;border-radius:20px"><?= cp_e($c['priority'] ?? 'Medium') ?></span>
                        </td>
                        <td><?= cp_badge($c['status'] ?? 'Open') ?></td>
                        <td style="font-size:.78rem;white-space:nowrap"><?= cp_ago($c['created_at'] ?? '') ?></td>
                        <td style="font-size:.78rem;white-space:nowrap;color:var(--muted)"><?= cp_ago($c['updated_at'] ?? '') ?></td>
                        <td>
                            <button onclick="viewComplaint(<?= (int)($c['id'] ?? 0) ?>, <?= htmlspecialchars(json_encode($c), ENT_QUOTES) ?>)" class="cp-btn cp-btn-outline cp-btn-sm">
                                <i class="fa-solid fa-eye"></i> View
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- View complaint modal -->
<div class="cp-modal-overlay" id="view-complaint-modal">
    <div class="cp-modal" style="max-width:600px">
        <div class="cp-modal-hdr">
            <h3><i class="fa-solid fa-headset"></i> Complaint Details</h3>
            <button class="cp-modal-close" onclick="CP.closeModal('view-complaint-modal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="cp-modal-body" id="complaint-detail-body">
            <!-- Populated by JS -->
        </div>
        <div class="cp-modal-footer">
            <button onclick="CP.closeModal('view-complaint-modal')" class="cp-btn cp-btn-outline">Close</button>
        </div>
    </div>
</div>

<script>
function viewComplaint(id, data) {
    var body = document.getElementById('complaint-detail-body');
    var pc = {'Urgent':'#ef4444','High':'#f97316','Medium':'#f59e0b','Low':'#22c55e'}[data.priority] || '#94a3b8';
    body.innerHTML = [
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">',
        '  <div><span style="font-size:.72rem;color:var(--muted);display:block">Ticket Number</span><strong style="font-family:monospace;color:var(--primary)">' + (data.ticket_no || '#'+id) + '</strong></div>',
        '  <div><span style="font-size:.72rem;color:var(--muted);display:block">Status</span>' + badgeHtml(data.status || 'Open') + '</div>',
        '  <div><span style="font-size:.72rem;color:var(--muted);display:block">Category</span><span style="font-size:.85rem">' + escHtml(data.category || '—') + '</span></div>',
        '  <div><span style="font-size:.72rem;color:var(--muted);display:block">Priority</span><span style="font-size:.75rem;font-weight:700;color:'+pc+';background:'+pc+'15;padding:2px 8px;border-radius:20px">' + escHtml(data.priority || '—') + '</span></div>',
        '</div>',
        '<div style="margin-bottom:14px"><span style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px">Subject</span><div style="font-size:.92rem;font-weight:600">' + escHtml(data.subject || '—') + '</div></div>',
        data.description ? '<div style="margin-bottom:14px"><span style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px">Description</span><div style="font-size:.84rem;background:#f8fafc;border-radius:8px;padding:10px">' + escHtml(data.description) + '</div></div>' : '',
        data.response ? '<div><span style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px">Bank Response</span><div style="font-size:.84rem;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:10px;color:#166534">' + escHtml(data.response) + '</div></div>' : '<div class="cp-alert cp-alert-info" style="font-size:.82rem"><i class="fa-solid fa-clock"></i><div>Awaiting response from our support team. Expected within 3 business days.</div></div>',
    ].join('');
    CP.openModal('view-complaint-modal');
}
function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function badgeHtml(s){
    var map={'Open':'#3b82f6','In Progress':'#f59e0b','Resolved':'#22c55e','Closed':'#94a3b8'};
    var c=map[s]||'#94a3b8';
    return '<span style="font-size:.75rem;font-weight:700;color:'+c+';background:'+c+'15;padding:2px 8px;border-radius:20px">'+escHtml(s)+'</span>';
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
