<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
$customer    = cp_guard();
$pageTitle   = 'My Dashboard — ' . CP_NAME;
$breadcrumb  = [['label' => 'Dashboard']];
$needsCharts = true;
$custId      = (int)($customer['id'] ?? 0);

// Get accounts
$accounts = CP_Database::query(
  "SELECT a.*, COALESCE(b.name,'--') AS branch_name
     FROM accounts a LEFT JOIN branches b ON b.id=a.branch_id
     WHERE a.customer_id=? AND a.status='Active'
     ORDER BY a.opened_date ASC",
  [$custId]
) ?: cp_demo_accounts($custId);

// Total balance across all accounts
$totalBalance = array_sum(array_column($accounts, 'balance'));

// Recent transactions
$recentTxns = CP_Database::query(
  "SELECT t.*, a.account_number FROM transactions t
     JOIN accounts a ON a.id=t.account_id
     WHERE a.customer_id=? ORDER BY t.created_at DESC LIMIT 8",
  [$custId]
) ?: cp_demo_transactions($custId, 8);

// Active loans
$activeLoans = CP_Database::query(
  "SELECT * FROM loans WHERE customer_id=? AND status IN('Active','Disbursed') ORDER BY created_at DESC LIMIT 3",
  [$custId]
) ?: [];

// Pending KYC
$kycStatus = $customer['kyc_status'] ?? 'Pending';

// Stats
$txnCount  = (int)(CP_Database::queryOne("SELECT COUNT(*) AS c FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND MONTH(t.created_at)=MONTH(CURDATE())", [$custId])['c'] ?? count($recentTxns));
$loanCount = (int)(CP_Database::queryOne("SELECT COUNT(*) AS c FROM loans WHERE customer_id=? AND status IN('Active','Disbursed')", [$custId])['c'] ?? 0);

$hour  = (int)date('G');
$greet = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$first = cp_e($customer['first_name'] ?? 'Customer');
$avatarUrl = cp_avatar($customer);
$initials  = cp_initials($customer);
$fullName  = cp_full_name($customer);

include dirname(__DIR__) . '/includes/header.php';

// Get primary account for the hero card
$primaryAcc = $accounts[0] ?? ['account_number' => '100XXXXXXXXXX', 'balance' => 0, 'account_type' => 'Savings', 'currency' => 'ETB', 'status' => 'Active', 'id' => 0];
$primaryBal = (float)$primaryAcc['balance'];
?>

<!-- ═══════════════════════════════════════════════════════
     DASHBOARD HERO — wallet-style card
═══════════════════════════════════════════════════════ -->
<div class="cp-dash-hero" id="cp-dash-hero">

  <!-- Decorative blobs -->
  <div class="cp-hero-blob cp-hero-blob1"></div>
  <div class="cp-hero-blob cp-hero-blob2"></div>

  <!-- TOP ROW: avatar + greeting | clock -->
  <div class="cp-hero-top">
    <div style="display:flex;align-items:center;gap:12px">
      <!-- Profile photo (clickable → profile edit) -->
      <a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-hero-avatar" id="hero-avatar" title="Edit profile photo">
        <?php if ($avatarUrl): ?>
          <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= cp_e($fullName) ?>">
        <?php else: ?>
          <span><?= $initials ?></span>
        <?php endif; ?>
        <div class="cp-hero-avatar-badge" title="Upload photo">
          <i class="fa-solid fa-camera" style="font-size:.55rem"></i>
        </div>
      </a>
      <div>
        <div class="cp-hero-greet"><?= $greet ?></div>
        <div class="cp-hero-name"><?= $first ?></div>
      </div>
    </div>
    <!-- Live clock -->
    <div style="text-align:right">
      <div class="cp-hero-clock" id="cp-hero-clock">00:00:00</div>
      <div class="cp-hero-date" id="cp-hero-date"><?= date('l, F j, Y') ?></div>
    </div>
  </div>

  <!-- BALANCE SECTION -->
  <div class="cp-hero-bal-section">
    <div class="cp-hero-bal-label">
      Available Balance
      <button class="cp-hero-eye" id="cp-bal-toggle" onclick="toggleBalance()" title="Show/hide balance" style="background:none;border:none;cursor:pointer;color:rgba(255,255,255,.6);margin-left:6px;font-size:.9rem;padding:0;vertical-align:middle">
        <i class="fa-solid fa-eye" id="cp-bal-eye"></i>
      </button>
    </div>
    <div class="cp-hero-bal-amount" id="cp-hero-bal">
      ETB <?= number_format($primaryBal, 2) ?>
    </div>
    <?php if (count($accounts) > 1): ?>
      <div class="cp-hero-bal-sub">
        Total portfolio: ETB <?= number_format($totalBalance, 2) ?>
        across <?= count($accounts) ?> accounts
      </div>
    <?php endif; ?>
  </div>

  <!-- 3 QUICK ACTION BUTTONS -->
  <div class="cp-hero-actions">
    <a href="<?= CP_BASE_URL ?>/customer/deposits/index.php" class="cp-hero-btn">
      <div class="cp-hero-btn-ic"><i class="fa-solid fa-arrow-down"></i></div>
      <span>Receive</span>
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/transfers/abay-bank.php" class="cp-hero-btn">
      <div class="cp-hero-btn-ic"><i class="fa-solid fa-paper-plane"></i></div>
      <span>Send</span>
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/transfers/own-account.php" class="cp-hero-btn">
      <div class="cp-hero-btn-ic"><i class="fa-solid fa-arrow-right-arrow-left"></i></div>
      <span>Swap</span>
    </a>
  </div>

  <!-- ACCOUNT NUMBER ROW -->
  <div class="cp-hero-acct-row">
    <div style="display:flex;align-items:center;gap:10px">
      <div class="cp-hero-acct-icon"><i class="fa-solid fa-shield-halved"></i></div>
      <div>
        <div style="font-size:.65rem;opacity:.55;font-weight:600;letter-spacing:.05em;text-transform:uppercase">Your Account Number</div>
        <div class="cp-hero-acct-num"><?= cp_e($primaryAcc['account_number']) ?></div>
      </div>
      <span class="cp-hero-status-badge <?= $primaryAcc['status'] === 'Active' ? 'active' : 'inactive' ?>">
        ● <?= cp_e($primaryAcc['status'] ?? 'Active') ?>
      </span>
    </div>
    <div style="display:flex;gap:8px">
      <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php?account=<?= (int)($primaryAcc['id'] ?? 0) ?>" class="cp-hero-chip">
        <i class="fa-solid fa-chart-line"></i> Transactions
      </a>
      <a href="<?= CP_BASE_URL ?>/customer/deposits/index.php" class="cp-hero-chip cp-hero-chip-gold">
        <i class="fa-solid fa-arrow-down"></i> Top Up
      </a>
    </div>
  </div>

</div><!-- /.cp-dash-hero -->

<!-- Secondary account cards (if more than 1) -->
<?php if (count($accounts) > 1): ?>
  <div class="cp-balance-grid" style="margin-bottom:24px">
    <?php foreach (array_slice($accounts, 1) as $acc): ?>
      <div class="cp-balance-card">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;position:relative;z-index:1">
          <div>
            <div class="cp-balance-label"><?= cp_e($acc['account_type'] ?? 'Account') ?></div>
            <div class="cp-balance-amount"><?= cp_etb((float)$acc['balance']) ?></div>
          </div>
          <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:6px 10px;font-size:.7rem;font-weight:700"><?= $acc['currency'] ?? 'ETB' ?></div>
        </div>
        <div class="cp-balance-acct" style="position:relative;z-index:1">
          <span style="font-family:monospace"><?= cp_e($acc['account_number'] ?? '') ?></span>
          &nbsp;·&nbsp;
          <span style="color:#C8A84B">● <?= cp_e($acc['status'] ?? 'Active') ?></span>
        </div>
        <div style="margin-top:12px;display:flex;gap:8px;position:relative;z-index:1">
          <a href="<?= CP_BASE_URL ?>/customer/accounts/details.php?id=<?= (int)($acc['id'] ?? 0) ?>" class="cp-btn cp-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:none;font-size:.74rem"><i class="fa-solid fa-eye"></i> Details</a>
          <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php?account=<?= (int)($acc['id'] ?? 0) ?>" class="cp-btn cp-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:none;font-size:.74rem"><i class="fa-solid fa-list"></i> History</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<style>
  /* ── Dashboard Hero ─────────────────────────────────────── */
  .cp-dash-hero {
    background: linear-gradient(160deg, #0d2137 0%, #0f3850 45%, #005464 100%);
    border-radius: 20px;
    padding: 22px 22px 0;
    margin-bottom: 22px;
    color: #fff;
    position: relative;
    overflow: hidden;
    box-shadow: 0 12px 40px rgba(0, 0, 0, .22);
  }

  .cp-hero-blob {
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
  }

  .cp-hero-blob1 {
    top: -60px;
    right: -40px;
    width: 200px;
    height: 200px;
    background: radial-gradient(circle, rgba(200, 168, 75, .22), transparent 70%);
  }

  .cp-hero-blob2 {
    bottom: -30px;
    left: -20px;
    width: 140px;
    height: 140px;
    background: radial-gradient(circle, rgba(0, 180, 138, .18), transparent 70%);
  }

  /* Top row */
  .cp-hero-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
  }

  /* Avatar */
  .cp-hero-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1B3A5C, #007A8A);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    font-weight: 800;
    color: #fff;
    overflow: hidden;
    flex-shrink: 0;
    position: relative;
    border: 2.5px solid rgba(255, 255, 255, .3);
    text-decoration: none;
  }

  .cp-hero-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  .cp-hero-avatar-badge {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: #C8A84B;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1.5px solid rgba(0, 0, 0, .3);
  }

  .cp-hero-greet {
    font-size: .72rem;
    opacity: .65;
    font-weight: 500;
  }

  .cp-hero-name {
    font-size: 1.05rem;
    font-weight: 800;
  }

  /* Clock */
  .cp-hero-clock {
    font-size: 1.35rem;
    font-weight: 900;
    letter-spacing: .04em;
    font-variant-numeric: tabular-nums;
    line-height: 1;
  }

  .cp-hero-date {
    font-size: .68rem;
    opacity: .55;
    margin-top: 3px;
  }

  /* Balance */
  .cp-hero-bal-section {
    position: relative;
    z-index: 1;
    margin-bottom: 20px;
  }

  .cp-hero-bal-label {
    font-size: .72rem;
    opacity: .6;
    text-transform: uppercase;
    letter-spacing: .1em;
    font-weight: 700;
    margin-bottom: 6px;
  }

  .cp-hero-bal-amount {
    font-size: 2.2rem;
    font-weight: 900;
    letter-spacing: -.02em;
    line-height: 1;
    margin-bottom: 5px;
  }

  .cp-hero-bal-sub {
    font-size: .72rem;
    opacity: .5;
  }

  /* 3 action buttons */
  .cp-hero-actions {
    display: flex;
    gap: 10px;
    margin-bottom: 18px;
    position: relative;
    z-index: 1;
  }

  .cp-hero-btn {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 7px;
    padding: 14px 8px;
    border-radius: 14px;
    background: rgba(255, 255, 255, .1);
    border: 1px solid rgba(255, 255, 255, .12);
    color: #fff;
    text-decoration: none;
    transition: background .2s, transform .15s;
    font-size: .73rem;
    font-weight: 700;
  }

  .cp-hero-btn:hover {
    background: rgba(255, 255, 255, .18);
    transform: translateY(-2px);
  }

  .cp-hero-btn-ic {
    width: 40px;
    height: 40px;
    border-radius: 11px;
    background: rgba(255, 255, 255, .14);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
  }

  /* Account row */
  .cp-hero-acct-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    background: rgba(0, 0, 0, .25);
    border-radius: 0 0 16px 16px;
    margin: 0 -22px;
    padding: 14px 22px;
    position: relative;
    z-index: 1;
  }

  .cp-hero-acct-icon {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    background: rgba(255, 255, 255, .1);
    color: rgba(255, 255, 255, .65);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .8rem;
  }

  .cp-hero-acct-num {
    font-size: .88rem;
    font-weight: 800;
    font-family: monospace;
    letter-spacing: .04em;
  }

  .cp-hero-status-badge {
    font-size: .65rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 99px;
    margin-left: 4px;
  }

  .cp-hero-status-badge.active {
    background: rgba(34, 197, 94, .18);
    color: #4ade80;
  }

  .cp-hero-status-badge.inactive {
    background: rgba(239, 68, 68, .18);
    color: #f87171;
  }

  /* Chip buttons */
  .cp-hero-chip {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 7px 14px;
    border-radius: 9px;
    font-size: .75rem;
    font-weight: 700;
    background: rgba(255, 255, 255, .1);
    color: #fff;
    text-decoration: none;
    border: 1px solid rgba(255, 255, 255, .14);
    transition: background .2s;
  }

  .cp-hero-chip:hover {
    background: rgba(255, 255, 255, .2);
  }

  .cp-hero-chip-gold {
    background: rgba(200, 168, 75, .3);
    border-color: rgba(200, 168, 75, .5);
    color: #fde68a;
  }

  .cp-hero-chip-gold:hover {
    background: rgba(200, 168, 75, .45);
  }

  @media (max-width: 520px) {
    .cp-hero-bal-amount {
      font-size: 1.7rem;
    }

    .cp-hero-acct-row {
      flex-direction: column;
      align-items: flex-start;
    }
  }
</style>

<script>
  /* ── Live clock ── */
  (function clockTick() {
    var el = document.getElementById('cp-hero-clock');
    if (el) {
      var now = new Date();
      el.textContent = now.toLocaleTimeString('en-ET', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      });
    }
    setTimeout(clockTick, 1000);
  })();

  /* ── Balance hide/show toggle ── */
  var _balHidden = false;
  var _balReal = document.getElementById('cp-hero-bal')?.textContent || '';

  function toggleBalance() {
    var el = document.getElementById('cp-hero-bal');
    var eye = document.getElementById('cp-bal-eye');
    if (!el) return;
    _balHidden = !_balHidden;
    el.textContent = _balHidden ? '●●●●●●●●' : _balReal;
    eye.className = _balHidden ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
  }
</script>

<!-- Stats Row -->
<div class="cp-stats">
  <div class="cp-stat">
    <div class="cp-stat-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-arrow-right-arrow-left"></i></div>
    <div>
      <div class="cp-stat-val"><?= $txnCount ?></div>
      <div class="cp-stat-lbl">Txns This Month</div>
    </div>
  </div>
  <div class="cp-stat">
    <div class="cp-stat-ic" style="background:#ede9fe;color:#7c3aed"><i class="fa-solid fa-file-invoice-dollar"></i></div>
    <div>
      <div class="cp-stat-val"><?= $loanCount ?></div>
      <div class="cp-stat-lbl">Active Loans</div>
    </div>
  </div>
  <div class="cp-stat">
    <div class="cp-stat-ic" style="background:#dcfce7;color:#16a34a"><i class="fa-solid fa-id-card"></i></div>
    <div>
      <div class="cp-stat-val"><?= cp_e($kycStatus) ?></div>
      <div class="cp-stat-lbl">KYC Status</div>
    </div>
  </div>
  <div class="cp-stat">
    <div class="cp-stat-ic" style="background:#fef9c3;color:#b45309"><i class="fa-solid fa-building-columns"></i></div>
    <div>
      <div class="cp-stat-val"><?= count($accounts) ?></div>
      <div class="cp-stat-lbl">Accounts</div>
    </div>
  </div>
</div>

<!-- Quick Actions -->
<div class="cp-quick-actions">
  <?php
  $actions = [
    [CP_BASE_URL . '/customer/transfers/index.php',  'fa-right-left',       'Transfer',   '#007A8A', '#e0f5f7'],
    [CP_BASE_URL . '/customer/deposits/index.php',   'fa-arrow-down',       'Deposit',    '#22c55e', '#dcfce7'],
    [CP_BASE_URL . '/customer/withdrawals/index.php', 'fa-arrow-up',         'Withdraw',   '#ef4444', '#fee2e2'],
    [CP_BASE_URL . '/customer/statements/index.php', 'fa-file-lines',       'Statement',  '#3b82f6', '#dbeafe'],
    [CP_BASE_URL . '/customer/loans/index.php',      'fa-file-invoice-dollar', 'Loans',    '#7c3aed', '#ede9fe'],
    [CP_BASE_URL . '/customer/cards/index.php',      'fa-credit-card',      'Cards',      '#C8A84B', '#fef9c3'],
    [CP_BASE_URL . '/customer/kyc/index.php',        'fa-id-card',          'KYC',        '#1B3A5C', '#e2e8f0'],
    [CP_BASE_URL . '/customer/appointments/index.php', 'fa-calendar-days',   'Appointment', '#0d9488', '#e0f5f7'],
  ];
  foreach ($actions as [$href, $ic, $lbl, $clr, $bg]): ?>
    <a href="<?= $href ?>" class="cp-qa">
      <div class="cp-qa-ic" style="background:<?= $bg ?>;color:<?= $clr ?>"><i class="fa-solid <?= $ic ?>"></i></div>
      <span class="cp-qa-label"><?= $lbl ?></span>
    </a>
  <?php endforeach; ?>
</div>

<!-- Charts + Activity -->
<div class="cp-grid-2">
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-chart-line" style="color:var(--teal)"></i> Balance &amp; Spending</h3>
    </div>
    <div class="cp-card-body"><canvas id="balance-chart" height="200"></canvas></div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-chart-pie" style="color:#C8A84B"></i> Transaction Types</h3>
    </div>
    <div class="cp-card-body"><canvas id="txn-type-chart" height="200"></canvas></div>
  </div>
</div>

<!-- Recent Transactions -->
<div class="cp-card">
  <div class="cp-card-hdr">
    <h3><i class="fa-solid fa-clock-rotate-left" style="color:var(--navy)"></i> Recent Transactions</h3>
    <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php" class="cp-btn cp-btn-outline cp-btn-sm">View All</a>
  </div>
  <div class="cp-card-body p0">
    <div class="cp-activity-feed">
      <?php
      $txnIcons = ['Deposit' => ['fa-arrow-down', '#22c55e', '#dcfce7'], 'Withdrawal' => ['fa-arrow-up', '#ef4444', '#fee2e2'], 'Transfer Out' => ['fa-right-left', '#3b82f6', '#dbeafe'], 'Transfer In' => ['fa-right-left', '#22c55e', '#dcfce7'], 'Loan Disbursement' => ['fa-file-invoice-dollar', '#7c3aed', '#ede9fe'], 'Loan Repayment' => ['fa-money-bill-wave', '#16a34a', '#dcfce7']];
      foreach ($recentTxns as $t):
        $isCredit = in_array($t['type'] ?? '', ['Deposit', 'Transfer In', 'Loan Disbursement']);
        [$ic, $clr, $bg] = $txnIcons[$t['type'] ?? ''] ?? ['fa-circle', '#64748b', '#f1f5f9'];
      ?>
        <div class="cp-activity-item" style="padding:12px 20px">
          <div class="cp-activity-ic" style="background:<?= $bg ?>;color:<?= $clr ?>"><i class="fa-solid <?= $ic ?>"></i></div>
          <div style="flex:1;min-width:0">
            <div class="cp-activity-text"><?= cp_e($t['description'] ?? $t['type'] ?? 'Transaction') ?></div>
            <div class="cp-activity-time"><?= cp_ago($t['created_at'] ?? '') ?> &middot; <?= cp_e($t['account_number'] ?? '') ?></div>
          </div>
          <div class="cp-activity-amount" style="color:<?= $isCredit ? '#16a34a' : '#dc2626' ?>">
            <?= $isCredit ? '+' : '-' ?><?= cp_etb(abs((float)($t['amount'] ?? 0))) ?>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($recentTxns)): ?>
        <div style="text-align:center;padding:40px;color:var(--muted)"><i class="fa-solid fa-inbox" style="font-size:2rem;display:block;margin-bottom:10px"></i>No transactions yet</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Active Loans (if any) -->
<?php if (!empty($activeLoans)): ?>
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-file-invoice-dollar" style="color:#7c3aed"></i> Active Loans</h3>
      <a href="<?= CP_BASE_URL ?>/customer/loans/index.php" class="cp-btn cp-btn-outline cp-btn-sm">Manage</a>
    </div>
    <div class="cp-card-body p0">
      <table class="cp-table">
        <thead>
          <tr>
            <th>Loan No.</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Outstanding</th>
            <th>Next Due</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($activeLoans as $l): ?>
            <tr>
              <td style="font-family:monospace;font-size:.82rem"><?= cp_e($l['loan_number'] ?? 'LN-XXXXXX') ?></td>
              <td><?= cp_e($l['loan_type'] ?? '—') ?></td>
              <td class="fw-6">ETB <?= number_format((float)($l['amount'] ?? 0)) ?></td>
              <td style="color:#ef4444;font-weight:600">ETB <?= number_format((float)($l['outstanding'] ?? 0)) ?></td>
              <td><?= cp_date($l['next_due_date'] ?? '') ?></td>
              <td><?= cp_badge($l['status'] ?? 'Active') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>

<?php
include dirname(__DIR__) . '/includes/footer.php';
?>