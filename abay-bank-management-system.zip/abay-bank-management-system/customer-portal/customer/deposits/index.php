<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Deposits — ' . CP_NAME;
$breadcrumb = [['label' => 'Deposits']];
$error = null; $success = null;
$accounts = CP_Database::query("SELECT id,account_number,account_type,balance FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId);
$history  = CP_Database::query("SELECT t.*,a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND t.type='Deposit' ORDER BY t.created_at DESC LIMIT 10",[$custId]) ?: array_filter(cp_demo_transactions($custId,8),fn($t)=>$t['type']==='Deposit');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cp_csrf_check();
    $accId  = (int)($_POST['account']      ??0);
    $amount = (float)($_POST['amount']     ??0);
    $type   = trim($_POST['deposit_type'] ??'Cash');
    $desc   = trim($_POST['description']  ??'Cash Deposit');
    if (!$accId)       $error='Please select an account.';
    elseif ($amount<CP_MIN_DEPOSIT) $error='Minimum deposit is '.cp_etb(CP_MIN_DEPOSIT).'.';
    else {
        $acc=CP_Database::queryOne("SELECT * FROM accounts WHERE id=? AND customer_id=?",[$accId,$custId]);
        if (!$acc&&!empty($accounts))$acc=$accounts[0];
        $ref='DEP-'.strtoupper(substr(uniqid('',true),-8));
        if ($acc&&CP_Database::get()){
            $nb=(float)$acc['balance']+$amount;
            CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$nb,$acc['id']]);
            CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Deposit',?,?,?,?,'Completed',NOW())",[$acc['id'],$amount,$nb,$desc,$ref]);
            $success="Deposit of ".cp_etb($amount)." successful! Ref: $ref";
        } else { $success="Demo: Deposit of ".cp_etb($amount)." recorded. Ref: $ref"; }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-arrow-down" style="color:#22c55e"></i> Deposits</h1><p>Request a deposit or view your deposit history</p></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div class="cp-grid-2" style="align-items:start">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3><i class="fa-solid fa-arrow-down" style="color:#22c55e"></i> Make a Deposit</h3></div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">Deposit to Account *</label>
          <select name="account" class="cp-select" required>
            <option value="">Select account…</option>
            <?php foreach ($accounts as $a): ?><option value="<?= $a['id'] ?>"><?= cp_e($a['account_number']) ?> · <?= cp_e($a['account_type']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="cp-fg"><label class="cp-label">Deposit Type</label>
          <select name="deposit_type" class="cp-select">
            <option>Cash</option><option>Cheque</option><option>Mobile Money</option><option>Bank Transfer</option>
          </select></div>
        <div class="cp-fg"><label class="cp-label">Amount (ETB) *</label>
          <div class="cp-inp-wrap"><span style="position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.82rem;font-weight:600">ETB</span>
            <input type="number" name="amount" class="cp-input" style="padding-left:48px" min="<?= CP_MIN_DEPOSIT ?>" placeholder="0.00" required></div></div>
        <div class="cp-fg"><label class="cp-label">Narration</label><input type="text" name="description" class="cp-input" value="Cash Deposit" placeholder="Purpose of deposit"></div>
        <button type="submit" class="cp-btn cp-btn-primary w-full" style="background:linear-gradient(135deg,#16a34a,#22c55e)"><i class="fa-solid fa-arrow-down"></i> Process Deposit</button>
      </form>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Deposit History</h3></div>
    <div class="cp-card-body p0">
      <table class="cp-table">
        <thead><tr><th>Date</th><th>Account</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($history as $d): ?>
          <tr>
            <td style="font-size:.8rem"><?= cp_date($d['created_at']??'','d M H:i') ?></td>
            <td style="font-family:monospace;font-size:.8rem"><?= cp_e($d['account_number']??'—') ?></td>
            <td style="font-weight:700;color:#16a34a">+<?= cp_etb((float)($d['amount']??0)) ?></td>
            <td><?= cp_badge($d['status']??'Completed') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
