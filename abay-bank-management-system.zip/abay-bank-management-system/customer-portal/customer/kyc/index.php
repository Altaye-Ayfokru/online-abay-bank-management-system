<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'KYC Verification — ' . CP_NAME;
$breadcrumb = [['label' => 'KYC Verification']];

$kycStatus = $customer['kyc_status'] ?? 'Pending';
$docs = CP_Database::query("SELECT * FROM customer_documents WHERE customer_id=? ORDER BY uploaded_at DESC",[$custId]) ?: [];

$docTypes = [
  ['National ID','National ID card or Kebele ID (Front & Back)','fa-id-card'],
  ['Passport','Valid Ethiopian passport (if available)','fa-passport'],
  ['Photo','Recent passport-size photograph','fa-camera'],
  ['Utility Bill','Electric, water or phone bill (address proof)','fa-file-invoice'],
];

$statusColors = ['Verified'=>'#22c55e','Pending'=>'#f59e0b','Under Review'=>'#3b82f6','Rejected'=>'#ef4444'];
$statusColor  = $statusColors[$kycStatus] ?? '#f59e0b';

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-id-card" style="color:var(--teal)"></i> KYC Verification</h1><p>Complete your identity verification to unlock all banking features</p></div>
</div>

<!-- Status Banner -->
<div style="background:<?= $statusColor ?>15;border:2px solid <?= $statusColor ?>30;border-radius:16px;padding:20px 24px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
  <div style="display:flex;align-items:center;gap:14px">
    <div style="width:50px;height:50px;background:<?= $statusColor ?>20;border-radius:50%;display:flex;align-items:center;justify-content:center">
      <i class="fa-solid fa-<?= $kycStatus==='Verified'?'circle-check':($kycStatus==='Rejected'?'circle-xmark':'clock') ?>" style="font-size:1.3rem;color:<?= $statusColor ?>"></i>
    </div>
    <div>
      <div style="font-weight:800;font-size:1rem;color:#1e293b">KYC Status: <span style="color:<?= $statusColor ?>"><?= cp_e($kycStatus) ?></span></div>
      <div style="font-size:.83rem;color:var(--muted)">
        <?php if ($kycStatus==='Verified'): ?>Your identity has been verified. All features are available.
        <?php elseif ($kycStatus==='Pending'): ?>Please upload your documents to complete verification.
        <?php elseif ($kycStatus==='Under Review'): ?>Your documents are being reviewed. This takes 1–3 business days.
        <?php else: ?>Your documents were rejected. Please re-upload with correct documents.<?php endif; ?>
      </div>
    </div>
  </div>
  <?php if ($kycStatus==='Verified'): ?>
  <div style="background:#22c55e20;border:1px solid #a7f3d0;border-radius:10px;padding:10px 16px;font-size:.83rem;color:#065f46;font-weight:600"><i class="fa-solid fa-shield-halved"></i> Fully Verified</div>
  <?php endif; ?>
</div>

<!-- Progress timeline -->
<div class="cp-card" style="margin-bottom:24px">
  <div class="cp-card-hdr"><h3>Verification Progress</h3></div>
  <div class="cp-card-body">
    <div style="display:flex;align-items:center;gap:0;flex-wrap:wrap">
      <?php $steps=[['Account Created','fa-user-plus','Completed'],['Documents Uploaded',count($docs)>0?'fa-circle-check':'fa-clock',count($docs)>0?'Completed':'Pending'],['Under Review','fa-magnifying-glass',$kycStatus==='Under Review'||$kycStatus==='Verified'?'Completed':'Pending'],['Verified','fa-shield-halved',$kycStatus==='Verified'?'Completed':'Pending']];
      foreach ($steps as $i=>[$label,$ic,$status]):
        $active = $status==='Completed';
        $clr = $active?'#22c55e':'#cbd5e1';
      ?>
      <div style="display:flex;align-items:center;flex:1;min-width:120px">
        <div style="text-align:center;flex:1">
          <div style="width:40px;height:40px;border-radius:50%;background:<?= $active?'#dcfce7':'#f1f5f9' ?>;border:3px solid <?= $clr ?>;display:flex;align-items:center;justify-content:center;margin:0 auto 6px">
            <i class="fa-solid <?= $ic ?>" style="color:<?= $clr ?>;font-size:.9rem"></i>
          </div>
          <div style="font-size:.72rem;font-weight:600;color:<?= $active?'#16a34a':'#94a3b8' ?>"><?= $label ?></div>
        </div>
        <?php if ($i<3): ?><div style="flex:1;height:3px;background:<?= $active?'#22c55e':'#e2e8f0' ?>;margin-bottom:22px"></div><?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Document upload section -->
<div class="cp-grid-2">
  <div>
    <div class="cp-card">
      <div class="cp-card-hdr"><h3>Required Documents</h3></div>
      <div class="cp-card-body">
        <?php foreach ($docTypes as [$type,$desc,$icon]):
          $uploaded = !empty(array_filter($docs, fn($d)=>($d['doc_type']??'')===$type));
        ?>
        <div style="display:flex;align-items:flex-start;gap:14px;padding:14px 0;border-bottom:1px solid var(--border)">
          <div style="width:44px;height:44px;background:<?= $uploaded?'#dcfce7':'#f1f5f9' ?>;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fa-solid <?= $icon ?>" style="color:<?= $uploaded?'#22c55e':'#94a3b8' ?>;font-size:1rem"></i>
          </div>
          <div style="flex:1">
            <div style="font-weight:700;font-size:.88rem;margin-bottom:3px"><?= $type ?></div>
            <div style="font-size:.78rem;color:var(--muted)"><?= $desc ?></div>
            <?php if ($uploaded): ?>
            <span style="font-size:.72rem;color:#22c55e;font-weight:700"><i class="fa-solid fa-circle-check"></i> Uploaded</span>
            <?php endif; ?>
          </div>
          <div>
            <label style="cursor:pointer" onclick="startUpload('<?= cp_e($type) ?>')">
              <span class="cp-btn cp-btn-outline cp-btn-sm"><?= $uploaded?'Re-upload':'Upload' ?></span>
            </label>
          </div>
        </div>
        <?php endforeach; ?>
        <input type="file" id="kyc-file-input" accept=".jpg,.jpeg,.png,.pdf" style="display:none" onchange="uploadKYCDoc(this)">
        <input type="hidden" id="kyc-doc-type" value="">
        <div id="kyc-upload-status" style="display:none;margin-top:12px">
          <div class="cp-progress"><div class="cp-progress-fill" id="kyc-bar" style="width:0%;background:var(--teal)"></div></div>
          <p style="font-size:.75rem;color:var(--muted);margin-top:4px">Uploading…</p>
        </div>
      </div>
    </div>
  </div>
  <div>
    <div class="cp-card">
      <div class="cp-card-hdr"><h3>Uploaded Documents</h3></div>
      <div class="cp-card-body">
        <?php if (empty($docs)): ?>
        <div style="text-align:center;padding:24px;color:var(--muted)"><i class="fa-solid fa-folder-open" style="font-size:2rem;display:block;margin-bottom:10px"></i>No documents uploaded yet</div>
        <?php else: foreach ($docs as $d): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border)">
          <div><div style="font-weight:600;font-size:.85rem"><?= cp_e($d['doc_type']??'Document') ?></div>
          <div style="font-size:.75rem;color:var(--muted)"><?= cp_e($d['file_name']??'') ?> · <?= cp_ago($d['uploaded_at']??'') ?></div></div>
          <?= cp_badge($d['status']??'Pending') ?>
        </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
    <div class="cp-alert cp-alert-info" style="margin-top:0">
      <i class="fa-solid fa-circle-info"></i>
      <div style="font-size:.82rem"><strong>Acceptable formats:</strong> JPG, PNG, PDF (max 10 MB each)<br><strong>Review time:</strong> 1–3 business days after submission</div>
    </div>
  </div>
</div>
<script>
var _kycDocType='';
function startUpload(type){_kycDocType=type;document.getElementById('kyc-doc-type').value=type;document.getElementById('kyc-file-input').click();}
function uploadKYCDoc(input){
  if(!input.files||!input.files[0])return;
  var file=input.files[0];
  if(file.size>10*1024*1024){CP.toast('File must be under 10 MB','danger');return;}
  var status=document.getElementById('kyc-upload-status');
  var bar=document.getElementById('kyc-bar');
  if(status)status.style.display='';
  var fd=new FormData();fd.append('document',file);fd.append('doc_type',_kycDocType);
  var xhr=new XMLHttpRequest();
  xhr.open('POST','<?= CP_BASE_URL ?>/customer/kyc/upload-document.php',true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.upload.onprogress=function(e){if(e.lengthComputable&&bar)bar.style.width=Math.round(e.loaded/e.total*100)+'%';};
  xhr.onload=function(){
    if(status)status.style.display='none';
    try{var r=JSON.parse(xhr.responseText);CP.toast(r.success?_kycDocType+' uploaded!':(r.message||'Upload failed'),r.success?'success':'danger');}
    catch(e){CP.toast('Upload failed','danger');}
    if(xhr.status===200)setTimeout(function(){location.reload();},1500);
  };
  xhr.onerror=function(){if(status)status.style.display='none';CP.toast('Upload error','danger');};
  xhr.send(fd);
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
