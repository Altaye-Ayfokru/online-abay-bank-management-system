<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
header('Content-Type: application/json');
$customer = cp_customer();
if (!$customer||!cp_is_logged_in()){echo json_encode(['success'=>false,'message'=>'Not authenticated']);exit;}
if (empty($_FILES['document'])){echo json_encode(['success'=>false,'message'=>'No file uploaded']);exit;}
$file=$_FILES['document'];
$allowed=['application/pdf','image/jpeg','image/png','image/webp'];
if (!in_array($file['type'],$allowed)){echo json_encode(['success'=>false,'message'=>'Only PDF, JPG or PNG allowed']);exit;}
if ($file['size']>10*1024*1024){echo json_encode(['success'=>false,'message'=>'File must be under 10 MB']);exit;}
$imgInfo=($file['type']!=='application/pdf')?@getimagesize($file['tmp_name']):true;
if (!$imgInfo){echo json_encode(['success'=>false,'message'=>'Invalid file']);exit;}
$dir=CP_BASE_PATH.'/uploads/kyc/';
if(!is_dir($dir))mkdir($dir,0755,true);
$ext=['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$file['type']]??'bin';
$fn='kyc_'.(int)$customer['id'].'_'.preg_replace('/[^a-z0-9]/','',$_POST['doc_type']??'doc').'_'.time().'.'.$ext;
if(!move_uploaded_file($file['tmp_name'],$dir.$fn)){echo json_encode(['success'=>false,'message'=>'Save failed']);exit;}
$url=CP_BASE_URL.'/uploads/kyc/'.$fn;
CP_Database::execute("INSERT INTO customer_documents (customer_id,doc_type,file_name,file_path,status,uploaded_at) VALUES (?,?,?,?,'Pending',NOW())",[(int)$customer['id'],$_POST['doc_type']??'Other',$file['name'],$url]);
// Update kyc_status to Under Review if still Pending
CP_Database::execute("UPDATE customers SET kyc_status='Under Review' WHERE id=? AND kyc_status='Pending'",[(int)$customer['id']]);
$_SESSION['cp_customer']['kyc_status']='Under Review';
echo json_encode(['success'=>true,'url'=>$url,'message'=>'Document uploaded']);
