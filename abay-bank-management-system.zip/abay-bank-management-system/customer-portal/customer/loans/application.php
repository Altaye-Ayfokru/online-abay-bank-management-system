<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Loan Application — ' . CP_NAME;
$breadcrumb = [['label' => 'Loans', 'url' => CP_BASE_URL . '/customer/loans/index.php'], ['label' => 'Apply']];
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  cp_csrf_check();
  $type    = trim($_POST['loan_type'] ?? '');
  $amount  = (float)($_POST['amount'] ?? 0);
  $term    = (int)($_POST['term']     ?? 12);
  $purpose = trim($_POST['purpose']   ?? '');
  if (!$type)         $error = 'Loan type is required.';
  elseif ($amount < 500) $error = 'Minimum loan amount is ETB 500.';
  elseif ($term < 1)    $error = 'Loan term must be at least 1 month.';
  elseif (!$purpose || strlen($purpose) < 10) $error = 'Please describe the loan purpose (min 10 chars).';
  else {
    $loanNo = 'LN-' . strtoupper(substr(uniqid('', true), -6));
    $rate = 12.0;
    $emi = $amount * ($rate / 1200) / (1 - pow(1 + $rate / 1200, -$term));
    $db = CP_Database::get();
    if ($db) {
      CP_Database::execute("INSERT INTO loans (loan_number,customer_id,loan_type,amount,interest_rate,term_months,emi_amount,purpose,outstanding,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,'Pending',NOW())", [$loanNo, $custId, $type, $amount, $rate, $term, round($emi, 2), $purpose, $amount]);
      // Notify admin about new loan application
      $custName = cp_full_name($customer);
      cp_notify_admin(
        'loan',
        "New Loan Application: $loanNo",
        "$custName applied for a $type of " . cp_etb($amount) . " ($term months). Ref: $loanNo",
        $custId
      );
      $success = "Loan application submitted! Reference: $loanNo. We will review your application within 2-3 business days.";
    } else {
      $success = "Demo: Loan application ($loanNo) for " . cp_etb($amount) . " submitted successfully!";
    }
  }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i> Loan Application</h1>
    <p>Apply for a personal, business, or agricultural loan</p>
  </div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/loans/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div class="cp-grid-2" style="align-items:start">
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3>Application Form</h3>
    </div>
    <div class="cp-card-body">
      <form method="POST" id="loan-form">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">Loan Type *</label>
          <select name="loan_type" class="cp-select" required onchange="updateRate(this.value)">
            <option value="">Select loan type…</option>
            <?php foreach (CP_LOAN_TYPES as $t): ?><option><?= $t ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="cp-fg"><label class="cp-label">Loan Amount (ETB) *</label>
          <div class="cp-inp-wrap"><span style="position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.82rem;font-weight:600">ETB</span>
            <input type="number" name="amount" id="loan-amt" class="cp-input" style="padding-left:48px" min="500" required oninput="calcEMI()">
          </div>
        </div>
        <div class="cp-fg"><label class="cp-label">Interest Rate (% p.a.)</label>
          <input type="number" id="loan-rate" class="cp-input" value="12" step="0.1" oninput="calcEMI()" readonly style="background:var(--light);color:var(--muted)">
        </div>
        <div class="cp-fg"><label class="cp-label">Term (Months) *</label>
          <select name="term" id="loan-term" class="cp-select" required onchange="calcEMI()">
            <?php foreach ([6, 12, 18, 24, 36, 48, 60, 84, 120] as $m): ?><option value="<?= $m ?>" <?= $m === 12 ? 'selected' : '' ?>><?= $m ?> months</option><?php endforeach; ?>
          </select>
        </div>
        <div class="cp-fg"><label class="cp-label">Loan Purpose *</label>
          <textarea name="purpose" class="cp-textarea" rows="3" required minlength="10" placeholder="Describe the purpose of this loan (min 10 characters)…"></textarea>
        </div>
        <div class="cp-fg"><label class="cp-label">Employment Type</label>
          <select class="cp-select">
            <option>Employed</option>
            <option>Self-Employed</option>
            <option>Business Owner</option>
            <option>Other</option>
          </select>
        </div>
        <div class="cp-alert cp-alert-info" style="font-size:.82rem;margin-bottom:16px"><i class="fa-solid fa-circle-info"></i>
          <div>Applications are reviewed within 2–3 business days. You will be notified via SMS and email.</div>
        </div>
        <button type="submit" class="cp-btn cp-btn-primary w-full"><i class="fa-solid fa-paper-plane"></i> Submit Application</button>
      </form>
    </div>
  </div>
  <!-- EMI Calculator -->
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-calculator"></i> EMI Calculator</h3>
    </div>
    <div class="cp-card-body">
      <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);border-radius:12px;padding:20px;color:#fff;text-align:center;margin-bottom:16px">
        <div style="font-size:.72rem;opacity:.65;font-weight:700;text-transform:uppercase;margin-bottom:6px">Monthly EMI</div>
        <div style="font-size:2rem;font-weight:800" id="emi-display">—</div>
      </div>
      <?php foreach ([['emi-principal', 'Principal', '#1B3A5C'], ['emi-interest', 'Total Interest', '#ef4444'], ['emi-total', 'Total Payable', '#007A8A']] as [$id, $label, $color]): ?>
        <div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);font-size:.85rem">
          <span style="color:var(--muted)"><?= $label ?></span>
          <span style="font-weight:700;color:<?= $color ?>" id="<?= $id ?>">—</span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<script>
  var RATES = {
    'Personal Loan': 12,
    'Business Loan': 10.5,
    'Agricultural Loan': 8,
    'Mortgage Loan': 9,
    'Student Loan': 7
  };

  function updateRate(t) {
    var r = RATES[t] || 12;
    document.getElementById('loan-rate').value = r;
    calcEMI();
  }

  function calcEMI() {
    var p = parseFloat(document.getElementById('loan-amt').value) || 0;
    var r = parseFloat(document.getElementById('loan-rate').value) || 12;
    var n = parseInt(document.getElementById('loan-term').value) || 12;
    if (!p || !r || !n) {
      ['emi-display', 'emi-principal', 'emi-interest', 'emi-total'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.textContent = '—';
      });
      return;
    }
    var mr = r / 1200;
    var emi = p * mr * Math.pow(1 + mr, n) / (Math.pow(1 + mr, n) - 1);
    var total = emi * n;
    var interest = total - p;

    function fmt(v) {
      return 'ETB ' + v.toLocaleString('en-US', {
        minimumFractionDigits: 2
      });
    }
    document.getElementById('emi-display').textContent = fmt(emi);
    document.getElementById('emi-principal').textContent = fmt(p);
    document.getElementById('emi-interest').textContent = fmt(interest);
    document.getElementById('emi-total').textContent = fmt(total);
  }
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>