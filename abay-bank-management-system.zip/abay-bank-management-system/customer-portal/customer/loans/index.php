<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'My Loans — ' . CP_NAME;
$breadcrumb = [['label' => 'Loans']];
$needsCharts = true;

$loans = CP_Database::query("SELECT * FROM loans WHERE customer_id=? ORDER BY created_at DESC",[$custId]) ?: [
  ['id'=>1,'loan_number'=>'LN-A1B2C3','loan_type'=>'Personal Loan','amount'=>150000,'outstanding'=>92400,'interest_rate'=>12,'term_months'=>36,'emi_amount'=>4982,'status'=>'Active','created_at'=>'2024-06-01','next_due_date'=>date('Y-m-d',strtotime('+15 days'))],
  ['id'=>2,'loan_number'=>'LN-D4E5F6','loan_type'=>'Agricultural Loan','amount'=>80000,'outstanding'=>0,'interest_rate'=>8,'term_months'=>24,'emi_amount'=>3626,'status'=>'Completed','created_at'=>'2022-01-15','next_due_date'=>null],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i> My Loans</h1><p>View active loans, repayment schedules, and apply for new loans</p></div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/loans/application.php" class="cp-btn cp-btn-primary"><i class="fa-solid fa-plus"></i> Apply for Loan</a></div>
</div>
<!-- Active loans -->
<?php foreach ($loans as $l):
  $pct = $l['amount']>0 ? round((1-(float)$l['outstanding']/(float)$l['amount'])*100) : 100;
  $isActive = in_array($l['status']??'',['Active','Disbursed']);
?>
<div class="cp-card" style="border-left:4px solid <?= $isActive?'#ef4444':'#22c55e' ?>;margin-bottom:16px">
  <div class="cp-card-body">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:16px">
      <div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
          <span style="font-weight:800;font-size:.95rem;color:var(--navy)"><?= cp_e($l['loan_type']??'Loan') ?></span>
          <?= cp_badge($l['status']??'Active') ?>
        </div>
        <div style="font-size:.8rem;font-family:monospace;color:var(--muted)"><?= cp_e($l['loan_number']??'—') ?></div>
      </div>
      <div style="text-align:right">
        <div style="font-size:.73rem;color:var(--muted)">Outstanding</div>
        <div style="font-size:1.3rem;font-weight:800;color:<?= $isActive?'#ef4444':'#22c55e' ?>"><?= cp_etb((float)($l['outstanding']??0)) ?></div>
        <div style="font-size:.75rem;color:var(--muted)">of <?= cp_etb((float)($l['amount']??0)) ?></div>
      </div>
    </div>
    <!-- Progress bar -->
    <div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;font-size:.76rem;margin-bottom:4px">
        <span style="color:var(--muted)">Repayment Progress</span><span style="font-weight:700;color:<?= $isActive?'#1B3A5C':'#22c55e' ?>"><?= $pct ?>%</span>
      </div>
      <div class="cp-progress"><div class="cp-progress-fill" style="width:<?= $pct ?>%;background:<?= $isActive?'#1B3A5C':'#22c55e' ?>"></div></div>
    </div>
    <div style="display:flex;gap:20px;font-size:.8rem;color:var(--muted);flex-wrap:wrap;margin-bottom:14px">
      <span><i class="fa-solid fa-percent" style="color:var(--teal);margin-right:4px"></i><?= $l['interest_rate']??0 ?>% p.a.</span>
      <span><i class="fa-solid fa-calendar" style="color:var(--teal);margin-right:4px"></i><?= $l['term_months']??0 ?> months</span>
      <span><i class="fa-solid fa-money-bill" style="color:var(--teal);margin-right:4px"></i>EMI: <?= cp_etb((float)($l['emi_amount']??0)) ?></span>
      <?php if ($l['next_due_date']): ?><span><i class="fa-solid fa-clock" style="color:#f59e0b;margin-right:4px"></i>Due: <?= cp_date($l['next_due_date']) ?></span><?php endif; ?>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a href="<?= CP_BASE_URL ?>/customer/loans/repayment.php?id=<?= (int)($l['id']??0) ?>" class="cp-btn cp-btn-primary cp-btn-sm"><i class="fa-solid fa-calendar-check"></i> Repayment Schedule</a>
      <?php if ($isActive): ?><a href="<?= CP_BASE_URL ?>/customer/deposits/index.php" class="cp-btn cp-btn-outline cp-btn-sm"><i class="fa-solid fa-money-bill-wave"></i> Pay Installment</a><?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($loans)): ?>
<div class="cp-card"><div class="cp-card-body" style="text-align:center;padding:48px">
  <i class="fa-solid fa-file-invoice-dollar" style="font-size:2.5rem;color:#cbd5e1;display:block;margin-bottom:12px"></i>
  <p style="color:var(--muted);margin-bottom:16px">You don't have any loans yet.</p>
  <a href="<?= CP_BASE_URL ?>/customer/loans/application.php" class="cp-btn cp-btn-primary"><i class="fa-solid fa-plus"></i> Apply for a Loan</a>
</div></div>
<?php endif; ?>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
