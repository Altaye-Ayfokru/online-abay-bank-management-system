<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$loanId     = (int)($_GET['id'] ?? 0);
$pageTitle  = 'Repayment Schedule — ' . CP_NAME;
$breadcrumb = [['label'=>'Loans','url'=>CP_BASE_URL.'/customer/loans/index.php'],['label'=>'Schedule']];

$loan = CP_Database::queryOne("SELECT * FROM loans WHERE id=? AND customer_id=?",[$loanId,$custId])
     ?? ['id'=>$loanId,'loan_number'=>'LN-A1B2C3','loan_type'=>'Personal Loan','amount'=>150000,'outstanding'=>92400,'interest_rate'=>12,'term_months'=>36,'emi_amount'=>4982,'status'=>'Active','created_at'=>'2024-06-01'];

$schedule = cp_loan_schedule((float)$loan['amount'],(float)$loan['interest_rate'],(int)$loan['term_months']);
$paidCount = count(array_filter($schedule,fn($r)=>$r['status']==='Paid'));
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-calendar-check" style="color:var(--teal)"></i> Repayment Schedule</h1><p><?= cp_e($loan['loan_type']??'Loan') ?> — <?= cp_e($loan['loan_number']??'—') ?></p></div>
  <div class="cp-page-actions">
    <button onclick="window.print()" class="cp-btn cp-btn-outline"><i class="fa-solid fa-print"></i> Print</button>
    <a href="<?= CP_BASE_URL ?>/customer/loans/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>
<!-- Loan summary -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:24px">
  <?php foreach ([['Loan Amount',cp_etb((float)$loan['amount']),'#1B3A5C'],['Outstanding',cp_etb((float)$loan['outstanding']),'#ef4444'],['Monthly EMI',cp_etb((float)$loan['emi_amount']),'#007A8A'],['Rate',$loan['interest_rate'].'% p.a.','#f59e0b'],['Paid',$paidCount.' / '.$loan['term_months'].' months','#22c55e']] as [$l,$v,$c]): ?>
  <div class="cp-card" style="border-top:3px solid <?= $c ?>"><div class="cp-card-body" style="padding:14px"><div style="font-size:.73rem;color:var(--muted);margin-bottom:4px"><?= $l ?></div><div style="font-weight:800;color:<?= $c ?>"><?= $v ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="cp-card">
  <div class="cp-card-hdr"><h3>Amortization Schedule</h3></div>
  <div class="cp-card-body p0">
    <div class="cp-table-wrap">
      <table class="cp-table">
        <thead><tr><th>#</th><th>Due Date</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Balance</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($schedule as $row): ?>
          <tr style="background:<?= $row['status']==='Paid'?'#f0fdf4':($row['status']==='Upcoming'?'#fffbeb':'') ?>">
            <td><?= $row['month'] ?></td>
            <td style="font-size:.82rem"><?= cp_date($row['due_date']) ?></td>
            <td class="fw-6"><?= cp_etb($row['emi']) ?></td>
            <td style="color:#1B3A5C"><?= cp_etb($row['principal']) ?></td>
            <td style="color:#ef4444"><?= cp_etb($row['interest']) ?></td>
            <td class="fw-6" style="color:var(--muted)"><?= cp_etb($row['balance']) ?></td>
            <td><?= cp_badge($row['status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<style>@media print{.cp-topbar,.cp-sidebar,.cp-page-actions,.cp-sb-backdrop{display:none!important;}.cp-main{margin:0!important;padding:0!important;}}</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
