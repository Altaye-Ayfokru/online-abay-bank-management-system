<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Messages — ' . CP_NAME;
$breadcrumb = [['label' => 'Messages']];

// Handle compose
$composeError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'send') {
    cp_csrf_check();
    $subject = trim($_POST['subject'] ?? '');
    $body    = trim($_POST['body']    ?? '');
    $dept    = trim($_POST['dept']    ?? 'Support');
    if (!$subject || !$body) {
        $composeError = 'Subject and message body are required.';
    } else {
        CP_Database::execute(
            "INSERT INTO messages (sender_id, sender_type, recipient_type, subject, body, department, status, sent_at) VALUES (?, 'customer', 'bank', ?, ?, ?, 'Sent', NOW())",
            [$custId, $subject, $body, $dept]
        );
        header('Location: ' . CP_BASE_URL . '/customer/messages/index.php?tab=sent&sent=1');
        exit;
    }
}

$tab = ($_GET['tab'] ?? 'inbox') === 'sent' ? 'sent' : 'inbox';

$inbox = CP_Database::query(
    "SELECT * FROM messages WHERE recipient_id=? AND recipient_type='customer' ORDER BY sent_at DESC LIMIT 50",
    [$custId]
) ?: [
    ['id' => 1, 'sender_name' => 'Abay Bank Support', 'subject' => 'Welcome to Customer Portal', 'body' => 'Dear Customer, Welcome to the Abay Bank Customer Portal. You can now manage your accounts, transfers, loans, and more online. For help, contact our 24/7 support at 8397.', 'is_read' => 0, 'sent_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 2, 'sender_name' => 'Loan Department', 'subject' => 'Loan Application Status Update', 'body' => 'Your loan application has been reviewed. Please visit your nearest branch with required documents within 5 business days to complete the process.', 'is_read' => 1, 'sent_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
    ['id' => 3, 'sender_name' => 'KYC Team', 'subject' => 'Document Verification Complete', 'body' => 'We are pleased to inform you that your identity documents have been verified successfully. Your account is now fully activated.', 'is_read' => 1, 'sent_at' => date('Y-m-d H:i:s', strtotime('-7 days'))],
];

$sent = CP_Database::query(
    "SELECT * FROM messages WHERE sender_id=? AND sender_type='customer' ORDER BY sent_at DESC LIMIT 50",
    [$custId]
) ?: [
    ['id' => 10, 'recipient_name' => 'Abay Bank Support', 'subject' => 'Question about transfer limits', 'body' => 'Hello, I would like to know the daily transfer limit for my savings account. Thank you.', 'status' => 'Read', 'sent_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
];

$unreadInbox = count(array_filter($inbox, fn($m) => !($m['is_read'] ?? 0)));
$messages    = $tab === 'sent' ? $sent : $inbox;

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
    <div>
        <h1><i class="fa-solid fa-envelope" style="color:var(--teal)"></i> Messages
            <?php if ($unreadInbox > 0): ?>
            <span style="background:#ef4444;color:#fff;font-size:.65rem;padding:2px 7px;border-radius:20px;font-weight:700;vertical-align:middle;margin-left:6px"><?= $unreadInbox ?></span>
            <?php endif; ?>
        </h1>
        <p>Communicate securely with Abay Bank support</p>
    </div>
    <div class="cp-page-actions">
        <button onclick="CP.openModal('compose-modal')" class="cp-btn cp-btn-primary">
            <i class="fa-solid fa-pen-to-square"></i> Compose
        </button>
    </div>
</div>

<?php if (isset($_GET['sent'])): ?>
<div class="cp-alert cp-alert-success"><i class="fa-solid fa-paper-plane"></i> Message sent successfully!</div>
<?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid var(--border);padding-bottom:0">
    <a href="?tab=inbox" style="text-decoration:none;padding:10px 20px;font-weight:600;font-size:.88rem;border-bottom:3px solid <?= $tab==='inbox'?'var(--teal)':'transparent' ?>;color:<?= $tab==='inbox'?'var(--teal)':'var(--muted)' ?>;margin-bottom:-2px">
        <i class="fa-solid fa-inbox"></i> Inbox
        <?php if ($unreadInbox > 0): ?><span style="background:#ef4444;color:#fff;font-size:.68rem;padding:1px 6px;border-radius:10px;margin-left:4px"><?= $unreadInbox ?></span><?php endif; ?>
    </a>
    <a href="?tab=sent" style="text-decoration:none;padding:10px 20px;font-weight:600;font-size:.88rem;border-bottom:3px solid <?= $tab==='sent'?'var(--teal)':'transparent' ?>;color:<?= $tab==='sent'?'var(--teal)':'var(--muted)' ?>;margin-bottom:-2px">
        <i class="fa-solid fa-paper-plane"></i> Sent
    </a>
</div>

<div style="display:grid;grid-template-columns:320px 1fr;gap:16px;align-items:start">
    <!-- Message list -->
    <div class="cp-card">
        <div class="cp-card-body p0">
            <?php if (empty($messages)): ?>
            <div style="text-align:center;padding:40px;color:var(--muted)">
                <i class="fa-solid fa-envelope-open" style="font-size:1.8rem;display:block;margin-bottom:8px;opacity:.3"></i>
                <div style="font-size:.85rem"><?= $tab === 'inbox' ? 'No messages yet.' : 'No sent messages.' ?></div>
            </div>
            <?php else: foreach ($messages as $i => $m):
                $isUnread = $tab === 'inbox' && !($m['is_read'] ?? 0);
            ?>
            <div class="msg-item" data-id="<?= $i ?>" onclick="showMessage(<?= $i ?>, <?= htmlspecialchars(json_encode($m), ENT_QUOTES) ?>)"
                 style="padding:14px 16px;border-bottom:1px solid var(--border);cursor:pointer;<?= $isUnread ? 'background:#f0f9ff;' : '' ?>;transition:background .15s"
                 onmouseenter="this.style.background='<?= $isUnread ? '#e0f2fe' : '#f8fafc' ?>'" onmouseleave="this.style.background='<?= $isUnread ? '#f0f9ff' : '' ?>'">
                <div style="display:flex;justify-content:space-between;margin-bottom:3px">
                    <div style="font-weight:<?= $isUnread ? '700' : '600' ?>;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px">
                        <?= cp_e($tab === 'inbox' ? ($m['sender_name'] ?? 'Abay Bank') : ($m['recipient_name'] ?? 'Support')) ?>
                    </div>
                    <div style="font-size:.7rem;color:var(--muted);flex-shrink:0;margin-left:4px"><?= cp_ago($m['sent_at'] ?? '') ?></div>
                </div>
                <div style="font-size:.8rem;<?= $isUnread ? 'font-weight:600' : 'color:var(--muted)' ?>;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                    <?= cp_e($m['subject'] ?? '—') ?>
                </div>
                <div style="font-size:.74rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px">
                    <?= cp_e(substr($m['body'] ?? '', 0, 60)) ?>…
                </div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>

    <!-- Message view -->
    <div class="cp-card" id="msg-view">
        <div class="cp-card-body" style="text-align:center;padding:60px;color:var(--muted)" id="msg-placeholder">
            <i class="fa-solid fa-envelope-open-text" style="font-size:2.5rem;display:block;margin-bottom:12px;opacity:.2"></i>
            <div style="font-size:.88rem">Select a message to read it</div>
        </div>
        <div id="msg-content" style="display:none;padding:24px">
            <div id="msg-meta" style="margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--border)"></div>
            <div id="msg-body" style="font-size:.88rem;line-height:1.7;color:#374151;white-space:pre-wrap"></div>
            <div id="msg-reply-btn" style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
                <button onclick="CP.openModal('compose-modal')" class="cp-btn cp-btn-outline cp-btn-sm"><i class="fa-solid fa-reply"></i> Reply</button>
            </div>
        </div>
    </div>
</div>

<!-- Compose modal -->
<div class="cp-modal-overlay" id="compose-modal">
    <div class="cp-modal" style="max-width:560px">
        <div class="cp-modal-hdr">
            <h3><i class="fa-solid fa-pen-to-square"></i> New Message</h3>
            <button class="cp-modal-close" onclick="CP.closeModal('compose-modal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="cp-modal-body">
            <?php if ($composeError): ?>
            <div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= cp_e($composeError) ?></div>
            <?php endif; ?>
            <form method="POST" id="compose-form">
                <?= cp_csrf_field() ?>
                <input type="hidden" name="action" value="send">
                <div class="cp-fg">
                    <label class="cp-label">Department</label>
                    <select name="dept" class="cp-select">
                        <?php foreach (['Support', 'Loans', 'Accounts', 'KYC', 'Cards', 'Complaints', 'General'] as $d): ?>
                        <option><?= $d ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cp-fg">
                    <label class="cp-label">Subject *</label>
                    <input type="text" name="subject" class="cp-input" placeholder="Message subject…" required>
                </div>
                <div class="cp-fg">
                    <label class="cp-label">Message *</label>
                    <textarea name="body" class="cp-textarea" rows="6" placeholder="Write your message here…" required></textarea>
                </div>
            </form>
        </div>
        <div class="cp-modal-footer">
            <button onclick="CP.closeModal('compose-modal')" class="cp-btn cp-btn-outline">Cancel</button>
            <button onclick="document.getElementById('compose-form').submit()" class="cp-btn cp-btn-primary">
                <i class="fa-solid fa-paper-plane"></i> Send Message
            </button>
        </div>
    </div>
</div>

<script>
var _activeMsg = null;
function showMessage(idx, data) {
    // Remove active style from siblings
    document.querySelectorAll('.msg-item').forEach(function(el, i) {
        el.style.background = i === idx ? '#e0f2fe' : '';
    });
    document.getElementById('msg-placeholder').style.display = 'none';
    document.getElementById('msg-content').style.display = '';
    var tab = '<?= $tab ?>';
    var from = tab === 'inbox' ? (data.sender_name || 'Abay Bank') : 'You → ' + (data.recipient_name || 'Support');
    document.getElementById('msg-meta').innerHTML =
        '<div style="margin-bottom:6px"><span style="font-size:.72rem;color:var(--muted);">' + (tab==='inbox'?'FROM':'TO') + '</span> <strong>' + escHtml(from) + '</strong></div>' +
        '<div style="font-size:1rem;font-weight:700;margin-bottom:4px">' + escHtml(data.subject || '—') + '</div>' +
        '<div style="font-size:.75rem;color:var(--muted)">' + (data.sent_at || '') + '</div>';
    document.getElementById('msg-body').textContent = data.body || '';
}
function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
<?php if ($composeError): ?>CP.openModal('compose-modal');<?php endif; ?>
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
