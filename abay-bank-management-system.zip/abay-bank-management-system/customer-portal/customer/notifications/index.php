<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Notifications — ' . CP_NAME;
$breadcrumb = [['label' => 'Notifications']];

// Mark single as read via GET
if (!empty($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    CP_Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=? AND customer_id=?", [(int)$_GET['mark_read'], $custId]);
}
// Mark all read via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_all') {
    CP_Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE customer_id=? AND is_read=0", [$custId]);
    header('Location: ' . CP_BASE_URL . '/customer/notifications/index.php');
    exit;
}

$filterUnread = ($_GET['filter'] ?? '') === 'unread';
$whereExtra   = $filterUnread ? 'AND n.is_read=0' : '';
$notifications = CP_Database::query(
    "SELECT * FROM notifications n WHERE n.customer_id=? $whereExtra ORDER BY n.created_at DESC LIMIT 100",
    [$custId]
) ?: [
    ['id' => 1, 'type' => 'transaction', 'title' => 'Credit Alert', 'message' => 'ETB 10,000.00 credited to your account 1000012345678.', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-5 min'))],
    ['id' => 2, 'type' => 'loan', 'title' => 'Loan Application Update', 'message' => 'Your loan application LN-2024-001 has been approved for ETB 50,000.', 'is_read' => 0, 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))],
    ['id' => 3, 'type' => 'account', 'title' => 'Account Statement Ready', 'message' => 'Your October 2024 account statement is now available.', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
    ['id' => 4, 'type' => 'security', 'title' => 'Login from New Device', 'message' => 'A new login was detected from Windows PC. If this was not you, contact us immediately.', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
    ['id' => 5, 'type' => 'promotion', 'title' => 'Special Offer', 'message' => 'Get preferential interest rates on fixed deposits this month. Visit any branch today!', 'is_read' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))],
];

$unreadCount = count(array_filter($notifications, fn($n) => !($n['is_read'] ?? 0)));

$typeIcons = ['transaction' => ['fa-arrow-right-arrow-left', '#3b82f6'], 'loan' => ['fa-hand-holding-dollar', '#22c55e'], 'account' => ['fa-building-columns', '#007A8A'], 'security' => ['fa-shield-halved', '#ef4444'], 'promotion' => ['fa-tag', '#f59e0b'], 'complaint' => ['fa-headset', '#8b5cf6'], 'kyc' => ['fa-id-card', '#06b6d4'], 'system' => ['fa-gear', '#94a3b8']];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
    <div>
        <h1><i class="fa-solid fa-bell" style="color:var(--teal)"></i> Notifications
            <?php if ($unreadCount > 0): ?>
            <span style="background:#ef4444;color:#fff;font-size:.65rem;padding:2px 7px;border-radius:20px;font-weight:700;vertical-align:middle;margin-left:6px"><?= $unreadCount ?> new</span>
            <?php endif; ?>
        </h1>
        <p>Stay up to date with your account activity</p>
    </div>
    <div class="cp-page-actions">
        <?php if ($unreadCount > 0): ?>
        <form method="POST" style="margin:0">
            <input type="hidden" name="action" value="mark_all">
            <button type="submit" class="cp-btn cp-btn-outline cp-btn-sm">
                <i class="fa-solid fa-check-double"></i> Mark All Read
            </button>
        </form>
        <?php endif; ?>
        <a href="?filter=<?= $filterUnread ? '' : 'unread' ?>" class="cp-btn <?= $filterUnread ? 'cp-btn-primary' : 'cp-btn-outline' ?> cp-btn-sm">
            <i class="fa-solid fa-filter"></i> <?= $filterUnread ? 'Show All' : 'Unread Only' ?>
        </a>
    </div>
</div>

<div class="cp-card">
    <div class="cp-card-body p0">
        <?php if (empty($notifications)): ?>
        <div style="text-align:center;padding:60px;color:var(--muted)">
            <i class="fa-solid fa-bell-slash" style="font-size:2.5rem;display:block;margin-bottom:12px;opacity:.3"></i>
            <div style="font-weight:600">No notifications</div>
            <p style="font-size:.85rem"><?= $filterUnread ? 'No unread notifications.' : "You're all caught up!" ?></p>
        </div>
        <?php else: ?>
        <?php foreach ($notifications as $n):
            [$icon, $iconColor] = $typeIcons[$n['type'] ?? 'system'] ?? ['fa-bell', '#94a3b8'];
            $isUnread = !($n['is_read'] ?? 0);
        ?>
        <div style="display:flex;align-items:flex-start;gap:14px;padding:16px 20px;border-bottom:1px solid var(--border);<?= $isUnread ? 'background:#f0f9ff;' : '' ?>position:relative;transition:background .2s"
             onmouseenter="this.style.background='<?= $isUnread ? '#e0f2fe' : '#f8fafc' ?>'" onmouseleave="this.style.background='<?= $isUnread ? '#f0f9ff' : 'transparent' ?>'">
            <?php if ($isUnread): ?>
            <div style="position:absolute;top:20px;left:8px;width:6px;height:6px;background:#3b82f6;border-radius:50%"></div>
            <?php endif; ?>
            <div style="width:42px;height:42px;border-radius:12px;background:<?= $iconColor ?>15;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-left:10px">
                <i class="fa-solid <?= $icon ?>" style="color:<?= $iconColor ?>;font-size:.9rem"></i>
            </div>
            <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:3px">
                    <div style="font-weight:<?= $isUnread ? '700' : '600' ?>;font-size:.88rem"><?= cp_e($n['title'] ?? 'Notification') ?></div>
                    <div style="font-size:.72rem;color:var(--muted);white-space:nowrap;flex-shrink:0"><?= cp_ago($n['created_at'] ?? '') ?></div>
                </div>
                <div style="font-size:.82rem;color:var(--muted);line-height:1.5"><?= cp_e($n['message'] ?? '') ?></div>
                <?php if ($isUnread): ?>
                <a href="?mark_read=<?= (int)($n['id'] ?? 0) ?>" style="font-size:.75rem;color:var(--teal);font-weight:600;text-decoration:none;margin-top:4px;display:inline-block">
                    <i class="fa-solid fa-check"></i> Mark as read
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
