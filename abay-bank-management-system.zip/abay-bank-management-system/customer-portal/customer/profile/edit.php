<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Edit Profile — ' . CP_NAME;
$breadcrumb = [['label' => 'Profile', 'url' => CP_BASE_URL . '/customer/profile/index.php'], ['label' => 'Edit']];
$errors     = [];

$profile = CP_Database::queryOne("SELECT * FROM customers WHERE id=?", [$custId]) ?? $customer;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  cp_csrf_check();
  $phone   = trim($_POST['phone']   ?? '');
  $email   = trim($_POST['email']   ?? '');
  $address = trim($_POST['address'] ?? '');
  $dob     = trim($_POST['dob']     ?? '');
  $gender  = trim($_POST['gender']  ?? '');

  if (!$phone) $errors[] = 'Phone number is required.';
  if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';

  if (!$errors) {
    CP_Database::execute(
      "UPDATE customers SET phone=?,email=?,address=?,date_of_birth=?,gender=?,updated_at=NOW() WHERE id=?",
      [$phone, $email, $address, $dob ?: null, $gender, $custId]
    );
    $_SESSION['cp_customer']['phone'] = $phone;
    $_SESSION['cp_customer']['email'] = $email;
    cp_flash('success', 'Profile updated successfully!');
    header('Location: ' . CP_BASE_URL . '/customer/profile/index.php');
    exit;
  }
  $profile = array_merge($profile, ['phone' => $phone, 'email' => $email, 'address' => $address, 'date_of_birth' => $dob, 'gender' => $gender]);
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-pen" style="color:var(--teal)"></i> Edit Profile</h1>
    <p>Update your personal contact information</p>
  </div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php foreach ($errors as $e): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($e) ?></div><?php endforeach; ?>
<div style="max-width:640px">
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3>Personal Information</h3>
    </div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div class="cp-fg"><label class="cp-label">First Name</label><input type="text" class="cp-input" value="<?= cp_e($profile['first_name'] ?? '') ?>" readonly style="background:var(--light);color:var(--muted)">
            <div class="cp-hint">Contact bank to change name</div>
          </div>
          <div class="cp-fg"><label class="cp-label">Last Name</label><input type="text" class="cp-input" value="<?= cp_e($profile['last_name'] ?? '') ?>" readonly style="background:var(--light);color:var(--muted)"></div>
          <div class="cp-fg"><label class="cp-label">Phone <span class="req">*</span></label><input type="tel" name="phone" class="cp-input" required value="<?= cp_e($profile['phone'] ?? '') ?>" placeholder="+251 9XX XXX XXX"></div>
          <div class="cp-fg"><label class="cp-label">Email</label><input type="email" name="email" class="cp-input" value="<?= cp_e($profile['email'] ?? '') ?>" placeholder="yourname@email.com"></div>
          <div class="cp-fg"><label class="cp-label">Date of Birth</label><input type="date" name="dob" class="cp-input" value="<?= cp_e($profile['date_of_birth'] ?? '') ?>" max="<?= date('Y-m-d', strtotime('-18 years')) ?>"></div>
          <div class="cp-fg"><label class="cp-label">Gender</label>
            <select name="gender" class="cp-select">
              <option value="">Select…</option>
              <?php foreach (['Male', 'Female', 'Other'] as $g): ?><option <?= ($profile['gender'] ?? '') === $g ? 'selected' : '' ?>><?= $g ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="cp-fg" style="grid-column:1/-1"><label class="cp-label">Home Address</label><textarea name="address" class="cp-textarea" rows="2" placeholder="Your residential address"><?= cp_e($profile['address'] ?? '') ?></textarea></div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
          <a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-btn cp-btn-outline">Cancel</a>
          <button type="submit" class="cp-btn cp-btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>