<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$pageTitle  = 'My Profile — ' . CP_NAME;
$breadcrumb = [['label' => 'My Profile']];
$custId     = (int)($customer['id'] ?? 0);

// Refresh from DB
$profile = CP_Database::queryOne(
  "SELECT c.*, COALESCE(b.name,'--') AS branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id WHERE c.id=?",
  [$custId]
) ?? $customer;

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-user-circle" style="color:var(--teal)"></i> My Profile</h1>
    <p>Manage your personal information, photo, and account security</p>
  </div>
  <div class="cp-page-actions">
    <a href="<?= CP_BASE_URL ?>/customer/profile/edit.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-pen"></i> Edit</a>
    <a href="<?= CP_BASE_URL ?>/customer/profile/security.php" class="cp-btn cp-btn-primary"><i class="fa-solid fa-lock"></i> Security</a>
  </div>
</div>

<div class="cp-grid-2" style="align-items:start">
  <!-- Avatar + quick info -->
  <div>
    <div class="cp-card" style="text-align:center">
      <div class="cp-card-body" style="padding:32px 24px">
        <?php $av = cp_avatar($profile); ?>
        <div style="position:relative;display:inline-block;margin-bottom:18px">
          <div class="cp-avatar cp-av-xl" style="background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff;margin:0 auto" id="av-wrap">
            <?php if ($av): ?><img src="<?= cp_e($av) ?>" alt="Photo" id="av-img">
              <?php else: ?><?= cp_initials($profile) ?><?php endif; ?>
          </div>
          <label for="photo-input" style="position:absolute;bottom:2px;right:2px;width:30px;height:30px;background:var(--teal);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.2)">
            <i class="fa-solid fa-camera" style="color:#fff;font-size:.65rem"></i>
          </label>
          <input type="file" id="photo-input" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="uploadPhoto(this)">
        </div>
        <h3 style="font-size:1.1rem;margin-bottom:4px"><?= cp_e(cp_full_name($profile)) ?></h3>
        <p style="color:var(--teal);font-weight:600;font-size:.88rem;margin-bottom:4px">Customer</p>
        <p style="color:var(--muted);font-size:.82rem"><?= cp_e($profile['customer_number'] ?? 'CUST-XXXXXXX') ?></p>
        <div style="margin-top:14px"><?= cp_badge($profile['kyc_status'] ?? 'Pending') ?></div>
        <div id="upload-progress" style="display:none;margin-top:12px">
          <div class="cp-progress">
            <div class="cp-progress-fill" id="up-bar" style="width:0%;background:var(--teal)"></div>
          </div>
          <p style="font-size:.73rem;color:var(--muted);margin-top:5px">Uploading…</p>
        </div>
      </div>
    </div>
    <div class="cp-card">
      <div class="cp-card-hdr">
        <h3>KYC &amp; Verification</h3>
      </div>
      <div class="cp-card-body">
        <div class="cp-info-row"><span class="cp-info-label">KYC Status</span><span><?= cp_badge($profile['kyc_status'] ?? 'Pending') ?></span></div>
        <div class="cp-info-row"><span class="cp-info-label">Account Status</span><span><?= cp_badge($profile['status'] ?? 'Active') ?></span></div>
        <div style="margin-top:14px">
          <a href="<?= CP_BASE_URL ?>/customer/kyc/index.php" class="cp-btn cp-btn-primary" style="width:100%;justify-content:center">
            <i class="fa-solid fa-id-card"></i> Manage KYC Documents
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- Personal info -->
  <div>
    <div class="cp-card">
      <div class="cp-card-hdr">
        <h3>Personal Information</h3><a href="<?= CP_BASE_URL ?>/customer/profile/edit.php" class="cp-btn cp-btn-outline cp-btn-sm"><i class="fa-solid fa-pen"></i> Edit</a>
      </div>
      <div class="cp-card-body">
        <?php foreach (
          [
            ['fa-user',         'Full Name',      cp_full_name($profile)],
            ['fa-id-badge',     'Customer No.',   $profile['customer_number'] ?? '—'],
            ['fa-envelope',     'Email',          $profile['email'] ?? '—'],
            ['fa-phone',        'Phone',          $profile['phone'] ?? '—'],
            ['fa-venus-mars',   'Gender',         $profile['gender'] ?? '—'],
            ['fa-calendar',     'Date of Birth',  cp_date($profile['date_of_birth'] ?? '')],
            ['fa-location-dot', 'Address',        $profile['address'] ?? '—'],
            ['fa-id-card',      'National ID',    $profile['national_id'] ?? '—'],
            ['fa-building',     'Branch',         $profile['branch_name'] ?? '—'],
            ['fa-calendar-plus', 'Member Since',   cp_date($profile['created_at'] ?? '')],
          ] as [$ico, $lbl, $val]
        ): ?>
          <div class="cp-info-row">
            <span class="cp-info-label"><i class="fa-solid <?= $ico ?>" style="color:var(--teal);width:16px;text-align:center;margin-right:6px"></i><?= $lbl ?></span>
            <span class="cp-info-val"><?= cp_e($val) ?: '—' ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
  function uploadPhoto(input) {
    if (!input.files || !input.files[0]) return;
    var file = input.files[0];
    if (file.size > 5 * 1024 * 1024) {
      CP.toast('Image must be under 5 MB', 'danger');
      input.value = '';
      return;
    }
    var reader = new FileReader();
    reader.onload = function(e) {
      var w = document.getElementById('av-wrap');
      if (w) w.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
    };
    reader.readAsDataURL(file);
    var prog = document.getElementById('upload-progress');
    var bar = document.getElementById('up-bar');
    if (prog) prog.style.display = '';
    var fd = new FormData();
    fd.append('photo', file);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?= CP_BASE_URL ?>/customer/profile/upload-photo.php', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.upload.onprogress = function(e) {
      if (e.lengthComputable && bar) bar.style.width = Math.round(e.loaded / e.total * 100) + '%';
    };
    xhr.onload = function() {
      if (prog) prog.style.display = 'none';
      try {
        var r = JSON.parse(xhr.responseText);
        CP.toast(r.success ? 'Photo updated!' : (r.message || 'Upload failed'), r.success ? 'success' : 'danger');
      } catch (e) {
        CP.toast('Upload failed', 'danger');
      }
    };
    xhr.onerror = function() {
      if (prog) prog.style.display = 'none';
      CP.toast('Upload error', 'danger');
    };
    xhr.send(fd);
  }
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>