<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Security — ' . CP_NAME;
$breadcrumb = [['label' => 'Profile', 'url' => CP_BASE_URL . '/customer/profile/index.php'], ['label' => 'Security']];
$error = null;
$success = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  cp_csrf_check();
  $cur = $_POST['current_password'] ?? '';
  $new = $_POST['new_password']     ?? '';
  $cf  = $_POST['confirm_password'] ?? '';
  if (!$cur || !$new || !$cf) {
    $error = 'All fields are required.';
  } elseif ($new !== $cf) {
    $error = 'New passwords do not match.';
  } elseif (strlen($new) < 8) {
    $error = 'Password must be at least 8 characters.';
  } else {
    $db = CP_Database::get();
    $user = CP_Database::queryOne("SELECT id,password_hash FROM customer_users WHERE customer_id=? LIMIT 1", [$custId]);
    if ($user && password_verify($cur, $user['password_hash'] ?? '')) {
      CP_Database::execute("UPDATE customer_users SET password_hash=?,updated_at=NOW() WHERE id=?", [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
      $success = 'Password changed successfully!';
    } elseif (!$user) {
      $success = 'Demo: Password changed!';
    } else {
      $error = 'Current password is incorrect.';
    }
  }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div>
    <h1><i class="fa-solid fa-lock" style="color:var(--teal)"></i> Security</h1>
    <p>Manage your password and account security</p>
  </div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div style="max-width:500px">
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-key"></i> Change Password</h3>
    </div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">Current Password *</label>
          <div class="cp-inp-wrap"><i class="fa-solid fa-lock cp-inp-ic"></i><input type="password" name="current_password" class="cp-input" required placeholder="Your current password">
            <button type="button" class="cp-inp-eye" onclick="tp('cp-0',this)"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
        <div class="cp-fg"><label class="cp-label">New Password *</label>
          <div class="cp-inp-wrap"><i class="fa-solid fa-lock cp-inp-ic"></i><input type="password" name="new_password" id="cp-new" class="cp-input" required minlength="8" oninput="chkStr(this.value)" placeholder="Min. 8 characters">
            <button type="button" class="cp-inp-eye" onclick="tp('cp-new',this)"><i class="fa-solid fa-eye"></i></button>
          </div>
          <div style="height:4px;background:#e2e8f0;border-radius:2px;margin-top:6px;overflow:hidden">
            <div id="str-bar" style="height:100%;border-radius:2px;transition:.3s;width:0%"></div>
          </div>
        </div>
        <div class="cp-fg"><label class="cp-label">Confirm New Password *</label>
          <div class="cp-inp-wrap"><i class="fa-solid fa-lock cp-inp-ic"></i><input type="password" name="confirm_password" id="cp-cf" class="cp-input" required oninput="chkMatch()"></div>
          <div class="cp-hint" id="match-msg"></div>
        </div>
        <button type="submit" class="cp-btn cp-btn-primary w-full"><i class="fa-solid fa-lock"></i> Update Password</button>
      </form>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr">
      <h3><i class="fa-solid fa-mobile-screen"></i> Two-Factor Authentication</h3>
    </div>
    <div class="cp-card-body">
      <p style="font-size:.85rem;color:var(--muted);margin-bottom:16px">Add an extra layer of security to your account with 2FA.</p>
      <button onclick="CP.toast('2FA setup coming soon','info')" class="cp-btn cp-btn-outline"><i class="fa-solid fa-shield-halved"></i> Enable 2FA</button>
    </div>
  </div>
</div>
<script>
  function tp(id, btn) {
    var i = document.getElementById(id);
    if (!i) return;
    i.type = i.type === 'password' ? 'text' : 'password';
    btn.querySelector('i').className = 'fa-solid ' + (i.type === 'password' ? 'fa-eye' : 'fa-eye-slash');
  }

  function chkStr(v) {
    var s = 0;
    if (v.length >= 8) s++;
    if (/[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^a-zA-Z0-9]/.test(v)) s++;
    var c = ['', '#ef4444', '#f59e0b', '#3b82f6', '#22c55e'][s] || '#e2e8f0';
    document.getElementById('str-bar').style.cssText = 'width:' + (s * 25) + '%;background:' + c;
  }

  function chkMatch() {
    var pw = document.getElementById('cp-new').value,
      cf = document.getElementById('cp-cf').value,
      el = document.getElementById('match-msg');
    if (!cf) return;
    el.textContent = pw === cf ? '✓ Passwords match' : '✗ Do not match';
    el.style.color = pw === cf ? '#22c55e' : '#ef4444';
  }
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>