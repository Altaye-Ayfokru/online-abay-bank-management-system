<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
header('Content-Type: application/json');
$customer = cp_customer();
if (!$customer || !cp_is_logged_in()) {
  echo json_encode(['success' => false, 'message' => 'Not authenticated']);
  exit;
}
if (empty($_FILES['photo'])) {
  echo json_encode(['success' => false, 'message' => 'No file uploaded']);
  exit;
}
$file = $_FILES['photo'];
$allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
if (!in_array($file['type'], $allowed)) {
  echo json_encode(['success' => false, 'message' => 'Only JPG, PNG or WebP allowed']);
  exit;
}
if ($file['size'] > 5 * 1024 * 1024) {
  echo json_encode(['success' => false, 'message' => 'Image must be under 5 MB']);
  exit;
}
$imgInfo = @getimagesize($file['tmp_name']);
if (!$imgInfo) {
  echo json_encode(['success' => false, 'message' => 'Invalid image file']);
  exit;
}
$dir = CP_BASE_PATH . '/uploads/profiles/';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$file['type']] ?? 'jpg';
$fn  = 'cust_' . (int)$customer['id'] . '_' . time() . '.' . $ext;
$dest = $dir . $fn;
// Remove old photo
$old = CP_Database::queryOne("SELECT photo_path FROM customers WHERE id=?", [(int)$customer['id']])['photo_path'] ?? null;
if ($old) {
  $oldFile = $dir . basename($old);
  if (file_exists($oldFile)) @unlink($oldFile);
}
if (!move_uploaded_file($file['tmp_name'], $dest)) {
  echo json_encode(['success' => false, 'message' => 'File save failed']);
  exit;
}
// Resize with GD if available
if (function_exists('imagecreatefromstring')) {
  try {
    $src = imagecreatefromstring(file_get_contents($dest));
    if ($src) {
      $w = $imagesx = $imgsX = imagesx($src);
      $h = imagesy($src);
      $max = 400;
      if ($w > $max || $h > $max) {
        $r = min($max / $w, $max / $h);
        $nw = (int)($w * $r);
        $nh = (int)($h * $r);
        $dst = imagecreatetruecolor($nw, $nh);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagejpeg($dst, $dest, 88);
        imagedestroy($src);
        imagedestroy($dst);
      }
    }
  } catch (Throwable) {
  }
}
$url = CP_BASE_URL . '/uploads/profiles/' . $fn;
CP_Database::execute("UPDATE customers SET photo_path=? WHERE id=?", [$fn, (int)$customer['id']]);
$_SESSION['cp_customer']['photo_path'] = $fn;
echo json_encode(['success' => true, 'url' => $url, 'message' => 'Photo updated']);
