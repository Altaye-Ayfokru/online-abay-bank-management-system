<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Settings — ' . CP_NAME;
$breadcrumb = [['label' => 'Settings']];
$success = null; $error = null;

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'password') {
    cp_csrf_check();
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    if (!$current || !$new || !$confirm) {
        $error = 'All password fields are required.';
    } elseif ($new !== $confirm) {
        $error = 'New password and confirmation do not match.';
    } elseif (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Z]/', $new) || !preg_match('/[0-9]/', $new) || !preg_match('/[^a-zA-Z0-9]/', $new)) {
        $error = 'Password must contain uppercase, number, and special character.';
    } else {
        $row = CP_Database::query("SELECT password FROM customers WHERE id=?", [$custId]);
        if ($row && password_verify($current, $row[0]['password'] ?? '')) {
            CP_Database::execute("UPDATE customers SET password=?, updated_at=NOW() WHERE id=?", [password_hash($new, PASSWORD_DEFAULT), $custId]);
            $success = 'Password changed successfully.';
        } else {
            $error = 'Current password is incorrect.';
        }
    }
}

// Handle notification prefs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'notifications') {
    cp_csrf_check();
    $prefs = [
        'email_transactions' => isset($_POST['email_transactions']) ? 1 : 0,
        'sms_transactions'   => isset($_POST['sms_transactions'])   ? 1 : 0,
        'email_loans'        => isset($_POST['email_loans'])        ? 1 : 0,
        'sms_loans'          => isset($_POST['sms_loans'])          ? 1 : 0,
        'email_marketing'    => isset($_POST['email_marketing'])    ? 1 : 0,
        'login_alerts'       => isset($_POST['login_alerts'])       ? 1 : 0,
    ];
    $prefsJson = json_encode($prefs);
    CP_Database::execute("UPDATE customers SET notification_prefs=? WHERE id=?", [$prefsJson, $custId]);
    $_SESSION['cp_customer']['notification_prefs'] = $prefsJson;
    $success = 'Notification preferences saved.';
}

// Handle preferences
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'preferences') {
    cp_csrf_check();
    $lang     = trim($_POST['language']  ?? 'en');
    $currency = trim($_POST['currency']  ?? 'ETB');
    $dateFormat=trim($_POST['date_format']?? 'Y-m-d');
    CP_Database::execute("UPDATE customers SET language=?, currency=?, date_format=? WHERE id=?", [$lang, $currency, $dateFormat, $custId]);
    $success = 'Preferences saved.';
}

// Load saved prefs
$notifPrefs = json_decode($customer['notification_prefs'] ?? '{}', true) ?: [];
$np = fn($key) => $notifPrefs[$key] ?? 1; // default all on

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
    <div>
        <h1><i class="fa-solid fa-gear" style="color:var(--teal)"></i> Settings</h1>
        <p>Manage your account security, notifications, and preferences</p>
    </div>
</div>

<?php if ($success): ?>
<div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i> <?= cp_e($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= cp_e($error) ?></div>
<?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid var(--border);overflow-x:auto">
    <?php foreach (['security' => ['fa-lock', 'Security'], 'notifications' => ['fa-bell', 'Notifications'], 'preferences' => ['fa-sliders', 'Preferences'], 'sessions' => ['fa-desktop', 'Sessions']] as $tid => [$ticon, $tlabel]): ?>
    <button onclick="switchTab('<?= $tid ?>')" id="tab-btn-<?= $tid ?>"
        style="padding:10px 18px;font-weight:600;font-size:.86rem;border:none;background:none;cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;color:var(--muted);transition:all .2s"
        class="settings-tab-btn">
        <i class="fa-solid <?= $ticon ?>"></i> <?= $tlabel ?>
    </button>
    <?php endforeach; ?>
</div>

<!-- Security Tab -->
<div id="tab-security" class="settings-tab">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start">
        <div class="cp-card">
            <div class="cp-card-hdr"><h3><i class="fa-solid fa-key"></i> Change Password</h3></div>
            <div class="cp-card-body">
                <form method="POST">
                    <?= cp_csrf_field() ?>
                    <input type="hidden" name="section" value="password">
                    <div class="cp-fg">
                        <label class="cp-label">Current Password *</label>
                        <div style="position:relative">
                            <input type="password" name="current_password" class="cp-input" id="cp-current" placeholder="Enter current password" autocomplete="current-password">
                            <button type="button" onclick="togglePwd('cp-current',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--muted)"><i class="fa-solid fa-eye"></i></button>
                        </div>
                    </div>
                    <div class="cp-fg">
                        <label class="cp-label">New Password *</label>
                        <div style="position:relative">
                            <input type="password" name="new_password" class="cp-input" id="cp-new" placeholder="Min 8 chars, uppercase, number, symbol" autocomplete="new-password" oninput="checkStrength(this.value)">
                            <button type="button" onclick="togglePwd('cp-new',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--muted)"><i class="fa-solid fa-eye"></i></button>
                        </div>
                        <div class="cp-progress" style="margin-top:6px"><div id="pwd-strength-bar" class="cp-progress-fill" style="width:0%;transition:width .3s,background .3s"></div></div>
                        <div id="pwd-strength-label" style="font-size:.72rem;color:var(--muted);margin-top:3px">Password strength</div>
                    </div>
                    <div class="cp-fg">
                        <label class="cp-label">Confirm New Password *</label>
                        <div style="position:relative">
                            <input type="password" name="confirm_password" class="cp-input" id="cp-confirm" placeholder="Re-enter new password" autocomplete="new-password">
                            <button type="button" onclick="togglePwd('cp-confirm',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--muted)"><i class="fa-solid fa-eye"></i></button>
                        </div>
                    </div>
                    <button type="submit" class="cp-btn cp-btn-primary w-full"><i class="fa-solid fa-key"></i> Update Password</button>
                </form>
            </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:16px">
            <div class="cp-card">
                <div class="cp-card-hdr"><h3><i class="fa-solid fa-shield-halved"></i> Two-Factor Authentication</h3></div>
                <div class="cp-card-body">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
                        <div><div style="font-weight:600;font-size:.88rem">SMS OTP</div><div style="font-size:.78rem;color:var(--muted)">Receive OTP on your phone for each login</div></div>
                        <label class="cp-toggle"><input type="checkbox" checked><span class="cp-toggle-slider"></span></label>
                    </div>
                    <div style="display:flex;align-items:center;justify-content:space-between">
                        <div><div style="font-weight:600;font-size:.88rem">Email OTP</div><div style="font-size:.78rem;color:var(--muted)">Also receive OTP via email</div></div>
                        <label class="cp-toggle"><input type="checkbox"><span class="cp-toggle-slider"></span></label>
                    </div>
                    <div class="cp-alert cp-alert-info" style="margin-top:12px;font-size:.78rem"><i class="fa-solid fa-circle-info"></i><div>2FA settings are managed by your branch. Contact us to enable full authenticator app support.</div></div>
                </div>
            </div>
            <div class="cp-card">
                <div class="cp-card-hdr"><h3><i class="fa-solid fa-right-from-bracket"></i> Account Actions</h3></div>
                <div class="cp-card-body" style="display:flex;flex-direction:column;gap:10px">
                    <button onclick="CP.confirm('Sign out of all devices?', function(){window.location='<?= CP_BASE_URL ?>/auth/logout.php?all=1';}, {title:'Sign Out All',danger:true,okLabel:'Sign Out All'})" class="cp-btn cp-btn-outline" style="color:#f97316;border-color:#f97316">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i> Sign Out All Devices
                    </button>
                    <button onclick="CP.confirm('Temporarily deactivate your portal access? You can reactivate by contacting us.',function(){CP.toast('Request sent to support.','warning');},{title:'Deactivate Portal Access',danger:true})" class="cp-btn cp-btn-outline" style="color:#ef4444;border-color:#ef4444">
                        <i class="fa-solid fa-ban"></i> Deactivate Portal Access
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Notifications Tab -->
<div id="tab-notifications" class="settings-tab" style="display:none">
    <div class="cp-card" style="max-width:600px">
        <div class="cp-card-hdr"><h3>Notification Preferences</h3></div>
        <div class="cp-card-body">
            <form method="POST">
                <?= cp_csrf_field() ?>
                <input type="hidden" name="section" value="notifications">
                <?php $notifItems = [
                    ['email_transactions', 'Transaction Alerts (Email)', 'Get emailed for every debit/credit'],
                    ['sms_transactions',   'Transaction Alerts (SMS)',   'Get SMS for every debit/credit'],
                    ['email_loans',        'Loan Updates (Email)',       'Email notifications for loan status'],
                    ['sms_loans',          'Loan Updates (SMS)',         'SMS notifications for loan status'],
                    ['email_marketing',    'Promotions & Offers',        'Receive bank promotions via email'],
                    ['login_alerts',       'Login Alerts',               'Alert when a new login is detected'],
                ]; ?>
                <?php foreach ($notifItems as [$key, $label, $desc]): ?>
                <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border)">
                    <div>
                        <div style="font-weight:600;font-size:.88rem"><?= $label ?></div>
                        <div style="font-size:.78rem;color:var(--muted)"><?= $desc ?></div>
                    </div>
                    <label class="cp-toggle">
                        <input type="checkbox" name="<?= $key ?>" <?= $np($key) ? 'checked' : '' ?>>
                        <span class="cp-toggle-slider"></span>
                    </label>
                </div>
                <?php endforeach; ?>
                <button type="submit" class="cp-btn cp-btn-primary" style="margin-top:16px"><i class="fa-solid fa-save"></i> Save Preferences</button>
            </form>
        </div>
    </div>
</div>

<!-- Preferences Tab -->
<div id="tab-preferences" class="settings-tab" style="display:none">
    <div class="cp-card" style="max-width:500px">
        <div class="cp-card-hdr"><h3>Display &amp; Regional Preferences</h3></div>
        <div class="cp-card-body">
            <form method="POST">
                <?= cp_csrf_field() ?>
                <input type="hidden" name="section" value="preferences">
                <div class="cp-fg"><label class="cp-label">Language</label>
                    <select name="language" class="cp-select">
                        <option value="en" <?= ($customer['language']??'en')==='en'?'selected':'' ?>>English</option>
                        <option value="am" <?= ($customer['language']??'')==='am'?'selected':'' ?>>አማርኛ (Amharic)</option>
                        <option value="or" <?= ($customer['language']??'')==='or'?'selected':'' ?>>Afaan Oromoo</option>
                    </select>
                </div>
                <div class="cp-fg"><label class="cp-label">Currency Display</label>
                    <select name="currency" class="cp-select">
                        <option value="ETB" <?= ($customer['currency']??'ETB')==='ETB'?'selected':'' ?>>ETB — Ethiopian Birr</option>
                        <option value="USD" <?= ($customer['currency']??'')==='USD'?'selected':'' ?>>USD — US Dollar</option>
                    </select>
                </div>
                <div class="cp-fg"><label class="cp-label">Date Format</label>
                    <select name="date_format" class="cp-select">
                        <option value="Y-m-d">YYYY-MM-DD</option>
                        <option value="d/m/Y">DD/MM/YYYY</option>
                        <option value="d M Y">DD Mon YYYY</option>
                    </select>
                </div>
                <button type="submit" class="cp-btn cp-btn-primary"><i class="fa-solid fa-save"></i> Save Preferences</button>
            </form>
        </div>
    </div>
</div>

<!-- Sessions Tab -->
<div id="tab-sessions" class="settings-tab" style="display:none">
    <div class="cp-card" style="max-width:640px">
        <div class="cp-card-hdr"><h3><i class="fa-solid fa-desktop"></i> Active Sessions</h3></div>
        <div class="cp-card-body">
            <?php $sessions = [
                ['device' => 'Current Session', 'browser' => 'Chrome / Windows', 'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1', 'time' => 'Now', 'current' => true],
            ]; foreach ($sessions as $sess): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid var(--border)">
                <div style="display:flex;gap:12px;align-items:center">
                    <div style="width:40px;height:40px;background:#f1f5f9;border-radius:10px;display:flex;align-items:center;justify-content:center">
                        <i class="fa-solid fa-desktop" style="color:var(--teal)"></i>
                    </div>
                    <div>
                        <div style="font-weight:600;font-size:.88rem"><?= cp_e($sess['device']) ?>
                            <?php if ($sess['current']): ?><span style="font-size:.7rem;color:#22c55e;background:#dcfce7;padding:1px 6px;border-radius:10px;margin-left:6px">Current</span><?php endif; ?>
                        </div>
                        <div style="font-size:.75rem;color:var(--muted)"><?= cp_e($sess['browser']) ?> · <?= cp_e($sess['ip']) ?></div>
                        <div style="font-size:.72rem;color:var(--muted)"><?= cp_e($sess['time']) ?></div>
                    </div>
                </div>
                <?php if (!$sess['current']): ?>
                <button onclick="CP.toast('Session terminated.','success')" class="cp-btn cp-btn-outline cp-btn-sm" style="color:#ef4444;border-color:#ef4444">Revoke</button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <div class="cp-alert cp-alert-info" style="margin-top:12px;font-size:.8rem"><i class="fa-solid fa-circle-info"></i><div>Session history shows your last 5 logins. Contact us if you see unrecognized sessions.</div></div>
        </div>
    </div>
</div>

<style>
.cp-toggle{position:relative;display:inline-block;width:46px;height:26px}
.cp-toggle input{opacity:0;width:0;height:0}
.cp-toggle-slider{position:absolute;cursor:pointer;inset:0;background:#cbd5e1;border-radius:26px;transition:.3s}
.cp-toggle-slider:before{content:'';position:absolute;height:18px;width:18px;left:4px;bottom:4px;background:#fff;border-radius:50%;transition:.3s;box-shadow:0 1px 4px rgba(0,0,0,.2)}
.cp-toggle input:checked+.cp-toggle-slider{background:var(--teal)}
.cp-toggle input:checked+.cp-toggle-slider:before{transform:translateX(20px)}
</style>
<script>
function switchTab(id) {
    document.querySelectorAll('.settings-tab').forEach(function(el) { el.style.display = 'none'; });
    document.querySelectorAll('.settings-tab-btn').forEach(function(btn) {
        btn.style.borderBottomColor = 'transparent'; btn.style.color = 'var(--muted)';
    });
    document.getElementById('tab-' + id).style.display = '';
    var btn = document.getElementById('tab-btn-' + id);
    if (btn) { btn.style.borderBottomColor = 'var(--teal)'; btn.style.color = 'var(--teal)'; }
}
// Init first tab
switchTab('security');

function togglePwd(id, btn) {
    var el = document.getElementById(id);
    if (!el) return;
    el.type = el.type === 'password' ? 'text' : 'password';
    btn.querySelector('i').className = el.type === 'password' ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
}
function checkStrength(val) {
    var bar = document.getElementById('pwd-strength-bar');
    var lbl = document.getElementById('pwd-strength-label');
    if (!bar || !lbl) return;
    var score = 0;
    if (val.length >= 8)  score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^a-zA-Z0-9]/.test(val)) score++;
    var levels = [['0%','#ef4444',''],['25%','#ef4444','Weak'],['50%','#f59e0b','Fair'],['75%','#3b82f6','Good'],['100%','#22c55e','Strong']];
    bar.style.width   = levels[score][0];
    bar.style.background = levels[score][1];
    lbl.textContent = levels[score][2];
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
