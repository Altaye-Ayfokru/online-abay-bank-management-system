<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Statements — ' . CP_NAME;
$breadcrumb = [['label' => 'Statements']];

$accounts = CP_Database::query("SELECT id,account_number,account_type,balance FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId);

$accId    = (int)($_GET['account']  ?? ($accounts[0]['id'] ?? 0));
$fromDate = $_GET['from']  ?? date('Y-m-01');
$toDate   = $_GET['to']    ?? date('Y-m-d');

$txns = CP_Database::query(
    "SELECT t.* FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND t.account_id=? AND DATE(t.created_at) BETWEEN ? AND ? ORDER BY t.created_at",
    [$custId, $accId, $fromDate, $toDate]
) ?: cp_demo_transactions($custId, 12);

$credits  = array_sum(array_column(array_filter($txns, fn($t)=>in_array($t['type']??'',['Deposit','Transfer In','Loan Disbursement'])), 'amount'));
$debits   = array_sum(array_column(array_filter($txns, fn($t)=>!in_array($t['type']??'',['Deposit','Transfer In','Loan Disbursement'])), 'amount'));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-file-lines" style="color:var(--teal)"></i> Account Statement</h1><p>View and download your transaction history</p></div>
  <div class="cp-page-actions">
    <button onclick="window.print()" class="cp-btn cp-btn-outline"><i class="fa-solid fa-print"></i> Print</button>
    <button onclick="exportCSV()" class="cp-btn cp-btn-primary"><i class="fa-solid fa-download"></i> Download CSV</button>
  </div>
</div>

<!-- Filters -->
<div class="cp-card" style="margin-bottom:20px">
  <div class="cp-card-body" style="padding:16px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="cp-label">Account</label>
        <select name="account" class="cp-select" style="width:220px">
          <?php foreach ($accounts as $a): ?><option value="<?= $a['id'] ?>" <?= $accId===$a['id']?'selected':'' ?>><?= cp_e($a['account_number']) ?> · <?= cp_e($a['account_type']) ?></option><?php endforeach; ?>
        </select></div>
      <div><label class="cp-label">Quick Range</label>
        <select id="quick-range" class="cp-select" style="width:150px" onchange="setRange(this.value)">
          <option value="">Custom</option>
          <option value="30">Last 30 days</option>
          <option value="90">Last 3 months</option>
          <option value="180">Last 6 months</option>
          <option value="365">Last year</option>
        </select></div>
      <div><label class="cp-label">From</label><input type="date" name="from" id="from-date" class="cp-input" style="width:145px" value="<?= cp_e($fromDate) ?>"></div>
      <div><label class="cp-label">To</label><input type="date" name="to" id="to-date" class="cp-input" style="width:145px" value="<?= cp_e($toDate) ?>"></div>
      <button type="submit" class="cp-btn cp-btn-primary cp-btn-sm"><i class="fa-solid fa-search"></i> Generate</button>
    </form>
  </div>
</div>

<!-- Summary -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:14px;margin-bottom:20px">
  <?php foreach ([['Total Credits',cp_etb($credits),'#22c55e','fa-arrow-down'],['Total Debits',cp_etb($debits),'#ef4444','fa-arrow-up'],['Net',cp_etb($credits-$debits),$credits>=$debits?'#1B3A5C':'#ef4444','fa-right-left'],['Transactions',count($txns),'#007A8A','fa-list']] as [$l,$v,$c,$i]): ?>
  <div class="cp-card"><div class="cp-card-body" style="padding:14px">
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:38px;height:38px;background:<?= $c ?>20;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fa-solid <?= $i ?>" style="color:<?= $c ?>"></i></div>
      <div><div style="font-size:.72rem;color:var(--muted)"><?= $l ?></div><div style="font-weight:800;font-size:.95rem;color:<?= $c ?>"><?= $v ?></div></div>
    </div>
  </div></div>
  <?php endforeach; ?>
</div>

<!-- Statement table -->
<div class="cp-card" id="statement-area">
  <!-- Header for print -->
  <div style="display:none" class="print-only" style="padding:20px;border-bottom:2px solid #e2e8f0;margin-bottom:16px">
    <h2 style="color:#1B3A5C">Abay Bank S.C. — Account Statement</h2>
    <p>Period: <?= cp_e($fromDate) ?> to <?= cp_e($toDate) ?> | Generated: <?= date('d M Y H:i') ?></p>
  </div>
  <div class="cp-card-body p0">
    <div class="cp-table-wrap">
      <table class="cp-table" id="stmt-table">
        <thead><tr><th>Date &amp; Time</th><th>Reference</th><th>Description</th><th style="text-align:right">Credit</th><th style="text-align:right">Debit</th><th style="text-align:right">Status</th></tr></thead>
        <tbody>
          <?php foreach ($txns as $t):
            $isC=in_array($t['type']??'',['Deposit','Transfer In','Loan Disbursement']);
          ?>
          <tr>
            <td style="font-size:.8rem;white-space:nowrap"><?= cp_date($t['created_at']??'','d M Y H:i') ?></td>
            <td style="font-family:monospace;font-size:.78rem"><?= cp_e($t['reference']??'—') ?></td>
            <td style="font-size:.83rem"><?= cp_e($t['description']??$t['type']??'—') ?></td>
            <td style="text-align:right;color:#16a34a;font-weight:600"><?= $isC?cp_etb((float)($t['amount']??0)):'' ?></td>
            <td style="text-align:right;color:#dc2626;font-weight:600"><?= !$isC?cp_etb((float)($t['amount']??0)):'' ?></td>
            <td><?= cp_badge($t['status']??'Completed') ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($txns)): ?>
          <tr><td colspan="6" style="text-align:center;padding:40px;color:var(--muted)"><i class="fa-solid fa-inbox" style="font-size:1.5rem;display:block;margin-bottom:8px"></i>No transactions in this period</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
function setRange(days) {
  if (!days) return;
  var to=new Date(), from=new Date();
  from.setDate(to.getDate()-parseInt(days));
  document.getElementById('from-date').value=from.toISOString().slice(0,10);
  document.getElementById('to-date').value=to.toISOString().slice(0,10);
}
function exportCSV() {
  var rows=[['Date','Reference','Description','Credit','Debit','Status']];
  document.querySelectorAll('#stmt-table tbody tr').forEach(function(tr){
    var c=tr.querySelectorAll('td');if(c.length<6)return;
    rows.push([c[0].textContent.trim(),c[1].textContent.trim(),c[2].textContent.trim(),c[3].textContent.trim(),c[4].textContent.trim(),c[5].textContent.trim()]);
  });
  var csv=rows.map(function(r){return r.map(function(v){return'"'+v+'"';}).join(',');}).join('\n');
  var a=document.createElement('a');a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);a.download='statement_<?= date('Y-m-d') ?>.csv';a.click();
}
</script>
<style>@media print{.cp-topbar,.cp-sidebar,.cp-page-actions,.cp-sb-backdrop,.cp-card:not(#statement-area){display:none!important;}.cp-main{margin:0!important;padding:0!important;}.print-only{display:block!important;}}</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
