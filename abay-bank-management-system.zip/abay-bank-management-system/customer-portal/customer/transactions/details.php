<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$txnId      = (int)($_GET['id'] ?? 0);
$pageTitle  = 'Transaction Receipt — ' . CP_NAME;
$breadcrumb = [['label'=>'Transactions','url'=>CP_BASE_URL.'/customer/transactions/index.php'],['label'=>'Receipt']];

$txn = CP_Database::queryOne(
    "SELECT t.*, a.account_number, a.account_type FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.id=? AND a.customer_id=?",
    [$txnId, $custId]
) ?? ['id'=>$txnId,'reference'=>'TXN-DEMO12345','type'=>'Deposit','amount'=>25000,'description'=>'Cash Deposit','status'=>'Completed','created_at'=>date('Y-m-d H:i:s'),'account_number'=>'1000012345678','account_type'=>'Savings'];

$isCredit = in_array($txn['type']??'',['Deposit','Transfer In','Loan Disbursement']);
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-receipt" style="color:var(--teal)"></i> Transaction Receipt</h1></div>
  <div class="cp-page-actions">
    <button onclick="window.print()" class="cp-btn cp-btn-outline"><i class="fa-solid fa-print"></i> Print</button>
    <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>
<div style="max-width:560px" id="receipt-area">
  <div class="cp-card">
    <!-- Receipt header -->
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);padding:22px 26px;border-radius:14px 14px 0 0;color:#fff;text-align:center">
      <div style="display:flex;align-items:flex-end;gap:3px;justify-content:center;margin-bottom:10px">
        <span style="width:5px;height:14px;background:#C8A84B;border-radius:2px 2px 0 0;display:block"></span>
        <span style="width:5px;height:19px;background:#7ecfd8;border-radius:2px 2px 0 0;display:block"></span>
        <span style="width:5px;height:24px;background:#fff;border-radius:2px 2px 0 0;display:block"></span>
        <span style="width:5px;height:14px;background:#7ecfd8;border-radius:2px 2px 0 0;display:block"></span>
      </div>
      <div style="font-size:.8rem;opacity:.7;font-weight:700;text-transform:uppercase;margin-bottom:4px">Transaction Receipt</div>
      <div style="font-size:1.5rem;font-weight:800;color:<?= $isCredit?'#C8A84B':'#fca5a5' ?>">
        <?= ($isCredit?'+':'-').cp_etb(abs((float)($txn['amount']??0))) ?>
      </div>
      <div style="font-size:.8rem;opacity:.7;margin-top:4px"><?= cp_e($txn['type']??'—') ?></div>
    </div>
    <!-- Receipt body -->
    <div class="cp-card-body">
      <div style="text-align:center;margin-bottom:20px">
        <span style="display:inline-block;padding:6px 18px;border-radius:99px;font-size:.78rem;font-weight:700;background:<?= $txn['status']==='Completed'?'#dcfce7':'#fef9c3' ?>;color:<?= $txn['status']==='Completed'?'#16a34a':'#b45309' ?>">
          <i class="fa-solid fa-<?= $txn['status']==='Completed'?'circle-check':'clock' ?>"></i>
          <?= cp_e($txn['status']??'Completed') ?>
        </span>
      </div>
      <?php foreach ([
        ['Reference No.',   $txn['reference']??'—'],
        ['Transaction Type',$txn['type']??'—'],
        ['Account Number',  $txn['account_number']??'—'],
        ['Account Type',    $txn['account_type']??'—'],
        ['Amount',          cp_etb(abs((float)($txn['amount']??0)))],
        ['Description',     $txn['description']??'—'],
        ['Date & Time',     cp_date($txn['created_at']??'','d M Y H:i:s')],
        ['Status',          $txn['status']??'—'],
      ] as [$l,$v]): ?>
      <div class="cp-info-row">
        <span class="cp-info-label"><?= $l ?></span>
        <span class="cp-info-val" style="font-family:<?= in_array($l,['Reference No.','Account Number'])?'monospace':'inherit' ?>"><?= cp_e($v) ?></span>
      </div>
      <?php endforeach; ?>
      <div style="border:2px dashed #e2e8f0;border-radius:10px;padding:12px;text-align:center;margin-top:16px;font-size:.75rem;color:var(--muted)">
        This is an official Abay Bank transaction receipt.<br>
        Keep this for your records. Transaction ID: <?= cp_e($txn['id']??$txnId) ?>
      </div>
    </div>
  </div>
</div>
<style>@media print{.cp-topbar,.cp-sidebar,.cp-page-actions,.cp-sb-backdrop{display:none!important;}.cp-main{margin:0!important;padding:0!important;}}</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
