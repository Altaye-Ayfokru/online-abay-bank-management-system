<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Transaction History — ' . CP_NAME;
$breadcrumb = [['label' => 'Transactions']];

$accFilter  = (int)($_GET['account']   ?? 0);
$typeFilter = trim($_GET['type']       ?? '');
$fromDate   = trim($_GET['from']       ?? date('Y-m-01'));
$toDate     = trim($_GET['to']         ?? date('Y-m-d'));
$page       = max(1,(int)($_GET['page']?? 1));
$perPage    = 15;

$where  = "a.customer_id=?"; $params=[$custId];
if ($accFilter) { $where .= " AND t.account_id=?"; $params[]=$accFilter; }
if ($typeFilter){ $where .= " AND t.type=?";        $params[]=$typeFilter; }
if ($fromDate)  { $where .= " AND DATE(t.created_at)>=?"; $params[]=$fromDate; }
if ($toDate)    { $where .= " AND DATE(t.created_at)<=?"; $params[]=$toDate; }

$total = (int)(CP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE $where",
    $params
)['c'] ?? 0);
$pages  = $total ? (int)ceil($total/$perPage) : 1;
$offset = ($page-1)*$perPage;

$txns = CP_Database::query(
    "SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE $where ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset",
    $params
) ?: cp_demo_transactions($custId, 15);

$accounts = CP_Database::query("SELECT id, account_number, account_type FROM accounts WHERE customer_id=? AND status='Active'",[$custId])
          ?: cp_demo_accounts($custId);

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-clock-rotate-left" style="color:var(--teal)"></i> Transaction History</h1><p>All your banking activity in one place</p></div>
  <div class="cp-page-actions">
    <button onclick="exportCSV()" class="cp-btn cp-btn-outline"><i class="fa-solid fa-file-csv"></i> Export CSV</button>
  </div>
</div>

<!-- Filters -->
<div class="cp-card" style="margin-bottom:16px">
  <div class="cp-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="cp-label">Account</label>
        <select name="account" class="cp-select" style="width:180px">
          <option value="">All Accounts</option>
          <?php foreach ($accounts as $a): ?>
          <option value="<?= $a['id'] ?>" <?= $accFilter===$a['id']?'selected':'' ?>><?= cp_e($a['account_number']) ?> (<?= cp_e($a['account_type']) ?>)</option>
          <?php endforeach; ?>
        </select></div>
      <div><label class="cp-label">Type</label>
        <select name="type" class="cp-select" style="width:150px">
          <option value="">All Types</option>
          <?php foreach (['Deposit','Withdrawal','Transfer Out','Transfer In','Loan Disbursement','Loan Repayment'] as $tp): ?>
          <option <?= $typeFilter===$tp?'selected':'' ?>><?= $tp ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label class="cp-label">From</label><input type="date" name="from" class="cp-input" style="width:145px" value="<?= cp_e($fromDate) ?>"></div>
      <div><label class="cp-label">To</label><input type="date" name="to" class="cp-input" style="width:145px" value="<?= cp_e($toDate) ?>"></div>
      <button type="submit" class="cp-btn cp-btn-primary cp-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php" class="cp-btn cp-btn-outline cp-btn-sm">Reset</a>
    </form>
  </div>
</div>

<div class="cp-card">
  <div class="cp-card-body p0">
    <div class="cp-table-wrap">
      <table class="cp-table" id="txn-table">
        <thead><tr><th>Date &amp; Time</th><th>Reference</th><th>Account</th><th>Description</th><th>Type</th><th style="text-align:right">Amount</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach ($txns as $t):
            $isC = in_array($t['type']??'',['Deposit','Transfer In','Loan Disbursement']);
          ?>
          <tr>
            <td style="font-size:.8rem;white-space:nowrap"><?= cp_date($t['created_at']??'','d M Y H:i') ?></td>
            <td style="font-family:monospace;font-size:.79rem"><?= cp_e($t['reference']??'—') ?></td>
            <td style="font-family:monospace;font-size:.8rem"><?= cp_e($t['account_number']??'—') ?></td>
            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.83rem"><?= cp_e($t['description']??$t['type']??'—') ?></td>
            <td><?= cp_badge($t['type']??'—') ?></td>
            <td style="text-align:right;font-weight:700;color:<?= $isC?'#16a34a':'#dc2626' ?>">
              <?= ($isC?'+':'-').cp_etb(abs((float)($t['amount']??0))) ?>
            </td>
            <td><?= cp_badge($t['status']??'Completed') ?></td>
            <td><a href="<?= CP_BASE_URL ?>/customer/transactions/details.php?id=<?= (int)($t['id']??0) ?>" class="cp-btn cp-btn-ghost cp-btn-sm"><i class="fa-solid fa-eye"></i></a></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($txns)): ?>
          <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--muted)"><i class="fa-solid fa-inbox" style="font-size:2rem;display:block;margin-bottom:10px"></i>No transactions found</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- Pagination -->
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid var(--border)">
    <span style="font-size:.82rem;color:var(--muted)">Showing <?= $offset+1 ?>–<?= min($offset+$perPage,$total?:count($txns)) ?> of <?= $total ?: count($txns) ?></span>
    <div style="display:flex;gap:6px">
      <?php if ($page>1): ?><a href="?<?= http_build_query(array_merge($_GET,['page'=>$page-1])) ?>" class="cp-btn cp-btn-outline cp-btn-sm">‹ Prev</a><?php endif; ?>
      <?php if ($page<$pages): ?><a href="?<?= http_build_query(array_merge($_GET,['page'=>$page+1])) ?>" class="cp-btn cp-btn-outline cp-btn-sm">Next ›</a><?php endif; ?>
    </div>
  </div>
</div>

<script>
function exportCSV() {
  var rows=[['Date','Reference','Account','Description','Type','Amount','Status']];
  document.querySelectorAll('#txn-table tbody tr').forEach(function(tr){
    var cells=tr.querySelectorAll('td');
    if(cells.length<7)return;
    rows.push([cells[0].textContent.trim(),cells[1].textContent.trim(),cells[2].textContent.trim(),cells[3].textContent.trim(),cells[4].textContent.trim(),cells[5].textContent.trim(),cells[6].textContent.trim()]);
  });
  var csv=rows.map(function(r){return r.map(function(v){return'"'+v+'"';}).join(',');}).join('\n');
  var a=document.createElement('a');a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);a.download='transactions_<?= date('Y-m-d') ?>.csv';a.click();
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
