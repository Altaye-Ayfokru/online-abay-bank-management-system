<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Transfer — Abay Bank — ' . CP_NAME;
$breadcrumb = [['label'=>'Transfers','url'=>CP_BASE_URL.'/customer/transfers/index.php'],['label'=>'Abay Bank']];
$error = null; $success = null;

$accounts = CP_Database::query("SELECT id,account_number,account_type,balance FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cp_csrf_check();
    $fromId  = (int)($_POST['from_account']    ?? 0);
    $toAccNo = trim($_POST['to_account_number']?? '');
    $amount  = (float)($_POST['amount']         ?? 0);
    $desc    = trim($_POST['description']       ?? 'Abay Bank Transfer');

    if (!$fromId)    $error = 'Please select a source account.';
    elseif (!$toAccNo) $error = 'Destination account number is required.';
    elseif ($amount < 1) $error = 'Minimum transfer is ETB 1.';
    else {
        $srcAcc = CP_Database::queryOne("SELECT * FROM accounts WHERE id=? AND customer_id=? AND status='Active'",[$fromId,$custId]);
        $dstAcc = CP_Database::queryOne("SELECT id,balance,customer_id FROM accounts WHERE account_number=? AND status='Active'",[$toAccNo]);
        if (!$srcAcc && !empty($accounts)) $srcAcc = $accounts[0];
        if (!$srcAcc) { $error='Source account not found.'; }
        elseif ((float)($srcAcc['balance']??84500) < $amount) { $error='Insufficient balance.'; }
        else {
            $ref = 'TRF-'.strtoupper(substr(uniqid('',true),-8));
            $db  = CP_Database::get();
            if ($db && $dstAcc) {
                try {
                    $db->beginTransaction();
                    $srcNew = (float)$srcAcc['balance'] - $amount;
                    $dstNew = (float)$dstAcc['balance'] + $amount;
                    CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$srcNew,$srcAcc['id']]);
                    CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$dstNew,$dstAcc['id']]);
                    CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Transfer Out',?,?,?,?,'Completed',NOW())",[$srcAcc['id'],$amount,$srcNew,$desc,$ref]);
                    CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Transfer In',?,?,?,?,'Completed',NOW())",[$dstAcc['id'],$amount,$dstNew,"From ".$customer['first_name']." ".$customer['last_name'].": ".$desc,$ref]);
                    $db->commit();
                    $success = "Transfer of ".cp_etb($amount)." to $toAccNo successful! Reference: $ref";
                } catch (Throwable $e) { $db->rollBack(); $error='Transfer failed: '.$e->getMessage(); }
            } else {
                $success = "Demo: Transfer of ".cp_etb($amount)." to $toAccNo recorded. Ref: $ref";
            }
        }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-building-columns" style="color:var(--teal)"></i> Abay Bank Transfer</h1><p>Send money to any Abay Bank account instantly</p></div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/transfers/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div class="cp-grid-2" style="align-items:start">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3><i class="fa-solid fa-right-left"></i> Transfer Details</h3></div>
    <div class="cp-card-body">
      <form method="POST" id="transfer-form">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">From Account <span class="req">*</span></label>
          <select name="from_account" id="from-acc" class="cp-select" required onchange="updateBalance(this)">
            <option value="">Select account…</option>
            <?php foreach ($accounts as $a): ?>
            <option value="<?= $a['id'] ?>" data-bal="<?= (float)($a['balance']??0) ?>"><?= cp_e($a['account_number']) ?> (<?= cp_e($a['account_type']) ?>) — <?= cp_etb((float)($a['balance']??0)) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="cp-hint" id="bal-hint"></div></div>
        <div class="cp-fg"><label class="cp-label">To Account Number <span class="req">*</span></label>
          <div class="cp-inp-wrap"><i class="fa-solid fa-building-columns cp-inp-ic"></i>
            <input type="text" name="to_account_number" class="cp-input" placeholder="Enter Abay Bank account number" required oninput="lookupAccount(this.value)">
          </div>
          <div class="cp-hint" id="acct-hint"></div></div>
        <div class="cp-fg"><label class="cp-label">Amount (ETB) <span class="req">*</span></label>
          <div class="cp-inp-wrap"><span style="position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.82rem;font-weight:600">ETB</span>
            <input type="number" name="amount" class="cp-input" style="padding-left:48px" min="1" step="0.01" placeholder="0.00" required oninput="updateSummary(this.value)">
          </div></div>
        <div class="cp-fg"><label class="cp-label">Description</label><input type="text" name="description" class="cp-input" value="Abay Bank Transfer" placeholder="Payment description"></div>
        <div class="cp-alert cp-alert-info" style="font-size:.82rem"><i class="fa-solid fa-circle-info"></i><div>Transfers within Abay Bank are instant and free.</div></div>
        <button type="submit" class="cp-btn cp-btn-primary w-full" id="submit-btn"><i class="fa-solid fa-paper-plane"></i> Send Money</button>
      </form>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr"><h3><i class="fa-solid fa-receipt"></i> Transfer Summary</h3></div>
    <div class="cp-card-body">
      <?php foreach ([['From Account','—','sum-from'],['To Account','—','sum-to'],['Amount','—','sum-amount'],['Fee','Free',''],['Total Deduction','—','sum-total']] as [$l,$d,$id]): ?>
      <div class="cp-info-row"><span class="cp-info-label"><?= $l ?></span><span class="cp-info-val" <?= $id?"id=\"$id\"":'' ?>><?= $d ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<script>
var _bal = 0;
function updateBalance(sel) {
  var opt = sel.selectedOptions[0];
  _bal = parseFloat(opt.dataset.bal || 0);
  var hint = document.getElementById('bal-hint');
  if (hint) hint.textContent = _bal > 0 ? 'Available: ETB ' + _bal.toLocaleString('en-US',{minimumFractionDigits:2}) : '';
  var sf = document.getElementById('sum-from');
  if (sf) sf.textContent = opt.text || '—';
  updateSummary(document.querySelector('[name="amount"]').value);
}
var _lookT;
function lookupAccount(v) {
  clearTimeout(_lookT);
  var hint = document.getElementById('acct-hint');
  var st   = document.getElementById('sum-to');
  if (v.length < 5) { if(hint)hint.textContent=''; return; }
  if(hint)hint.textContent='Checking…'; 
  _lookT = setTimeout(function(){
    fetch('<?= CP_BASE_URL ?>/api/transfers/validate-account.php?account_number='+encodeURIComponent(v),{credentials:'include',headers:{'X-Requested-With':'XMLHttpRequest'}})
      .then(function(r){return r.json();}).then(function(d){
        if(d&&d.success){
          if(hint)hint.innerHTML='<span style="color:#22c55e">✓ '+d.data.customer_name+'</span>';
          if(st)st.textContent=v;
        } else {
          if(hint)hint.innerHTML='<span style="color:#ef4444">Account not found</span>';
        }
      }).catch(function(){if(hint)hint.innerHTML='<span style="color:#f59e0b">Demo mode — account not verified</span>';if(st)st.textContent=v;});
  },600);
}
function updateSummary(v) {
  var amt = parseFloat(v)||0;
  var sa  = document.getElementById('sum-amount');
  var st  = document.getElementById('sum-total');
  if(sa) sa.textContent = amt>0?'ETB '+amt.toLocaleString('en-US',{minimumFractionDigits:2}):'—';
  if(st) st.textContent = amt>0?'ETB '+amt.toLocaleString('en-US',{minimumFractionDigits:2}):'—';
}
document.getElementById('transfer-form').addEventListener('submit',function(){
  CP.setBtn('submit-btn',true,'Processing…');
});
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
