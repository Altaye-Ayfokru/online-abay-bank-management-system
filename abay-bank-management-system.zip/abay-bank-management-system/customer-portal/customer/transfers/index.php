<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Transfers — ' . CP_NAME;
$breadcrumb = [['label' => 'Transfers']];

$recentTransfers = CP_Database::query(
    "SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND t.type IN('Transfer Out','Transfer In') ORDER BY t.created_at DESC LIMIT 8",
    [$custId]
) ?: cp_demo_transactions($custId, 6);

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-right-left" style="color:var(--teal)"></i> Transfers</h1><p>Send money within Abay Bank or to other banks</p></div>
</div>
<!-- Transfer type cards -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px;margin-bottom:28px">
  <?php $types=[
    [CP_BASE_URL.'/customer/transfers/own-account.php','fa-arrow-right-arrow-left','#007A8A','#e0f5f7','Own Accounts','Transfer between your accounts instantly — free'],
    [CP_BASE_URL.'/customer/transfers/abay-bank.php','fa-building-columns','#1B3A5C','#e2e8f0','Abay Bank','Send to any Abay Bank account — free, instant'],
    ['#','fa-network-wired','#7c3aed','#ede9fe','EthSwitch / Other Banks','Transfer to commercial banks via EthSwitch'],
    ['#','fa-globe','#f59e0b','#fef9c3','Telebirr / Mobile Money','Send to Telebirr and mobile wallets'],
  ];
  foreach ($types as [$href,$ic,$clr,$bg,$title,$desc]): ?>
  <a href="<?= $href ?>" class="cp-card" style="text-decoration:none;transition:.2s;display:block" onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='0 12px 32px rgba(0,0,0,.12)'" onmouseout="this.style.transform='';this.style.boxShadow=''">
    <div class="cp-card-body">
      <div style="width:50px;height:50px;background:<?= $bg ?>;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:14px">
        <i class="fa-solid <?= $ic ?>" style="color:<?= $clr ?>;font-size:1.2rem"></i>
      </div>
      <div style="font-weight:700;font-size:.95rem;color:var(--navy);margin-bottom:6px"><?= $title ?></div>
      <div style="font-size:.8rem;color:var(--muted);line-height:1.5"><?= $desc ?></div>
    </div>
  </a>
  <?php endforeach; ?>
</div>
<!-- Daily limit info -->
<div class="cp-alert cp-alert-info" style="margin-bottom:20px">
  <i class="fa-solid fa-circle-info"></i>
  <div><strong>Daily Transfer Limit:</strong> ETB <?= number_format(CP_DAILY_TRANSFER_LIMIT) ?> &nbsp;·&nbsp; <strong>Used Today:</strong> ETB 0.00 &nbsp;·&nbsp; <strong>Remaining:</strong> ETB <?= number_format(CP_DAILY_TRANSFER_LIMIT) ?></div>
</div>
<!-- Recent transfers -->
<div class="cp-card">
  <div class="cp-card-hdr"><h3>Recent Transfers</h3><a href="<?= CP_BASE_URL ?>/customer/transactions/index.php" class="cp-btn cp-btn-outline cp-btn-sm">View All</a></div>
  <div class="cp-card-body p0">
    <table class="cp-table">
      <thead><tr><th>Date</th><th>Reference</th><th>Account</th><th>Description</th><th style="text-align:right">Amount</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($recentTransfers as $t):
          $isC = $t['type'] === 'Transfer In';
        ?>
        <tr>
          <td style="font-size:.8rem;white-space:nowrap"><?= cp_date($t['created_at']??'','d M H:i') ?></td>
          <td style="font-family:monospace;font-size:.79rem"><?= cp_e($t['reference']??'—') ?></td>
          <td style="font-family:monospace;font-size:.8rem"><?= cp_e($t['account_number']??'—') ?></td>
          <td style="font-size:.83rem"><?= cp_e($t['description']??'—') ?></td>
          <td style="text-align:right;font-weight:700;color:<?= $isC?'#16a34a':'#dc2626' ?>"><?= ($isC?'+':'-').cp_etb(abs((float)($t['amount']??0))) ?></td>
          <td><?= cp_badge($t['status']??'Completed') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
