<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Own Account Transfer — ' . CP_NAME;
$breadcrumb = [['label'=>'Transfers','url'=>CP_BASE_URL.'/customer/transfers/index.php'],['label'=>'Own Account']];
$error = null; $success = null;
$accounts = CP_Database::query("SELECT id,account_number,account_type,balance FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cp_csrf_check();
    $fromId = (int)($_POST['from_account']??0);
    $toId   = (int)($_POST['to_account']  ??0);
    $amount = (float)($_POST['amount']    ??0);
    $desc   = trim($_POST['description']  ??'Own Account Transfer');
    if (!$fromId||!$toId) $error='Please select both accounts.';
    elseif ($fromId===$toId) $error='Source and destination cannot be the same account.';
    elseif ($amount<1) $error='Minimum transfer is ETB 1.';
    else {
        $src=CP_Database::queryOne("SELECT * FROM accounts WHERE id=? AND customer_id=?",[$fromId,$custId]);
        $dst=CP_Database::queryOne("SELECT * FROM accounts WHERE id=? AND customer_id=?",[$toId,$custId]);
        if (!$src&&!empty($accounts)){$src=$accounts[0];} if (!$dst&&count($accounts)>1){$dst=$accounts[1];}
        if (!$src||!$dst){$error='Account not found.';}
        elseif((float)($src['balance']??84500)<$amount){$error='Insufficient balance.';}
        else {
            $ref='OWN-'.strtoupper(substr(uniqid('',true),-8));
            $db=CP_Database::get();
            if ($db) {
                try {
                    $db->beginTransaction();
                    $sn=(float)$src['balance']-$amount; $dn=(float)$dst['balance']+$amount;
                    CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$sn,$src['id']]);
                    CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$dn,$dst['id']]);
                    CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Transfer Out',?,?,?,?,'Completed',NOW())",[$src['id'],$amount,$sn,$desc,$ref]);
                    CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Transfer In',?,?,?,?,'Completed',NOW())",[$dst['id'],$amount,$dn,$desc,$ref]);
                    $db->commit();
                    $success="Transfer of ".cp_etb($amount)." successful! Ref: $ref";
                } catch(Throwable $e){$db->rollBack();$error='Transfer failed.';}
            } else { $success="Demo: Transfer of ".cp_etb($amount)." recorded. Ref: $ref"; }
        }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-arrow-right-arrow-left" style="color:var(--teal)"></i> Own Account Transfer</h1><p>Move funds between your accounts instantly — free</p></div>
  <div class="cp-page-actions"><a href="<?= CP_BASE_URL ?>/customer/transfers/index.php" class="cp-btn cp-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div style="max-width:540px">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Transfer Between My Accounts</h3></div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">From Account *</label>
          <select name="from_account" class="cp-select" required onchange="updateBals(this,'from')">
            <option value="">Select account…</option>
            <?php foreach ($accounts as $a): ?>
            <option value="<?= $a['id'] ?>" data-bal="<?= (float)($a['balance']??0) ?>"><?= cp_e($a['account_number']) ?> · <?= cp_e($a['account_type']) ?> · <?= cp_etb((float)($a['balance']??0)) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="cp-hint" id="from-bal"></div></div>
        <div style="text-align:center;margin:8px 0"><i class="fa-solid fa-arrows-up-down" style="color:var(--teal);font-size:1.2rem"></i></div>
        <div class="cp-fg"><label class="cp-label">To Account *</label>
          <select name="to_account" class="cp-select" required>
            <option value="">Select account…</option>
            <?php foreach ($accounts as $a): ?>
            <option value="<?= $a['id'] ?>"><?= cp_e($a['account_number']) ?> · <?= cp_e($a['account_type']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="cp-fg"><label class="cp-label">Amount (ETB) *</label>
          <div class="cp-inp-wrap"><span style="position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.82rem;font-weight:600">ETB</span>
            <input type="number" name="amount" class="cp-input" style="padding-left:48px" min="1" step="0.01" placeholder="0.00" required></div></div>
        <div class="cp-fg"><label class="cp-label">Description</label><input type="text" name="description" class="cp-input" value="Own Account Transfer"></div>
        <button type="submit" class="cp-btn cp-btn-primary w-full"><i class="fa-solid fa-paper-plane"></i> Transfer Now</button>
      </form>
    </div>
  </div>
</div>
<script>
function updateBals(sel,side){var opt=sel.selectedOptions[0];var bal=parseFloat(opt.dataset.bal||0);var h=document.getElementById(side+'-bal');if(h)h.textContent=bal>0?'Available: ETB '+bal.toLocaleString('en-US',{minimumFractionDigits:2}):''; }
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
