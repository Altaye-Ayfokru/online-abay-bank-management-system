<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$customer   = cp_guard();
$custId     = (int)($customer['id'] ?? 0);
$pageTitle  = 'Withdrawals — ' . CP_NAME;
$breadcrumb = [['label' => 'Withdrawals']];
$error = null; $success = null;
$accounts = CP_Database::query("SELECT id,account_number,account_type,balance FROM accounts WHERE customer_id=? AND status='Active'",[$custId]) ?: cp_demo_accounts($custId);
$history  = CP_Database::query("SELECT t.*,a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE a.customer_id=? AND t.type='Withdrawal' ORDER BY t.created_at DESC LIMIT 10",[$custId]) ?: [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    cp_csrf_check();
    $accId  = (int)($_POST['account']??0);
    $amount = (float)($_POST['amount']??0);
    $method = trim($_POST['method']??'Counter');
    $desc   = trim($_POST['description']??'Cash Withdrawal');
    if (!$accId)       $error='Please select an account.';
    elseif ($amount<CP_MIN_WITHDRAWAL) $error='Minimum withdrawal is '.cp_etb(CP_MIN_WITHDRAWAL).'.';
    else {
        $acc=CP_Database::queryOne("SELECT * FROM accounts WHERE id=? AND customer_id=?",[$accId,$custId]);
        if (!$acc&&!empty($accounts))$acc=$accounts[0];
        if (!$acc){$error='Account not found.';}
        elseif ((float)($acc['balance']??84500)<$amount){$error='Insufficient balance.';}
        else {
            $ref='WDR-'.strtoupper(substr(uniqid('',true),-8));
            $db=CP_Database::get();
            if ($db&&$acc&&isset($acc['id'])){
                $nb=(float)$acc['balance']-$amount;
                CP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$nb,$acc['id']]);
                CP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_at) VALUES (?,'Withdrawal',?,?,?,?,'Completed',NOW())",[$acc['id'],$amount,$nb,$desc,$ref]);
                $success="Withdrawal of ".cp_etb($amount)." processed! Ref: $ref";
            } else { $success="Demo: Withdrawal of ".cp_etb($amount)." recorded. Ref: $ref"; }
        }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="cp-page-hdr">
  <div><h1><i class="fa-solid fa-arrow-up" style="color:#ef4444"></i> Withdrawals</h1><p>Request a withdrawal from your account</p></div>
</div>
<?php if ($error): ?><div class="cp-alert cp-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= cp_e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cp-alert cp-alert-success"><i class="fa-solid fa-circle-check"></i><?= cp_e($success) ?></div><?php endif; ?>
<div class="cp-grid-2" style="align-items:start">
  <div class="cp-card">
    <div class="cp-card-hdr"><h3><i class="fa-solid fa-arrow-up" style="color:#ef4444"></i> Withdraw Funds</h3></div>
    <div class="cp-card-body">
      <form method="POST">
        <?= cp_csrf_field() ?>
        <div class="cp-fg"><label class="cp-label">From Account *</label>
          <select name="account" class="cp-select" required onchange="showBal(this)">
            <option value="">Select account…</option>
            <?php foreach ($accounts as $a): ?><option value="<?= $a['id'] ?>" data-bal="<?= (float)($a['balance']??0) ?>"><?= cp_e($a['account_number']) ?> · <?= cp_etb((float)($a['balance']??0)) ?></option><?php endforeach; ?>
          </select>
          <div class="cp-hint" id="bal-display"></div></div>
        <div class="cp-fg"><label class="cp-label">Withdrawal Method</label>
          <select name="method" class="cp-select"><option>Counter (Branch)</option><option>ATM</option><option>Mobile Money</option></select></div>
        <div class="cp-fg"><label class="cp-label">Amount (ETB) *</label>
          <div class="cp-inp-wrap"><span style="position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.82rem;font-weight:600">ETB</span>
            <input type="number" name="amount" class="cp-input" style="padding-left:48px" min="<?= CP_MIN_WITHDRAWAL ?>" placeholder="0.00" required id="wdr-amt" oninput="validateAmt(this.value)"></div>
          <div class="cp-hint" id="amt-hint"></div></div>
        <div class="cp-fg"><label class="cp-label">Narration</label><input type="text" name="description" class="cp-input" value="Cash Withdrawal"></div>
        <div class="cp-alert cp-alert-warning" style="font-size:.82rem;margin-bottom:16px"><i class="fa-solid fa-triangle-exclamation"></i><div>Large withdrawals may require in-branch verification.</div></div>
        <button type="submit" class="cp-btn cp-btn-danger w-full"><i class="fa-solid fa-arrow-up"></i> Request Withdrawal</button>
      </form>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-hdr"><h3>Withdrawal History</h3></div>
    <div class="cp-card-body p0">
      <?php if (empty($history)): ?>
      <div style="text-align:center;padding:32px;color:var(--muted)"><i class="fa-solid fa-inbox" style="font-size:1.5rem;display:block;margin-bottom:8px"></i>No withdrawals yet</div>
      <?php else: ?>
      <table class="cp-table"><thead><tr><th>Date</th><th>Account</th><th>Amount</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($history as $w): ?>
        <tr><td style="font-size:.8rem"><?= cp_date($w['created_at']??'','d M H:i') ?></td><td style="font-family:monospace;font-size:.8rem"><?= cp_e($w['account_number']??'—') ?></td><td style="font-weight:700;color:#dc2626">-<?= cp_etb((float)($w['amount']??0)) ?></td><td><?= cp_badge($w['status']??'Completed') ?></td></tr>
        <?php endforeach; ?>
      </tbody></table>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
var _avBal=0;
function showBal(sel){var o=sel.selectedOptions[0];_avBal=parseFloat(o.dataset.bal||0);var h=document.getElementById('bal-display');if(h)h.textContent='Available: ETB '+_avBal.toLocaleString('en-US',{minimumFractionDigits:2});}
function validateAmt(v){var amt=parseFloat(v)||0;var h=document.getElementById('amt-hint');if(!h)return;if(_avBal>0&&amt>_avBal){h.innerHTML='<span style="color:#ef4444">Exceeds available balance</span>';}else if(amt>0){h.innerHTML='<span style="color:#22c55e">✓ Amount valid</span>';}else{h.textContent='';}}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
