<?php foreach (['success','danger','warning','info'] as $t) {
    $m = cp_get_flash($t);
    if ($m): ?>
<div class="cp-alert cp-alert-<?= $t ?>" style="margin-bottom:16px">
  <i class="fa-solid <?= ['success'=>'fa-circle-check','danger'=>'fa-circle-xmark','warning'=>'fa-triangle-exclamation','info'=>'fa-circle-info'][$t] ?>"></i>
  <div><?= htmlspecialchars($m) ?></div>
</div>
<?php endif; } ?>
