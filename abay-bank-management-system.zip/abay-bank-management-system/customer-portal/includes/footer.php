<?php /** Customer Portal Footer */ ?>
</div><!-- end cp-main -->

<?php if (!empty($needsCharts)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<?php endif; ?>
<script src="<?= CP_ASSET_URL ?>/js/app.js"></script>
<?php if (!empty($needsCharts)): ?><script src="<?= CP_ASSET_URL ?>/js/dashboard.js"></script><?php endif; ?>
<?php if (!empty($extraJs)) foreach ((array)$extraJs as $js): ?>
<script src="<?= htmlspecialchars($js) ?>"></script>
<?php endforeach; ?>
<?php if (!empty($pageScript)): ?><script><?= $pageScript ?></script><?php endif; ?>
</body>
</html>
