<?php

/** Customer Portal Helper Functions */

function cp_e(mixed $v): string
{
  return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function cp_etb(float $n): string
{
  return 'ETB ' . number_format($n, 2);
}
function cp_num(int $n): string
{
  return number_format($n);
}
function cp_redirect(string $url): never
{
  header('Location: ' . $url);
  exit;
}

function cp_flash(string $type, string $msg): void
{
  $_SESSION['cp_flash_' . $type] = $msg;
}
function cp_get_flash(string $type): ?string
{
  $m = $_SESSION['cp_flash_' . $type] ?? null;
  unset($_SESSION['cp_flash_' . $type]);
  return $m;
}

function cp_full_name(array $c): string
{
  return trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? '')) ?: ($c['name'] ?? 'Customer');
}
function cp_initials(array $c): string
{
  $n = cp_full_name($c);
  $p = explode(' ', $n);
  return strtoupper(substr($p[0], 0, 1) . (isset($p[1]) ? substr($p[1], 0, 1) : ''));
}
function cp_avatar(array $c): string
{
  if (!empty($c['photo_path'])) return CP_BASE_URL . '/uploads/profiles/' . basename($c['photo_path']);
  if (!empty($c['avatar']))    return CP_BASE_URL . '/uploads/profiles/' . basename($c['avatar']);
  return '';
}
function cp_date(string $d, string $fmt = 'd M Y'): string
{
  if (!$d || $d === '0000-00-00') return '—';
  try {
    return (new DateTime($d))->format($fmt);
  } catch (Throwable) {
    return $d;
  }
}
function cp_ago(string $dt): string
{
  try {
    $diff = time() - (new DateTime($dt))->getTimestamp();
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return (int)($diff / 60) . ' min ago';
    if ($diff < 86400) return (int)($diff / 3600) . ' hr ago';
    return cp_date($dt);
  } catch (Throwable) {
    return $dt;
  }
}
function cp_badge(string $status): string
{
  $map = [
    'Active' => 'success',
    'Verified' => 'success',
    'Completed' => 'success',
    'Approved' => 'success',
    'Paid' => 'success',
    'Pending' => 'warning',
    'Processing' => 'warning',
    'In Review' => 'warning',
    'Inactive' => 'secondary',
    'Closed' => 'secondary',
    'Expired' => 'secondary',
    'Rejected' => 'danger',
    'Suspended' => 'danger',
    'Failed' => 'danger',
    'Overdue' => 'danger'
  ];
  $cls = $map[$status] ?? 'secondary';
  $colors = ['success' => '#22c55e20,#16a34a', 'warning' => '#fef9c320,#b45309', 'danger' => '#fee2e220,#dc2626', 'secondary' => '#f1f5f920,#64748b', 'info' => '#dbeafe20,#1d4ed8', 'primary' => '#e0f5f720,#007A8A'];
  [$bg, $clr] = explode(',', $colors[$cls] ?? '#f1f5f920,#64748b');
  return "<span style=\"background:{$bg};color:{$clr};padding:3px 10px;border-radius:99px;font-size:.72rem;font-weight:700\">" . cp_e($status) . "</span>";
}

/** Demo customer data */
function cp_demo_customers(): array
{
  return [
    ['id' => 1, 'customer_number' => 'CUST-A1B2C3D', 'first_name' => 'Abebe', 'last_name' => 'Bekele', 'email' => 'abebe.bekele@email.com', 'phone' => '+251911234567', 'gender' => 'Male', 'date_of_birth' => '1990-05-15', 'kyc_status' => 'Verified', 'status' => 'Active', 'branch_id' => 1, 'created_at' => '2022-03-10', 'address' => 'Bole Sub-City, Addis Ababa', 'photo_path' => null, 'national_id' => 'ET12345678'],
    ['id' => 2, 'customer_number' => 'CUST-E4F5G6H', 'first_name' => 'Tigist', 'last_name' => 'Haile', 'email' => 'tigist.haile@email.com', 'phone' => '+251912345678', 'gender' => 'Female', 'date_of_birth' => '1988-08-22', 'kyc_status' => 'Verified', 'status' => 'Active', 'branch_id' => 2, 'created_at' => '2021-11-05', 'address' => 'Kirkos Sub-City, Addis Ababa', 'photo_path' => null, 'national_id' => 'ET23456789'],
  ];
}

/** Demo accounts for a customer */
function cp_demo_accounts(int $custId): array
{
  return [
    ['id' => 1, 'account_number' => '1000012345678', 'account_type' => 'Savings', 'balance' => 157278.50, 'status' => 'Active', 'opened_date' => '2022-03-12', 'currency' => 'ETB', 'branch_name' => 'Alem Ketema Branch'],
    ['id' => 2, 'account_number' => '1000098765432', 'account_type' => 'Current', 'balance' => 45000.00, 'status' => 'Active', 'opened_date' => '2023-01-20', 'currency' => 'ETB', 'branch_name' => 'Alem Ketema Branch'],
  ];
}

/** Demo transactions */
function cp_demo_transactions(int $custId, int $limit = 10): array
{
  $types = ['Deposit', 'Withdrawal', 'Transfer Out', 'Transfer In', 'Loan Disbursement', 'Loan Repayment'];
  $descs = ['Cash deposit', 'ATM withdrawal', 'Transfer to account', 'Salary credit', 'Utility payment', 'Mobile top-up'];
  $txns = [];
  for ($i = 0; $i < $limit; $i++) {
    $type = $types[$i % count($types)];
    $isCredit = in_array($type, ['Deposit', 'Transfer In', 'Loan Disbursement']);
    $txns[] = [
      'id' => $i + 1,
      'reference' => 'TXN-' . strtoupper(substr(md5($i), 0, 8)),
      'type' => $type,
      'amount' => round(rand(500, 50000) * 0.01, 2) * 100,
      'description' => $descs[$i % count($descs)],
      'status' => 'Completed',
      'is_credit' => $isCredit,
      'created_at' => date('Y-m-d H:i:s', time() - ($i * 86400 + rand(0, 3600))),
    ];
  }
  return $txns;
}

/** Loan repayment schedule */
function cp_loan_schedule(float $principal, float $rate, int $months): array
{
  $r = $rate / 1200;
  $emi = $principal * $r / pow(1 + $r, -$months) * -1;
  $schedule = [];
  $bal = $principal;
  for ($i = 1; $i <= $months; $i++) {
    $int = round($bal * $r, 2);
    $prin = round($emi - $int, 2);
    $bal = round($bal - $prin, 2);
    $schedule[] = ['month' => $i, 'emi' => round($emi, 2), 'principal' => $prin, 'interest' => $int, 'balance' => max(0, $bal), 'due_date' => date('Y-m-d', strtotime("+{$i} months")), 'status' => $i <= 3 ? 'Paid' : ($i == 4 ? 'Upcoming' : 'Pending')];
    if ($bal <= 0) break;
  }
  return $schedule;
}

/**
 * Notify all admin users about a new pending request from the customer portal.
 * Inserts a notification row into the shared 'notifications' table (if DB available).
 *
 * @param string $type    e.g. 'loan', 'appointment', 'complaint', 'kyc'
 * @param string $title   Short title for the notification
 * @param string $message Descriptive message
 * @param int    $custId  Customer ID (used for reference)
 */
function cp_notify_admin(string $type, string $title, string $message, int $custId = 0): void
{
  try {
    $db = CP_Database::get();
    if (!$db) return;

    // Get all Admin users from the users table
    $stmt = $db->prepare("SELECT id FROM users u LEFT JOIN roles r ON r.id=u.role_id WHERE r.role_name='Admin' AND u.status='Active' LIMIT 20");
    $stmt->execute();
    $admins = $stmt->fetchAll(\PDO::FETCH_COLUMN);

    if (empty($admins)) $admins = [1]; // fallback to user ID 1

    $ins = $db->prepare("INSERT INTO notifications (user_id, type, title, message, customer_id, is_read, created_at) VALUES (?,?,?,?,?,0,NOW())");
    foreach ($admins as $adminId) {
      $ins->execute([(int)$adminId, $type, $title, $message, $custId ?: null]);
    }
  } catch (\Throwable) {
    // Silently ignore — notification is non-critical
  }
}
