<?php

/**
 * Customer Portal — HTML Head + Topbar
 * Expects: $pageTitle, $customer (from cp_guard())
 */
$pageTitle = $pageTitle ?? CP_NAME;
$unreadCount = 0;
if (!empty($customer['id'])) {
  $unreadCount = (int)(CP_Database::queryOne("SELECT COUNT(*) AS c FROM notifications WHERE customer_id=? AND is_read=0", [$customer['id']])['c'] ?? 0);
}
$avatarUrl = cp_avatar($customer ?? []);
$initials  = cp_initials($customer ?? []);
$fullName  = cp_full_name($customer ?? []);
$custNo    = $customer['customer_number'] ?? 'CUST-XXXXXXX';
$kycStatus = $customer['kyc_status'] ?? 'Pending';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <meta name="cp-base-url" content="<?= CP_BASE_URL ?>">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= CP_ASSET_URL ?>/css/main.css">
  <link rel="stylesheet" href="<?= CP_ASSET_URL ?>/css/sidebar.css">
  <link rel="stylesheet" href="<?= CP_ASSET_URL ?>/css/dashboard.css">
  <?php if (!empty($extraCss)) foreach ((array)$extraCss as $css): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars($css) ?>">
  <?php endforeach; ?>
</head>

<body>

  <!-- Sidebar backdrop -->
  <div class="cp-sb-backdrop" id="cp-sb-backdrop"></div>

  <?php include __DIR__ . '/sidebar.php'; ?>

  <!-- Topbar -->
  <header class="cp-topbar">
    <div class="cp-topbar-left">
      <button class="cp-hamburger" id="cp-hamburger"><i class="fa-solid fa-bars"></i></button>
      <div class="cp-breadcrumb">
        <a href="<?= CP_BASE_URL ?>/customer/dashboard.php"><i class="fa-solid fa-house" style="font-size:.75rem"></i></a>
        <?php if (!empty($breadcrumb)) foreach ((array)$breadcrumb as $bc): ?>
          <span>/</span>
          <?php if (isset($bc['url'])): ?><a href="<?= htmlspecialchars($bc['url']) ?>"><?= cp_e($bc['label'] ?? $bc) ?></a>
          <?php else: ?><span style="color:#1e293b;font-weight:600"><?= cp_e($bc['label'] ?? $bc) ?></span><?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="cp-topbar-right">
      <span id="cp-clock" style="font-size:.78rem;color:#64748b;font-weight:600;min-width:50px"></span>
      <!-- Theme toggle -->
      <button class="cp-tb-btn" onclick="toggleTheme()" title="Toggle theme" id="theme-btn">
        <i class="fa-solid fa-moon" id="theme-ic"></i>
      </button>
      <!-- Notifications -->
      <a href="<?= CP_BASE_URL ?>/customer/notifications/index.php" class="cp-tb-btn" title="Notifications">
        <i class="fa-solid fa-bell"></i>
        <?php if ($unreadCount > 0): ?><span class="cp-notif-dot"></span><?php endif; ?>
      </a>
      <!-- User -->
      <a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-tb-user">
        <div class="cp-avatar cp-av-sm" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;overflow:hidden;border-radius:50%;flex-shrink:0">
          <?php if ($avatarUrl): ?>
            <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= cp_e($fullName) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
          <?php else: ?>
            <span style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
          <?php endif; ?>
        </div>
        <div style="display:none" class="d-lg-block">
          <div class="cp-tb-uname"><?= cp_e($fullName) ?></div>
          <div class="cp-tb-urole">Customer</div>
        </div>
      </a>
      <a href="<?= CP_BASE_URL ?>/auth/logout.php" class="cp-btn cp-btn-ghost cp-btn-sm" title="Sign out">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
      </a>
    </div>
  </header>

  <!-- Main content wrapper -->
  <div class="cp-main">

    <?php include __DIR__ . '/alerts.php'; ?>
    <script>
      function toggleTheme() {
        var html = document.documentElement,
          cur = html.getAttribute('data-theme') || 'light',
          next = cur === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('cp_theme', next);
        document.getElementById('theme-ic').className = 'fa-solid ' + (next === 'dark' ? 'fa-sun' : 'fa-moon');
      }
      (function() {
        var t = localStorage.getItem('cp_theme') || 'light';
        document.documentElement.setAttribute('data-theme', t);
        var ic = document.getElementById('theme-ic');
        if (ic) ic.className = 'fa-solid ' + (t === 'dark' ? 'fa-sun' : 'fa-moon');
      })();
    </script>