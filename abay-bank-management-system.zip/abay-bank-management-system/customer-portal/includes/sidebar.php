<?php

/**
 * Customer Portal — Sidebar Navigation
 * Expects $customer array from cp_guard()
 */
$curPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$isActive = fn(string $p): string => str_contains($curPath, $p) ? ' active' : '';

$c = $customer ?? [];
$avatarUrl = cp_avatar($c);
$initials  = cp_initials($c);
$fullName  = cp_full_name($c);
$custNo    = $c['customer_number'] ?? 'CUST-XXXXXXX';
$kycStatus = $c['kyc_status'] ?? 'Pending';
$kycColor  = $kycStatus === 'Verified' ? '#22c55e' : ($kycStatus === 'Rejected' ? '#ef4444' : '#f59e0b');

// Get primary account balance for sidebar
$primaryAcc = CP_Database::queryOne(
  "SELECT account_number, balance, account_type FROM accounts WHERE customer_id=? AND status='Active' ORDER BY opened_date ASC LIMIT 1",
  [(int)($c['id'] ?? 0)]
) ?? ['account_number' => '100XXXXXXXXXX', 'balance' => 0, 'account_type' => 'Savings'];
?>
<aside class="cp-sidebar" id="cp-sidebar">

  <div class="cp-sb-brand">
    <div class="cp-sb-logo">
      <span class="cp-lb1"></span><span class="cp-lb2"></span>
      <span class="cp-lb3"></span><span class="cp-lb4"></span>
    </div>
    <div>
      <div class="cp-sb-name">Abay Bank S.C.</div>
      <div class="cp-sb-portal">Online Banking</div>
    </div>
  </div>

  <!-- Customer profile card -->
  <div class="cp-sb-profile">
    <div class="cp-sb-profile-av" style="overflow:hidden;border-radius:50%">
      <?php if ($avatarUrl): ?>
        <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= cp_e($fullName) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
        <span style="display:none"><?= $initials ?></span>
      <?php else: ?>
        <?= $initials ?>
      <?php endif; ?>
    </div>
    <div style="flex:1;min-width:0;overflow:hidden">
      <div class="cp-sb-profile-name"><?= cp_e($fullName) ?></div>
      <div class="cp-sb-profile-id"><?= cp_e($custNo) ?></div>
      <div class="cp-sb-profile-kyc"><i class="fa-solid fa-circle" style="font-size:.4rem"></i> <?= cp_e($kycStatus) ?></div>
    </div>
  </div>

  <!-- Balance mini card -->
  <div class="cp-sb-balance">
    <div class="cp-sb-bal-label">Available Balance</div>
    <div class="cp-sb-bal-amount"><?= cp_etb((float)$primaryAcc['balance']) ?></div>
    <div class="cp-sb-bal-acct"><?= cp_e($primaryAcc['account_number']) ?> &middot; <?= cp_e($primaryAcc['account_type']) ?></div>
  </div>

  <div class="cp-sb-scroll">

    <div class="cp-sb-section">Main</div>
    <a href="<?= CP_BASE_URL ?>/customer/dashboard.php" class="cp-sb-link<?= $isActive('/dashboard') ?>">
      <i class="fa-solid fa-gauge-high"></i> Dashboard
    </a>

    <div class="cp-sb-section">Accounts &amp; Cards</div>
    <a href="<?= CP_BASE_URL ?>/customer/accounts/index.php" class="cp-sb-link<?= $isActive('/accounts') ?>">
      <i class="fa-solid fa-building-columns"></i> My Accounts
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/cards/index.php" class="cp-sb-link<?= $isActive('/cards') ?>">
      <i class="fa-solid fa-credit-card"></i> Cards
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/statements/index.php" class="cp-sb-link<?= $isActive('/statements') ?>">
      <i class="fa-solid fa-file-lines"></i> Statements
    </a>

    <div class="cp-sb-section">Transactions</div>
    <a href="<?= CP_BASE_URL ?>/customer/transactions/index.php" class="cp-sb-link<?= $isActive('/transactions') ?>">
      <i class="fa-solid fa-clock-rotate-left"></i> History
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/transfers/index.php" class="cp-sb-link<?= $isActive('/transfers') ?>">
      <i class="fa-solid fa-right-left"></i> Transfers
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/deposits/index.php" class="cp-sb-link<?= $isActive('/deposits') ?>">
      <i class="fa-solid fa-arrow-down"></i> Deposits
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/withdrawals/index.php" class="cp-sb-link<?= $isActive('/withdrawals') ?>">
      <i class="fa-solid fa-arrow-up"></i> Withdrawals
    </a>

    <div class="cp-sb-section">Services</div>
    <a href="<?= CP_BASE_URL ?>/customer/loans/index.php" class="cp-sb-link<?= $isActive('/loans') ?>">
      <i class="fa-solid fa-file-invoice-dollar"></i> Loans
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/kyc/index.php" class="cp-sb-link<?= $isActive('/kyc') ?>">
      <i class="fa-solid fa-id-card"></i> KYC Verification
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/beneficiaries/index.php" class="cp-sb-link<?= $isActive('/beneficiaries') ?>">
      <i class="fa-solid fa-users"></i> Beneficiaries
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/appointments/index.php" class="cp-sb-link<?= $isActive('/appointments') ?>">
      <i class="fa-solid fa-calendar-days"></i> Appointments
    </a>

    <div class="cp-sb-section">Support</div>
    <a href="<?= CP_BASE_URL ?>/customer/complaints/index.php" class="cp-sb-link<?= $isActive('/complaints') ?>">
      <i class="fa-solid fa-headset"></i> Complaints
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/notifications/index.php" class="cp-sb-link<?= $isActive('/notifications') ?>">
      <i class="fa-solid fa-bell"></i> Notifications
      <?php
      $unread = (int)(CP_Database::queryOne("SELECT COUNT(*) AS c FROM notifications WHERE customer_id=? AND is_read=0", [(int)($c['id'] ?? 0)])['c'] ?? 0);
      if ($unread > 0): ?><span class="cp-sb-badge"><?= $unread ?></span><?php endif; ?>
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/messages/index.php" class="cp-sb-link<?= $isActive('/messages') ?>">
      <i class="fa-solid fa-envelope"></i> Messages
    </a>

    <div class="cp-sb-section">Account</div>
    <a href="<?= CP_BASE_URL ?>/customer/profile/index.php" class="cp-sb-link<?= $isActive('/profile') ?>">
      <i class="fa-solid fa-user-circle"></i> My Profile
    </a>
    <a href="<?= CP_BASE_URL ?>/customer/settings/index.php" class="cp-sb-link<?= $isActive('/settings') ?>">
      <i class="fa-solid fa-gear"></i> Settings
    </a>

  </div>

  <div class="cp-sb-footer">
    <div class="cp-avatar cp-av-sm" style="background:linear-gradient(135deg,#C8A84B,#e8c86a);color:#1B3A5C;flex-shrink:0">
      <?php if ($avatarUrl): ?><img src="<?= htmlspecialchars($avatarUrl) ?>" alt="">
        <?php else: ?><?= $initials ?><?php endif; ?>
    </div>
    <div style="flex:1;min-width:0;overflow:hidden">
      <div style="font-size:.79rem;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= cp_e($fullName) ?></div>
      <div style="font-size:.66rem;color:rgba(255,255,255,.4)">Customer</div>
    </div>
    <a href="<?= CP_BASE_URL ?>/auth/logout.php" class="cp-sb-logout" title="Sign Out">
      <i class="fa-solid fa-arrow-right-from-bracket"></i>
    </a>
  </div>

</aside>