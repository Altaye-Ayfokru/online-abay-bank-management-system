<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/middleware/auth.php';
if (cp_is_logged_in()) { header('Location: ' . CP_BASE_URL . '/customer/dashboard.php'); exit; }
header('Location: ' . CP_BASE_URL . '/auth/login.php'); exit;
