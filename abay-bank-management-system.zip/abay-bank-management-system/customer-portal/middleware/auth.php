<?php
require_once dirname(__DIR__) . '/config/config.php';

function cp_guard(): array {
    if (empty($_SESSION['cp_logged_in']) || empty($_SESSION['cp_customer'])) {
        $_SESSION['cp_flash_error'] = 'Please sign in to access your customer portal.';
        $_SESSION['cp_redirect_after'] = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: ' . CP_BASE_URL . '/auth/login.php'); exit;
    }
    if (!empty($_SESSION['cp_last_activity']) && (time()-$_SESSION['cp_last_activity']) > CP_SESSION_TIMEOUT) {
        cp_logout();
        header('Location: ' . CP_BASE_URL . '/auth/login.php?reason=timeout'); exit;
    }
    $_SESSION['cp_last_activity'] = time();
    return $_SESSION['cp_customer'];
}

function cp_login_customer(array $customer): void {
    $_SESSION['cp_logged_in']      = true;
    $_SESSION['cp_customer']       = $customer;
    $_SESSION['cp_login_time']     = time();
    $_SESSION['cp_last_activity']  = time();
}

function cp_logout(): void {
    unset($_SESSION['cp_logged_in'],$_SESSION['cp_customer'],$_SESSION['cp_login_time'],$_SESSION['cp_last_activity']);
}

function cp_is_logged_in(): bool {
    return !empty($_SESSION['cp_logged_in']) && !empty($_SESSION['cp_customer']);
}

function cp_customer(): ?array {
    return $_SESSION['cp_customer'] ?? null;
}
