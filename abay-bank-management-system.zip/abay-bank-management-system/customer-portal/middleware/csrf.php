<?php
function cp_csrf_token(): string {
    if (empty($_SESSION['cp_csrf'])) $_SESSION['cp_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['cp_csrf'];
}
function cp_csrf_field(): string {
    return '<input type="hidden" name="_cp_csrf" value="' . htmlspecialchars(cp_csrf_token()) . '">';
}
function cp_csrf_check(): void {
    $t = $_POST['_cp_csrf'] ?? $_SERVER['HTTP_X_CP_CSRF'] ?? '';
    if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['cp_csrf']??'',$t)) {
        http_response_code(403); die('Invalid CSRF token. <a href="javascript:history.back()">Go back</a>');
    }
}
