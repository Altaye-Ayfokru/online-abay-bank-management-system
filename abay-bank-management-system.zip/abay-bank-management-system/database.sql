-- ============================================================
-- ABAY BANK MANAGEMENT SYSTEM — DATABASE SCHEMA
-- MySQL 8.0+ | Character Set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET GLOBAL time_zone = '+03:00';

CREATE DATABASE IF NOT EXISTS `abay_bank`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `abay_bank`;

-- ============================================================
-- 1. BRANCHES
-- ============================================================
CREATE TABLE IF NOT EXISTS `branches` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`         VARCHAR(20)  NOT NULL UNIQUE,
  `name`         VARCHAR(100) NOT NULL,
  `city`         VARCHAR(100) NOT NULL,
  `region`       VARCHAR(100) NOT NULL DEFAULT 'Addis Ababa',
  `address`      TEXT,
  `phone`        VARCHAR(20),
  `email`        VARCHAR(100),
  `manager_id`   INT UNSIGNED NULL,
  `cash_balance` DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `status`       ENUM('Active','Inactive','Maintenance') NOT NULL DEFAULT 'Active',
  `opened_date`  DATE,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 2. ROLES & PERMISSIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `roles` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(50)  NOT NULL UNIQUE,
  `description` VARCHAR(255),
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `permissions` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `module`     VARCHAR(50) NOT NULL,
  `action`     ENUM('view','create','edit','delete','approve') NOT NULL,
  `role_id`    INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_role_module_action` (`role_id`,`module`,`action`),
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 3. USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id`                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username`             VARCHAR(50)  NOT NULL UNIQUE,
  `email`                VARCHAR(100) NOT NULL UNIQUE,
  `password`             VARCHAR(255) NOT NULL,
  `role_id`              INT UNSIGNED NOT NULL,
  `branch_id`            INT UNSIGNED,
  `full_name`            VARCHAR(100),
  `phone`                VARCHAR(20),
  `status`               ENUM('Active','Inactive','Locked') NOT NULL DEFAULT 'Active',
  `failed_attempts`      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login_at`        DATETIME,
  `password_changed_at`  DATETIME,
  `created_at`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`           DATETIME NULL,
  FOREIGN KEY (`role_id`)   REFERENCES `roles`(`id`),
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`) ON DELETE SET NULL,
  INDEX `idx_status`  (`status`),
  INDEX `idx_role`    (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 4. CUSTOMERS
-- ============================================================
CREATE TABLE IF NOT EXISTS `customers` (
  `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_number`   VARCHAR(20) NULL UNIQUE,
  `first_name`        VARCHAR(50)  NOT NULL,
  `last_name`         VARCHAR(50)  NOT NULL,
  `email`             VARCHAR(100) NOT NULL UNIQUE,
  `phone`             VARCHAR(20)  NOT NULL,
  `alt_phone`         VARCHAR(20),
  `national_id`       VARCHAR(30)  NOT NULL UNIQUE,
  `passport_number`   VARCHAR(30),
  `date_of_birth`     DATE,
  `gender`            ENUM('Male','Female','Other'),
  `marital_status`    ENUM('Single','Married','Divorced','Widowed'),
  `nationality`       VARCHAR(50)  NOT NULL DEFAULT 'Ethiopian',
  `occupation`        VARCHAR(100),
  `employer`          VARCHAR(100),
  `monthly_income`    DECIMAL(15,2),
  `segment`           ENUM('Retail','Premium','Corporate','SME') NOT NULL DEFAULT 'Retail',
  `address`           TEXT,
  `city`              VARCHAR(100),
  `region`            VARCHAR(100),
  `subcity`           VARCHAR(100),
  `kebele`            VARCHAR(50),
  `po_box`            VARCHAR(20),
  `branch_id`         INT UNSIGNED NOT NULL,
  `relationship_mgr`  INT UNSIGNED NULL,
  `status`            ENUM('Active','Inactive','Suspended','Deleted') NOT NULL DEFAULT 'Active',
  `kyc_status`        ENUM('Pending','Verified','Rejected','Expired') NOT NULL DEFAULT 'Pending',
  `kyc_verified_at`   DATETIME,
  `kyc_verified_by`   INT UNSIGNED,
  `photo_path`        VARCHAR(255),
  `notes`             TEXT,
  `created_by`        INT UNSIGNED,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`        DATETIME NULL,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  INDEX `idx_status`     (`status`),
  INDEX `idx_kyc`        (`kyc_status`),
  INDEX `idx_email`      (`email`),
  INDEX `idx_phone`      (`phone`),
  INDEX `idx_national_id`(`national_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 5. ACCOUNTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `accounts` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`    INT UNSIGNED NOT NULL,
  `branch_id`      INT UNSIGNED NOT NULL,
  `account_number` VARCHAR(20)  NOT NULL UNIQUE,
  `account_type`   ENUM('Savings','Current','Fixed Deposit') NOT NULL,
  `currency`       VARCHAR(3)   NOT NULL DEFAULT 'ETB',
  `balance`        DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `interest_rate`  DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `min_balance`    DECIMAL(15,2) NOT NULL DEFAULT 100.00,
  `overdraft_limit`DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `status`         ENUM('Active','Frozen','Blocked','Closed') NOT NULL DEFAULT 'Active',
  `opened_date`    DATE NOT NULL DEFAULT (CURDATE()),
  `closed_date`    DATE,
  `fd_duration`    TINYINT UNSIGNED COMMENT 'Fixed deposit months',
  `fd_maturity_date` DATE,
  `fd_interest_rate` DECIMAL(5,2),
  `created_by`     INT UNSIGNED,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`),
  FOREIGN KEY (`branch_id`)   REFERENCES `branches`(`id`),
  INDEX `idx_customer`  (`customer_id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_type`      (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 6. TRANSACTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `transactions` (
  `id`             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id`     INT UNSIGNED NOT NULL,
  `reference`      VARCHAR(40)  NOT NULL UNIQUE,
  `type`           ENUM('Deposit','Withdrawal','Transfer In','Transfer Out','Interest Credit','Loan Disbursement','Loan Repayment','Fee','Reversal') NOT NULL,
  `amount`         DECIMAL(20,2) NOT NULL,
  `balance_before` DECIMAL(20,2) NOT NULL,
  `balance_after`  DECIMAL(20,2) NOT NULL,
  `description`    VARCHAR(255),
  `channel`        ENUM('Counter','ATM','Online','Mobile','RTGS','SWIFT') NOT NULL DEFAULT 'Counter',
  `status`         ENUM('Pending','Completed','Failed','Reversed') NOT NULL DEFAULT 'Completed',
  `approved_by`    INT UNSIGNED,
  `approved_at`    DATETIME,
  `reversed_by`    INT UNSIGNED,
  `reversed_at`    DATETIME,
  `created_by`     INT UNSIGNED,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`),
  INDEX `idx_account`  (`account_id`),
  INDEX `idx_reference`(`reference`),
  INDEX `idx_type`     (`type`),
  INDEX `idx_status`   (`status`),
  INDEX `idx_date`     (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 7. LOANS
-- ============================================================
CREATE TABLE IF NOT EXISTS `loans` (
  `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loan_number`       VARCHAR(20) NULL UNIQUE,
  `customer_id`       INT UNSIGNED NOT NULL,
  `account_id`        INT UNSIGNED NOT NULL,
  `branch_id`         INT UNSIGNED NOT NULL,
  `loan_type`         ENUM('Personal','Business','Mortgage','Agricultural','Student','Emergency') NOT NULL,
  `amount`            DECIMAL(20,2) NOT NULL,
  `approved_amount`   DECIMAL(20,2),
  `interest_rate`     DECIMAL(5,2)  NOT NULL,
  `term_months`       SMALLINT UNSIGNED NOT NULL,
  `emi`               DECIMAL(15,2),
  `purpose`           TEXT NOT NULL,
  `collateral_type`   VARCHAR(100),
  `collateral_value`  DECIMAL(20,2),
  `disbursed_amount`  DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `outstanding`       DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `paid_amount`       DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `overdue_amount`    DECIMAL(20,2) NOT NULL DEFAULT 0.00,
  `next_due_date`     DATE,
  `disbursed_date`    DATE,
  `expected_close_date` DATE,
  `actual_close_date` DATE,
  `status`            ENUM('Pending','Under Review','Approved','Rejected','Active','Completed','Defaulted') NOT NULL DEFAULT 'Pending',
  `credit_score`      SMALLINT UNSIGNED,
  `loan_officer_id`   INT UNSIGNED,
  `approved_by`       INT UNSIGNED,
  `approved_at`       DATETIME,
  `rejection_reason`  TEXT,
  `created_by`        INT UNSIGNED,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`),
  FOREIGN KEY (`account_id`)  REFERENCES `accounts`(`id`),
  FOREIGN KEY (`branch_id`)   REFERENCES `branches`(`id`),
  INDEX `idx_customer` (`customer_id`),
  INDEX `idx_status`   (`status`),
  INDEX `idx_type`     (`loan_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 8. LOAN REPAYMENT SCHEDULE
-- ============================================================
CREATE TABLE IF NOT EXISTS `loan_schedules` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loan_id`         INT UNSIGNED NOT NULL,
  `installment_no`  SMALLINT UNSIGNED NOT NULL,
  `due_date`        DATE NOT NULL,
  `emi_amount`      DECIMAL(15,2) NOT NULL,
  `principal`       DECIMAL(15,2) NOT NULL,
  `interest`        DECIMAL(15,2) NOT NULL,
  `balance`         DECIMAL(15,2) NOT NULL,
  `paid_date`       DATE,
  `paid_amount`     DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `penalty`         DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `status`          ENUM('Upcoming','Due','Paid','Overdue') NOT NULL DEFAULT 'Upcoming',
  FOREIGN KEY (`loan_id`) REFERENCES `loans`(`id`) ON DELETE CASCADE,
  INDEX `idx_loan_due` (`loan_id`, `due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 9. ATM CARDS
-- ============================================================
CREATE TABLE IF NOT EXISTS `atm_cards` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id`    INT UNSIGNED NOT NULL,
  `customer_id`   INT UNSIGNED NOT NULL,
  `card_number`   VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Last 4 digits only stored',
  `card_type`     ENUM('Visa Debit','Mastercard Debit','Prepaid') NOT NULL DEFAULT 'Visa Debit',
  `expiry_date`   DATE NOT NULL,
  `cvv_hash`      VARCHAR(255) NOT NULL,
  `pin_hash`      VARCHAR(255) NOT NULL,
  `daily_limit`   DECIMAL(12,2) NOT NULL DEFAULT 10000.00,
  `status`        ENUM('Active','Blocked','Expired','Cancelled','Pending') NOT NULL DEFAULT 'Pending',
  `issued_date`   DATE NOT NULL DEFAULT (CURDATE()),
  `blocked_at`    DATETIME,
  `blocked_reason`VARCHAR(255),
  `created_by`    INT UNSIGNED,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`account_id`)  REFERENCES `accounts`(`id`),
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`),
  INDEX `idx_account`  (`account_id`),
  INDEX `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 10. CHEQUES
-- ============================================================
CREATE TABLE IF NOT EXISTS `cheques` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `cheque_number`  VARCHAR(20)  NOT NULL UNIQUE,
  `account_id`     INT UNSIGNED NOT NULL,
  `payee_name`     VARCHAR(100) NOT NULL,
  `amount`         DECIMAL(20,2) NOT NULL,
  `cheque_date`    DATE NOT NULL,
  `memo`           VARCHAR(255),
  `status`         ENUM('Pending','Cleared','Returned','Stopped','Cancelled') NOT NULL DEFAULT 'Pending',
  `cleared_date`   DATE,
  `stop_reason`    VARCHAR(255),
  `issued_by`      INT UNSIGNED,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`),
  INDEX `idx_account` (`account_id`),
  INDEX `idx_status`  (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 11. DEPARTMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `departments` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`       VARCHAR(100) NOT NULL UNIQUE,
  `code`       VARCHAR(10)  NOT NULL UNIQUE,
  `manager_id` INT UNSIGNED NULL,
  `branch_id`  INT UNSIGNED,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 12. EMPLOYEES
-- ============================================================
CREATE TABLE IF NOT EXISTS `employees` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_number`  VARCHAR(20) NULL UNIQUE,
  `user_id`          INT UNSIGNED UNIQUE,
  `first_name`       VARCHAR(50)  NOT NULL,
  `last_name`        VARCHAR(50)  NOT NULL,
  `email`            VARCHAR(100) NOT NULL UNIQUE,
  `phone`            VARCHAR(20)  NOT NULL,
  `national_id`      VARCHAR(30)  NOT NULL UNIQUE,
  `date_of_birth`    DATE,
  `gender`           ENUM('Male','Female','Other'),
  `department_id`    INT UNSIGNED,
  `branch_id`        INT UNSIGNED NOT NULL,
  `position`         VARCHAR(100) NOT NULL,
  `employment_type`  ENUM('Permanent','Contract','Probation','Part-time') NOT NULL DEFAULT 'Permanent',
  `basic_salary`     DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `transport_allow`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `housing_allow`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `other_allowances` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `bank_account`     VARCHAR(20),
  `tin_number`       VARCHAR(30),
  `pension_number`   VARCHAR(30),
  `join_date`        DATE NOT NULL,
  `terminate_date`   DATE,
  `status`           ENUM('Active','On Leave','Suspended','Terminated') NOT NULL DEFAULT 'Active',
  `manager_id`       INT UNSIGNED,
  `photo_path`       VARCHAR(255),
  `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`)       REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`branch_id`)     REFERENCES `branches`(`id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_branch`    (`branch_id`),
  INDEX `idx_department`(`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 13. ATTENDANCE
-- ============================================================
CREATE TABLE IF NOT EXISTS `attendance` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`  INT UNSIGNED NOT NULL,
  `date`         DATE NOT NULL,
  `check_in`     TIME,
  `check_out`    TIME,
  `hours_worked` DECIMAL(4,2) GENERATED ALWAYS AS (
    CASE WHEN check_in IS NOT NULL AND check_out IS NOT NULL
         THEN TIME_TO_SEC(TIMEDIFF(check_out, check_in))/3600 ELSE 0 END
  ) STORED,
  `overtime_hrs` DECIMAL(4,2) NOT NULL DEFAULT 0.00,
  `status`       ENUM('Present','Absent','Late','Half Day','Holiday','Leave') NOT NULL DEFAULT 'Present',
  `note`         VARCHAR(255),
  `recorded_by`  INT UNSIGNED,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_emp_date` (`employee_id`, `date`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  INDEX `idx_date`   (`date`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 14. LEAVE REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `leave_requests` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`  INT UNSIGNED NOT NULL,
  `leave_type`   ENUM('Annual','Sick','Maternity','Paternity','Emergency','Unpaid','Compassionate') NOT NULL,
  `from_date`    DATE NOT NULL,
  `to_date`      DATE NOT NULL,
  `days`         TINYINT UNSIGNED GENERATED ALWAYS AS (DATEDIFF(to_date, from_date) + 1) STORED,
  `reason`       TEXT,
  `status`       ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  `approved_by`  INT UNSIGNED,
  `approved_at`  DATETIME,
  `reject_reason`VARCHAR(255),
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  INDEX `idx_employee` (`employee_id`),
  INDEX `idx_status`   (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 15. PAYROLL
-- ============================================================
CREATE TABLE IF NOT EXISTS `payroll` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`    INT UNSIGNED NOT NULL,
  `pay_period`     VARCHAR(20)  NOT NULL COMMENT 'e.g. 2025-07',
  `basic_salary`   DECIMAL(15,2) NOT NULL,
  `transport_allow`DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `housing_allow`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `other_allowances`DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `gross_salary`   DECIMAL(15,2) NOT NULL,
  `pension`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `income_tax`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `other_deductions`DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total_deductions`DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `net_salary`     DECIMAL(15,2) NOT NULL,
  `paid_date`      DATE,
  `payment_method` ENUM('Bank Transfer','Cash','Cheque') NOT NULL DEFAULT 'Bank Transfer',
  `status`         ENUM('Draft','Processed','Paid') NOT NULL DEFAULT 'Draft',
  `processed_by`   INT UNSIGNED,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_emp_period` (`employee_id`, `pay_period`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  INDEX `idx_period` (`pay_period`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 16. PERFORMANCE EVALUATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `performance_evaluations` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`   INT UNSIGNED NOT NULL,
  `period`        VARCHAR(20)  NOT NULL COMMENT 'e.g. Q3-2025',
  `kpi_score`     TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `punctuality`   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `quality`       TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `teamwork`      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `overall_score` TINYINT UNSIGNED GENERATED ALWAYS AS (
    ROUND((kpi_score + punctuality + quality + teamwork) / 4)
  ) STORED,
  `rating`        ENUM('Excellent','Good','Average','Needs Improvement','Poor') NOT NULL,
  `comments`      TEXT,
  `evaluator_id`  INT UNSIGNED,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_emp_period` (`employee_id`, `period`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 17. RECRUITMENT
-- ============================================================
CREATE TABLE IF NOT EXISTS `job_vacancies` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`        VARCHAR(100) NOT NULL,
  `department_id`INT UNSIGNED,
  `branch_id`    INT UNSIGNED,
  `description`  TEXT NOT NULL,
  `requirements` TEXT,
  `salary_range` VARCHAR(50),
  `vacancies`    TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `deadline`     DATE NOT NULL,
  `status`       ENUM('Open','Closed','On Hold') NOT NULL DEFAULT 'Open',
  `posted_by`    INT UNSIGNED,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`branch_id`)     REFERENCES `branches`(`id`)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `job_applications` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `vacancy_id`   INT UNSIGNED NOT NULL,
  `applicant_name`  VARCHAR(100) NOT NULL,
  `email`        VARCHAR(100) NOT NULL,
  `phone`        VARCHAR(20),
  `cv_path`      VARCHAR(255),
  `cover_letter` TEXT,
  `status`       ENUM('Received','Shortlisted','Interview','Selected','Rejected') NOT NULL DEFAULT 'Received',
  `interview_date`  DATETIME,
  `notes`        TEXT,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`vacancy_id`) REFERENCES `job_vacancies`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 18. TRAINING
-- ============================================================
CREATE TABLE IF NOT EXISTS `training_programs` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`        VARCHAR(200) NOT NULL,
  `category`     VARCHAR(100) NOT NULL,
  `description`  TEXT,
  `trainer`      VARCHAR(100),
  `start_date`   DATE NOT NULL,
  `end_date`     DATE NOT NULL,
  `department_id`INT UNSIGNED,
  `branch_id`    INT UNSIGNED,
  `max_capacity` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `status`       ENUM('Upcoming','Active','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming',
  `created_by`   INT UNSIGNED,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `training_attendance` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `program_id`     INT UNSIGNED NOT NULL,
  `employee_id`    INT UNSIGNED NOT NULL,
  `attended`       TINYINT(1) NOT NULL DEFAULT 0,
  `score`          TINYINT UNSIGNED,
  `certificate_issued` TINYINT(1) NOT NULL DEFAULT 0,
  `certificate_path`   VARCHAR(255),
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_program_employee` (`program_id`, `employee_id`),
  FOREIGN KEY (`program_id`)  REFERENCES `training_programs`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 19. NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT UNSIGNED,
  `type`       ENUM('transaction','loan','alert','system','employee','hr') NOT NULL,
  `title`      VARCHAR(200) NOT NULL,
  `body`       TEXT NOT NULL,
  `channel`    ENUM('In-App','Email','SMS','All') NOT NULL DEFAULT 'In-App',
  `priority`   ENUM('Normal','High','Urgent') NOT NULL DEFAULT 'Normal',
  `is_read`    TINYINT(1) NOT NULL DEFAULT 0,
  `read_at`    DATETIME,
  `sent_by`    INT UNSIGNED,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_read` (`user_id`, `is_read`),
  INDEX `idx_type`      (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 20. COMPLAINTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `complaints` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `reference`     VARCHAR(20) NULL UNIQUE,
  `customer_id`   INT UNSIGNED,
  `category`      VARCHAR(100) NOT NULL,
  `subject`       VARCHAR(200) NOT NULL,
  `description`   TEXT NOT NULL,
  `priority`      ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Medium',
  `status`        ENUM('Open','In Progress','Resolved','Closed') NOT NULL DEFAULT 'Open',
  `assigned_to`   INT UNSIGNED,
  `resolved_at`   DATETIME,
  `resolution`    TEXT,
  `created_by`    INT UNSIGNED,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL,
  INDEX `idx_status`   (`status`),
  INDEX `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 21. APPOINTMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `appointments` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `reference`      VARCHAR(20) NULL UNIQUE,
  `customer_id`    INT UNSIGNED,
  `customer_name`  VARCHAR(100),
  `service_type`   VARCHAR(100) NOT NULL,
  `appointment_date` DATE NOT NULL,
  `appointment_time` TIME NOT NULL,
  `branch_id`      INT UNSIGNED,
  `assigned_staff` INT UNSIGNED,
  `notes`          TEXT,
  `status`         ENUM('Pending','Confirmed','Completed','Cancelled','No Show') NOT NULL DEFAULT 'Pending',
  `created_by`     INT UNSIGNED,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`branch_id`)   REFERENCES `branches`(`id`) ON DELETE SET NULL,
  INDEX `idx_date`   (`appointment_date`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 22. AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id`           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED,
  `event_type`   VARCHAR(100) NOT NULL,
  `description`  TEXT NOT NULL,
  `old_values`   JSON,
  `new_values`   JSON,
  `model`        VARCHAR(100),
  `model_id`     INT UNSIGNED,
  `ip_address`   VARCHAR(45) NOT NULL DEFAULT '0.0.0.0',
  `user_agent`   VARCHAR(500),
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_user`       (`user_id`),
  INDEX `idx_event`      (`event_type`),
  INDEX `idx_date`       (`created_at`),
  INDEX `idx_model`      (`model`, `model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 23. SYSTEM SETTINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `settings` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key`        VARCHAR(100) NOT NULL UNIQUE,
  `value`      TEXT,
  `type`       ENUM('string','integer','decimal','boolean','json') NOT NULL DEFAULT 'string',
  `group`      VARCHAR(50)  NOT NULL DEFAULT 'general',
  `label`      VARCHAR(100),
  `updated_by` INT UNSIGNED,
  `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_group` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 24. BACKUPS
-- ============================================================
CREATE TABLE IF NOT EXISTS `backups` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `filename`   VARCHAR(255) NOT NULL,
  `file_size`  BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `type`       ENUM('Manual','Auto') NOT NULL DEFAULT 'Auto',
  `status`     ENUM('Completed','Failed','In Progress') NOT NULL DEFAULT 'In Progress',
  `duration_s` SMALLINT UNSIGNED,
  `path`       VARCHAR(500),
  `created_by` INT UNSIGNED,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Roles
INSERT INTO `roles` (`id`,`name`,`description`) VALUES
(1,'Admin',        'Full system access — all modules'),
(2,'Manager',      'Branch management and approvals'),
(3,'Teller',       'Process transactions and customer service'),
(4,'Loan Officer', 'Loan processing and approvals'),
(5,'Auditor',      'Read-only audit and reporting access'),
(6,'HR Officer',   'Employee management and payroll'),
(7,'Customer',     'Customer self-service portal');

-- Branches
INSERT INTO `branches` (`id`,`code`,`name`,`city`,`region`,`address`,`phone`,`cash_balance`,`status`,`opened_date`) VALUES
(1,'BR-001','Addis Ababa Main','Addis Ababa','Addis Ababa','Bole Road, Addis Ababa','+251-11-515-4545',5000000.00,'Active','2010-01-15'),
(2,'BR-002','Bole Branch',     'Addis Ababa','Addis Ababa','Bole Sub City, Woreda 03','+251-11-661-2233',3000000.00,'Active','2012-03-20'),
(3,'BR-003','Kirkos Branch',   'Addis Ababa','Addis Ababa','Kirkos Sub City, Woreda 02','+251-11-557-8899',2500000.00,'Active','2013-06-10'),
(4,'BR-004','Arada Branch',    'Addis Ababa','Addis Ababa','Arada Sub City, Woreda 07','+251-11-112-3344',2000000.00,'Active','2014-09-01'),
(5,'BR-005','Lideta Branch',   'Addis Ababa','Addis Ababa','Lideta Sub City, Woreda 01','+251-11-445-6677',1500000.00,'Active','2015-02-14'),
(6,'BR-006','Yeka Branch',     'Addis Ababa','Addis Ababa','Yeka Sub City, Woreda 05','+251-11-778-9900',1200000.00,'Active','2016-07-22'),
(7,'BR-007','Bahir Dar Branch','Bahir Dar',  'Amhara',    'Kebele 07, Bahir Dar',    '+251-58-220-1122',1000000.00,'Active','2017-04-05'),
(8,'BR-008','Hawassa Branch',  'Hawassa',   'SNNPR',     'Piazza Area, Hawassa',    '+251-46-212-3344', 800000.00,'Active','2018-08-18'),
(9,'BR-009','Dire Dawa Branch','Dire Dawa', 'Dire Dawa', 'Kezira, Dire Dawa',       '+251-25-111-5566', 700000.00,'Active','2019-01-30');

-- Departments
INSERT INTO `departments` (`id`,`name`,`code`,`branch_id`) VALUES
(1,'Finance & Accounting','FIN',1),
(2,'Operations',          'OPS',1),
(3,'Information Technology','IT',1),
(4,'Human Resources',     'HR',1),
(5,'Loans & Credit',      'LOAN',1),
(6,'Compliance & Audit',  'AUD',1),
(7,'Customer Service',    'CS',1),
(8,'Marketing',           'MKT',1);

-- Users (passwords are bcrypt of their respective passwords)
INSERT INTO `users` (`id`,`username`,`email`,`password`,`role_id`,`branch_id`,`full_name`,`phone`,`status`,`must_change_password`) VALUES
(1,'admin',   'admin@abaybank.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1,1,'Admin User',     '0911000001','Active',0),
(2,'manager', 'manager@abaybank.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',2,2,'Branch Manager',  '0911000002','Active',0),
(3,'teller',  'teller@abaybank.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',3,1,'Teller Officer',  '0911000003','Active',0),
(4,'loanofficer','loan@abaybank.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',4,1,'Loan Officer',    '0911000004','Active',0),
(5,'auditor', 'auditor@abaybank.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',5,1,'Audit Officer',   '0911000005','Active',0),
(6,'hrstaff', 'hr@abaybank.com',      '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',6,1,'HR Officer',      '0911000006','Active',0);

-- Permissions (Admin — full access)
INSERT INTO `permissions` (`role_id`,`module`,`action`) VALUES
(1,'Dashboard',   'view'),(1,'Customers','view'),(1,'Customers','create'),(1,'Customers','edit'),(1,'Customers','delete'),(1,'Customers','approve'),
(1,'Accounts',    'view'),(1,'Accounts','create'),(1,'Accounts','edit'),(1,'Accounts','delete'),(1,'Accounts','approve'),
(1,'Transactions','view'),(1,'Transactions','create'),(1,'Transactions','edit'),(1,'Transactions','approve'),
(1,'Loans',       'view'),(1,'Loans','create'),(1,'Loans','edit'),(1,'Loans','delete'),(1,'Loans','approve'),
(1,'Employees',   'view'),(1,'Employees','create'),(1,'Employees','edit'),(1,'Employees','delete'),
(1,'Payroll',     'view'),(1,'Payroll','create'),(1,'Payroll','approve'),
(1,'Reports',     'view'),(1,'Settings','view'),(1,'Settings','edit'),
(1,'Audit Log',   'view'),(1,'Roles','view'),(1,'Roles','create'),(1,'Roles','edit'),
-- Teller — limited access
(3,'Dashboard',   'view'),(3,'Customers','view'),(3,'Customers','create'),
(3,'Accounts',    'view'),(3,'Transactions','view'),(3,'Transactions','create'),
(3,'Loans',       'view'),
-- Loan Officer
(4,'Loans','view'),(4,'Loans','create'),(4,'Loans','edit'),(4,'Loans','approve'),
(4,'Customers','view'),(4,'Accounts','view'),(4,'Dashboard','view'),
-- Auditor — read only
(5,'Dashboard','view'),(5,'Customers','view'),(5,'Accounts','view'),(5,'Transactions','view'),(5,'Loans','view'),(5,'Reports','view'),(5,'Audit Log','view');

-- Sample Customers
INSERT INTO `customers` (`first_name`,`last_name`,`email`,`phone`,`national_id`,`date_of_birth`,`gender`,`city`,`region`,`branch_id`,`status`,`kyc_status`,`created_at`) VALUES
('Abebe',  'Bekele',   'abebe.bekele@email.com',  '0911234567','ET10000001','1985-03-15','Male',  'Addis Ababa','Addis Ababa',1,'Active','Verified',NOW()),
('Tigist', 'Haile',    'tigist.haile@email.com',   '0922345678','ET10000002','1990-07-22','Female','Addis Ababa','Addis Ababa',2,'Active','Verified',NOW()),
('Kebede', 'Alemu',    'kebede.alemu@email.com',   '0933456789','ET10000003','1988-11-05','Male',  'Addis Ababa','Addis Ababa',1,'Active','Pending', NOW()),
('Almaz',  'Tesfaye',  'almaz.tesfaye@email.com',  '0944567890','ET10000004','1992-04-18','Female','Bahir Dar',  'Amhara',    7,'Active','Verified',NOW()),
('Solomon','Girma',    'solomon.girma@email.com',   '0955678901','ET10000005','1983-09-30','Male',  'Hawassa',   'SNNPR',     8,'Active','Verified',NOW()),
('Meron',  'Tadesse',  'meron.tadesse@email.com',   '0966789012','ET10000006','1995-01-12','Female','Addis Ababa','Addis Ababa',3,'Active','Pending', NOW()),
('Daniel', 'Worku',    'daniel.worku@email.com',    '0977890123','ET10000007','1987-06-25','Male',  'Dire Dawa', 'Dire Dawa', 9,'Active','Verified',NOW()),
('Hanna',  'Getnet',   'hanna.getnet@email.com',    '0988901234','ET10000008','1993-08-14','Female','Addis Ababa','Addis Ababa',2,'Active','Verified',NOW()),
('Yonas',  'Bekele',   'yonas.bekele@email.com',    '0999012345','ET10000009','1989-12-03','Male',  'Addis Ababa','Addis Ababa',1,'Active','Verified',NOW()),
('Sara',   'Mekonnen', 'sara.mekonnen@email.com',   '0911123456','ET10000010','1991-05-27','Female','Addis Ababa','Addis Ababa',4,'Inactive','Expired',NOW());

-- Sample Accounts
INSERT INTO `accounts` (`customer_id`,`branch_id`,`account_number`,`account_type`,`balance`,`interest_rate`,`status`,`opened_date`) VALUES
(1,1,'10010000000001','Savings',     84500.00, 3.5,'Active','2022-01-15'),
(1,1,'20010000000001','Current',     40000.00, 0.0,'Active','2022-03-20'),
(2,2,'10020000000001','Savings',    125000.00, 3.5,'Active','2021-06-10'),
(3,1,'10010000000002','Savings',     15000.00, 3.5,'Active','2023-02-28'),
(4,7,'30070000000001','Fixed Deposit',200000.00,8.5,'Active','2023-01-01'),
(5,8,'10080000000001','Savings',     55000.00, 3.5,'Active','2022-09-15'),
(6,3,'20030000000001','Current',     28000.00, 0.0,'Active','2022-11-05'),
(7,9,'10090000000001','Savings',     42000.00, 3.5,'Active','2021-12-20'),
(8,2,'10020000000002','Savings',     95000.00, 3.5,'Active','2020-07-08'),
(9,1,'10010000000003','Savings',     67500.00, 3.5,'Active','2021-03-14');

-- Sample Transactions
INSERT INTO `transactions` (`account_id`,`reference`,`type`,`amount`,`balance_before`,`balance_after`,`description`,`status`,`created_at`) VALUES
(1,'DEP-A1B2C3D4-20250801','Deposit',   15000.00,69500.00,84500.00,'Cash Deposit',     'Completed','2025-08-01 09:15:00'),
(1,'WDR-B2C3D4E5-20250802','Withdrawal',5000.00, 84500.00,79500.00,'Cash Withdrawal',  'Completed','2025-08-02 10:30:00'),
(1,'TRF-C3D4E5F6-20250803','Transfer Out',8000.00,79500.00,71500.00,'Transfer to Tigist','Completed','2025-08-03 11:45:00'),
(3,'TRF-C3D4E5F7-20250803','Transfer In',8000.00,117000.00,125000.00,'Transfer from Abebe','Completed','2025-08-03 11:45:00'),
(1,'DEP-D4E5F6G7-20250804','Deposit',   13000.00,71500.00,84500.00,'Salary Credit',    'Completed','2025-08-04 14:00:00'),
(4,'DEP-E5F6G7H8-20250801','Deposit',    5000.00,10000.00,15000.00,'Cash Deposit',     'Completed','2025-08-01 08:30:00'),
(5,'DEP-F6G7H8I9-20250802','Deposit',   20000.00,35000.00,55000.00,'Business Income',  'Completed','2025-08-02 13:20:00'),
(2,'WDR-G7H8I9J0-20250805','Withdrawal',10000.00,50000.00,40000.00,'Utility Payment',  'Completed','2025-08-05 09:00:00'),
(8,'DEP-H8I9J0K1-20250803','Deposit',   25000.00,70000.00,95000.00,'Salary Credit',    'Completed','2025-08-03 16:45:00'),
(9,'WDR-I9J0K1L2-20250804','Withdrawal', 2500.00,70000.00,67500.00,'ATM Withdrawal',   'Completed','2025-08-04 12:10:00');

-- Sample Loans
INSERT INTO `loans` (`customer_id`,`account_id`,`branch_id`,`loan_type`,`amount`,`approved_amount`,`interest_rate`,`term_months`,`emi`,`purpose`,`outstanding`,`paid_amount`,`status`,`disbursed_date`,`next_due_date`) VALUES
(1,1,1,'Personal',  150000.00,150000.00,12.0,24,7073.50,'Business equipment purchase',      67000.00,83000.00,'Active',  '2024-08-15','2025-09-15'),
(2,3,2,'Business',  500000.00,500000.00,10.5,36,16219.00,'Expand retail operations',        380000.00,120000.00,'Active',  '2024-06-01','2025-09-01'),
(3,4,1,'Personal',   80000.00,80000.00, 14.0,18,5012.00, 'Medical expenses',                  0.00, 80000.00,'Completed','2023-07-01','2025-01-01'),
(5,6,8,'Agricultural',200000.00,180000.00,8.0,60,4058.00,'Farm machinery',                  152000.00,28000.00,'Active',  '2025-01-15','2025-09-15'),
(8,9,2,'Personal',  100000.00,100000.00,12.5,12,8885.00,'Home renovation',                   45000.00,55000.00,'Active',  '2025-02-01','2025-09-01');

-- Sample Employees
INSERT INTO `employees` (`user_id`,`first_name`,`last_name`,`email`,`phone`,`national_id`,`department_id`,`branch_id`,`position`,`employment_type`,`basic_salary`,`transport_allow`,`housing_allow`,`join_date`,`status`) VALUES
(1,'Admin',   'User',     'admin@abaybank.com',     '0911000001','ET20000001',2,1,'System Administrator','Permanent',35000.00,3500.00,5250.00,'2020-01-01','Active'),
(2,'Branch',  'Manager',  'manager@abaybank.com',   '0911000002','ET20000002',2,2,'Branch Manager',      'Permanent',28000.00,2800.00,4200.00,'2020-03-15','Active'),
(3,'Teller',  'Officer',  'teller@abaybank.com',    '0911000003','ET20000003',2,1,'Senior Teller',       'Permanent',15000.00,1500.00,2250.00,'2021-06-01','Active'),
(4,'Loan',    'Officer',  'loan@abaybank.com',      '0911000004','ET20000004',5,1,'Loan Officer',        'Permanent',20000.00,2000.00,3000.00,'2021-09-01','Active'),
(5,'Audit',   'Officer',  'auditor@abaybank.com',   '0911000005','ET20000005',6,1,'Internal Auditor',    'Permanent',22000.00,2200.00,3300.00,'2020-07-15','Active'),
(6,'HR',      'Officer',  'hr@abaybank.com',        '0911000006','ET20000006',4,1,'HR Specialist',       'Permanent',18000.00,1800.00,2700.00,'2022-02-01','Active');

-- Sample Attendance (today)
INSERT INTO `attendance` (`employee_id`,`date`,`check_in`,`check_out`,`overtime_hrs`,`status`) VALUES
(1,CURDATE(),'07:55:00','17:05:00',1.0,'Present'),
(2,CURDATE(),'08:02:00','17:00:00',0.0,'Present'),
(3,CURDATE(),'08:15:00','17:00:00',0.0,'Late'),
(4,CURDATE(),'08:00:00','17:00:00',0.0,'Present'),
(5,CURDATE(),'08:10:00','17:00:00',0.0,'Present'),
(6,CURDATE(),NULL,NULL,0.0,'Absent');

-- Sample Notifications
INSERT INTO `notifications` (`user_id`,`type`,`title`,`body`,`priority`,`is_read`) VALUES
(1,'transaction','Large Deposit Received',      'ETB 500,000 deposited to account #10010000000001','High',0),
(1,'loan',       'Loan Application Pending',    'New loan application L-00005 requires your review','Normal',0),
(1,'alert',      'Security Alert',              'Multiple failed login attempts from 192.168.1.102','Urgent',0),
(1,'system',     'Backup Completed',            'Daily backup completed successfully. Size: 4.7 GB','Normal',1),
(2,'loan',       'Loan Approved',               'Loan L-00001 has been approved and disbursed','Normal',1),
(3,'transaction','Transaction Alert',           'Cash withdrawal of ETB 5,000 processed','Normal',0);

-- System Settings
INSERT INTO `settings` (`key`,`value`,`type`,`group`,`label`) VALUES
('bank_name',         'Abay Bank S.C.',        'string',  'general',  'Bank Name'),
('bank_short_name',   'Abay Bank',             'string',  'general',  'Short Name'),
('bank_swift',        'ABYAETAA',              'string',  'general',  'SWIFT Code'),
('bank_license',      'NBE/LIC/2010/001',      'string',  'general',  'License Number'),
('base_currency',     'ETB',                   'string',  'currency', 'Base Currency'),
('savings_rate',      '3.5',                   'decimal', 'interest', 'Savings Interest Rate'),
('personal_loan_rate','12.0',                  'decimal', 'interest', 'Personal Loan Rate'),
('business_loan_rate','10.5',                  'decimal', 'interest', 'Business Loan Rate'),
('mortgage_rate',     '9.0',                   'decimal', 'interest', 'Mortgage Rate'),
('session_timeout',   '120',                   'integer', 'security', 'Session Timeout (minutes)'),
('max_failed_logins', '5',                     'integer', 'security', 'Max Failed Login Attempts'),
('lockout_duration',  '15',                    'integer', 'security', 'Lockout Duration (minutes)'),
('withdrawal_approval_threshold','100000',     'decimal', 'operations','Large Withdrawal Threshold'),
('auto_backup',       '1',                     'boolean', 'backup',   'Auto Backup Enabled'),
('backup_schedule',   'daily',                 'string',  'backup',   'Backup Schedule'),
('sms_enabled',       '1',                     'boolean', 'sms',      'SMS Alerts Enabled'),
('email_enabled',     '1',                     'boolean', 'email',    'Email Notifications Enabled'),
('maintenance_mode',  '0',                     'boolean', 'system',   'Maintenance Mode'),
('app_version',       '1.0.0',                 'string',  'system',   'Application Version');

-- Backup history sample
INSERT INTO `backups` (`filename`,`file_size`,`type`,`status`,`duration_s`,`path`,`created_at`) VALUES
('backup_20250806_020000.sql.gz',5032448,'Auto',  'Completed',127,'/storage/backups/backup_20250806_020000.sql.gz','2025-08-06 02:02:07'),
('backup_20250805_020000.sql.gz',4998144,'Auto',  'Completed',119,'/storage/backups/backup_20250805_020000.sql.gz','2025-08-05 02:01:59'),
('backup_20250804_manual.sql.gz',4912128,'Manual','Completed',143,'/storage/backups/backup_20250804_manual.sql.gz', '2025-08-04 14:23:11'),
('backup_20250803_020000.sql.gz',4875264,'Auto',  'Completed',112,'/storage/backups/backup_20250803_020000.sql.gz','2025-08-03 02:01:52');

-- Audit log samples
INSERT INTO `audit_logs` (`user_id`,`event_type`,`description`,`ip_address`,`created_at`) VALUES
(1,'Login',          'Admin logged in successfully',                         '192.168.1.10','2025-08-06 07:55:00'),
(3,'Transaction',    'Cash deposit of ETB 15,000 processed for CUST-00001', '192.168.1.11','2025-08-06 09:15:00'),
(4,'Loan Approval',  'Loan L-00001 approved — ETB 150,000',                 '192.168.1.12','2025-08-06 10:30:00'),
(1,'Customer Update','Customer CUST-00003 KYC status updated to Pending',   '192.168.1.10','2025-08-06 11:00:00'),
(5,'Report Viewed',  'Financial report generated for August 2025',          '192.168.1.13','2025-08-06 11:45:00'),
(1,'Settings Change','Interest rate updated: savings_rate = 3.5%',          '192.168.1.10','2025-08-06 14:00:00'),
(2,'Login',          'Branch Manager logged in',                            '192.168.1.14','2025-08-06 08:02:00'),
(3,'Transaction',    'Cash withdrawal of ETB 5,000 processed',              '192.168.1.11','2025-08-06 10:30:00');

-- ============================================================
-- TRIGGERS — auto-populate generated reference numbers
-- ============================================================

DELIMITER $$

CREATE TRIGGER `trg_customers_number` AFTER INSERT ON `customers`
FOR EACH ROW
BEGIN
  UPDATE `customers` SET `customer_number` = CONCAT('CUST-', LPAD(NEW.id, 5, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER `trg_loans_number` AFTER INSERT ON `loans`
FOR EACH ROW
BEGIN
  UPDATE `loans` SET `loan_number` = CONCAT('L-', LPAD(NEW.id, 5, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER `trg_employees_number` AFTER INSERT ON `employees`
FOR EACH ROW
BEGIN
  UPDATE `employees` SET `employee_number` = CONCAT('EMP-', LPAD(NEW.id, 4, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER `trg_complaints_reference` AFTER INSERT ON `complaints`
FOR EACH ROW
BEGIN
  UPDATE `complaints` SET `reference` = CONCAT('CMP-', LPAD(NEW.id, 5, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER `trg_appointments_reference` AFTER INSERT ON `appointments`
FOR EACH ROW
BEGIN
  UPDATE `appointments` SET `reference` = CONCAT('APT-', LPAD(NEW.id, 5, '0')) WHERE `id` = NEW.id;
END$$

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- END OF SCHEMA
-- ============================================================

-- ============================================================
-- EXTENDED SCHEMA — Missing tables added for full platform
-- ============================================================

-- Account Types lookup
CREATE TABLE IF NOT EXISTS `account_types` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`         VARCHAR(20) NOT NULL UNIQUE,
  `name`         VARCHAR(60) NOT NULL,
  `description`  TEXT,
  `min_balance`  DECIMAL(15,2) DEFAULT 0.00,
  `interest_rate` DECIMAL(5,2) DEFAULT 0.00,
  `is_active`    TINYINT(1) DEFAULT 1,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `account_types` (`code`,`name`,`description`,`min_balance`,`interest_rate`) VALUES
('SAV','Savings Account','Standard savings account with interest',500.00,3.50),
('CUR','Current Account','Business current account with no interest',1000.00,0.00),
('FD','Fixed Deposit','Fixed term deposit with higher interest',5000.00,8.50),
('JNTSAV','Joint Savings Account','Savings account for two holders',500.00,3.50),
('SSTUD','Student Savings','Savings account for students',100.00,3.00);

-- Transaction Types lookup
CREATE TABLE IF NOT EXISTS `transaction_types` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`        VARCHAR(30) NOT NULL UNIQUE,
  `name`        VARCHAR(60) NOT NULL,
  `direction`   ENUM('Debit','Credit','Both') DEFAULT 'Both',
  `requires_auth` TINYINT(1) DEFAULT 0,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `transaction_types` (`code`,`name`,`direction`,`requires_auth`) VALUES
('DEP','Deposit','Credit',0),('WDR','Withdrawal','Debit',0),
('TRF_OUT','Transfer Out','Debit',0),('TRF_IN','Transfer In','Credit',0),
('LOAN_DIS','Loan Disbursement','Credit',1),('LOAN_REP','Loan Repayment','Debit',0),
('INT_CREDIT','Interest Credit','Credit',0),('SVC_CHARGE','Service Charge','Debit',0),
('REVERSAL','Transaction Reversal','Both',1),('ADJ','Account Adjustment','Both',1);

-- Dedicated Transfers table (bulletproof: separate from transactions)
CREATE TABLE IF NOT EXISTS `transfers` (
  `id`                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `reference`          VARCHAR(30) NOT NULL UNIQUE,
  `transfer_type`      ENUM('Own','Internal','InterBranch','RTGS','EFT') DEFAULT 'Internal',
  `from_account_id`    INT UNSIGNED NOT NULL,
  `to_account_id`      INT UNSIGNED NOT NULL,
  `amount`             DECIMAL(15,2) NOT NULL,
  `fee`                DECIMAL(10,2) DEFAULT 0.00,
  `exchange_rate`      DECIMAL(10,6) DEFAULT 1.000000,
  `from_currency`      VARCHAR(3) DEFAULT 'ETB',
  `to_currency`        VARCHAR(3) DEFAULT 'ETB',
  `description`        VARCHAR(255),
  `debit_txn_id`       INT UNSIGNED,
  `credit_txn_id`      INT UNSIGNED,
  `initiated_by`       INT UNSIGNED,
  `authorized_by`      INT UNSIGNED,
  `status`             ENUM('Pending','Processing','Completed','Failed','Reversed') DEFAULT 'Pending',
  `failure_reason`     VARCHAR(255),
  `created_at`         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `completed_at`       TIMESTAMP NULL,
  KEY `idx_from_acct` (`from_account_id`),
  KEY `idx_to_acct`   (`to_account_id`),
  KEY `idx_status`    (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Beneficiaries
CREATE TABLE IF NOT EXISTS `beneficiaries` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL,
  `nickname`        VARCHAR(60) NOT NULL,
  `account_number`  VARCHAR(20) NOT NULL,
  `account_name`    VARCHAR(120) NOT NULL,
  `bank_name`       VARCHAR(100) DEFAULT 'Abay Bank',
  `bank_code`       VARCHAR(20),
  `account_type`    VARCHAR(30),
  `is_favorite`     TINYINT(1) DEFAULT 0,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- KYC Records
CREATE TABLE IF NOT EXISTS `kyc_records` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL UNIQUE,
  `fayda_id`        VARCHAR(20),
  `national_id`     VARCHAR(30),
  `id_type`         ENUM('Fayda','National_ID','Passport','Drivers_License','Voter_ID') DEFAULT 'National_ID',
  `id_expiry`       DATE,
  `risk_level`      ENUM('Low','Medium','High') DEFAULT 'Low',
  `kyc_status`      ENUM('Pending','Under_Review','Verified','Rejected','Expired') DEFAULT 'Pending',
  `verified_by`     INT UNSIGNED,
  `verified_at`     TIMESTAMP NULL,
  `rejection_reason` VARCHAR(255),
  `next_review_date` DATE,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`),
  KEY `idx_status`   (`kyc_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Identity Verifications (Fayda / document checks)
CREATE TABLE IF NOT EXISTS `identity_verifications` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL,
  `verification_type` ENUM('Fayda','Manual','ThirdParty') DEFAULT 'Manual',
  `reference_id`    VARCHAR(50),
  `status`          ENUM('Pending','Success','Failed','NotFound') DEFAULT 'Pending',
  `score`           DECIMAL(5,2),
  `response_data`   JSON,
  `verified_at`     TIMESTAMP NULL,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Customer Documents
CREATE TABLE IF NOT EXISTS `customer_documents` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL,
  `doc_type`        ENUM('National_ID','Passport','Photo','Utility_Bill','Bank_Statement','Business_Reg','Tax_Cert','Other') NOT NULL,
  `filename`        VARCHAR(255) NOT NULL,
  `original_name`   VARCHAR(255),
  `file_size`       INT UNSIGNED,
  `mime_type`       VARCHAR(60),
  `path`            VARCHAR(500) NOT NULL,
  `status`          ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
  `reviewed_by`     INT UNSIGNED,
  `reviewed_at`     TIMESTAMP NULL,
  `note`            VARCHAR(255),
  `uploaded_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`),
  KEY `idx_status`   (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Loan Types
CREATE TABLE IF NOT EXISTS `loan_types` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`          VARCHAR(20) NOT NULL UNIQUE,
  `name`          VARCHAR(60) NOT NULL,
  `min_amount`    DECIMAL(15,2) DEFAULT 1000.00,
  `max_amount`    DECIMAL(15,2) DEFAULT 10000000.00,
  `min_term`      INT DEFAULT 3,
  `max_term`      INT DEFAULT 120,
  `base_rate`     DECIMAL(5,2) DEFAULT 12.00,
  `requires_collateral` TINYINT(1) DEFAULT 0,
  `is_active`     TINYINT(1) DEFAULT 1,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `loan_types` (`code`,`name`,`min_amount`,`max_amount`,`min_term`,`max_term`,`base_rate`,`requires_collateral`) VALUES
('PERS','Personal Loan',5000,500000,6,60,12.00,0),
('BIZ','Business Loan',10000,5000000,6,120,10.50,1),
('MORT','Mortgage Loan',50000,10000000,12,360,9.00,1),
('AGRI','Agricultural Loan',5000,1000000,6,84,8.00,0),
('EDU','Education Loan',5000,200000,6,60,10.00,0),
('AUTO','Auto Loan',20000,1000000,12,72,11.00,1),
('EMRG','Emergency Loan',2000,50000,3,24,14.00,0);

-- Loan Approvals workflow
CREATE TABLE IF NOT EXISTS `loan_approvals` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `loan_id`       INT UNSIGNED NOT NULL,
  `step`          TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `action`        ENUM('Submitted','Under_Review','Pending_Docs','Credit_Check','Approved','Rejected','Disbursed') NOT NULL,
  `actor_id`      INT UNSIGNED,
  `note`          TEXT,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_loan` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Leave Types
CREATE TABLE IF NOT EXISTS `leave_types` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`          VARCHAR(20) NOT NULL UNIQUE,
  `name`          VARCHAR(60) NOT NULL,
  `days_per_year` INT DEFAULT 0,
  `is_paid`       TINYINT(1) DEFAULT 1,
  `is_active`     TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `leave_types` (`code`,`name`,`days_per_year`,`is_paid`) VALUES
('ANN','Annual Leave',21,1),('SICK','Sick Leave',10,1),
('MAT','Maternity Leave',90,1),('PAT','Paternity Leave',10,1),
('UNPAID','Unpaid Leave',0,0),('EMRG','Emergency Leave',5,1),
('STUDY','Study Leave',10,1);

-- Salary Components
CREATE TABLE IF NOT EXISTS `salary_components` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`          VARCHAR(20) NOT NULL UNIQUE,
  `name`          VARCHAR(60) NOT NULL,
  `type`          ENUM('Allowance','Deduction','Tax') NOT NULL,
  `calculation`   ENUM('Fixed','Percentage') DEFAULT 'Fixed',
  `value`         DECIMAL(10,2) DEFAULT 0.00,
  `is_active`     TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `salary_components` (`code`,`name`,`type`,`calculation`,`value`) VALUES
('TRANS','Transport Allowance','Allowance','Percentage',10.00),
('HOUSE','Housing Allowance','Allowance','Percentage',15.00),
('INCOME_TAX','Income Tax','Tax','Percentage',15.00),
('PENSION_EMP','Employee Pension','Deduction','Percentage',7.00),
('PENSION_ER','Employer Pension','Deduction','Percentage',11.00),
('BONUS','Performance Bonus','Allowance','Percentage',10.00);

-- Cheque Books
CREATE TABLE IF NOT EXISTS `cheque_books` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `account_id`      INT UNSIGNED NOT NULL,
  `customer_id`     INT UNSIGNED NOT NULL,
  `book_number`     VARCHAR(20) NOT NULL UNIQUE,
  `start_leaf`      INT UNSIGNED NOT NULL,
  `end_leaf`        INT UNSIGNED NOT NULL,
  `leaves_used`     INT UNSIGNED DEFAULT 0,
  `issued_date`     DATE,
  `status`          ENUM('Requested','Issued','Active','Exhausted','Blocked','Cancelled') DEFAULT 'Requested',
  `issued_by`       INT UNSIGNED,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Internal Messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `from_user_id`  INT UNSIGNED NOT NULL,
  `to_user_id`    INT UNSIGNED NOT NULL,
  `subject`       VARCHAR(200) NOT NULL,
  `body`          TEXT NOT NULL,
  `is_read`       TINYINT(1) DEFAULT 0,
  `read_at`       TIMESTAMP NULL,
  `parent_id`     INT UNSIGNED,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_to`    (`to_user_id`),
  KEY `idx_from`  (`from_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Login Attempts log
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username`      VARCHAR(100),
  `ip_address`    VARCHAR(45) NOT NULL,
  `user_agent`    VARCHAR(500),
  `status`        ENUM('Success','Failed','Locked') NOT NULL,
  `user_id`       INT UNSIGNED,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_ip`    (`ip_address`),
  KEY `idx_user`  (`username`),
  KEY `idx_at`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sessions tracking
CREATE TABLE IF NOT EXISTS `sessions` (
  `id`            VARCHAR(64) PRIMARY KEY,
  `user_id`       INT UNSIGNED NOT NULL,
  `ip_address`    VARCHAR(45),
  `user_agent`    VARCHAR(500),
  `portal`        ENUM('admin','customer','employee') DEFAULT 'admin',
  `last_activity` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expires_at`    TIMESTAMP NOT NULL,
  `is_active`     TINYINT(1) DEFAULT 1,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_user`  (`user_id`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exchange Rates
CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `from_currency` VARCHAR(3) NOT NULL,
  `to_currency`   VARCHAR(3) NOT NULL,
  `buying_rate`   DECIMAL(12,6) NOT NULL,
  `selling_rate`  DECIMAL(12,6) NOT NULL,
  `mid_rate`      DECIMAL(12,6) NOT NULL,
  `source`        VARCHAR(60) DEFAULT 'NBE',
  `effective_date` DATE NOT NULL,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_rate_date` (`from_currency`,`to_currency`,`effective_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `exchange_rates` (`from_currency`,`to_currency`,`buying_rate`,`selling_rate`,`mid_rate`,`effective_date`) VALUES
('USD','ETB',56.82,57.24,57.03,CURDATE()),
('EUR','ETB',61.45,61.94,61.70,CURDATE()),
('GBP','ETB',71.20,71.78,71.49,CURDATE()),
('AED','ETB',15.47,15.59,15.53,CURDATE()),
('SAR','ETB',15.15,15.27,15.21,CURDATE());

-- Fixed Deposits (dedicated table for FD management)
CREATE TABLE IF NOT EXISTS `fixed_deposits` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `fd_number`       VARCHAR(20) NOT NULL UNIQUE,
  `customer_id`     INT UNSIGNED NOT NULL,
  `account_id`      INT UNSIGNED NOT NULL,
  `linked_account_id` INT UNSIGNED,
  `principal`       DECIMAL(15,2) NOT NULL,
  `interest_rate`   DECIMAL(5,2) NOT NULL,
  `tenure_days`     INT NOT NULL,
  `maturity_amount` DECIMAL(15,2),
  `start_date`      DATE NOT NULL,
  `maturity_date`   DATE NOT NULL,
  `interest_payout` ENUM('Monthly','Quarterly','On_Maturity') DEFAULT 'On_Maturity',
  `auto_renew`      TINYINT(1) DEFAULT 0,
  `status`          ENUM('Active','Matured','Broken','Renewed') DEFAULT 'Active',
  `created_by`      INT UNSIGNED,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`),
  KEY `idx_account`  (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inventory / Assets
CREATE TABLE IF NOT EXISTS `inventory` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `asset_number`  VARCHAR(30) NOT NULL UNIQUE,
  `name`          VARCHAR(120) NOT NULL,
  `category`      ENUM('Computer','Furniture','Vehicle','Equipment','Software','Other') NOT NULL,
  `brand`         VARCHAR(60),
  `model`         VARCHAR(60),
  `serial_number` VARCHAR(60),
  `quantity`      INT UNSIGNED DEFAULT 1,
  `unit_cost`     DECIMAL(12,2) DEFAULT 0.00,
  `total_cost`    DECIMAL(12,2) DEFAULT 0.00,
  `location`      VARCHAR(100),
  `branch_id`     INT UNSIGNED,
  `assigned_to`   INT UNSIGNED,
  `purchase_date` DATE,
  `warranty_until` DATE,
  `condition`     ENUM('New','Good','Fair','Poor','Disposed') DEFAULT 'Good',
  `status`        ENUM('Available','In_Use','Maintenance','Disposed') DEFAULT 'Available',
  `notes`         TEXT,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_branch` (`branch_id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Customer Account Opening Applications (workflow tracking)
CREATE TABLE IF NOT EXISTS `account_applications` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `application_number` VARCHAR(20) NOT NULL UNIQUE,
  `first_name`      VARCHAR(60) NOT NULL,
  `last_name`       VARCHAR(60) NOT NULL,
  `email`           VARCHAR(120),
  `phone`           VARCHAR(20) NOT NULL,
  `date_of_birth`   DATE,
  `gender`          ENUM('Male','Female','Other'),
  `nationality`     VARCHAR(60) DEFAULT 'Ethiopian',
  `city`            VARCHAR(60),
  `sub_city`        VARCHAR(60),
  `kebele`          VARCHAR(30),
  `account_type`    VARCHAR(20) NOT NULL,
  `fayda_id`        VARCHAR(20),
  `national_id`     VARCHAR(30),
  `id_type`         VARCHAR(30) DEFAULT 'National_ID',
  `fayda_verified`  TINYINT(1) DEFAULT 0,
  `kyc_status`      ENUM('Pending','Submitted','Under_Review','Approved','Rejected') DEFAULT 'Pending',
  `current_step`    TINYINT UNSIGNED DEFAULT 1,
  `status`          ENUM('Draft','Submitted','Under_Review','Pending_Docs','Approved','Rejected') DEFAULT 'Draft',
  `reviewer_id`     INT UNSIGNED,
  `reviewed_at`     TIMESTAMP NULL,
  `rejection_reason` VARCHAR(255),
  `customer_id`     INT UNSIGNED,
  `account_id`      INT UNSIGNED,
  `ip_address`      VARCHAR(45),
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_status`  (`status`),
  KEY `idx_phone`   (`phone`),
  KEY `idx_fayda`   (`fayda_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Customer Portal Credentials (separate from staff users)
CREATE TABLE IF NOT EXISTS `customer_users` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL UNIQUE,
  `username`        VARCHAR(60) NOT NULL UNIQUE,
  `email`           VARCHAR(120) NOT NULL UNIQUE,
  `password`        VARCHAR(255) NOT NULL,
  `pin`             VARCHAR(255),
  `is_active`       TINYINT(1) DEFAULT 1,
  `is_locked`       TINYINT(1) DEFAULT 0,
  `failed_attempts` TINYINT UNSIGNED DEFAULT 0,
  `locked_until`    TIMESTAMP NULL,
  `last_login_at`   TIMESTAMP NULL,
  `last_login_ip`   VARCHAR(45),
  `two_fa_enabled`  TINYINT(1) DEFAULT 0,
  `two_fa_secret`   VARCHAR(60),
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- E-Receipts
CREATE TABLE IF NOT EXISTS `receipts` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `receipt_number`  VARCHAR(30) NOT NULL UNIQUE,
  `transaction_id`  INT UNSIGNED NOT NULL,
  `customer_id`     INT UNSIGNED,
  `account_id`      INT UNSIGNED,
  `amount`          DECIMAL(15,2) NOT NULL,
  `type`            VARCHAR(30),
  `generated_by`    INT UNSIGNED,
  `pdf_path`        VARCHAR(500),
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_txn`     (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Announcements (broadcast messages to customers/staff)
CREATE TABLE IF NOT EXISTS `announcements` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`         VARCHAR(200) NOT NULL,
  `body`          TEXT NOT NULL,
  `audience`      ENUM('All','Customers','Staff','Branch') DEFAULT 'All',
  `branch_id`     INT UNSIGNED,
  `priority`      ENUM('Normal','High','Urgent') DEFAULT 'Normal',
  `is_published`  TINYINT(1) DEFAULT 0,
  `published_at`  TIMESTAMP NULL,
  `expires_at`    TIMESTAMP NULL,
  `created_by`    INT UNSIGNED,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `announcements` (`title`,`body`,`audience`,`priority`,`is_published`,`published_at`,`created_by`) VALUES
('System Maintenance Notice','The banking system will undergo scheduled maintenance on Sunday August 11, 2026 from 2:00 AM to 4:00 AM EAT. Online banking services may be temporarily unavailable.','All','High',1,NOW(),1),
('New Mobile Banking App','We are pleased to announce the launch of our new Abay Bank Mobile App with biometric login. Download now from Google Play and Apple App Store.','Customers','Normal',1,NOW(),1);

-- KYC Applications insert sample data
INSERT INTO `kyc_records` (`customer_id`,`fayda_id`,`national_id`,`id_type`,`kyc_status`,`risk_level`) VALUES
(1,'FYD-0001-2025','ET10000001','Fayda','Verified','Low'),
(2,'FYD-0002-2025','ET10000002','Fayda','Verified','Low'),
(3,NULL,'ET10000003','National_ID','Pending','Medium'),
(4,'FYD-0004-2025','ET10000004','Fayda','Verified','Low'),
(5,'FYD-0005-2025','ET10000005','Fayda','Verified','Low'),
(6,NULL,'ET10000006','National_ID','Pending','Medium'),
(7,NULL,'ET10000007','National_ID','Verified','Low'),
(8,'FYD-0008-2025','ET10000008','Fayda','Verified','Low'),
(9,'FYD-0009-2025','ET10000009','Fayda','Verified','Low');

-- Seed customer portal credentials (password = Customer@1234 bcrypt)
INSERT INTO `customer_users` (`customer_id`,`username`,`email`,`password`) VALUES
(1,'abebe.bekele','abebe.bekele@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMVAFb9Mx8VlGRp1kG9sYdZXKy'),
(2,'tigist.haile','tigist.haile@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMVAFb9Mx8VlGRp1kG9sYdZXKy'),
(5,'solomon.girma','solomon.girma@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMVAFb9Mx8VlGRp1kG9sYdZXKy');

-- Auto-number trigger for applications
DELIMITER $$
CREATE TRIGGER IF NOT EXISTS `trg_application_number` AFTER INSERT ON `account_applications`
FOR EACH ROW
BEGIN
  UPDATE `account_applications` SET `application_number` = CONCAT('APP-', LPAD(NEW.id, 6, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER IF NOT EXISTS `trg_fd_number` AFTER INSERT ON `fixed_deposits`
FOR EACH ROW
BEGIN
  UPDATE `fixed_deposits` SET `fd_number` = CONCAT('FD-', LPAD(NEW.id, 6, '0')) WHERE `id` = NEW.id;
END$$

CREATE TRIGGER IF NOT EXISTS `trg_receipt_number` AFTER INSERT ON `receipts`
FOR EACH ROW
BEGIN
  UPDATE `receipts` SET `receipt_number` = CONCAT('RCP-', LPAD(NEW.id, 7, '0')) WHERE `id` = NEW.id;
END$$
DELIMITER ;


-- ============================================================
-- NEW FEATURES — ONLINE BANKING, ATM BIOMETRIC, INTER-BANK
-- ============================================================

-- Add Alem Ketema Branch
INSERT IGNORE INTO `branches` (`id`,`code`,`name`,`city`,`region`,`address`,`phone`,`cash_balance`,`status`,`opened_date`) VALUES
(10,'BR-010','Alem Ketema Branch','Alem Ketema','Amhara','Main Road, Alem Ketema, North Shewa Zone','+251-11-234-5678',600000.00,'Active','2024-03-10');

-- ============================================================
-- 25. ONLINE ACCOUNT APPLICATIONS (Fayda / National ID)
-- ============================================================
CREATE TABLE IF NOT EXISTS `online_applications` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `ref_number`       VARCHAR(30)  NOT NULL UNIQUE,
  `first_name`       VARCHAR(50)  NOT NULL,
  `last_name`        VARCHAR(50)  NOT NULL,
  `email`            VARCHAR(100) NOT NULL,
  `phone`            VARCHAR(20)  NOT NULL,
  `national_id`      VARCHAR(30)  NOT NULL,
  `fayda_id`         VARCHAR(40)  NOT NULL COMMENT 'Ethiopian Fayda National ID number',
  `date_of_birth`    DATE         NOT NULL,
  `gender`           ENUM('Male','Female','Other') NOT NULL,
  `address`          TEXT,
  `city`             VARCHAR(100),
  `region`           VARCHAR(100),
  `subcity`          VARCHAR(100),
  `kebele`           VARCHAR(50),
  `occupation`       VARCHAR(100),
  `monthly_income`   DECIMAL(15,2),
  `account_type`     ENUM('Savings','Current','Fixed Deposit') NOT NULL DEFAULT 'Savings',
  `preferred_branch` INT UNSIGNED,
  `initial_deposit`  DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `selfie_path`      VARCHAR(255) COMMENT 'Uploaded selfie photo',
  `id_front_path`    VARCHAR(255) COMMENT 'National ID front photo',
  `id_back_path`     VARCHAR(255) COMMENT 'National ID back photo',
  `fayda_verified`   TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Whether Fayda verification passed',
  `fayda_verified_at`DATETIME,
  `fayda_response`   JSON         COMMENT 'Raw Fayda API response data',
  `status`           ENUM('Pending','Under Review','Approved','Rejected','Completed') NOT NULL DEFAULT 'Pending',
  `reviewed_by`      INT UNSIGNED,
  `reviewed_at`      DATETIME,
  `reject_reason`    TEXT,
  `customer_id`      INT UNSIGNED COMMENT 'Set after account is created',
  `account_id`       INT UNSIGNED COMMENT 'Set after account is created',
  `ip_address`       VARCHAR(45),
  `user_agent`       VARCHAR(500),
  `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`preferred_branch`) REFERENCES `branches`(`id`) ON DELETE SET NULL,
  INDEX `idx_status`     (`status`),
  INDEX `idx_fayda`      (`fayda_id`),
  INDEX `idx_national_id`(`national_id`),
  INDEX `idx_email`      (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 26. FAYDA VERIFICATION LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `fayda_verifications` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT UNSIGNED,
  `customer_id`    INT UNSIGNED,
  `fayda_id`       VARCHAR(40)  NOT NULL,
  `national_id`    VARCHAR(30)  NOT NULL,
  `full_name`      VARCHAR(100),
  `dob`            DATE,
  `face_match_score` DECIMAL(5,2) COMMENT 'Face match score 0-100',
  `id_match_score`   DECIMAL(5,2) COMMENT 'ID data match score 0-100',
  `result`         ENUM('Verified','Failed','Partial','Pending') NOT NULL DEFAULT 'Pending',
  `failure_reason` VARCHAR(255),
  `raw_response`   JSON,
  `ip_address`     VARCHAR(45),
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`application_id`) REFERENCES `online_applications`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`customer_id`)    REFERENCES `customers`(`id`) ON DELETE SET NULL,
  INDEX `idx_fayda_id`  (`fayda_id`),
  INDEX `idx_result`    (`result`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 27. BIOMETRIC REGISTRATION (Fingerprint / Iris)
-- ============================================================
CREATE TABLE IF NOT EXISTS `biometric_records` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`     INT UNSIGNED NOT NULL,
  `account_id`      INT UNSIGNED NOT NULL,
  `biometric_type`  ENUM('Fingerprint','Iris','Face') NOT NULL,
  `template_hash`   VARCHAR(255) NOT NULL COMMENT 'Hashed biometric template (never store raw)',
  `device_id`       VARCHAR(100) COMMENT 'ATM/device that enrolled the biometric',
  `quality_score`   TINYINT UNSIGNED NOT NULL DEFAULT 80 COMMENT '0-100 quality score',
  `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
  `enrolled_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at`    DATETIME,
  `fail_count`      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`    DATETIME COMMENT 'Biometric locked after too many failures',
  `created_by`      INT UNSIGNED,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`account_id`)  REFERENCES `accounts`(`id`)  ON DELETE CASCADE,
  UNIQUE KEY `uq_customer_bio_type` (`customer_id`, `biometric_type`),
  INDEX `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 28. ATM SESSIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `atm_sessions` (
  `id`              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `session_token`   VARCHAR(64)  NOT NULL UNIQUE,
  `atm_id`          VARCHAR(50)  NOT NULL COMMENT 'ATM machine identifier',
  `atm_location`    VARCHAR(200) COMMENT 'ATM physical location',
  `customer_id`     INT UNSIGNED,
  `account_id`      INT UNSIGNED,
  `auth_method`     ENUM('PIN','Fingerprint','Iris','Username+Account') NOT NULL DEFAULT 'PIN',
  `username`        VARCHAR(50)  COMMENT 'Used when auth_method = Username+Account',
  `account_number`  VARCHAR(20)  COMMENT 'Used when auth_method = Username+Account',
  `status`          ENUM('Active','Completed','Timed Out','Blocked') NOT NULL DEFAULT 'Active',
  `fail_attempts`   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `started_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at`        DATETIME,
  `ip_address`      VARCHAR(45),
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`account_id`)  REFERENCES `accounts`(`id`)  ON DELETE SET NULL,
  INDEX `idx_token`     (`session_token`),
  INDEX `idx_customer`  (`customer_id`),
  INDEX `idx_started`   (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 29. ATM TRANSACTIONS (channel already on transactions table,
--     this stores extra ATM-specific metadata)
-- ============================================================
CREATE TABLE IF NOT EXISTS `atm_transaction_meta` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `transaction_id`  BIGINT UNSIGNED NOT NULL,
  `atm_session_id`  BIGINT UNSIGNED NOT NULL,
  `atm_id`          VARCHAR(50) NOT NULL,
  `atm_location`    VARCHAR(200),
  `auth_method`     ENUM('PIN','Fingerprint','Iris','Username+Account') NOT NULL,
  `notes`           VARCHAR(255),
  `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`atm_session_id`) REFERENCES `atm_sessions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 30. INTER-BANK TRANSFERS (EthSwitch / CBE / Dashen / etc.)
-- ============================================================
CREATE TABLE IF NOT EXISTS `interbank_transfers` (
  `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `reference`           VARCHAR(50) NOT NULL UNIQUE,
  `source_account_id`   INT UNSIGNED NOT NULL,
  `source_customer_id`  INT UNSIGNED NOT NULL,
  `dest_bank_code`      VARCHAR(20) NOT NULL  COMMENT 'e.g. CBE, DBE, DASHEN, AWASH, ABYSSINIA',
  `dest_bank_name`      VARCHAR(100) NOT NULL,
  `dest_account_number` VARCHAR(30) NOT NULL,
  `dest_account_name`   VARCHAR(100),
  `amount`              DECIMAL(20,2) NOT NULL,
  `fee`                 DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `net_amount`          DECIMAL(20,2) NOT NULL COMMENT 'amount - fee deducted',
  `currency`            VARCHAR(3) NOT NULL DEFAULT 'ETB',
  `purpose`             VARCHAR(255),
  `channel`             ENUM('Online','Counter','ATM','Mobile') NOT NULL DEFAULT 'Online',
  `status`              ENUM('Pending','Processing','Completed','Failed','Reversed') NOT NULL DEFAULT 'Pending',
  `ethswitch_ref`       VARCHAR(60) COMMENT 'EthSwitch transaction reference',
  `response_code`       VARCHAR(10),
  `response_message`    VARCHAR(255),
  `processed_at`        DATETIME,
  `initiated_by`        INT UNSIGNED COMMENT 'user_id or customer_id',
  `approved_by`         INT UNSIGNED,
  `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`source_account_id`)  REFERENCES `accounts`(`id`),
  FOREIGN KEY (`source_customer_id`) REFERENCES `customers`(`id`),
  INDEX `idx_source`    (`source_account_id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_dest_bank` (`dest_bank_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 31. CUSTOMER PORTAL USERS (online banking login credentials)
-- ============================================================
CREATE TABLE IF NOT EXISTS `customer_users` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`    INT UNSIGNED NOT NULL UNIQUE,
  `username`       VARCHAR(50)  NOT NULL UNIQUE,
  `email`          VARCHAR(100) NOT NULL UNIQUE,
  `password`       VARCHAR(255) NOT NULL,
  `pin_hash`       VARCHAR(255) COMMENT '4-6 digit PIN for mobile/ATM',
  `status`         ENUM('Active','Locked','Suspended') NOT NULL DEFAULT 'Active',
  `failed_attempts`TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`   DATETIME,
  `last_login_at`  DATETIME,
  `otp_secret`     VARCHAR(64)  COMMENT 'TOTP secret for 2FA',
  `two_fa_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  INDEX `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 32. BENEFICIARIES (saved inter-bank transfer destinations)
-- ============================================================
CREATE TABLE IF NOT EXISTS `beneficiaries` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id`    INT UNSIGNED NOT NULL,
  `nickname`       VARCHAR(100) NOT NULL,
  `bank_code`      VARCHAR(20)  NOT NULL,
  `bank_name`      VARCHAR(100) NOT NULL,
  `account_number` VARCHAR(30)  NOT NULL,
  `account_name`   VARCHAR(100),
  `is_active`      TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  INDEX `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed customer_users for sample customers (password = Customer@1234)
INSERT IGNORE INTO `customer_users` (`customer_id`,`username`,`email`,`password`,`is_active`) VALUES
(1,'abebe.bekele',  'abebe.bekele@email.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1),
(2,'tigist.haile',  'tigist.haile@email.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1),
(5,'solomon.girma', 'solomon.girma@email.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1),
(7,'daniel.worku',  'daniel.worku@email.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1),
(8,'hanna.getnet',  'hanna.getnet@email.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1);
