# Abay Bank — Employee Self-Service Portal

A complete standalone PHP portal for Abay Bank employees.

## Access URL
```
http://localhost/abay-bank-management-system/employee-portal/
```

## Demo Credentials

| Username | Password | Role |
|---|---|---|
| `abebe.girma` | `Employee@1234` | Senior Teller |
| `tigist.haile` | `Employee@1234` | Loan Officer |
| `samuel.bekele` | `Employee@1234` | IT Staff |
| `meron.tesfaye` | `Employee@1234` | Customer Service |

> **Demo mode**: Works without a database. All actions show realistic responses.  
> **Live mode**: Connects to the shared `abay_bank` MySQL database automatically.

## Setup (with database)

1. Import the main system schema first
2. Run the employee portal schema:
   ```sql
   SOURCE /path/to/employee-portal/database/schema.sql;
   SOURCE /path/to/employee-portal/database/seed.sql;
   ```
3. The `.env` file from the parent project is used for DB credentials

## Features

| Section | Pages |
|---|---|
| **Auth** | Sign In, Sign Up, Forgot Password |
| **Dashboard** | Stats, Quick Actions, Attendance Chart, Tasks, Activity Feed |
| **Profile** | View, Edit, Photo Upload, Change Password |
| **Attendance** | Check In/Out, History, Monthly Calendar |
| **Leave** | Balance, Request, History, Cancel |
| **Payroll** | Payslip List, Payslip Detail (printable) |
| **Performance** | KPI Radar, Goals, Rating |
| **Training** | Available Programs, Enroll, Certificates |
| **Tasks** | Assigned Tasks, Start/Submit, Priority View |
| **Customers** | Search, View, Register |
| **Accounts** | List, Open Account |
| **Transactions** | Deposit, Withdrawal, Transfer, History |
| **Loans** | List, View, Applications |
| **KYC** | Pending Queue, Review, Verify/Reject |
| **Complaints** | List, View, Respond |
| **Appointments** | Today, Upcoming, Check-in |
| **Messages** | Inbox, Compose |
| **Notifications** | List, Mark Read |
| **Reports** | Dashboard, Daily Report |
| **Branch** | Info, Staff List |
| **Documents** | My Docs, Upload |
| **Settings** | Notifications, Display Preferences |

## Structure

```
employee-portal/
├── index.php              ← Root entry (redirect)
├── auth/                  ← login, logout, forgot-password
├── config/                ← database, constants, config
├── middleware/            ← auth, csrf, role-check, session-check
├── includes/              ← header, footer, sidebar, alerts, functions, pagination
├── employee/              ← All portal pages
│   ├── dashboard.php
│   ├── profile/
│   ├── attendance/
│   ├── leave/
│   ├── payroll/
│   ├── performance/
│   ├── training/
│   ├── tasks/
│   ├── customers/
│   ├── accounts/
│   ├── transactions/
│   ├── loans/
│   ├── kyc/
│   ├── complaints/
│   ├── appointments/
│   ├── messages/
│   ├── notifications/
│   ├── reports/
│   ├── branch/
│   ├── documents/
│   └── settings/
├── controllers/           ← AuthController, EmployeeController, etc.
├── models/                ← Employee, Attendance, Leave, Payroll, Task, Notification
├── api/                   ← JSON endpoints (attendance, accounts, customers)
├── assets/css/            ← style.css, sidebar.css, dashboard.css
├── assets/js/             ← app.js, dashboard.js, attendance.js, charts.js
├── uploads/               ← employee-profiles/, employee-documents/
└── database/              ← schema.sql, seed.sql
```

## Security
- Session-based authentication with timeout (2 hours)
- CSRF protection on all POST forms
- Password hashing with PHP `password_hash()` (bcrypt)
- File uploads: MIME validation, size limits, PHP execution blocked in uploads/
- Input sanitization with `htmlspecialchars()` / `ep_e()`
- Sensitive directories blocked via `.htaccess`
