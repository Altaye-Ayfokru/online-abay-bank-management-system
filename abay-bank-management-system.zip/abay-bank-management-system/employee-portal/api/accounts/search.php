<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
header('Content-Type: application/json');
$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'message'=>'Not authenticated']); exit; }
$accNo = trim($_GET['account_number'] ?? '');
if (!$accNo) { echo json_encode(['success'=>false,'message'=>'Account number required']); exit; }
$acc = EP_Database::queryOne(
    "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
     FROM accounts a JOIN customers c ON c.id=a.customer_id
     WHERE a.account_number=? AND a.status='Active' LIMIT 1", [$accNo]
);
if (!$acc) {
    // Demo fallback
    echo json_encode(['success'=>true,'data'=>['account_number'=>$accNo,'customer_name'=>'Demo Customer','balance'=>84500,'account_type'=>'Savings','status'=>'Active']]);
    exit;
}
echo json_encode(['success'=>true,'data'=>$acc]);
