<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/controllers/EmployeeController.php';
require_once dirname(__DIR__, 2) . '/controllers/AttendanceController.php';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'message'=>'POST only']); exit; }

$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'message'=>'Not authenticated']); exit; }

$result = AttendanceController::checkIn((int)$emp['id']);
echo json_encode($result);
