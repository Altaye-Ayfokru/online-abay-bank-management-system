<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
header('Content-Type: application/json');
$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'message'=>'Not authenticated']); exit; }
$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) { echo json_encode(['success'=>true,'data'=>[]]); exit; }
$s = "%$q%";
$results = EP_Database::query(
    "SELECT id, customer_number, first_name, last_name, phone, kyc_status
     FROM customers WHERE first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR customer_number LIKE ? LIMIT 10",
    [$s,$s,$s,$s]
) ?: [];
echo json_encode(['success'=>true,'data'=>$results]);
