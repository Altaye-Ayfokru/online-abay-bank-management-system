<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/controllers/EmployeeController.php';
header('Content-Type: application/json');
$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'message'=>'Not authenticated']); exit; }
$stats = EmployeeController::getDashboardStats((int)$emp['id']);
echo json_encode(['success'=>true,'data'=>$stats]);
