<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
header('Content-Type: application/json');
$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'count'=>0]); exit; }
$count = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [(int)$emp['id']])['c'] ?? 0);
echo json_encode(['success'=>true,'count'=>$count]);
