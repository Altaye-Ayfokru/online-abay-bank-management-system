/* ============================================================
   ABAY BANK — Employee Portal Core JS
   ============================================================ */
'use strict';

const EP = {
  baseUrl: document.querySelector('meta[name="ep-base-url"]')?.content || '/employee-portal',

  /* ── Toast notifications ── */
  toast(msg, type = 'info', duration = 3500) {
    const colors = { success: '#22c55e', danger: '#ef4444', warning: '#f59e0b', info: '#3b82f6' };
    const icons  = { success: 'fa-circle-check', danger: 'fa-circle-xmark', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' };
    let container = document.getElementById('ep-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'ep-toast-container';
      container.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
      document.body.appendChild(container);
    }
    const t = document.createElement('div');
    t.style.cssText = `background:#fff;border-left:4px solid ${colors[type]};border-radius:10px;padding:13px 16px;box-shadow:0 8px 32px rgba(0,0,0,.14);min-width:260px;max-width:360px;display:flex;align-items:center;gap:10px;font-size:.85rem;font-weight:500;pointer-events:all;transform:translateX(120%);transition:transform .3s;`;
    t.innerHTML = `<i class="fa-solid ${icons[type]}" style="color:${colors[type]};font-size:1rem;flex-shrink:0"></i><span>${msg}</span>`;
    container.appendChild(t);
    requestAnimationFrame(() => { t.style.transform = 'translateX(0)'; });
    setTimeout(() => { t.style.transform = 'translateX(120%)'; setTimeout(() => t.remove(), 350); }, duration);
  },

  /* ── Loading button ── */
  setBtn(idOrEl, loading, label = '') {
    const btn = typeof idOrEl === 'string' ? document.getElementById(idOrEl) : idOrEl;
    if (!btn) return;
    if (loading) {
      btn._origHtml = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner" style="animation:ep-spin 1s linear infinite"></i> ' + (label || 'Loading…');
    } else {
      btn.disabled = false;
      btn.innerHTML = label || btn._origHtml || 'Submit';
    }
  },

  /* ── Confirm dialog ── */
  confirm(msg, onOk, opts = {}) {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9998;display:flex;align-items:center;justify-content:center;padding:20px;';
    overlay.innerHTML = `
      <div style="background:#fff;border-radius:16px;padding:28px 28px 20px;max-width:420px;width:100%;box-shadow:0 24px 64px rgba(0,0,0,.2)">
        <div style="font-size:1rem;font-weight:700;color:#1e293b;margin-bottom:10px">${opts.title || 'Confirm'}</div>
        <p style="font-size:.87rem;color:#64748b;margin-bottom:20px">${msg}</p>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button id="ep-cf-cancel" style="padding:9px 20px;border-radius:9px;border:2px solid #e2e8f0;background:none;cursor:pointer;font-size:.86rem;font-weight:600">Cancel</button>
          <button id="ep-cf-ok" style="padding:9px 20px;border-radius:9px;border:none;background:${opts.danger ? '#ef4444' : '#1B3A5C'};color:#fff;cursor:pointer;font-size:.86rem;font-weight:700">${opts.okLabel || 'Confirm'}</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#ep-cf-cancel').onclick = () => overlay.remove();
    overlay.querySelector('#ep-cf-ok').onclick = () => { overlay.remove(); onOk(); };
    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };
  },

  /* ── Modal ── */
  openModal(id) { document.getElementById(id)?.classList.add('ep-modal-open'); },
  closeModal(id) { document.getElementById(id)?.classList.remove('ep-modal-open'); },

  /* ── API helper ── */
  async api(endpoint, opts = {}) {
    const defaults = {
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    };
    try {
      const r = await fetch(this.baseUrl + '/api' + endpoint, { ...defaults, ...opts, headers: { ...defaults.headers, ...(opts.headers || {}) } });
      return await r.json();
    } catch { return null; }
  },

  /* ── Init ── */
  init() {
    this.initSidebar();
    this.initModals();
    this.initSearch();
    this.highlightActiveNav();
  },

  initSidebar() {
    const sidebar  = document.getElementById('ep-sidebar');
    const backdrop = document.getElementById('ep-sb-backdrop');
    const hamburger= document.getElementById('ep-hamburger');

    hamburger?.addEventListener('click', () => {
      sidebar?.classList.toggle('open');
      backdrop?.classList.toggle('show');
    });
    backdrop?.addEventListener('click', () => {
      sidebar?.classList.remove('open');
      backdrop?.classList.remove('show');
    });
  },

  initModals() {
    document.querySelectorAll('.ep-modal-overlay').forEach(ov => {
      ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('ep-modal-open'); });
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') document.querySelectorAll('.ep-modal-overlay.ep-modal-open').forEach(m => m.classList.remove('ep-modal-open'));
    });
  },

  initSearch() {
    const input = document.getElementById('ep-global-search');
    input?.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        const q = input.value.trim();
        if (q) window.location.href = EP.baseUrl + '/employee/customers/search.php?q=' + encodeURIComponent(q);
      }
    });
  },

  highlightActiveNav() {
    const path = window.location.pathname;
    document.querySelectorAll('.ep-sb-link').forEach(link => {
      const href = link.getAttribute('href');
      if (href && path.includes(href.replace(/^.*employee-portal/, ''))) {
        link.classList.add('active');
      }
    });
  }
};

// Spinner keyframe
const epStyle = document.createElement('style');
epStyle.textContent = '@keyframes ep-spin{to{transform:rotate(360deg);}} .ep-modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px;} .ep-modal-overlay.ep-modal-open{display:flex;} .ep-modal{background:#fff;border-radius:16px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,.2);} .ep-modal-hdr{display:flex;justify-content:space-between;align-items:center;padding:18px 20px;border-bottom:1px solid #e2e8f0;} .ep-modal-hdr h3{font-size:.95rem;font-weight:700;color:#1B3A5C;} .ep-modal-close{background:none;border:none;cursor:pointer;color:#94a3b8;font-size:1.1rem;} .ep-modal-body{padding:20px;} .ep-modal-footer{padding:14px 20px;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;gap:10px;}';
document.head.appendChild(epStyle);

document.addEventListener('DOMContentLoaded', () => EP.init());
