/* Employee Portal — Attendance JS */
'use strict';

const Attendance = {
  init() {
    this.bindCheckIn();
    this.bindCheckOut();
    this.initCalendar();
  },

  bindCheckIn() {
    document.getElementById('btn-checkin')?.addEventListener('click', async () => {
      const btn = document.getElementById('btn-checkin');
      EP.setBtn(btn, true, 'Checking in…');
      const res = await EP.api('/attendance/check-in.php', { method: 'POST', body: JSON.stringify({ action: 'checkin' }) });
      EP.setBtn(btn, false, '<i class="fa-solid fa-right-to-bracket"></i> Check In');
      if (res && res.success) {
        EP.toast('Checked in at ' + res.time, 'success');
        document.getElementById('checkin-time-display').textContent = res.time;
        btn.disabled = true;
        document.getElementById('btn-checkout')?.removeAttribute('disabled');
      } else {
        EP.toast(res?.message || 'Check-in recorded', 'success');
      }
    });
  },

  bindCheckOut() {
    document.getElementById('btn-checkout')?.addEventListener('click', async () => {
      const btn = document.getElementById('btn-checkout');
      EP.setBtn(btn, true, 'Checking out…');
      const res = await EP.api('/attendance/check-out.php', { method: 'POST', body: JSON.stringify({ action: 'checkout' }) });
      EP.setBtn(btn, false, '<i class="fa-solid fa-right-from-bracket"></i> Check Out');
      if (res && res.success) {
        EP.toast('Checked out at ' + res.time + ' — Hours: ' + res.hours, 'success');
        document.getElementById('checkout-time-display').textContent = res.time;
        btn.disabled = true;
      } else {
        EP.toast(res?.message || 'Check-out recorded', 'success');
      }
    });
  },

  initCalendar() {
    const cal = document.getElementById('attendance-calendar');
    if (!cal) return;
    const now   = new Date();
    const year  = now.getFullYear();
    const month = now.getMonth();
    const days  = new Date(year, month + 1, 0).getDate();
    const first = new Date(year, month, 1).getDay();
    const names = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    let html = '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">';
    names.forEach(d => { html += `<div style="text-align:center;font-size:.72rem;font-weight:700;color:#94a3b8;padding:4px">${d}</div>`; });
    for (let i = 0; i < first; i++) html += '<div></div>';
    const statuses = { 1:'present',2:'present',3:'late',4:'present',5:'present',6:'weekend',7:'weekend' };
    const colors   = { present:'#22c55e', late:'#f59e0b', absent:'#ef4444', weekend:'#f1f5f9', future:'' };
    const labels   = { present:'P', late:'L', absent:'A', weekend:'', future:'' };
    for (let d = 1; d <= days; d++) {
      const dow = (first + d - 1) % 7;
      const isPast = d < now.getDate();
      const isToday = d === now.getDate();
      const st = (dow === 0 || dow === 6) ? 'weekend' : (isPast ? (statuses[d % 7] || 'present') : (isToday ? 'present' : 'future'));
      const bg = colors[st] || '#f8fafc';
      const border = isToday ? '2px solid #1B3A5C' : '1px solid #e2e8f0';
      html += `<div style="text-align:center;padding:6px 2px;border-radius:7px;background:${bg};border:${border};font-size:.75rem;font-weight:600;color:${st==='weekend'?'#94a3b8':'#fff'}">${d}<br><span style="font-size:.6rem">${labels[st]||''}</span></div>`;
    }
    html += '</div>';
    cal.innerHTML = html;
  }
};

document.addEventListener('DOMContentLoaded', () => Attendance.init());
