/* Employee Portal — Charts JS */
'use strict';

const EPCharts = {
  attendance(ctxId, labels, data) {
    const ctx = document.getElementById(ctxId);
    if (!ctx || !window.Chart) return;
    return new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets: [{ label: 'Days Present', data, backgroundColor: '#007A8A', borderRadius: 5 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 23 } } }
    });
  },

  doughnut(ctxId, labels, data, colors) {
    const ctx = document.getElementById(ctxId);
    if (!ctx || !window.Chart) return;
    return new Chart(ctx, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: colors || ['#22c55e','#f59e0b','#ef4444','#3b82f6'] }] },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  },

  line(ctxId, labels, datasets) {
    const ctx = document.getElementById(ctxId);
    if (!ctx || !window.Chart) return;
    return new Chart(ctx, {
      type: 'line',
      data: { labels, datasets: datasets.map((d,i) => ({
        ...d,
        borderColor: ['#007A8A','#C8A84B','#22c55e','#3b82f6'][i % 4],
        backgroundColor: ['rgba(0,122,138,.1)','rgba(200,168,75,.1)','rgba(34,197,94,.1)','rgba(59,130,246,.1)'][i % 4],
        fill: true, tension: 0.4, pointRadius: 4
      })) },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true } } }
    });
  },

  radar(ctxId, labels, data) {
    const ctx = document.getElementById(ctxId);
    if (!ctx || !window.Chart) return;
    return new Chart(ctx, {
      type: 'radar',
      data: { labels, datasets: [{ label: 'Score', data, borderColor: '#007A8A', backgroundColor: 'rgba(0,122,138,.15)', pointBackgroundColor: '#007A8A', pointRadius: 4 }] },
      options: { responsive: true, scales: { r: { min: 0, max: 100, ticks: { stepSize: 25 } } }, plugins: { legend: { display: false } } }
    });
  }
};
