/* ============================================================
   ABAY BANK — Employee Portal Dashboard JS
   ============================================================ */
'use strict';

// Live clock
function updateClock() {
  const el = document.getElementById('ep-clock');
  if (el) el.textContent = new Date().toLocaleTimeString('en-ET', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

// Attendance chart
function initAttendanceChart(ctx, labels, present, late, absent) {
  if (!ctx || !window.Chart) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Present', data: present, backgroundColor: '#22c55e', borderRadius: 4 },
        { label: 'Late',    data: late,    backgroundColor: '#f59e0b', borderRadius: 4 },
        { label: 'Absent',  data: absent,  backgroundColor: '#ef4444', borderRadius: 4 },
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } },
      scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, max: 1 } }
    }
  });
}

// KPI radar chart
function initKpiChart(ctx, data) {
  if (!ctx || !window.Chart) return;
  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Customer Service', 'Accuracy', 'Speed', 'Teamwork', 'Communication', 'Compliance'],
      datasets: [{
        label: 'KPI Score',
        data: data || [88, 92, 85, 90, 87, 95],
        borderColor: '#007A8A',
        backgroundColor: 'rgba(0,122,138,.15)',
        pointBackgroundColor: '#007A8A',
        pointRadius: 4,
      }]
    },
    options: { responsive: true, scales: { r: { min: 0, max: 100, ticks: { stepSize: 20 } } }, plugins: { legend: { display: false } } }
  });
}

// Attendance check-in button
document.addEventListener('DOMContentLoaded', () => {
  const checkInBtn = document.getElementById('ep-checkin-btn');
  if (checkInBtn) {
    checkInBtn.addEventListener('click', async () => {
      EP.setBtn(checkInBtn, true, 'Checking in…');
      const res = await EP.api('/attendance/check-in.php', { method: 'POST', body: JSON.stringify({ action: 'checkin' }) });
      EP.setBtn(checkInBtn, false);
      if (res && res.success) {
        EP.toast('Checked in at ' + res.time, 'success');
        document.getElementById('ep-checkin-time')?.setText?.(res.time);
      } else {
        EP.toast(res?.message || 'Check-in recorded (demo mode)', 'info');
      }
    });
  }
});
