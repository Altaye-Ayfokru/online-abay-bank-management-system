<?php
// Temporary: show errors to diagnose 500
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once dirname(__DIR__) . '/middleware/csrf.php';

// Already logged in → redirect
if (ep_is_logged_in()) {
  header('Location: ' . EP_BASE_URL . '/employee/dashboard.php');
  exit;
}

$error   = ep_get_flash('danger');
$success = ep_get_flash('success');
$tab     = $_GET['tab'] ?? 'signin';

// POST handler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  ep_csrf_check();
  $action = $_POST['_action'] ?? 'signin';

  /* ── SIGN IN ── */
  if ($action === 'signin') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
      $error = 'Username and password are required.';
    } else {
      $emp = null;

      // Try DB first
      $db = EP_Database::get();
      if ($db) {
        try {
          $row = EP_Database::queryOne(
            "SELECT eu.*, e.first_name, e.last_name, e.employee_number,
                                e.basic_salary, e.hire_date, e.avatar, e.status AS emp_status,
                                d.name AS dept_name, b.branch_name, e.position,
                                r.role_name AS role
                         FROM employee_users eu
                         JOIN employees e ON e.id = eu.employee_id
                         LEFT JOIN departments d ON d.id = e.department_id
                         LEFT JOIN branches b ON b.id = e.branch_id
                         LEFT JOIN roles r ON r.id = eu.role_id
                         WHERE (eu.username = ? OR eu.email = ?) AND eu.is_active=1 AND e.status = 'Active'
                         LIMIT 1",
            [$username, $username]
          );
          if ($row && password_verify($password, $row['password_hash'] ?? '')) {
            $emp = $row;
            EP_Database::execute("UPDATE employee_users SET last_login=NOW() WHERE id=?", [$row['id']]);
          }
        } catch (Throwable $e2) {
        }
      }

      // Demo fallback
      if (!$emp) {
        $demos = [
          'abebe.girma'   => ['id' => 1, 'employee_number' => 'EMP-000001', 'username' => 'abebe.girma', 'first_name' => 'Abebe', 'last_name' => 'Girma', 'email' => 'abebe.girma@abaybank.com', 'phone' => '+251911234567', 'role' => 'Teller', 'dept_name' => 'Operations', 'branch_name' => 'Head Office', 'position' => 'Senior Teller', 'basic_salary' => 18500, 'hire_date' => '2019-03-01', 'avatar' => null, 'emp_status' => 'Active'],
          'tigist.haile'  => ['id' => 2, 'employee_number' => 'EMP-000002', 'username' => 'tigist.haile', 'first_name' => 'Tigist', 'last_name' => 'Haile', 'email' => 'tigist.haile@abaybank.com', 'phone' => '+251912345678', 'role' => 'Loan Officer', 'dept_name' => 'Loans', 'branch_name' => 'Bole Branch', 'position' => 'Loan Officer', 'basic_salary' => 22000, 'hire_date' => '2020-07-15', 'avatar' => null, 'emp_status' => 'Active'],
          'samuel.bekele' => ['id' => 3, 'employee_number' => 'EMP-000003', 'username' => 'samuel.bekele', 'first_name' => 'Samuel', 'last_name' => 'Bekele', 'email' => 'samuel.bekele@abaybank.com', 'phone' => '+251913456789', 'role' => 'IT Staff', 'dept_name' => 'IT', 'branch_name' => 'Head Office', 'position' => 'IT Technician', 'basic_salary' => 25000, 'hire_date' => '2021-01-10', 'avatar' => null, 'emp_status' => 'Active'],
          'meron.tesfaye' => ['id' => 4, 'employee_number' => 'EMP-000004', 'username' => 'meron.tesfaye', 'first_name' => 'Meron', 'last_name' => 'Tesfaye', 'email' => 'meron.tesfaye@abaybank.com', 'phone' => '+251914567890', 'role' => 'Customer Service', 'dept_name' => 'Customer Service', 'branch_name' => 'Alem Ketema Branch', 'position' => 'CS Officer', 'basic_salary' => 17000, 'hire_date' => '2022-04-05', 'avatar' => null, 'emp_status' => 'Active'],
        ];
        $key = strtolower(trim($username));
        $pwds = ['abebe.girma' => 'Employee@1234', 'tigist.haile' => 'Employee@1234', 'samuel.bekele' => 'Employee@1234', 'meron.tesfaye' => 'Employee@1234'];
        if (isset($demos[$key]) && ($pwds[$key] ?? '') === $password) {
          $emp = $demos[$key];
        }
      }

      if ($emp) {
        ep_login_employee($emp);
        $redir = $_SESSION['ep_redirect_after'] ?? EP_BASE_URL . '/employee/dashboard.php';
        unset($_SESSION['ep_redirect_after']);
        header('Location: ' . $redir);
        exit;
      } else {
        $error = 'Invalid username or password. Use the demo credentials below.';
        $tab   = 'signin';
      }
    }
  }

  /* ── SIGN UP ── */
  if ($action === 'signup') {
    $firstName = trim($_POST['first_name']  ?? '');
    $lastName  = trim($_POST['last_name']   ?? '');
    $empId     = strtoupper(trim($_POST['employee_id'] ?? ''));
    $email     = trim($_POST['email']       ?? '');
    $username  = strtolower(trim($_POST['username']   ?? ''));
    $password  = $_POST['password']         ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';
    $tab       = 'signup';

    $errs = [];
    if (!$firstName || !$lastName)     $errs[] = 'Full name is required.';
    if (!$empId)                        $errs[] = 'Employee ID is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Valid work email is required.';
    if (strlen($username) < 4)         $errs[] = 'Username must be at least 4 characters.';
    if (strlen($password) < 8)         $errs[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm)        $errs[] = 'Passwords do not match.';

    if ($errs) {
      $error = implode(' ', $errs);
    } else {
      $db = EP_Database::get();
      if ($db) {
        $empRecord = EP_Database::queryOne("SELECT id FROM employees WHERE employee_number=? AND status='Active' LIMIT 1", [$empId]);
        if (!$empRecord) {
          $error = 'Employee ID not found. Contact HR.';
        } else {
          $exists = EP_Database::queryOne("SELECT id FROM employee_users WHERE username=? OR email=? LIMIT 1", [$username, $email]);
          if ($exists) {
            $error = 'Username or email already registered.';
          } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            EP_Database::execute("INSERT INTO employee_users (employee_id,username,email,password_hash,is_active,created_at) VALUES (?,?,?,?,1,NOW())", [$empRecord['id'], $username, $email, $hash]);
            ep_flash('success', 'Account created! You can now sign in.');
            header('Location: ' . EP_BASE_URL . '/auth/login.php');
            exit;
          }
        }
      } else {
        ep_flash('success', 'Demo: Account registered for ' . htmlspecialchars($firstName) . '! Sign in with demo credentials.');
        header('Location: ' . EP_BASE_URL . '/auth/login.php');
        exit;
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Sign In — <?= EP_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    :root {
      --navy: #1B3A5C;
      --teal: #007A8A;
      --gold: #C8A84B;
      --green: #2d6a4f;
      --err: #ef4444;
    }

    html,
    body {
      height: 100%;
      font-family: 'Inter', sans-serif;
    }

    body {
      display: flex;
      min-height: 100vh;
      background: #f0f4f8;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }

    .wrap {
      display: flex;
      max-width: 1020px;
      width: 100%;
      background: #fff;
      border-radius: 22px;
      overflow: hidden;
      box-shadow: 0 24px 80px rgba(27, 58, 92, .22);
    }

    .left {
      flex: 1.1;
      background: linear-gradient(160deg, #1B3A5C, #2d6a4f);
      padding: 52px 44px;
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      overflow: hidden;
    }

    .left::before {
      content: '';
      position: absolute;
      top: -100px;
      right: -100px;
      width: 380px;
      height: 380px;
      background: radial-gradient(circle, rgba(200, 168, 75, .18), transparent 70%);
      border-radius: 50%;
    }

    .logo-row {
      display: flex;
      align-items: center;
      gap: 13px;
      margin-bottom: 32px;
      position: relative;
      z-index: 2;
    }

    .logo-bars {
      display: flex;
      align-items: flex-end;
      gap: 4px;
      background: rgba(255, 255, 255, .12);
      border-radius: 10px;
      padding: 8px 10px 10px;
    }

    .b {
      border-radius: 2px 2px 0 0;
      display: block;
    }

    .b1 {
      width: 6px;
      height: 18px;
      background: #C8A84B;
    }

    .b2 {
      width: 6px;
      height: 24px;
      background: #7ecfd8;
    }

    .b3 {
      width: 6px;
      height: 30px;
      background: #fff;
    }

    .b4 {
      width: 6px;
      height: 18px;
      background: #7ecfd8;
    }

    .logo-am {
      font-size: 1.05rem;
      font-weight: 800;
    }

    .logo-en {
      font-size: .72rem;
      color: #C8A84B;
      font-weight: 600;
      letter-spacing: .1em;
      text-transform: uppercase;
    }

    .headline {
      font-size: 1.85rem;
      font-weight: 800;
      line-height: 1.2;
      margin-bottom: 12px;
      position: relative;
      z-index: 2;
    }

    .headline span {
      color: #C8A84B;
    }

    .sub {
      font-size: .88rem;
      opacity: .8;
      line-height: 1.7;
      margin-bottom: 32px;
      position: relative;
      z-index: 2;
    }

    .feats {
      display: flex;
      flex-direction: column;
      gap: 11px;
      position: relative;
      z-index: 2;
    }

    .feat {
      display: flex;
      align-items: center;
      gap: 12px;
      background: rgba(255, 255, 255, .1);
      border: 1px solid rgba(255, 255, 255, .14);
      border-radius: 10px;
      padding: 12px 14px;
    }

    .feat-ic {
      width: 34px;
      height: 34px;
      background: #C8A84B;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #1B3A5C;
      font-size: .85rem;
      flex-shrink: 0;
    }

    .left-foot {
      font-size: .72rem;
      opacity: .45;
      margin-top: 28px;
      position: relative;
      z-index: 2;
    }

    .right {
      flex: 1;
      padding: 44px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      overflow-y: auto;
      max-height: 100vh;
    }

    .form-tag {
      font-size: .7rem;
      font-weight: 700;
      color: var(--green);
      text-transform: uppercase;
      letter-spacing: 1.5px;
      margin-bottom: 9px;
    }

    .tabs {
      display: flex;
      background: #f1f5f9;
      border-radius: 12px;
      padding: 4px;
      margin-bottom: 22px;
      gap: 4px;
    }

    .tab {
      flex: 1;
      padding: 10px;
      border: none;
      background: none;
      border-radius: 9px;
      font-size: .87rem;
      font-weight: 600;
      cursor: pointer;
      color: #64748b;
      transition: .2s;
      font-family: inherit;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
    }

    .tab.active {
      background: #fff;
      color: var(--navy);
      box-shadow: 0 1px 4px rgba(0, 0, 0, .1);
    }

    .demo-box {
      background: linear-gradient(135deg, #ecfdf5, #f0faf4);
      border: 1px solid #a7f3d0;
      border-radius: 12px;
      padding: 13px 15px;
      margin-bottom: 18px;
    }

    .demo-title {
      font-size: .7rem;
      font-weight: 700;
      color: #065f46;
      text-transform: uppercase;
      letter-spacing: .8px;
      margin-bottom: 9px;
    }

    .demo-row {
      display: grid;
      grid-template-columns: 150px 1fr 1fr;
      gap: 8px;
      padding: 6px 8px;
      border-radius: 7px;
      cursor: pointer;
      font-size: .8rem;
      align-items: center;
      transition: .2s;
    }

    .demo-row:hover {
      background: rgba(45, 106, 79, .1);
    }

    .dr-role {
      font-weight: 700;
      color: var(--navy);
    }

    .dr-user {
      color: #475569;
    }

    .dr-pass {
      font-family: monospace;
      color: var(--green);
      font-size: .78rem;
    }

    .alert {
      display: flex;
      align-items: flex-start;
      gap: 9px;
      padding: 11px 14px;
      border-radius: 9px;
      font-size: .84rem;
      margin-bottom: 16px;
    }

    .alert-err {
      background: #fee2e2;
      border: 1px solid #fecaca;
      color: #991b1b;
    }

    .alert-ok {
      background: #dcfce7;
      border: 1px solid #a7f3d0;
      color: #065f46;
    }

    .fg {
      margin-bottom: 14px;
    }

    .lbl {
      display: block;
      font-size: .8rem;
      font-weight: 600;
      color: #374151;
      margin-bottom: 5px;
    }

    .inp-w {
      position: relative;
    }

    .inp-ic {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #94a3b8;
      font-size: .88rem;
      pointer-events: none;
    }

    .inp {
      width: 100%;
      padding: 11px 13px 11px 38px;
      border: 2px solid #e2e8f0;
      border-radius: 10px;
      font-size: .88rem;
      font-family: inherit;
      outline: none;
      transition: .2s;
    }

    .inp:focus {
      border-color: var(--green);
      box-shadow: 0 0 0 3px rgba(45, 106, 79, .1);
    }

    .inp-noi {
      padding-left: 13px;
    }

    .eye-btn {
      position: absolute;
      right: 11px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: #94a3b8;
      cursor: pointer;
    }

    .form-row2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .hint {
      font-size: .72rem;
      color: #94a3b8;
      margin-top: 3px;
    }

    .foot-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      font-size: .82rem;
    }

    .foot-row a {
      color: var(--green);
      font-weight: 600;
    }

    .btn-submit {
      width: 100%;
      padding: 13px;
      background: linear-gradient(135deg, var(--navy), var(--green));
      color: #fff;
      border: none;
      border-radius: 11px;
      font-size: .95rem;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 9px;
      transition: .2s;
    }

    .btn-submit:hover {
      opacity: .9;
      transform: translateY(-1px);
    }

    .btn-submit:disabled {
      opacity: .65;
      cursor: not-allowed;
      transform: none;
    }

    .switch-ln {
      text-align: center;
      font-size: .82rem;
      color: #64748b;
      margin-top: 14px;
    }

    .switch-ln a {
      color: var(--green);
      font-weight: 600;
    }

    .str-bar {
      height: 4px;
      background: #e2e8f0;
      border-radius: 2px;
      margin-top: 6px;
      overflow: hidden;
    }

    .str-fill {
      height: 100%;
      border-radius: 2px;
      transition: .3s;
    }

    .portal-links {
      display: flex;
      justify-content: center;
      gap: 16px;
      margin-top: 20px;
      padding-top: 16px;
      border-top: 1px solid #f1f5f9;
      font-size: .79rem;
    }

    .portal-links a {
      color: #94a3b8;
      display: flex;
      align-items: center;
      gap: 5px;
      text-decoration: none;
    }

    .portal-links a:hover {
      color: var(--navy);
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }

    @media(max-width:800px) {
      .left {
        display: none;
      }

      .right {
        padding: 32px 24px;
      }
    }
  </style>
</head>

<body>
  <div class="wrap">
    <!-- Left panel -->
    <div class="left">
      <div>
        <div class="logo-row">
          <div class="logo-bars"><span class="b b1"></span><span class="b b2"></span><span class="b b3"></span><span class="b b4"></span></div>
          <div>
            <div class="logo-am">ዓባይ ባንክ</div>
            <div class="logo-en">Abay Bank S.C.</div>
          </div>
        </div>
        <h1 class="headline">Employee<br><span>Self-Service</span><br>Portal</h1>
        <p class="sub">Access payslips, attendance, leave requests, tasks, and your full banking work hub.</p>
        <div class="feats">
          <div class="feat">
            <div class="feat-ic"><i class="fa-solid fa-receipt"></i></div><span style="font-size:.8rem;font-weight:500">View payslips &amp; salary breakdown</span>
          </div>
          <div class="feat">
            <div class="feat-ic"><i class="fa-solid fa-calendar-check"></i></div><span style="font-size:.8rem;font-weight:500">Check in / out &amp; apply for leave</span>
          </div>
          <div class="feat">
            <div class="feat-ic"><i class="fa-solid fa-users"></i></div><span style="font-size:.8rem;font-weight:500">Manage customers, accounts &amp; loans</span>
          </div>
          <div class="feat">
            <div class="feat-ic"><i class="fa-solid fa-chart-bar"></i></div><span style="font-size:.8rem;font-weight:500">KPI tracking &amp; performance reviews</span>
          </div>
        </div>
      </div>
      <div class="left-foot">© <?= date('Y') ?> Abay Bank S.C. &middot; Employee Self-Service Portal &middot; NBE Licensed</div>
    </div>

    <!-- Right panel -->
    <div class="right">
      <div class="form-tag"><i class="fa-solid fa-id-badge"></i> &nbsp;Employee Portal</div>

      <div class="tabs" id="auth-tabs">
        <button class="tab <?= $tab === 'signin' ? 'active' : '' ?>" onclick="switchTab('signin')" id="tab-signin">
          <i class="fa-solid fa-right-to-bracket"></i> Sign In
        </button>
        <button class="tab <?= $tab === 'signup' ? 'active' : '' ?>" onclick="switchTab('signup')" id="tab-signup">
          <i class="fa-solid fa-user-plus"></i> Sign Up
        </button>
      </div>

      <!-- Demo credentials (signin only) -->
      <div class="demo-box" id="demo-box" <?= $tab === 'signup' ? 'style="display:none"' : '' ?>>
        <div class="demo-title"><i class="fa-solid fa-circle-info"></i> Demo Credentials — click to fill</div>
        <div class="demo-row" onclick="fillDemo('abebe.girma','Employee@1234')"><span class="dr-role"><i class="fa-solid fa-user-tie"></i> Sr. Teller</span><span class="dr-user">abebe.girma</span><span class="dr-pass">Employee@1234</span></div>
        <div class="demo-row" onclick="fillDemo('tigist.haile','Employee@1234')"><span class="dr-role"><i class="fa-solid fa-user-tie"></i> Loan Officer</span><span class="dr-user">tigist.haile</span><span class="dr-pass">Employee@1234</span></div>
        <div class="demo-row" onclick="fillDemo('samuel.bekele','Employee@1234')"><span class="dr-role"><i class="fa-solid fa-user-tie"></i> IT Staff</span><span class="dr-user">samuel.bekele</span><span class="dr-pass">Employee@1234</span></div>
        <div class="demo-row" onclick="fillDemo('meron.tesfaye','Employee@1234')"><span class="dr-role"><i class="fa-solid fa-user-tie"></i> CS Officer</span><span class="dr-user">meron.tesfaye</span><span class="dr-pass">Employee@1234</span></div>
      </div>

      <?php if ($error): ?><div class="alert alert-err"><i class="fa-solid fa-circle-xmark"></i><span><?= htmlspecialchars($error) ?></span></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-ok"><i class="fa-solid fa-circle-check"></i><span><?= htmlspecialchars($success) ?></span></div><?php endif; ?>

      <!-- SIGN IN -->
      <div id="panel-signin" <?= $tab === 'signup' ? 'style="display:none"' : '' ?>>
        <h2 style="font-size:1.5rem;font-weight:800;color:var(--navy);margin-bottom:4px">Welcome Back</h2>
        <p style="font-size:.84rem;color:#64748b;margin-bottom:20px">Sign in to your employee account</p>
        <form method="POST" id="signin-form">
          <?= ep_csrf_field() ?>
          <input type="hidden" name="_action" value="signin">
          <div class="fg">
            <label class="lbl">Employee ID / Username</label>
            <div class="inp-w"><i class="fa-solid fa-id-badge inp-ic"></i>
              <input type="text" name="username" id="si-user" class="inp" placeholder="e.g. abebe.girma" required autocomplete="username">
            </div>
          </div>
          <div class="fg">
            <label class="lbl">Password</label>
            <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i>
              <input type="password" name="password" id="si-pass" class="inp" placeholder="Your password" required autocomplete="current-password">
              <button type="button" class="eye-btn" onclick="togglePw('si-pass',this)"><i class="fa-solid fa-eye"></i></button>
            </div>
          </div>
          <div class="foot-row">
            <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:.82rem"><input type="checkbox" name="remember"> Remember me</label>
            <a href="<?= EP_BASE_URL ?>/auth/forgot-password.php">Forgot password?</a>
          </div>
          <button type="submit" class="btn-submit" id="signin-btn"><i class="fa-solid fa-right-to-bracket"></i> Sign In</button>
        </form>
        <div class="switch-ln">No account? <a href="#" onclick="switchTab('signup');return false">Create one</a></div>
      </div>

      <!-- SIGN UP -->
      <div id="panel-signup" <?= $tab === 'signin' ? 'style="display:none"' : '' ?>>
        <h2 style="font-size:1.5rem;font-weight:800;color:var(--navy);margin-bottom:4px">Create Account</h2>
        <p style="font-size:.84rem;color:#64748b;margin-bottom:20px">Register with your Employee ID</p>
        <form method="POST" id="signup-form">
          <?= ep_csrf_field() ?>
          <input type="hidden" name="_action" value="signup">
          <div class="form-row2">
            <div class="fg"><label class="lbl">First Name *</label>
              <div class="inp-w"><i class="fa-solid fa-user inp-ic"></i><input type="text" name="first_name" class="inp" placeholder="Abebe" required value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>"></div>
            </div>
            <div class="fg"><label class="lbl">Last Name *</label>
              <div class="inp-w"><i class="fa-solid fa-user inp-ic"></i><input type="text" name="last_name" class="inp" placeholder="Girma" required value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>"></div>
            </div>
          </div>
          <div class="fg"><label class="lbl">Employee ID *</label>
            <div class="inp-w"><i class="fa-solid fa-id-card inp-ic"></i><input type="text" name="employee_id" class="inp" placeholder="EMP-000001" required value="<?= htmlspecialchars($_POST['employee_id'] ?? '') ?>"></div>
            <div class="hint">On your ID badge (EMP-XXXXXX)</div>
          </div>
          <div class="fg"><label class="lbl">Work Email *</label>
            <div class="inp-w"><i class="fa-solid fa-envelope inp-ic"></i><input type="email" name="email" class="inp" placeholder="yourname@abaybank.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div>
          </div>
          <div class="fg"><label class="lbl">Username *</label>
            <div class="inp-w"><i class="fa-solid fa-at inp-ic"></i><input type="text" name="username" class="inp" placeholder="firstname.lastname" required minlength="4" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"></div>
          </div>
          <div class="fg"><label class="lbl">Password *</label>
            <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i>
              <input type="password" name="password" id="su-pass" class="inp" placeholder="Min. 8 characters" required minlength="8" oninput="checkStr(this.value)">
              <button type="button" class="eye-btn" onclick="togglePw('su-pass',this)"><i class="fa-solid fa-eye"></i></button>
            </div>
            <div class="str-bar">
              <div class="str-fill" id="str-fill" style="width:0%"></div>
            </div>
          </div>
          <div class="fg"><label class="lbl">Confirm Password *</label>
            <div class="inp-w"><i class="fa-solid fa-lock inp-ic"></i><input type="password" name="confirm_password" id="su-cf" class="inp" placeholder="Repeat password" required oninput="checkMatch()"></div>
            <div class="hint" id="match-msg"></div>
          </div>
          <button type="submit" class="btn-submit" id="signup-btn" style="background:linear-gradient(135deg,var(--navy),var(--green))"><i class="fa-solid fa-user-plus"></i> Create Account</button>
        </form>
        <div class="switch-ln">Have an account? <a href="#" onclick="switchTab('signin');return false">Sign In</a></div>
      </div>

      <div class="portal-links">
        <a href="/abay-bank-management-system/"><i class="fa-solid fa-house"></i> Home</a>
        <a href="/abay-bank-management-system/login"><i class="fa-solid fa-shield-halved"></i> Staff Portal</a>
        <a href="/abay-bank-management-system/customer/login"><i class="fa-solid fa-user"></i> Customer Portal</a>
      </div>
    </div>
  </div>
  <script>
    function switchTab(t) {
      var isSi = t === 'signin';
      document.getElementById('panel-signin').style.display = isSi ? '' : 'none';
      document.getElementById('panel-signup').style.display = isSi ? 'none' : '';
      document.getElementById('demo-box').style.display = isSi ? '' : 'none';
      document.getElementById('tab-signin').className = 'tab' + (isSi ? ' active' : '');
      document.getElementById('tab-signup').className = 'tab' + (!isSi ? ' active' : '');
    }

    function fillDemo(u, p) {
      document.getElementById('si-user').value = u;
      document.getElementById('si-pass').value = p;
    }

    function togglePw(id, btn) {
      var i = document.getElementById(id);
      i.type = i.type === 'password' ? 'text' : 'password';
      btn.querySelector('i').className = 'fa-solid ' + (i.type === 'password' ? 'fa-eye' : 'fa-eye-slash');
    }

    function checkStr(v) {
      var s = 0;
      if (v.length >= 8) s++;
      if (/[A-Z]/.test(v)) s++;
      if (/[0-9]/.test(v)) s++;
      if (/[^a-zA-Z0-9]/.test(v)) s++;
      var c = ['', '#ef4444', '#f59e0b', '#3b82f6', '#22c55e'][s] || '';
      document.getElementById('str-fill').style.cssText = 'width:' + (s * 25) + '%;background:' + c;
    }

    function checkMatch() {
      var pw = document.getElementById('su-pass').value,
        cf = document.getElementById('su-cf').value,
        el = document.getElementById('match-msg');
      if (!cf) {
        el.textContent = '';
        return;
      }
      el.textContent = pw === cf ? '✓ Match' : '✗ No match';
      el.style.color = pw === cf ? '#22c55e' : '#ef4444';
    }
    document.getElementById('signin-form').addEventListener('submit', function() {
      var b = document.getElementById('signin-btn');
      b.disabled = true;
      b.innerHTML = '<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Signing in…';
    });
    document.getElementById('signup-form').addEventListener('submit', function(e) {
      if (document.getElementById('su-pass').value !== document.getElementById('su-cf').value) {
        e.preventDefault();
        alert('Passwords do not match');
        return;
      }
      var b = document.getElementById('signup-btn');
      b.disabled = true;
      b.innerHTML = '<i class="fa-solid fa-spinner" style="animation:spin 1s linear infinite"></i> Creating…';
    });
  </script>
</body>

</html>