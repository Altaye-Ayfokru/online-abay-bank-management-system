<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
ep_logout();
ep_flash('success', 'You have been signed out successfully.');
header('Location: ' . EP_BASE_URL . '/auth/login.php');
exit;
