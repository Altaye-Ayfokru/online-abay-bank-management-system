<?php
/**
 * Abay Bank — Employee Portal Bootstrap
 * Include this at the top of every page.
 */

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs/application/php_errors.log');

// Load constants
require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/database.php';

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_name(EP_SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => EP_SESSION_TIMEOUT,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Regenerate session ID once per session for security
if (empty($_SESSION['_ep_initiated'])) {
    session_regenerate_id(true);
    $_SESSION['_ep_initiated'] = true;
}

// Timezone
date_default_timezone_set('Africa/Addis_Ababa');

// Load helpers
require_once __DIR__ . '/../includes/functions.php';
