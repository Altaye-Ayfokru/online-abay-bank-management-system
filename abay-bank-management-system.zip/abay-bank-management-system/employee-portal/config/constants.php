<?php
/**
 * Abay Bank — Employee Portal Constants
 */

define('EP_VERSION',   '1.0.0');
define('EP_NAME',      'Abay Bank Employee Portal');
define('EP_BASE_URL',  'http://localhost/abay-bank-management-system/employee-portal');
define('EP_BASE_PATH', dirname(__DIR__));
define('EP_UPLOAD_PATH', EP_BASE_PATH . '/uploads');
define('EP_ASSET_URL',   EP_BASE_URL  . '/assets');

// Session
define('EP_SESSION_NAME',    'ep_session');
define('EP_SESSION_TIMEOUT', 7200); // 2 hours

// Pagination
define('EP_PER_PAGE', 15);

// Upload limits
define('EP_MAX_FILE_SIZE',  5 * 1024 * 1024); // 5 MB
define('EP_ALLOWED_IMAGES', ['image/jpeg','image/png','image/webp','image/gif']);
define('EP_ALLOWED_DOCS',   ['application/pdf','image/jpeg','image/png','application/msword',
                              'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);

// Leave types
define('EP_LEAVE_TYPES', ['Annual Leave','Sick Leave','Emergency Leave','Maternity Leave','Paternity Leave','Unpaid Leave']);

// Roles
define('EP_ROLES', ['Teller','Loan Officer','Customer Service','IT Staff','HR Officer','Branch Manager','Accountant','Auditor','Security','Driver','Cleaner','Other']);

// Attendance statuses
define('EP_ATT_STATUSES', ['Present','Late','Absent','Half Day','On Leave','Holiday']);

// Task priorities
define('EP_PRIORITIES', ['Low','Medium','High','Critical']);

// Date formats
define('EP_DATE_FMT',     'd M Y');
define('EP_DATETIME_FMT', 'd M Y H:i');
define('EP_TIME_FMT',     'H:i');
