<?php
/**
 * Abay Bank — Employee Portal Database
 * Uses the same MySQL database as the main system.
 */

class EP_Database {
    private static ?PDO $instance = null;

    public static function connect(): PDO {
        if (self::$instance !== null) return self::$instance;

        // Try to read .env from parent project
        $envFile = dirname(__DIR__, 2) . '/.env';
        $env = [];
        if (file_exists($envFile)) {
            foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                if (str_starts_with(trim($line), '#') || !str_contains($line, '=')) continue;
                [$k, $v] = explode('=', $line, 2);
                $env[trim($k)] = trim($v, " \t\n\r\0\x0B\"'");
            }
        }

        $host    = $env['DB_HOST']     ?? 'localhost';
        $port    = $env['DB_PORT']     ?? '3306';
        $db      = $env['DB_DATABASE'] ?? 'abay_bank';
        $user    = $env['DB_USERNAME'] ?? 'root';
        $pass    = $env['DB_PASSWORD'] ?? '';

        $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            self::$instance = new PDO($dsn, $user, $pass, $options);
        } catch (PDOException $e) {
            // Return null-safe wrapper in demo mode
            throw new RuntimeException('DB offline: ' . $e->getMessage());
        }
        return self::$instance;
    }

    public static function get(): ?PDO {
        try { return self::connect(); } catch (Throwable) { return null; }
    }

    public static function query(string $sql, array $params = []): array {
        $db = self::get();
        if (!$db) return [];
        try {
            $s = $db->prepare($sql);
            $s->execute($params);
            return $s->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return []; }
    }

    public static function queryOne(string $sql, array $params = []): ?array {
        $rows = self::query($sql, $params);
        return $rows[0] ?? null;
    }

    public static function execute(string $sql, array $params = []): bool {
        $db = self::get();
        if (!$db) return false;
        try {
            return $db->prepare($sql)->execute($params);
        } catch (Throwable) { return false; }
    }

    public static function lastId(): int {
        $db = self::get();
        return $db ? (int)$db->lastInsertId() : 0;
    }

    public static function isOnline(): bool {
        return self::get() !== null;
    }
}
