<?php

/**
 * Employee Portal — Attendance Controller
 */
class AttendanceController
{

  public static function checkIn(int $empId): array
  {
    $today = EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId]);
    if ($today && $today['check_in']) return ['success' => false, 'message' => 'Already checked in at ' . $today['check_in']];
    $now  = date('H:i:s');
    $status = (strtotime($now) > strtotime('09:00:00')) ? 'Late' : 'Present';
    if ($today) {
      EP_Database::execute("UPDATE attendance SET check_in=?,status=? WHERE employee_id=? AND date=CURDATE()", [$now, $status, $empId]);
    } else {
      EP_Database::execute("INSERT INTO attendance (employee_id,date,check_in,status) VALUES (?,CURDATE(),?,?)", [$empId, $now, $status]);
    }
    EmployeeController::logActivity($empId, "Checked in at $now", 'attendance');
    return ['success' => true, 'time' => date('H:i'), 'status' => $status];
  }

  public static function checkOut(int $empId): array
  {
    $today = EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId]);
    if (!$today || !$today['check_in']) return ['success' => false, 'message' => 'Not checked in today.'];
    if ($today['check_out']) return ['success' => false, 'message' => 'Already checked out at ' . $today['check_out']];
    $now   = date('H:i:s');
    $diff  = strtotime($now) - strtotime($today['check_in']);
    // Store as decimal hours (e.g. 9.25 = 9h 15m) to match decimal(4,2) column
    $hours = round($diff / 3600, 2);
    $hoursDisplay = floor($diff / 3600) . 'h ' . floor(($diff % 3600) / 60) . 'm';
    EP_Database::execute("UPDATE attendance SET check_out=?,hours_worked=? WHERE employee_id=? AND date=CURDATE()", [$now, $hours, $empId]);
    EmployeeController::logActivity($empId, "Checked out at $now. Hours: $hoursDisplay", 'attendance');
    return ['success' => true, 'time' => date('H:i'), 'hours' => $hoursDisplay];
  }

  public static function getMonthSummary(int $empId, int $month, int $year): array
  {
    return EP_Database::queryOne(
      "SELECT COUNT(*) AS total, SUM(status='Present') AS present, SUM(status='Late') AS late,
                    SUM(status='Absent') AS absent, SUM(status='On Leave') AS on_leave
             FROM attendance WHERE employee_id=? AND MONTH(date)=? AND YEAR(date)=?",
      [$empId, $month, $year]
    ) ?? ['total' => 0, 'present' => 0, 'late' => 0, 'absent' => 0, 'on_leave' => 0];
  }

  public static function getHistory(int $empId, string $month, string $status = '', int $limit = 15, int $offset = 0): array
  {
    $where = "employee_id=? AND DATE_FORMAT(date,'%Y-%m')=?";
    $params = [$empId, $month];
    if ($status) {
      $where .= " AND status=?";
      $params[] = $status;
    }
    return EP_Database::query("SELECT * FROM attendance WHERE $where ORDER BY date DESC LIMIT ? OFFSET ?", [...$params, $limit, $offset]) ?: [];
  }
}
