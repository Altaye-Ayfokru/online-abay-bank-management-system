<?php
/**
 * Employee Portal — Auth Controller
 * Handles login, logout, registration, password reset.
 */
class AuthController {
    private static array $demoUsers = [
        'abebe.girma'   => ['pwd'=>'Employee@1234','id'=>1,'employee_number'=>'EMP-000001','first_name'=>'Abebe','last_name'=>'Girma','email'=>'abebe.girma@abaybank.com','phone'=>'+251911234567','role'=>'Teller','dept_name'=>'Operations','branch_name'=>'Head Office','position'=>'Senior Teller','basic_salary'=>18500,'hire_date'=>'2019-03-01','avatar'=>null,'status'=>'Active'],
        'tigist.haile'  => ['pwd'=>'Employee@1234','id'=>2,'employee_number'=>'EMP-000002','first_name'=>'Tigist','last_name'=>'Haile','email'=>'tigist.haile@abaybank.com','phone'=>'+251912345678','role'=>'Loan Officer','dept_name'=>'Loans','branch_name'=>'Bole Branch','position'=>'Loan Officer','basic_salary'=>22000,'hire_date'=>'2020-07-15','avatar'=>null,'status'=>'Active'],
        'samuel.bekele' => ['pwd'=>'Employee@1234','id'=>3,'employee_number'=>'EMP-000003','first_name'=>'Samuel','last_name'=>'Bekele','email'=>'samuel.bekele@abaybank.com','phone'=>'+251913456789','role'=>'IT Staff','dept_name'=>'IT','branch_name'=>'Head Office','position'=>'IT Technician','basic_salary'=>25000,'hire_date'=>'2021-01-10','avatar'=>null,'status'=>'Active'],
        'meron.tesfaye' => ['pwd'=>'Employee@1234','id'=>4,'employee_number'=>'EMP-000004','first_name'=>'Meron','last_name'=>'Tesfaye','email'=>'meron.tesfaye@abaybank.com','phone'=>'+251914567890','role'=>'Customer Service','dept_name'=>'Customer Service','branch_name'=>'Alem Ketema Branch','position'=>'CS Officer','basic_salary'=>17000,'hire_date'=>'2022-04-05','avatar'=>null,'status'=>'Active'],
    ];

    public static function login(string $username, string $password): array {
        // Try DB
        $db = EP_Database::get();
        if ($db) {
            $row = EP_Database::queryOne(
                "SELECT eu.*, e.first_name, e.last_name, e.employee_number, e.basic_salary,
                        e.hire_date, e.avatar, e.status AS emp_status, e.position,
                        d.name AS dept_name, b.branch_name, r.role_name AS role
                 FROM employee_users eu
                 JOIN employees e ON e.id = eu.employee_id
                 LEFT JOIN departments d ON d.id = e.department_id
                 LEFT JOIN branches b ON b.id = e.branch_id
                 LEFT JOIN roles r ON r.id = eu.role_id
                 WHERE (eu.username=? OR eu.email=?) AND eu.is_active=1 AND e.status='Active'
                 LIMIT 1",
                [$username, $username]
            );
            if ($row && password_verify($password, $row['password_hash'] ?? '')) {
                EP_Database::execute("UPDATE employee_users SET last_login=NOW() WHERE id=?", [$row['id']]);
                unset($row['password_hash']);
                return ['success'=>true, 'employee'=>$row, 'mode'=>'live'];
            }
            if ($row) return ['success'=>false, 'message'=>'Incorrect password.'];
        }

        // Demo fallback
        $key = strtolower(trim($username));
        $demo = self::$demoUsers[$key] ?? null;
        if ($demo && $demo['pwd'] === $password) {
            $emp = $demo;
            unset($emp['pwd']);
            return ['success'=>true, 'employee'=>$emp, 'mode'=>'demo'];
        }
        return ['success'=>false, 'message'=>'Invalid username or password.'];
    }

    public static function register(array $data): array {
        $fn   = trim($data['first_name']  ?? '');
        $ln   = trim($data['last_name']   ?? '');
        $empNo= strtoupper(trim($data['employee_id'] ?? ''));
        $email= trim($data['email']       ?? '');
        $user = strtolower(trim($data['username']   ?? ''));
        $pass = $data['password']         ?? '';
        $conf = $data['confirm_password'] ?? '';

        if (!$fn || !$ln)              return ['success'=>false,'message'=>'Full name is required.'];
        if (!$empNo)                   return ['success'=>false,'message'=>'Employee ID is required.'];
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) return ['success'=>false,'message'=>'Valid work email is required.'];
        if (strlen($user) < 4)         return ['success'=>false,'message'=>'Username must be at least 4 characters.'];
        if (strlen($pass) < 8)         return ['success'=>false,'message'=>'Password must be at least 8 characters.'];
        if ($pass !== $conf)           return ['success'=>false,'message'=>'Passwords do not match.'];

        $db = EP_Database::get();
        if (!$db) return ['success'=>true,'message'=>'Demo: Account registered. Sign in with demo credentials.','demo'=>true];

        $empRecord = EP_Database::queryOne("SELECT id FROM employees WHERE employee_number=? AND status='Active' LIMIT 1", [$empNo]);
        if (!$empRecord) return ['success'=>false,'message'=>'Employee ID not found in records. Contact HR.'];

        $exists = EP_Database::queryOne("SELECT id FROM employee_users WHERE username=? OR email=? LIMIT 1", [$user,$email]);
        if ($exists) return ['success'=>false,'message'=>'Username or email already registered.'];

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        EP_Database::execute(
            "INSERT INTO employee_users (employee_id,username,email,password_hash,is_active,created_at) VALUES (?,?,?,?,1,NOW())",
            [$empRecord['id'],$user,$email,$hash]
        );
        return ['success'=>true,'message'=>"Account created for $fn $ln. You can now sign in."];
    }

    public static function changePassword(int $empId, string $current, string $new): array {
        if (strlen($new) < 8) return ['success'=>false,'message'=>'Password must be at least 8 characters.'];
        $db = EP_Database::get();
        if (!$db) return ['success'=>true,'message'=>'Demo: Password changed.'];
        $user = EP_Database::queryOne("SELECT id,password_hash FROM employee_users WHERE employee_id=? LIMIT 1", [$empId]);
        if (!$user) return ['success'=>false,'message'=>'Account not found.'];
        if (!password_verify($current, $user['password_hash']??'')) return ['success'=>false,'message'=>'Current password is incorrect.'];
        EP_Database::execute("UPDATE employee_users SET password_hash=?,updated_at=NOW() WHERE id=?", [password_hash($new,PASSWORD_DEFAULT),$user['id']]);
        return ['success'=>true,'message'=>'Password changed successfully.'];
    }
}
