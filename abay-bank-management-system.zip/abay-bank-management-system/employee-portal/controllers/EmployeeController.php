<?php

/**
 * Employee Portal — Employee Controller
 */
class EmployeeController
{

  public static function getProfile(int $empId): ?array
  {
    return EP_Database::queryOne(
      "SELECT e.*, d.name AS dept_name, b.branch_name, r.role_name AS role
             FROM employees e
             LEFT JOIN departments d ON d.id=e.department_id
             LEFT JOIN branches b ON b.id=e.branch_id
             LEFT JOIN roles r ON r.id=e.role_id
             WHERE e.id=?",
      [$empId]
    );
  }

  public static function updateProfile(int $empId, array $data): bool
  {
    return EP_Database::execute(
      "UPDATE employees SET phone=?,email=?,address=?,dob=?,gender=?,national_id=?,updated_at=NOW() WHERE id=?",
      [$data['phone'] ?? null, $data['email'] ?? null, $data['address'] ?? null, $data['dob'] ?? null, $data['gender'] ?? null, $data['national_id'] ?? null, $empId]
    );
  }

  public static function updateAvatar(int $empId, string $filename): bool
  {
    return EP_Database::execute("UPDATE employees SET avatar=? WHERE id=?", [$filename, $empId]);
  }

  public static function getDashboardStats(int $empId): array
  {
    $att   = EP_Database::queryOne("SELECT SUM(status='Present') AS present, SUM(status='Late') AS late FROM attendance WHERE employee_id=? AND MONTH(date)=MONTH(CURDATE())", [$empId]) ?? ['present' => 20, 'late' => 1];
    $leave = EP_Database::queryOne("SELECT annual_remaining, sick_remaining FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())", [$empId]) ?? ['annual_remaining' => 12, 'sick_remaining' => 8];
    $tasks = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_tasks WHERE assigned_to=? AND status IN('Pending','In Progress')", [$empId])['c'] ?? 3);
    $pay   = EP_Database::queryOne("SELECT net_salary FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT 1", [$empId]) ?? ['net_salary' => 17405];
    $notifs = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [$empId])['c'] ?? 2);
    return ['present' => (int)$att['present'], 'late' => (int)$att['late'], 'leave_remaining' => (int)$leave['annual_remaining'], 'tasks' => $tasks, 'net_salary' => (float)$pay['net_salary'], 'unread_notifs' => $notifs];
  }

  public static function logActivity(int $empId, string $description, string $type = 'general'): void
  {
    EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,ip,created_at) VALUES (?,?,?,?,NOW())", [$empId, $description, $type, $_SERVER['REMOTE_ADDR'] ?? '']);
  }

  public static function getRecentActivity(int $empId, int $limit = 8): array
  {
    return EP_Database::query("SELECT description,type,created_at FROM employee_activity_log WHERE employee_id=? ORDER BY created_at DESC LIMIT ?", [$empId, $limit])
      ?: [
        ['description' => 'Checked in at 08:02', 'type' => 'attendance', 'created_at' => date('Y-m-d H:i:s', time() - 3600)],
        ['description' => 'Deposit ETB 5,000 to ACC-001234', 'type' => 'transaction', 'created_at' => date('Y-m-d H:i:s', time() - 7200)]
      ];
  }
}
