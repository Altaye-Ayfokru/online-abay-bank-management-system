﻿<?php
/**
 * Employee Portal â€” Leave Controller
 */
class LeaveController {

    public static function getBalance(int $empId): array {
        return EP_Database::queryOne(
            "SELECT * FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())", [$empId]
        ) ?? ['annual_total'=>18,'annual_remaining'=>12,'sick_total'=>10,'sick_remaining'=>8,'emergency_total'=>3,'emergency_remaining'=>3];
    }

    public static function submit(int $empId, array $data): array {
        $type    = trim($data['leave_type']  ?? '');
        $start   = trim($data['from_date']  ?? '');
        $end     = trim($data['to_date']    ?? '');
        $reason  = trim($data['reason']      ?? '');

        if (!$type)  return ['success'=>false,'message'=>'Leave type required.'];
        if (!$start) return ['success'=>false,'message'=>'Start date required.'];
        if (!$end)   return ['success'=>false,'message'=>'End date required.'];
        if ($end < $start) return ['success'=>false,'message'=>'End date must be after start date.'];
        if (strlen($reason) < 10) return ['success'=>false,'message'=>'Reason must be at least 10 characters.'];

        // Count working days
        $days = 0; $cur = new DateTime($start); $endDt = new DateTime($end);
        while ($cur <= $endDt) { if ((int)$cur->format('N') < 6) $days++; $cur->modify('+1 day'); }

        EP_Database::execute(
            "INSERT INTO leave_requests (employee_id,leave_type,from_date,to_date,days,reason,status,created_at)
             VALUES (?,?,?,?,?,?,?,'Pending',NOW())",
            [$empId,$type,$start,$end,$days,$reason]
        );
        EmployeeController::logActivity($empId,"Leave request: $type ($days days)",'leave');
        return ['success'=>true,'message'=>"Leave request submitted for $days working days.",'days'=>$days];
    }

    public static function cancel(int $id, int $empId): array {
        $req = EP_Database::queryOne("SELECT * FROM leave_requests WHERE id=? AND employee_id=? AND status='Pending'", [$id,$empId]);
        if (!$req) return ['success'=>false,'message'=>'Request not found or cannot be cancelled.'];
        EP_Database::execute("UPDATE leave_requests SET status='Cancelled' WHERE id=?", [$id]);
        return ['success'=>true,'message'=>'Leave request cancelled.'];
    }

    public static function getHistory(int $empId, int $year, string $status='', int $limit=15, int $offset=0): array {
        $where = "employee_id=? AND YEAR(from_date)=?"; $params = [$empId,$year];
        if ($status) { $where .= " AND status=?"; $params[] = $status; }
        return EP_Database::query("SELECT * FROM leave_requests WHERE $where ORDER BY created_at DESC LIMIT ? OFFSET ?", [...$params,$limit,$offset]) ?: [];
    }
}
