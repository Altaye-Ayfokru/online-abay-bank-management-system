<?php
/**
 * Employee Portal — Notification Controller
 */
class NotificationController {

    public static function getAll(int $empId, bool $unreadOnly=false, int $limit=20, int $offset=0): array {
        $sql = "SELECT * FROM employee_notifications WHERE employee_id=?" . ($unreadOnly?" AND is_read=0":"") . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        return EP_Database::query($sql, [$empId,$limit,$offset]) ?: [];
    }

    public static function getUnreadCount(int $empId): int {
        return (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [$empId])['c'] ?? 0);
    }

    public static function markRead(int $id, int $empId): bool {
        return EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE id=? AND employee_id=?", [$id,$empId]);
    }

    public static function markAllRead(int $empId): bool {
        return EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE employee_id=?", [$empId]);
    }

    public static function send(int $empId, string $title, string $message, string $type='general', ?string $link=null): bool {
        return EP_Database::execute(
            "INSERT INTO employee_notifications (employee_id,title,message,type,link,is_read,created_at) VALUES (?,?,?,?,?,0,NOW())",
            [$empId,$title,$message,$type,$link]
        );
    }
}
