<?php
/**
 * Employee Portal — Transaction Controller
 * Wraps deposit, withdrawal, transfer with DB transactions and activity logging.
 */
class TransactionController {

    public static function deposit(string $accountNumber, float $amount, string $description, int $createdBy): array {
        if (!$accountNumber) return ['success'=>false,'message'=>'Account number required.'];
        if ($amount < 1)     return ['success'=>false,'message'=>'Minimum deposit is ETB 1.'];

        $db = EP_Database::get();
        if (!$db) {
            $ref = 'DEP-'.strtoupper(substr(uniqid('',true),-8));
            return ['success'=>true,'message'=>"Demo: Deposit of ETB ".number_format($amount,2)." recorded. Ref: $ref",'reference'=>$ref,'demo'=>true];
        }
        try {
            $db->beginTransaction();
            $acc = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE", [$accountNumber]);
            if (!$acc || $acc['status']!=='Active') throw new RuntimeException('Account not found or inactive.');
            $newBal = (float)$acc['balance'] + $amount;
            EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?", [$newBal,$acc['id']]);
            $ref = 'DEP-'.strtoupper(substr(uniqid('',true),-8));
            EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Deposit',?,?,?,?,'Completed',?,NOW())", [$acc['id'],$amount,$newBal,$description,$ref,$createdBy]);
            EmployeeController::logActivity($createdBy,"Deposit ETB $amount to $accountNumber. Ref:$ref",'transaction');
            $db->commit();
            return ['success'=>true,'message'=>'Deposit successful.','reference'=>$ref,'new_balance'=>$newBal];
        } catch (Throwable $e) { $db->rollBack(); return ['success'=>false,'message'=>$e->getMessage()]; }
    }

    public static function withdrawal(string $accountNumber, float $amount, string $description, int $createdBy): array {
        if ($amount < 1) return ['success'=>false,'message'=>'Minimum withdrawal is ETB 1.'];
        $db = EP_Database::get();
        if (!$db) { $ref='WDR-'.strtoupper(substr(uniqid('',true),-8)); return ['success'=>true,'message'=>"Demo: Withdrawal recorded. Ref: $ref",'reference'=>$ref,'demo'=>true]; }
        try {
            $db->beginTransaction();
            $acc = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE", [$accountNumber]);
            if (!$acc || $acc['status']!=='Active') throw new RuntimeException('Account not found or inactive.');
            if ((float)$acc['balance'] < $amount) throw new RuntimeException('Insufficient balance.');
            $newBal = (float)$acc['balance'] - $amount;
            EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?", [$newBal,$acc['id']]);
            $ref='WDR-'.strtoupper(substr(uniqid('',true),-8));
            EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Withdrawal',?,?,?,?,'Completed',?,NOW())", [$acc['id'],$amount,$newBal,$description,$ref,$createdBy]);
            EmployeeController::logActivity($createdBy,"Withdrawal ETB $amount from $accountNumber. Ref:$ref",'transaction');
            $db->commit();
            return ['success'=>true,'message'=>'Withdrawal successful.','reference'=>$ref,'new_balance'=>$newBal];
        } catch (Throwable $e) { $db->rollBack(); return ['success'=>false,'message'=>$e->getMessage()]; }
    }

    public static function transfer(string $from, string $to, float $amount, string $description, int $createdBy): array {
        if ($from===$to) return ['success'=>false,'message'=>'Source and destination must differ.'];
        if ($amount < 1) return ['success'=>false,'message'=>'Minimum transfer is ETB 1.'];
        $db = EP_Database::get();
        if (!$db) { $ref='TRF-'.strtoupper(substr(uniqid('',true),-8)); return ['success'=>true,'message'=>"Demo: Transfer recorded. Ref: $ref",'reference'=>$ref,'demo'=>true]; }
        try {
            $db->beginTransaction();
            $src = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE", [$from]);
            $dst = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE", [$to]);
            if (!$src) throw new RuntimeException('Source account not found.');
            if (!$dst) throw new RuntimeException('Destination account not found.');
            if ((float)$src['balance'] < $amount) throw new RuntimeException('Insufficient balance.');
            $srcNew=(float)$src['balance']-$amount; $dstNew=(float)$dst['balance']+$amount;
            EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?", [$srcNew,$src['id']]);
            EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?", [$dstNew,$dst['id']]);
            $ref='TRF-'.strtoupper(substr(uniqid('',true),-8));
            EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Transfer Out',?,?,?,?,'Completed',?,NOW())", [$src['id'],$amount,$srcNew,"To $to: $description",$ref,$createdBy]);
            EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Transfer In',?,?,?,?,'Completed',?,NOW())", [$dst['id'],$amount,$dstNew,"From $from: $description",$ref,$createdBy]);
            EmployeeController::logActivity($createdBy,"Transfer ETB $amount from $from to $to. Ref:$ref",'transaction');
            $db->commit();
            return ['success'=>true,'message'=>'Transfer successful.','reference'=>$ref];
        } catch (Throwable $e) { $db->rollBack(); return ['success'=>false,'message'=>$e->getMessage()]; }
    }
}
