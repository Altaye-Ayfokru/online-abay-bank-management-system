-- ============================================================
-- Abay Bank Employee Portal — Database Schema
-- Run this ONCE to add Employee Portal tables to abay_bank DB
-- Existing tables (customers, accounts, transactions, etc.) are
-- shared with the main management system.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── Employee Portal Users (login accounts) ──────────────────
CREATE TABLE IF NOT EXISTS `employee_users` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`   INT UNSIGNED NOT NULL,
  `username`      VARCHAR(60) NOT NULL UNIQUE,
  `email`         VARCHAR(120) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role_id`       INT UNSIGNED DEFAULT NULL,
  `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
  `last_login`    DATETIME DEFAULT NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Employee Notifications ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `employee_notifications` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT UNSIGNED NOT NULL,
  `title`       VARCHAR(200) NOT NULL,
  `message`     TEXT NOT NULL,
  `type`        ENUM('payroll','leave','task','training','security','general','kyc') NOT NULL DEFAULT 'general',
  `link`        VARCHAR(500) DEFAULT NULL,
  `is_read`     TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_emp_notif` (`employee_id`, `is_read`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Employee Tasks ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `employee_tasks` (
  `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`             VARCHAR(300) NOT NULL,
  `description`       TEXT DEFAULT NULL,
  `assigned_to`       INT UNSIGNED NOT NULL,
  `assigned_by`       INT UNSIGNED DEFAULT NULL,
  `priority`          ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Medium',
  `status`            ENUM('Pending','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  `due_date`          DATE DEFAULT NULL,
  `completion_notes`  TEXT DEFAULT NULL,
  `completed_at`      DATETIME DEFAULT NULL,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_task_assigned` (`assigned_to`, `status`),
  FOREIGN KEY (`assigned_to`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Employee Activity Log ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `employee_activity_log` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT UNSIGNED NOT NULL,
  `description` VARCHAR(500) NOT NULL,
  `type`        VARCHAR(50)  NOT NULL DEFAULT 'general',
  `ip`          VARCHAR(45)  DEFAULT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_activity_emp` (`employee_id`),
  INDEX `idx_activity_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Leave Balances ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `leave_balances` (
  `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`         INT UNSIGNED NOT NULL,
  `year`                YEAR NOT NULL,
  `annual_total`        DECIMAL(5,1) NOT NULL DEFAULT 18,
  `annual_remaining`    DECIMAL(5,1) NOT NULL DEFAULT 18,
  `sick_total`          DECIMAL(5,1) NOT NULL DEFAULT 10,
  `sick_remaining`      DECIMAL(5,1) NOT NULL DEFAULT 10,
  `emergency_total`     DECIMAL(5,1) NOT NULL DEFAULT 3,
  `emergency_remaining` DECIMAL(5,1) NOT NULL DEFAULT 3,
  UNIQUE KEY `uq_emp_year` (`employee_id`, `year`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Ensure leave_requests has needed columns ─────────────────
CREATE TABLE IF NOT EXISTS `leave_requests` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`   INT UNSIGNED NOT NULL,
  `leave_type`    ENUM('Annual','Sick','Maternity','Paternity','Emergency','Unpaid','Compassionate') NOT NULL,
  `from_date`     DATE NOT NULL,
  `to_date`       DATE NOT NULL,
  `days`          TINYINT(3) UNSIGNED NOT NULL DEFAULT 1,
  `reason`        TEXT NOT NULL,
  `status`        ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  `approved_by`   INT UNSIGNED DEFAULT NULL,
  `approved_at`   DATETIME DEFAULT NULL,
  `reject_reason` VARCHAR(255) DEFAULT NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_leave_emp` (`employee_id`, `status`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Attendance (ensure correct columns) ─────────────────────
CREATE TABLE IF NOT EXISTS `attendance` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`  INT UNSIGNED NOT NULL,
  `date`         DATE NOT NULL,
  `check_in`     TIME DEFAULT NULL,
  `check_out`    TIME DEFAULT NULL,
  `hours_worked` DECIMAL(4,2) DEFAULT NULL,
  `overtime_hrs` DECIMAL(4,2) DEFAULT NULL,
  `status`       ENUM('Present','Absent','Late','Half Day','Holiday','Leave') NOT NULL DEFAULT 'Present',
  `note`         VARCHAR(255) DEFAULT NULL,
  `recorded_by`  INT UNSIGNED DEFAULT NULL,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_att_emp_date` (`employee_id`, `date`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Payroll ──────────────────────────────────────────────────
-- Note: If payroll table already exists, this CREATE is skipped.
-- The existing abay_bank payroll table uses pay_period (VARCHAR),
-- transport_allow, housing_allow, pension, paid_date columns.
CREATE TABLE IF NOT EXISTS `payroll` (
  `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employee_id`       INT UNSIGNED NOT NULL,
  `pay_period`        VARCHAR(20) NOT NULL COMMENT 'Format: YYYY-MM',
  `basic_salary`      DECIMAL(15,2) NOT NULL DEFAULT 0,
  `transport_allow`   DECIMAL(12,2) NOT NULL DEFAULT 0,
  `housing_allow`     DECIMAL(12,2) NOT NULL DEFAULT 0,
  `other_allowances`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `gross_salary`      DECIMAL(15,2) NOT NULL DEFAULT 0,
  `pension`           DECIMAL(12,2) NOT NULL DEFAULT 0,
  `income_tax`        DECIMAL(12,2) NOT NULL DEFAULT 0,
  `other_deductions`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `total_deductions`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `net_salary`        DECIMAL(15,2) NOT NULL DEFAULT 0,
  `paid_date`         DATE DEFAULT NULL,
  `payment_method`    ENUM('Bank Transfer','Cash','Cheque') NOT NULL DEFAULT 'Bank Transfer',
  `status`            ENUM('Draft','Processed','Paid') NOT NULL DEFAULT 'Paid',
  `processed_by`      INT UNSIGNED DEFAULT NULL,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_payroll_emp_period` (`employee_id`, `pay_period`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Customer Documents ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS `customer_documents` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT UNSIGNED NOT NULL,
  `doc_type`    VARCHAR(80)  NOT NULL,
  `file_name`   VARCHAR(255) NOT NULL,
  `file_path`   VARCHAR(500) NOT NULL,
  `status`      ENUM('Pending','Verified','Rejected') NOT NULL DEFAULT 'Pending',
  `uploaded_by` INT UNSIGNED DEFAULT NULL,
  `uploaded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
