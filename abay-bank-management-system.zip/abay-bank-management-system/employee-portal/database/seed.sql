-- ============================================================
-- Abay Bank Employee Portal — Seed Data  (v3 — matches real DB)
-- Run AFTER schema.sql. Safe to re-run (INSERT IGNORE).
-- ============================================================
SET NAMES utf8mb4;

-- ── Employee Portal Users ────────────────────────────────────
-- Password: 'Employee@1234'
INSERT IGNORE INTO `employee_users`
  (`employee_id`,`username`,`email`,`password_hash`,`is_active`,`created_at`)
VALUES
(1,'abebe.girma',  'abebe.girma@abaybank.com',  '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHi2',1,NOW()),
(2,'tigist.haile', 'tigist.haile@abaybank.com',  '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHi2',1,NOW()),
(3,'samuel.bekele','samuel.bekele@abaybank.com', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHi2',1,NOW()),
(4,'meron.tesfaye','meron.tesfaye@abaybank.com', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHi2',1,NOW());

-- ── Leave Balances ───────────────────────────────────────────
INSERT IGNORE INTO `leave_balances`
  (`employee_id`,`year`,`annual_total`,`annual_remaining`,`sick_total`,`sick_remaining`,`emergency_total`,`emergency_remaining`)
VALUES
(1,YEAR(CURDATE()),18,12,10,8,3,3),
(2,YEAR(CURDATE()),18,15,10,10,3,2),
(3,YEAR(CURDATE()),18,18,10,8,3,3),
(4,YEAR(CURDATE()),18,10,10,6,3,3);

-- ── Payroll ──────────────────────────────────────────────────
-- Real columns: pay_period, basic_salary, transport_allow, housing_allow,
--               gross_salary, income_tax, pension, total_deductions, net_salary, paid_date, status
INSERT IGNORE INTO `payroll`
  (`employee_id`,`pay_period`,`basic_salary`,`transport_allow`,`housing_allow`,
   `gross_salary`,`income_tax`,`pension`,`total_deductions`,`net_salary`,`status`,`paid_date`,`created_at`)
VALUES
(1,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%Y-%m'),18500,1500,2000,22000,3300,1295,4595,17405,'Paid',DATE_SUB(CURDATE(),INTERVAL 28 DAY),NOW()),
(1,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 2 MONTH),'%Y-%m'),18500,1500,2000,22000,3300,1295,4595,17405,'Paid',DATE_SUB(CURDATE(),INTERVAL 58 DAY),NOW()),
(1,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 3 MONTH),'%Y-%m'),18500,1500,2000,22000,3300,1295,4595,17405,'Paid',DATE_SUB(CURDATE(),INTERVAL 88 DAY),NOW()),
(2,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%Y-%m'),22000,1500,2500,26000,4050,1540,5590,20410,'Paid',DATE_SUB(CURDATE(),INTERVAL 28 DAY),NOW()),
(3,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%Y-%m'),25000,2000,3000,30000,4800,1750,6550,23450,'Paid',DATE_SUB(CURDATE(),INTERVAL 28 DAY),NOW()),
(4,DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%Y-%m'),17000,1500,1500,20000,2700,1190,3890,16110,'Paid',DATE_SUB(CURDATE(),INTERVAL 28 DAY),NOW());

-- ── Attendance ───────────────────────────────────────────────
-- Real columns: employee_id, date, check_in, check_out, hours_worked (decimal), status
-- hours_worked is decimal(4,2) so store as numeric hours e.g. 9.05
INSERT IGNORE INTO `attendance`
  (`employee_id`,`date`,`check_in`,`check_out`,`hours_worked`,`status`)
VALUES
(1,CURDATE(),                              '08:02:00',NULL,        NULL, 'Present'),
(1,DATE_SUB(CURDATE(),INTERVAL 1 DAY),    '07:58:00','17:10:00',  9.20,'Present'),
(1,DATE_SUB(CURDATE(),INTERVAL 2 DAY),    '09:14:00','17:00:00',  7.77,'Late'),
(1,DATE_SUB(CURDATE(),INTERVAL 3 DAY),    '08:05:00','17:15:00',  9.17,'Present'),
(1,DATE_SUB(CURDATE(),INTERVAL 4 DAY),    '08:01:00','17:08:00',  9.12,'Present'),
(1,DATE_SUB(CURDATE(),INTERVAL 7 DAY),    '08:00:00','17:02:00',  9.03,'Present'),
(1,DATE_SUB(CURDATE(),INTERVAL 8 DAY),    '08:03:00','17:05:00',  9.03,'Present'),
(2,CURDATE(),                              '08:10:00',NULL,        NULL, 'Present'),
(2,DATE_SUB(CURDATE(),INTERVAL 1 DAY),    '08:00:00','17:05:00',  9.08,'Present'),
(2,DATE_SUB(CURDATE(),INTERVAL 2 DAY),    '08:02:00','17:00:00',  8.97,'Present');

-- ── Employee Tasks ───────────────────────────────────────────
INSERT IGNORE INTO `employee_tasks`
  (`id`,`title`,`description`,`assigned_to`,`priority`,`status`,`due_date`,`created_at`)
VALUES
(1,'Process KYC for 3 pending customers',   'Verify docs for Abebe T., Hana B., Dawit A.',      1,'Critical','Pending',    CURDATE(),                           NOW()),
(2,'Review loan application LN-00234',       'Check collateral, credit score, income.',           1,'High',   'In Progress',CURDATE(),                           NOW()),
(3,'Monthly transaction summary report',     'Compile and submit monthly transaction log.',       1,'Medium', 'Pending',    DATE_ADD(CURDATE(),INTERVAL 2 DAY),  NOW()),
(4,'Customer complaint CC-089 follow-up',    'Contact Meron T. re ATM card issue.',               1,'High',   'Pending',    DATE_ADD(CURDATE(),INTERVAL 1 DAY),  NOW()),
(5,'Update customer contact information',    'Batch update phone numbers per HR memo.',           2,'Low',    'Pending',    DATE_ADD(CURDATE(),INTERVAL 5 DAY),  NOW());

-- ── Employee Notifications ───────────────────────────────────
INSERT IGNORE INTO `employee_notifications`
  (`employee_id`,`title`,`message`,`type`,`is_read`,`created_at`)
VALUES
(1,'Payslip Ready',    CONCAT('Payslip for ',DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%M %Y'),' is ready.'), 'payroll', 0,NOW()),
(1,'Leave Approved',   'Your annual leave (5 days) has been approved.',                                                'leave',   0,DATE_SUB(NOW(),INTERVAL 2 HOUR)),
(1,'Task Assigned',    'Assigned: Review loan application LN-00234.',                                                  'task',    1,DATE_SUB(NOW(),INTERVAL 1 DAY)),
(1,'Training Reminder','Core Banking Training starts Sep 1. Please confirm.',                                          'training',1,DATE_SUB(NOW(),INTERVAL 2 DAY)),
(1,'Security Alert',   'Password expires in 7 days. Update in Settings.',                                             'security',0,DATE_SUB(NOW(),INTERVAL 3 DAY)),
(2,'Payslip Ready',    CONCAT('Payslip for ',DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 MONTH),'%M %Y'),' is ready.'), 'payroll', 0,NOW()),
(2,'KYC Pending',      '12 customers need KYC verification.',                                                          'kyc',     0,DATE_SUB(NOW(),INTERVAL 1 HOUR));

-- ── Leave Requests ───────────────────────────────────────────
-- Real columns: employee_id, leave_type (enum: Annual/Sick/etc.),
--               from_date, to_date, days, reason, status, created_at
INSERT IGNORE INTO `leave_requests`
  (`employee_id`,`leave_type`,`from_date`,`to_date`,`days`,`reason`,`status`,`created_at`)
VALUES
(1,'Annual',   DATE_SUB(CURDATE(),INTERVAL 45 DAY), DATE_SUB(CURDATE(),INTERVAL 41 DAY), 5,'Family vacation',    'Approved',DATE_SUB(NOW(),INTERVAL 52 DAY)),
(1,'Sick',     DATE_SUB(CURDATE(),INTERVAL 80 DAY), DATE_SUB(CURDATE(),INTERVAL 79 DAY), 2,'Medical appointment','Approved',DATE_SUB(NOW(),INTERVAL 82 DAY)),
(2,'Annual',   DATE_ADD(CURDATE(),INTERVAL 7 DAY),  DATE_ADD(CURDATE(),INTERVAL 11 DAY), 5,'Personal travel',    'Pending', DATE_SUB(NOW(),INTERVAL 1 DAY));
