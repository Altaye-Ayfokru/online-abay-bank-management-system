<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Accounts — ' . EP_NAME;
$breadcrumb = [['label'=>'Accounts']];
$page   = max(1,(int)($_GET['page']??1));
$type   = $_GET['type'] ?? '';
$search = trim($_GET['q'] ?? '');

$where = "1=1"; $params = [];
if ($type)   { $where .= " AND a.account_type=?"; $params[] = $type; }
if ($search) { $where .= " AND (a.account_number LIKE ? OR c.first_name LIKE ? OR c.phone LIKE ?)"; $s="%$search%"; array_push($params,$s,$s,$s); }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE $where", $params)['c'] ?? 12);
$pag   = ep_paginate($total, $page);
$accounts = EP_Database::query(
    "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE $where ORDER BY a.opened_date DESC LIMIT ? OFFSET ?",
    [...$params,$pag['perPage'],$pag['offset']]
) ?: [
    ['id'=>1,'account_number'=>'1000012345678','account_type'=>'Savings','balance'=>84500,'customer_name'=>'Abebe Girma','phone'=>'+251911234567','status'=>'Active','opened_date'=>'2022-01-15'],
    ['id'=>2,'account_number'=>'1000098765432','account_type'=>'Current','balance'=>250000,'customer_name'=>'Tigist Haile','phone'=>'+251912345678','status'=>'Active','opened_date'=>'2021-07-22'],
    ['id'=>3,'account_number'=>'1000011223344','account_type'=>'Fixed Deposit','balance'=>500000,'customer_name'=>'Samuel Bekele','phone'=>'+251913456789','status'=>'Active','opened_date'=>'2020-11-05'],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-building-columns" style="color:var(--teal)"></i> Accounts</h1></div>
  <div class="ep-page-actions">
    <a href="open-account.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-folder-open"></i> Open Account</a>
  </div>
</div>
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="ep-label">Type</label>
        <select name="type" class="ep-select" style="width:150px">
          <option value="">All Types</option>
          <option <?= $type==='Savings'?'selected':'' ?>>Savings</option>
          <option <?= $type==='Current'?'selected':'' ?>>Current</option>
          <option <?= $type==='Fixed Deposit'?'selected':'' ?>>Fixed Deposit</option>
        </select>
      </div>
      <div style="flex:1"><label class="ep-label">Search</label>
        <div class="ep-inp-wrap"><i class="fa-solid fa-search ep-inp-ic"></i><input type="text" name="q" class="ep-input" placeholder="Account no., customer name…" value="<?= ep_e($search) ?>"></div>
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="index.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Account No.</th><th>Customer</th><th>Type</th><th>Balance</th><th>Status</th><th>Opened</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($accounts as $a): ?>
        <tr>
          <td style="font-family:monospace;font-size:.82rem;font-weight:700"><?= ep_e($a['account_number']) ?></td>
          <td><div class="fw-6" style="font-size:.84rem"><?= ep_e($a['customer_name']??'—') ?></div><div style="font-size:.75rem;color:var(--muted)"><?= ep_e($a['phone']??'') ?></div></td>
          <td><?= ep_badge($a['account_type']??'Savings') ?></td>
          <td class="fw-7" style="color:var(--teal)">ETB <?= number_format((float)($a['balance']??0),2) ?></td>
          <td><?= ep_badge($a['status']??'Active') ?></td>
          <td style="font-size:.82rem;color:var(--muted)"><?= ep_date($a['opened_date']??'') ?></td>
          <td>
            <a href="view.php?id=<?= (int)($a['id']??0) ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-eye"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
