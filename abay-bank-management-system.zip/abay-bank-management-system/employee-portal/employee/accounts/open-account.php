<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Open Account — ' . EP_NAME;
$breadcrumb = [['label'=>'Accounts','url'=>EP_BASE_URL.'/employee/accounts/index.php'],['label'=>'Open Account']];
$empId  = (int)($emp['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $custId   = (int)($_POST['customer_id']    ?? 0);
    $type     = trim($_POST['account_type']    ?? '');
    $deposit  = (float)($_POST['initial_deposit'] ?? 0);
    $branchId = (int)($_POST['branch_id']      ?? 1);
    $currency = trim($_POST['currency']        ?? 'ETB');

    if (!$custId)     $errors[] = 'Please select a customer.';
    if (!$type)       $errors[] = 'Account type is required.';
    if ($deposit < 100) $errors[] = 'Minimum initial deposit is ETB 100.';

    if (!$errors) {
        $accNo = '10000' . str_pad((string)rand(0,9999999), 8, '0', STR_PAD_LEFT);
        EP_Database::execute(
            "INSERT INTO accounts (customer_id,account_number,account_type,balance,branch_id,currency,status,opened_by,opened_date,created_at)
             VALUES (?,?,?,?,?,?,'Active',?,CURDATE(),NOW())",
            [$custId,$accNo,$type,$deposit,$branchId,$currency,$empId]
        );
        $accId = EP_Database::lastId();
        if ($accId && $deposit > 0) {
            EP_Database::execute(
                "INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,?,?,?,?,?,'Completed',?,NOW())",
                [$accId,'Deposit',$deposit,$deposit,'Initial Deposit','DEP-'.strtoupper(substr(uniqid('',true),-8)),$empId]
            );
        }
        EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())", [$empId,"Account opened: $accNo ($type)",'account']);
        ep_flash('success', "Account $accNo opened successfully.");
        header('Location: ' . EP_BASE_URL . '/employee/accounts/index.php'); exit;
    }
}
$customers = EP_Database::query("SELECT id, CONCAT(first_name,' ',last_name) AS name, customer_number FROM customers WHERE status='Active' ORDER BY first_name LIMIT 500")
          ?: [['id'=>1,'name'=>'Abebe Girma','customer_number'=>'CUST-001'],['id'=>2,'name'=>'Tigist Haile','customer_number'=>'CUST-002']];
$branches = EP_Database::query("SELECT id, branch_name FROM branches WHERE status='Active'")
         ?: [['id'=>1,'branch_name'=>'Head Office'],['id'=>2,'branch_name'=>'Bole Branch'],['id'=>3,'branch_name'=>'Alem Ketema Branch'],['id'=>4,'branch_name'=>'Kirkos Branch'],['id'=>5,'branch_name'=>'Bahir Dar Branch'],['id'=>6,'branch_name'=>'Hawassa Branch'],['id'=>7,'branch_name'=>'Dire Dawa Branch'],['id'=>8,'branch_name'=>'Mekelle Branch']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-folder-open" style="color:var(--teal)"></i> Open New Account</h1></div>
  <div class="ep-page-actions"><a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>
<div style="max-width:600px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Account Details</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group"><label class="ep-label">Customer <span class="req">*</span></label>
          <select name="customer_id" class="ep-select" required>
            <option value="">Select customer…</option>
            <?php foreach ($customers as $c): ?><option value="<?= $c['id'] ?>"><?= ep_e($c['name']) ?> (<?= ep_e($c['customer_number']) ?>)</option><?php endforeach; ?>
          </select>
        </div>
        <div class="ep-form-row">
          <div class="ep-form-group"><label class="ep-label">Account Type <span class="req">*</span></label>
            <select name="account_type" class="ep-select" required><option value="">Select…</option><option>Savings</option><option>Current</option><option>Fixed Deposit</option></select></div>
          <div class="ep-form-group"><label class="ep-label">Branch</label>
            <select name="branch_id" class="ep-select"><?php foreach ($branches as $b): ?><option value="<?= $b['id'] ?>"><?= ep_e($b['branch_name']) ?></option><?php endforeach; ?></select></div>
          <div class="ep-form-group"><label class="ep-label">Initial Deposit (ETB) <span class="req">*</span></label>
            <input type="number" name="initial_deposit" class="ep-input ep-inp-noi" min="100" step="0.01" placeholder="500.00" required></div>
          <div class="ep-form-group"><label class="ep-label">Currency</label>
            <select name="currency" class="ep-select"><option>ETB</option><option>USD</option><option>EUR</option></select></div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
          <a href="index.php" class="ep-btn ep-btn-outline">Cancel</a>
          <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-folder-open"></i> Open Account</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
