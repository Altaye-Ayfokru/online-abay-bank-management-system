<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Appointments — ' . EP_NAME;
$breadcrumb = [['label'=>'Appointments']];
$empId    = (int)($emp['id'] ?? 0);
$branchId = (int)($emp['branch_id'] ?? 0);

$filterDate = $_GET['date'] ?? date('Y-m-d');

// Today's appointments
$today = EP_Database::query(
    "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone AS customer_phone,
            CONCAT(e.first_name,' ',e.last_name) AS officer_name
     FROM appointments a
     LEFT JOIN customers c  ON c.id = a.customer_id
     LEFT JOIN employees e  ON e.id = a.assigned_to
     WHERE DATE(a.appointment_date) = ? AND a.branch_id = ?
     ORDER BY a.appointment_time ASC",
    [date('Y-m-d'), $branchId]
) ?: [
    ['id'=>1,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'09:00:00','customer_name'=>'Abebe Girma',  'customer_phone'=>'+251 911 100 200','purpose'=>'Account Opening',    'status'=>'Confirmed', 'officer_name'=>'Tigist Haile','notes'=>'Bring national ID and utility bill'],
    ['id'=>2,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'10:30:00','customer_name'=>'Kebede Alemu', 'customer_phone'=>'+251 912 200 300','purpose'=>'Loan Inquiry',        'status'=>'Confirmed', 'officer_name'=>'Samuel Bekele','notes'=>'Personal loan application'],
    ['id'=>3,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'13:00:00','customer_name'=>'Hiwot Tadesse','customer_phone'=>'+251 913 300 400','purpose'=>'Account Upgrade',     'status'=>'Pending',   'officer_name'=>'Meron Tesfaye','notes'=>''],
    ['id'=>4,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'14:30:00','customer_name'=>'Dawit Mengistu','customer_phone'=>'+251 914 400 500','purpose'=>'Investment Consultation','status'=>'Completed','officer_name'=>'Abebe Girma','notes'=>'Discussed fixed deposit options'],
];

// Upcoming appointments (next 7 days, excluding today)
$upcoming = EP_Database::query(
    "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone AS customer_phone,
            CONCAT(e.first_name,' ',e.last_name) AS officer_name
     FROM appointments a
     LEFT JOIN customers c ON c.id = a.customer_id
     LEFT JOIN employees e ON e.id = a.assigned_to
     WHERE a.appointment_date BETWEEN ? AND ? AND a.branch_id = ?
     ORDER BY a.appointment_date ASC, a.appointment_time ASC",
    [date('Y-m-d', strtotime('+1 day')), date('Y-m-d', strtotime('+7 days')), $branchId]
) ?: [
    ['id'=>5,'appointment_date'=>date('Y-m-d',strtotime('+1 day')),'appointment_time'=>'09:30:00','customer_name'=>'Selam Worku',  'customer_phone'=>'+251 915 500 600','purpose'=>'Loan Follow-up',  'status'=>'Confirmed','officer_name'=>'Tigist Haile'],
    ['id'=>6,'appointment_date'=>date('Y-m-d',strtotime('+1 day')),'appointment_time'=>'11:00:00','customer_name'=>'Yonas Girma', 'customer_phone'=>'+251 916 600 700','purpose'=>'Account Review',  'status'=>'Pending',  'officer_name'=>'Samuel Bekele'],
    ['id'=>7,'appointment_date'=>date('Y-m-d',strtotime('+2 days')),'appointment_time'=>'10:00:00','customer_name'=>'Feven Haile', 'customer_phone'=>'+251 917 700 800','purpose'=>'Card Replacement','status'=>'Confirmed','officer_name'=>'Meron Tesfaye'],
    ['id'=>8,'appointment_date'=>date('Y-m-d',strtotime('+3 days')),'appointment_time'=>'14:00:00','customer_name'=>'Bini Bekele', 'customer_phone'=>'+251 918 800 900','purpose'=>'Savings Plan',    'status'=>'Confirmed','officer_name'=>'Abebe Girma'],
];

$statusIcons = ['Confirmed'=>'circle-check','Pending'=>'clock','Completed'=>'check-double','Cancelled'=>'xmark'];
$statusColors = ['Confirmed'=>'#22c55e','Pending'=>'#f59e0b','Completed'=>'#3b82f6','Cancelled'=>'#ef4444'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-calendar-days" style="color:var(--teal)"></i> Appointments</h1>
    <p>Today's schedule and upcoming bookings</p>
  </div>
  <div class="ep-page-actions">
    <a href="today.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-print"></i> Print Today</a>
  </div>
</div>

<!-- Today Section -->
<div style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center">
  <h2 style="font-size:1rem;font-weight:700;color:var(--text)">
    <i class="fa-solid fa-sun" style="color:#f59e0b"></i>
    Today &mdash; <?= date('l, d F Y') ?>
  </h2>
  <span class="ep-badge ep-badge-info"><?= count($today) ?> appointments</span>
</div>

<?php if (empty($today)): ?>
<div class="ep-card" style="margin-bottom:20px">
  <div class="ep-card-body" style="text-align:center;padding:32px;color:var(--muted)">
    <i class="fa-solid fa-calendar-check" style="font-size:2rem;margin-bottom:8px;display:block;color:#22c55e"></i>
    No appointments scheduled for today.
  </div>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;margin-bottom:24px">
  <?php foreach ($today as $a): ?>
  <?php
    $sc = $statusColors[$a['status']] ?? '#64748b';
    $si = $statusIcons[$a['status']] ?? 'circle';
  ?>
  <div class="ep-card" style="border-left:4px solid <?= $sc ?>">
    <div class="ep-card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
        <div>
          <div style="font-size:1.1rem;font-weight:700;color:var(--teal)"><?= date('H:i', strtotime($a['appointment_time'])) ?></div>
          <div class="fw-6" style="font-size:.9rem"><?= ep_e($a['customer_name'] ?? '—') ?></div>
        </div>
        <span style="font-size:.78rem;font-weight:600;color:<?= $sc ?>"><i class="fa-solid fa-<?= $si ?>"></i> <?= ep_e($a['status'] ?? '') ?></span>
      </div>
      <div style="font-size:.82rem;margin-bottom:6px">
        <i class="fa-solid fa-tag" style="color:var(--muted);width:16px"></i> <?= ep_e($a['purpose'] ?? '—') ?>
      </div>
      <div style="font-size:.82rem;margin-bottom:6px;color:var(--muted)">
        <i class="fa-solid fa-user-tie" style="width:16px"></i> <?= ep_e($a['officer_name'] ?? '—') ?>
      </div>
      <div style="font-size:.82rem;color:var(--muted)">
        <i class="fa-solid fa-phone" style="width:16px"></i> <?= ep_e($a['customer_phone'] ?? '—') ?>
      </div>
      <?php if (!empty($a['notes'])): ?>
      <div style="margin-top:10px;font-size:.78rem;color:var(--muted);background:var(--surface);border-radius:6px;padding:6px 10px">
        <i class="fa-solid fa-note-sticky"></i> <?= ep_e($a['notes']) ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Upcoming Section -->
<div style="margin-bottom:8px">
  <h2 style="font-size:1rem;font-weight:700;color:var(--text)">
    <i class="fa-solid fa-calendar-week" style="color:var(--teal)"></i> Upcoming (Next 7 Days)
  </h2>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr><th>Date</th><th>Time</th><th>Customer</th><th>Purpose</th><th>Officer</th><th>Status</th></tr>
        </thead>
        <tbody>
          <?php if (empty($upcoming)): ?>
          <tr><td colspan="6" style="text-align:center;padding:24px;color:var(--muted)">No upcoming appointments</td></tr>
          <?php else: ?>
          <?php foreach ($upcoming as $a): ?>
          <?php $sc = $statusColors[$a['status']] ?? '#64748b'; ?>
          <tr>
            <td class="fw-6" style="white-space:nowrap"><?= ep_date($a['appointment_date'] ?? '') ?></td>
            <td style="font-family:monospace;color:var(--teal);font-weight:600"><?= date('H:i', strtotime($a['appointment_time'] ?? '00:00')) ?></td>
            <td>
              <div class="fw-6" style="font-size:.84rem"><?= ep_e($a['customer_name'] ?? '—') ?></div>
              <div style="font-size:.76rem;color:var(--muted)"><?= ep_e($a['customer_phone'] ?? '') ?></div>
            </td>
            <td style="font-size:.82rem"><?= ep_e($a['purpose'] ?? '—') ?></td>
            <td style="font-size:.82rem"><?= ep_e($a['officer_name'] ?? '—') ?></td>
            <td><span style="font-size:.8rem;font-weight:600;color:<?= $sc ?>"><?= ep_e($a['status'] ?? '') ?></span></td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
