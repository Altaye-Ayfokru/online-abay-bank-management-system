<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = "Today's Appointments — " . EP_NAME;
$breadcrumb = [['label'=>'Appointments','url'=>EP_BASE_URL.'/employee/appointments/index.php'],["label"=>"Today"]];
$empId    = (int)($emp['id'] ?? 0);
$branchId = (int)($emp['branch_id'] ?? 0);

// Handle check-in POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $apptId = (int)($_POST['appointment_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($apptId && in_array($action, ['checkin','complete','cancel'], true)) {
        $newStatus = match($action) { 'checkin'=>'In Progress', 'complete'=>'Completed', 'cancel'=>'Cancelled', default=>'Pending' };
        $db = EP_Database::get();
        if ($db) {
            EP_Database::execute("UPDATE appointments SET status=?, updated_at=NOW() WHERE id=?", [$newStatus, $apptId]);
        }
        ep_flash('success', 'Appointment status updated to ' . $newStatus . '.');
    }
    ep_redirect(EP_BASE_URL . '/employee/appointments/today.php');
}

$flashSuccess = ep_get_flash('success');

$appointments = EP_Database::query(
    "SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone AS customer_phone,
            c.email AS customer_email,
            CONCAT(e.first_name,' ',e.last_name) AS officer_name, e.role AS officer_role
     FROM appointments a
     LEFT JOIN customers c ON c.id = a.customer_id
     LEFT JOIN employees e ON e.id = a.assigned_to
     WHERE DATE(a.appointment_date) = CURDATE() AND a.branch_id = ?
     ORDER BY a.appointment_time ASC",
    [$branchId]
) ?: [
    ['id'=>1,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'09:00:00','customer_name'=>'Abebe Girma',   'customer_phone'=>'+251 911 100 200','customer_email'=>'abebe@example.com','purpose'=>'Account Opening',       'status'=>'Confirmed',  'officer_name'=>'Tigist Haile',  'officer_role'=>'Customer Service','notes'=>'Bring national ID and utility bill'],
    ['id'=>2,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'10:30:00','customer_name'=>'Kebede Alemu',  'customer_phone'=>'+251 912 200 300','customer_email'=>'kebede@example.com','purpose'=>'Loan Inquiry',          'status'=>'In Progress','officer_name'=>'Samuel Bekele', 'officer_role'=>'Loan Officer',    'notes'=>'Personal loan application'],
    ['id'=>3,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'13:00:00','customer_name'=>'Hiwot Tadesse', 'customer_phone'=>'+251 913 300 400','customer_email'=>'hiwot@example.com','purpose'=>'Account Upgrade',        'status'=>'Pending',    'officer_name'=>'Meron Tesfaye', 'officer_role'=>'Customer Service','notes'=>''],
    ['id'=>4,'appointment_date'=>date('Y-m-d'),'appointment_time'=>'14:30:00','customer_name'=>'Dawit Mengistu','customer_phone'=>'+251 914 400 500','customer_email'=>'dawit@example.com','purpose'=>'Investment Consultation','status'=>'Completed',  'officer_name'=>'Abebe Girma',   'officer_role'=>'Teller',          'notes'=>'Discussed fixed deposit'],
];

$statusColors = ['Confirmed'=>'#22c55e','In Progress'=>'#3b82f6','Pending'=>'#f59e0b','Completed'=>'#8b5cf6','Cancelled'=>'#ef4444'];
$statusBg     = ['Confirmed'=>'#dcfce7','In Progress'=>'#dbeafe','Pending'=>'#fef9c3','Completed'=>'#ede9fe','Cancelled'=>'#fee2e2'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr no-print">
  <div>
    <h1><i class="fa-solid fa-calendar-day" style="color:var(--teal)"></i> Today's Appointments</h1>
    <p><?= date('l, d F Y') ?> &mdash; <?= count($appointments) ?> scheduled</p>
  </div>
  <div class="ep-page-actions">
    <a href="index.php" class="ep-btn ep-btn-outline no-print"><i class="fa-solid fa-arrow-left"></i> Back</a>
    <button onclick="window.print()" class="ep-btn ep-btn-primary no-print"><i class="fa-solid fa-print"></i> Print</button>
  </div>
</div>

<?php if ($flashSuccess): ?><div class="ep-alert ep-alert-success no-print"><i class="fa-solid fa-circle-check"></i> <?= ep_e($flashSuccess) ?></div><?php endif; ?>

<!-- Print Header (hidden on screen) -->
<div class="print-only" style="display:none;text-align:center;margin-bottom:20px">
  <h2 style="margin:0">Abay Bank — Daily Appointment Schedule</h2>
  <p style="margin:4px 0;color:#555"><?= date('l, d F Y') ?> | Printed: <?= date('H:i') ?></p>
  <hr>
</div>

<?php if (empty($appointments)): ?>
<div class="ep-card">
  <div class="ep-card-body" style="text-align:center;padding:40px;color:var(--muted)">
    <i class="fa-solid fa-calendar-check" style="font-size:2.5rem;color:#22c55e;margin-bottom:10px;display:block"></i>
    <div class="fw-6">No appointments today</div>
  </div>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:12px">
  <?php foreach ($appointments as $idx => $a): ?>
  <?php
    $sc = $statusColors[$a['status']] ?? '#64748b';
    $sbg = $statusBg[$a['status']] ?? '#f1f5f9';
    $num = str_pad((string)($idx + 1), 2, '0', STR_PAD_LEFT);
  ?>
  <div style="display:grid;grid-template-columns:56px 1fr auto;gap:0;border:1px solid var(--border);border-radius:12px;overflow:hidden">
    <!-- Number + Time -->
    <div style="background:var(--teal);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px 8px">
      <div style="font-size:.7rem;opacity:.8">#<?= $num ?></div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-1px"><?= date('H:i', strtotime($a['appointment_time'] ?? '00:00')) ?></div>
    </div>
    <!-- Main Info -->
    <div style="padding:12px 16px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
        <span class="fw-6" style="font-size:.9rem"><?= ep_e($a['customer_name'] ?? '—') ?></span>
        <span style="font-size:.78rem;font-weight:600;color:<?= $sc ?>;background:<?= $sbg ?>;padding:2px 8px;border-radius:20px"><?= ep_e($a['status'] ?? '') ?></span>
      </div>
      <div style="font-size:.82rem;display:flex;flex-wrap:wrap;gap:14px;color:var(--muted)">
        <span><i class="fa-solid fa-tag" style="width:14px"></i> <?= ep_e($a['purpose'] ?? '—') ?></span>
        <span><i class="fa-solid fa-phone" style="width:14px"></i> <?= ep_e($a['customer_phone'] ?? '—') ?></span>
        <span><i class="fa-solid fa-user-tie" style="width:14px"></i> <?= ep_e($a['officer_name'] ?? '—') ?></span>
      </div>
      <?php if (!empty($a['notes'])): ?>
      <div style="margin-top:6px;font-size:.78rem;color:var(--muted)"><i class="fa-solid fa-note-sticky"></i> <?= ep_e($a['notes']) ?></div>
      <?php endif; ?>
    </div>
    <!-- Actions -->
    <div style="padding:12px;display:flex;flex-direction:column;gap:6px;justify-content:center;border-left:1px solid var(--border)" class="no-print">
      <?php if ($a['status'] === 'Confirmed'): ?>
      <form method="POST" style="margin:0">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="appointment_id" value="<?= (int)$a['id'] ?>">
        <button type="submit" name="action" value="checkin" class="ep-btn ep-btn-primary ep-btn-sm" style="width:100%">
          <i class="fa-solid fa-user-check"></i> Check-In
        </button>
      </form>
      <form method="POST" style="margin:0">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="appointment_id" value="<?= (int)$a['id'] ?>">
        <button type="submit" name="action" value="cancel" class="ep-btn ep-btn-ghost ep-btn-sm" style="width:100%;color:#ef4444"
                onclick="return confirm('Cancel this appointment?')">
          <i class="fa-solid fa-xmark"></i> Cancel
        </button>
      </form>
      <?php elseif ($a['status'] === 'In Progress'): ?>
      <form method="POST" style="margin:0">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="appointment_id" value="<?= (int)$a['id'] ?>">
        <button type="submit" name="action" value="complete" class="ep-btn ep-btn-primary ep-btn-sm" style="width:100%;background:#8b5cf6;border-color:#8b5cf6">
          <i class="fa-solid fa-check-double"></i> Complete
        </button>
      </form>
      <?php else: ?>
      <span style="font-size:.78rem;color:var(--muted);text-align:center;padding:6px"><?= ep_e($a['status']) ?></span>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<style>
@media print {
  .no-print { display: none !important; }
  .print-only { display: block !important; }
  body { font-size: 12px; }
}
</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
