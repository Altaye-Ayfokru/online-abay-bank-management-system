<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp   = ep_guard();
$empId = (int)($emp['id'] ?? 0);

// Check if already checked in today
$today = EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $now  = date('H:i:s');
    $date = date('Y-m-d');

    if ($today && $today['check_in']) {
        ep_flash('warning', 'You have already checked in today at ' . $today['check_in']);
    } else {
        $status = (strtotime($now) > strtotime('09:00:00')) ? 'Late' : 'Present';
        if ($today) {
            EP_Database::execute("UPDATE attendance SET check_in=?, status=? WHERE employee_id=? AND date=?", [$now, $status, $empId, $date]);
        } else {
            EP_Database::execute(
                "INSERT INTO attendance (employee_id, date, check_in, status) VALUES (?,?,?,?)",
                [$empId, $date, $now, $status]
            );
        }
        EP_Database::execute(
            "INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())",
            [$empId, "Checked in at $now", 'attendance']
        );
        ep_flash('success', "Checked in at $now. Status: $status");
    }
    header('Location: ' . EP_BASE_URL . '/employee/attendance/index.php'); exit;
}

$pageTitle  = 'Check In — ' . EP_NAME;
$breadcrumb = [['label'=>'Attendance','url'=>EP_BASE_URL.'/employee/attendance/index.php'],['label'=>'Check In']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-right-to-bracket" style="color:var(--teal)"></i> Check In</h1></div>
</div>
<div style="max-width:420px">
  <div class="ep-card">
    <div class="ep-card-body" style="text-align:center;padding:40px 24px">
      <i class="fa-solid fa-clock" style="font-size:3rem;color:var(--teal);margin-bottom:16px;display:block"></i>
      <h3 style="font-size:1.5rem;margin-bottom:4px" id="live-time"><?= date('H:i:s') ?></h3>
      <p style="color:var(--muted);margin-bottom:24px"><?= date('l, d F Y') ?></p>
      <?php if ($today && $today['check_in']): ?>
        <div class="ep-alert ep-alert-warning"><i class="fa-solid fa-triangle-exclamation"></i> Already checked in at <?= ep_e($today['check_in']) ?></div>
        <a href="<?= EP_BASE_URL ?>/employee/attendance/index.php" class="ep-btn ep-btn-outline w-full">Back to Attendance</a>
      <?php else: ?>
        <form method="POST">
          <?= ep_csrf_field() ?>
          <button type="submit" class="ep-btn ep-btn-success" style="width:100%;font-size:1rem;padding:14px"><i class="fa-solid fa-right-to-bracket"></i> Confirm Check In</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>setInterval(()=>{var el=document.getElementById('live-time');if(el)el.textContent=new Date().toLocaleTimeString('en-ET');},1000);</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
