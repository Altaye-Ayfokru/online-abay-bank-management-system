<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp   = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$today = EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $now = date('H:i:s');
    if (!$today || !$today['check_in']) {
        ep_flash('warning', 'You have not checked in today yet.');
    } elseif ($today['check_out']) {
        ep_flash('warning', 'You have already checked out at ' . $today['check_out']);
    } else {
        $inTime  = strtotime($today['check_in']);
        $outTime = strtotime($now);
        $diff    = $outTime - $inTime;
        $hours   = floor($diff/3600) . 'h ' . floor(($diff%3600)/60) . 'm';
        EP_Database::execute("UPDATE attendance SET check_out=?, hours_worked=? WHERE employee_id=? AND date=CURDATE()", [$now, $hours, $empId]);
        EP_Database::execute("INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())", [$empId, "Checked out at $now. Hours: $hours", 'attendance']);
        ep_flash('success', "Checked out at $now. Total hours: $hours");
    }
    header('Location: ' . EP_BASE_URL . '/employee/attendance/index.php'); exit;
}

$pageTitle  = 'Check Out — ' . EP_NAME;
$breadcrumb = [['label'=>'Attendance','url'=>EP_BASE_URL.'/employee/attendance/index.php'],['label'=>'Check Out']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr"><div><h1><i class="fa-solid fa-right-from-bracket" style="color:var(--warn)"></i> Check Out</h1></div></div>
<div style="max-width:420px">
  <div class="ep-card">
    <div class="ep-card-body" style="text-align:center;padding:40px 24px">
      <i class="fa-solid fa-clock" style="font-size:3rem;color:var(--warn);margin-bottom:16px;display:block"></i>
      <h3 style="font-size:1.5rem;margin-bottom:4px" id="live-time"><?= date('H:i:s') ?></h3>
      <p style="color:var(--muted);margin-bottom:8px"><?= date('l, d F Y') ?></p>
      <?php if ($today && $today['check_in']): ?>
        <p style="color:var(--muted);margin-bottom:24px">Checked in at <strong><?= ep_e($today['check_in']) ?></strong></p>
        <?php if ($today['check_out']): ?>
          <div class="ep-alert ep-alert-warning"><i class="fa-solid fa-triangle-exclamation"></i> Already checked out at <?= ep_e($today['check_out']) ?></div>
        <?php else: ?>
          <form method="POST">
            <?= ep_csrf_field() ?>
            <button type="submit" class="ep-btn ep-btn-warning" style="width:100%;font-size:1rem;padding:14px"><i class="fa-solid fa-right-from-bracket"></i> Confirm Check Out</button>
          </form>
        <?php endif; ?>
      <?php else: ?>
        <div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i> You haven't checked in today.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>setInterval(()=>{var el=document.getElementById('live-time');if(el)el.textContent=new Date().toLocaleTimeString('en-ET');},1000);</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
