<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';

$emp = ep_guard();
$pageTitle  = 'Attendance History — ' . EP_NAME;
$breadcrumb = [['label'=>'Attendance','url'=>EP_BASE_URL.'/employee/attendance/index.php'],['label'=>'History']];
$empId = (int)($emp['id'] ?? 0);

$page    = max(1, (int)($_GET['page'] ?? 1));
$month   = $_GET['month'] ?? date('Y-m');
$status  = $_GET['status'] ?? '';

$total = (int)(EP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM attendance WHERE employee_id=? AND DATE_FORMAT(date,'%Y-%m')=?" . ($status ? " AND status=?" : ""),
    $status ? [$empId,$month,$status] : [$empId,$month]
)['c'] ?? 30);

$pag = ep_paginate($total, $page);

$records = EP_Database::query(
    "SELECT * FROM attendance WHERE employee_id=? AND DATE_FORMAT(date,'%Y-%m')=?" . ($status ? " AND status=?" : "") . " ORDER BY date DESC LIMIT ? OFFSET ?",
    $status ? [$empId,$month,$status,$pag['perPage'],$pag['offset']] : [$empId,$month,$pag['perPage'],$pag['offset']]
) ?: array_map(fn($i) => [
    'date'       => date('Y-m-d', strtotime("-$i days")),
    'check_in'   => '08:0' . rand(0,5),
    'check_out'  => '17:0' . rand(0,5),
    'hours_worked'=> '8h ' . rand(10,59) . 'm',
    'status'     => $i%5===2 ? 'Late' : ($i%7===4 ? 'Absent' : 'Present'),
], range(0, 29));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-history" style="color:var(--teal)"></i> Attendance History</h1></div>
  <div class="ep-page-actions"><a href="<?= EP_BASE_URL ?>/employee/attendance/monthly.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-calendar"></i> Monthly View</a></div>
</div>
<!-- Filters -->
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="ep-label">Month</label><input type="month" name="month" class="ep-input" value="<?= ep_e($month) ?>"></div>
      <div><label class="ep-label">Status</label>
        <select name="status" class="ep-select" style="width:140px">
          <option value="">All</option>
          <?php foreach (EP_ATT_STATUSES as $s): ?><option <?= $status===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="<?= EP_BASE_URL ?>/employee/attendance/history.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead><tr><th>Date</th><th>Day</th><th>Check In</th><th>Check Out</th><th>Hours</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($records as $r): ?>
          <tr>
            <td class="fw-6"><?= ep_date($r['date'] ?? '') ?></td>
            <td class="text-muted"><?= $r['date'] ? date('D', strtotime($r['date'])) : '—' ?></td>
            <td><?= ep_e($r['check_in'] ?? '—') ?></td>
            <td><?= ep_e($r['check_out'] ?? '—') ?></td>
            <td><?= ep_e($r['hours_worked'] ?? '—') ?></td>
            <td><?= ep_badge($r['status'] ?? 'Present') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
