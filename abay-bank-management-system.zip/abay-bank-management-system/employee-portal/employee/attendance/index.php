﻿<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp = ep_guard();
$pageTitle  = 'Attendance â€” ' . EP_NAME;
$breadcrumb = [['label'=>'Attendance']];
$needsCharts = true;
$extraJs     = [EP_ASSET_URL . '/js/attendance.js'];
$empId = (int)($emp['id'] ?? 0);

// Today's record
$today = EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId])
      ?? ['check_in'=>null,'check_out'=>null,'status'=>null,'date'=>date('Y-m-d')];

// This month summary
$monthSummary = EP_Database::queryOne(
    "SELECT COUNT(*) AS total, SUM(status='Present') AS present, SUM(status='Late') AS late,
            SUM(status='Absent') AS absent, SUM(status='On Leave') AS on_leave
     FROM attendance WHERE employee_id=? AND MONTH(date)=MONTH(CURDATE()) AND YEAR(date)=YEAR(CURDATE())",
    [$empId]
) ?? ['total'=>22,'present'=>20,'late'=>1,'absent'=>1,'on_leave'=>0];

// Rate
$rate = $monthSummary['total'] > 0
      ? round(($monthSummary['present'] / $monthSummary['total']) * 100)
      : 95;

// Recent records
$records = EP_Database::query(
    "SELECT * FROM attendance WHERE employee_id=? ORDER BY date DESC LIMIT 20",
    [$empId]
) ?: array_map(fn($i) => [
    'date'      => date('Y-m-d', strtotime("-$i days")),
    'check_in'  => '08:0' . rand(0,9),
    'check_out' => '17:0' . rand(0,9),
    'status'    => $i === 3 ? 'Late' : 'Present',
    'hours_worked' => '8h ' . rand(0,59) . 'm',
], range(0, 14));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-calendar-check" style="color:var(--teal)"></i> My Attendance</h1><p>Track your daily attendance, check-in/out, and monthly overview</p></div>
  <div class="ep-page-actions">
    <a href="<?= EP_BASE_URL ?>/employee/attendance/history.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-history"></i> Full History</a>
    <a href="<?= EP_BASE_URL ?>/employee/attendance/monthly.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-calendar"></i> Monthly View</a>
  </div>
</div>

<!-- Today Check-in/out -->
<div class="ep-card" style="border-left:4px solid var(--teal);margin-bottom:20px">
  <div class="ep-card-body">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
      <div>
        <h3 style="font-size:1rem;font-weight:700;color:var(--navy);margin-bottom:4px">
          <i class="fa-solid fa-clock" style="color:var(--teal)"></i> Today â€” <?= date('l, d F Y') ?>
        </h3>
        <p style="font-size:.84rem;color:var(--muted)">
          <?php if ($today['check_in']): ?>
            Checked in at <strong><?= ep_e($today['check_in']) ?></strong>
            <?php if ($today['check_out']): ?> Â· Checked out at <strong><?= ep_e($today['check_out']) ?></strong><?php endif; ?>
          <?php else: ?>
            Not checked in yet
          <?php endif; ?>
        </p>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <?php if (!$today['check_in']): ?>
        <a href="<?= EP_BASE_URL ?>/employee/attendance/check-in.php" class="ep-btn ep-btn-success">
          <i class="fa-solid fa-right-to-bracket"></i> Check In Now
        </a>
        <?php elseif (!$today['check_out']): ?>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="ep-badge ep-badge-success">Checked In <?= ep_e($today['check_in']) ?></span>
          <a href="<?= EP_BASE_URL ?>/employee/attendance/check-out.php" class="ep-btn ep-btn-warning">
            <i class="fa-solid fa-right-from-bracket"></i> Check Out
          </a>
        </div>
        <?php else: ?>
        <div style="display:flex;gap:8px">
          <span class="ep-badge ep-badge-success">In <?= ep_e($today['check_in']) ?></span>
          <span class="ep-badge ep-badge-secondary">Out <?= ep_e($today['check_out']) ?></span>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Month Stats -->
<div class="ep-stats">
  <?php foreach ([
    [(int)$monthSummary['present'],'Present','fa-circle-check','#dcfce7','#16a34a'],
    [(int)$monthSummary['late'],   'Late',   'fa-clock',       '#fef9c3','#b45309'],
    [(int)$monthSummary['absent'], 'Absent', 'fa-circle-xmark','#fee2e2','#dc2626'],
    [(int)$monthSummary['on_leave'],'On Leave','fa-calendar-xmark','#dbeafe','#1d4ed8'],
    [$rate . '%',                  'Rate',   'fa-chart-pie',   '#ede9fe','#7c3aed'],
  ] as [$v,$l,$i,$bg,$c]): ?>
  <div class="ep-stat"><div class="ep-stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
    <div><div class="ep-stat-val"><?= $v ?></div><div class="ep-stat-lbl"><?= $l ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Calendar + Table -->
<div class="ep-grid-2">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3><i class="fa-solid fa-calendar"></i> <?= date('F Y') ?></h3></div>
    <div class="ep-card-body"><div id="attendance-calendar"></div></div>
  </div>
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Recent Attendance Log</h3></div>
    <div class="ep-card-body p0">
      <div class="ep-table-wrap">
        <table class="ep-table">
          <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Hours</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($records as $r): ?>
            <tr>
              <td><?= ep_date($r['date'] ?? '') ?></td>
              <td><?= ep_e($r['check_in'] ?? 'â€”') ?></td>
              <td><?= ep_e($r['check_out'] ?? 'â€”') ?></td>
              <td class="text-muted"><?= ep_e($r['hours_worked'] ?? 'â€”') ?></td>
              <td><?= ep_badge($r['status'] ?? 'Present') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
