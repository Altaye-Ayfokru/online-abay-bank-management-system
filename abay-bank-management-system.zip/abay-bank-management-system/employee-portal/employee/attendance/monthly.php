<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';

$emp = ep_guard();
$pageTitle  = 'Monthly Attendance — ' . EP_NAME;
$breadcrumb = [['label'=>'Attendance','url'=>EP_BASE_URL.'/employee/attendance/index.php'],['label'=>'Monthly']];
$empId = (int)($emp['id'] ?? 0);
$year  = (int)($_GET['year']  ?? date('Y'));
$month = (int)($_GET['month'] ?? date('n'));

$records = EP_Database::query(
    "SELECT date, status FROM attendance WHERE employee_id=? AND MONTH(date)=? AND YEAR(date)=?",
    [$empId, $month, $year]
);
$byDate = [];
foreach ($records as $r) $byDate[$r['date']] = $r['status'];

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$firstDay    = date('N', mktime(0,0,0,$month,1,$year)); // 1=Mon, 7=Sun

$statusColors = ['Present'=>'#22c55e','Late'=>'#f59e0b','Absent'=>'#ef4444','On Leave'=>'#3b82f6','Holiday'=>'#7c3aed'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-calendar" style="color:var(--teal)"></i> Monthly Attendance</h1></div>
  <form method="GET" style="display:flex;gap:8px;align-items:center">
    <select name="month" class="ep-select ep-select" style="width:130px">
      <?php for ($m=1;$m<=12;$m++): ?><option value="<?= $m ?>" <?= $m===$month?'selected':'' ?>><?= date('F',mktime(0,0,0,$m,1)) ?></option><?php endfor; ?>
    </select>
    <select name="year" class="ep-select" style="width:90px">
      <?php for ($y=date('Y');$y>=date('Y')-3;$y--): ?><option value="<?= $y ?>" <?= $y===$year?'selected':'' ?>><?= $y ?></option><?php endfor; ?>
    </select>
    <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i></button>
  </form>
</div>

<div class="ep-card">
  <div class="ep-card-hdr"><h3><?= date('F Y', mktime(0,0,0,$month,1,$year)) ?></h3>
    <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:.78rem">
      <?php foreach ($statusColors as $s=>$c): ?><span style="display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:3px;background:<?= $c ?>"></span><?= $s ?></span><?php endforeach; ?>
      <span style="display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:3px;background:#f1f5f9"></span>Weekend</span>
    </div>
  </div>
  <div class="ep-card-body">
    <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px">
      <?php foreach (['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $d): ?>
      <div style="text-align:center;font-size:.72rem;font-weight:700;color:var(--muted);padding:6px"><?= $d ?></div>
      <?php endforeach; ?>
      <?php for ($i=1; $i<$firstDay; $i++): ?><div></div><?php endfor; ?>
      <?php for ($d=1; $d<=$daysInMonth; $d++):
        $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $d);
        $dow     = date('N', mktime(0,0,0,$month,$d,$year));
        $isWkend = $dow >= 6;
        $status  = $byDate[$dateStr] ?? ($isWkend ? 'Weekend' : ($dateStr < date('Y-m-d') ? 'Present' : ''));
        $bg      = $isWkend ? '#f1f5f9' : ($statusColors[$status] ?? ($dateStr === date('Y-m-d') ? '#e0f5f7' : '#fff'));
        $border  = $dateStr === date('Y-m-d') ? '2px solid #1B3A5C' : '1px solid #e2e8f0';
        $short   = ['Present'=>'P','Late'=>'L','Absent'=>'A','On Leave'=>'OL','Holiday'=>'H','Weekend'=>''][$status] ?? '';
      ?>
      <div style="text-align:center;padding:8px 4px;border-radius:9px;background:<?= $bg ?>;border:<?= $border ?>;min-height:52px;display:flex;flex-direction:column;align-items:center;justify-content:center">
        <div style="font-size:.82rem;font-weight:700;color:<?= $isWkend?'#94a3b8':'#1e293b' ?>"><?= $d ?></div>
        <?php if ($short): ?><div style="font-size:.6rem;font-weight:700;color:<?= $bg==='#fff'?'#64748b':'#fff' ?>;margin-top:2px"><?= $short ?></div><?php endif; ?>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
