<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'My Branch — ' . EP_NAME;
$breadcrumb = [['label'=>'Branch']];
$empId    = (int)($emp['id'] ?? 0);
$branchId = (int)($emp['branch_id'] ?? 0);

$branch = EP_Database::queryOne(
    "SELECT b.*, CONCAT(m.first_name,' ',m.last_name) AS manager_name, m.email AS manager_email, m.phone AS manager_phone,
            (SELECT COUNT(*) FROM employees WHERE branch_id=b.id AND status='Active') AS emp_count,
            (SELECT COUNT(*) FROM accounts   WHERE branch_id=b.id AND status='Active') AS acc_count,
            (SELECT COUNT(*) FROM loans      WHERE branch_id=b.id AND status='Active') AS loan_count
     FROM branches b
     LEFT JOIN employees m ON m.id = b.manager_id
     WHERE b.id = ?",
    [$branchId]
) ?: [
    'id'=>1,'name'=>'Head Office','code'=>'HO-001','address'=>'Bole Road, Addis Ababa','phone'=>'+251 111 234 567',
    'email'=>'headoffice@abaybank.com','status'=>'Active','established_date'=>'2005-03-15',
    'manager_name'=>'Dawit Mengistu','manager_email'=>'dawit@abaybank.com','manager_phone'=>'+251 911 000 001',
    'emp_count'=>45,'acc_count'=>2840,'loan_count'=>187,
];

$employees = EP_Database::query(
    "SELECT id, employee_number, first_name, last_name, role, position, status, hire_date
     FROM employees WHERE branch_id = ? AND status = 'Active' ORDER BY first_name, last_name",
    [$branchId]
) ?: [
    ['id'=>1,'employee_number'=>'EMP-000001','first_name'=>'Abebe',  'last_name'=>'Girma',  'role'=>'Teller',          'position'=>'Senior Teller',  'status'=>'Active','hire_date'=>'2019-03-01'],
    ['id'=>2,'employee_number'=>'EMP-000002','first_name'=>'Tigist', 'last_name'=>'Haile',  'role'=>'Loan Officer',    'position'=>'Loan Officer',   'status'=>'Active','hire_date'=>'2020-07-15'],
    ['id'=>3,'employee_number'=>'EMP-000003','first_name'=>'Samuel', 'last_name'=>'Bekele', 'role'=>'IT Staff',        'position'=>'IT Technician',  'status'=>'Active','hire_date'=>'2021-01-10'],
    ['id'=>4,'employee_number'=>'EMP-000004','first_name'=>'Meron',  'last_name'=>'Tesfaye','role'=>'Customer Service','position'=>'CS Officer',     'status'=>'Active','hire_date'=>'2022-04-05'],
    ['id'=>5,'employee_number'=>'EMP-000005','first_name'=>'Dawit',  'last_name'=>'Mengistu','role'=>'Branch Manager', 'position'=>'Branch Manager', 'status'=>'Active','hire_date'=>'2015-06-01'],
];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-building" style="color:var(--teal)"></i> <?= ep_e($branch['name'] ?? 'My Branch') ?></h1>
    <p><?= ep_e($branch['address'] ?? '') ?></p>
  </div>
  <div class="ep-page-actions">
    <?= ep_badge($branch['status'] ?? 'Active') ?>
  </div>
</div>

<!-- Stats -->
<div class="ep-stats" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:20px">
  <?php foreach ([
    ['Employees',   ep_num((int)($branch['emp_count']  ?? 0)), 'fa-users',           '#22c55e','#dcfce7'],
    ['Accounts',    ep_num((int)($branch['acc_count']  ?? 0)), 'fa-building-columns','#3b82f6','#dbeafe'],
    ['Active Loans',ep_num((int)($branch['loan_count'] ?? 0)), 'fa-file-invoice',    '#8b5cf6','#ede9fe'],
    ['Branch Code', ep_e($branch['code'] ?? '—'),              'fa-id-card',         '#f59e0b','#fef9c3'],
  ] as [$lbl,$val,$icon,$color,$bg]): ?>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:<?= $bg ?>;color:<?= $color ?>"><i class="fa-solid <?= $icon ?>"></i></div>
    <div>
      <div class="ep-stat-val" style="color:<?= $color ?>"><?= $val ?></div>
      <div class="ep-stat-lbl"><?= $lbl ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="ep-grid-2" style="align-items:start">
  <!-- Branch Info -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Branch Information</h3></div>
    <div class="ep-card-body">
      <?php foreach ([
        ['Branch Name',    $branch['name']   ?? '—'],
        ['Branch Code',    $branch['code']   ?? '—'],
        ['Address',        $branch['address'] ?? '—'],
        ['Phone',          $branch['phone']  ?? '—'],
        ['Email',          $branch['email']  ?? '—'],
        ['Established',    ep_date($branch['established_date'] ?? '')],
      ] as [$l,$v]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem;gap:12px">
        <span class="text-muted" style="white-space:nowrap"><?= $l ?></span>
        <span class="fw-6" style="text-align:right"><?= ep_e($v) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Manager Info -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Branch Manager</h3></div>
    <div class="ep-card-body">
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
        <div style="width:56px;height:56px;border-radius:50%;background:var(--teal);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.2rem">
          <?= strtoupper(substr($branch['manager_name'] ?? '?', 0, 1)) ?>
        </div>
        <div>
          <div class="fw-6" style="font-size:.95rem"><?= ep_e($branch['manager_name'] ?? '—') ?></div>
          <div style="font-size:.8rem;color:var(--muted)">Branch Manager</div>
        </div>
      </div>
      <?php foreach ([['Email',$branch['manager_email']??'—'],['Phone',$branch['manager_phone']??'—']] as [$l,$v]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem">
        <span class="text-muted"><?= $l ?></span><span class="fw-6"><?= ep_e($v) ?></span>
      </div>
      <?php endforeach; ?>
      <div style="margin-top:14px">
        <a href="<?= EP_BASE_URL ?>/employee/messages/compose.php?to=manager" class="ep-btn ep-btn-outline" style="width:100%">
          <i class="fa-solid fa-envelope"></i> Send Message
        </a>
      </div>
    </div>
  </div>
</div>

<!-- Branch Employees -->
<div class="ep-card" style="margin-top:20px">
  <div class="ep-card-hdr">
    <h3><i class="fa-solid fa-users" style="color:var(--teal)"></i> Branch Staff</h3>
    <span class="ep-badge ep-badge-info"><?= count($employees) ?> active</span>
  </div>
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr><th>Employee #</th><th>Name</th><th>Role</th><th>Position</th><th>Joined</th><th>Status</th></tr>
        </thead>
        <tbody>
          <?php foreach ($employees as $e): ?>
          <tr>
            <td><code style="font-size:.78rem"><?= ep_e($e['employee_number'] ?? '—') ?></code></td>
            <td>
              <div class="fw-6" style="font-size:.84rem"><?= ep_e(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?></div>
            </td>
            <td style="font-size:.82rem"><?= ep_e($e['role'] ?? '—') ?></td>
            <td style="font-size:.82rem;color:var(--muted)"><?= ep_e($e['position'] ?? '—') ?></td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($e['hire_date'] ?? '') ?></td>
            <td><?= ep_badge($e['status'] ?? 'Active') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
