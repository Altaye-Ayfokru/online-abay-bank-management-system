<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Complaints — ' . EP_NAME;
$breadcrumb = [['label'=>'Complaints']];
$empId    = (int)($emp['id'] ?? 0);
$branchId = (int)($emp['branch_id'] ?? 0);

$page         = max(1, (int)($_GET['page']   ?? 1));
$statusFilter = $_GET['status']   ?? '';
$priority     = $_GET['priority'] ?? '';
$search       = trim($_GET['search'] ?? '');

$where  = "WHERE 1=1";
$params = [];
if ($branchId) { $where .= " AND cp.branch_id = ?"; $params[] = $branchId; }
if ($statusFilter) { $where .= " AND cp.status = ?";   $params[] = $statusFilter; }
if ($priority)     { $where .= " AND cp.priority = ?"; $params[] = $priority; }
if ($search)       {
    $where .= " AND (cp.ticket_number LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR cp.issue_type LIKE ?)";
    $s = "%$search%"; $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
}

$total = (int)(EP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM complaints cp LEFT JOIN customers c ON c.id=cp.customer_id $where", $params
)['c'] ?? 0);
$pag = ep_paginate($total, $page);

$pParams = array_merge($params, [$pag['perPage'], $pag['offset']]);
$complaints = EP_Database::query(
    "SELECT cp.id, cp.ticket_number, cp.issue_type, cp.priority, cp.status, cp.created_at,
            CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
     FROM complaints cp
     LEFT JOIN customers c ON c.id = cp.customer_id
     $where ORDER BY cp.created_at DESC LIMIT ? OFFSET ?",
    $pParams
) ?: [
    ['id'=>1,'ticket_number'=>'TKT-2026-001','issue_type'=>'Account Freeze',      'priority'=>'High',   'status'=>'Pending',     'customer_name'=>'Abebe Girma',  'phone'=>'+251 911 100 200','created_at'=>date('Y-m-d H:i:s',strtotime('-2 hours'))],
    ['id'=>2,'ticket_number'=>'TKT-2026-002','issue_type'=>'Wrong Charge',        'priority'=>'Medium', 'status'=>'In Progress', 'customer_name'=>'Tigist Haile', 'phone'=>'+251 912 300 400','created_at'=>date('Y-m-d H:i:s',strtotime('-1 day'))],
    ['id'=>3,'ticket_number'=>'TKT-2026-003','issue_type'=>'ATM Issue',           'priority'=>'Low',    'status'=>'Pending',     'customer_name'=>'Samuel Bekele','phone'=>'+251 913 500 600','created_at'=>date('Y-m-d H:i:s',strtotime('-2 days'))],
    ['id'=>4,'ticket_number'=>'TKT-2026-004','issue_type'=>'Online Banking Error','priority'=>'Critical','status'=>'Pending',    'customer_name'=>'Meron Tesfaye','phone'=>'+251 914 700 800','created_at'=>date('Y-m-d H:i:s',strtotime('-3 days'))],
    ['id'=>5,'ticket_number'=>'TKT-2026-005','issue_type'=>'Loan Query',          'priority'=>'Low',    'status'=>'Review',      'customer_name'=>'Dawit Mengistu','phone'=>'+251 915 900 000','created_at'=>date('Y-m-d H:i:s',strtotime('-5 days'))],
];

$priorityColors = ['Critical'=>'#ef4444','High'=>'#f59e0b','Medium'=>'#3b82f6','Low'=>'#22c55e'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-circle-exclamation" style="color:var(--teal)"></i> Complaints</h1>
    <p>Branch complaints and customer issues</p>
  </div>
</div>

<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div>
        <label class="ep-label">Status</label>
        <select name="status" class="ep-select" style="width:140px">
          <option value="">All Statuses</option>
          <?php foreach (['Pending','In Progress','Review','Resolved','Closed'] as $s): ?>
          <option value="<?= $s ?>" <?= $statusFilter===$s?'selected':'' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="ep-label">Priority</label>
        <select name="priority" class="ep-select" style="width:120px">
          <option value="">All</option>
          <?php foreach (['Critical','High','Medium','Low'] as $p): ?>
          <option value="<?= $p ?>" <?= $priority===$p?'selected':'' ?>><?= $p ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="ep-label">Search</label>
        <input type="text" name="search" class="ep-input ep-inp-noi" value="<?= ep_e($search) ?>"
               placeholder="Ticket # or customer" style="width:200px">
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="index.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>

<div class="ep-card">
  <div class="ep-card-hdr">
    <h3>Complaints <span style="font-size:.8rem;font-weight:400;color:var(--muted)">(<?= number_format($total) ?> total)</span></h3>
  </div>
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr>
            <th>Ticket #</th>
            <th>Customer</th>
            <th>Issue Type</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($complaints)): ?>
          <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--muted)">No complaints found</td></tr>
          <?php else: ?>
          <?php foreach ($complaints as $cp): ?>
          <?php $pc = $priorityColors[$cp['priority'] ?? ''] ?? '#64748b'; ?>
          <tr>
            <td>
              <a href="view.php?id=<?= (int)$cp['id'] ?>" class="fw-6" style="font-size:.82rem;font-family:monospace;color:var(--teal);text-decoration:none">
                <?= ep_e($cp['ticket_number']) ?>
              </a>
            </td>
            <td>
              <div class="fw-6" style="font-size:.84rem"><?= ep_e($cp['customer_name']) ?></div>
              <div style="font-size:.76rem;color:var(--muted)"><?= ep_e($cp['phone'] ?? '') ?></div>
            </td>
            <td style="font-size:.83rem"><?= ep_e($cp['issue_type'] ?? '—') ?></td>
            <td>
              <span style="font-size:.8rem;font-weight:600;color:<?= $pc ?>">
                <i class="fa-solid fa-circle-dot"></i> <?= ep_e($cp['priority'] ?? '—') ?>
              </span>
            </td>
            <td><?= ep_badge($cp['status'] ?? '') ?></td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_ago($cp['created_at'] ?? '') ?></td>
            <td>
              <a href="view.php?id=<?= (int)$cp['id'] ?>" class="ep-btn ep-btn-ghost ep-btn-sm">
                <i class="fa-solid fa-eye"></i> View
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
