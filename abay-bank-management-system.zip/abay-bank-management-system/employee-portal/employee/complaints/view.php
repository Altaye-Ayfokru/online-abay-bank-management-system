<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$cpId  = (int)($_GET['id'] ?? 0);

if (!$cpId) {
    ep_flash('danger', 'Invalid complaint ID.');
    ep_redirect(EP_BASE_URL . '/employee/complaints/index.php');
}

$complaint = EP_Database::queryOne(
    "SELECT cp.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name,
            c.email AS customer_email, c.phone AS customer_phone, c.account_number
     FROM complaints cp
     LEFT JOIN customers c ON c.id = cp.customer_id
     WHERE cp.id = ?",
    [$cpId]
) ?: [
    'id'=>$cpId,'ticket_number'=>'TKT-2026-001','issue_type'=>'Account Freeze',
    'priority'=>'High','status'=>'Pending','description'=>'Customer reports their account was frozen without notice. They are unable to perform any transactions and urgently need the account reactivated.',
    'customer_name'=>'Abebe Girma','customer_email'=>'abebe.girma@example.com',
    'customer_phone'=>'+251 911 100 200','account_number'=>'1000012345678',
    'created_at'=>date('Y-m-d H:i:s',strtotime('-2 hours')),
    'branch_id'=>1,
];

$responses = EP_Database::query(
    "SELECT cr.*, CONCAT(e.first_name,' ',e.last_name) AS responder_name, e.role AS responder_role
     FROM complaint_responses cr
     LEFT JOIN employees e ON e.id = cr.employee_id
     WHERE cr.complaint_id = ? ORDER BY cr.created_at ASC",
    [$cpId]
) ?: [
    ['id'=>1,'message'=>'We have received your complaint and are investigating the account freeze. We will update you within 24 hours.',
     'responder_name'=>'Meron Tesfaye','responder_role'=>'Customer Service','created_at'=>date('Y-m-d H:i:s',strtotime('-1 hour')),'is_internal'=>0],
];

$success = ep_get_flash('success');
$error   = ep_get_flash('danger');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $action  = $_POST['action']  ?? 'respond';
    $message = trim($_POST['message'] ?? '');
    $newStatus = trim($_POST['new_status'] ?? '');

    if ($action === 'respond') {
        if (!$message) {
            ep_flash('danger', 'Response message is required.');
        } else {
            $db = EP_Database::get();
            if ($db) {
                EP_Database::execute(
                    "INSERT INTO complaint_responses (complaint_id,employee_id,message,is_internal,created_at) VALUES (?,?,?,0,NOW())",
                    [$cpId, $empId, $message]
                );
                if ($newStatus) {
                    EP_Database::execute("UPDATE complaints SET status=?, updated_at=NOW() WHERE id=?", [$newStatus, $cpId]);
                }
                EP_Database::execute(
                    "INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",
                    [$empId, "Responded to complaint $cpId", 'complaint']
                );
            }
            ep_flash('success', 'Response submitted successfully.');
        }
    }
    ep_redirect(EP_BASE_URL . '/employee/complaints/view.php?id=' . $cpId);
}

$pageTitle  = 'Complaint ' . ep_e($complaint['ticket_number'] ?? $cpId) . ' — ' . EP_NAME;
$breadcrumb = [['label'=>'Complaints','url'=>EP_BASE_URL.'/employee/complaints/index.php'],['label'=>ep_e($complaint['ticket_number'] ?? '')]];
$priorityColors = ['Critical'=>'#ef4444','High'=>'#f59e0b','Medium'=>'#3b82f6','Low'=>'#22c55e'];
$pc = $priorityColors[$complaint['priority'] ?? ''] ?? '#64748b';

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-circle-exclamation" style="color:var(--teal)"></i>
        <?= ep_e($complaint['ticket_number'] ?? 'Complaint') ?></h1>
    <p><?= ep_e($complaint['issue_type'] ?? '') ?></p>
  </div>
  <div class="ep-page-actions">
    <a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>

<?php if ($success): ?><div class="ep-alert ep-alert-success"><i class="fa-solid fa-circle-check"></i> <?= ep_e($success) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= ep_e($error) ?></div><?php endif; ?>

<div class="ep-grid-2" style="align-items:start">
  <!-- Complaint Details -->
  <div class="ep-card">
    <div class="ep-card-hdr">
      <h3>Complaint Details</h3>
      <div style="display:flex;gap:8px;align-items:center">
        <span style="font-size:.8rem;font-weight:600;color:<?= $pc ?>"><i class="fa-solid fa-circle-dot"></i> <?= ep_e($complaint['priority'] ?? '') ?></span>
        <?= ep_badge($complaint['status'] ?? '') ?>
      </div>
    </div>
    <div class="ep-card-body">
      <?php foreach ([
        ['Ticket #',   $complaint['ticket_number'] ?? '—'],
        ['Issue Type', $complaint['issue_type']    ?? '—'],
        ['Submitted',  ep_date($complaint['created_at'] ?? '')],
      ] as [$l,$v]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem">
        <span class="text-muted"><?= $l ?></span><span class="fw-6"><?= ep_e($v) ?></span>
      </div>
      <?php endforeach; ?>
      <div style="margin-top:14px">
        <div class="ep-label" style="margin-bottom:6px">Description</div>
        <p style="font-size:.84rem;line-height:1.6;color:var(--text)"><?= nl2br(ep_e($complaint['description'] ?? '')) ?></p>
      </div>
    </div>
  </div>

  <!-- Customer Info -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Customer</h3></div>
    <div class="ep-card-body">
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
        <div style="width:48px;height:48px;border-radius:50%;background:var(--teal);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem">
          <?= strtoupper(substr($complaint['customer_name'] ?? '?', 0, 1)) ?>
        </div>
        <div>
          <div class="fw-6"><?= ep_e($complaint['customer_name'] ?? '—') ?></div>
          <div style="font-size:.8rem;color:var(--muted)"><?= ep_e($complaint['customer_email'] ?? '') ?></div>
        </div>
      </div>
      <?php foreach ([['Phone',$complaint['customer_phone']??'—'],['Account',$complaint['account_number']??'—']] as [$l,$v]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem">
        <span class="text-muted"><?= $l ?></span><span class="fw-6 font-mono"><?= ep_e($v) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Conversation Thread -->
<div class="ep-card" style="margin-top:20px">
  <div class="ep-card-hdr"><h3><i class="fa-solid fa-comments" style="color:var(--teal)"></i> Conversation</h3></div>
  <div class="ep-card-body">
    <?php if (empty($responses)): ?>
    <div style="text-align:center;padding:24px;color:var(--muted)">
      <i class="fa-solid fa-comment-slash" style="font-size:1.5rem;margin-bottom:8px;display:block"></i>
      No responses yet. Be the first to respond.
    </div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:16px;margin-bottom:20px">
      <?php foreach ($responses as $r): ?>
      <div style="background:var(--surface);border-radius:10px;padding:14px 16px;border-left:3px solid var(--teal)">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px">
          <span class="fw-6" style="font-size:.84rem"><?= ep_e($r['responder_name'] ?? 'Support Agent') ?>
            <span style="font-weight:400;color:var(--muted)">&bull; <?= ep_e($r['responder_role'] ?? '') ?></span>
          </span>
          <span style="font-size:.76rem;color:var(--muted)"><?= ep_ago($r['created_at'] ?? '') ?></span>
        </div>
        <p style="font-size:.84rem;line-height:1.6;margin:0"><?= nl2br(ep_e($r['message'] ?? '')) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Response Form -->
    <div style="border-top:1px solid var(--border);padding-top:18px">
      <h4 style="margin:0 0 14px;font-size:.9rem">Add Response</h4>
      <form method="POST">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="action" value="respond">
        <div class="ep-form-group">
          <label class="ep-label">Message <span class="req">*</span></label>
          <textarea name="message" class="ep-textarea" rows="4" required
                    placeholder="Type your response to the customer..."></textarea>
        </div>
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
          <div class="ep-form-group" style="flex:1;min-width:160px;margin-bottom:0">
            <label class="ep-label">Update Status</label>
            <select name="new_status" class="ep-select">
              <option value="">Keep Current</option>
              <?php foreach (['In Progress','Review','Resolved','Closed'] as $s): ?>
              <option value="<?= $s ?>"><?= $s ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="ep-btn ep-btn-primary" style="margin-top:18px">
            <i class="fa-solid fa-paper-plane"></i> Send Response
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
