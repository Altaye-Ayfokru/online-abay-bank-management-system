<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'New Customer — ' . EP_NAME;
$breadcrumb = [['label'=>'Customers','url'=>EP_BASE_URL.'/employee/customers/index.php'],['label'=>'New']];
$empId  = (int)($emp['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $fn    = trim($_POST['first_name'] ?? '');
    $ln    = trim($_POST['last_name']  ?? '');
    $phone = trim($_POST['phone']      ?? '');
    $email = trim($_POST['email']      ?? '');
    $dob   = trim($_POST['dob']        ?? '');
    $gender= trim($_POST['gender']     ?? '');
    $addr  = trim($_POST['address']    ?? '');
    $nid   = trim($_POST['national_id']?? '');
    $branchId = (int)($_POST['branch_id'] ?? 1);

    if (!$fn) $errors[] = 'First name is required.';
    if (!$ln) $errors[] = 'Last name is required.';
    if (!$phone) $errors[] = 'Phone is required.';
    if (!$nid) $errors[] = 'National ID is required.';

    if (!$errors) {
        $custNo = 'CUST-' . strtoupper(substr(uniqid('',true),-7));
        EP_Database::execute(
            "INSERT INTO customers (customer_number,first_name,last_name,phone,email,date_of_birth,gender,address,national_id,branch_id,kyc_status,status,created_by,created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,'Pending','Active',?,NOW())",
            [$custNo,$fn,$ln,$phone,$email,$dob?:null,$gender,$addr,$nid,$branchId,$empId]
        );
        EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())", [$empId,"Customer created: $fn $ln ($custNo)",'customer']);
        ep_flash('success', "Customer $fn $ln registered. ID: $custNo");
        header('Location: ' . EP_BASE_URL . '/employee/customers/index.php'); exit;
    }
}
$branches = EP_Database::query("SELECT id, branch_name FROM branches WHERE status='Active' ORDER BY branch_name")
         ?: [['id'=>1,'branch_name'=>'Head Office'],['id'=>2,'branch_name'=>'Bole Branch'],['id'=>3,'branch_name'=>'Alem Ketema Branch'],['id'=>4,'branch_name'=>'Kirkos Branch'],['id'=>5,'branch_name'=>'Bahir Dar Branch'],['id'=>6,'branch_name'=>'Hawassa Branch'],['id'=>7,'branch_name'=>'Dire Dawa Branch'],['id'=>8,'branch_name'=>'Mekelle Branch']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-user-plus" style="color:var(--teal)"></i> Register Customer</h1></div>
  <div class="ep-page-actions"><a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>
<div style="max-width:700px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Customer Information</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-row">
          <div class="ep-form-group"><label class="ep-label">First Name <span class="req">*</span></label><input type="text" name="first_name" class="ep-input ep-inp-noi" required value="<?= ep_e($_POST['first_name']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Last Name <span class="req">*</span></label><input type="text" name="last_name" class="ep-input ep-inp-noi" required value="<?= ep_e($_POST['last_name']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Phone <span class="req">*</span></label><input type="tel" name="phone" class="ep-input ep-inp-noi" required placeholder="+251 9XX XXX XXX" value="<?= ep_e($_POST['phone']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Email</label><input type="email" name="email" class="ep-input ep-inp-noi" value="<?= ep_e($_POST['email']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Date of Birth</label><input type="date" name="dob" class="ep-input" value="<?= ep_e($_POST['dob']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Gender</label>
            <select name="gender" class="ep-select"><option value="">Select…</option><option>Male</option><option>Female</option></select></div>
          <div class="ep-form-group"><label class="ep-label">National ID <span class="req">*</span></label><input type="text" name="national_id" class="ep-input ep-inp-noi" required value="<?= ep_e($_POST['national_id']??'') ?>"></div>
          <div class="ep-form-group"><label class="ep-label">Branch</label>
            <select name="branch_id" class="ep-select"><?php foreach ($branches as $b): ?><option value="<?= $b['id'] ?>"><?= ep_e($b['branch_name']) ?></option><?php endforeach; ?></select></div>
          <div class="ep-form-group ep-form-full"><label class="ep-label">Address</label><textarea name="address" class="ep-textarea" rows="2"><?= ep_e($_POST['address']??'') ?></textarea></div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
          <a href="index.php" class="ep-btn ep-btn-outline">Cancel</a>
          <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-user-plus"></i> Register Customer</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
