<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Customers — ' . EP_NAME;
$breadcrumb = [['label'=>'Customers']];
$page   = max(1,(int)($_GET['page']??1));
$search = trim($_GET['q'] ?? '');
$pag    = ep_paginate(0, $page); // will update after count

$where = "1=1"; $params = [];
if ($search) { $where .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.phone LIKE ? OR c.customer_number LIKE ?)"; $s="%$search%"; $params=[$s,$s,$s,$s]; }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM customers c WHERE $where", $params)['c'] ?? 10);
$pag   = ep_paginate($total, $page);
$customers = EP_Database::query(
    "SELECT c.*, b.branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id WHERE $where ORDER BY c.created_at DESC LIMIT ? OFFSET ?",
    [...$params, $pag['perPage'], $pag['offset']]
) ?: ep_demo_employees(); // fallback to demo data

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-users" style="color:var(--teal)"></i> Customers</h1></div>
  <div class="ep-page-actions">
    <a href="<?= EP_BASE_URL ?>/employee/customers/create.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-user-plus"></i> New Customer</a>
  </div>
</div>
<!-- Search -->
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:10px">
      <div class="ep-inp-wrap" style="flex:1"><i class="fa-solid fa-search ep-inp-ic"></i>
        <input type="text" name="q" class="ep-input" placeholder="Search by name, phone, customer ID…" value="<?= ep_e($search) ?>">
      </div>
      <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-search"></i> Search</button>
      <?php if ($search): ?><a href="index.php" class="ep-btn ep-btn-outline">Clear</a><?php endif; ?>
    </form>
  </div>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Customer</th><th>ID</th><th>Phone</th><th>Branch</th><th>KYC</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($customers as $c): ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="ep-avatar ep-av-sm" style="background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff;flex-shrink:0"><?= strtoupper(substr($c['first_name']??$c['username']??'?',0,1)) ?></div>
              <div><div class="fw-6" style="font-size:.85rem"><?= ep_e(($c['first_name']??'').' '.($c['last_name']??'')) ?></div><div style="font-size:.75rem;color:var(--muted)"><?= ep_e($c['email']??'') ?></div></div>
            </div>
          </td>
          <td style="font-family:monospace;font-size:.82rem"><?= ep_e($c['customer_number']??$c['employee_number']??'—') ?></td>
          <td><?= ep_e($c['phone']??'—') ?></td>
          <td><?= ep_e($c['branch_name']??'—') ?></td>
          <td><?= ep_badge($c['kyc_status']??'Pending') ?></td>
          <td><?= ep_badge($c['status']??'Active') ?></td>
          <td>
            <a href="view.php?id=<?= (int)($c['id']??0) ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-eye"></i></a>
            <a href="update.php?id=<?= (int)($c['id']??0) ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-pen"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
