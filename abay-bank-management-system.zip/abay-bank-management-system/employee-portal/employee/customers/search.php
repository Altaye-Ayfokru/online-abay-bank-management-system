<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$q = trim($_GET['q'] ?? '');
// If AJAX request return JSON
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    $results = EP_Database::query(
        "SELECT id, customer_number, first_name, last_name, phone, kyc_status FROM customers WHERE first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR customer_number LIKE ? LIMIT 10",
        ["%$q%","%$q%","%$q%","%$q%"]
    ) ?: [];
    echo json_encode(['success'=>true,'data'=>$results]); exit;
}
// HTML redirect to customer list with search
header('Location: ' . EP_BASE_URL . '/employee/customers/index.php?q=' . urlencode($q)); exit;
