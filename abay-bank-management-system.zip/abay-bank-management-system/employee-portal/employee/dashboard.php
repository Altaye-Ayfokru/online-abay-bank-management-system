<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once dirname(__DIR__) . '/middleware/csrf.php';

$emp = ep_guard();
$pageTitle  = 'Dashboard — ' . EP_NAME;
$breadcrumb = [['label' => 'Dashboard']];
$needsCharts = true;
$extraJs     = [EP_ASSET_URL . '/js/attendance.js'];

// --- Data ---
$db   = EP_Database::get();
$live = $db !== null;

// Stats
$empId = (int)($emp['id'] ?? 0);

$attendanceThisMonth = EP_Database::queryOne(
  "SELECT COUNT(*) AS present, SUM(status='Late') AS late, SUM(status='Absent') AS absent
     FROM attendance WHERE employee_id=? AND MONTH(date)=MONTH(CURDATE()) AND YEAR(date)=YEAR(CURDATE())",
  [$empId]
) ?? ['present' => 20, 'late' => 1, 'absent' => 1];

$leaveBalance = EP_Database::queryOne(
  "SELECT annual_remaining, sick_remaining FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())",
  [$empId]
) ?? ['annual_remaining' => 12, 'sick_remaining' => 8];

$pendingTasks = (int)(EP_Database::queryOne(
  "SELECT COUNT(*) AS c FROM employee_tasks WHERE assigned_to=? AND status IN('Pending','In Progress')",
  [$empId]
)['c'] ?? 3);

$lastPayslip = EP_Database::queryOne(
  "SELECT net_salary, pay_period FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT 1",
  [$empId]
) ?? ['net_salary' => (float)($emp['basic_salary'] ?? 18500) * 0.845, 'pay_period' => date('Y-m', strtotime('-1 month'))];

// Recent activity
$recentActivity = EP_Database::query(
  "SELECT description, created_at, type FROM employee_activity_log WHERE employee_id=? ORDER BY created_at DESC LIMIT 8",
  [$empId]
) ?: [
  ['description' => 'Checked in at 08:02', 'created_at' => date('Y-m-d H:i:s', time() - 3600), 'type' => 'attendance'],
  ['description' => 'Transaction: Deposit ETB 5,000 to ACC-001234', 'created_at' => date('Y-m-d H:i:s', time() - 7200), 'type' => 'transaction'],
  ['description' => 'KYC document verified for Abebe T.', 'created_at' => date('Y-m-d H:i:s', time() - 10800), 'type' => 'kyc'],
  ['description' => 'Leave request submitted', 'created_at' => date('Y-m-d H:i:s', time() - 86400), 'type' => 'leave'],
  ['description' => 'Customer account opened: ACC-009823', 'created_at' => date('Y-m-d H:i:s', time() - 90000), 'type' => 'account'],
];

// Pending tasks
$tasks = EP_Database::query(
  "SELECT * FROM employee_tasks WHERE assigned_to=? AND status IN('Pending','In Progress') ORDER BY priority DESC, due_date ASC LIMIT 6",
  [$empId]
) ?: [
  ['id' => 1, 'title' => 'Process KYC verification for 3 customers', 'priority' => 'High', 'due_date' => date('Y-m-d'), 'status' => 'Pending'],
  ['id' => 2, 'title' => 'Review loan application LN-00234', 'priority' => 'Critical', 'due_date' => date('Y-m-d'), 'status' => 'In Progress'],
  ['id' => 3, 'title' => 'Monthly transaction report submission', 'priority' => 'Medium', 'due_date' => date('Y-m-d', strtotime('+2 days')), 'status' => 'Pending'],
  ['id' => 4, 'title' => 'Customer complaint follow-up #CC-089', 'priority' => 'High', 'due_date' => date('Y-m-d', strtotime('+1 day')), 'status' => 'Pending'],
];

// Today's check-in status
$todayAtt = EP_Database::queryOne(
  "SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()",
  [$empId]
) ?? ['check_in' => null, 'check_out' => null, 'status' => null];

// Notifications unread count
$unreadNotifs = (int)(EP_Database::queryOne(
  "SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0",
  [$empId]
)['c'] ?? 2);

// Attendance chart data (last 6 months)
$attChart = [];
for ($i = 5; $i >= 0; $i--) {
  $mo = date('Y-m', strtotime("-$i months"));
  $row = EP_Database::queryOne(
    "SELECT COUNT(*) AS present FROM attendance WHERE employee_id=? AND DATE_FORMAT(date,'%Y-%m')=? AND status='Present'",
    [$empId, $mo]
  ) ?? ['present' => rand(18, 22)];
  $attChart['labels'][]  = date('M', strtotime($mo . '-01'));
  $attChart['present'][] = (int)$row['present'];
}

$hour   = (int)date('G');
$greet  = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$first  = ep_e($emp['first_name'] ?? 'Employee');

include dirname(__DIR__) . '/includes/header.php';
?>

<!-- Welcome Banner -->
<div class="ep-welcome">
  <div style="position:relative;z-index:1;display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px">
    <div>
      <div class="ep-welcome-title"><?= $greet ?>, <?= $first ?>! <span style="color:#C8A84B">👋</span></div>
      <div class="ep-welcome-sub"><?= ep_e($emp['position'] ?? 'Staff') ?> · <?= ep_e($emp['branch_name'] ?? 'Head Office') ?></div>
      <div class="ep-welcome-meta">
        <span><i class="fa-solid fa-calendar-day"></i> <?= date('l, d F Y') ?></span>
        <span><i class="fa-solid fa-building"></i> <?= ep_e($emp['dept_name'] ?? 'Operations') ?></span>
        <span><i class="fa-solid fa-id-badge"></i> <?= ep_e($emp['employee_number'] ?? 'EMP-000001') ?></span>
        <span id="ep-clock" style="font-variant-numeric:tabular-nums"></span>
        <?php if (!$live): ?><span style="background:rgba(200,168,75,.25);color:#C8A84B;padding:2px 8px;border-radius:99px;font-size:.68rem;font-weight:700"><i class="fa-solid fa-circle-exclamation"></i> Demo Mode</span><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <?php if (!$todayAtt['check_in']): ?>
        <button id="btn-checkin" class="ep-btn ep-btn-success ep-btn-sm">
          <i class="fa-solid fa-right-to-bracket"></i> Check In
        </button>
      <?php else: ?>
        <div style="background:rgba(34,197,94,.2);color:#dcfce7;padding:7px 14px;border-radius:9px;font-size:.82rem;font-weight:600;display:flex;align-items:center;gap:7px">
          <i class="fa-solid fa-circle-check"></i> Checked in <?= ep_e($todayAtt['check_in']) ?>
        </div>
      <?php endif; ?>
      <a href="<?= EP_BASE_URL ?>/employee/attendance/check-in.php" class="ep-btn ep-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.3)">
        <i class="fa-solid fa-clock"></i> Attendance
      </a>
    </div>
  </div>
</div>

<!-- KPI Stats -->
<div class="ep-stats">
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:#dcfce7;color:#16a34a"><i class="fa-solid fa-calendar-check"></i></div>
    <div>
      <div class="ep-stat-val"><?= (int)$attendanceThisMonth['present'] ?></div>
      <div class="ep-stat-lbl">Days Present</div>
    </div>
  </div>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:#fef9c3;color:#b45309"><i class="fa-solid fa-calendar-xmark"></i></div>
    <div>
      <div class="ep-stat-val"><?= (int)($leaveBalance['annual_remaining'] ?? 12) ?></div>
      <div class="ep-stat-lbl">Leave Days Left</div>
    </div>
  </div>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:#dbeafe;color:#1d4ed8"><i class="fa-solid fa-list-check"></i></div>
    <div>
      <div class="ep-stat-val"><?= $pendingTasks ?></div>
      <div class="ep-stat-lbl">Pending Tasks</div>
    </div>
  </div>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:#ede9fe;color:#7c3aed"><i class="fa-solid fa-receipt"></i></div>
    <div>
      <div class="ep-stat-val">ETB <?= number_format((float)$lastPayslip['net_salary']) ?></div>
      <div class="ep-stat-lbl">Last Net Pay</div>
    </div>
  </div>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:#fee2e2;color:#dc2626"><i class="fa-solid fa-bell"></i></div>
    <div>
      <div class="ep-stat-val"><?= $unreadNotifs ?></div>
      <div class="ep-stat-lbl">Notifications</div>
    </div>
  </div>
</div>

<!-- Quick Actions -->
<div class="ep-quick-actions">
  <a href="<?= EP_BASE_URL ?>/employee/customers/search.php" class="ep-qa-btn"><i class="fa-solid fa-magnifying-glass"></i> Customer Search</a>
  <a href="<?= EP_BASE_URL ?>/employee/accounts/open-account.php" class="ep-qa-btn"><i class="fa-solid fa-folder-open"></i> Open Account</a>
  <a href="<?= EP_BASE_URL ?>/employee/transactions/deposit.php" class="ep-qa-btn"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
  <a href="<?= EP_BASE_URL ?>/employee/transactions/transfer.php" class="ep-qa-btn"><i class="fa-solid fa-right-left"></i> Transfer</a>
  <a href="<?= EP_BASE_URL ?>/employee/loans/applications.php" class="ep-qa-btn"><i class="fa-solid fa-file-invoice-dollar"></i> Loan App</a>
  <a href="<?= EP_BASE_URL ?>/employee/reports/daily.php" class="ep-qa-btn"><i class="fa-solid fa-chart-bar"></i> Daily Report</a>
</div>

<div class="ep-grid-2">
  <!-- Attendance Chart -->
  <div class="ep-card">
    <div class="ep-card-hdr">
      <h3><i class="fa-solid fa-chart-bar" style="color:var(--teal)"></i> Attendance (6 Months)</h3>
    </div>
    <div class="ep-card-body"><canvas id="att-chart" height="180"></canvas></div>
  </div>

  <!-- Recent Activity -->
  <div class="ep-card">
    <div class="ep-card-hdr">
      <h3><i class="fa-solid fa-bolt" style="color:#C8A84B"></i> Recent Activity</h3>
      <a href="<?= EP_BASE_URL ?>/employee/reports/daily.php" style="font-size:.78rem;color:var(--teal);font-weight:600">View All</a>
    </div>
    <div class="ep-card-body p0">
      <div class="ep-activity">
        <?php
        $actIcons = ['attendance' => ['fa-calendar-check', '#22c55e', '#dcfce7'], 'transaction' => ['fa-arrow-right-arrow-left', '#3b82f6', '#dbeafe'], 'kyc' => ['fa-id-card', '#7c3aed', '#ede9fe'], 'leave' => ['fa-calendar-xmark', '#f59e0b', '#fef9c3'], 'account' => ['fa-building-columns', '#007A8A', '#e0f5f7'], 'task' => ['fa-list-check', '#dc2626', '#fee2e2']];
        foreach ($recentActivity as $act):
          [$ic, $clr, $bg] = $actIcons[$act['type'] ?? 'task'] ?? ['fa-circle', '#94a3b8', '#f1f5f9'];
        ?>
          <div class="ep-act-item" style="padding:11px 20px">
            <div class="ep-act-ic" style="background:<?= $bg ?>;color:<?= $clr ?>"><i class="fa-solid <?= $ic ?>"></i></div>
            <div>
              <div class="ep-act-text"><?= ep_e($act['description']) ?></div>
              <div class="ep-act-time"><?= ep_ago($act['created_at']) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Pending Tasks -->
<div class="ep-card">
  <div class="ep-card-hdr">
    <h3><i class="fa-solid fa-list-check" style="color:var(--navy)"></i> Pending Tasks
      <?php if ($pendingTasks > 0): ?><span class="ep-badge ep-badge-danger" style="margin-left:8px"><?= $pendingTasks ?></span><?php endif; ?>
    </h3>
    <a href="<?= EP_BASE_URL ?>/employee/tasks/index.php" class="ep-btn ep-btn-outline ep-btn-sm">View All</a>
  </div>
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr>
            <th>Task</th>
            <th>Priority</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tasks as $task):
            $pCls = 'ep-priority-' . strtolower($task['priority'] ?? 'low');
            $dueDate = $task['due_date'] ?? '';
            $overdue = $dueDate && $dueDate < date('Y-m-d') && ($task['status'] ?? '') !== 'Completed';
          ?>
            <tr>
              <td style="max-width:280px">
                <div class="fw-6" style="font-size:.84rem"><?= ep_e($task['title']) ?></div>
              </td>
              <td><span class="<?= $pCls ?> fw-6" style="font-size:.82rem"><?= ep_e($task['priority'] ?? 'Medium') ?></span></td>
              <td style="font-size:.82rem;color:<?= $overdue ? '#ef4444' : 'var(--muted)' ?>"><?= ep_date($dueDate) ?><?= $overdue ? ' <i class="fa-solid fa-triangle-exclamation"></i>' : '' ?></td>
              <td><?= ep_badge($task['status'] ?? 'Pending') ?></td>
              <td>
                <a href="<?= EP_BASE_URL ?>/employee/tasks/view.php?id=<?= (int)$task['id'] ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-eye"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php
$pageScript = "
document.addEventListener('DOMContentLoaded', function() {
  if (!window.Chart) return;
  EPCharts.attendance('att-chart',
    " . json_encode($attChart['labels'] ?? []) . ",
    " . json_encode($attChart['present'] ?? []) . "
  );
  var btn = document.getElementById('btn-checkin');
  if (btn) {
    btn.addEventListener('click', function() {
      EP.setBtn(btn, true, 'Checking in…');
      fetch('" . EP_BASE_URL . "/api/attendance/check-in.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'checkin'})})
        .then(r=>r.json()).then(d=>{
          EP.setBtn(btn, false, '<i class=\"fa-solid fa-right-to-bracket\"></i> Check In');
          EP.toast(d.success ? 'Checked in at '+d.time : (d.message||'Check-in recorded'), d.success?'success':'info');
          if (d.success) btn.closest('.ep-welcome').querySelector('.ep-welcome-meta')?.insertAdjacentHTML('beforeend','<span style=\"color:#C8A84B\"><i class=\"fa-solid fa-circle-check\"></i> '+d.time+'</span>');
        }).catch(()=>{EP.setBtn(btn,false,'<i class=\"fa-solid fa-right-to-bracket\"></i> Check In');EP.toast('Check-in recorded (demo)','success');});
    });
  }
});
";
include dirname(__DIR__) . '/includes/footer.php';
?>