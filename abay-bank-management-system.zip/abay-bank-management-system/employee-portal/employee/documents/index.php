<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'My Documents — ' . EP_NAME;
$breadcrumb = [['label'=>'Documents']];
$empId = (int)($emp['id'] ?? 0);

// Employee documents from DB
$dbDocs = EP_Database::query(
    "SELECT * FROM employee_documents WHERE employee_id=? ORDER BY created_at DESC", [$empId]
) ?: [];

// Demo personal documents (static for all employees)
$personalDocs = [
    ['type'=>'Employment Contract','filename'=>'employment_contract.pdf','size'=>'245 KB','date'=>ep_date($emp['hire_date'] ?? date('Y-m-d')),'icon'=>'file-contract','color'=>'#3b82f6'],
    ['type'=>'Latest Payslip',     'filename'=>'payslip_'.date('Y_m').'.pdf','size'=>'128 KB','date'=>ep_date(date('Y-m-d',strtotime('first day of this month'))),'icon'=>'file-invoice-dollar','color'=>'#22c55e'],
    ['type'=>'Previous Payslip',   'filename'=>'payslip_'.date('Y_m',strtotime('-1 month')).'.pdf','size'=>'126 KB','date'=>ep_date(date('Y-m-d',strtotime('first day of last month'))),'icon'=>'file-invoice-dollar','color'=>'#22c55e'],
    ['type'=>'Job Offer Letter',   'filename'=>'offer_letter.pdf','size'=>'198 KB','date'=>ep_date($emp['hire_date'] ?? date('Y-m-d')),'icon'=>'envelope-open-text','color'=>'#8b5cf6'],
    ['type'=>'Tax Clearance',      'filename'=>'tax_clearance_2025.pdf','size'=>'312 KB','date'=>'01 Jan 2026','icon'=>'file-shield','color'=>'#f59e0b'],
];

// KYC / Uploaded documents
$kycDocs = !empty($dbDocs) ? $dbDocs : [
    ['id'=>1,'doc_type'=>'National ID',         'original_name'=>'national_id.jpg',       'file_size'=>1200000,'status'=>'Verified', 'created_at'=>date('Y-m-d H:i:s',strtotime('-60 days'))],
    ['id'=>2,'doc_type'=>'Passport Photo',      'original_name'=>'passport_photo.jpg',    'file_size'=>450000, 'status'=>'Verified', 'created_at'=>date('Y-m-d H:i:s',strtotime('-60 days'))],
    ['id'=>3,'doc_type'=>'Educational Certificate','original_name'=>'degree_certificate.pdf','file_size'=>2100000,'status'=>'Verified','created_at'=>date('Y-m-d H:i:s',strtotime('-45 days'))],
    ['id'=>4,'doc_type'=>'Bank Account Statement','original_name'=>'bank_statement.pdf',  'file_size'=>890000, 'status'=>'Pending',  'created_at'=>date('Y-m-d H:i:s',strtotime('-5 days'))],
];

$docTypeIcons = [
    'National ID'=>'id-card','Passport Photo'=>'image','Educational Certificate'=>'graduation-cap',
    'Bank Account Statement'=>'building-columns','Medical Certificate'=>'notes-medical','Other'=>'file',
];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-folder-open" style="color:var(--teal)"></i> My Documents</h1>
    <p>Personal documents and KYC files</p>
  </div>
  <div class="ep-page-actions">
    <a href="upload.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-upload"></i> Upload Document</a>
  </div>
</div>

<!-- Personal Documents -->
<div style="margin-bottom:8px">
  <h2 style="font-size:.95rem;font-weight:700;color:var(--text)"><i class="fa-solid fa-briefcase" style="color:var(--teal)"></i> Personal & HR Documents</h2>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin-bottom:24px">
  <?php foreach ($personalDocs as $doc): ?>
  <div class="ep-card" style="cursor:pointer" onclick="alert('Download feature: <?= ep_e($doc['filename']) ?>')">
    <div class="ep-card-body" style="text-align:center;padding:20px 16px">
      <div style="width:52px;height:52px;border-radius:12px;background:<?= $doc['color'] ?>18;color:<?= $doc['color'] ?>;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:1.4rem">
        <i class="fa-solid fa-<?= $doc['icon'] ?>"></i>
      </div>
      <div class="fw-6" style="font-size:.84rem;margin-bottom:4px"><?= ep_e($doc['type']) ?></div>
      <div style="font-size:.74rem;color:var(--muted);margin-bottom:8px"><?= ep_e($doc['filename']) ?></div>
      <div style="display:flex;justify-content:space-between;font-size:.73rem;color:var(--muted)">
        <span><?= $doc['size'] ?></span><span><?= $doc['date'] ?></span>
      </div>
      <div style="margin-top:10px">
        <span class="ep-btn ep-btn-ghost ep-btn-sm" style="font-size:.74rem"><i class="fa-solid fa-download"></i> Download</span>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- KYC / Uploaded Documents -->
<div style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center">
  <h2 style="font-size:.95rem;font-weight:700;color:var(--text)"><i class="fa-solid fa-shield-halved" style="color:var(--teal)"></i> KYC & Uploaded Documents</h2>
  <a href="upload.php" class="ep-btn ep-btn-outline ep-btn-sm"><i class="fa-solid fa-plus"></i> Upload</a>
</div>

<div class="ep-card">
  <div class="ep-card-body p0">
    <?php if (empty($kycDocs)): ?>
    <div style="text-align:center;padding:40px;color:var(--muted)">
      <i class="fa-solid fa-file-circle-plus" style="font-size:2rem;margin-bottom:10px;display:block"></i>
      No documents uploaded yet. <a href="upload.php" style="color:var(--teal)">Upload your first document</a>.
    </div>
    <?php else: ?>
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr><th>Document Type</th><th>Filename</th><th>Size</th><th>Uploaded</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php foreach ($kycDocs as $doc): ?>
          <?php
            $typeKey = $doc['doc_type'] ?? 'Other';
            $icon = $docTypeIcons[$typeKey] ?? 'file';
            $sizeKB = isset($doc['file_size']) ? round((int)$doc['file_size'] / 1024) . ' KB' : '—';
          ?>
          <tr>
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:32px;height:32px;border-radius:8px;background:#f1f5f9;color:var(--teal);display:flex;align-items:center;justify-content:center">
                  <i class="fa-solid fa-<?= $icon ?>"></i>
                </div>
                <span class="fw-6" style="font-size:.84rem"><?= ep_e($typeKey) ?></span>
              </div>
            </td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_e($doc['original_name'] ?? '—') ?></td>
            <td style="font-size:.8rem"><?= $sizeKB ?></td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($doc['created_at'] ?? '') ?></td>
            <td><?= ep_badge($doc['status'] ?? 'Pending') ?></td>
            <td>
              <a href="#" class="ep-btn ep-btn-ghost ep-btn-sm" title="Download">
                <i class="fa-solid fa-download"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Upload CTA -->
<div class="ep-card" style="margin-top:20px;border:2px dashed var(--border);background:var(--surface)">
  <div class="ep-card-body" style="text-align:center;padding:28px">
    <i class="fa-solid fa-cloud-arrow-up" style="font-size:2rem;color:var(--teal);margin-bottom:10px;display:block"></i>
    <div class="fw-6" style="margin-bottom:6px">Upload a new document</div>
    <div style="font-size:.82rem;color:var(--muted);margin-bottom:16px">Supported formats: PDF, JPG, PNG, DOC/DOCX &mdash; Max 5 MB</div>
    <a href="upload.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-upload"></i> Upload Document</a>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
