<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Upload Document — ' . EP_NAME;
$breadcrumb = [['label'=>'Documents','url'=>EP_BASE_URL.'/employee/documents/index.php'],['label'=>'Upload']];
$empId = (int)($emp['id'] ?? 0);
$errors  = [];
$success = null;

$docTypes = [
    'National ID', 'Passport', 'Passport Photo', 'Educational Certificate',
    'Professional Certificate', 'Bank Account Statement', 'Medical Certificate',
    'Utility Bill', 'Reference Letter', 'Other',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();

    $docType = trim($_POST['doc_type'] ?? '');
    $notes   = trim($_POST['notes']   ?? '');

    if (!$docType || !in_array($docType, $docTypes, true)) {
        $errors[] = 'Please select a valid document type.';
    }

    if (empty($_FILES['document']) || $_FILES['document']['error'] === UPLOAD_ERR_NO_FILE) {
        $errors[] = 'Please select a file to upload.';
    } elseif (!empty($_FILES['document'])) {
        $file = $_FILES['document'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'File upload error (code ' . (int)$file['error'] . '). Please try again.';
        } elseif ($file['size'] > EP_MAX_FILE_SIZE) {
            $errors[] = 'File size exceeds 5 MB limit. Please compress the file and try again.';
        } else {
            // Validate MIME type strictly
            $finfo    = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($file['tmp_name']);
            $allowed  = array_merge(EP_ALLOWED_IMAGES, EP_ALLOWED_DOCS);
            if (!in_array($mimeType, $allowed, true)) {
                $errors[] = 'File type not allowed. Only PDF, JPG, PNG, DOC, DOCX are accepted.';
            }
        }
    }

    if (!$errors && !empty($_FILES['document'])) {
        $file         = $_FILES['document'];
        $origName     = basename($file['name']);
        $ext          = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        $safeName     = 'doc_' . $empId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $uploadDir    = EP_BASE_PATH . '/uploads/employee-documents/';
        $uploadPath   = $uploadDir . $safeName;

        // Ensure upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $db = EP_Database::get();
            if ($db) {
                EP_Database::execute(
                    "INSERT INTO employee_documents
                     (employee_id, doc_type, filename, original_name, file_size, mime_type, notes, status, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())",
                    [$empId, $docType, $safeName, $origName, $file['size'], $file['type'], $notes]
                );
                EP_Database::execute(
                    "INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",
                    [$empId, "Uploaded document: $docType ($origName)", 'document']
                );
            }
            ep_flash('success', "Document '$docType' uploaded successfully and is pending review.");
            ep_redirect(EP_BASE_URL . '/employee/documents/index.php');
        } else {
            $errors[] = 'Failed to save the file. Please check permissions and try again.';
        }
    }
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-cloud-arrow-up" style="color:var(--teal)"></i> Upload Document</h1></div>
  <div class="ep-page-actions">
    <a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>

<?php foreach ($errors as $e): ?>
<div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= ep_e($e) ?></div>
<?php endforeach; ?>

<div style="max-width:680px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Upload New Document</h3></div>
    <div class="ep-card-body">
      <form method="POST" enctype="multipart/form-data" id="upload-form">
        <?= ep_csrf_field() ?>

        <div class="ep-form-group">
          <label class="ep-label">Document Type <span class="req">*</span></label>
          <select name="doc_type" class="ep-select" required>
            <option value="">— Select type —</option>
            <?php foreach ($docTypes as $dt): ?>
            <option value="<?= ep_e($dt) ?>" <?= (($_POST['doc_type'] ?? '') === $dt) ? 'selected' : '' ?>><?= ep_e($dt) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Drag-drop upload zone -->
        <div class="ep-form-group">
          <label class="ep-label">File <span class="req">*</span></label>
          <div id="drop-zone" style="border:2px dashed var(--border);border-radius:12px;padding:32px 24px;text-align:center;cursor:pointer;transition:border-color .2s,background .2s"
               onclick="document.getElementById('file-input').click()"
               ondragover="event.preventDefault();this.style.borderColor='var(--teal)';this.style.background='rgba(0,152,175,.05)'"
               ondragleave="this.style.borderColor='var(--border)';this.style.background=''"
               ondrop="handleDrop(event)">
            <i class="fa-solid fa-cloud-arrow-up" id="dz-icon" style="font-size:2.2rem;color:var(--teal);margin-bottom:10px;display:block"></i>
            <div class="fw-6" id="dz-title">Drag & drop your file here</div>
            <div style="font-size:.8rem;color:var(--muted);margin-top:4px" id="dz-sub">or click to browse</div>
            <div style="font-size:.75rem;color:var(--muted);margin-top:10px">PDF, JPG, PNG, DOC, DOCX &mdash; Max 5 MB</div>
          </div>
          <input type="file" name="document" id="file-input" style="display:none"
                 accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx"
                 onchange="showSelectedFile(this)">
          <div id="file-preview" style="display:none;margin-top:10px;background:var(--surface);border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:12px">
            <i class="fa-solid fa-file" style="color:var(--teal);font-size:1.2rem"></i>
            <div>
              <div class="fw-6" style="font-size:.84rem" id="fp-name">—</div>
              <div style="font-size:.76rem;color:var(--muted)" id="fp-size">—</div>
            </div>
            <button type="button" onclick="clearFile()" style="margin-left:auto;background:none;border:none;cursor:pointer;color:#ef4444;font-size:1rem"><i class="fa-solid fa-xmark"></i></button>
          </div>
        </div>

        <div class="ep-form-group">
          <label class="ep-label">Notes <span style="color:var(--muted);font-weight:400">(optional)</span></label>
          <textarea name="notes" class="ep-textarea" rows="3" maxlength="500"
                    placeholder="Any notes about this document..."><?= ep_e($_POST['notes'] ?? '') ?></textarea>
        </div>

        <div class="ep-alert ep-alert-info" style="margin-bottom:16px">
          <i class="fa-solid fa-circle-info"></i>
          Uploaded documents will be reviewed by HR and marked as <strong>Verified</strong> once approved.
        </div>

        <div style="display:flex;gap:10px">
          <button type="submit" class="ep-btn ep-btn-primary" id="upload-btn">
            <i class="fa-solid fa-upload"></i> Upload Document
          </button>
          <a href="index.php" class="ep-btn ep-btn-outline">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function showSelectedFile(input) {
  if (input.files && input.files[0]) {
    var f    = input.files[0];
    var size = f.size < 1048576 ? (f.size/1024).toFixed(1)+' KB' : (f.size/1048576).toFixed(1)+' MB';
    document.getElementById('fp-name').textContent = f.name;
    document.getElementById('fp-size').textContent = size;
    document.getElementById('file-preview').style.display = 'flex';
    document.getElementById('dz-title').textContent = f.name;
    document.getElementById('dz-sub').textContent   = size;
    document.getElementById('dz-icon').className    = 'fa-solid fa-file-check';
    document.getElementById('dz-icon').style.color  = '#22c55e';
  }
}
function clearFile() {
  document.getElementById('file-input').value = '';
  document.getElementById('file-preview').style.display = 'none';
  document.getElementById('dz-title').textContent = 'Drag & drop your file here';
  document.getElementById('dz-sub').textContent   = 'or click to browse';
  document.getElementById('dz-icon').className    = 'fa-solid fa-cloud-arrow-up';
  document.getElementById('dz-icon').style.color  = 'var(--teal)';
}
function handleDrop(e) {
  e.preventDefault();
  var dt = document.getElementById('drop-zone');
  dt.style.borderColor = 'var(--border)';
  dt.style.background  = '';
  var files = e.dataTransfer.files;
  if (files && files[0]) {
    var input = document.getElementById('file-input');
    var transfer = new DataTransfer();
    transfer.items.add(files[0]);
    input.files = transfer.files;
    showSelectedFile(input);
  }
}
document.getElementById('upload-form').addEventListener('submit', function(){
  document.getElementById('upload-btn').disabled = true;
  document.getElementById('upload-btn').innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uploading...';
});
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
