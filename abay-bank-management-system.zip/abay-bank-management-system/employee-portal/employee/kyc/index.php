<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'KYC Verification — ' . EP_NAME;
$breadcrumb = [['label'=>'KYC']];
$page   = max(1,(int)($_GET['page']??1));
$status = $_GET['status'] ?? 'Pending';

$where = "c.kyc_status=?"; $params = [$status];
$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM customers c WHERE $where",$params)['c'] ?? 4);
$pag   = ep_paginate($total, $page);
$customers = EP_Database::query(
    "SELECT c.*, b.branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id WHERE $where ORDER BY c.created_at DESC LIMIT ? OFFSET ?",
    [...$params,$pag['perPage'],$pag['offset']]
) ?: [
    ['id'=>1,'customer_number'=>'CUST-001','first_name'=>'Abebe','last_name'=>'Tadesse','phone'=>'+251911000001','kyc_status'=>'Pending','created_at'=>date('Y-m-d H:i:s',time()-3600),'branch_name'=>'Head Office'],
    ['id'=>2,'customer_number'=>'CUST-002','first_name'=>'Hana','last_name'=>'Bekele','phone'=>'+251911000002','kyc_status'=>'Pending','created_at'=>date('Y-m-d H:i:s',time()-7200),'branch_name'=>'Bole Branch'],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-id-card" style="color:var(--teal)"></i> KYC Management</h1><p>Review and verify customer identity documents</p></div>
</div>
<div class="ep-tabs" style="max-width:400px;margin-bottom:16px">
  <?php foreach (['Pending','Under Review','Verified','Rejected'] as $s): ?>
  <a href="?status=<?= $s ?>" class="ep-tab <?= $status===$s?'active':'' ?>" style="text-decoration:none"><?= $s ?></a>
  <?php endforeach; ?>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Customer</th><th>ID</th><th>Phone</th><th>Branch</th><th>Submitted</th><th>KYC Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($customers as $c): ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="ep-avatar ep-av-sm" style="background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff"><?= strtoupper(substr($c['first_name']??'?',0,1)) ?></div>
              <span class="fw-6" style="font-size:.84rem"><?= ep_e(($c['first_name']??'').' '.($c['last_name']??'')) ?></span>
            </div>
          </td>
          <td style="font-family:monospace;font-size:.8rem"><?= ep_e($c['customer_number']??'—') ?></td>
          <td><?= ep_e($c['phone']??'—') ?></td>
          <td><?= ep_e($c['branch_name']??'—') ?></td>
          <td style="font-size:.8rem;color:var(--muted)"><?= ep_ago($c['created_at']??'') ?></td>
          <td><?= ep_badge($c['kyc_status']??'Pending') ?></td>
          <td>
            <a href="review.php?id=<?= (int)($c['id']??0) ?>" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-magnifying-glass"></i> Review</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
