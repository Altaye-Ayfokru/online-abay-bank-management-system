<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$id    = (int)($_GET['id'] ?? 0);
$customer = EP_Database::queryOne("SELECT c.*, b.branch_name FROM customers c LEFT JOIN branches b ON b.id=c.branch_id WHERE c.id=?",[$id])
          ?? ['id'=>$id,'first_name'=>'Abebe','last_name'=>'Tadesse','phone'=>'+251911000001','kyc_status'=>'Pending','national_id'=>'ET123456','branch_name'=>'Head Office'];
$docs = EP_Database::query("SELECT * FROM customer_documents WHERE customer_id=?",[$id]) ?: [];
$pageTitle  = 'KYC Review — ' . EP_NAME;
$breadcrumb = [['label'=>'KYC','url'=>EP_BASE_URL.'/employee/kyc/index.php'],['label'=>'Review']];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $action = $_POST['action'] ?? '';
    $note   = trim($_POST['note'] ?? '');
    if ($action === 'verify') {
        EP_Database::execute("UPDATE customers SET kyc_status='Verified' WHERE id=?",[$id]);
        EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",[$empId,"KYC verified for customer #$id",'kyc']);
        ep_flash('success','KYC verified successfully.');
    } elseif ($action === 'reject') {
        EP_Database::execute("UPDATE customers SET kyc_status='Rejected' WHERE id=?",[$id]);
        EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",[$empId,"KYC rejected for customer #$id. Note: $note",'kyc']);
        ep_flash('warning','KYC rejected.');
    }
    header('Location: ' . EP_BASE_URL . '/employee/kyc/index.php'); exit;
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-magnifying-glass" style="color:var(--teal)"></i> KYC Review</h1></div>
  <div class="ep-page-actions"><a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<div class="ep-grid-2" style="align-items:start">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Customer Information</h3></div>
    <div class="ep-card-body">
      <div style="text-align:center;margin-bottom:20px">
        <div class="ep-avatar ep-av-lg" style="background:linear-gradient(135deg,var(--navy),var(--teal));color:#fff;margin:0 auto 12px"><?= strtoupper(substr($customer['first_name']??'?',0,1)) ?></div>
        <h3 style="margin-bottom:4px"><?= ep_e(($customer['first_name']??'').' '.($customer['last_name']??'')) ?></h3>
        <?= ep_badge($customer['kyc_status']??'Pending') ?>
      </div>
      <?php foreach ([['National ID',$customer['national_id']??'—'],['Phone',$customer['phone']??'—'],['Branch',$customer['branch_name']??'—']] as [$l,$v]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem"><span class="text-muted"><?= $l ?></span><span class="fw-6"><?= ep_e($v) ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
  <div>
    <div class="ep-card" style="margin-bottom:16px">
      <div class="ep-card-hdr"><h3>Submitted Documents</h3></div>
      <div class="ep-card-body">
        <?php if (empty($docs)): ?>
        <p class="text-muted" style="text-align:center;padding:16px">No documents uploaded yet.</p>
        <?php else: foreach ($docs as $d): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border)">
          <div><div class="fw-6" style="font-size:.84rem"><?= ep_e($d['doc_type']??'Document') ?></div><div style="font-size:.75rem;color:var(--muted)"><?= ep_e($d['file_name']??'') ?></div></div>
          <?= ep_badge($d['status']??'Pending') ?>
        </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
    <?php if (($customer['kyc_status']??'') === 'Pending' || ($customer['kyc_status']??'') === 'Under Review'): ?>
    <div class="ep-card">
      <div class="ep-card-hdr"><h3>Verification Decision</h3></div>
      <div class="ep-card-body">
        <form method="POST">
          <?= ep_csrf_field() ?>
          <div class="ep-form-group"><label class="ep-label">Note (for rejection)</label><textarea name="note" class="ep-textarea" rows="2" placeholder="Reason for rejection if applicable…"></textarea></div>
          <div style="display:flex;gap:10px">
            <button type="submit" name="action" value="verify" class="ep-btn ep-btn-success" style="flex:1"><i class="fa-solid fa-check"></i> Verify KYC</button>
            <button type="submit" name="action" value="reject" class="ep-btn ep-btn-danger" style="flex:1" onclick="return confirm('Reject this KYC?')"><i class="fa-solid fa-xmark"></i> Reject</button>
          </div>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
