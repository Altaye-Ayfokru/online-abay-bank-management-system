<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$id    = (int)($_GET['id'] ?? 0);
if ($id) {
    $req = EP_Database::queryOne("SELECT * FROM leave_requests WHERE id=? AND employee_id=? AND status='Pending'", [$id, $empId]);
    if ($req) {
        EP_Database::execute("UPDATE leave_requests SET status='Cancelled' WHERE id=?", [$id]);
        ep_flash('success', 'Leave request cancelled.');
    } else {
        ep_flash('danger', 'Request not found or cannot be cancelled.');
    }
}
header('Location: ' . EP_BASE_URL . '/employee/leave/index.php'); exit;
