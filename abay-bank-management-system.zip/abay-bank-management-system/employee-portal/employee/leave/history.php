﻿<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Leave History â€” ' . EP_NAME;
$breadcrumb = [['label' => 'Leave', 'url' => EP_BASE_URL . '/employee/leave/index.php'], ['label' => 'History']];
$empId = (int)($emp['id'] ?? 0);
$page   = max(1, (int)($_GET['page'] ?? 1));
$status = $_GET['status'] ?? '';
$year   = (int)($_GET['year'] ?? date('Y'));

$total = (int)(EP_Database::queryOne(
  "SELECT COUNT(*) AS c FROM leave_requests WHERE employee_id=? AND YEAR(from_date)=?" . ($status ? " AND status=?" : ''),
  $status ? [$empId, $year, $status] : [$empId, $year]
)['c'] ?? 5);
$pag = ep_paginate($total, $page);

$records = EP_Database::query(
  "SELECT * FROM leave_requests WHERE employee_id=? AND YEAR(from_date)=?" . ($status ? " AND status=?" : '') . " ORDER BY created_at DESC LIMIT ? OFFSET ?",
  $status ? [$empId, $year, $status, $pag['perPage'], $pag['offset']] : [$empId, $year, $pag['perPage'], $pag['offset']]
) ?: [
  ['id' => 1, 'leave_type' => 'Annual', 'from_date' => '2026-07-14', 'to_date' => '2026-07-18', 'days' => 5, 'reason' => 'Family vacation', 'status' => 'Approved', 'created_at' => '2026-07-08 09:00:00'],
  ['id' => 2, 'leave_type' => 'Sick', 'from_date' => '2026-06-03', 'to_date' => '2026-06-04', 'days' => 2, 'reason' => 'Medical appointment', 'status' => 'Approved', 'created_at' => '2026-06-03 08:00:00'],
  ['id' => 3, 'leave_type' => 'Annual', 'from_date' => date('Y-m-d', strtotime('+7 days')), 'to_date' => date('Y-m-d', strtotime('+11 days')), 'days' => 5, 'reason' => 'Holiday trip', 'status' => 'Pending', 'created_at' => date('Y-m-d H:i:s')],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-history" style="color:var(--teal)"></i> Leave History</h1>
  </div>
  <div class="ep-page-actions"><a href="<?= EP_BASE_URL ?>/employee/leave/request.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-plus"></i> New Request</a></div>
</div>
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="ep-label">Year</label>
        <select name="year" class="ep-select" style="width:100px">
          <?php for ($y = date('Y'); $y >= date('Y') - 3; $y--): ?><option value="<?= $y ?>" <?= $y === $year ? 'selected' : '' ?>><?= $y ?></option><?php endfor; ?>
        </select>
      </div>
      <div><label class="ep-label">Status</label>
        <select name="status" class="ep-select" style="width:140px">
          <option value="">All</option>
          <?php foreach (['Pending', 'Approved', 'Rejected', 'Cancelled'] as $s): ?><option <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="<?= EP_BASE_URL ?>/employee/leave/history.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead>
        <tr>
          <th>Type</th>
          <th>Start</th>
          <th>End</th>
          <th>Days</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Applied</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($records as $r): ?>
          <tr>
            <td class="fw-6"><?= ep_e($r['leave_type']) ?></td>
            <td><?= ep_date($r['from_date']) ?></td>
            <td><?= ep_date($r['to_date']) ?></td>
            <td><?= (int)($r['days'] ?? 0) ?></td>
            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.82rem;color:var(--muted)"><?= ep_e($r['reason'] ?? '') ?></td>
            <td><?= ep_badge($r['status']) ?></td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($r['created_at'] ?? '') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>