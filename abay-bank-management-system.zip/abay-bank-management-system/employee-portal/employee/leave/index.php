﻿<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Leave â€” ' . EP_NAME;
$breadcrumb = [['label'=>'Leave']];
$empId = (int)($emp['id'] ?? 0);

$balance = EP_Database::queryOne(
    "SELECT * FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())", [$empId]
) ?? ['annual_remaining'=>12,'annual_total'=>18,'sick_remaining'=>8,'sick_total'=>10,'emergency_remaining'=>3,'emergency_total'=>3];

$pending = EP_Database::query(
    "SELECT * FROM leave_requests WHERE employee_id=? AND status='Pending' ORDER BY created_at DESC", [$empId]
) ?: [['id'=>1,'leave_type'=>'Annual','from_date'=>date('Y-m-d',strtotime('+7 days')),'to_date'=>date('Y-m-d',strtotime('+11 days')),'days'=>5,'reason'=>'Family vacation','status'=>'Pending','created_at'=>date('Y-m-d H:i:s')]];

$recent = EP_Database::query(
    "SELECT * FROM leave_requests WHERE employee_id=? ORDER BY created_at DESC LIMIT 10", [$empId]
) ?: [
    ['id'=>1,'leave_type'=>'Annual','from_date'=>'2026-07-14','to_date'=>'2026-07-18','days'=>5,'status'=>'Approved','created_at'=>'2026-07-08 09:00:00'],
    ['id'=>2,'leave_type'=>'Sick','from_date'=>'2026-06-03','to_date'=>'2026-06-04','days'=>2,'status'=>'Approved','created_at'=>'2026-06-03 08:00:00'],
    ['id'=>3,'leave_type'=>'Annual','from_date'=>date('Y-m-d',strtotime('+7 days')),'to_date'=>date('Y-m-d',strtotime('+11 days')),'days'=>5,'status'=>'Pending','created_at'=>date('Y-m-d H:i:s')],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-calendar-xmark" style="color:var(--teal)"></i> Leave Management</h1><p>View your leave balance and request time off</p></div>
  <div class="ep-page-actions">
    <a href="<?= EP_BASE_URL ?>/employee/leave/request.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-plus"></i> Request Leave</a>
  </div>
</div>

<!-- Balance Cards -->
<div class="ep-stats" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
  <?php foreach ([
    ['Annual','annual',$balance,'#22c55e','#dcfce7'],
    ['Sick','sick',$balance,'#3b82f6','#dbeafe'],
    ['Emergency','emergency',$balance,'#f59e0b','#fef9c3'],
  ] as [$name,$key,$bal,$c,$bg]):
    $rem   = (int)($bal[$key.'_remaining'] ?? 0);
    $total = (int)($bal[$key.'_total'] ?? 10);
    $pct   = $total > 0 ? round($rem/$total*100) : 0;
  ?>
  <div class="ep-stat" style="flex-direction:column;align-items:flex-start;gap:10px">
    <div style="display:flex;justify-content:space-between;width:100%">
      <span style="font-size:.82rem;font-weight:600;color:var(--text)"><?= $name ?> Leave</span>
      <span style="font-weight:800;color:<?= $c ?>"><?= $rem ?> days</span>
    </div>
    <div class="ep-progress" style="width:100%"><div class="ep-progress-fill" style="width:<?= $pct ?>%;background:<?= $c ?>"></div></div>
    <span style="font-size:.73rem;color:var(--muted)"><?= $rem ?> of <?= $total ?> days remaining</span>
  </div>
  <?php endforeach; ?>
</div>

<!-- Pending + Recent -->
<div class="ep-grid-2">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3><i class="fa-solid fa-clock" style="color:#f59e0b"></i> Pending Requests</h3>
      <a href="<?= EP_BASE_URL ?>/employee/leave/request.php" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-plus"></i> New</a>
    </div>
    <?php if (empty($pending)): ?>
    <div class="ep-card-body" style="text-align:center;padding:32px">
      <i class="fa-solid fa-circle-check" style="font-size:2rem;color:#22c55e;margin-bottom:8px;display:block"></i>
      <p class="text-muted">No pending leave requests</p>
    </div>
    <?php else: ?>
    <div class="ep-card-body p0">
      <?php foreach ($pending as $req): ?>
      <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
          <div>
            <div class="fw-6" style="font-size:.88rem"><?= ep_e($req['leave_type']) ?></div>
            <div style="font-size:.8rem;color:var(--muted)"><?= ep_date($req['from_date']) ?> â€“ <?= ep_date($req['to_date']) ?> (<?= (int)($req['days']??0) ?> days)</div>
          </div>
          <?= ep_badge($req['status']) ?>
        </div>
        <div style="margin-top:8px;display:flex;gap:8px">
          <a href="<?= EP_BASE_URL ?>/employee/leave/view.php?id=<?= (int)$req['id'] ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-eye"></i> View</a>
          <a href="<?= EP_BASE_URL ?>/employee/leave/cancel.php?id=<?= (int)$req['id'] ?>" class="ep-btn ep-btn-ghost ep-btn-sm" style="color:var(--err)" onclick="return confirm('Cancel this request?')"><i class="fa-solid fa-xmark"></i> Cancel</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Leave History</h3><a href="<?= EP_BASE_URL ?>/employee/leave/history.php" class="ep-btn ep-btn-outline ep-btn-sm">View All</a></div>
    <div class="ep-card-body p0">
      <table class="ep-table">
        <thead><tr><th>Type</th><th>Dates</th><th>Days</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recent as $r): ?>
          <tr>
            <td class="fw-6" style="font-size:.82rem"><?= ep_e($r['leave_type']) ?></td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($r['from_date']) ?></td>
            <td><?= (int)($r['days']??0) ?></td>
            <td><?= ep_badge($r['status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
