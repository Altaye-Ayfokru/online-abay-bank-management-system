﻿<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Request Leave â€” ' . EP_NAME;
$breadcrumb = [['label'=>'Leave','url'=>EP_BASE_URL.'/employee/leave/index.php'],['label'=>'Request']];
$empId = (int)($emp['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $type    = trim($_POST['leave_type']   ?? '');
    $start   = trim($_POST['from_date']   ?? '');
    $end     = trim($_POST['to_date']     ?? '');
    $reason  = trim($_POST['reason']       ?? '');
    $contact = trim($_POST['contact']      ?? '');

    if (!$type)  $errors[] = 'Leave type is required.';
    if (!$start) $errors[] = 'Start date is required.';
    if (!$end)   $errors[] = 'End date is required.';
    if ($start && $end && $end < $start) $errors[] = 'End date must be after start date.';
    if (!$reason || strlen($reason) < 10) $errors[] = 'Reason must be at least 10 characters.';

    if (!$errors) {
        $days = 0;
        $cur = new DateTime($start);
        $endDt = new DateTime($end);
        while ($cur <= $endDt) {
            if ((int)$cur->format('N') < 6) $days++;
            $cur->modify('+1 day');
        }
        EP_Database::execute(
            "INSERT INTO leave_requests (employee_id, leave_type, from_date, to_date, days, reason, status, created_at)
             VALUES (?,?,?,?,?,?,?,'Pending',NOW())",
            [$empId, $type, $start, $end, $days, $reason, $contact]
        );
        EP_Database::execute(
            "INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())",
            [$empId, "Leave request submitted: $type ($days days)", 'leave']
        );
        ep_flash('success', "Leave request submitted for $days working days. You'll be notified once it's reviewed.");
        header('Location: ' . EP_BASE_URL . '/employee/leave/index.php'); exit;
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-paper-plane" style="color:var(--teal)"></i> Request Leave</h1></div>
  <div class="ep-page-actions"><a href="<?= EP_BASE_URL ?>/employee/leave/index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>
<div style="max-width:640px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Leave Application Form</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group">
          <label class="ep-label">Leave Type <span class="req">*</span></label>
          <select name="leave_type" class="ep-select" required>
            <option value="">Select leave typeâ€¦</option>
            <?php foreach (EP_LEAVE_TYPES as $t): ?><option <?= ($_POST['leave_type']??'')===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="ep-form-row">
          <div class="ep-form-group">
            <label class="ep-label">Start Date <span class="req">*</span></label>
            <input type="date" name="from_date" class="ep-input" required min="<?= date('Y-m-d') ?>" value="<?= ep_e($_POST['from_date'] ?? '') ?>" onchange="calcDays()">
          </div>
          <div class="ep-form-group">
            <label class="ep-label">End Date <span class="req">*</span></label>
            <input type="date" name="to_date" class="ep-input" required min="<?= date('Y-m-d') ?>" value="<?= ep_e($_POST['to_date'] ?? '') ?>" onchange="calcDays()">
          </div>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Working Days</label>
          <div id="days-display" style="background:var(--light);border:2px solid var(--border);border-radius:var(--r);padding:10px 13px;font-weight:700;font-size:1rem;color:var(--teal)">â€”</div>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Reason <span class="req">*</span></label>
          <textarea name="reason" class="ep-textarea" rows="3" required minlength="10" placeholder="Please provide a brief reason for your leave requestâ€¦"><?= ep_e($_POST['reason'] ?? '') ?></textarea>
          <div class="ep-hint">Minimum 10 characters</div>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Contact During Leave</label>
          <input type="tel" name="contact" class="ep-input ep-inp-noi" placeholder="+251 9XX XXX XXX" value="<?= ep_e($_POST['contact'] ?? '') ?>">
          <div class="ep-hint">Optional â€” phone number where you can be reached</div>
        </div>
        <div style="background:#fef9c3;border:1px solid #fde68a;border-radius:10px;padding:12px 14px;margin-bottom:16px;font-size:.82rem;color:#78350f">
          <i class="fa-solid fa-triangle-exclamation" style="color:#d97706;margin-right:5px"></i>
          Leave requests require manager approval. You'll receive a notification once reviewed.
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <a href="<?= EP_BASE_URL ?>/employee/leave/index.php" class="ep-btn ep-btn-outline">Cancel</a>
          <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-paper-plane"></i> Submit Request</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
function calcDays() {
  var s = document.querySelector('[name="from_date"]').value;
  var e = document.querySelector('[name="to_date"]').value;
  var el = document.getElementById('days-display');
  if (!s || !e) { el.textContent='â€”'; return; }
  var start = new Date(s), end = new Date(e), days = 0;
  if (end < start) { el.textContent='Invalid date range'; el.style.color='#ef4444'; return; }
  var cur = new Date(start);
  while (cur <= end) { if (cur.getDay()!==0 && cur.getDay()!==6) days++; cur.setDate(cur.getDate()+1); }
  el.textContent = days + ' working day' + (days!==1?'s':'');
  el.style.color = 'var(--teal)';
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
