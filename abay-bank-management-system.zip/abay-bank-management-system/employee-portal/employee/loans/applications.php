<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Loan Applications — ' . EP_NAME;
$breadcrumb = [['label'=>'Loans'],['label'=>'Applications']];
$empId = (int)($emp['id'] ?? 0);

$page       = max(1, (int)($_GET['page']   ?? 1));
$statusFilter = $_GET['status'] ?? 'Pending';
$search     = trim($_GET['search'] ?? '');

$where  = "WHERE 1=1";
$params = [];
if ($statusFilter) { $where .= " AND l.status = ?";  $params[] = $statusFilter; }
if ($search)       { $where .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR l.loan_number LIKE ?)";
                     $s = "%$search%"; $params[] = $s; $params[] = $s; $params[] = $s; }

$total = (int)(EP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM loans l LEFT JOIN customers c ON c.id=l.customer_id $where", $params
)['c'] ?? 0);
$pag = ep_paginate($total, $page);

$pParams = array_merge($params, [$pag['perPage'], $pag['offset']]);
$loans = EP_Database::query(
    "SELECT l.id, l.loan_number, l.amount, l.interest_rate, l.term_months, l.status,
            l.created_at, lt.name AS loan_type,
            CONCAT(c.first_name,' ',c.last_name) AS customer_name, c.phone
     FROM loans l
     LEFT JOIN customers c   ON c.id = l.customer_id
     LEFT JOIN loan_types lt ON lt.id = l.loan_type_id
     $where ORDER BY l.created_at DESC LIMIT ? OFFSET ?",
    $pParams
) ?: [
    ['id'=>1,'loan_number'=>'LN-2026-000042','loan_type'=>'Personal Loan','customer_name'=>'Kebede Alemu',   'phone'=>'+251 911 000 111','amount'=>150000,'interest_rate'=>12.5,'term_months'=>24,'status'=>'Pending','created_at'=>date('Y-m-d H:i:s',strtotime('-1 day'))],
    ['id'=>2,'loan_number'=>'LN-2026-000043','loan_type'=>'Business Loan','customer_name'=>'Hiwot Tadesse',  'phone'=>'+251 912 222 333','amount'=>500000,'interest_rate'=>14.0,'term_months'=>36,'status'=>'Pending','created_at'=>date('Y-m-d H:i:s',strtotime('-2 days'))],
    ['id'=>3,'loan_number'=>'LN-2026-000041','loan_type'=>'Mortgage Loan','customer_name'=>'Dawit Mengistu', 'phone'=>'+251 913 444 555','amount'=>1200000,'interest_rate'=>10.5,'term_months'=>120,'status'=>'Active','created_at'=>date('Y-m-d H:i:s',strtotime('-5 days'))],
    ['id'=>4,'loan_number'=>'LN-2026-000040','loan_type'=>'Personal Loan','customer_name'=>'Selam Worku',    'phone'=>'+251 914 666 777','amount'=>80000, 'interest_rate'=>13.0,'term_months'=>18,'status'=>'Rejected','created_at'=>date('Y-m-d H:i:s',strtotime('-7 days'))],
];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i> Loan Applications</h1>
    <p>Review and process loan applications</p>
  </div>
</div>

<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div>
        <label class="ep-label">Status</label>
        <select name="status" class="ep-select" style="width:140px">
          <option value="">All</option>
          <?php foreach (['Pending','Active','Rejected','Completed'] as $s): ?>
          <option value="<?= $s ?>" <?= $statusFilter===$s?'selected':'' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="ep-label">Search</label>
        <input type="text" name="search" class="ep-input ep-inp-noi" value="<?= ep_e($search) ?>" placeholder="Name or loan #" style="width:200px">
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="applications.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>

<div class="ep-card">
  <div class="ep-card-hdr">
    <h3>Applications <span style="font-size:.8rem;font-weight:400;color:var(--muted)">(<?= number_format($total) ?> total)</span></h3>
  </div>
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr>
            <th>Loan #</th>
            <th>Applicant</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Rate</th>
            <th>Term</th>
            <th>Applied</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($loans)): ?>
          <tr><td colspan="9" style="text-align:center;padding:32px;color:var(--muted)">No applications found</td></tr>
          <?php else: ?>
          <?php foreach ($loans as $l): ?>
          <tr>
            <td><code style="font-size:.78rem;background:var(--surface);padding:2px 6px;border-radius:4px"><?= ep_e($l['loan_number']) ?></code></td>
            <td>
              <div class="fw-6" style="font-size:.84rem"><?= ep_e($l['customer_name']) ?></div>
              <div style="font-size:.76rem;color:var(--muted)"><?= ep_e($l['phone'] ?? '') ?></div>
            </td>
            <td style="font-size:.82rem"><?= ep_e($l['loan_type'] ?? '—') ?></td>
            <td class="fw-6"><?= ep_etb((float)($l['amount'] ?? 0)) ?></td>
            <td><?= number_format((float)($l['interest_rate'] ?? 0), 1) ?>%</td>
            <td style="font-size:.82rem"><?= (int)($l['term_months'] ?? 0) ?> mo</td>
            <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($l['created_at'] ?? '') ?></td>
            <td><?= ep_badge($l['status'] ?? '') ?></td>
            <td>
              <a href="view.php?id=<?= (int)$l['id'] ?>" class="ep-btn ep-btn-ghost ep-btn-sm">
                <i class="fa-solid fa-eye"></i> Review
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
