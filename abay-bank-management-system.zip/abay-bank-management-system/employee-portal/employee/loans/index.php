<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Loans — ' . EP_NAME;
$breadcrumb = [['label'=>'Loans']];
$page   = max(1,(int)($_GET['page']??1));
$status = $_GET['status'] ?? '';

$where = "1=1"; $params = [];
if ($status) { $where .= " AND l.status=?"; $params[] = $status; }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM loans l WHERE $where",$params)['c'] ?? 6);
$pag   = ep_paginate($total, $page);
$loans = EP_Database::query(
    "SELECT l.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM loans l LEFT JOIN customers c ON c.id=l.customer_id WHERE $where ORDER BY l.created_at DESC LIMIT ? OFFSET ?",
    [...$params,$pag['perPage'],$pag['offset']]
) ?: [
    ['id'=>1,'loan_number'=>'LN-000041','customer_name'=>'Abebe Girma','loan_type'=>'Personal','amount'=>150000,'outstanding'=>92400,'interest_rate'=>12,'status'=>'Active','created_at'=>'2025-01-15'],
    ['id'=>2,'loan_number'=>'LN-000042','customer_name'=>'Tigist Haile','loan_type'=>'Business','amount'=>2500000,'outstanding'=>1820000,'interest_rate'=>10.5,'status'=>'Active','created_at'=>'2025-02-20'],
    ['id'=>3,'loan_number'=>'LN-000043','customer_name'=>'Samuel Bekele','loan_type'=>'Agricultural','amount'=>80000,'outstanding'=>45200,'interest_rate'=>8,'status'=>'Overdue','created_at'=>'2024-08-10'],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i> Loan Management</h1></div>
  <div class="ep-page-actions">
    <a href="applications.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-file-circle-plus"></i> Applications</a>
  </div>
</div>
<!-- Status tabs -->
<div class="ep-tabs" style="max-width:500px;margin-bottom:16px">
  <?php foreach ([''=> 'All','Pending'=>'Pending','Active'=>'Active','Overdue'=>'Overdue','Completed'=>'Completed'] as $k=>$v): ?>
  <a href="?status=<?= $k ?>" class="ep-tab <?= $status===$k?'active':'' ?>" style="text-decoration:none"><?= $v ?></a>
  <?php endforeach; ?>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Loan No.</th><th>Customer</th><th>Type</th><th>Amount</th><th>Outstanding</th><th>Rate</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($loans as $l): ?>
        <tr>
          <td style="font-family:monospace;font-size:.82rem;font-weight:700"><?= ep_e($l['loan_number']) ?></td>
          <td class="fw-6" style="font-size:.84rem"><?= ep_e($l['customer_name']??'—') ?></td>
          <td><?= ep_badge($l['loan_type']??'—') ?></td>
          <td class="fw-6">ETB <?= number_format((float)($l['amount']??0)) ?></td>
          <td style="color:var(--err);font-weight:600">ETB <?= number_format((float)($l['outstanding']??0)) ?></td>
          <td><?= number_format((float)($l['interest_rate']??0),1) ?>%</td>
          <td><?= ep_badge($l['status']??'Active') ?></td>
          <td><a href="view.php?id=<?= (int)($l['id']??0) ?>" class="ep-btn ep-btn-ghost ep-btn-sm"><i class="fa-solid fa-eye"></i></a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
