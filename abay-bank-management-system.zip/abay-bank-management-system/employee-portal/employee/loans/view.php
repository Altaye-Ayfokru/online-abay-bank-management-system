<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$empId  = (int)($emp['id'] ?? 0);
$loanId = (int)($_GET['id'] ?? 0);

if (!$loanId) {
    ep_flash('danger', 'Invalid loan ID.');
    ep_redirect(EP_BASE_URL . '/employee/loans/applications.php');
}

$loan = EP_Database::queryOne(
    "SELECT l.*, c.first_name, c.last_name, c.phone, c.email, c.national_id,
            lt.name AS loan_type_name, b.name AS branch_name
     FROM loans l
     LEFT JOIN customers c  ON c.id = l.customer_id
     LEFT JOIN loan_types lt ON lt.id = l.loan_type_id
     LEFT JOIN branches b   ON b.id  = l.branch_id
     WHERE l.id = ?",
    [$loanId]
) ?: [
    'id'=>$loanId,'loan_number'=>'LN-2026-000042','loan_type_name'=>'Personal Loan',
    'first_name'=>'Kebede','last_name'=>'Alemu','phone'=>'+251 911 000 111',
    'email'=>'kebede.alemu@example.com','national_id'=>'ET123456789',
    'branch_name'=>'Head Office','amount'=>150000,'outstanding'=>135000,
    'interest_rate'=>12.5,'term_months'=>24,'disbursement_date'=>'2026-01-15',
    'maturity_date'=>'2028-01-15','status'=>'Active','purpose'=>'Business capital for small retail shop',
    'collateral'=>'Title deed for residential property','created_at'=>'2026-01-10 09:00:00',
];

// Demo repayment schedule
$schedule = EP_Database::query(
    "SELECT * FROM loan_repayments WHERE loan_id=? ORDER BY due_date ASC", [$loanId]
) ?: array_map(static function(int $i) use ($loan): array {
    $due = date('Y-m-d', strtotime($loan['disbursement_date'] . ' +' . $i . ' months'));
    $paid = $i <= 2;
    return [
        'installment_no' => $i,
        'due_date'       => $due,
        'principal'      => 6250,
        'interest'       => round(($loan['amount'] ?? 150000) * ($loan['interest_rate'] ?? 12.5) / 100 / 12, 2),
        'total'          => 0,
        'status'         => $paid ? 'Paid' : ($i == 3 ? 'Pending' : 'Upcoming'),
        'paid_date'      => $paid ? date('Y-m-d', strtotime($due . ' -3 days')) : null,
    ];
}, range(1, 6));
foreach ($schedule as &$row) { $row['total'] = $row['principal'] + $row['interest']; }
unset($row);

$pageTitle  = 'Loan #' . ep_e($loan['loan_number'] ?? $loanId) . ' — ' . EP_NAME;
$breadcrumb = [['label'=>'Loans','url'=>EP_BASE_URL.'/employee/loans/applications.php'],['label'=>'View Loan']];

// Handle approve / reject actions
$actionMsg = ep_get_flash('success');
$actionErr = ep_get_flash('danger');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $action = $_POST['action'] ?? '';
    $note   = trim($_POST['note'] ?? '');
    if (in_array($action, ['approve','reject'], true)) {
        $newStatus = $action === 'approve' ? 'Active' : 'Rejected';
        $db = EP_Database::get();
        if ($db) {
            EP_Database::execute(
                "UPDATE loans SET status=?, officer_note=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?",
                [$newStatus, $note, $empId, $loanId]
            );
            EP_Database::execute(
                "INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",
                [$empId, ucfirst($action) . "d loan $loanId. Note: $note", 'loan']
            );
            $loan['status'] = $newStatus;
        }
        ep_flash('success', "Loan has been " . $newStatus . " successfully.");
        ep_redirect(EP_BASE_URL . '/employee/loans/view.php?id=' . $loanId);
    }
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-file-invoice-dollar" style="color:var(--teal)"></i>
        Loan <?= ep_e($loan['loan_number'] ?? '#'.$loanId) ?></h1>
    <p><?= ep_e(($loan['first_name'] ?? '') . ' ' . ($loan['last_name'] ?? '')) ?> &mdash; <?= ep_e($loan['loan_type_name'] ?? '') ?></p>
  </div>
  <div class="ep-page-actions">
    <a href="applications.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>

<?php if ($actionMsg): ?><div class="ep-alert ep-alert-success"><i class="fa-solid fa-circle-check"></i> <?= ep_e($actionMsg) ?></div><?php endif; ?>
<?php if ($actionErr): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= ep_e($actionErr) ?></div><?php endif; ?>

<!-- Loan Summary Stats -->
<div class="ep-stats" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:20px">
  <?php
  $stats = [
    ['Loan Amount',     ep_etb((float)($loan['amount']??0)),       'fa-money-bill-wave','#22c55e','#dcfce7'],
    ['Outstanding',     ep_etb((float)($loan['outstanding']??0)),  'fa-hourglass-half', '#ef4444','#fee2e2'],
    ['Interest Rate',   ($loan['interest_rate']??0) . '% p.a.',    'fa-percent',        '#3b82f6','#dbeafe'],
    ['Term',            ($loan['term_months']??0) . ' months',     'fa-calendar',       '#8b5cf6','#ede9fe'],
  ];
  foreach ($stats as [$lbl,$val,$icon,$color,$bg]):
  ?>
  <div class="ep-stat">
    <div class="ep-stat-ic" style="background:<?= $bg ?>;color:<?= $color ?>"><i class="fa-solid fa-<?= $icon ?>"></i></div>
    <div>
      <div class="ep-stat-val" style="color:<?= $color ?>"><?= $val ?></div>
      <div class="ep-stat-lbl"><?= $lbl ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="ep-grid-2" style="align-items:start">
  <!-- Loan Details -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Loan Details</h3><?= ep_badge($loan['status'] ?? 'Pending') ?></div>
    <div class="ep-card-body">
      <?php
      $details = [
        ['Loan Number',    $loan['loan_number']    ?? '—'],
        ['Loan Type',      $loan['loan_type_name'] ?? '—'],
        ['Branch',         $loan['branch_name']    ?? '—'],
        ['Disbursement',   ep_date($loan['disbursement_date'] ?? '')],
        ['Maturity Date',  ep_date($loan['maturity_date'] ?? '')],
        ['Purpose',        $loan['purpose'] ?? '—'],
        ['Collateral',     $loan['collateral'] ?? '—'],
      ];
      foreach ($details as [$l,$v]):
      ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem;gap:12px">
        <span class="text-muted" style="white-space:nowrap"><?= $l ?></span>
        <span class="fw-6" style="text-align:right"><?= ep_e($v) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Customer Details -->
  <div>
    <div class="ep-card" style="margin-bottom:16px">
      <div class="ep-card-hdr"><h3>Customer</h3></div>
      <div class="ep-card-body">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
          <div style="width:48px;height:48px;border-radius:50%;background:var(--teal);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem">
            <?= strtoupper(substr($loan['first_name']??'?',0,1) . substr($loan['last_name']??'',0,1)) ?>
          </div>
          <div>
            <div class="fw-6"><?= ep_e(($loan['first_name']??'') . ' ' . ($loan['last_name']??'')) ?></div>
            <div style="font-size:.8rem;color:var(--muted)"><?= ep_e($loan['email'] ?? '') ?></div>
          </div>
        </div>
        <?php foreach ([['Phone',$loan['phone']??'—'],['National ID',$loan['national_id']??'—']] as [$l,$v]): ?>
        <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem">
          <span class="text-muted"><?= $l ?></span><span class="fw-6"><?= ep_e($v) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Actions (if Pending) -->
    <?php if (($loan['status'] ?? '') === 'Pending'): ?>
    <div class="ep-card">
      <div class="ep-card-hdr"><h3>Review Decision</h3></div>
      <div class="ep-card-body">
        <form method="POST">
          <?= ep_csrf_field() ?>
          <div class="ep-form-group">
            <label class="ep-label">Officer Note</label>
            <textarea name="note" class="ep-textarea" rows="3" placeholder="Add a review note (optional)..."></textarea>
          </div>
          <div style="display:flex;gap:10px">
            <button type="submit" name="action" value="approve" class="ep-btn ep-btn-primary" style="flex:1"
                    onclick="return confirm('Approve this loan?')">
              <i class="fa-solid fa-check"></i> Approve
            </button>
            <button type="submit" name="action" value="reject" class="ep-btn ep-btn-outline" style="flex:1;color:#ef4444;border-color:#ef4444"
                    onclick="return confirm('Reject this loan?')">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
          </div>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Repayment Schedule -->
<div class="ep-card" style="margin-top:20px">
  <div class="ep-card-hdr"><h3><i class="fa-solid fa-calendar-days" style="color:var(--teal)"></i> Repayment Schedule</h3></div>
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead>
        <tr><th>#</th><th>Due Date</th><th>Principal</th><th>Interest</th><th>Total</th><th>Paid Date</th><th>Status</th></tr>
      </thead>
      <tbody>
        <?php foreach ($schedule as $s): ?>
        <tr>
          <td class="fw-6" style="color:var(--muted)"><?= (int)($s['installment_no'] ?? 0) ?></td>
          <td><?= ep_date($s['due_date'] ?? '') ?></td>
          <td><?= ep_etb((float)($s['principal'] ?? 0)) ?></td>
          <td><?= ep_etb((float)($s['interest'] ?? 0)) ?></td>
          <td class="fw-6"><?= ep_etb((float)($s['total'] ?? 0)) ?></td>
          <td style="color:var(--muted);font-size:.82rem"><?= $s['paid_date'] ? ep_date($s['paid_date']) : '—' ?></td>
          <td><?= ep_badge($s['status'] ?? 'Upcoming') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
