<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Compose Message — ' . EP_NAME;
$breadcrumb = [['label'=>'Messages','url'=>EP_BASE_URL.'/employee/messages/index.php'],['label'=>'Compose']];
$empId = (int)($emp['id'] ?? 0);
$errors  = [];
$success = null;

// Load employees for "To" dropdown (exclude self)
$employees = EP_Database::query(
    "SELECT id, first_name, last_name, role, dept_name FROM employees WHERE id != ? AND status='Active' ORDER BY first_name, last_name",
    [$empId]
) ?: [
    ['id'=>1,'first_name'=>'Abebe',  'last_name'=>'Girma',  'role'=>'Teller',          'dept_name'=>'Operations'],
    ['id'=>2,'first_name'=>'Tigist', 'last_name'=>'Haile',  'role'=>'Loan Officer',    'dept_name'=>'Loans'],
    ['id'=>3,'first_name'=>'Samuel', 'last_name'=>'Bekele', 'role'=>'IT Staff',        'dept_name'=>'IT'],
    ['id'=>4,'first_name'=>'Meron',  'last_name'=>'Tesfaye','role'=>'Customer Service','dept_name'=>'Customer Service'],
    ['id'=>5,'first_name'=>'Dawit',  'last_name'=>'Mengistu','role'=>'Branch Manager', 'dept_name'=>'Management'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $recipientId = (int)($_POST['recipient_id'] ?? 0);
    $subject     = trim($_POST['subject'] ?? '');
    $body        = trim($_POST['body']    ?? '');

    if (!$recipientId) $errors[] = 'Please select a recipient.';
    if (!$subject)     $errors[] = 'Subject is required.';
    if (mb_strlen($subject) > 200) $errors[] = 'Subject must be 200 characters or fewer.';
    if (!$body)        $errors[] = 'Message body is required.';
    if (mb_strlen($body) > 5000)   $errors[] = 'Message must be 5000 characters or fewer.';

    if (!$errors) {
        // Verify recipient exists
        $validRecipient = false;
        foreach ($employees as $e) {
            if ((int)$e['id'] === $recipientId) { $validRecipient = true; break; }
        }
        if (!$validRecipient) $errors[] = 'Invalid recipient selected.';
    }

    if (!$errors) {
        $db = EP_Database::get();
        if ($db) {
            EP_Database::execute(
                "INSERT INTO messages (sender_id,recipient_id,subject,body,is_read,created_at) VALUES (?,?,?,?,0,NOW())",
                [$empId, $recipientId, $subject, $body]
            );
            EP_Database::execute(
                "INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",
                [$empId, "Sent message: $subject", 'message']
            );
        }
        ep_flash('success', 'Message sent successfully.');
        ep_redirect(EP_BASE_URL . '/employee/messages/index.php?tab=sent');
    }
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-pen-to-square" style="color:var(--teal)"></i> Compose Message</h1></div>
  <div class="ep-page-actions">
    <a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>

<?php foreach ($errors as $e): ?>
<div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i> <?= ep_e($e) ?></div>
<?php endforeach; ?>

<div style="max-width:760px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>New Message</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group">
          <label class="ep-label">To <span class="req">*</span></label>
          <select name="recipient_id" class="ep-select" required>
            <option value="">— Select recipient —</option>
            <?php foreach ($employees as $e): ?>
            <?php $sel = isset($_POST['recipient_id']) && (int)$_POST['recipient_id'] === (int)$e['id'] ? 'selected' : ''; ?>
            <option value="<?= (int)$e['id'] ?>" <?= $sel ?>>
              <?= ep_e($e['first_name'] . ' ' . $e['last_name']) ?> — <?= ep_e($e['role'] . ' (' . ($e['dept_name'] ?? '') . ')') ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Subject <span class="req">*</span></label>
          <input type="text" name="subject" class="ep-input ep-inp-noi" maxlength="200" required
                 value="<?= ep_e($_POST['subject'] ?? '') ?>" placeholder="Message subject">
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Message <span class="req">*</span></label>
          <textarea name="body" class="ep-textarea" rows="8" maxlength="5000" required
                    placeholder="Write your message here..."><?= ep_e($_POST['body'] ?? '') ?></textarea>
          <div style="font-size:.76rem;color:var(--muted);margin-top:4px">Max 5000 characters</div>
        </div>
        <div style="display:flex;gap:10px">
          <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
          <a href="index.php" class="ep-btn ep-btn-outline">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
