<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Messages — ' . EP_NAME;
$breadcrumb = [['label'=>'Messages']];
$empId = (int)($emp['id'] ?? 0);

$tab  = $_GET['tab']  ?? 'inbox';
$page = max(1, (int)($_GET['page'] ?? 1));

// Mark as read on click
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
    ep_csrf_check();
    $msgId = (int)$_POST['mark_read'];
    EP_Database::execute("UPDATE messages SET is_read=1, read_at=NOW() WHERE id=? AND recipient_id=?", [$msgId, $empId]);
    ep_redirect(EP_BASE_URL . '/employee/messages/index.php?tab=inbox');
}

// Count unread
$unread = (int)(EP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM messages WHERE recipient_id=? AND is_read=0", [$empId]
)['c'] ?? 0);

// Inbox or Sent
if ($tab === 'sent') {
    $total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM messages WHERE sender_id=?", [$empId])['c'] ?? 0);
    $pag = ep_paginate($total, $page);
    $messages = EP_Database::query(
        "SELECT m.*, CONCAT(e.first_name,' ',e.last_name) AS other_name, e.role AS other_role
         FROM messages m LEFT JOIN employees e ON e.id = m.recipient_id
         WHERE m.sender_id = ? ORDER BY m.created_at DESC LIMIT ? OFFSET ?",
        [$empId, $pag['perPage'], $pag['offset']]
    ) ?: [
        ['id'=>3,'subject'=>'RE: Monthly Report','body'=>'Please review the attached monthly summary.','other_name'=>'HR Office',     'other_role'=>'HR Officer',     'is_read'=>1,'created_at'=>date('Y-m-d H:i:s',strtotime('-1 day'))],
        ['id'=>4,'subject'=>'Leave Request',     'body'=>'Requesting approval for annual leave.',      'other_name'=>'Branch Manager','other_role'=>'Branch Manager', 'is_read'=>1,'created_at'=>date('Y-m-d H:i:s',strtotime('-3 days'))],
    ];
} else {
    $total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM messages WHERE recipient_id=?", [$empId])['c'] ?? 0);
    $pag = ep_paginate($total, $page);
    $messages = EP_Database::query(
        "SELECT m.*, CONCAT(e.first_name,' ',e.last_name) AS other_name, e.role AS other_role
         FROM messages m LEFT JOIN employees e ON e.id = m.sender_id
         WHERE m.recipient_id = ? ORDER BY m.created_at DESC LIMIT ? OFFSET ?",
        [$empId, $pag['perPage'], $pag['offset']]
    ) ?: [
        ['id'=>1,'subject'=>'Monthly Performance Review',    'body'=>'Please review your performance report for this month and provide your feedback.', 'other_name'=>'HR Office',     'other_role'=>'HR Officer',      'is_read'=>0,'created_at'=>date('Y-m-d H:i:s',strtotime('-30 minutes'))],
        ['id'=>2,'subject'=>'System Maintenance Notice',     'body'=>'The banking system will undergo maintenance on Saturday from 11PM to 2AM.',       'other_name'=>'IT Support',    'other_role'=>'IT Staff',        'is_read'=>0,'created_at'=>date('Y-m-d H:i:s',strtotime('-2 hours'))],
        ['id'=>5,'subject'=>'New Policy Update',             'body'=>'Please read the updated HR policies attached to this message.',                   'other_name'=>'HR Office',     'other_role'=>'HR Officer',      'is_read'=>1,'created_at'=>date('Y-m-d H:i:s',strtotime('-1 day'))],
        ['id'=>6,'subject'=>'Branch Meeting Reminder',       'body'=>'Reminder: All-staff meeting tomorrow at 9AM in the main conference room.',         'other_name'=>'Branch Manager','other_role'=>'Branch Manager',  'is_read'=>1,'created_at'=>date('Y-m-d H:i:s',strtotime('-2 days'))],
        ['id'=>7,'subject'=>'Customer Complaint Assignment', 'body'=>'You have been assigned complaint TKT-2026-001. Please review and respond.',        'other_name'=>'System',        'other_role'=>'Automated',       'is_read'=>1,'created_at'=>date('Y-m-d H:i:s',strtotime('-3 days'))],
    ];
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-envelope" style="color:var(--teal)"></i> Messages
      <?php if ($unread > 0): ?>
      <span style="background:#ef4444;color:#fff;font-size:.7rem;font-weight:700;border-radius:20px;padding:2px 8px;vertical-align:middle"><?= $unread ?></span>
      <?php endif; ?>
    </h1>
    <p>Internal communications</p>
  </div>
  <div class="ep-page-actions">
    <a href="compose.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-pen"></i> Compose</a>
  </div>
</div>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:16px;border-bottom:2px solid var(--border)">
  <?php foreach ([['inbox','Inbox','inbox'],['sent','Sent','paper-plane']] as [$key,$label,$icon]): ?>
  <a href="?tab=<?= $key ?>" style="padding:10px 18px;font-weight:600;font-size:.88rem;text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;
     <?= $tab===$key ? 'color:var(--teal);border-color:var(--teal)' : 'color:var(--muted)' ?>">
    <i class="fa-solid fa-<?= $icon ?>"></i> <?= $label ?>
    <?php if ($key==='inbox' && $unread>0): ?>
    <span style="background:#ef4444;color:#fff;font-size:.68rem;border-radius:20px;padding:1px 6px"><?= $unread ?></span>
    <?php endif; ?>
  </a>
  <?php endforeach; ?>
</div>

<div class="ep-card">
  <div class="ep-card-body p0">
    <?php if (empty($messages)): ?>
    <div style="text-align:center;padding:40px;color:var(--muted)">
      <i class="fa-solid fa-envelope-open" style="font-size:2rem;margin-bottom:10px;display:block"></i>
      <?= $tab === 'sent' ? 'No sent messages.' : 'Your inbox is empty.' ?>
    </div>
    <?php else: ?>
    <?php foreach ($messages as $m): ?>
    <?php $isUnread = !$m['is_read'] && $tab === 'inbox'; ?>
    <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:14px;align-items:flex-start;<?= $isUnread ? 'background:var(--surface)' : '' ?>">
      <!-- Avatar -->
      <div style="width:40px;height:40px;min-width:40px;border-radius:50%;background:var(--teal);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem">
        <?= strtoupper(substr($m['other_name'] ?? '?', 0, 1)) ?>
      </div>
      <!-- Content -->
      <div style="flex:1;min-width:0">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
          <div style="min-width:0">
            <span class="fw-6" style="font-size:.86rem"><?= ep_e($m['other_name'] ?? '—') ?></span>
            <span style="font-size:.76rem;color:var(--muted);margin-left:6px"><?= ep_e($m['other_role'] ?? '') ?></span>
          </div>
          <div style="display:flex;align-items:center;gap:8px;white-space:nowrap">
            <?php if ($isUnread): ?><span class="ep-badge ep-badge-info">New</span><?php endif; ?>
            <span style="font-size:.76rem;color:var(--muted)"><?= ep_ago($m['created_at'] ?? '') ?></span>
          </div>
        </div>
        <div style="font-weight:<?= $isUnread ? '700' : '400' ?>;font-size:.85rem;margin:2px 0 4px"><?= ep_e($m['subject'] ?? '') ?></div>
        <div style="font-size:.8rem;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= ep_e($m['body'] ?? '') ?></div>
      </div>
      <!-- Mark read -->
      <?php if ($isUnread): ?>
      <form method="POST" style="margin:0">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="mark_read" value="<?= (int)$m['id'] ?>">
        <button type="submit" class="ep-btn ep-btn-ghost ep-btn-sm" title="Mark as read">
          <i class="fa-solid fa-check"></i>
        </button>
      </form>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
