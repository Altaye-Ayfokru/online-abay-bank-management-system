<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp   = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$pageTitle  = 'Notifications — ' . EP_NAME;
$breadcrumb = [['label'=>'Notifications']];

// Mark all read if requested
if (isset($_GET['mark_all'])) {
    EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE employee_id=?", [$empId]);
    ep_flash('success', 'All notifications marked as read.');
    header('Location: ' . EP_BASE_URL . '/employee/notifications/index.php'); exit;
}

// Mark single read via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    $nid = (int)($_POST['id'] ?? 0);
    EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE id=? AND employee_id=?", [$nid, $empId]);
    header('Content-Type: application/json');
    echo json_encode(['success' => true]); exit;
}

$page  = max(1, (int)($_GET['page'] ?? 1));
$filter= $_GET['filter'] ?? 'all';

$where  = "n.employee_id=?"; $params = [$empId];
if ($filter === 'unread') { $where .= " AND n.is_read=0"; }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications n WHERE $where", $params)['c'] ?? 5);
$pag   = ep_paginate($total, $page);
$notifs = EP_Database::query(
    "SELECT * FROM employee_notifications WHERE employee_id=?" . ($filter==='unread'?" AND is_read=0":"") . " ORDER BY created_at DESC LIMIT ? OFFSET ?",
    [$empId, $pag['perPage'], $pag['offset']]
) ?: [
    ['id'=>1,'title'=>'Payslip Ready','message'=>'Your payslip for '.date('F Y',strtotime('-1 month')).' is ready to download.','type'=>'payroll','is_read'=>0,'created_at'=>date('Y-m-d H:i:s',time()-3600)],
    ['id'=>2,'title'=>'Leave Approved','message'=>'Your annual leave request (5 days) has been approved by the manager.','type'=>'leave','is_read'=>0,'created_at'=>date('Y-m-d H:i:s',time()-7200)],
    ['id'=>3,'title'=>'New Task Assigned','message'=>'You have been assigned: Review loan application LN-00234.','type'=>'task','is_read'=>1,'created_at'=>date('Y-m-d H:i:s',time()-86400)],
    ['id'=>4,'title'=>'Training Reminder','message'=>'Core Banking System Training starts tomorrow (Sep 1).','type'=>'training','is_read'=>1,'created_at'=>date('Y-m-d H:i:s',time()-172800)],
    ['id'=>5,'title'=>'Password Expiry','message'=>'Your password will expire in 7 days. Please update it.','type'=>'security','is_read'=>0,'created_at'=>date('Y-m-d H:i:s',time()-3*86400)],
];
$unread = count(array_filter($notifs, fn($n) => !$n['is_read']));

$typeIcons = ['payroll'=>['fa-receipt','#22c55e','#dcfce7'],'leave'=>['fa-calendar-xmark','#3b82f6','#dbeafe'],'task'=>['fa-list-check','#f59e0b','#fef9c3'],'training'=>['fa-graduation-cap','#7c3aed','#ede9fe'],'security'=>['fa-shield-halved','#ef4444','#fee2e2'],'general'=>['fa-bell','#007A8A','#e0f5f7']];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-bell" style="color:var(--teal)"></i> Notifications <?php if ($unread > 0): ?><span class="ep-badge ep-badge-danger" style="font-size:.8rem;margin-left:8px"><?= $unread ?> new</span><?php endif; ?></h1></div>
  <div class="ep-page-actions">
    <?php if ($unread > 0): ?><a href="?mark_all=1" class="ep-btn ep-btn-outline"><i class="fa-solid fa-check-double"></i> Mark All Read</a><?php endif; ?>
  </div>
</div>

<div class="ep-tabs" style="max-width:300px;margin-bottom:16px">
  <a href="?filter=all"    class="ep-tab <?= $filter==='all'   ?'active':'' ?>" style="text-decoration:none">All</a>
  <a href="?filter=unread" class="ep-tab <?= $filter==='unread'?'active':'' ?>" style="text-decoration:none">Unread <?php if ($unread>0): ?><span class="ep-badge ep-badge-danger" style="font-size:.7rem"><?= $unread ?></span><?php endif; ?></a>
</div>

<div style="display:flex;flex-direction:column;gap:8px">
  <?php foreach ($notifs as $n):
    [$ic,$clr,$bg] = $typeIcons[$n['type']??'general'] ?? ['fa-bell','#007A8A','#e0f5f7'];
    $unreadStyle = !$n['is_read'] ? 'border-left:4px solid var(--teal);' : 'border-left:4px solid transparent;';
  ?>
  <div class="ep-card" style="<?= $unreadStyle ?><?= !$n['is_read']?'background:rgba(0,122,138,.03)':'' ?>;margin-bottom:0" id="notif-<?= (int)$n['id'] ?>">
    <div class="ep-card-body" style="padding:14px 18px">
      <div style="display:flex;align-items:flex-start;gap:14px">
        <div style="width:40px;height:40px;border-radius:10px;background:<?= $bg ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fa-solid <?= $ic ?>" style="color:<?= $clr ?>;font-size:.9rem"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap">
            <h4 style="font-size:.9rem;font-weight:<?= !$n['is_read']?'700':'600' ?>;color:var(--navy);margin-bottom:4px"><?= ep_e($n['title']) ?><?php if (!$n['is_read']): ?><span style="display:inline-block;width:8px;height:8px;background:var(--teal);border-radius:50%;margin-left:8px;vertical-align:middle"></span><?php endif; ?></h4>
            <span style="font-size:.75rem;color:var(--muted);white-space:nowrap"><?= ep_ago($n['created_at']??'') ?></span>
          </div>
          <p style="font-size:.84rem;color:var(--muted);margin:0;line-height:1.5"><?= ep_e($n['message']) ?></p>
        </div>
        <?php if (!$n['is_read']): ?>
        <button onclick="markRead(<?= (int)$n['id'] ?>)" class="ep-btn ep-btn-ghost ep-btn-sm" title="Mark as read" style="flex-shrink:0">
          <i class="fa-solid fa-check"></i>
        </button>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (empty($notifs)): ?>
  <div class="ep-card"><div class="ep-card-body" style="text-align:center;padding:48px">
    <i class="fa-solid fa-bell-slash" style="font-size:2.5rem;color:#cbd5e1;display:block;margin-bottom:12px"></i>
    <p class="text-muted">No notifications<?= $filter==='unread'?' to read':'' ?>.</p>
  </div></div>
  <?php endif; ?>
</div>
<script>
function markRead(id) {
  fetch('<?= EP_BASE_URL ?>/employee/notifications/index.php', {
    method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
    body:'id='+id
  }).then(()=>{
    var el = document.getElementById('notif-'+id);
    if (el) { el.style.borderLeftColor='transparent'; el.style.background=''; }
    EP.toast('Marked as read','success');
  });
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
