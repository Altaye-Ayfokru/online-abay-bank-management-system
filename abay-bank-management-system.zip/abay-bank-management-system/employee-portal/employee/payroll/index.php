<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle   = 'Payroll — ' . EP_NAME;
$breadcrumb  = [['label' => 'Payroll']];
$needsCharts = true;
$empId = (int)($emp['id'] ?? 0);

// Real columns: pay_period (YYYY-MM), basic_salary, transport_allow,
//               housing_allow, gross_salary, income_tax, pension,
//               total_deductions, net_salary, paid_date, status
$latest = EP_Database::queryOne(
  "SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT 1",
  [$empId]
) ?? [
  'pay_period'      => date('Y-m', strtotime('-1 month')),
  'basic_salary'    => (float)($emp['basic_salary'] ?? 18500),
  'transport_allow' => 1500,
  'housing_allow'   => 2000,
  'gross_salary'    => 22000,
  'income_tax'      => 3300,
  'pension'         => 1295,
  'total_deductions' => 4595,
  'net_salary'      => 17405,
  'status'          => 'Paid',
];

$gross      = (float)($latest['gross_salary']    ?? (float)$latest['basic_salary'] + (float)($latest['transport_allow'] ?? 0) + (float)($latest['housing_allow'] ?? 0));
$deductions = (float)($latest['total_deductions'] ?? (float)($latest['income_tax'] ?? 0) + (float)($latest['pension'] ?? 0));
if (!$deductions && $gross > 0) {
  $taxable    = $gross - 600;
  $deductions = $taxable > 0 ? round($taxable * 0.15, 2) : 0;
}
$net = (float)($latest['net_salary'] ?: $gross - $deductions);

// Period label: "2026-08" → "August 2026"
function periodLabel(string $p): string
{
  $parts = explode('-', $p);
  return count($parts) === 2 ? date('F Y', mktime(0, 0, 0, (int)$parts[1], 1, (int)$parts[0])) : $p;
}

$payslips = EP_Database::query(
  "SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT 12",
  [$empId]
) ?: array_map(fn($i) => [
  'id'              => $i + 1,
  'pay_period'      => date('Y-m', strtotime("-$i months")),
  'gross_salary'    => $gross,
  'total_deductions' => $deductions,
  'net_salary'      => $net,
  'status'          => 'Paid',
], range(0, 11));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-receipt" style="color:var(--teal)"></i> My Payroll</h1>
    <p>Salary breakdown, payslips, and payment history</p>
  </div>
</div>

<!-- Current Month Banner -->
<div class="ep-card" style="border-left:4px solid var(--teal);margin-bottom:20px">
  <div class="ep-card-body">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
      <div>
        <div style="font-size:.75rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">
          Net Pay — <?= periodLabel($latest['pay_period'] ?? date('Y-m', strtotime('-1 month'))) ?>
        </div>
        <div style="font-size:2rem;font-weight:800;color:var(--navy)">ETB <?= number_format($net, 2) ?></div>
        <div style="font-size:.82rem;color:var(--muted);margin-top:4px">
          Gross: ETB <?= number_format($gross, 2) ?> &nbsp;·&nbsp; Deductions: ETB <?= number_format($deductions, 2) ?>
        </div>
      </div>
      <a href="<?= EP_BASE_URL ?>/employee/payroll/view-payslip.php?id=<?= (int)($payslips[0]['id'] ?? 1) ?>"
        class="ep-btn ep-btn-primary">
        <i class="fa-solid fa-download"></i> Download Latest Payslip
      </a>
    </div>
  </div>
</div>

<!-- Salary Breakdown + Chart -->
<div class="ep-grid-2">
  <div class="ep-card">
    <div class="ep-card-hdr">
      <h3>Salary Breakdown</h3>
    </div>
    <div class="ep-card-body">
      <?php
      $earnings = [
        ['Basic Salary',        $latest['basic_salary']    ?? 0, true],
        ['Transport Allowance', $latest['transport_allow'] ?? 0, true],
        ['Housing Allowance',   $latest['housing_allow']   ?? 0, true],
        ['Other Allowances',    $latest['other_allowances'] ?? 0, true],
      ];
      $dedRows = [
        ['Income Tax',          $latest['income_tax']       ?? 0, false],
        ['Pension (7%)',        $latest['pension']           ?? 0, false],
        ['Other Deductions',    $latest['other_deductions']  ?? 0, false],
      ];
      foreach (array_merge($earnings, $dedRows) as [$label, $amount, $isCredit]):
        if (!(float)$amount) continue;
      ?>
        <div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);font-size:.85rem">
          <span style="font-weight:500"><?= $label ?></span>
          <span style="font-weight:700;color:<?= $isCredit ? '#16a34a' : '#dc2626' ?>">
            <?= $isCredit ? '+' : '-' ?> ETB <?= number_format((float)$amount, 2) ?>
          </span>
        </div>
      <?php endforeach; ?>
      <div style="display:flex;justify-content:space-between;padding:12px 0;border-top:2px solid var(--border);margin-top:4px">
        <span class="fw-7">Net Pay</span>
        <span style="font-weight:800;font-size:1.1rem;color:var(--teal)">ETB <?= number_format($net, 2) ?></span>
      </div>
    </div>
  </div>
  <div class="ep-card">
    <div class="ep-card-hdr">
      <h3>Salary Composition</h3>
    </div>
    <div class="ep-card-body"><canvas id="salary-chart" height="200"></canvas></div>
  </div>
</div>

<!-- Payslip History -->
<div class="ep-card">
  <div class="ep-card-hdr">
    <h3>Payslip History</h3>
  </div>
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead>
        <tr>
          <th>Month</th>
          <th>Gross Pay</th>
          <th>Deductions</th>
          <th>Net Pay</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($payslips as $p):
          $pGross = (float)($p['gross_salary']    ?? $gross);
          $pDed   = (float)($p['total_deductions'] ?? $deductions);
          $pNet   = (float)($p['net_salary']       ?? $net);
        ?>
          <tr>
            <td class="fw-6"><?= periodLabel($p['pay_period'] ?? date('Y-m', strtotime('-1 month'))) ?></td>
            <td>ETB <?= number_format($pGross, 2) ?></td>
            <td style="color:var(--err)">ETB <?= number_format($pDed, 2) ?></td>
            <td style="color:var(--ok);font-weight:700">ETB <?= number_format($pNet, 2) ?></td>
            <td><?= ep_badge($p['status'] ?? 'Paid') ?></td>
            <td>
              <a href="<?= EP_BASE_URL ?>/employee/payroll/view-payslip.php?id=<?= (int)($p['id'] ?? 1) ?>"
                class="ep-btn ep-btn-outline ep-btn-sm">
                <i class="fa-solid fa-eye"></i> View
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$pageScript = "
document.addEventListener('DOMContentLoaded', function() {
  if (!window.Chart) return;
  new Chart(document.getElementById('salary-chart'), {
    type: 'doughnut',
    data: {
      labels: ['Basic', 'Transport', 'Housing', 'Deductions'],
      datasets: [{
        data: [" . (float)($latest['basic_salary'] ?? 18500) . ","
  . (float)($latest['transport_allow'] ?? 1500) . ","
  . (float)($latest['housing_allow'] ?? 2000) . ","
  . $deductions . "],
        backgroundColor: ['#007A8A','#22c55e','#3b82f6','#ef4444']
      }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
  });
});
";
include dirname(__DIR__, 2) . '/includes/footer.php'; ?>