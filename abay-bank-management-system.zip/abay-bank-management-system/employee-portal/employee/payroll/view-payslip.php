<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Payslip — ' . EP_NAME;
$breadcrumb = [['label' => 'Payroll', 'url' => EP_BASE_URL . '/employee/payroll/index.php'], ['label' => 'Payslip']];
$empId = (int)($emp['id'] ?? 0);
$id    = (int)($_GET['id'] ?? 1);

// Real columns: pay_period, basic_salary, transport_allow, housing_allow,
//               gross_salary, income_tax, pension, total_deductions, net_salary, paid_date, status
$p = EP_Database::queryOne("SELECT * FROM payroll WHERE id=? AND employee_id=?", [$id, $empId])
  ?? [
    'pay_period'      => date('Y-m', strtotime('-1 month')),
    'basic_salary'    => (float)($emp['basic_salary'] ?? 18500),
    'transport_allow' => 1500,
    'housing_allow'   => 2000,
    'other_allowances' => 0,
    'gross_salary'    => 22000,
    'income_tax'      => 3300,
    'pension'         => 1295,
    'other_deductions' => 0,
    'total_deductions' => 4595,
    'net_salary'      => 17405,
    'paid_date'       => date('Y-m-d', strtotime('-28 days')),
    'status'          => 'Paid',
  ];

// Compute values with fallbacks
$basic    = (float)($p['basic_salary']    ?? 0);
$transp   = (float)($p['transport_allow'] ?? $p['transport_allowance'] ?? 0);
$housing  = (float)($p['housing_allow']   ?? $p['housing_allowance']   ?? 0);
$other    = (float)($p['other_allowances'] ?? $p['overtime_pay']        ?? 0);
$gross    = (float)($p['gross_salary']    ?? $basic + $transp + $housing + $other);
$tax      = (float)($p['income_tax']      ?? 0);
$pension  = (float)($p['pension']         ?? $p['pension_employee']    ?? 0);
$otherDed = (float)($p['other_deductions'] ?? 0);
$totalDed = (float)($p['total_deductions'] ?? $tax + $pension + $otherDed);
if (!$totalDed && $gross > 0) {
  $taxable = $gross - 600;
  $totalDed = $taxable > 0 ? round($taxable * 0.15, 2) : 0;
}
$net      = (float)($p['net_salary']      ?: $gross - $totalDed);

// Period label: "2026-08" → "August 2026"
function periodLabel2(string $period): string
{
  $parts = explode('-', $period);
  return count($parts) === 2 ? date('F Y', mktime(0, 0, 0, (int)$parts[1], 1, (int)$parts[0])) : $period;
}
$periodDisplay = periodLabel2($p['pay_period'] ?? date('Y-m', strtotime('-1 month')));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-receipt" style="color:var(--teal)"></i> Payslip — <?= $periodDisplay ?></h1>
  </div>
  <div class="ep-page-actions">
    <button onclick="window.print()" class="ep-btn ep-btn-outline"><i class="fa-solid fa-print"></i> Print</button>
    <a href="<?= EP_BASE_URL ?>/employee/payroll/index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>

<div style="max-width:700px">
  <div class="ep-card" id="payslip-print">

    <!-- Payslip Header -->
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);padding:24px 28px;border-radius:14px 14px 0 0;color:#fff">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
        <div style="display:flex;align-items:center;gap:12px">
          <div style="display:flex;align-items:flex-end;gap:3px;background:rgba(255,255,255,.12);border-radius:8px;padding:6px 8px 8px">
            <span style="width:5px;height:14px;background:#C8A84B;border-radius:2px 2px 0 0;display:block"></span>
            <span style="width:5px;height:19px;background:#7ecfd8;border-radius:2px 2px 0 0;display:block"></span>
            <span style="width:5px;height:24px;background:#fff;border-radius:2px 2px 0 0;display:block"></span>
            <span style="width:5px;height:14px;background:#7ecfd8;border-radius:2px 2px 0 0;display:block"></span>
          </div>
          <div>
            <div style="font-size:1rem;font-weight:800">Abay Bank S.C.</div>
            <div style="font-size:.7rem;opacity:.7">Employee Pay Statement</div>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-size:.75rem;opacity:.7">Pay Period</div>
          <div style="font-size:1rem;font-weight:700"><?= $periodDisplay ?></div>
          <?php if (!empty($p['paid_date'])): ?>
            <div style="font-size:.72rem;opacity:.65">Paid: <?= ep_date($p['paid_date']) ?></div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Employee Info -->
    <div style="padding:18px 28px;background:#f8fafc;border-bottom:1px solid var(--border);display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <?php foreach (
        [
          ['Employee Name',   ep_full_name($emp)],
          ['Employee No.',    $emp['employee_number'] ?? 'EMP-000001'],
          ['Department',      $emp['dept_name']       ?? '—'],
          ['Branch',          $emp['branch_name']     ?? '—'],
          ['Position',        $emp['position']        ?? '—'],
          ['Pay Date',        ep_date($p['paid_date'] ?? date('Y-m-d', strtotime('-28 days')))],
        ] as [$l, $v]
      ): ?>
        <div>
          <div style="font-size:.7rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.04em"><?= $l ?></div>
          <div style="font-weight:600;font-size:.87rem;margin-top:2px"><?= ep_e($v) ?></div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Earnings & Deductions -->
    <div style="padding:24px 28px;display:grid;grid-template-columns:1fr 1fr;gap:28px">
      <div>
        <h4 style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-bottom:12px">Earnings</h4>
        <?php foreach (
          [
            ['Basic Salary',       $basic],
            ['Transport Allowance', $transp],
            ['Housing Allowance',  $housing],
            ['Other Allowances',   $other],
          ] as [$label, $val]
        ):
          if (!(float)$val) continue;
        ?>
          <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #f1f5f9;font-size:.85rem">
            <span><?= $label ?></span>
            <span class="fw-6" style="color:#16a34a">+ ETB <?= number_format((float)$val, 2) ?></span>
          </div>
        <?php endforeach; ?>
        <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:2px solid var(--border);margin-top:4px;font-size:.88rem">
          <span class="fw-7">Gross Earnings</span>
          <span class="fw-7" style="color:#16a34a">ETB <?= number_format($gross, 2) ?></span>
        </div>
      </div>

      <div>
        <h4 style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-bottom:12px">Deductions</h4>
        <?php foreach (
          [
            ['Income Tax',      $tax],
            ['Pension (7%)',    $pension],
            ['Other Deductions', $otherDed],
          ] as [$label, $val]
        ):
          if (!(float)$val) continue;
        ?>
          <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #f1f5f9;font-size:.85rem">
            <span><?= $label ?></span>
            <span class="fw-6" style="color:#dc2626">- ETB <?= number_format((float)$val, 2) ?></span>
          </div>
        <?php endforeach; ?>
        <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:2px solid var(--border);margin-top:4px;font-size:.88rem">
          <span class="fw-7">Total Deductions</span>
          <span class="fw-7" style="color:#dc2626">ETB <?= number_format($totalDed, 2) ?></span>
        </div>
      </div>
    </div>

    <!-- Net Pay -->
    <div style="background:linear-gradient(135deg,#1B3A5C,#007A8A);margin:0 28px 28px;border-radius:12px;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;color:#fff">
      <div>
        <div style="font-size:.73rem;opacity:.75;font-weight:700;text-transform:uppercase;letter-spacing:.05em">Net Pay</div>
        <div style="font-size:.8rem;opacity:.6;margin-top:2px"><?= $periodDisplay ?></div>
      </div>
      <div style="font-size:1.8rem;font-weight:800">ETB <?= number_format($net, 2) ?></div>
    </div>

  </div><!-- end payslip-print -->
</div>

<style>
  @media print {

    .ep-topbar,
    .ep-sidebar,
    .ep-page-actions,
    .ep-sb-backdrop {
      display: none !important;
    }

    .ep-main {
      margin: 0 !important;
      padding: 0 !important;
    }
  }
</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>