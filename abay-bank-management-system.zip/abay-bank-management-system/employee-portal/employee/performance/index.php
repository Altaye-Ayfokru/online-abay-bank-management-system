<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Performance — ' . EP_NAME;
$breadcrumb = [['label'=>'Performance']];
$empId = (int)($emp['id'] ?? 0);

$year = (int)($_GET['year'] ?? date('Y'));

// Current period review
$review = EP_Database::queryOne(
    "SELECT * FROM performance_reviews WHERE employee_id=? AND YEAR(review_period)=? ORDER BY review_period DESC LIMIT 1",
    [$empId, $year]
) ?: [
    'overall_rating'  => 4.2,
    'customer_score'  => 88,
    'attendance_score'=> 92,
    'productivity'    => 85,
    'teamwork'        => 90,
    'communication'   => 78,
    'compliance'      => 95,
    'initiative'      => 82,
    'review_period'   => $year . '-06-30',
    'reviewer_notes'  => 'Excellent performance in customer service and compliance. Continue to develop communication skills and initiative in process improvement.',
    'status'          => 'Completed',
];

// Goals
$goals = EP_Database::query(
    "SELECT * FROM performance_goals WHERE employee_id=? AND YEAR(target_date)=? ORDER BY target_date ASC",
    [$empId, $year]
) ?: [
    ['id'=>1,'title'=>'Complete AML Certification',      'target_date'=>date('Y-m-d',strtotime('first day of july this year')),'progress'=>100,'status'=>'Completed','category'=>'Training'],
    ['id'=>2,'title'=>'Process 500+ transactions/month', 'target_date'=>date('Y-m-d',strtotime('last day of december this year')),'progress'=>68,'status'=>'In Progress','category'=>'Productivity'],
    ['id'=>3,'title'=>'Zero compliance violations',      'target_date'=>date('Y-m-d',strtotime('last day of december this year')),'progress'=>100,'status'=>'Completed','category'=>'Compliance'],
    ['id'=>4,'title'=>'Customer satisfaction >90%',      'target_date'=>date('Y-m-d',strtotime('last day of december this year')),'progress'=>88,'status'=>'In Progress','category'=>'Customer Service'],
    ['id'=>5,'title'=>'Mentor 1 new employee',           'target_date'=>date('Y-m-d',strtotime('last day of september this year')),'progress'=>50,'status'=>'In Progress','category'=>'Leadership'],
];

// Trend data (last 6 periods)
$trend = EP_Database::query(
    "SELECT MONTH(review_period) AS month, overall_rating FROM performance_reviews
     WHERE employee_id=? AND YEAR(review_period)=? ORDER BY review_period ASC",
    [$empId, $year]
) ?: [
    ['month'=>1,'overall_rating'=>3.8],['month'=>2,'overall_rating'=>4.0],
    ['month'=>3,'overall_rating'=>3.9],['month'=>4,'overall_rating'=>4.2],
    ['month'=>5,'overall_rating'=>4.1],['month'=>6,'overall_rating'=>4.2],
];

// Rating badge
$rating = (float)($review['overall_rating'] ?? 0);
$ratingLabel = match(true) {
    $rating >= 4.5 => ['Exceptional',  '#22c55e','#dcfce7'],
    $rating >= 4.0 => ['Excellent',    '#3b82f6','#dbeafe'],
    $rating >= 3.5 => ['Good',         '#f59e0b','#fef9c3'],
    $rating >= 3.0 => ['Satisfactory', '#8b5cf6','#ede9fe'],
    default        => ['Needs Improvement','#ef4444','#fee2e2'],
};

$kpis = [
    'Customer Score'   => (int)($review['customer_score']   ?? 0),
    'Attendance'       => (int)($review['attendance_score'] ?? 0),
    'Productivity'     => (int)($review['productivity']     ?? 0),
    'Teamwork'         => (int)($review['teamwork']         ?? 0),
    'Communication'    => (int)($review['communication']    ?? 0),
    'Compliance'       => (int)($review['compliance']       ?? 0),
];

$categoryColors = ['Training'=>'#3b82f6','Productivity'=>'#22c55e','Compliance'=>'#8b5cf6','Customer Service'=>'#f59e0b','Leadership'=>'#ef4444'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-chart-line" style="color:var(--teal)"></i> My Performance</h1>
    <p>KPIs, goals, and review for <?= $year ?></p>
  </div>
  <div class="ep-page-actions">
    <form method="GET" style="display:inline">
      <select name="year" class="ep-select" onchange="this.form.submit()" style="width:100px">
        <?php for ($y = date('Y'); $y >= date('Y') - 3; $y--): ?>
        <option value="<?= $y ?>" <?= $y===$year?'selected':'' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </form>
  </div>
</div>

<!-- Overall Rating Banner -->
<div class="ep-card" style="margin-bottom:20px;background:linear-gradient(135deg,var(--teal) 0%,#0891b2 100%);color:#fff;border:none">
  <div class="ep-card-body" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
    <div>
      <div style="font-size:.85rem;opacity:.85;margin-bottom:4px">Overall Performance Rating — <?= $year ?></div>
      <div style="font-size:2.8rem;font-weight:900;line-height:1"><?= number_format($rating, 1) ?><span style="font-size:1rem;font-weight:400;opacity:.7"> / 5.0</span></div>
      <span style="background:<?= $ratingLabel[2] ?>;color:<?= $ratingLabel[1] ?>;padding:4px 14px;border-radius:20px;font-size:.8rem;font-weight:700;display:inline-block;margin-top:8px">
        <?= $ratingLabel[0] ?>
      </span>
    </div>
    <div style="display:flex;gap:24px;flex-wrap:wrap">
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-weight:800"><?= count(array_filter($goals, fn($g) => ($g['status']??'') === 'Completed')) ?></div>
        <div style="font-size:.78rem;opacity:.8">Goals Met</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-weight:800"><?= count($goals) ?></div>
        <div style="font-size:.78rem;opacity:.8">Total Goals</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-weight:800"><?= (int)($review['attendance_score'] ?? 0) ?>%</div>
        <div style="font-size:.78rem;opacity:.8">Attendance</div>
      </div>
    </div>
  </div>
</div>

<div class="ep-grid-2" style="align-items:start">
  <!-- KPI Chart -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>KPI Breakdown</h3></div>
    <div class="ep-card-body">
      <canvas id="kpiChart" height="200"></canvas>
      <div style="margin-top:16px">
        <?php foreach ($kpis as $kpi => $score): ?>
        <?php $color = $score >= 90 ? '#22c55e' : ($score >= 75 ? '#3b82f6' : ($score >= 60 ? '#f59e0b' : '#ef4444')); ?>
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:4px">
            <span><?= $kpi ?></span><span class="fw-6" style="color:<?= $color ?>"><?= $score ?>%</span>
          </div>
          <div class="ep-progress"><div class="ep-progress-fill" style="width:<?= $score ?>%;background:<?= $color ?>"></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Goals -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Goals for <?= $year ?></h3></div>
    <div class="ep-card-body">
      <?php foreach ($goals as $g): ?>
      <?php
        $gc  = $categoryColors[$g['category'] ?? ''] ?? '#64748b';
        $pct = min(100, max(0, (int)($g['progress'] ?? 0)));
        $done = ($g['status'] ?? '') === 'Completed' || $pct >= 100;
      ?>
      <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
          <div>
            <span style="font-size:.7rem;font-weight:600;color:<?= $gc ?>;background:<?= $gc ?>18;padding:2px 8px;border-radius:20px;margin-right:6px">
              <?= ep_e($g['category'] ?? '') ?>
            </span>
            <div class="fw-6" style="font-size:.84rem;margin-top:4px"><?= ep_e($g['title'] ?? '') ?></div>
          </div>
          <?php if ($done): ?>
          <i class="fa-solid fa-circle-check" style="color:#22c55e;font-size:1.1rem;flex-shrink:0"></i>
          <?php endif; ?>
        </div>
        <div style="margin-bottom:4px">
          <div style="display:flex;justify-content:space-between;font-size:.76rem;margin-bottom:4px;color:var(--muted)">
            <span>Target: <?= ep_date($g['target_date'] ?? '') ?></span>
            <span class="fw-6" style="color:<?= $done ? '#22c55e' : 'var(--teal)' ?>"><?= $pct ?>%</span>
          </div>
          <div class="ep-progress">
            <div class="ep-progress-fill" style="width:<?= $pct ?>%;background:<?= $done ? '#22c55e' : 'var(--teal)' ?>"></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Trend Chart -->
<div class="ep-card" style="margin-top:20px">
  <div class="ep-card-hdr"><h3>Performance Trend — <?= $year ?></h3></div>
  <div class="ep-card-body">
    <canvas id="trendChart" height="80"></canvas>
  </div>
</div>

<!-- Reviewer Notes -->
<?php if (!empty($review['reviewer_notes'])): ?>
<div class="ep-card" style="margin-top:20px">
  <div class="ep-card-hdr"><h3>Reviewer Notes</h3><?= ep_badge($review['status'] ?? '') ?></div>
  <div class="ep-card-body">
    <p style="font-size:.88rem;line-height:1.7;color:var(--text);margin:0"><?= nl2br(ep_e($review['reviewer_notes'])) ?></p>
  </div>
</div>
<?php endif; ?>

<script>
(function(){
  var kpiLabels = <?= json_encode(array_keys($kpis)) ?>;
  var kpiData   = <?= json_encode(array_values($kpis)) ?>;
  var months    = <?= json_encode(array_map(fn($r) => date('M', mktime(0,0,0,(int)$r['month'],1)), $trend)) ?>;
  var ratings   = <?= json_encode(array_map(fn($r) => (float)$r['overall_rating'], $trend)) ?>;

  // KPI Radar
  var kpiCtx = document.getElementById('kpiChart').getContext('2d');
  new Chart(kpiCtx, {
    type: 'radar',
    data: {
      labels: kpiLabels,
      datasets: [{
        label: 'KPI Score (%)',
        data: kpiData,
        backgroundColor: 'rgba(0,152,175,0.15)',
        borderColor: 'rgba(0,152,175,1)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(0,152,175,1)',
        pointRadius: 4,
      }]
    },
    options: {
      responsive: true,
      scales: { r: { beginAtZero: true, max: 100, ticks: { stepSize: 20, font: { size: 10 } } } },
      plugins: { legend: { display: false } }
    }
  });

  // Trend Line
  var trendCtx = document.getElementById('trendChart').getContext('2d');
  new Chart(trendCtx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{
        label: 'Overall Rating',
        data: ratings,
        borderColor: 'rgba(0,152,175,1)',
        backgroundColor: 'rgba(0,152,175,0.1)',
        fill: true,
        tension: 0.4,
        borderWidth: 2,
        pointRadius: 5,
        pointBackgroundColor: 'rgba(0,152,175,1)',
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { min: 0, max: 5, ticks: { stepSize: 1 } }
      },
      plugins: { legend: { display: false } }
    }
  });
})();
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
