<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp    = ep_guard();
$empId  = (int)($emp['id'] ?? 0);
$pageTitle  = 'Change Password — ' . EP_NAME;
$breadcrumb = [['label'=>'My Profile','url'=> EP_BASE_URL.'/employee/profile/index.php'],['label'=>'Change Password']];
$error = null; $success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!$current || !$new || !$confirm) {
        $error = 'All fields are required.';
    } elseif ($new !== $confirm) {
        $error = 'New passwords do not match.';
    } elseif (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $user = EP_Database::queryOne("SELECT id, password_hash FROM employee_users WHERE employee_id=? LIMIT 1", [$empId]);
        if ($user && password_verify($current, $user['password_hash'] ?? '')) {
            $hashed = password_hash($new, PASSWORD_DEFAULT);
            EP_Database::execute("UPDATE employee_users SET password_hash=?, updated_at=NOW() WHERE id=?", [$hashed, $user['id']]);
            EP_Database::execute("INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())", [$empId, 'Password changed', 'security']);
            ep_flash('success', 'Password changed successfully!');
            header('Location: ' . EP_BASE_URL . '/employee/profile/index.php'); exit;
        } elseif (!$user) {
            // Demo mode
            ep_flash('success', 'Demo: Password changed successfully!');
            header('Location: ' . EP_BASE_URL . '/employee/profile/index.php'); exit;
        } else {
            $error = 'Current password is incorrect.';
        }
    }
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-lock" style="color:var(--teal)"></i> Change Password</h1><p>Update your account password</p></div>
  <div class="ep-page-actions"><a href="<?= EP_BASE_URL ?>/employee/profile/index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>

<div style="max-width:480px">
  <?php if ($error): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($error) ?></div><?php endif; ?>
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>New Password</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group">
          <label class="ep-label">Current Password <span class="req">*</span></label>
          <div class="ep-inp-wrap">
            <i class="fa-solid fa-lock ep-inp-ic"></i>
            <input type="password" name="current_password" id="pw-cur" class="ep-input" placeholder="Your current password" required>
            <button type="button" class="ep-inp-eye" onclick="tp('pw-cur',this)"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">New Password <span class="req">*</span></label>
          <div class="ep-inp-wrap">
            <i class="fa-solid fa-lock ep-inp-ic"></i>
            <input type="password" name="new_password" id="pw-new" class="ep-input" placeholder="Min. 8 characters" required minlength="8" oninput="chkStr(this.value)">
            <button type="button" class="ep-inp-eye" onclick="tp('pw-new',this)"><i class="fa-solid fa-eye"></i></button>
          </div>
          <div class="ep-progress" style="margin-top:6px"><div class="ep-progress-fill" id="str-bar" style="width:0%;background:#e2e8f0"></div></div>
          <div class="ep-hint" id="str-lbl"></div>
        </div>
        <div class="ep-form-group">
          <label class="ep-label">Confirm New Password <span class="req">*</span></label>
          <div class="ep-inp-wrap">
            <i class="fa-solid fa-lock ep-inp-ic"></i>
            <input type="password" name="confirm_password" id="pw-cf" class="ep-input" placeholder="Repeat new password" required oninput="chkMatch()">
          </div>
          <div class="ep-hint" id="match-msg"></div>
        </div>
        <!-- Requirements -->
        <div style="background:#f8fafc;border-radius:10px;padding:14px;margin-bottom:16px">
          <p style="font-size:.78rem;font-weight:700;color:var(--muted);margin-bottom:8px">Requirements:</p>
          <?php foreach ([['r-len','At least 8 characters'],['r-up','One uppercase letter'],['r-num','One number'],['r-sp','One special character']] as [$id,$lbl]): ?>
          <div id="<?= $id ?>" style="font-size:.8rem;color:var(--muted);display:flex;align-items:center;gap:7px;margin-bottom:5px">
            <i class="fa-solid fa-circle-xmark" style="color:#e2e8f0"></i> <?= $lbl ?>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="submit" class="ep-btn ep-btn-primary w-full"><i class="fa-solid fa-lock"></i> Update Password</button>
      </form>
    </div>
  </div>
</div>
<script>
function tp(id,btn){var i=document.getElementById(id);i.type=i.type==='password'?'text':'password';btn.querySelector('i').className='fa-solid '+(i.type==='password'?'fa-eye':'fa-eye-slash');}
function chkStr(v){
  var checks={len:v.length>=8,up:/[A-Z]/.test(v),num:/[0-9]/.test(v),sp:/[^a-zA-Z0-9]/.test(v)};
  var s=Object.values(checks).filter(Boolean).length;
  var c=['','#ef4444','#f59e0b','#3b82f6','#22c55e'][s]||'#e2e8f0';
  document.getElementById('str-bar').style.cssText='width:'+(s*25)+'%;background:'+c;
  document.getElementById('str-lbl').textContent=['','Weak','Fair','Good','Strong'][s]||'';
  [['r-len',checks.len],['r-up',checks.up],['r-num',checks.num],['r-sp',checks.sp]].forEach(([id,ok])=>{
    var el=document.getElementById(id); if(!el) return;
    el.style.color=ok?'#22c55e':'var(--muted)';
    el.querySelector('i').className='fa-solid '+(ok?'fa-circle-check':'fa-circle-xmark');
    el.querySelector('i').style.color=ok?'#22c55e':'#e2e8f0';
  });
}
function chkMatch(){var pw=document.getElementById('pw-new').value,cf=document.getElementById('pw-cf').value,el=document.getElementById('match-msg');if(!cf)return;el.textContent=pw===cf?'✓ Passwords match':'✗ Do not match';el.style.color=pw===cf?'#22c55e':'#ef4444';}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
