<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp    = ep_guard();
$empId  = (int)($emp['id'] ?? 0);
$pageTitle  = 'Edit Profile — ' . EP_NAME;
$breadcrumb = [['label'=>'My Profile','url'=> EP_BASE_URL.'/employee/profile/index.php'],['label'=>'Edit']];

$profile = EP_Database::queryOne("SELECT * FROM employees WHERE id=?", [$empId]) ?? $emp;
$errors  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $phone   = trim($_POST['phone']   ?? '');
    $email   = trim($_POST['email']   ?? '');
    $address = trim($_POST['address'] ?? '');
    $dob     = trim($_POST['dob']     ?? '');
    $gender  = trim($_POST['gender']  ?? '');
    $nationalId = trim($_POST['national_id'] ?? '');

    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
    if (!$phone) $errors[] = 'Phone number is required.';

    if (!$errors) {
        EP_Database::execute(
            "UPDATE employees SET phone=?, email=?, address=?, dob=?, gender=?, national_id=?, updated_at=NOW() WHERE id=?",
            [$phone, $email, $address, $dob ?: null, $gender, $nationalId, $empId]
        );
        EP_Database::execute(
            "INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())",
            [$empId, 'Profile information updated', 'profile']
        );
        // Update session
        $_SESSION['ep_employee']['email'] = $email;
        $_SESSION['ep_employee']['phone'] = $phone;
        ep_flash('success', 'Profile updated successfully!');
        header('Location: ' . EP_BASE_URL . '/employee/profile/index.php'); exit;
    }
    // Re-populate from POST on error
    $profile = array_merge($profile, ['phone'=>$phone,'email'=>$email,'address'=>$address,'dob'=>$dob,'gender'=>$gender,'national_id'=>$nationalId]);
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-pen" style="color:var(--teal)"></i> Edit Profile</h1><p>Update your personal contact information</p></div>
  <div class="ep-page-actions"><a href="<?= EP_BASE_URL ?>/employee/profile/index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>

<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>

<div style="max-width:700px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Personal Information</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-row">
          <div class="ep-form-group">
            <label class="ep-label">First Name</label>
            <input type="text" class="ep-input" value="<?= ep_e($profile['first_name'] ?? '') ?>" readonly style="background:#f8fafc;color:var(--muted)">
            <div class="ep-hint">Contact HR to change your name</div>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Last Name</label>
            <input type="text" class="ep-input" value="<?= ep_e($profile['last_name'] ?? '') ?>" readonly style="background:#f8fafc;color:var(--muted)">
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Phone <span class="req">*</span></label>
            <input type="tel" name="phone" class="ep-input" value="<?= ep_e($profile['phone'] ?? '') ?>" placeholder="+251 9XX XXX XXX" required>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Work Email</label>
            <input type="email" name="email" class="ep-input" value="<?= ep_e($profile['email'] ?? '') ?>" placeholder="yourname@abaybank.com">
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Date of Birth</label>
            <input type="date" name="dob" class="ep-input" value="<?= ep_e($profile['dob'] ?? '') ?>" max="<?= date('Y-m-d', strtotime('-18 years')) ?>">
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Gender</label>
            <select name="gender" class="ep-select">
              <option value="">Select…</option>
              <?php foreach (['Male','Female','Other'] as $g): ?>
              <option <?= ($profile['gender'] ?? '') === $g ? 'selected':'' ?>><?= $g ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">National ID</label>
            <input type="text" name="national_id" class="ep-input" value="<?= ep_e($profile['national_id'] ?? '') ?>" placeholder="ET12345678">
          </div>
          <div class="ep-form-group ep-form-full">
            <label class="ep-label">Home Address</label>
            <textarea name="address" class="ep-textarea" rows="2" placeholder="Your residential address"><?= ep_e($profile['address'] ?? '') ?></textarea>
          </div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
          <a href="<?= EP_BASE_URL ?>/employee/profile/index.php" class="ep-btn ep-btn-outline">Cancel</a>
          <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
