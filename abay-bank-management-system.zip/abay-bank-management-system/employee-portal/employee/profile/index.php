<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

$emp = ep_guard();
$pageTitle  = 'My Profile — ' . EP_NAME;
$breadcrumb = [['label'=>'My Profile']];
$empId = (int)($emp['id'] ?? 0);

// Fresh DB data
$profile = EP_Database::queryOne(
    "SELECT e.*, d.name AS dept_name, b.branch_name, r.role_name AS role
     FROM employees e
     LEFT JOIN departments d ON d.id=e.department_id
     LEFT JOIN branches b ON b.id=e.branch_id
     LEFT JOIN roles r ON r.id=e.role_id
     WHERE e.id=?", [$empId]
) ?? $emp;

include dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-user-circle" style="color:var(--teal)"></i> My Profile</h1>
    <p>View and manage your personal information, security settings, and documents</p>
  </div>
  <div class="ep-page-actions">
    <a href="<?= EP_BASE_URL ?>/employee/profile/edit.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-pen"></i> Edit Profile</a>
    <a href="<?= EP_BASE_URL ?>/employee/profile/change-password.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-lock"></i> Change Password</a>
  </div>
</div>

<div class="ep-grid-2" style="align-items:start">
  <!-- Left: Avatar + Info -->
  <div>
    <div class="ep-card" style="text-align:center">
      <div class="ep-card-body" style="padding:32px 24px">
        <?php $avatarUrl = ep_avatar($profile); ?>
        <div style="position:relative;display:inline-block;margin-bottom:18px">
          <div class="ep-avatar ep-av-xl" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;margin:0 auto" id="avatar-display">
            <?php if ($avatarUrl): ?>
              <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="Profile Photo" id="avatar-img">
            <?php else: ?>
              <span id="avatar-initials"><?= ep_initials($profile) ?></span>
            <?php endif; ?>
          </div>
          <label for="photo-input" title="Change photo"
            style="position:absolute;bottom:2px;right:2px;width:30px;height:30px;background:var(--teal);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.2)">
            <i class="fa-solid fa-camera" style="color:#fff;font-size:.65rem"></i>
          </label>
          <input type="file" id="photo-input" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="uploadPhoto(this)">
        </div>
        <h3 style="font-size:1.1rem;margin-bottom:4px"><?= ep_e(ep_full_name($profile)) ?></h3>
        <p style="color:var(--teal);font-weight:600;font-size:.88rem;margin-bottom:2px"><?= ep_e($profile['position'] ?? 'Staff') ?></p>
        <p style="color:var(--muted);font-size:.82rem"><?= ep_e($profile['dept_name'] ?? '') ?> · <?= ep_e($profile['branch_name'] ?? '') ?></p>
        <div style="margin-top:16px">
          <div id="upload-progress" style="display:none">
            <div class="ep-progress"><div class="ep-progress-fill" id="up-bar" style="width:0%;background:var(--teal)"></div></div>
            <p style="font-size:.73rem;color:var(--muted);margin-top:5px">Uploading…</p>
          </div>
        </div>
      </div>
    </div>

    <div class="ep-card">
      <div class="ep-card-hdr"><h3>Employment Details</h3></div>
      <div class="ep-card-body">
        <?php $rows = [
          ['Employee ID',  $profile['employee_number'] ?? 'EMP-000001'],
          ['Department',   $profile['dept_name']   ?? '—'],
          ['Branch',       $profile['branch_name'] ?? '—'],
          ['Position',     $profile['position']    ?? '—'],
          ['Role',         $profile['role']        ?? $profile['role_name'] ?? '—'],
          ['Hire Date',    ep_date($profile['hire_date'] ?? '')],
          ['Status',       $profile['status'] ?? 'Active'],
        ];
        foreach ($rows as [$l,$v]): ?>
        <div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);font-size:.84rem">
          <span class="text-muted fw-5"><?= $l ?></span>
          <span class="fw-6"><?= ep_e($v) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Right: Personal Info -->
  <div>
    <div class="ep-card">
      <div class="ep-card-hdr"><h3>Personal Information</h3><a href="<?= EP_BASE_URL ?>/employee/profile/edit.php" class="ep-btn ep-btn-outline ep-btn-sm"><i class="fa-solid fa-pen"></i> Edit</a></div>
      <div class="ep-card-body">
        <?php $prows = [
          ['fa-user',           'Full Name',    ep_full_name($profile)],
          ['fa-id-badge',       'Employee No.', $profile['employee_number'] ?? '—'],
          ['fa-envelope',       'Email',        $profile['email'] ?? '—'],
          ['fa-phone',          'Phone',        $profile['phone'] ?? '—'],
          ['fa-calendar',       'Date of Birth',$profile['dob'] ?? '—'],
          ['fa-venus-mars',     'Gender',       $profile['gender'] ?? '—'],
          ['fa-location-dot',   'Address',      $profile['address'] ?? '—'],
          ['fa-person-military-rifle','National ID', $profile['national_id'] ?? '—'],
        ];
        foreach ($prows as [$icon,$label,$value]): ?>
        <div style="display:flex;align-items:flex-start;gap:14px;padding:11px 0;border-bottom:1px solid var(--border)">
          <div style="width:34px;height:34px;border-radius:9px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="fa-solid <?= $icon ?>" style="color:var(--teal);font-size:.85rem"></i>
          </div>
          <div>
            <div style="font-size:.73rem;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.04em"><?= $label ?></div>
            <div style="font-size:.88rem;font-weight:600;margin-top:2px"><?= ep_e($value) ?: '—' ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="ep-card">
      <div class="ep-card-hdr"><h3>Security</h3></div>
      <div class="ep-card-body">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border)">
          <div><div class="fw-6" style="font-size:.87rem">Password</div><div style="font-size:.78rem;color:var(--muted)">Last changed: recently</div></div>
          <a href="<?= EP_BASE_URL ?>/employee/profile/change-password.php" class="ep-btn ep-btn-outline ep-btn-sm">Change</a>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0">
          <div><div class="fw-6" style="font-size:.87rem">Two-Factor Auth</div><div style="font-size:.78rem;color:var(--muted)">Add extra security to your account</div></div>
          <button onclick="EP.toast('2FA setup coming soon','info')" class="ep-btn ep-btn-outline ep-btn-sm">Enable</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function uploadPhoto(input) {
  if (!input.files || !input.files[0]) return;
  var file = input.files[0];
  if (file.size > 5*1024*1024) { EP.toast('Image must be under 5 MB','danger'); return; }

  // Preview instantly
  var reader = new FileReader();
  reader.onload = function(e) {
    var d = document.getElementById('avatar-display');
    d.innerHTML = '<img src="'+e.target.result+'" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
  };
  reader.readAsDataURL(file);

  // Upload via XHR
  var prog = document.getElementById('upload-progress');
  var bar  = document.getElementById('up-bar');
  if (prog) prog.style.display = '';

  var fd = new FormData();
  fd.append('photo', file);
  fd.append('_ep_csrf', document.querySelector('input[name="_ep_csrf"]')?.value || '');

  var xhr = new XMLHttpRequest();
  xhr.open('POST', '<?= EP_BASE_URL ?>/employee/profile/photo.php', true);
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.upload.onprogress = function(e) {
    if (e.lengthComputable && bar) bar.style.width = Math.round(e.loaded/e.total*100) + '%';
  };
  xhr.onload = function() {
    if (prog) prog.style.display = 'none';
    try {
      var r = JSON.parse(xhr.responseText);
      EP.toast(r.success ? 'Profile photo updated!' : (r.message||'Upload failed'), r.success?'success':'danger');
    } catch(e) { EP.toast('Upload failed','danger'); }
  };
  xhr.onerror = function() { if (prog) prog.style.display='none'; EP.toast('Upload error','danger'); };
  xhr.send(fd);
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
