<?php
/**
 * Employee Portal — Profile Photo Upload Handler
 * Accepts: POST multipart/form-data with field 'photo'
 * Returns: JSON {success, message, url}
 */
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';

header('Content-Type: application/json');

$emp = ep_employee();
if (!$emp) { echo json_encode(['success'=>false,'message'=>'Not authenticated']); exit; }

// CSRF check (token via form field or header)
$token  = $_POST['_ep_csrf'] ?? $_SERVER['HTTP_X_EP_CSRF'] ?? '';
if (!hash_equals($_SESSION['ep_csrf'] ?? '', $token)) {
    echo json_encode(['success'=>false,'message'=>'Invalid security token']); exit;
}

if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    $errCodes = [1=>'File too large (PHP)',2=>'File too large',3=>'Partial upload',4=>'No file sent'];
    $msg = $errCodes[$_FILES['photo']['error'] ?? 4] ?? 'Upload error';
    echo json_encode(['success'=>false,'message'=>$msg]); exit;
}

$file    = $_FILES['photo'];
$allowed = ['image/jpeg','image/png','image/webp','image/gif'];
$maxSize = 5 * 1024 * 1024;

if (!in_array($file['type'], $allowed)) {
    echo json_encode(['success'=>false,'message'=>'Only JPG, PNG, WebP or GIF allowed']); exit;
}
if ($file['size'] > $maxSize) {
    echo json_encode(['success'=>false,'message'=>'Image must be under 5 MB']); exit;
}

// Verify it's actually an image
$imgInfo = @getimagesize($file['tmp_name']);
if (!$imgInfo) {
    echo json_encode(['success'=>false,'message'=>'Invalid image file']); exit;
}

// Build destination path
$uploadDir = EP_BASE_PATH . '/uploads/employee-profiles/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$ext      = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$file['type']] ?? 'jpg';
$filename = 'emp_' . (int)$emp['id'] . '_' . time() . '.' . $ext;
$destPath = $uploadDir . $filename;

// Remove old avatar file
$oldAvatar = EP_Database::queryOne("SELECT avatar FROM employees WHERE id=?", [(int)$emp['id']])['avatar'] ?? null;
if ($oldAvatar) {
    $oldFile = $uploadDir . basename($oldAvatar);
    if (file_exists($oldFile)) @unlink($oldFile);
}

if (!move_uploaded_file($file['tmp_name'], $destPath)) {
    echo json_encode(['success'=>false,'message'=>'Failed to save file — check server permissions']); exit;
}

// Resize to max 400x400 using GD (if available)
if (function_exists('imagecreatefromjpeg')) {
    try {
        $src = imagecreatefromstring(file_get_contents($destPath));
        if ($src) {
            $w = imagesx($src); $h = imagesy($src);
            $maxDim = 400;
            if ($w > $maxDim || $h > $maxDim) {
                $ratio = min($maxDim/$w, $maxDim/$h);
                $nw = (int)($w*$ratio); $nh = (int)($h*$ratio);
                $dst = imagecreatetruecolor($nw, $nh);
                imagealphablending($dst, false); imagesavealpha($dst, true);
                imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
                imagejpeg($dst, $destPath, 85);
                imagedestroy($src); imagedestroy($dst);
            }
        }
    } catch (Throwable) {}
}

// Save to DB
$url = EP_BASE_URL . '/uploads/employee-profiles/' . $filename;
EP_Database::execute("UPDATE employees SET avatar=? WHERE id=?", [$filename, (int)$emp['id']]);
EP_Database::execute(
    "INSERT INTO employee_activity_log (employee_id, description, type, created_at) VALUES (?,?,?,NOW())",
    [(int)$emp['id'], 'Profile photo updated', 'profile']
);

// Update session avatar
$_SESSION['ep_employee']['avatar'] = $filename;

echo json_encode(['success'=>true,'message'=>'Photo updated successfully','url'=>$url]);
