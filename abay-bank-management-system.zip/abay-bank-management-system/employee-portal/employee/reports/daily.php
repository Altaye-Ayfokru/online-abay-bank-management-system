<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Daily Report — ' . EP_NAME;
$breadcrumb = [['label'=>'Reports','url'=>EP_BASE_URL.'/employee/reports/index.php'],['label'=>'Daily']];
$empId = (int)($emp['id'] ?? 0);
$date  = $_GET['date'] ?? date('Y-m-d');

$txns  = EP_Database::query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.created_by=? AND DATE(t.created_at)=? ORDER BY t.created_at DESC", [$empId,$date]) ?: [];
$custs = EP_Database::query("SELECT * FROM customers WHERE created_by=? AND DATE(created_at)=? ORDER BY created_at DESC", [$empId,$date]) ?: [];
$accts = EP_Database::query("SELECT a.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM accounts a JOIN customers c ON c.id=a.customer_id WHERE a.opened_by=? AND a.opened_date=? ORDER BY a.created_at DESC", [$empId,$date]) ?: [];

$totalDeposits    = array_sum(array_column(array_filter($txns, fn($t)=>$t['type']==='Deposit'),    'amount'));
$totalWithdrawals = array_sum(array_column(array_filter($txns, fn($t)=>$t['type']==='Withdrawal'), 'amount'));

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-calendar-day" style="color:var(--teal)"></i> Daily Activity Report</h1></div>
  <div class="ep-page-actions">
    <input type="date" id="date-pick" value="<?= ep_e($date) ?>" class="ep-input" style="width:160px" onchange="window.location.href='?date='+this.value">
    <button onclick="window.print()" class="ep-btn ep-btn-outline"><i class="fa-solid fa-print"></i> Print</button>
  </div>
</div>

<div class="ep-stats">
  <?php foreach ([
    [count($txns),               'Total Transactions',     '#1d4ed8','#dbeafe'],
    ['ETB '.number_format($totalDeposits),  'Deposits',   '#16a34a','#dcfce7'],
    ['ETB '.number_format($totalWithdrawals),'Withdrawals','#dc2626','#fee2e2'],
    [count($custs),              'Customers Registered',   '#7c3aed','#ede9fe'],
    [count($accts),              'Accounts Opened',        '#b45309','#fef9c3'],
  ] as [$v,$l,$c,$bg]): ?>
  <div class="ep-stat"><div class="ep-stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid fa-chart-bar"></i></div>
    <div><div class="ep-stat-val" style="font-size:<?= strlen((string)$v)>10?'.95rem':'1.2rem' ?>"><?= $v ?></div><div class="ep-stat-lbl"><?= $l ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($txns): ?>
<div class="ep-card">
  <div class="ep-card-hdr"><h3>Transactions — <?= ep_date($date) ?></h3></div>
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Time</th><th>Account</th><th>Type</th><th>Amount</th><th>Reference</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($txns as $t): ?>
        <tr>
          <td style="font-size:.8rem;color:var(--muted)"><?= ep_date($t['created_at']??'','H:i') ?></td>
          <td style="font-family:monospace;font-size:.82rem"><?= ep_e($t['account_number']??'—') ?></td>
          <td><?= ep_badge($t['type']??'—') ?></td>
          <td class="fw-7">ETB <?= number_format((float)($t['amount']??0),2) ?></td>
          <td style="font-family:monospace;font-size:.78rem"><?= ep_e($t['reference']??'—') ?></td>
          <td><?= ep_badge($t['status']??'Completed') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php else: ?>
<div class="ep-card"><div class="ep-card-body" style="text-align:center;padding:32px">
  <i class="fa-solid fa-inbox" style="font-size:2rem;color:#cbd5e1;display:block;margin-bottom:10px"></i>
  <p class="text-muted">No transactions recorded for <?= ep_date($date) ?></p>
</div></div>
<?php endif; ?>
<style>@media print{.ep-topbar,.ep-sidebar,.ep-page-actions,.ep-sb-backdrop{display:none!important;}.ep-main{margin:0!important;padding:8px!important;}}</style>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
