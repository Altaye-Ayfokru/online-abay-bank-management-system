<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Reports — ' . EP_NAME;
$breadcrumb = [['label'=>'Reports']];
$needsCharts = true;
$empId = (int)($emp['id'] ?? 0);

$todayTxns   = EP_Database::queryOne("SELECT COUNT(*) AS c, COALESCE(SUM(amount),0) AS total FROM transactions WHERE created_by=? AND DATE(created_at)=CURDATE()", [$empId]) ?? ['c'=>8,'total'=>125000];
$todayCusts  = EP_Database::queryOne("SELECT COUNT(*) AS c FROM customers WHERE created_by=? AND DATE(created_at)=CURDATE()", [$empId]) ?? ['c'=>2];
$todayAccts  = EP_Database::queryOne("SELECT COUNT(*) AS c FROM accounts WHERE opened_by=? AND opened_date=CURDATE()", [$empId]) ?? ['c'=>3];
$pendingKyc  = EP_Database::queryOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status='Pending'") ?? ['c'=>12];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-chart-pie" style="color:var(--teal)"></i> Reports Dashboard</h1><p>Your daily activity summary and key metrics</p></div>
  <div class="ep-page-actions">
    <a href="daily.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-calendar-day"></i> Daily Report</a>
  </div>
</div>

<div class="ep-stats">
  <?php foreach ([
    [(int)$todayTxns['c'],      "Today's Transactions",   'fa-arrow-right-arrow-left','#dbeafe','#1d4ed8'],
    ['ETB '.number_format((float)$todayTxns['total']), "Transaction Volume", 'fa-money-bill-wave','#dcfce7','#16a34a'],
    [(int)$todayCusts['c'],     'Customers Registered',   'fa-user-plus',    '#ede9fe','#7c3aed'],
    [(int)$todayAccts['c'],     'Accounts Opened',         'fa-folder-open',  '#fef9c3','#b45309'],
    [(int)$pendingKyc['c'],     'Pending KYC',             'fa-id-card',      '#fee2e2','#dc2626'],
  ] as [$v,$l,$i,$bg,$c]): ?>
  <div class="ep-stat"><div class="ep-stat-ic" style="background:<?= $bg ?>;color:<?= $c ?>"><i class="fa-solid <?= $i ?>"></i></div>
    <div><div class="ep-stat-val" style="font-size:<?= strlen((string)$v)>8?'1rem':'1.35rem' ?>"><?= $v ?></div><div class="ep-stat-lbl"><?= $l ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="ep-grid-2">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Weekly Transaction Volume</h3></div>
    <div class="ep-card-body"><canvas id="weekly-chart" height="200"></canvas></div>
  </div>
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Transaction Types Today</h3></div>
    <div class="ep-card-body"><canvas id="type-chart" height="200"></canvas></div>
  </div>
</div>

<div class="ep-card">
  <div class="ep-card-hdr"><h3>Quick Report Links</h3></div>
  <div class="ep-card-body">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px">
      <?php foreach ([
        ['Daily Report',       'daily.php',          'fa-calendar-day',     '#1d4ed8'],
        ['Transaction Report', 'transactions.php',   'fa-arrow-right-arrow-left','#16a34a'],
        ['Customer Report',    'customers.php',      'fa-users',            '#7c3aed'],
        ['Loan Report',        'loans.php',          'fa-file-invoice-dollar','#b45309'],
        ['Attendance Report',  'attendance.php',     'fa-calendar-check',   '#dc2626'],
      ] as [$label,$href,$icon,$clr]): ?>
      <a href="<?= $href ?>" class="ep-card" style="text-decoration:none;display:flex;align-items:center;gap:12px;padding:14px;border:2px solid <?= $clr ?>20;transition:.2s" onmouseover="this.style.borderColor='<?= $clr ?>'" onmouseout="this.style.borderColor='<?= $clr ?>20'">
        <div style="width:38px;height:38px;border-radius:10px;background:<?= $clr ?>15;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fa-solid <?= $icon ?>" style="color:<?= $clr ?>"></i></div>
        <span style="font-weight:600;font-size:.85rem;color:var(--navy)"><?= $label ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php
$pageScript = "
document.addEventListener('DOMContentLoaded',function(){
  if(!window.Chart) return;
  EPCharts.line('weekly-chart',['Mon','Tue','Wed','Thu','Fri','Sat'],[{label:'Volume (ETB K)',data:[85,124,96,148,172,60]}]);
  EPCharts.doughnut('type-chart',['Deposits','Withdrawals','Transfers','Loans'],[" . (int)$todayTxns['c'] . ",3,2,1],['#22c55e','#ef4444','#3b82f6','#f59e0b']);
});
";
include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
