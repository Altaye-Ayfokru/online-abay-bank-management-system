<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Settings — ' . EP_NAME;
$breadcrumb = [['label'=>'Settings']];
$empId = (int)($emp['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $section = $_POST['section'] ?? '';
    if ($section === 'notifications') {
        // Save notification preferences
        ep_flash('success', 'Notification preferences saved.');
    } elseif ($section === 'preferences') {
        ep_flash('success', 'Preferences saved.');
    }
    header('Location: ' . EP_BASE_URL . '/employee/settings/index.php'); exit;
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-gear" style="color:var(--teal)"></i> Settings</h1><p>Manage your portal preferences and notification settings</p></div>
</div>

<div style="max-width:720px">
  <!-- Profile Quick Links -->
  <div class="ep-card" style="margin-bottom:20px">
    <div class="ep-card-hdr"><h3><i class="fa-solid fa-user"></i> Account</h3></div>
    <div class="ep-card-body">
      <div style="display:flex;flex-direction:column;gap:2px">
        <?php foreach ([
          [EP_BASE_URL.'/employee/profile/index.php',   'fa-user-circle',  'View Profile',          'View and update your personal information'],
          [EP_BASE_URL.'/employee/profile/edit.php',    'fa-pen',          'Edit Profile',           'Update contact details and personal info'],
          [EP_BASE_URL.'/employee/profile/photo.php',   'fa-camera',       'Update Profile Photo',   'Upload a new profile picture'],
          [EP_BASE_URL.'/employee/profile/change-password.php','fa-lock',  'Change Password',        'Update your account password'],
        ] as [$url,$icon,$label,$desc]): ?>
        <a href="<?= $url ?>" style="display:flex;align-items:center;gap:14px;padding:13px;border-radius:10px;text-decoration:none;transition:.2s;color:var(--text)" onmouseover="this.style.background='var(--light)'" onmouseout="this.style.background=''">
          <div style="width:38px;height:38px;background:var(--light);border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fa-solid <?= $icon ?>" style="color:var(--teal)"></i></div>
          <div><div class="fw-6" style="font-size:.88rem"><?= $label ?></div><div style="font-size:.78rem;color:var(--muted)"><?= $desc ?></div></div>
          <i class="fa-solid fa-chevron-right" style="margin-left:auto;color:var(--muted);font-size:.75rem"></i>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Notification Preferences -->
  <div class="ep-card" style="margin-bottom:20px">
    <div class="ep-card-hdr"><h3><i class="fa-solid fa-bell"></i> Notification Preferences</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="section" value="notifications">
        <?php foreach ([
          ['notify_leave',    'Leave Updates',      'When leave requests are approved or rejected'],
          ['notify_payroll',  'Payroll',            'When payslip is generated'],
          ['notify_tasks',    'Task Assignments',   'When new tasks are assigned to you'],
          ['notify_kyc',      'KYC Alerts',         'Pending KYC verifications requiring your attention'],
          ['notify_security', 'Security Alerts',    'Login from new devices or password changes'],
        ] as [$name,$label,$desc]): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border)">
          <div><div class="fw-6" style="font-size:.87rem"><?= $label ?></div><div style="font-size:.78rem;color:var(--muted)"><?= $desc ?></div></div>
          <label class="ep-toggle"><input type="checkbox" name="<?= $name ?>" checked onchange="EP.toast('Preference updated','success')"><span class="ep-toggle-slider"></span></label>
        </div>
        <?php endforeach; ?>
        <div style="margin-top:16px"><button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-save"></i> Save Preferences</button></div>
      </form>
    </div>
  </div>

  <!-- Display Preferences -->
  <div class="ep-card">
    <div class="ep-card-hdr"><h3><i class="fa-solid fa-palette"></i> Display Preferences</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="section" value="preferences">
        <div class="ep-form-row">
          <div class="ep-form-group">
            <label class="ep-label">Language</label>
            <select class="ep-select"><option>English</option><option>አማርኛ (Amharic)</option><option>Afaan Oromoo</option></select>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Theme</label>
            <select class="ep-select" onchange="localStorage.setItem('ep_theme',this.value);EP.toast(this.value+' mode','success')">
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Items Per Page</label>
            <select class="ep-select"><option>10</option><option selected>15</option><option>25</option><option>50</option></select>
          </div>
          <div class="ep-form-group">
            <label class="ep-label">Time Zone</label>
            <select class="ep-select"><option selected>Africa/Addis_Ababa (EAT +3)</option><option>UTC</option></select>
          </div>
        </div>
        <button type="submit" class="ep-btn ep-btn-primary"><i class="fa-solid fa-save"></i> Save Settings</button>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
