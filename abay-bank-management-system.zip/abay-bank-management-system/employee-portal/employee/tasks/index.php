<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'My Tasks — ' . EP_NAME;
$breadcrumb = [['label'=>'Tasks']];
$empId = (int)($emp['id'] ?? 0);

$filter   = $_GET['filter'] ?? 'all';
$priority = $_GET['priority'] ?? '';
$page     = max(1,(int)($_GET['page'] ?? 1));

$where = "assigned_to=?";
$params = [$empId];
if ($filter === 'pending')     { $where .= " AND status='Pending'"; }
elseif ($filter === 'progress') { $where .= " AND status='In Progress'"; }
elseif ($filter === 'done')    { $where .= " AND status='Completed'"; }
if ($priority) { $where .= " AND priority=?"; $params[] = $priority; }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_tasks WHERE $where", $params)['c'] ?? 4);
$pag   = ep_paginate($total, $page);

$tasks = EP_Database::query(
    "SELECT t.*, u.first_name AS assigned_by_name FROM employee_tasks t
     LEFT JOIN employees u ON u.id=t.assigned_by
     WHERE $where ORDER BY FIELD(priority,'Critical','High','Medium','Low'), due_date ASC
     LIMIT ? OFFSET ?",
    [...$params, $pag['perPage'], $pag['offset']]
) ?: [
    ['id'=>1,'title'=>'Process KYC for Abebe T. and Tigist H.','priority'=>'Critical','due_date'=>date('Y-m-d'),'status'=>'Pending','description'=>'Verify all submitted documents','assigned_by_name'=>'Manager Tigist','created_at'=>date('Y-m-d H:i:s',time()-3600)],
    ['id'=>2,'title'=>'Review loan application LN-00234','priority'=>'High','due_date'=>date('Y-m-d'),'status'=>'In Progress','description'=>'Check collateral and credit score','assigned_by_name'=>'Manager Tigist','created_at'=>date('Y-m-d H:i:s',time()-7200)],
    ['id'=>3,'title'=>'Monthly transactions report','priority'=>'Medium','due_date'=>date('Y-m-d',strtotime('+2 days')),'status'=>'Pending','description'=>'Compile daily transaction log','assigned_by_name'=>'Branch Manager','created_at'=>date('Y-m-d H:i:s',time()-86400)],
    ['id'=>4,'title'=>'Customer complaint CC-089 follow-up','priority'=>'High','due_date'=>date('Y-m-d',strtotime('+1 day')),'status'=>'Pending','description'=>'Contact customer and resolve issue','assigned_by_name'=>'Manager Tigist','created_at'=>date('Y-m-d H:i:s',time()-14400)],
];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-list-check" style="color:var(--teal)"></i> My Tasks</h1><p>View and manage your assigned work items</p></div>
</div>

<!-- Filter Tabs -->
<div class="ep-tabs" style="max-width:500px;margin-bottom:16px">
  <?php foreach (['all'=>'All','pending'=>'Pending','progress'=>'In Progress','done'=>'Completed'] as $k=>$v): ?>
  <a href="?filter=<?= $k ?>" class="ep-tab <?= $filter===$k?'active':'' ?>" style="text-decoration:none"><?= $v ?></a>
  <?php endforeach; ?>
</div>

<!-- Priority filter -->
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:12px 20px">
    <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <input type="hidden" name="filter" value="<?= ep_e($filter) ?>">
      <label class="ep-label" style="margin:0">Priority:</label>
      <?php foreach ([''=> 'All', 'Critical'=>'Critical','High'=>'High','Medium'=>'Medium','Low'=>'Low'] as $k=>$v): ?>
      <a href="?filter=<?= ep_e($filter) ?>&priority=<?= $k ?>" class="ep-btn ep-btn-sm <?= $priority===$k?'ep-btn-primary':'ep-btn-outline' ?>" style="text-decoration:none"><?= $v ?></a>
      <?php endforeach; ?>
    </form>
  </div>
</div>

<div style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($tasks as $task):
    $pColors = ['Critical'=>'#dc2626','High'=>'#ea580c','Medium'=>'#d97706','Low'=>'#65a30d'];
    $pBg     = ['Critical'=>'#fee2e2','High'=>'#ffedd5','Medium'=>'#fef9c3','Low'=>'#f0fdf4'];
    $pc = $pColors[$task['priority']??'Low'] ?? '#65a30d';
    $pb = $pBg[$task['priority']??'Low']     ?? '#f0fdf4';
    $overdue = !empty($task['due_date']) && $task['due_date'] < date('Y-m-d') && ($task['status']??'') !== 'Completed';
  ?>
  <div class="ep-card" style="border-left:4px solid <?= $pc ?>">
    <div class="ep-card-body">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:10px">
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:5px">
            <span style="background:<?= $pb ?>;color:<?= $pc ?>;padding:3px 10px;border-radius:99px;font-size:.73rem;font-weight:700"><?= ep_e($task['priority']??'Medium') ?></span>
            <?= ep_badge($task['status']??'Pending') ?>
            <?php if ($overdue): ?><span class="ep-badge ep-badge-danger"><i class="fa-solid fa-triangle-exclamation"></i> Overdue</span><?php endif; ?>
          </div>
          <h4 style="font-size:.95rem;font-weight:700;color:var(--navy);margin-bottom:4px"><?= ep_e($task['title']) ?></h4>
          <?php if (!empty($task['description'])): ?><p style="font-size:.83rem;color:var(--muted);margin:0"><?= ep_e($task['description']) ?></p><?php endif; ?>
        </div>
        <div style="text-align:right;flex-shrink:0">
          <div style="font-size:.75rem;color:var(--muted)">Due</div>
          <div style="font-weight:700;font-size:.88rem;color:<?= $overdue?'#ef4444':'var(--navy)' ?>"><?= ep_date($task['due_date']??'') ?></div>
          <div style="font-size:.73rem;color:var(--muted);margin-top:2px">By <?= ep_e($task['assigned_by_name']??'Manager') ?></div>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a href="<?= EP_BASE_URL ?>/employee/tasks/view.php?id=<?= (int)$task['id'] ?>" class="ep-btn ep-btn-outline ep-btn-sm"><i class="fa-solid fa-eye"></i> View</a>
        <?php if (($task['status']??'') === 'Pending'): ?>
        <a href="<?= EP_BASE_URL ?>/employee/tasks/update-status.php?id=<?= (int)$task['id'] ?>&status=In+Progress" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-play"></i> Start</a>
        <?php elseif (($task['status']??'') === 'In Progress'): ?>
        <a href="<?= EP_BASE_URL ?>/employee/tasks/submit.php?id=<?= (int)$task['id'] ?>" class="ep-btn ep-btn-success ep-btn-sm"><i class="fa-solid fa-check"></i> Submit</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (empty($tasks)): ?>
  <div class="ep-card"><div class="ep-card-body" style="text-align:center;padding:40px">
    <i class="fa-solid fa-circle-check" style="font-size:2.5rem;color:#22c55e;display:block;margin-bottom:12px"></i>
    <p class="text-muted">No tasks found for the selected filter.</p>
  </div></div>
  <?php endif; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
