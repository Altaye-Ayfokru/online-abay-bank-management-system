<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$id    = (int)($_GET['id'] ?? 0);
$task  = EP_Database::queryOne("SELECT * FROM employee_tasks WHERE id=? AND assigned_to=?", [$id, $empId]) ?? ['id'=>$id,'title'=>'Task'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $notes = trim($_POST['notes'] ?? '');
    EP_Database::execute("UPDATE employee_tasks SET status='Completed', completion_notes=?, completed_at=NOW() WHERE id=? AND assigned_to=?", [$notes, $id, $empId]);
    EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())", [$empId,"Task #$id submitted as completed",'task']);
    ep_flash('success', 'Task marked as completed!');
    header('Location: ' . EP_BASE_URL . '/employee/tasks/index.php'); exit;
}
$pageTitle  = 'Submit Task — ' . EP_NAME;
$breadcrumb = [['label'=>'Tasks','url'=>EP_BASE_URL.'/employee/tasks/index.php'],['label'=>'Submit']];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr"><div><h1><i class="fa-solid fa-check-circle" style="color:var(--ok)"></i> Submit Task</h1></div></div>
<div style="max-width:520px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3><?= ep_e($task['title']) ?></h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group">
          <label class="ep-label">Completion Notes</label>
          <textarea name="notes" class="ep-textarea" rows="4" placeholder="Describe what was done, any issues, or outcomes…"></textarea>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <a href="index.php" class="ep-btn ep-btn-outline">Cancel</a>
          <button type="submit" class="ep-btn ep-btn-success"><i class="fa-solid fa-check"></i> Mark Complete</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
