<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$empId  = (int)($emp['id'] ?? 0);
$id     = (int)($_GET['id'] ?? 0);
$status = $_GET['status'] ?? '';
$allowed = ['Pending','In Progress','Completed'];
if ($id && in_array($status, $allowed)) {
    EP_Database::execute("UPDATE employee_tasks SET status=? WHERE id=? AND assigned_to=?", [$status, $id, $empId]);
    EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())", [$empId,"Task #$id status → $status",'task']);
    ep_flash('success', "Task status updated to $status.");
}
header('Location: ' . EP_BASE_URL . '/employee/tasks/index.php'); exit;
