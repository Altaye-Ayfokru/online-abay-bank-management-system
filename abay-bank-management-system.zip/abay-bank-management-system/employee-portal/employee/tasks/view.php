<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$empId = (int)($emp['id'] ?? 0);
$id    = (int)($_GET['id'] ?? 0);
$task  = EP_Database::queryOne("SELECT t.*, e.first_name AS assigned_by_name FROM employee_tasks t LEFT JOIN employees e ON e.id=t.assigned_by WHERE t.id=? AND t.assigned_to=?", [$id, $empId])
       ?? ['id'=>$id,'title'=>'Sample Task','priority'=>'High','status'=>'Pending','due_date'=>date('Y-m-d'),'description'=>'Task description goes here.','assigned_by_name'=>'Manager','created_at'=>date('Y-m-d H:i:s')];
$pageTitle  = 'Task — ' . EP_NAME;
$breadcrumb = [['label'=>'Tasks','url'=>EP_BASE_URL.'/employee/tasks/index.php'],['label'=>ep_e($task['title'])]];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-list-check" style="color:var(--teal)"></i> Task Detail</h1></div>
  <div class="ep-page-actions">
    <?php if ($task['status']==='Pending'): ?><a href="update-status.php?id=<?= $id ?>&status=In+Progress" class="ep-btn ep-btn-primary"><i class="fa-solid fa-play"></i> Start Task</a><?php endif; ?>
    <?php if ($task['status']==='In Progress'): ?><a href="submit.php?id=<?= $id ?>" class="ep-btn ep-btn-success"><i class="fa-solid fa-check"></i> Submit</a><?php endif; ?>
    <a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a>
  </div>
</div>
<div style="max-width:700px">
  <div class="ep-card">
    <div class="ep-card-body">
      <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
        <?= ep_badge($task['status']) ?>
        <span style="background:#fee2e2;color:#dc2626;padding:3px 10px;border-radius:99px;font-size:.73rem;font-weight:700"><?= ep_e($task['priority']) ?></span>
      </div>
      <h2 style="font-size:1.15rem;font-weight:800;color:var(--navy);margin-bottom:12px"><?= ep_e($task['title']) ?></h2>
      <p style="font-size:.87rem;color:var(--muted);line-height:1.7;margin-bottom:20px"><?= ep_e($task['description']??'No description provided.') ?></p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <?php foreach ([['Due Date',ep_date($task['due_date']??'')],['Assigned By',ep_e($task['assigned_by_name']??'')],['Created',ep_ago($task['created_at']??'')],['Status',ep_badge($task['status']??'')]] as [$l,$v]): ?>
        <div style="background:var(--light);border-radius:10px;padding:12px">
          <div style="font-size:.7rem;color:var(--muted);font-weight:700;text-transform:uppercase;margin-bottom:4px"><?= $l ?></div>
          <div class="fw-6"><?= $v ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
