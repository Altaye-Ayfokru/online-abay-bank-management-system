<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Training — ' . EP_NAME;
$breadcrumb = [['label'=>'Training']];
$empId = (int)($emp['id'] ?? 0);

// Handle enroll POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enroll'])) {
    ep_csrf_check();
    $trainingId = (int)$_POST['training_id'];
    $db = EP_Database::get();
    if ($db) {
        $exists = EP_Database::queryOne(
            "SELECT id FROM training_enrollments WHERE training_id=? AND employee_id=?", [$trainingId, $empId]
        );
        if (!$exists) {
            EP_Database::execute(
                "INSERT INTO training_enrollments (training_id,employee_id,status,created_at) VALUES (?,?,'Enrolled',NOW())",
                [$trainingId, $empId]
            );
        }
    }
    ep_flash('success', 'Successfully enrolled in training program.');
    ep_redirect(EP_BASE_URL . '/employee/training/index.php');
}

$flashSuccess = ep_get_flash('success');

$tab = $_GET['tab'] ?? 'available';

// My enrollments
$myEnrollments = EP_Database::query(
    "SELECT te.training_id, te.status AS enroll_status, te.progress,
            t.title, t.trainer, t.start_date, t.end_date, t.mode, t.status,
            t.description, t.duration_hours
     FROM training_enrollments te
     JOIN training_programs t ON t.id = te.training_id
     WHERE te.employee_id = ? ORDER BY t.start_date DESC",
    [$empId]
) ?: [];

$enrolledIds = array_column($myEnrollments, 'training_id');

// Available programs
$programs = EP_Database::query(
    "SELECT t.*, (SELECT COUNT(*) FROM training_enrollments WHERE training_id=t.id) AS enrolled_count
     FROM training_programs t ORDER BY t.start_date ASC",
    []
) ?: [
    ['id'=>1,'title'=>'Anti-Money Laundering (AML) Compliance','trainer'=>'Compliance Team','start_date'=>date('Y-m-d',strtotime('+5 days')),'end_date'=>date('Y-m-d',strtotime('+5 days')),'mode'=>'In-Person','status'=>'Upcoming','description'=>'Mandatory AML training for all banking staff covering detection and reporting procedures.','duration_hours'=>8,'enrolled_count'=>23],
    ['id'=>2,'title'=>'Customer Service Excellence',           'trainer'=>'Dr. Aisha Mohamed','start_date'=>date('Y-m-d',strtotime('+10 days')),'end_date'=>date('Y-m-d',strtotime('+11 days')),'mode'=>'In-Person','status'=>'Upcoming','description'=>'Enhance customer interaction skills, complaint handling, and service delivery.','duration_hours'=>16,'enrolled_count'=>18],
    ['id'=>3,'title'=>'Digital Banking & Fintech Trends',     'trainer'=>'IT Department','start_date'=>date('Y-m-d',strtotime('-3 days')),'end_date'=>date('Y-m-d',strtotime('+4 days')),'mode'=>'Online','status'=>'In Progress','description'=>'Overview of digital banking innovations, mobile money, and emerging fintech solutions.','duration_hours'=>12,'enrolled_count'=>35],
    ['id'=>4,'title'=>'Credit Risk Assessment',               'trainer'=>'Risk Management Dept','start_date'=>date('Y-m-d',strtotime('+20 days')),'end_date'=>date('Y-m-d',strtotime('+22 days')),'mode'=>'Hybrid','status'=>'Upcoming','description'=>'Advanced training on evaluating loan applications, credit scoring, and portfolio management.','duration_hours'=>24,'enrolled_count'=>12],
    ['id'=>5,'title'=>'MS Excel for Banking Professionals',   'trainer'=>'IT Training Center','start_date'=>date('Y-m-d',strtotime('-30 days')),'end_date'=>date('Y-m-d',strtotime('-28 days')),'mode'=>'In-Person','status'=>'Completed','description'=>'Excel skills for financial analysis, data management, and reporting.','duration_hours'=>16,'enrolled_count'=>29],
    ['id'=>6,'title'=>'Leadership & Team Management',         'trainer'=>'HR Development','start_date'=>date('Y-m-d',strtotime('+35 days')),'end_date'=>date('Y-m-d',strtotime('+36 days')),'mode'=>'In-Person','status'=>'Upcoming','description'=>'Developing leadership potential, team collaboration, and conflict resolution skills.','duration_hours'=>16,'enrolled_count'=>8],
];

$modeColors  = ['Online'=>'#3b82f6','In-Person'=>'#22c55e','Hybrid'=>'#8b5cf6'];
$modeIcons   = ['Online'=>'wifi','In-Person'=>'building','Hybrid'=>'laptop-code'];
$statusColors= ['Upcoming'=>'#f59e0b','In Progress'=>'#3b82f6','Completed'=>'#22c55e'];

// Merge enrollment data into programs
$myMap = [];
foreach ($myEnrollments as $e) { $myMap[$e['training_id']] = $e; }

// Build demo enrollments if empty
if (empty($myEnrollments)) {
    $myEnrollments = [
        array_merge($programs[2] ?? [], ['enroll_status'=>'In Progress','progress'=>45,'training_id'=>3]),
        array_merge($programs[4] ?? [], ['enroll_status'=>'Completed',  'progress'=>100,'training_id'=>5]),
    ];
    foreach ($myEnrollments as $e) { $myMap[$e['training_id']] = $e; }
    $enrolledIds = array_column($myEnrollments, 'training_id');
}

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-graduation-cap" style="color:var(--teal)"></i> Training Programs</h1>
    <p>Professional development and learning opportunities</p>
  </div>
</div>

<?php if ($flashSuccess): ?><div class="ep-alert ep-alert-success"><i class="fa-solid fa-circle-check"></i> <?= ep_e($flashSuccess) ?></div><?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid var(--border)">
  <?php foreach ([['available','Available','book-open'],['my','My Enrollments','user-graduate']] as [$key,$label,$icon]): ?>
  <a href="?tab=<?= $key ?>" style="padding:10px 18px;font-weight:600;font-size:.88rem;text-decoration:none;border-bottom:2px solid transparent;margin-bottom:-2px;
     <?= $tab===$key ? 'color:var(--teal);border-color:var(--teal)' : 'color:var(--muted)' ?>">
    <i class="fa-solid fa-<?= $icon ?>"></i> <?= $label ?>
  </a>
  <?php endforeach; ?>
</div>

<?php if ($tab === 'my'): ?>
<!-- My Enrollments -->
<?php if (empty($myEnrollments)): ?>
<div class="ep-card">
  <div class="ep-card-body" style="text-align:center;padding:40px;color:var(--muted)">
    <i class="fa-solid fa-graduation-cap" style="font-size:2rem;margin-bottom:10px;display:block"></i>
    Not enrolled in any training programs yet. <a href="?tab=available" style="color:var(--teal)">Browse available programs</a>.
  </div>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px">
  <?php foreach ($myEnrollments as $prog): ?>
  <?php
    $mc = $modeColors[$prog['mode'] ?? '']  ?? '#64748b';
    $mi = $modeIcons[$prog['mode'] ?? '']   ?? 'chalkboard-teacher';
    $sc = $statusColors[$prog['status'] ?? ''] ?? '#64748b';
    $pct = min(100, max(0, (int)($prog['progress'] ?? 0)));
  ?>
  <div class="ep-card">
    <div class="ep-card-body">
      <div style="display:flex;justify-content:space-between;margin-bottom:10px">
        <span style="font-size:.78rem;font-weight:600;color:<?= $mc ?>;background:<?= $mc ?>18;padding:3px 10px;border-radius:20px">
          <i class="fa-solid fa-<?= $mi ?>"></i> <?= ep_e($prog['mode'] ?? '') ?>
        </span>
        <?= ep_badge($prog['status'] ?? '') ?>
      </div>
      <div class="fw-6" style="font-size:.9rem;margin-bottom:6px"><?= ep_e($prog['title'] ?? '') ?></div>
      <div style="font-size:.8rem;color:var(--muted);margin-bottom:12px">
        <i class="fa-solid fa-chalkboard-teacher" style="width:14px"></i> <?= ep_e($prog['trainer'] ?? '') ?>
        &nbsp;&bull;&nbsp;
        <i class="fa-solid fa-clock" style="width:14px"></i> <?= (int)($prog['duration_hours'] ?? 0) ?>h
      </div>
      <?php if ($pct > 0): ?>
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:4px">
          <span style="color:var(--muted)">Progress</span>
          <span class="fw-6" style="color:var(--teal)"><?= $pct ?>%</span>
        </div>
        <div class="ep-progress"><div class="ep-progress-fill" style="width:<?= $pct ?>%"></div></div>
      </div>
      <?php endif; ?>
      <div style="font-size:.8rem;color:var(--muted)">
        <?= ep_date($prog['start_date'] ?? '') ?> — <?= ep_date($prog['end_date'] ?? '') ?>
      </div>
      <?php if (($prog['enroll_status'] ?? '') === 'Completed' || $pct >= 100): ?>
      <a href="#" class="ep-btn ep-btn-outline ep-btn-sm" style="margin-top:12px;width:100%;justify-content:center;display:flex">
        <i class="fa-solid fa-certificate"></i> View Certificate
      </a>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php else: ?>
<!-- Available Programs -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px">
  <?php foreach ($programs as $prog): ?>
  <?php
    $mc  = $modeColors[$prog['mode'] ?? '']   ?? '#64748b';
    $mi  = $modeIcons[$prog['mode'] ?? '']    ?? 'chalkboard-teacher';
    $sc  = $statusColors[$prog['status'] ?? ''] ?? '#64748b';
    $isEnrolled = in_array((int)($prog['id'] ?? 0), $enrolledIds, true);
  ?>
  <div class="ep-card">
    <div class="ep-card-body">
      <div style="display:flex;justify-content:space-between;margin-bottom:10px">
        <span style="font-size:.78rem;font-weight:600;color:<?= $mc ?>;background:<?= $mc ?>18;padding:3px 10px;border-radius:20px">
          <i class="fa-solid fa-<?= $mi ?>"></i> <?= ep_e($prog['mode'] ?? '') ?>
        </span>
        <span style="font-size:.78rem;font-weight:600;color:<?= $sc ?>"><?= ep_e($prog['status'] ?? '') ?></span>
      </div>
      <div class="fw-6" style="font-size:.9rem;margin-bottom:6px"><?= ep_e($prog['title'] ?? '') ?></div>
      <p style="font-size:.8rem;color:var(--muted);line-height:1.5;margin:0 0 12px"><?= ep_e($prog['description'] ?? '') ?></p>
      <div style="font-size:.8rem;color:var(--muted);display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px">
        <span><i class="fa-solid fa-chalkboard-teacher" style="width:14px"></i> <?= ep_e($prog['trainer'] ?? '') ?></span>
        <span><i class="fa-solid fa-clock" style="width:14px"></i> <?= (int)($prog['duration_hours'] ?? 0) ?>h</span>
        <span><i class="fa-solid fa-users" style="width:14px"></i> <?= (int)($prog['enrolled_count'] ?? 0) ?> enrolled</span>
      </div>
      <div style="font-size:.8rem;color:var(--muted);margin-bottom:12px">
        <i class="fa-solid fa-calendar" style="width:14px"></i>
        <?= ep_date($prog['start_date'] ?? '') ?> — <?= ep_date($prog['end_date'] ?? '') ?>
      </div>
      <?php if ($prog['status'] === 'Completed'): ?>
      <div class="ep-btn ep-btn-ghost ep-btn-sm" style="width:100%;justify-content:center;display:flex;cursor:default;opacity:.5">
        <i class="fa-solid fa-check"></i> Completed
      </div>
      <?php elseif ($isEnrolled): ?>
      <div class="ep-btn ep-btn-outline ep-btn-sm" style="width:100%;justify-content:center;display:flex;cursor:default;color:#22c55e;border-color:#22c55e">
        <i class="fa-solid fa-circle-check"></i> Enrolled
      </div>
      <?php else: ?>
      <form method="POST" style="margin:0">
        <?= ep_csrf_field() ?>
        <input type="hidden" name="training_id" value="<?= (int)($prog['id'] ?? 0) ?>">
        <button type="submit" name="enroll" value="1" class="ep-btn ep-btn-primary ep-btn-sm" style="width:100%">
          <i class="fa-solid fa-plus"></i> Enroll
        </button>
      </form>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
