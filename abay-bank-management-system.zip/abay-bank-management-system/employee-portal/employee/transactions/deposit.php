<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Deposit — ' . EP_NAME;
$breadcrumb = [['label'=>'Transactions','url'=>EP_BASE_URL.'/employee/transactions/index.php'],['label'=>'Deposit']];
$empId  = (int)($emp['id'] ?? 0);
$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $accNo  = trim($_POST['account_number'] ?? '');
    $amount = (float)($_POST['amount']      ?? 0);
    $desc   = trim($_POST['description']    ?? 'Cash Deposit');
    $type   = trim($_POST['deposit_type']   ?? 'Cash');

    if (!$accNo)      $errors[] = 'Account number is required.';
    if ($amount < 1)  $errors[] = 'Minimum deposit is ETB 1.';
    if ($amount > 5000000) $errors[] = 'Amount exceeds limit ETB 5,000,000.';

    if (!$errors) {
        $db = EP_Database::get();
        if ($db) {
            try {
                $db->beginTransaction();
                $acc = EP_Database::queryOne("SELECT id, balance, status FROM accounts WHERE account_number=? FOR UPDATE", [$accNo]);
                if (!$acc || $acc['status'] !== 'Active') throw new RuntimeException('Account not found or inactive.');
                $newBal = (float)$acc['balance'] + $amount;
                EP_Database::execute("UPDATE accounts SET balance=?, updated_at=NOW() WHERE id=?", [$newBal,$acc['id']]);
                $ref = 'DEP-' . strtoupper(substr(uniqid('',true),-8));
                EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,?,?,?,?,?,'Completed',?,NOW())", [$acc['id'],'Deposit',$amount,$newBal,$desc,$ref,$empId]);
                EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())", [$empId,"Deposit ETB $amount to $accNo. Ref:$ref",'transaction']);
                $db->commit();
                $success = "Deposit of ETB " . number_format($amount,2) . " to $accNo successful. Reference: $ref";
            } catch (Throwable $e) { $db->rollBack(); $errors[] = $e->getMessage(); }
        } else {
            $ref = 'DEP-' . strtoupper(substr(uniqid('',true),-8));
            $success = "Demo: Deposit of ETB " . number_format($amount,2) . " recorded. Reference: $ref";
        }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-arrow-down" style="color:#22c55e"></i> Cash Deposit</h1></div>
  <div class="ep-page-actions"><a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($success): ?><div class="ep-alert ep-alert-success"><i class="fa-solid fa-circle-check"></i><?= ep_e($success) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>
<div class="ep-grid-2" style="align-items:start;max-width:900px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Deposit Form</h3></div>
    <div class="ep-card-body">
      <form method="POST" id="dep-form">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group">
          <label class="ep-label">Account Number <span class="req">*</span></label>
          <div class="ep-inp-wrap"><i class="fa-solid fa-building-columns ep-inp-ic"></i>
            <input type="text" name="account_number" id="acc-no" class="ep-input" placeholder="e.g. 1000012345678" required oninput="lookupAcc(this.value)">
          </div>
        </div>
        <div id="acc-info" style="display:none;background:#f0fdf4;border:1px solid #a7f3d0;border-radius:10px;padding:12px 14px;margin-bottom:14px">
          <div class="fw-6" id="acc-holder">—</div>
          <div style="font-size:.82rem;color:#065f46" id="acc-balance">—</div>
        </div>
        <div class="ep-form-row">
          <div class="ep-form-group"><label class="ep-label">Deposit Type</label>
            <select name="deposit_type" class="ep-select"><option>Cash</option><option>Cheque</option><option>Bank Transfer</option></select></div>
          <div class="ep-form-group"><label class="ep-label">Amount (ETB) <span class="req">*</span></label>
            <input type="number" name="amount" class="ep-input ep-inp-noi" min="1" step="0.01" placeholder="0.00" required oninput="updatePreview(this.value)"></div>
        </div>
        <div class="ep-form-group"><label class="ep-label">Narration</label><input type="text" name="description" class="ep-input ep-inp-noi" value="Cash Deposit" placeholder="Purpose of deposit"></div>
        <button type="submit" class="ep-btn ep-btn-success" style="width:100%"><i class="fa-solid fa-arrow-down"></i> Process Deposit</button>
      </form>
    </div>
  </div>
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Summary</h3></div>
    <div class="ep-card-body">
      <?php foreach ([['Account','—','sum-acc'],['Customer','—','sum-cust'],['Current Balance','—','sum-bal'],['Deposit Amount','ETB 0.00','sum-amt'],['New Balance','—','sum-new']] as [$l,$d,$id]): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);font-size:.84rem">
        <span class="text-muted"><?= $l ?></span><span class="fw-6" id="<?= $id ?>"><?= $d ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<script>
var _accBal = 0;
function lookupAcc(v) {
  if (v.length < 5) return;
  clearTimeout(window._accT);
  window._accT = setTimeout(function(){
    fetch('<?= EP_BASE_URL ?>/api/accounts/search.php?account_number='+encodeURIComponent(v))
      .then(r=>r.json()).then(d=>{
        if(d&&d.success&&d.data){
          var a=d.data; _accBal=parseFloat(a.balance||0);
          document.getElementById('acc-holder').textContent=a.customer_name||'—';
          document.getElementById('acc-balance').textContent='Balance: ETB '+Number(_accBal).toLocaleString('en-US',{minimumFractionDigits:2});
          document.getElementById('acc-info').style.display='';
          document.getElementById('sum-acc').textContent=a.account_number||v;
          document.getElementById('sum-cust').textContent=a.customer_name||'—';
          document.getElementById('sum-bal').textContent='ETB '+Number(_accBal).toLocaleString('en-US',{minimumFractionDigits:2});
          updatePreview(document.querySelector('[name="amount"]').value);
        }
      }).catch(()=>{ _accBal=84500; document.getElementById('acc-info').style.display='none'; });
  },500);
}
function updatePreview(v){
  var amt=parseFloat(v)||0;
  document.getElementById('sum-amt').textContent='ETB '+amt.toLocaleString('en-US',{minimumFractionDigits:2});
  document.getElementById('sum-new').textContent='ETB '+(_accBal+amt).toLocaleString('en-US',{minimumFractionDigits:2});
}
</script>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
