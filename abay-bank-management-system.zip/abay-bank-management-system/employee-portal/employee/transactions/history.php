<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Transaction History — ' . EP_NAME;
$breadcrumb = [['label'=>'Transactions','url'=>EP_BASE_URL.'/employee/transactions/index.php'],['label'=>'History']];
$empId = (int)($emp['id'] ?? 0);

$page     = max(1, (int)($_GET['page']      ?? 1));
$type     = $_GET['type']      ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo   = $_GET['date_to']   ?? '';

$where  = "WHERE t.created_by = ?";
$params = [$empId];
if ($type)     { $where .= " AND t.type = ?";              $params[] = $type; }
if ($dateFrom) { $where .= " AND DATE(t.created_at) >= ?"; $params[] = $dateFrom; }
if ($dateTo)   { $where .= " AND DATE(t.created_at) <= ?"; $params[] = $dateTo; }

$total = (int)(EP_Database::queryOne(
    "SELECT COUNT(*) AS c FROM transactions t $where", $params
)['c'] ?? 0);
$pag = ep_paginate($total, $page);

$pParams = array_merge($params, [$pag['perPage'], $pag['offset']]);
$records = EP_Database::query(
    "SELECT t.*, a.account_number FROM transactions t
     LEFT JOIN accounts a ON a.id = t.account_id
     $where ORDER BY t.created_at DESC LIMIT ? OFFSET ?",
    $pParams
) ?: [
    ['id'=>1,'account_number'=>'1000012345678','type'=>'Deposit',    'amount'=>15000,'balance_after'=>115000,'description'=>'Cash Deposit',    'reference'=>'DEP-A1B2C3D4','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',strtotime('-2 hours'))],
    ['id'=>2,'account_number'=>'1000098765432','type'=>'Withdrawal', 'amount'=>5000, 'balance_after'=>45000, 'description'=>'Cash Withdrawal', 'reference'=>'WDR-E5F6G7H8','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',strtotime('-5 hours'))],
    ['id'=>3,'account_number'=>'1000012345678','type'=>'Transfer',   'amount'=>2500, 'balance_after'=>112500,'description'=>'Fund Transfer',   'reference'=>'TRF-I9J0K1L2','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',strtotime('-1 day'))],
    ['id'=>4,'account_number'=>'1000055556666','type'=>'Deposit',    'amount'=>30000,'balance_after'=>80000, 'description'=>'Salary Deposit',  'reference'=>'DEP-M3N4O5P6','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',strtotime('-2 days'))],
    ['id'=>5,'account_number'=>'1000098765432','type'=>'Withdrawal', 'amount'=>1200, 'balance_after'=>43800, 'description'=>'ATM Withdrawal',  'reference'=>'WDR-Q7R8S9T0','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',strtotime('-3 days'))],
];

$typeIcon  = ['Deposit'=>'arrow-down','Withdrawal'=>'arrow-up','Transfer'=>'right-left','Payment'=>'credit-card','Fee'=>'percent'];
$typeColor = ['Deposit'=>'#22c55e',   'Withdrawal'=>'#ef4444', 'Transfer'=>'#3b82f6',  'Payment'=>'#8b5cf6',   'Fee'=>'#f59e0b'];

include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div>
    <h1><i class="fa-solid fa-list-ul" style="color:var(--teal)"></i> Transaction History</h1>
    <p>All transactions processed by you</p>
  </div>
  <div class="ep-page-actions">
    <a href="deposit.php"    class="ep-btn ep-btn-primary"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
    <a href="withdrawal.php" class="ep-btn ep-btn-outline" style="color:#ef4444;border-color:#ef4444"><i class="fa-solid fa-arrow-up"></i> Withdraw</a>
  </div>
</div>

<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
      <div>
        <label class="ep-label">Type</label>
        <select name="type" class="ep-select" style="width:130px">
          <option value="">All Types</option>
          <?php foreach (['Deposit','Withdrawal','Transfer','Payment','Fee'] as $t): ?>
          <option value="<?= $t ?>" <?= $type===$t?'selected':'' ?>><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="ep-label">From</label>
        <input type="date" name="date_from" class="ep-input ep-inp-noi" value="<?= ep_e($dateFrom) ?>" style="width:150px">
      </div>
      <div>
        <label class="ep-label">To</label>
        <input type="date" name="date_to"   class="ep-input ep-inp-noi" value="<?= ep_e($dateTo) ?>" style="width:150px">
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="history.php" class="ep-btn ep-btn-outline ep-btn-sm">Reset</a>
    </form>
  </div>
</div>

<div class="ep-card">
  <div class="ep-card-hdr">
    <h3>Transactions <span style="font-size:.8rem;font-weight:400;color:var(--muted)">(<?= number_format($total) ?> total)</span></h3>
  </div>
  <div class="ep-card-body p0">
    <div class="ep-table-wrap">
      <table class="ep-table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Account</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Balance After</th>
            <th>Description</th>
            <th>Status</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($records)): ?>
          <tr><td colspan="8" style="text-align:center;padding:32px;color:var(--muted)">No transactions found</td></tr>
          <?php else: ?>
          <?php foreach ($records as $r): ?>
          <?php
            $tc   = $typeColor[$r['type']] ?? '#64748b';
            $icon = $typeIcon[$r['type']]  ?? 'circle-dot';
          ?>
          <tr>
            <td><code style="font-size:.78rem;background:var(--surface);padding:2px 6px;border-radius:4px"><?= ep_e($r['reference'] ?? '—') ?></code></td>
            <td style="font-family:monospace;font-size:.82rem"><?= ep_e($r['account_number'] ?? '—') ?></td>
            <td>
              <span style="display:inline-flex;align-items:center;gap:5px;font-size:.82rem;font-weight:600;color:<?= $tc ?>">
                <i class="fa-solid fa-<?= $icon ?>"></i> <?= ep_e($r['type']) ?>
              </span>
            </td>
            <td class="fw-6" style="color:<?= $tc ?>"><?= ep_etb((float)($r['amount'] ?? 0)) ?></td>
            <td style="font-size:.83rem"><?= ep_etb((float)($r['balance_after'] ?? 0)) ?></td>
            <td style="font-size:.8rem;color:var(--muted);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= ep_e($r['description'] ?? '') ?></td>
            <td><?= ep_badge($r['status'] ?? 'Completed') ?></td>
            <td style="font-size:.8rem;color:var(--muted);white-space:nowrap"><?= ep_ago($r['created_at'] ?? '') ?></td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
