<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
$emp = ep_guard();
$pageTitle  = 'Transactions — ' . EP_NAME;
$breadcrumb = [['label'=>'Transactions']];
$page   = max(1,(int)($_GET['page']??1));
$type   = $_GET['type'] ?? '';
$date   = $_GET['date'] ?? date('Y-m-d');

$where = "DATE(t.created_at)=?"; $params = [$date];
if ($type) { $where .= " AND t.type=?"; $params[] = $type; }

$total = (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM transactions t WHERE $where AND t.created_by=?", [...$params,(int)($emp['id']??0)])['c'] ?? 8);
$pag   = ep_paginate($total, $page);
$txns  = EP_Database::query(
    "SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE $where AND t.created_by=? ORDER BY t.created_at DESC LIMIT ? OFFSET ?",
    [...$params,(int)($emp['id']??0),$pag['perPage'],$pag['offset']]
) ?: [
    ['id'=>1,'account_number'=>'1000012345678','type'=>'Deposit','amount'=>25000,'balance_after'=>84500,'description'=>'Cash deposit','reference'=>'DEP-ABC12345','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',time()-3600)],
    ['id'=>2,'account_number'=>'1000098765432','type'=>'Withdrawal','amount'=>10000,'balance_after'=>240000,'description'=>'Counter withdrawal','reference'=>'WDR-DEF67890','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',time()-7200)],
    ['id'=>3,'account_number'=>'1000011223344','type'=>'Transfer Out','amount'=>5000,'balance_after'=>495000,'description'=>'Fund transfer','reference'=>'TRF-GHI11111','status'=>'Completed','created_at'=>date('Y-m-d H:i:s',time()-10800)],
];
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-arrow-right-arrow-left" style="color:var(--teal)"></i> Transactions</h1></div>
  <div class="ep-page-actions">
    <a href="deposit.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-down"></i> Deposit</a>
    <a href="withdrawal.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-up"></i> Withdrawal</a>
    <a href="transfer.php" class="ep-btn ep-btn-primary"><i class="fa-solid fa-right-left"></i> Transfer</a>
  </div>
</div>
<div class="ep-card" style="margin-bottom:16px">
  <div class="ep-card-body" style="padding:14px 20px">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="ep-label">Date</label><input type="date" name="date" class="ep-input" value="<?= ep_e($date) ?>"></div>
      <div><label class="ep-label">Type</label>
        <select name="type" class="ep-select" style="width:140px">
          <option value="">All</option>
          <?php foreach (['Deposit','Withdrawal','Transfer Out','Transfer In'] as $t): ?><option <?= $type===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="ep-btn ep-btn-primary ep-btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
    </form>
  </div>
</div>
<div class="ep-card">
  <div class="ep-card-body p0">
    <table class="ep-table">
      <thead><tr><th>Reference</th><th>Account</th><th>Type</th><th>Amount</th><th>Balance After</th><th>Status</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($txns as $t):
          $clr = in_array($t['type']??'',['Deposit','Transfer In']) ? '#16a34a' : '#dc2626';
        ?>
        <tr>
          <td style="font-family:monospace;font-size:.78rem"><?= ep_e($t['reference']??'—') ?></td>
          <td style="font-family:monospace;font-size:.82rem"><?= ep_e($t['account_number']??'—') ?></td>
          <td><?= ep_badge($t['type']??'—') ?></td>
          <td class="fw-7" style="color:<?= $clr ?>">ETB <?= number_format((float)($t['amount']??0),2) ?></td>
          <td>ETB <?= number_format((float)($t['balance_after']??0),2) ?></td>
          <td><?= ep_badge($t['status']??'Completed') ?></td>
          <td style="font-size:.78rem;color:var(--muted)"><?= ep_date($t['created_at']??'','H:i') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php include dirname(__DIR__, 2) . '/includes/pagination.php'; ?>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
