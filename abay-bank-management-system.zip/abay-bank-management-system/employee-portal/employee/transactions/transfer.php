<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/middleware/auth.php';
require_once dirname(__DIR__, 2) . '/middleware/csrf.php';
$emp = ep_guard();
$pageTitle  = 'Fund Transfer — ' . EP_NAME;
$breadcrumb = [['label'=>'Transactions','url'=>EP_BASE_URL.'/employee/transactions/index.php'],['label'=>'Transfer']];
$empId  = (int)($emp['id'] ?? 0);
$errors = []; $success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ep_csrf_check();
    $from   = trim($_POST['from_account'] ?? '');
    $to     = trim($_POST['to_account']   ?? '');
    $amount = (float)($_POST['amount']    ?? 0);
    $desc   = trim($_POST['description']  ?? 'Fund Transfer');

    if (!$from)      $errors[] = 'Source account is required.';
    if (!$to)        $errors[] = 'Destination account is required.';
    if ($from === $to) $errors[] = 'Source and destination must differ.';
    if ($amount < 1) $errors[] = 'Minimum transfer is ETB 1.';

    if (!$errors) {
        $db = EP_Database::get();
        if ($db) {
            try {
                $db->beginTransaction();
                $src = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE",[$from]);
                $dst = EP_Database::queryOne("SELECT id,balance,status FROM accounts WHERE account_number=? FOR UPDATE",[$to]);
                if (!$src) throw new RuntimeException("Source account not found.");
                if (!$dst) throw new RuntimeException("Destination account not found.");
                if ((float)$src['balance'] < $amount) throw new RuntimeException("Insufficient balance.");
                $srcNew=(float)$src['balance']-$amount; $dstNew=(float)$dst['balance']+$amount;
                EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$srcNew,$src['id']]);
                EP_Database::execute("UPDATE accounts SET balance=?,updated_at=NOW() WHERE id=?",[$dstNew,$dst['id']]);
                $ref='TRF-'.strtoupper(substr(uniqid('',true),-8));
                EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Transfer Out',?,?,?,?,'Completed',?,NOW())",[$src['id'],$amount,$srcNew,"To $to: $desc",$ref,$empId]);
                EP_Database::execute("INSERT INTO transactions (account_id,type,amount,balance_after,description,reference,status,created_by,created_at) VALUES (?,'Transfer In',?,?,?,?,'Completed',?,NOW())",[$dst['id'],$amount,$dstNew,"From $from: $desc",$ref,$empId]);
                EP_Database::execute("INSERT INTO employee_activity_log (employee_id,description,type,created_at) VALUES (?,?,?,NOW())",[$empId,"Transfer ETB $amount from $from to $to. Ref:$ref",'transaction']);
                $db->commit();
                $success = "Transfer of ETB " . number_format($amount,2) . " from $from to $to successful. Ref: $ref";
            } catch (Throwable $e) { $db->rollBack(); $errors[] = $e->getMessage(); }
        } else {
            $ref='TRF-'.strtoupper(substr(uniqid('',true),-8));
            $success = "Demo: Transfer of ETB " . number_format($amount,2) . " recorded. Ref: $ref";
        }
    }
}
include dirname(__DIR__, 2) . '/includes/header.php';
?>
<div class="ep-page-hdr">
  <div><h1><i class="fa-solid fa-right-left" style="color:var(--teal)"></i> Fund Transfer</h1></div>
  <div class="ep-page-actions"><a href="index.php" class="ep-btn ep-btn-outline"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($success): ?><div class="ep-alert ep-alert-success"><i class="fa-solid fa-circle-check"></i><?= ep_e($success) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="ep-alert ep-alert-danger"><i class="fa-solid fa-circle-xmark"></i><?= ep_e($e) ?></div><?php endforeach; ?>
<div style="max-width:540px">
  <div class="ep-card">
    <div class="ep-card-hdr"><h3>Transfer Details</h3></div>
    <div class="ep-card-body">
      <form method="POST">
        <?= ep_csrf_field() ?>
        <div class="ep-form-group"><label class="ep-label">From Account <span class="req">*</span></label>
          <div class="ep-inp-wrap"><i class="fa-solid fa-building-columns ep-inp-ic"></i><input type="text" name="from_account" class="ep-input" placeholder="Source account number" required></div></div>
        <div class="ep-form-group"><label class="ep-label">To Account <span class="req">*</span></label>
          <div class="ep-inp-wrap"><i class="fa-solid fa-building-columns ep-inp-ic"></i><input type="text" name="to_account" class="ep-input" placeholder="Destination account number" required></div></div>
        <div class="ep-form-group"><label class="ep-label">Amount (ETB) <span class="req">*</span></label>
          <input type="number" name="amount" class="ep-input ep-inp-noi" min="1" step="0.01" placeholder="0.00" required></div>
        <div class="ep-form-group"><label class="ep-label">Description</label>
          <input type="text" name="description" class="ep-input ep-inp-noi" value="Fund Transfer"></div>
        <button type="submit" class="ep-btn ep-btn-primary" style="width:100%"><i class="fa-solid fa-right-left"></i> Process Transfer</button>
      </form>
    </div>
  </div>
</div>
<?php include dirname(__DIR__, 2) . '/includes/footer.php'; ?>
