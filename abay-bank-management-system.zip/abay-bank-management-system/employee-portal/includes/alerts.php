<?php
/** Employee Portal — Flash Alert Display */
$types = ['success','danger','warning','info'];
foreach ($types as $t) {
    $msg = ep_get_flash($t);
    if ($msg): ?>
    <div class="ep-alert ep-alert-<?= $t ?>" style="margin-bottom:16px">
      <i class="fa-solid <?= ['success'=>'fa-circle-check','danger'=>'fa-circle-xmark','warning'=>'fa-triangle-exclamation','info'=>'fa-circle-info'][$t] ?>"></i>
      <div><?= htmlspecialchars($msg) ?></div>
    </div>
    <?php endif;
}
