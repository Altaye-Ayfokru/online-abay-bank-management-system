<?php /** Employee Portal — Footer */ ?>
</div><!-- end ep-main -->

<script src="<?= EP_ASSET_URL ?>/js/app.js"></script>
<?php if (!empty($needsCharts)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= EP_ASSET_URL ?>/js/charts.js"></script>
<?php endif; ?>
<?php if (!empty($extraJs)): foreach ((array)$extraJs as $js): ?>
<script src="<?= htmlspecialchars($js) ?>"></script>
<?php endforeach; endif; ?>
<?php if (!empty($pageScript)): ?>
<script><?= $pageScript ?></script>
<?php endif; ?>
<!-- Dashboard JS always loaded for clock -->
<script src="<?= EP_ASSET_URL ?>/js/dashboard.js"></script>
</body>
</html>
