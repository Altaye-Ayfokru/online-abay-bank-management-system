<?php
/**
 * Abay Bank — Employee Portal Helper Functions
 */

/** Format currency in ETB */
function ep_etb(float $n): string {
    return 'ETB ' . number_format($n, 2);
}

/** Format integer with commas */
function ep_num(int $n): string {
    return number_format($n);
}

/** HTML-escape a value */
function ep_e(mixed $v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Redirect helper */
function ep_redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

/** Set flash message */
function ep_flash(string $type, string $msg): void {
    $_SESSION['ep_flash_' . $type] = $msg;
}

/** Get and clear flash message */
function ep_get_flash(string $type): ?string {
    $msg = $_SESSION['ep_flash_' . $type] ?? null;
    unset($_SESSION['ep_flash_' . $type]);
    return $msg;
}

/** Get employee avatar URL or initial */
function ep_avatar(array $emp): string {
    if (!empty($emp['avatar']) && file_exists(EP_BASE_PATH . '/uploads/employee-profiles/' . basename($emp['avatar']))) {
        return EP_BASE_URL . '/uploads/employee-profiles/' . basename($emp['avatar']);
    }
    return '';
}

function ep_initials(array $emp): string {
    $n = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
    if (!$n) $n = $emp['username'] ?? '?';
    $parts = explode(' ', $n);
    return strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}

function ep_full_name(array $emp): string {
    return trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) ?: ($emp['username'] ?? 'Employee');
}

/** Pagination helper */
function ep_paginate(int $total, int $page, int $perPage = EP_PER_PAGE): array {
    $pages = (int)ceil($total / $perPage);
    return [
        'total'   => $total,
        'page'    => max(1, min($page, max(1, $pages))),
        'pages'   => $pages,
        'perPage' => $perPage,
        'offset'  => (max(1, $page) - 1) * $perPage,
    ];
}

/** Badge HTML by status */
function ep_badge(string $status): string {
    $map = [
        'Present'   => 'success', 'Active'     => 'success', 'Approved'  => 'success',
        'Completed' => 'success', 'Verified'   => 'success', 'Paid'      => 'success',
        'Late'      => 'warning', 'Pending'    => 'warning', 'Review'    => 'warning',
        'In Progress'=>'warning', 'Processing' => 'warning',
        'Absent'    => 'danger',  'Rejected'   => 'danger',  'Overdue'   => 'danger',
        'Blocked'   => 'danger',  'Bounced'    => 'danger',
        'On Leave'  => 'info',    'Inactive'   => 'secondary',
    ];
    $cls = $map[$status] ?? 'secondary';
    return '<span class="ep-badge ep-badge-' . $cls . '">' . ep_e($status) . '</span>';
}

/** Format date */
function ep_date(string $date, string $fmt = 'd M Y'): string {
    if (!$date || $date === '0000-00-00') return '—';
    try { return (new DateTime($date))->format($fmt); } catch (Throwable) { return $date; }
}

/** Time ago */
function ep_ago(string $datetime): string {
    try {
        $diff = time() - (new DateTime($datetime))->getTimestamp();
        if ($diff < 60)   return 'Just now';
        if ($diff < 3600) return (int)($diff/60)   . ' min ago';
        if ($diff < 86400)return (int)($diff/3600) . ' hr ago';
        if ($diff < 604800) return (int)($diff/86400) . ' days ago';
        return ep_date($datetime);
    } catch (Throwable) { return $datetime; }
}

/** Demo employee data when DB is offline */
function ep_demo_employees(): array {
    return [
        ['id'=>1,'employee_number'=>'EMP-000001','first_name'=>'Abebe','last_name'=>'Girma','username'=>'abebe.girma','email'=>'abebe.girma@abaybank.com','phone'=>'+251 911 234 567','role'=>'Teller','dept_name'=>'Operations','branch_name'=>'Head Office','position'=>'Senior Teller','basic_salary'=>18500,'status'=>'Active','hire_date'=>'2019-03-01','avatar'=>null],
        ['id'=>2,'employee_number'=>'EMP-000002','first_name'=>'Tigist','last_name'=>'Haile','username'=>'tigist.haile','email'=>'tigist.haile@abaybank.com','phone'=>'+251 912 345 678','role'=>'Loan Officer','dept_name'=>'Loans','branch_name'=>'Bole Branch','position'=>'Loan Officer','basic_salary'=>22000,'status'=>'Active','hire_date'=>'2020-07-15','avatar'=>null],
        ['id'=>3,'employee_number'=>'EMP-000003','first_name'=>'Samuel','last_name'=>'Bekele','username'=>'samuel.bekele','email'=>'samuel.bekele@abaybank.com','phone'=>'+251 913 456 789','role'=>'IT Staff','dept_name'=>'IT','branch_name'=>'Head Office','position'=>'IT Technician','basic_salary'=>25000,'status'=>'Active','hire_date'=>'2021-01-10','avatar'=>null],
        ['id'=>4,'employee_number'=>'EMP-000004','first_name'=>'Meron','last_name'=>'Tesfaye','username'=>'meron.tesfaye','email'=>'meron.tesfaye@abaybank.com','phone'=>'+251 914 567 890','role'=>'Customer Service','dept_name'=>'Customer Service','branch_name'=>'Alem Ketema Branch','position'=>'CS Officer','basic_salary'=>17000,'status'=>'Active','hire_date'=>'2022-04-05','avatar'=>null],
        ['id'=>4,'employee_number'=>'EMP-000004','first_name'=>'Meron','last_name'=>'Tesfaye','username'=>'meron.tesfaye','email'=>'meron.tesfaye@abaybank.com','phone'=>'+251 914 567 890','role'=>'Customer Service','dept_name'=>'Customer Service','branch_name'=>'Piassa Branch','position'=>'CS Officer','basic_salary'=>17000,'status'=>'Active','hire_date'=>'2022-04-05','avatar'=>null],
    ];
}

/** Check if a file upload is valid image */
function ep_validate_image(array $file): array {
    if ($file['error'] !== UPLOAD_ERR_OK) return ['ok'=>false,'msg'=>'Upload error: code '.$file['error']];
    if ($file['size'] > EP_MAX_FILE_SIZE)  return ['ok'=>false,'msg'=>'File too large. Max 5 MB.'];
    if (!in_array($file['type'], EP_ALLOWED_IMAGES)) return ['ok'=>false,'msg'=>'Only JPG, PNG, WebP images allowed.'];
    return ['ok'=>true,'msg'=>''];
}
