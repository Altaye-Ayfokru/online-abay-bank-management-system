<?php

/**
 * Employee Portal — HTML Head + Topbar
 * Include at top of every protected page.
 * Expects: $pageTitle (string), $emp (array from ep_guard())
 */
$pageTitle = $pageTitle ?? 'Employee Portal — Abay Bank';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <meta name="ep-base-url" content="<?= EP_BASE_URL ?>">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= EP_ASSET_URL ?>/css/style.css">
  <link rel="stylesheet" href="<?= EP_ASSET_URL ?>/css/sidebar.css">
  <link rel="stylesheet" href="<?= EP_ASSET_URL ?>/css/dashboard.css">
  <?php if (!empty($extraCss)) foreach ((array)$extraCss as $css): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars($css) ?>">
  <?php endforeach; ?>
</head>

<body>

  <!-- Sidebar backdrop (mobile) -->
  <div class="ep-sb-backdrop" id="ep-sb-backdrop"></div>

  <?php include __DIR__ . '/sidebar.php'; ?>

  <!-- Topbar -->
  <header class="ep-topbar" id="ep-topbar">
    <div class="ep-topbar-left">
      <button class="ep-hamburger" id="ep-hamburger" aria-label="Toggle menu">
        <i class="fa-solid fa-bars"></i>
      </button>
      <div class="ep-breadcrumb">
        <a href="<?= EP_BASE_URL ?>/employee/dashboard.php"><i class="fa-solid fa-house" style="font-size:.75rem"></i></a>
        <?php if (!empty($breadcrumb)): ?>
          <?php foreach ((array)$breadcrumb as $bc): ?>
            <span>/</span>
            <?php if (isset($bc['url'])): ?>
              <a href="<?= htmlspecialchars($bc['url']) ?>"><?= htmlspecialchars($bc['label']) ?></a>
            <?php else: ?>
              <span style="color:#1e293b;font-weight:600"><?= htmlspecialchars($bc['label'] ?? $bc) ?></span>
            <?php endif; ?>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
    <div class="ep-topbar-right">
      <!-- Global search -->
      <div style="position:relative;display:flex;align-items:center">
        <i class="fa-solid fa-magnifying-glass" style="position:absolute;left:10px;color:#94a3b8;font-size:.8rem;pointer-events:none"></i>
        <input type="text" id="ep-global-search" placeholder="Search customers…"
          style="padding:8px 12px 8px 32px;border:1.5px solid #e2e8f0;border-radius:20px;font-size:.82rem;width:200px;outline:none;font-family:inherit;background:#f8fafc"
          onfocus="this.style.borderColor='#007A8A';this.style.width='240px'"
          onblur="this.style.borderColor='#e2e8f0';this.style.width='200px'">
      </div>
      <!-- Notifications -->
      <a href="<?= EP_BASE_URL ?>/employee/notifications/index.php" class="ep-tb-btn" title="Notifications">
        <i class="fa-solid fa-bell"></i>
        <?php
        $unreadNotifs = EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [$emp['id'] ?? 0])['c'] ?? 0;
        if ($unreadNotifs > 0): ?>
          <span class="ep-notif-dot"></span>
        <?php endif; ?>
      </a>
      <!-- Clock -->
      <span id="ep-clock" style="font-size:.78rem;color:#64748b;font-weight:600;font-variant-numeric:tabular-nums;min-width:64px"></span>
      <!-- User -->
      <a href="<?= EP_BASE_URL ?>/employee/profile/index.php" class="ep-tb-user">
        <?php
        $avatarUrl = ep_avatar($emp);
        $initials  = ep_initials($emp);
        ?>
        <div class="ep-avatar ep-av-sm" style="background:linear-gradient(135deg,#1B3A5C,#007A8A);color:#fff;overflow:hidden;border-radius:50%;flex-shrink:0">
          <?php if ($avatarUrl): ?>
            <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= htmlspecialchars(ep_full_name($emp)) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
          <?php else: ?>
            <span style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
          <?php endif; ?>
        </div>
        <div style="display:none" class="d-md-block">
          <div class="ep-tb-uname"><?= htmlspecialchars(ep_full_name($emp)) ?></div>
          <div class="ep-tb-urole"><?= htmlspecialchars($emp['role'] ?? '') ?></div>
        </div>
      </a>
      <a href="<?= EP_BASE_URL ?>/auth/logout.php" class="ep-btn ep-btn-ghost ep-btn-sm" title="Sign out">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
      </a>
    </div>
  </header>

  <!-- Page wrapper -->
  <div class="ep-main">

    <?php include __DIR__ . '/alerts.php'; ?>