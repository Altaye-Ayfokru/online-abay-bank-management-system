<?php
/**
 * Employee Portal — Pagination Component
 * Expects $pag array from ep_paginate()
 */
if (!isset($pag) || $pag['pages'] <= 1) return;
$base = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
$params = $_GET;
function ep_page_url(array $params, int $page, string $base): string {
    $params['page'] = $page;
    return $base . '?' . http_build_query($params);
}
?>
<div style="display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-top:1px solid #e2e8f0;font-size:.83rem">
  <span style="color:#64748b">
    Showing <?= number_format(($pag['page']-1)*$pag['perPage']+1) ?>–<?= number_format(min($pag['page']*$pag['perPage'],$pag['total'])) ?> of <?= number_format($pag['total']) ?>
  </span>
  <div style="display:flex;gap:4px">
    <?php if ($pag['page'] > 1): ?>
    <a href="<?= ep_page_url($params,$pag['page']-1,$base) ?>" class="ep-btn ep-btn-outline ep-btn-sm">&larr; Prev</a>
    <?php endif; ?>
    <?php
    $start = max(1, $pag['page'] - 2);
    $end   = min($pag['pages'], $pag['page'] + 2);
    for ($p = $start; $p <= $end; $p++):
        $active = $p === $pag['page'] ? 'background:#1B3A5C;color:#fff;border-color:#1B3A5C' : '';
    ?>
    <a href="<?= ep_page_url($params,$p,$base) ?>" class="ep-btn ep-btn-outline ep-btn-sm" style="<?= $active ?>"><?= $p ?></a>
    <?php endfor; ?>
    <?php if ($pag['page'] < $pag['pages']): ?>
    <a href="<?= ep_page_url($params,$pag['page']+1,$base) ?>" class="ep-btn ep-btn-outline ep-btn-sm">Next &rarr;</a>
    <?php endif; ?>
  </div>
</div>
