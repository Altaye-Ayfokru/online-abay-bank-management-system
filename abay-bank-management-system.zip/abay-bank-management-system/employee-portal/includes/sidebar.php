<?php

/**
 * Employee Portal — Sidebar Navigation
 * Expects $emp array from ep_guard()
 */
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$isActive = function (string $path) use ($currentPath): string {
  return str_contains($currentPath, $path) ? ' active' : '';
};
$avatarUrl = ep_avatar($emp ?? []);
$initials  = ep_initials($emp ?? []);
$fullName  = ep_full_name($emp ?? []);
$role      = ($emp ?? [])['role'] ?? 'Staff';
?>
<aside class="ep-sidebar" id="ep-sidebar">

  <div class="ep-sb-brand">
    <div class="ep-sb-logo">
      <span class="ep-lb1"></span><span class="ep-lb2"></span>
      <span class="ep-lb3"></span><span class="ep-lb4"></span>
    </div>
    <div>
      <div class="ep-sb-name">Abay Bank S.C.</div>
      <div class="ep-sb-portal">Employee Portal</div>
    </div>
  </div>

  <div class="ep-sb-scroll">

    <div class="ep-sb-section">Main</div>
    <a href="<?= EP_BASE_URL ?>/employee/dashboard.php" class="ep-sb-link<?= $isActive('/employee/dashboard') ?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    <a href="<?= EP_BASE_URL ?>/employee/profile/index.php" class="ep-sb-link<?= $isActive('/employee/profile') ?>"><i class="fa-solid fa-user-circle"></i> My Profile</a>

    <div class="ep-sb-section">HR & Attendance</div>
    <a href="<?= EP_BASE_URL ?>/employee/attendance/index.php" class="ep-sb-link<?= $isActive('/employee/attendance') ?>"><i class="fa-solid fa-calendar-check"></i> Attendance</a>
    <a href="<?= EP_BASE_URL ?>/employee/leave/index.php" class="ep-sb-link<?= $isActive('/employee/leave') ?>"><i class="fa-solid fa-calendar-xmark"></i> Leave</a>
    <a href="<?= EP_BASE_URL ?>/employee/payroll/index.php" class="ep-sb-link<?= $isActive('/employee/payroll') ?>"><i class="fa-solid fa-receipt"></i> Payroll</a>
    <a href="<?= EP_BASE_URL ?>/employee/performance/index.php" class="ep-sb-link<?= $isActive('/employee/performance') ?>"><i class="fa-solid fa-chart-bar"></i> Performance</a>
    <a href="<?= EP_BASE_URL ?>/employee/training/index.php" class="ep-sb-link<?= $isActive('/employee/training') ?>"><i class="fa-solid fa-graduation-cap"></i> Training</a>

    <div class="ep-sb-section">Banking Operations</div>
    <a href="<?= EP_BASE_URL ?>/employee/customers/index.php" class="ep-sb-link<?= $isActive('/employee/customers') ?>"><i class="fa-solid fa-users"></i> Customers</a>
    <a href="<?= EP_BASE_URL ?>/employee/accounts/index.php" class="ep-sb-link<?= $isActive('/employee/accounts') ?>"><i class="fa-solid fa-building-columns"></i> Accounts</a>
    <a href="<?= EP_BASE_URL ?>/employee/transactions/index.php" class="ep-sb-link<?= $isActive('/employee/transactions') ?>"><i class="fa-solid fa-arrow-right-arrow-left"></i> Transactions</a>
    <a href="<?= EP_BASE_URL ?>/employee/loans/index.php" class="ep-sb-link<?= $isActive('/employee/loans') ?>"><i class="fa-solid fa-file-invoice-dollar"></i> Loans</a>
    <a href="<?= EP_BASE_URL ?>/employee/kyc/index.php" class="ep-sb-link<?= $isActive('/employee/kyc') ?>"><i class="fa-solid fa-id-card"></i> KYC
      <?php
      $pendingKyc = EP_Database::queryOne("SELECT COUNT(*) AS c FROM customers WHERE kyc_status='Pending'")['c'] ?? 0;
      if ($pendingKyc > 0): ?><span class="ep-sb-badge"><?= $pendingKyc ?></span><?php endif; ?>
    </a>

    <div class="ep-sb-section">Work</div>
    <a href="<?= EP_BASE_URL ?>/employee/tasks/index.php" class="ep-sb-link<?= $isActive('/employee/tasks') ?>"><i class="fa-solid fa-list-check"></i> My Tasks
      <?php
      $pendingTasks = EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_tasks WHERE assigned_to=? AND status='Pending'", [$emp['id'] ?? 0])['c'] ?? 3;
      if ($pendingTasks > 0): ?><span class="ep-sb-badge"><?= $pendingTasks ?></span><?php endif; ?>
    </a>
    <a href="<?= EP_BASE_URL ?>/employee/complaints/index.php" class="ep-sb-link<?= $isActive('/employee/complaints') ?>"><i class="fa-solid fa-headset"></i> Complaints</a>
    <a href="<?= EP_BASE_URL ?>/employee/appointments/index.php" class="ep-sb-link<?= $isActive('/employee/appointments') ?>"><i class="fa-solid fa-calendar-days"></i> Appointments</a>

    <div class="ep-sb-section">Info</div>
    <a href="<?= EP_BASE_URL ?>/employee/notifications/index.php" class="ep-sb-link<?= $isActive('/employee/notifications') ?>"><i class="fa-solid fa-bell"></i> Notifications
      <?php
      $unread = EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [$emp['id'] ?? 0])['c'] ?? 0;
      if ($unread > 0): ?><span class="ep-sb-badge"><?= $unread ?></span><?php endif; ?>
    </a>
    <a href="<?= EP_BASE_URL ?>/employee/messages/index.php" class="ep-sb-link<?= $isActive('/employee/messages') ?>"><i class="fa-solid fa-envelope"></i> Messages</a>
    <a href="<?= EP_BASE_URL ?>/employee/reports/index.php" class="ep-sb-link<?= $isActive('/employee/reports') ?>"><i class="fa-solid fa-chart-pie"></i> Reports</a>
    <a href="<?= EP_BASE_URL ?>/employee/documents/index.php" class="ep-sb-link<?= $isActive('/employee/documents') ?>"><i class="fa-solid fa-folder-open"></i> Documents</a>
    <a href="<?= EP_BASE_URL ?>/employee/branch/index.php" class="ep-sb-link<?= $isActive('/employee/branch') ?>"><i class="fa-solid fa-building"></i> My Branch</a>
    <a href="<?= EP_BASE_URL ?>/employee/settings/index.php" class="ep-sb-link<?= $isActive('/employee/settings') ?>"><i class="fa-solid fa-gear"></i> Settings</a>

  </div>

  <div class="ep-sb-footer">
    <div class="ep-sb-avatar" style="overflow:hidden;border-radius:50%">
      <?php if ($avatarUrl): ?>
        <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= htmlspecialchars($fullName) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
      <?php else: ?>
        <span style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-weight:800"><?= $initials ?></span>
      <?php endif; ?>
    </div>
    <div style="flex:1;min-width:0;overflow:hidden">
      <div class="ep-sb-uname"><?= htmlspecialchars($fullName) ?></div>
      <div class="ep-sb-urole"><?= htmlspecialchars($role) ?></div>
    </div>
    <a href="<?= EP_BASE_URL ?>/auth/logout.php" class="ep-sb-logout" title="Sign Out">
      <i class="fa-solid fa-arrow-right-from-bracket"></i>
    </a>
  </div>

</aside>