<?php
/**
 * Employee Portal — Root Entry
 * Redirects to dashboard if logged in, else to login.
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/middleware/auth.php';

if (ep_is_logged_in()) {
    header('Location: ' . EP_BASE_URL . '/employee/dashboard.php'); exit;
}
header('Location: ' . EP_BASE_URL . '/auth/login.php'); exit;
