<?php
/**
 * Employee Portal — Auth Middleware
 * Require this at top of any protected page.
 * Usage: require_once __DIR__ . '/../../middleware/auth.php';
 */
require_once dirname(__DIR__) . '/config/config.php';

function ep_guard(string $redirect = '/employee-portal/auth/login.php'): array {
    if (empty($_SESSION['ep_logged_in']) || empty($_SESSION['ep_employee'])) {
        $_SESSION['ep_flash_error'] = 'Please sign in to access the Employee Portal.';
        $_SESSION['ep_redirect_after'] = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: ' . EP_BASE_URL . '/auth/login.php');
        exit;
    }
    // Timeout check
    if (!empty($_SESSION['ep_last_activity'])) {
        if ((time() - $_SESSION['ep_last_activity']) > EP_SESSION_TIMEOUT) {
            ep_logout();
            header('Location: ' . EP_BASE_URL . '/auth/login.php?reason=timeout');
            exit;
        }
    }
    $_SESSION['ep_last_activity'] = time();
    return $_SESSION['ep_employee'];
}

function ep_login_employee(array $employee): void {
    $_SESSION['ep_logged_in']    = true;
    $_SESSION['ep_employee']     = $employee;
    $_SESSION['ep_login_time']   = time();
    $_SESSION['ep_last_activity']= time();
}

function ep_logout(): void {
    unset($_SESSION['ep_logged_in'], $_SESSION['ep_employee'],
          $_SESSION['ep_login_time'], $_SESSION['ep_last_activity']);
}

function ep_is_logged_in(): bool {
    return !empty($_SESSION['ep_logged_in']) && !empty($_SESSION['ep_employee']);
}

function ep_employee(): ?array {
    return $_SESSION['ep_employee'] ?? null;
}
