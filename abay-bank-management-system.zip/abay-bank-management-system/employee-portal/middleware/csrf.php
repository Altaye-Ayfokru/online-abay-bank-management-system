<?php
/**
 * Employee Portal — CSRF Protection
 */

function ep_csrf_token(): string {
    if (empty($_SESSION['ep_csrf'])) {
        $_SESSION['ep_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['ep_csrf'];
}

function ep_csrf_field(): string {
    return '<input type="hidden" name="_ep_csrf" value="' . htmlspecialchars(ep_csrf_token()) . '">';
}

function ep_verify_csrf(): bool {
    $token = $_POST['_ep_csrf'] ?? $_SERVER['HTTP_X_EP_CSRF'] ?? '';
    return hash_equals($_SESSION['ep_csrf'] ?? '', $token);
}

function ep_csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !ep_verify_csrf()) {
        http_response_code(403);
        die('<h1>403 — Invalid CSRF Token</h1><p><a href="javascript:history.back()">Go back</a></p>');
    }
}
