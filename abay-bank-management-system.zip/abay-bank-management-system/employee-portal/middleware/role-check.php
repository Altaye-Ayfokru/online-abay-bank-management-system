<?php
/**
 * Employee Portal — Role Check Middleware
 */

function ep_require_role(string|array $roles): void {
    $emp  = ep_employee();
    if (!$emp) { header('Location: ' . EP_BASE_URL . '/auth/login.php'); exit; }
    $allowed = is_array($roles) ? $roles : [$roles];
    if (!in_array($emp['role'] ?? '', $allowed, true)) {
        http_response_code(403);
        include dirname(__DIR__) . '/includes/header.php';
        echo '<div class="ep-alert ep-alert-danger" style="margin:40px auto;max-width:500px;text-align:center">
            <i class="fa-solid fa-ban" style="font-size:2rem;margin-bottom:12px;display:block"></i>
            <h3>Access Denied</h3>
            <p>Your role does not have permission to access this page.</p>
            <a href="' . EP_BASE_URL . '/employee/dashboard.php" class="ep-btn ep-btn-primary" style="margin-top:16px">Back to Dashboard</a>
        </div>';
        include dirname(__DIR__) . '/includes/footer.php';
        exit;
    }
}

function ep_can(string $role): bool {
    $emp = ep_employee();
    return ($emp['role'] ?? '') === $role;
}

function ep_is_manager(): bool {
    return ep_can('Branch Manager') || ep_can('HR Officer');
}
