<?php
/**
 * Employee Portal — Session Check Middleware
 * Soft check — does not redirect, just returns status.
 */
require_once dirname(__DIR__) . '/config/config.php';

function ep_session_status(): array {
    $loggedIn = !empty($_SESSION['ep_logged_in']) && !empty($_SESSION['ep_employee']);
    $expired  = false;
    if ($loggedIn && isset($_SESSION['ep_last_activity'])) {
        $expired = (time() - $_SESSION['ep_last_activity']) > EP_SESSION_TIMEOUT;
    }
    return [
        'logged_in' => $loggedIn && !$expired,
        'expired'   => $expired,
        'employee'  => $_SESSION['ep_employee'] ?? null,
    ];
}
