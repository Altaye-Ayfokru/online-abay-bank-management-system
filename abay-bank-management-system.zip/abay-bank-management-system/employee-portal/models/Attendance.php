<?php
class Attendance {
    public static function today(int $empId): ?array {
        return EP_Database::queryOne("SELECT * FROM attendance WHERE employee_id=? AND date=CURDATE()", [$empId]);
    }
    public static function insert(int $empId, string $date, array $data): bool {
        return EP_Database::execute("INSERT INTO attendance (employee_id,date,check_in,check_out,hours_worked,status,note) VALUES (?,?,?,?,?,?,?)", [$empId,$date,$data['check_in']??null,$data['check_out']??null,$data['hours_worked']??null,$data['status']??'Present',$data['note']??null]);
    }
    public static function update(int $empId, string $date, array $data): bool {
        $sets=[]; $vals=[];
        foreach ($data as $k=>$v) { $sets[]="$k=?"; $vals[]=$v; }
        $vals[]=$empId; $vals[]=$date;
        return EP_Database::execute("UPDATE attendance SET ".implode(',',$sets)." WHERE employee_id=? AND date=?", $vals);
    }
    public static function monthSummary(int $empId, int $month, int $year): array {
        return EP_Database::queryOne("SELECT SUM(status='Present') AS present, SUM(status='Late') AS late, SUM(status='Absent') AS absent FROM attendance WHERE employee_id=? AND MONTH(date)=? AND YEAR(date)=?", [$empId,$month,$year]) ?? ['present'=>0,'late'=>0,'absent'=>0];
    }
}
