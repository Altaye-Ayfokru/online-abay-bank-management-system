<?php
/**
 * Employee Model
 */
class Employee {
    public static function find(int $id): ?array {
        return EP_Database::queryOne(
            "SELECT e.*, d.name AS dept_name, b.branch_name FROM employees e
             LEFT JOIN departments d ON d.id=e.department_id
             LEFT JOIN branches b ON b.id=e.branch_id WHERE e.id=?", [$id]);
    }
    public static function findByNumber(string $number): ?array {
        return EP_Database::queryOne("SELECT * FROM employees WHERE employee_number=? AND status='Active' LIMIT 1", [$number]);
    }
    public static function update(int $id, array $fields): bool {
        $sets=[]; $vals=[];
        foreach ($fields as $k=>$v) { $sets[]="$k=?"; $vals[]=$v; }
        if (!$sets) return false;
        $vals[] = $id;
        return EP_Database::execute("UPDATE employees SET ".implode(',',$sets).", updated_at=NOW() WHERE id=?", $vals);
    }
    public static function all(int $limit=100, int $offset=0): array {
        return EP_Database::query("SELECT e.*, d.name AS dept_name, b.branch_name FROM employees e LEFT JOIN departments d ON d.id=e.department_id LEFT JOIN branches b ON b.id=e.branch_id WHERE e.status='Active' ORDER BY e.first_name LIMIT ? OFFSET ?", [$limit,$offset]);
    }
}
