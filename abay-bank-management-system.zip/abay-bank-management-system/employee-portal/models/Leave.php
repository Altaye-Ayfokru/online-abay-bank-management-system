<?php
class Leave {
    public static function balance(int $empId): array {
        return EP_Database::queryOne("SELECT * FROM leave_balances WHERE employee_id=? AND year=YEAR(CURDATE())", [$empId])
            ?? ['annual_total'=>18,'annual_remaining'=>12,'sick_total'=>10,'sick_remaining'=>8,'emergency_total'=>3,'emergency_remaining'=>3];
    }
    public static function all(int $empId, int $limit=20): array {
        return EP_Database::query("SELECT * FROM leave_requests WHERE employee_id=? ORDER BY created_at DESC LIMIT ?", [$empId,$limit]);
    }
    public static function find(int $id): ?array {
        return EP_Database::queryOne("SELECT * FROM leave_requests WHERE id=?", [$id]);
    }
    public static function pending(int $empId): array {
        return EP_Database::query("SELECT * FROM leave_requests WHERE employee_id=? AND status='Pending' ORDER BY created_at DESC", [$empId]);
    }
}
