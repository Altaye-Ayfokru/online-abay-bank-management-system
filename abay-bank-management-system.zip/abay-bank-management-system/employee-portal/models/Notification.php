<?php
class Notification {
    public static function unreadCount(int $empId): int {
        return (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_notifications WHERE employee_id=? AND is_read=0", [$empId])['c'] ?? 0);
    }
    public static function all(int $empId, bool $unreadOnly=false, int $limit=20): array {
        $sql = "SELECT * FROM employee_notifications WHERE employee_id=?" . ($unreadOnly?" AND is_read=0":"") . " ORDER BY created_at DESC LIMIT ?";
        return EP_Database::query($sql, [$empId,$limit]) ?: [];
    }
    public static function markRead(int $id, int $empId): bool {
        return EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE id=? AND employee_id=?", [$id,$empId]);
    }
    public static function markAllRead(int $empId): bool {
        return EP_Database::execute("UPDATE employee_notifications SET is_read=1 WHERE employee_id=?", [$empId]);
    }
}
