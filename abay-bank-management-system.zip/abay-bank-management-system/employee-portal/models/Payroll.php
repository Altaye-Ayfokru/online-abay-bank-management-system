<?php

/**
 * Payroll Model
 * Matches the actual abay_bank.payroll table columns:
 * pay_period, basic_salary, transport_allow, housing_allow,
 * gross_salary, income_tax, pension, total_deductions, net_salary,
 * paid_date, status
 */
class Payroll
{

  public static function latest(int $empId): ?array
  {
    return EP_Database::queryOne(
      "SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT 1",
      [$empId]
    );
  }

  public static function all(int $empId, int $limit = 12): array
  {
    return EP_Database::query(
      "SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_period DESC LIMIT ?",
      [$empId, $limit]
    );
  }

  public static function find(int $id, int $empId): ?array
  {
    return EP_Database::queryOne(
      "SELECT * FROM payroll WHERE id=? AND employee_id=?",
      [$id, $empId]
    );
  }

  public static function grossSalary(array $p): float
  {
    return (float)($p['basic_salary']    ?? 0)
      + (float)($p['transport_allow'] ?? $p['transport_allowance'] ?? 0)
      + (float)($p['housing_allow']   ?? $p['housing_allowance']   ?? 0)
      + (float)($p['other_allowances'] ?? $p['overtime_pay']        ?? 0);
  }

  public static function totalDeductions(array $p): float
  {
    return (float)($p['income_tax']        ?? 0)
      + (float)($p['pension']           ?? $p['pension_employee'] ?? 0)
      + (float)($p['other_deductions']  ?? 0);
  }

  /** Format pay_period (YYYY-MM) as readable month */
  public static function periodLabel(string $period): string
  {
    $parts = explode('-', $period);
    if (count($parts) === 2) {
      return date('F Y', mktime(0, 0, 0, (int)$parts[1], 1, (int)$parts[0]));
    }
    return $period;
  }
}
