<?php
class Task {
    public static function all(int $empId, string $status='', string $priority='', int $limit=20, int $offset=0): array {
        $where="assigned_to=?"; $p=[$empId];
        if ($status)   { $where.=" AND status=?";   $p[]=$status; }
        if ($priority) { $where.=" AND priority=?"; $p[]=$priority; }
        return EP_Database::query("SELECT t.*,e.first_name AS assigned_by_name FROM employee_tasks t LEFT JOIN employees e ON e.id=t.assigned_by WHERE $where ORDER BY FIELD(priority,'Critical','High','Medium','Low'),due_date ASC LIMIT ? OFFSET ?", [...$p,$limit,$offset]);
    }
    public static function find(int $id, int $empId): ?array {
        return EP_Database::queryOne("SELECT * FROM employee_tasks WHERE id=? AND assigned_to=?", [$id,$empId]);
    }
    public static function updateStatus(int $id, int $empId, string $status, string $notes=''): bool {
        $sql = "UPDATE employee_tasks SET status=?" . ($status==='Completed' ? ",completed_at=NOW(),completion_notes=?" : "") . " WHERE id=? AND assigned_to=?";
        $params = $status==='Completed' ? [$status,$notes,$id,$empId] : [$status,$id,$empId];
        return EP_Database::execute($sql, $params);
    }
    public static function pendingCount(int $empId): int {
        return (int)(EP_Database::queryOne("SELECT COUNT(*) AS c FROM employee_tasks WHERE assigned_to=? AND status IN('Pending','In Progress')", [$empId])['c'] ?? 0);
    }
}
