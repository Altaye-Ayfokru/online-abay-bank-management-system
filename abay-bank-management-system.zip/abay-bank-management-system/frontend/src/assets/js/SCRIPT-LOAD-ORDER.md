# Script Loading Order for All Pages

**CRITICAL:** Scripts MUST be loaded in this exact order for the app to work correctly.

## Standard Order (ALL pages except login/auth pages):

```html
<!-- 1. PATH RESOLVER (MUST BE FIRST!) -->
<script src="../../src/assets/js/path-resolver.js"></script>

<!-- 2. Core Utilities -->
<script src="../../src/assets/js/helpers.js"></script>
<script src="../../src/assets/js/validation.js"></script>

<!-- 3. Authentication -->
<script src="../../src/assets/js/auth.js"></script>

<!-- 4. Features -->
<script src="../../src/assets/js/notifications.js"></script>
<script src="../../src/assets/js/search.js"></script>

<!-- 5. UI Shell (builds navbar/sidebar) -->
<script src="../../src/assets/js/_navbar.js"></script>

<!-- 6. App Init -->
<script src="../../src/assets/js/app.js"></script>

<!-- 7. Page-Specific (optional) -->
<script src="../../src/assets/js/dashboard.js"></script>
<!-- OR accounts.js, loans.js, etc. -->

<!-- 8. Inline page scripts (optional) -->
<script>
  document.addEventListener('DOMContentLoaded', () => {
    Auth.guard(); // Session check
    // Page-specific init code here
  });
</script>
```

## Authentication Pages (login, register, forgot-password, reset-password):

```html
<!-- 1. PATH RESOLVER (MUST BE FIRST!) -->
<script src="../../src/assets/js/path-resolver.js"></script>

<!-- 2. Core Utilities -->
<script src="../../src/assets/js/helpers.js"></script>
<script src="../../src/assets/js/validation.js"></script>

<!-- 3. Authentication -->
<script src="../../src/assets/js/auth.js"></script>

<!-- 4. App Init -->
<script src="../../src/assets/js/app.js"></script>

<!-- No _navbar.js, notifications.js, search.js needed on auth pages -->
```

## Why This Order Matters:

1. **path-resolver.js** defines `PathResolver` which auth.js, search.js, and _navbar.js all depend on
2. **helpers.js** defines utilities (`Format`, `Store`, `DOM`, etc.) used by all other scripts
3. **validation.js** provides form validation used by auth and other pages
4. **auth.js** uses `PathResolver.paths.login` and `PathResolver.paths.dashboard`
5. **notifications.js** initializes notification panel
6. **search.js** builds search index using `PathResolver.paths.*`
7. **_navbar.js** builds sidebar/navbar using `PathResolver.paths.*`
8. **app.js** initializes the core app (theme, sidebar, dropdowns, etc.)

## Path Depth Detection:

PathResolver automatically detects page depth:
- `pages/dashboard/dashboard.html` → depth=1 → prefix=`../`
- `pages/accounts/savings.html` → depth=1 → prefix=`../`
- `pages/authentication/login.html` → depth=1 → prefix=`../`

All paths from `../../src/assets/js/` work correctly from depth-1 pages.
