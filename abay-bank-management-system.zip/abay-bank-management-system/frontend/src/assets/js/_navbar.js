/* ============================================================
   ABAY BANK — DYNAMIC NAVBAR & SIDEBAR SHELL
   Builds the top navbar and sidebar nav for all inner pages.
   Uses PathResolver so all links work from any folder depth.
   ============================================================ */
(function buildShell() {
  const p = PathResolver.paths;

  /* ── Top Navbar ── */
  const navbar = document.getElementById('main-navbar');
  if (navbar) {
    navbar.innerHTML = `
      <button class="navbar-toggle" id="sidebar-toggle" aria-label="Toggle Sidebar">
        <i class="fa-solid fa-bars"></i>
      </button>
      <div class="navbar-search" id="navbar-search" style="position:relative">
        <i class="fa-solid fa-magnifying-glass search-icon"></i>
        <input type="search" id="global-search-input" placeholder="Search customers, accounts, transactions..." autocomplete="off">
      </div>
      <div class="navbar-actions">
        <button class="navbar-btn theme-toggle" onclick="AbayBank.toggleTheme()" aria-label="Toggle theme">
          <i class="fa-solid fa-moon icon-moon"></i>
          <i class="fa-solid fa-sun icon-sun"></i>
        </button>

        <!-- Notifications -->
        <div style="position:relative">
          <button class="navbar-btn" id="notif-bell" aria-label="Notifications">
            <i class="fa-solid fa-bell"></i>
            <span class="notif-count" id="notif-badge"></span>
          </button>
          <div class="notif-panel" id="notif-panel">
            <div class="notif-header">
              <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
              <button class="btn btn-ghost btn-sm" id="notif-mark-all">Mark all read</button>
            </div>
            <div class="notif-body" id="notif-list"></div>
            <div class="notif-footer">
              <a href="${p.notifications}">View all notifications</a>
            </div>
          </div>
        </div>

        <!-- Quick Add -->
        <div class="dropdown">
          <button class="btn btn-primary btn-sm" data-toggle="dropdown">
            <i class="fa-solid fa-plus"></i> Quick Add
            <i class="fa-solid fa-chevron-down" style="font-size:.7rem"></i>
          </button>
          <div class="dropdown-menu">
            <a href="${p.customerRegister}"  class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-user-plus"></i></span>New Customer</a>
            <a href="${p.accountOpening}"    class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-folder-open"></i></span>Open Account</a>
            <a href="${p.deposit}"           class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-arrow-down"></i></span>Deposit</a>
            <a href="${p.withdrawal}"        class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-arrow-up"></i></span>Withdrawal</a>
            <a href="${p.transfer}"          class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-right-left"></i></span>Fund Transfer</a>
            <div class="dropdown-divider"></div>
            <a href="${p.applyLoan}"         class="dropdown-item"><span class="item-icon"><i class="fa-solid fa-file-invoice-dollar"></i></span>Apply Loan</a>
          </div>
        </div>

        <!-- User Menu -->
        <div class="dropdown" style="position:relative">
          <button class="navbar-user" data-toggle="dropdown">
            <div class="avatar avatar-md" style="background:var(--primary);color:white;font-weight:700" data-user-avatar>A</div>
            <div class="user-info">
              <span class="user-name" data-user-name>Admin</span>
              <span class="user-role" data-user-role>Admin</span>
            </div>
            <i class="fa-solid fa-chevron-down" style="font-size:.7rem;color:var(--text-muted)"></i>
          </button>
          <div class="dropdown-menu" style="right:0;left:auto;min-width:200px">
            <a href="${p.settings}" class="dropdown-item">
              <span class="item-icon"><i class="fa-solid fa-gear"></i></span>Settings
            </a>
            <div class="dropdown-divider"></div>
            <button class="dropdown-item danger" onclick="Auth.logout()">
              <span class="item-icon"><i class="fa-solid fa-right-from-bracket"></i></span>Logout
            </button>
          </div>
        </div>
      </div>`;
  }

  /* ── Sidebar Nav ── */
  const nav = document.getElementById('sidebar-nav');
  if (!nav) return;

  nav.innerHTML = `
    <div class="nav-section">
      <div class="nav-section-title">Main</div>
      <div class="nav-item">
        <a href="${p.dashboard}" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-gauge"></i></span>
          <span class="nav-label">Dashboard</span>
        </a>
      </div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Banking</div>

      <div class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-users"></i></span>
          <span class="nav-label">Customers</span>
        </a>
        <div class="nav-submenu">
          <div class="nav-item"><a href="${p.customerList}"     class="nav-link"><span class="nav-icon"><i class="fa-solid fa-list"></i></span><span class="nav-label">Customer List</span></a></div>
          <div class="nav-item"><a href="${p.customerRegister}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-user-plus"></i></span><span class="nav-label">Register</span></a></div>
          <div class="nav-item"><a href="${p.customerKYC}"      class="nav-link"><span class="nav-icon"><i class="fa-solid fa-id-card"></i></span><span class="nav-label">KYC</span></a></div>
        </div>
      </div>

      <div class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-building-columns"></i></span>
          <span class="nav-label">Accounts</span>
        </a>
        <div class="nav-submenu">
          <div class="nav-item"><a href="${p.savings}"          class="nav-link"><span class="nav-icon"><i class="fa-solid fa-piggy-bank"></i></span><span class="nav-label">Savings</span></a></div>
          <div class="nav-item"><a href="${p.current}"          class="nav-link"><span class="nav-icon"><i class="fa-solid fa-wallet"></i></span><span class="nav-label">Current</span></a></div>
          <div class="nav-item"><a href="${p.fixedDeposit}"     class="nav-link"><span class="nav-icon"><i class="fa-solid fa-lock"></i></span><span class="nav-label">Fixed Deposits</span></a></div>
          <div class="nav-item"><a href="${p.accountStatement}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-file-lines"></i></span><span class="nav-label">Statement</span></a></div>
          <div class="nav-item"><a href="${p.accountOpening}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-folder-open"></i></span><span class="nav-label">Open Account</span></a></div>
          <div class="nav-item"><a href="${p.accountClosing}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-folder-minus"></i></span><span class="nav-label">Close Account</span></a></div>
        </div>
      </div>

      <div class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-arrow-right-arrow-left"></i></span>
          <span class="nav-label">Transactions</span>
        </a>
        <div class="nav-submenu">
          <div class="nav-item"><a href="${p.deposit}"              class="nav-link"><span class="nav-icon"><i class="fa-solid fa-arrow-down"></i></span><span class="nav-label">Deposit</span></a></div>
          <div class="nav-item"><a href="${p.withdrawal}"           class="nav-link"><span class="nav-icon"><i class="fa-solid fa-arrow-up"></i></span><span class="nav-label">Withdrawal</span></a></div>
          <div class="nav-item"><a href="${p.transfer}"             class="nav-link"><span class="nav-icon"><i class="fa-solid fa-right-left"></i></span><span class="nav-label">Transfer</span></a></div>
          <div class="nav-item"><a href="${p.transactionHistory}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-clock-rotate-left"></i></span><span class="nav-label">History</span></a></div>
          <div class="nav-item"><a href="${p.transactionApproval}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-check-double"></i></span><span class="nav-label">Approvals</span></a></div>
        </div>
      </div>

      <div class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-file-invoice-dollar"></i></span>
          <span class="nav-label">Loans</span>
        </a>
        <div class="nav-submenu">
          <div class="nav-item"><a href="${p.applyLoan}"     class="nav-link"><span class="nav-icon"><i class="fa-solid fa-pen-to-square"></i></span><span class="nav-label">Apply</span></a></div>
          <div class="nav-item"><a href="${p.loanList}"      class="nav-link"><span class="nav-icon"><i class="fa-solid fa-list-ul"></i></span><span class="nav-label">Loan List</span></a></div>
          <div class="nav-item"><a href="${p.loanApproval}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-circle-check"></i></span><span class="nav-label">Approvals</span></a></div>
          <div class="nav-item"><a href="${p.loanPayment}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-money-bill"></i></span><span class="nav-label">Payments</span></a></div>
        </div>
      </div>

      <div class="nav-item">
        <a href="${p.atmCards}" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-credit-card"></i></span>
          <span class="nav-label">ATM Cards</span>
        </a>
      </div>
      <div class="nav-item">
        <a href="${p.cheques}" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-money-check"></i></span>
          <span class="nav-label">Cheques</span>
        </a>
      </div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Human Resources</div>
      <div class="nav-item"><a href="${p.employees}"    class="nav-link"><span class="nav-icon"><i class="fa-solid fa-people-group"></i></span><span class="nav-label">Employees</span></a></div>
      <div class="nav-item"><a href="${p.attendance}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-calendar-check"></i></span><span class="nav-label">Attendance</span></a></div>
      <div class="nav-item"><a href="${p.leave}"        class="nav-link"><span class="nav-icon"><i class="fa-solid fa-calendar-xmark"></i></span><span class="nav-label">Leave</span></a></div>
      <div class="nav-item"><a href="${p.payroll}"      class="nav-link"><span class="nav-icon"><i class="fa-solid fa-receipt"></i></span><span class="nav-label">Payroll</span></a></div>
      <div class="nav-item"><a href="${p.performance}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-star"></i></span><span class="nav-label">Performance</span></a></div>
      <div class="nav-item"><a href="${p.recruitment}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-user-tie"></i></span><span class="nav-label">Recruitment</span></a></div>
      <div class="nav-item"><a href="${p.training}"     class="nav-link"><span class="nav-icon"><i class="fa-solid fa-graduation-cap"></i></span><span class="nav-label">Training</span></a></div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Management</div>
      <div class="nav-item"><a href="${p.branches}"          class="nav-link"><span class="nav-icon"><i class="fa-solid fa-building"></i></span><span class="nav-label">Branches</span></a></div>
      <div class="nav-item"><a href="${p.branchPerformance}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-chart-bar"></i></span><span class="nav-label">Branch Performance</span></a></div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Reports</div>
      <div class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <span class="nav-icon"><i class="fa-solid fa-chart-line"></i></span>
          <span class="nav-label">Reports</span>
        </a>
        <div class="nav-submenu">
          <div class="nav-item"><a href="${p.financialReport}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-file-invoice"></i></span><span class="nav-label">Financial</span></a></div>
          <div class="nav-item"><a href="${p.customerReport}"   class="nav-link"><span class="nav-icon"><i class="fa-solid fa-users"></i></span><span class="nav-label">Customers</span></a></div>
          <div class="nav-item"><a href="${p.loanReport}"       class="nav-link"><span class="nav-icon"><i class="fa-solid fa-file-invoice-dollar"></i></span><span class="nav-label">Loans</span></a></div>
          <div class="nav-item"><a href="${p.attendanceReport}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-calendar-check"></i></span><span class="nav-label">Attendance</span></a></div>
        </div>
      </div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Support</div>
      <div class="nav-item"><a href="${p.complaints}"    class="nav-link"><span class="nav-icon"><i class="fa-solid fa-comment-dots"></i></span><span class="nav-label">Complaints</span></a></div>
      <div class="nav-item"><a href="${p.appointments}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-calendar-days"></i></span><span class="nav-label">Appointments</span></a></div>
      <div class="nav-item"><a href="${p.notifications}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-bell"></i></span><span class="nav-label">Notifications</span></a></div>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">Administration</div>
      <div class="nav-item"><a href="${p.users}"    class="nav-link"><span class="nav-icon"><i class="fa-solid fa-users-cog"></i></span><span class="nav-label">Users</span></a></div>
      <div class="nav-item"><a href="${p.roles}"    class="nav-link"><span class="nav-icon"><i class="fa-solid fa-shield-halved"></i></span><span class="nav-label">Roles & Permissions</span></a></div>
      <div class="nav-item"><a href="${p.auditLog}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-scroll"></i></span><span class="nav-label">Audit Log</span></a></div>
      <div class="nav-item"><a href="${p.security}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-lock"></i></span><span class="nav-label">Security</span></a></div>
      <div class="nav-item"><a href="${p.documents}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-folder-open"></i></span><span class="nav-label">Documents</span></a></div>
      <div class="nav-item"><a href="${p.inventory}" class="nav-link"><span class="nav-icon"><i class="fa-solid fa-boxes-stacked"></i></span><span class="nav-label">Inventory</span></a></div>
      <div class="nav-item"><a href="${p.backup}"    class="nav-link"><span class="nav-icon"><i class="fa-solid fa-database"></i></span><span class="nav-label">Backup</span></a></div>
      <div class="nav-item"><a href="${p.settings}"  class="nav-link"><span class="nav-icon"><i class="fa-solid fa-gear"></i></span><span class="nav-label">Settings</span></a></div>
    </div>`;
})();
