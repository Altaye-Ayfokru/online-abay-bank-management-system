/* Sets today's date display on any page that has #today-date */
document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('today-date');
  if (el && typeof DateHelper !== 'undefined') el.textContent = DateHelper.todayLabel();
});
