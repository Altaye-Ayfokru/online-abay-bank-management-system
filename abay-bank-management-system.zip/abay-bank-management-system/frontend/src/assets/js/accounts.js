/* ============================================================
   ABAY BANK — ACCOUNTS MODULE
   ============================================================ */
'use strict';

const Accounts = {
  init() {
    this.bindEvents();
    this.loadAccounts();
  },

  loadAccounts() {
    const tbody = document.getElementById('accounts-table-body');
    if (!tbody) return;
    const accounts = Array.from({ length: 15 }, (_, i) => ({
      id: `ACC-${String(i+1).padStart(6,'0')}`,
      number: `100${String(i).padStart(11,'0')}`,
      customer: DemoData.names[i % DemoData.names.length],
      type: ['Savings','Current','Fixed Deposit'][i % 3],
      balance: parseFloat((Math.random() * 200000 + 500).toFixed(2)),
      interest: [3.5, 0, 7.25][i % 3],
      status: ['Active','Active','Active','Frozen','Closed'][i % 5],
      opened: DateHelper.addDays(DateHelper.today(), -(i * 45 + 30)),
    }));

    tbody.innerHTML = accounts.map(a => `
      <tr>
        <td class="cell-account">${a.number}</td>
        <td>
          <div class="cell-user">
            <div class="avatar avatar-sm" style="background:var(--primary);color:white">${Format.initials(a.customer)}</div>
            <div class="user-details"><div class="user-name">${a.customer}</div></div>
          </div>
        </td>
        <td><span class="badge badge-${a.type==='Savings'?'success':a.type==='Current'?'info':'secondary'}">${a.type}</span></td>
        <td class="amount">${Format.currency(a.balance)}</td>
        <td>${a.interest > 0 ? Format.percent(a.interest) : '—'}</td>
        <td><span class="${Colors.badge(a.status)} badge-dot">${a.status}</span></td>
        <td class="cell-date">${Format.date(a.opened)}</td>
        <td><div class="table-actions">
          <button class="action-btn view"   data-tooltip="Statement" onclick="Accounts.statement('${a.id}')"><i class="fa-solid fa-file-lines"></i></button>
          <button class="action-btn edit"   data-tooltip="Edit"      onclick="Accounts.edit('${a.id}')"><i class="fa-solid fa-pen"></i></button>
          <button class="action-btn ${a.status==='Active'?'delete':'approve'}" data-tooltip="${a.status==='Active'?'Freeze':'Unfreeze'}">
            <i class="fa-solid ${a.status==='Active'?'fa-snowflake':'fa-fire-flame-curved'}"></i>
          </button>
        </div></td>
      </tr>`).join('');
  },

  statement(id) { window.location.href = `${window.BASE_URL || ''}/accounts/statement?id=${id}`; },
  edit(id)      { Modal.open('account-edit-modal'); },

  bindEvents() {
    document.getElementById('open-account-btn')?.addEventListener('click', () => Modal.open('open-account-modal'));
    document.getElementById('open-account-form')?.addEventListener('submit', e => { e.preventDefault(); this.openAccount(e.target); });
    document.getElementById('account-type')?.addEventListener('change', e => this.updateAccountFields(e.target.value));
  },

  updateAccountFields(type) {
    const fdFields = document.getElementById('fd-fields');
    if (fdFields) DOM.toggle(fdFields, type === 'fixed_deposit');
  },

  openAccount(form) {
    const rules = {
      'account-customer': { required: true },
      'account-type':     { required: true },
      'initial-deposit':  { required: true, amount: true, min: 100 },
    };
    if (!Validate.form(form, rules)) return;
    const btn = form.querySelector('[type="submit"]');
    DOM.loading(btn, true, 'Opening...');
    setTimeout(() => {
      DOM.loading(btn, false);
      Modal.close('open-account-modal');
      Toast.success('Account opened successfully. Account number generated.');
      form.reset();
    }, 1000);
  },

  calculateInterest(principal, rate, months) {
    const interest = NumberHelper.simpleInterest(principal, rate, months);
    const maturity = parseFloat(principal) + interest;
    document.getElementById('calc-interest').textContent = Format.currency(interest);
    document.getElementById('calc-maturity').textContent = Format.currency(maturity);
  },
};

/* ── Statement Page ── */
const Statement = {
  init() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id') || 'ACC-000001';
    this.loadStatement(id);
    this.bindEvents();
  },

  loadStatement(id) {
    const transactions = DemoData.transactions(25);
    const tbody = document.getElementById('statement-tbody');
    if (!tbody) return;
    let balance = 50000;
    tbody.innerHTML = transactions.map(t => {
      const isCredit = ['Deposit','Interest Credit'].includes(t.type);
      if (isCredit) balance += t.amount; else balance -= t.amount;
      return `
        <tr>
          <td class="cell-date">${Format.date(t.date)}</td>
          <td>${t.id}</td>
          <td>${t.description}</td>
          <td class="amount ${isCredit ? 'credit' : ''}">${isCredit ? '+'+Format.currency(t.amount) : ''}</td>
          <td class="amount ${!isCredit ? 'debit' : ''}">${!isCredit ? '-'+Format.currency(t.amount) : ''}</td>
          <td class="amount fw-semibold">${Format.currency(balance)}</td>
        </tr>`;
    }).join('');
  },

  bindEvents() {
    document.getElementById('print-statement')?.addEventListener('click', () => window.print());
    document.getElementById('export-statement')?.addEventListener('click', () => Toast.info('Exporting to PDF...'));
    document.getElementById('filter-date-from')?.addEventListener('change', () => this.filterStatement());
    document.getElementById('filter-date-to')?.addEventListener('change', () => this.filterStatement());
  },

  filterStatement() {
    Toast.info('Filtering statement...');
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('accounts-table-body')) Accounts.init();
  if (document.getElementById('statement-tbody'))     Statement.init();
});
