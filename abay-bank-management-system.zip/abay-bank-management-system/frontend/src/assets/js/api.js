/* ============================================================
   ABAY BANK — API SERVICE LAYER
   Central service that connects frontend to PHP backend.
   All API calls go through this file.
   Base URL: /abay-bank-management-system/api
   ============================================================ */
'use strict';

const API = {
  /* ── Base URL — resolves to /project-root/api regardless of page depth ── */
  get baseURL() {
    const origin = window.location.origin;
    const path   = window.location.pathname;

    // Walk up from current path to find the project root
    // by detecting known folder markers in the URL
    const markers = ['/frontend/', '/backend/'];
    for (const marker of markers) {
      const idx = path.indexOf(marker);
      if (idx !== -1) {
        return origin + path.substring(0, idx) + '/api';
      }
    }

    // Fallback: assume first path segment is project root
    const parts = path.split('/').filter(Boolean);
    if (parts.length >= 1) {
      return origin + '/' + parts[0] + '/api';
    }
    return origin + '/api';
  },

  /* ── Get stored JWT token ── */
  getToken() {
    return localStorage.getItem('abay_token') || '';
  },

  /* ── Build default headers ── */
  headers(extra = {}) {
    const token = this.getToken();
    return {
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...extra,
    };
  },

  /* ── Core request handler ── */
  async request(method, endpoint, body = null, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      method,
      headers: this.headers(options.headers || {}),
    };
    if (body && method !== 'GET') {
      config.body = JSON.stringify(body);
    }

    try {
      const res = await fetch(url, config);

      /* 401 — return null, let caller decide (don't wipe session) */
      if (res.status === 401) {
        console.warn(`API 401 on ${endpoint} — returning null (demo or expired)`);
        return null;
      }

      /* Try to parse JSON; if PHP returns HTML error, return null */
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        console.warn(`API ${endpoint} returned non-JSON (${contentType}) — backend may be offline`);
        return null;
      }

      return await res.json();
    } catch (err) {
      console.warn(`API ${method} ${endpoint} — network/parse error:`, err.message || err);
      return null;
    }
  },

  get:    (endpoint, opts)       => API.request('GET',    endpoint, null, opts),
  post:   (endpoint, body, opts) => API.request('POST',   endpoint, body, opts),
  put:    (endpoint, body, opts) => API.request('PUT',    endpoint, body, opts),
  patch:  (endpoint, body, opts) => API.request('PATCH',  endpoint, body, opts),
  delete: (endpoint, opts)       => API.request('DELETE', endpoint, null, opts),

  /* ════════════════════════════════════════
     AUTH ENDPOINTS
     ════════════════════════════════════════ */
  auth: {
    login:          (data)           => API.post('/auth/login',           data, { skipAuthRedirect: true }),
    logout:         ()               => API.post('/auth/logout',          {}),
    refresh:        ()               => API.post('/auth/refresh',         {}),
    forgotPassword: (data)           => API.post('/auth/forgot-password', data, { skipAuthRedirect: true }),
    resetPassword:  (data)           => API.post('/auth/reset-password',  data, { skipAuthRedirect: true }),
    changePassword: (data)           => API.put ('/auth/change-password', data),
  },

  /* ════════════════════════════════════════
     DASHBOARD ENDPOINTS
     ════════════════════════════════════════ */
  dashboard: {
    stats:      () => API.get('/dashboard/stats'),
    charts:     () => API.get('/dashboard/charts'),
    activities: () => API.get('/dashboard/activities'),
  },

  /* ════════════════════════════════════════
     CUSTOMERS ENDPOINTS
     ════════════════════════════════════════ */
  customers: {
    list:   (params = {}) => API.get(`/customers?${new URLSearchParams(params)}`),
    create: (data)        => API.post('/customers', data),
    get:    (id)          => API.get(`/customers/${id}`),
    update: (id, data)    => API.put(`/customers/${id}`, data),
    delete: (id)          => API.delete(`/customers/${id}`),
    kyc:    (id, data)    => API.put(`/customers/${id}/kyc`, data),
  },

  /* ════════════════════════════════════════
     ACCOUNTS ENDPOINTS
     ════════════════════════════════════════ */
  accounts: {
    list:      (params = {}) => API.get(`/accounts?${new URLSearchParams(params)}`),
    create:    (data)        => API.post('/accounts', data),
    get:       (id)          => API.get(`/accounts/${id}`),
    update:    (id, data)    => API.put(`/accounts/${id}`, data),
    freeze:    (id)          => API.put(`/accounts/${id}/freeze`, {}),
    unfreeze:  (id)          => API.put(`/accounts/${id}/unfreeze`, {}),
    statement: (id, params)  => API.get(`/accounts/${id}/statement?${new URLSearchParams(params)}`),
    balance:   (id)          => API.get(`/accounts/${id}/balance`),
  },

  /* ════════════════════════════════════════
     TRANSACTIONS ENDPOINTS
     ════════════════════════════════════════ */
  transactions: {
    list:       (params = {}) => API.get(`/transactions?${new URLSearchParams(params)}`),
    get:        (id)          => API.get(`/transactions/${id}`),
    deposit:    (data)        => API.post('/transactions/deposit',    data),
    withdrawal: (data)        => API.post('/transactions/withdrawal', data),
    transfer:   (data)        => API.post('/transactions/transfer',   data),
    approve:    (id)          => API.put(`/transactions/${id}/approve`, {}),
    reverse:    (id)          => API.put(`/transactions/${id}/reverse`, {}),
  },

  /* ════════════════════════════════════════
     LOANS ENDPOINTS
     ════════════════════════════════════════ */
  loans: {
    list:         (params = {}) => API.get(`/loans?${new URLSearchParams(params)}`),
    apply:        (data)        => API.post('/loans', data),
    get:          (id)          => API.get(`/loans/${id}`),
    approve:      (id, data)    => API.put(`/loans/${id}/approve`, data),
    reject:       (id, data)    => API.put(`/loans/${id}/reject`, data),
    payment:      (id, data)    => API.post(`/loans/${id}/payment`, data),
    schedule:     (id)          => API.get(`/loans/${id}/schedule`),
    calculateEmi: (data)        => API.post('/loans/calculate-emi', data),
  },

  /* ════════════════════════════════════════
     EMPLOYEES ENDPOINTS
     ════════════════════════════════════════ */
  employees: {
    list:   (params = {}) => API.get(`/employees?${new URLSearchParams(params)}`),
    create: (data)        => API.post('/employees', data),
    get:    (id)          => API.get(`/employees/${id}`),
    update: (id, data)    => API.put(`/employees/${id}`, data),
    delete: (id)          => API.delete(`/employees/${id}`),
  },

  /* ════════════════════════════════════════
     ATTENDANCE ENDPOINTS
     ════════════════════════════════════════ */
  attendance: {
    list:     (params = {}) => API.get(`/attendance?${new URLSearchParams(params)}`),
    checkIn:  (data)        => API.post('/attendance/checkin',  data),
    checkOut: (data)        => API.post('/attendance/checkout', data),
    report:   (params = {}) => API.get(`/attendance/report?${new URLSearchParams(params)}`),
  },

  /* ════════════════════════════════════════
     LEAVE ENDPOINTS
     ════════════════════════════════════════ */
  leaves: {
    list:    (params = {}) => API.get(`/leaves?${new URLSearchParams(params)}`),
    apply:   (data)        => API.post('/leaves', data),
    approve: (id)          => API.put(`/leaves/${id}/approve`, {}),
    reject:  (id, data)    => API.put(`/leaves/${id}/reject`, data),
  },

  /* ════════════════════════════════════════
     PAYROLL ENDPOINTS
     ════════════════════════════════════════ */
  payroll: {
    list:    (params = {}) => API.get(`/payroll?${new URLSearchParams(params)}`),
    process: (data)        => API.post('/payroll/process', data),
    slip:    (id)          => API.get(`/payroll/${id}/slip`),
  },

  /* ════════════════════════════════════════
     BRANCHES ENDPOINTS
     ════════════════════════════════════════ */
  branches: {
    list:   (params = {}) => API.get(`/branches?${new URLSearchParams(params)}`),
    create: (data)        => API.post('/branches', data),
    get:    (id)          => API.get(`/branches/${id}`),
    update: (id, data)    => API.put(`/branches/${id}`, data),
  },

  /* ════════════════════════════════════════
     REPORTS ENDPOINTS
     ════════════════════════════════════════ */
  reports: {
    financial:    (params = {}) => API.get(`/reports/financial?${new URLSearchParams(params)}`),
    customers:    (params = {}) => API.get(`/reports/customers?${new URLSearchParams(params)}`),
    loans:        (params = {}) => API.get(`/reports/loans?${new URLSearchParams(params)}`),
    transactions: (params = {}) => API.get(`/reports/transactions?${new URLSearchParams(params)}`),
    attendance:   (params = {}) => API.get(`/reports/attendance?${new URLSearchParams(params)}`),
    branch:       (params = {}) => API.get(`/reports/branch?${new URLSearchParams(params)}`),
  },

  /* ════════════════════════════════════════
     NOTIFICATIONS ENDPOINTS
     ════════════════════════════════════════ */
  notifications: {
    list:       (params = {}) => API.get(`/notifications?${new URLSearchParams(params)}`),
    markRead:   (id)          => API.put(`/notifications/${id}/read`, {}),
    markAllRead:()            => API.put('/notifications/read-all', {}),
    send:       (data)        => API.post('/notifications/send', data),
  },

  /* ════════════════════════════════════════
     COMPLAINTS ENDPOINTS
     ════════════════════════════════════════ */
  complaints: {
    list:    (params = {}) => API.get(`/complaints?${new URLSearchParams(params)}`),
    create:  (data)        => API.post('/complaints', data),
    resolve: (id, data)    => API.put(`/complaints/${id}/resolve`, data),
  },

  /* ════════════════════════════════════════
     APPOINTMENTS ENDPOINTS
     ════════════════════════════════════════ */
  appointments: {
    list:   (params = {}) => API.get(`/appointments?${new URLSearchParams(params)}`),
    create: (data)        => API.post('/appointments', data),
    update: (id, data)    => API.put(`/appointments/${id}`, data),
  },

  /* ════════════════════════════════════════
     ATM CARDS ENDPOINTS
     ════════════════════════════════════════ */
  cards: {
    list:     (params = {}) => API.get(`/cards?${new URLSearchParams(params)}`),
    issue:    (data)        => API.post('/cards', data),
    block:    (id)          => API.put(`/cards/${id}/block`, {}),
    activate: (id)          => API.put(`/cards/${id}/activate`, {}),
  },

  /* ════════════════════════════════════════
     USERS & ROLES ENDPOINTS
     ════════════════════════════════════════ */
  users: {
    list:   (params = {}) => API.get(`/users?${new URLSearchParams(params)}`),
    create: (data)        => API.post('/users', data),
    update: (id, data)    => API.put(`/users/${id}`, data),
    delete: (id)          => API.delete(`/users/${id}`),
  },
  roles: {
    list:              ()        => API.get('/roles'),
    create:            (data)    => API.post('/roles', data),
    updatePermissions: (id, data)=> API.put(`/roles/${id}/permissions`, data),
  },

  /* ════════════════════════════════════════
     AUDIT, SETTINGS, BACKUP ENDPOINTS
     ════════════════════════════════════════ */
  audit: {
    list: (params = {}) => API.get(`/audit?${new URLSearchParams(params)}`),
  },
  settings: {
    get:    ()     => API.get('/settings'),
    update: (data) => API.put('/settings', data),
  },
  backup: {
    create:  ()     => API.post('/backup/create', {}),
    list:    ()     => API.get('/backup/list'),
    restore: (data) => API.post('/backup/restore', data),
  },
};

/* ── Expose globally ── */
window.API = API;
