/* ============================================================
   ABAY BANK MANAGEMENT SYSTEM — APP CORE
   ============================================================ */

'use strict';

/* ── Global App Object ── */
const AbayBank = {
  version: '1.0.0',
  baseURL: '/api',
  user: null,
  theme: localStorage.getItem('abay_theme') || 'light',
  sidebarCollapsed: localStorage.getItem('abay_sidebar') === 'true',

  /* ── Init ── */
  init() {
    this.applyTheme();
    this.initSidebar();
    this.initNavbar();
    this.initDropdowns();
    this.initModals();
    this.initToasts();
    this.initRipple();
    this.loadUser();
    this.highlightActiveNav();
    this.initTooltips();
    console.log(`%c Abay Bank v${this.version} `, 'background:#1a3c5e;color:#c8a84b;font-weight:bold;padding:4px 8px;border-radius:4px;');
  },

  /* ── Theme ── */
  applyTheme() {
    document.documentElement.setAttribute('data-theme', this.theme);
  },

  toggleTheme() {
    this.theme = this.theme === 'light' ? 'dark' : 'light';
    localStorage.setItem('abay_theme', this.theme);
    this.applyTheme();
    Toast.show(this.theme === 'dark' ? 'Dark mode enabled' : 'Light mode enabled', 'info');
  },

  /* ── Sidebar ── */
  initSidebar() {
    const sidebar  = document.querySelector('.sidebar');
    const navbar   = document.querySelector('.navbar');
    const content  = document.querySelector('.main-content');
    const toggle   = document.querySelector('.navbar-toggle');
    const backdrop = document.querySelector('.sidebar-backdrop');

    if (!sidebar) return;

    const isMobile = () => window.innerWidth <= 768;

    const apply = () => {
      if (isMobile()) {
        sidebar.classList.remove('collapsed');
        sidebar.classList.toggle('mobile-open', false);
        backdrop?.classList.remove('show');
        navbar?.classList.remove('sidebar-collapsed');
        content?.classList.remove('sidebar-collapsed');
      } else {
        sidebar.classList.toggle('collapsed', this.sidebarCollapsed);
        navbar?.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
        content?.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
      }
    };

    apply();

    toggle?.addEventListener('click', () => {
      if (isMobile()) {
        const open = sidebar.classList.toggle('mobile-open');
        backdrop?.classList.toggle('show', open);
      } else {
        this.sidebarCollapsed = !this.sidebarCollapsed;
        localStorage.setItem('abay_sidebar', this.sidebarCollapsed);
        apply();
      }
    });

    backdrop?.addEventListener('click', () => {
      sidebar.classList.remove('mobile-open');
      backdrop.classList.remove('show');
    });

    window.addEventListener('resize', () => apply());

    /* Submenu toggles — handled via event delegation in navbar.php inline script */
    // (no per-element listeners here to avoid double-bind)
  },

  /* ── Navbar ── */
  initNavbar() {
    /* Mobile search toggle */
    const searchToggle = document.querySelector('[data-action="toggle-search"]');
    const searchBox    = document.querySelector('.navbar-search');
    searchToggle?.addEventListener('click', () => {
      searchBox?.classList.toggle('mobile-open');
      if (searchBox?.classList.contains('mobile-open')) searchBox.querySelector('input')?.focus();
    });

    /* User dropdown */
    const userBtn = document.querySelector('.navbar-user');
    const userMenu = document.querySelector('.navbar-user-menu');
    userBtn?.addEventListener('click', e => {
      e.stopPropagation();
      userMenu?.classList.toggle('open');
    });

    document.addEventListener('click', () => userMenu?.classList.remove('open'));
  },

  /* ── Dropdowns ── */
  initDropdowns() {
    document.querySelectorAll('[data-toggle="dropdown"]').forEach(trigger => {
      const menu = trigger.nextElementSibling || document.querySelector(trigger.dataset.target);
      trigger.addEventListener('click', e => {
        e.stopPropagation();
        const isOpen = menu.classList.contains('open');
        document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
        menu?.classList.toggle('open', !isOpen);
      });
    });
    document.addEventListener('click', () =>
      document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'))
    );
  },

  /* ── Modals ── */
  initModals() {
    document.querySelectorAll('[data-modal]').forEach(trigger => {
      trigger.addEventListener('click', () => Modal.open(trigger.dataset.modal));
    });
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) Modal.close(overlay.id);
      });
    });
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', () => {
        const overlay = btn.closest('.modal-overlay');
        if (overlay) Modal.close(overlay.id);
      });
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.open').forEach(o => Modal.close(o.id));
      }
    });
  },

  /* ── Toasts ── */
  initToasts() {
    if (!document.querySelector('.toast-container')) {
      const container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
  },

  /* ── Ripple ── */
  initRipple() {
    document.querySelectorAll('.btn, .ripple').forEach(el => {
      el.addEventListener('click', e => {
        const rect   = el.getBoundingClientRect();
        const size   = Math.max(rect.width, rect.height);
        const x      = e.clientX - rect.left - size / 2;
        const y      = e.clientY - rect.top - size / 2;
        const ripple = document.createElement('span');
        ripple.className = 'ripple-effect';
        ripple.style.cssText = `width:${size}px;height:${size}px;left:${x}px;top:${y}px`;
        el.appendChild(ripple);
        ripple.addEventListener('animationend', () => ripple.remove());
      });
    });
  },

  /* ── User ── */
  loadUser() {
    const raw = localStorage.getItem('abay_user');
    if (raw) {
      try {
        this.user = JSON.parse(raw);
        this.renderUserUI();
      } catch (_) {}
    }
  },

  renderUserUI() {
    if (!this.user) return;
    document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = this.user.name || '');
    document.querySelectorAll('[data-user-role]').forEach(el => el.textContent = this.user.role || '');
    document.querySelectorAll('[data-user-avatar]').forEach(el => {
      if (this.user.avatar) el.src = this.user.avatar;
      else el.textContent = (this.user.name || 'U')[0].toUpperCase();
    });
  },

  /* ── Active Nav ── */
  highlightActiveNav() {
    const current = window.location.pathname.split('/').pop();
    document.querySelectorAll('.nav-link').forEach(link => {
      const href = (link.getAttribute('href') || '').split('/').pop();
      if (href && href === current) {
        link.classList.add('active');
        link.closest('.nav-item.has-submenu')?.classList.add('open');
      }
    });
  },

  /* ── Tooltips ── */
  initTooltips() {
    /* CSS-driven, no JS needed for basic tooltips */
  },

  /* ── API Helper ── */
  async api(endpoint, options = {}) {
    // Resolve base URL from PHP-injected window.BASE_URL (set in base.php)
    // Falls back to auto-detecting the app root from the current pathname
    const base = (typeof window !== 'undefined' && window.BASE_URL)
      ? window.BASE_URL
      : (() => {
          const parts = window.location.pathname.split('/');
          const idx   = parts.indexOf('abay-bank-management-system');
          return idx !== -1
            ? window.location.origin + '/' + parts.slice(1, idx + 1).join('/')
            : window.location.origin;
        })();

    const token = localStorage.getItem('abay_token');
    const defaults = {
      credentials: 'include',                          // ← always send the PHP session cookie
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',          // marks this as an AJAX call
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    };

    try {
      const url = `${base}/api${endpoint}`;
      const res = await fetch(url, {
        ...defaults,
        ...options,
        headers: { ...defaults.headers, ...(options.headers || {}) },
      });
      if (res.status === 401) {
        /* Return the actual JSON error so callers can show the message.
           Previously returned null which hid the real error. */
        console.warn('AbayBank.api 401 on', endpoint, '— session may have expired');
        try { return await res.json(); } catch (_) {}
        return { success: false, message: 'Unauthorized. Please sign in.' };
      }
      return await res.json();
    } catch (err) {
      console.warn('AbayBank.api error (backend offline?):', err.message || err);
      return null;
    }
  },

  /* ── Convenience wrappers (used by views as ABAY.setBtn / ABAY.toast / ABAY.badge / ABAY.fmtNum) ── */
  setBtn(id, loading, html) {
    const btn = document.getElementById(id);
    if (!btn) return;
    if (loading) {
      btn.dataset.orig = btn.innerHTML;
      btn.innerHTML = html || '<span class="spinner" style="width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;display:inline-block;animation:spin .7s linear infinite"></span> Loading…';
      btn.disabled = true;
    } else {
      btn.innerHTML = html || btn.dataset.orig || btn.innerHTML;
      btn.disabled = false;
    }
  },

  toast(msg, type = 'info') {
    Toast.show(msg, type === 'ok' ? 'success' : type);
  },

  badge(status) {
    const map = {
      'Active': ['#dcfce7','#166534'], 'On Leave': ['#fef9c3','#92400e'],
      'Inactive': ['#f1f5f9','#475569'], 'Suspended': ['#fee2e2','#991b1b'],
      'Pending': ['#dbeafe','#1e40af'], 'Approved': ['#dcfce7','#166534'],
      'Rejected': ['#fee2e2','#991b1b'],
    };
    const [bg, color] = map[status] || ['#f1f5f9','#475569'];
    return `<span style="background:${bg};color:${color};padding:2px 9px;border-radius:20px;font-size:.72rem;font-weight:700">${status || '—'}</span>`;
  },

  fmtNum(n) { return new Intl.NumberFormat('en').format(n); },

  fmtCurrency(n) {
    return 'ETB ' + new Intl.NumberFormat('en', { minimumFractionDigits: 2 }).format(n);
  },
};

/* ── Modal Manager ── */
const Modal = {
  open(id) {
    const overlay = document.getElementById(id);
    if (overlay) {
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  },
  close(id) {
    const overlay = document.getElementById(id);
    if (overlay) {
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  },
  closeAll() {
    document.querySelectorAll('.modal-overlay.open').forEach(o => {
      o.classList.remove('open');
    });
    document.body.style.overflow = '';
  },
};

/* ── Toast Manager ── */
const Toast = {
  icons: { success: 'fa-circle-check', error: 'fa-circle-xmark', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' },
  titles: { success: 'Success', error: 'Error', warning: 'Warning', info: 'Info' },

  show(message, type = 'info', duration = 4000, title = null) {
    const container = document.querySelector('.toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <i class="fa-solid ${this.icons[type]} toast-icon"></i>
      <div class="toast-content">
        <div class="toast-title">${title || this.titles[type]}</div>
        <div class="toast-message">${message}</div>
      </div>
      <button class="toast-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
      <div class="toast-progress" style="animation-duration:${duration}ms;color:var(--${type === 'error' ? 'danger' : type})"></div>
    `;
    container.appendChild(toast);
    requestAnimationFrame(() => { requestAnimationFrame(() => toast.classList.add('show')); });

    toast.querySelector('.toast-close').addEventListener('click', () => this._remove(toast));
    const timer = setTimeout(() => this._remove(toast), duration);
    toast.addEventListener('mouseenter', () => clearTimeout(timer));
    toast.addEventListener('mouseleave', () => setTimeout(() => this._remove(toast), 1000));
  },

  _remove(toast) {
    toast.classList.add('hide');
    toast.addEventListener('transitionend', () => toast.remove(), { once: true });
  },

  success(msg, title) { this.show(msg, 'success', 4000, title); },
  error(msg, title)   { this.show(msg, 'error',   5000, title); },
  warning(msg, title) { this.show(msg, 'warning', 4500, title); },
  info(msg, title)    { this.show(msg, 'info',    3500, title); },
};

/* ── Confirm Dialog ── */
const Confirm = {
  show(message, onConfirm, options = {}) {
    const { title = 'Confirm Action', confirmText = 'Confirm', type = 'danger' } = options;
    const id = 'confirm-modal';
    let modal = document.getElementById(id);
    if (!modal) {
      modal = document.createElement('div');
      modal.className = 'modal-overlay'; modal.id = id;
      modal.innerHTML = `
        <div class="modal modal-sm">
          <div class="modal-header"><h3 id="confirm-title"><i class="fa-solid fa-triangle-exclamation"></i> ${title}</h3></div>
          <div class="modal-body"><p id="confirm-message" style="margin:0;font-size:var(--text-sm)"></p></div>
          <div class="modal-footer">
            <button class="btn btn-ghost" id="confirm-cancel">Cancel</button>
            <button class="btn btn-${type}" id="confirm-ok">${confirmText}</button>
          </div>
        </div>`;
      document.body.appendChild(modal);
    }
    document.getElementById('confirm-title').innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${title}`;
    document.getElementById('confirm-message').textContent = message;
    const okBtn = document.getElementById('confirm-ok');
    const cancelBtn = document.getElementById('confirm-cancel');
    okBtn.className = `btn btn-${type}`;
    okBtn.textContent = confirmText;
    const cleanOk = okBtn.cloneNode(true);
    const cleanCancel = cancelBtn.cloneNode(true);
    okBtn.replaceWith(cleanOk); cancelBtn.replaceWith(cleanCancel);
    cleanOk.addEventListener('click', () => { Modal.close(id); onConfirm(); });
    cleanCancel.addEventListener('click', () => Modal.close(id));
    Modal.open(id);
  },
};

/* ── Format Helpers ── */
const Format = {
  currency(amount, currency = 'ETB') {
    return new Intl.NumberFormat('en-ET', { style: 'currency', currency, minimumFractionDigits: 2 }).format(amount);
  },
  number(n) { return new Intl.NumberFormat('en').format(n); },
  date(d, opts = {}) {
    return new Intl.DateTimeFormat('en-ET', { year: 'numeric', month: 'short', day: '2-digit', ...opts }).format(new Date(d));
  },
  dateTime(d) {
    return this.date(d, { hour: '2-digit', minute: '2-digit' });
  },
  percent(n, decimals = 1) { return `${Number(n).toFixed(decimals)}%`; },
  accountNumber(n) { return String(n).replace(/(.{4})/g, '$1 ').trim(); },
  phone(p) { return String(p).replace(/(\d{4})(\d{3})(\d{3})/, '$1-$2-$3'); },
  initials(name) { return (name || '').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2); },
  relativeTime(d) {
    const diff = Date.now() - new Date(d).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1)   return 'Just now';
    if (mins < 60)  return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24)   return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 7)   return `${days}d ago`;
    return this.date(d);
  },
  fileSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes/1024).toFixed(1)} KB`;
    return `${(bytes/1048576).toFixed(1)} MB`;
  },
};

/* ── DOM Helpers ── */
const DOM = {
  $(sel, ctx = document) { return ctx.querySelector(sel); },
  $$(sel, ctx = document) { return [...ctx.querySelectorAll(sel)]; },
  on(el, event, handler) {
    if (typeof el === 'string') el = document.querySelector(el);
    el?.addEventListener(event, handler);
  },
  show(el) { if (typeof el === 'string') el = document.querySelector(el); el?.classList.remove('d-none'); },
  hide(el) { if (typeof el === 'string') el = document.querySelector(el); el?.classList.add('d-none'); },
  toggle(el, condition) {
    if (typeof el === 'string') el = document.querySelector(el);
    el?.classList.toggle('d-none', !condition);
  },
  html(el, content) {
    if (typeof el === 'string') el = document.querySelector(el);
    if (el) el.innerHTML = content;
  },
  text(el, content) {
    if (typeof el === 'string') el = document.querySelector(el);
    if (el) el.textContent = content;
  },
  val(el) {
    if (typeof el === 'string') el = document.querySelector(el);
    return el?.value ?? '';
  },
  setVal(el, val) {
    if (typeof el === 'string') el = document.querySelector(el);
    if (el) el.value = val;
  },
  loading(btn, state, text = 'Loading...') {
    if (state) {
      btn.dataset.originalText = btn.innerHTML;
      btn.innerHTML = `<span class="spinner"></span> ${text}`;
      btn.disabled = true;
    } else {
      btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
      btn.disabled = false;
    }
  },
};

/* ── Boot ── */
document.addEventListener('DOMContentLoaded', () => AbayBank.init());
