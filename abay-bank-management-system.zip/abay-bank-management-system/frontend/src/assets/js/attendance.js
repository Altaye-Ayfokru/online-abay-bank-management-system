/* ============================================================
   ABAY BANK — ATTENDANCE MODULE
   ============================================================ */
'use strict';

const Attendance = {
  data: [],

  init() {
    this.data = this.generateData();
    this.loadTable();
    this.loadSummaryCards();
    this.initCalendar();
    this.bindEvents();
  },

  generateData() {
    return DemoData.names.map((name, i) => {
      const checkIn  = `0${7 + (i % 3)}:${i % 2 === 0 ? '00' : '30'} AM`;
      const checkOut = `0${4 + (i % 2)}:${i % 3 === 0 ? '00' : '30'} PM`;
      const late     = i % 4 === 0;
      const absent   = i % 8 === 0;
      return {
        id:         `EMP-${String(i+1).padStart(4,'0')}`,
        name,
        department: ['Finance','Operations','IT','HR','Loans'][i % 5],
        date:       DateHelper.today(),
        checkIn:    absent ? '—' : checkIn,
        checkOut:   absent ? '—' : checkOut,
        hours:      absent ? 0 : (8 - (late ? 0.5 : 0)),
        status:     absent ? 'Absent' : late ? 'Late' : 'Present',
        overtime:   i % 5 === 0 ? 1.5 : 0,
      };
    });
  },

  loadTable() {
    const tbody = document.getElementById('attendance-tbody');
    if (!tbody) return;
    tbody.innerHTML = this.data.map(a => `
      <tr>
        <td class="cell-account">${a.id}</td>
        <td>
          <div class="cell-user">
            <div class="avatar avatar-sm" style="background:var(--primary);color:white">${Format.initials(a.name)}</div>
            <div class="user-details"><div class="user-name">${a.name}</div><div class="user-id">${a.department}</div></div>
          </div>
        </td>
        <td class="cell-date">${Format.date(a.date)}</td>
        <td class="${a.status === 'Late' ? 'text-warning fw-semibold' : ''}">${a.checkIn}</td>
        <td>${a.checkOut}</td>
        <td>${a.hours > 0 ? a.hours + ' hrs' : '—'}</td>
        <td>${a.overtime > 0 ? `<span class="text-info">${a.overtime} hrs</span>` : '—'}</td>
        <td><span class="${a.status==='Present'?'badge badge-success':a.status==='Late'?'badge badge-warning':'badge badge-danger'} badge-dot">${a.status}</span></td>
        <td><div class="table-actions">
          <button class="action-btn edit" data-tooltip="Edit" onclick="Attendance.editRecord('${a.id}')"><i class="fa-solid fa-pen"></i></button>
        </div></td>
      </tr>`).join('');
  },

  loadSummaryCards() {
    const present = this.data.filter(a => a.status === 'Present').length;
    const absent  = this.data.filter(a => a.status === 'Absent').length;
    const late    = this.data.filter(a => a.status === 'Late').length;
    const total   = this.data.length;

    DOM.text('#att-present', present);
    DOM.text('#att-absent',  absent);
    DOM.text('#att-late',    late);
    DOM.text('#att-rate',    Format.percent((present / total) * 100));
  },

  initCalendar() {
    const cal = document.getElementById('attendance-calendar');
    if (!cal) return;
    const now   = new Date();
    const year  = now.getFullYear();
    const month = now.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay    = new Date(year, month, 1).getDay();

    const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    let html = `<table class="mini-calendar"><thead><tr>${days.map(d=>`<th>${d}</th>`).join('')}</tr></thead><tbody><tr>`;
    for (let i = 0; i < firstDay; i++) html += '<td class="other-month"></td>';
    for (let d = 1; d <= daysInMonth; d++) {
      if ((d + firstDay - 1) % 7 === 0 && d > 1) html += '</tr><tr>';
      const isToday = d === now.getDate();
      const isWeekend = ((d + firstDay - 1) % 7 === 0 || (d + firstDay - 1) % 7 === 6);
      html += `<td class="${isToday ? 'today' : ''} ${isWeekend ? 'other-month' : ''}" title="Day ${d}">${d}</td>`;
    }
    html += '</tr></tbody></table>';
    cal.innerHTML = html;
  },

  editRecord(id) {
    Toast.info(`Editing attendance for ${id}`);
    Modal.open('attendance-edit-modal');
  },

  markAttendance(id, status) {
    const record = this.data.find(a => a.id === id);
    if (record) {
      record.status = status;
      if (status === 'Present') { record.checkIn = new Date().toLocaleTimeString(); }
      this.loadTable();
      this.loadSummaryCards();
      Toast.success(`Attendance marked: ${status} for ${id}`);
    }
  },

  bindEvents() {
    document.getElementById('mark-all-present')?.addEventListener('click', () => {
      Confirm.show('Mark all employees as Present for today?', () => {
        this.data.forEach(a => { if (a.status !== 'Absent') a.status = 'Present'; });
        this.loadTable(); this.loadSummaryCards();
        Toast.success('All attendance marked as Present.');
      }, { title: 'Mark All Present', confirmText: 'Mark Present', type: 'success' });
    });

    document.getElementById('export-attendance')?.addEventListener('click', () =>
      Exporter.toCSV(this.data, 'attendance'));

    document.getElementById('filter-att-date')?.addEventListener('change', e => {
      DOM.text('#att-date-label', Format.date(e.target.value));
    });
  },
};

/* ── Leave Management ── */
const Leave = {
  init() {
    this.loadLeaveRequests();
    this.bindEvents();
  },

  loadLeaveRequests() {
    const tbody = document.getElementById('leave-tbody');
    if (!tbody) return;
    const types    = ['Annual','Sick','Maternity','Paternity','Emergency','Unpaid'];
    const statuses = ['Pending','Approved','Approved','Rejected','Pending','Approved'];
    tbody.innerHTML = Array.from({ length: 10 }, (_, i) => {
      const from = DateHelper.addDays(DateHelper.today(), i * 5 + 5);
      const to   = DateHelper.addDays(from, i % 5 + 1);
      const days = DateHelper.diffDays(from, to) + 1;
      return `
        <tr>
          <td class="cell-account">EMP-${String(i+1).padStart(4,'0')}</td>
          <td>${DemoData.names[i % DemoData.names.length]}</td>
          <td><span class="badge badge-info">${types[i % types.length]}</span></td>
          <td class="cell-date">${Format.date(from)}</td>
          <td class="cell-date">${Format.date(to)}</td>
          <td><strong>${days}</strong> day${days > 1 ? 's' : ''}</td>
          <td>${i % 3 === 0 ? '<span class="text-muted">—</span>' : 'Emergency family matter'}</td>
          <td><span class="${Colors.badge(statuses[i % statuses.length])} badge-dot">${statuses[i % statuses.length]}</span></td>
          <td><div class="table-actions">
            ${statuses[i % statuses.length] === 'Pending' ? `
            <button class="action-btn approve" data-tooltip="Approve" onclick="Leave.approve(${i})"><i class="fa-solid fa-check"></i></button>
            <button class="action-btn delete"  data-tooltip="Reject"  onclick="Leave.reject(${i})"><i class="fa-solid fa-xmark"></i></button>` : ''}
            <button class="action-btn view" data-tooltip="View"><i class="fa-solid fa-eye"></i></button>
          </div></td>
        </tr>`;
    }).join('');
  },

  approve(i) {
    Confirm.show('Approve this leave request?', () => {
      Toast.success('Leave request approved.');
      this.loadLeaveRequests();
    }, { title: 'Approve Leave', confirmText: 'Approve', type: 'success' });
  },

  reject(i) {
    Confirm.show('Reject this leave request?', () => {
      Toast.warning('Leave request rejected.');
      this.loadLeaveRequests();
    }, { title: 'Reject Leave', confirmText: 'Reject', type: 'danger' });
  },

  bindEvents() {
    document.getElementById('apply-leave-btn')?.addEventListener('click', () => Modal.open('leave-modal'));
    document.getElementById('leave-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const rules = {
        'leave-type':  { required: true },
        'leave-from':  { required: true, date: true },
        'leave-to':    { required: true, date: true },
        'leave-reason':{ required: true, minLen: 10 },
      };
      if (!Validate.form(e.target, rules)) return;
      const btn = e.target.querySelector('[type="submit"]');
      DOM.loading(btn, true, 'Submitting...');
      setTimeout(() => {
        DOM.loading(btn, false);
        Modal.close('leave-modal');
        Toast.success('Leave request submitted successfully.');
        e.target.reset();
      }, 800);
    });
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('attendance-tbody'))  Attendance.init();
  if (document.getElementById('leave-tbody'))       Leave.init();
});
