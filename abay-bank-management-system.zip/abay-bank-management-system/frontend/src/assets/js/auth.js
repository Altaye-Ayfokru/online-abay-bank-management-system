/* ============================================================
   ABAY BANK — AUTHENTICATION
   Works in demo mode (no backend) AND with real backend.
   Safe: never freezes, never throws uncaught errors.
   ============================================================ */
'use strict';

const Auth = {
  TOKEN_KEY:    'abay_token',
  USER_KEY:     'abay_user',
  EXPIRY_KEY:   'abay_expiry',
  SESSION_MINS: 120,

  /* ─────────────────────────────────────────
     LOGIN
  ───────────────────────────────────────── */
  async login(credentials) {
    const btn = document.getElementById('login-btn');
    if (btn) DOM.loading(btn, true, 'Signing in...');

    let usedBackend = false;

    try {
      if (typeof API !== 'undefined') {
        const res = await Promise.race([
          API.auth.login({ username: credentials.username, password: credentials.password }),
          new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 5000))
        ]);

        if (res && res.success && res.data && res.data.token) {
          const { token, user } = res.data;
          this._saveSession(token, {
            id:     user.id,
            name:   user.full_name || user.username,
            role:   user.role_name || user.role || 'Staff',
            email:  user.email,
            branch: user.branch_id,
          });
          usedBackend = true;
          if (btn) DOM.loading(btn, false);
          this._redirect();
          return;
        } else if (res && !res.success) {
          if (btn) DOM.loading(btn, false);
          this.showLoginError(res.message || 'Invalid username or password.');
          this._trackFailed();
          return;
        }
      }
    } catch (_) {
      // Backend offline or timed out — fall through to demo mode
    }

    if (!usedBackend) {
      await this._demoLogin(credentials, btn);
    }
  },

  /* ─────────────────────────────────────────
     DEMO LOGIN (no backend needed)
  ───────────────────────────────────────── */
  async _demoLogin(credentials, btn) {
    await this._sleep(600);

    const users = {
      admin:       { id:1, name:'Admin User',     role:'Admin',       email:'admin@abaybank.com'   },
      manager:     { id:2, name:'Branch Manager', role:'Manager',     email:'manager@abaybank.com' },
      teller:      { id:3, name:'Teller Officer', role:'Teller',      email:'teller@abaybank.com'  },
      loanofficer: { id:4, name:'Loan Officer',   role:'Loan Officer',email:'loan@abaybank.com'    },
      auditor:     { id:5, name:'Audit Officer',  role:'Auditor',     email:'auditor@abaybank.com' },
      hrstaff:     { id:6, name:'HR Officer',     role:'HR Officer',  email:'hr@abaybank.com'      },
    };
    const pwds = {
      admin:'Admin@1234', manager:'Manager@1234', teller:'Teller@1234',
      loanofficer:'Admin@1234', auditor:'Admin@1234', hrstaff:'Admin@1234',
    };

    const key  = (credentials.username || '').toLowerCase().replace(/\s/g,'');
    const user = users[key];
    const ok   = user && pwds[key] === credentials.password;

    if (ok) {
      const fakeToken = btoa(JSON.stringify({ id: user.id, demo: true, exp: Date.now() + this.SESSION_MINS * 60000 }));
      this._saveSession(fakeToken, user);
      if (btn) DOM.loading(btn, false);
      this._redirect();
    } else {
      if (btn) DOM.loading(btn, false);
      this.showLoginError('Invalid username or password. Please try again.');
      this._trackFailed();
    }
  },

  /* ─────────────────────────────────────────
     SESSION HELPERS
  ───────────────────────────────────────── */
  _saveSession(token, user) {
    const expiry = Date.now() + this.SESSION_MINS * 60000;
    localStorage.setItem(this.TOKEN_KEY,  token);
    localStorage.setItem(this.USER_KEY,   JSON.stringify(user));
    localStorage.setItem(this.EXPIRY_KEY, String(expiry));
    localStorage.removeItem('abay_failed_attempts');
    localStorage.removeItem('abay_locked_until');
  },

  /* ─────────────────────────────────────────
     LOGOUT — clears session and goes to login.
     Does NOT call the backend API to avoid any
     re-entrant redirect race conditions.
  ───────────────────────────────────────── */
  logout(message) {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    localStorage.removeItem(this.EXPIRY_KEY);

    if (message) {
      try { sessionStorage.setItem('abay_logout_msg', message); } catch (_) {}
    }

    const loginUrl = this._buildLoginUrl();
    window.location.replace(loginUrl);
  },

  _buildLoginUrl() {
    try {
      if (typeof PathResolver !== 'undefined') {
        return PathResolver.paths.login;
      }
    } catch (_) {}

    // Fallback: calculate from current URL
    const path = window.location.pathname;
    const idx  = path.indexOf('/pages/');
    if (idx !== -1) {
      const base = path.substring(0, idx + 7); // up to /pages/
      return window.location.origin + base + 'authentication/login.html';
    }
    return window.location.origin + '/abay-bank-management-system/frontend/pages/authentication/login.html';
  },

  /* ─────────────────────────────────────────
     GUARD — protects every dashboard page.
     Reads localStorage directly — no helpers needed.
  ───────────────────────────────────────── */
  guard() {
    try {
      var token  = localStorage.getItem('abay_token');
      var expiry = parseInt(localStorage.getItem('abay_expiry') || '0', 10);

      /* no token → send to login */
      if (!token) {
        this._redirectToLogin('Please login to access this page.');
        return false;
      }

      /* token exists but has genuinely expired */
      if (expiry > 0 && Date.now() > expiry) {
        this._redirectToLogin('Your session has expired. Please login again.');
        return false;
      }

      /* valid session — extend, start timer, render user */
      this._extendSession();
      this._startTimer();
      this._renderUser();
      return true;

    } catch (err) {
      console.error('Auth.guard error:', err);
      return true; /* never kick user out on unexpected JS errors */
    }
  },

  /* Redirect to login — no API calls, no race conditions */
  _redirectToLogin(message) {
    try {
      if (message) sessionStorage.setItem('abay_logout_msg', message);
    } catch (_) {}
    window.location.replace(this._buildLoginUrl());
  },

  /* ─────────────────────────────────────────
     SESSION EXTENSION & TIMER
  ───────────────────────────────────────── */
  _extendSession() {
    try {
      const expiry = Date.now() + this.SESSION_MINS * 60000;
      localStorage.setItem(this.EXPIRY_KEY, String(expiry));

      const extend = () => {
        try {
          localStorage.setItem(this.EXPIRY_KEY, String(Date.now() + this.SESSION_MINS * 60000));
        } catch (_) {}
      };

      ['click', 'keydown', 'scroll', 'mousemove'].forEach(ev => {
        document.addEventListener(ev, extend, { passive: true, once: true });
      });
    } catch (_) {}
  },

  _timerStarted: false,
  _startTimer() {
    if (this._timerStarted) return;
    this._timerStarted = true;

    setInterval(() => {
      try {
        var expiry = parseInt(localStorage.getItem(this.EXPIRY_KEY) || '0', 10);
        if (expiry > 0 && Date.now() > expiry) {
          this._redirectToLogin('Your session has expired. Please login again.');
        }
      } catch (_) {}
    }, 60000);
  },

  /* ─────────────────────────────────────────
     RENDER USER INFO IN UI
  ───────────────────────────────────────── */
  _renderUser() {
    try {
      const user = this.getUser();
      if (!user) return;
      document.querySelectorAll('[data-user-name]').forEach(el => { el.textContent = user.name || ''; });
      document.querySelectorAll('[data-user-role]').forEach(el => { el.textContent = user.role || ''; });
      document.querySelectorAll('[data-user-avatar]').forEach(el => {
        el.textContent = (user.name || 'U')[0].toUpperCase();
      });
    } catch (_) {}
  },

  /* ─────────────────────────────────────────
     LOCKOUT TRACKING
  ───────────────────────────────────────── */
  _trackFailed() {
    try {
      const key      = 'abay_failed_attempts';
      const attempts = parseInt(localStorage.getItem(key) || '0', 10) + 1;
      localStorage.setItem(key, String(attempts));
      if (attempts >= 5) {
        localStorage.setItem('abay_locked_until', String(Date.now() + 15 * 60000));
        this.showLoginError('Account temporarily locked for 15 minutes after 5 failed attempts.');
        const btn = document.getElementById('login-btn');
        if (btn) btn.disabled = true;
      }
    } catch (_) {}
  },

  isLocked() {
    try {
      const until = parseInt(localStorage.getItem('abay_locked_until') || '0', 10);
      if (Date.now() < until) {
        const mins = Math.ceil((until - Date.now()) / 60000);
        return `Account locked. Try again in ${mins} minute${mins !== 1 ? 's' : ''}.`;
      }
      localStorage.removeItem('abay_locked_until');
      localStorage.removeItem('abay_failed_attempts');
    } catch (_) {}
    return false;
  },

  /* ─────────────────────────────────────────
     GETTERS
  ───────────────────────────────────────── */
  getUser() {
    try { return JSON.parse(localStorage.getItem(this.USER_KEY) || 'null'); } catch { return null; }
  },
  getToken()   { return localStorage.getItem(this.TOKEN_KEY) || null; },
  isLoggedIn() {
    try {
      return !!this.getToken() && Date.now() < parseInt(localStorage.getItem(this.EXPIRY_KEY) || '0', 10);
    } catch { return false; }
  },
  hasRole(role) {
    try {
      const user  = this.getUser();
      if (!user) return false;
      const roles = Array.isArray(role) ? role : [role];
      return roles.includes(user.role);
    } catch { return false; }
  },

  /* ─────────────────────────────────────────
     REDIRECT AFTER LOGIN
  ───────────────────────────────────────── */
  _redirect() {
    try {
      if (typeof PathResolver !== 'undefined') {
        window.location.href = PathResolver.paths.dashboard;
        return;
      }
    } catch (_) {}

    // Fallback redirect
    const path = window.location.pathname;
    const idx  = path.indexOf('/pages/');
    if (idx !== -1) {
      const base = path.substring(0, idx + 7);
      window.location.href = window.location.origin + base + 'dashboard/dashboard.html';
    } else {
      window.location.href = window.location.origin + '/abay-bank-management-system/frontend/pages/dashboard/dashboard.html';
    }
  },

  /* ─────────────────────────────────────────
     PASSWORD ACTIONS
  ───────────────────────────────────────── */
  async forgotPassword(email) {
    try {
      const btn = document.getElementById('forgot-btn');
      if (btn) DOM.loading(btn, true, 'Sending...');
      if (typeof API !== 'undefined') await API.auth.forgotPassword({ email });
      if (btn) DOM.loading(btn, false);
      Toast.success('If this email is registered, a reset link will be sent.');
      setTimeout(() => window.location.href = 'login.html', 3000);
    } catch (_) {
      Toast.info('Reset link sent (demo mode).');
    }
  },

  async changePassword(current, newPass, confirm) {
    try {
      if (newPass !== confirm) { Toast.error('New passwords do not match.'); return; }
      if (newPass.length < 8)  { Toast.error('Password must be at least 8 characters.'); return; }
      const btn = document.getElementById('change-pass-btn');
      if (btn) DOM.loading(btn, true, 'Updating...');
      if (typeof API !== 'undefined') {
        const res = await API.auth.changePassword({ current_password: current, new_password: newPass });
        if (btn) DOM.loading(btn, false);
        if (res?.success) Toast.success('Password changed successfully.');
        else Toast.error(res?.message || 'Failed.');
      } else {
        if (btn) DOM.loading(btn, false);
        Toast.success('Password changed (demo mode).');
      }
    } catch (_) {
      Toast.error('Could not change password. Please try again.');
    }
  },

  _sleep: ms => new Promise(resolve => setTimeout(resolve, ms)),
};

/* ─────────────────────────────────────────
   LOGIN PAGE INIT
   NOTE: login.html manages its own submit handler.
   This block only handles shared utilities (lockout
   message, logout message, password toggle, remember-me).
───────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  if (!loginForm) return;

  // Show lockout message
  const locked = Auth.isLocked();
  if (locked) {
    Auth.showLoginError(locked);
    const btn = document.getElementById('login-btn');
    if (btn) btn.disabled = true;
  }

  // Show logout message (set by Auth.logout())
  try {
    const msg = sessionStorage.getItem('abay_logout_msg');
    if (msg && typeof Toast !== 'undefined') {
      Toast.info(msg);
      sessionStorage.removeItem('abay_logout_msg');
    }
  } catch (_) {}

  // Password toggle (data-toggle-password attribute pattern)
  document.querySelectorAll('[data-toggle-password]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      if (!input) return;
      const isText = input.type === 'text';
      input.type = isText ? 'password' : 'text';
      const icon = btn.querySelector('i');
      if (icon) icon.className = isText ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
    });
  });

  // Pre-fill remembered username
  try {
    const remembered = localStorage.getItem('abay_remember');
    if (remembered) {
      const u = document.getElementById('username');
      if (u) u.value = remembered;
      const r = document.getElementById('remember-me');
      if (r) r.checked = true;
    }
  } catch (_) {}
});

/* ─────────────────────────────────────────
   SHOW LOGIN ERROR — works on both login.html
   and the custom login in home pages
───────────────────────────────────────── */
Auth.showLoginError = function(msg) {
  // Try the error-alert element (login.html structure)
  const alertEl = document.getElementById('error-alert');
  const msgEl   = document.getElementById('error-message');
  if (alertEl && msgEl) {
    msgEl.textContent = msg;
    alertEl.classList.add('show');
    alertEl.style.display = 'flex';
    setTimeout(() => alertEl.classList.remove('show'), 5000);
    return;
  }

  // Try the legacy login-error element
  const el = document.getElementById('login-error');
  if (el) {
    const legacyMsg = el.querySelector('.alert-message');
    if (legacyMsg) legacyMsg.textContent = msg;
    else el.textContent = msg;
    el.classList.remove('d-none');
    el.style.display = 'flex';
    return;
  }

  // Fallback to Toast
  try {
    if (typeof Toast !== 'undefined') Toast.error(msg, 'Login Failed');
  } catch (_) {
    alert(msg);
  }
};
