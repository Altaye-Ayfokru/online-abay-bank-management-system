/* ============================================================
   ABAY BANK — CHARTS CONFIGURATION
   ============================================================ */
'use strict';

/* ── Global Chart defaults ── */
const ChartConfig = {
  apply() {
    if (!window.Chart) return;
    Chart.defaults.font.family = 'Inter, sans-serif';
    Chart.defaults.font.size   = 12;
    Chart.defaults.color       = '#64748b';
    Chart.defaults.plugins.legend.labels.boxWidth  = 10;
    Chart.defaults.plugins.legend.labels.boxHeight = 10;
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15,23,42,.9)';
    Chart.defaults.plugins.tooltip.padding         = 12;
    Chart.defaults.plugins.tooltip.cornerRadius    = 8;
    Chart.defaults.plugins.tooltip.titleFont       = { size: 13, weight: 'bold' };
    Chart.defaults.plugins.tooltip.bodyFont        = { size: 12 };
    Chart.defaults.animation.duration              = 800;
    Chart.defaults.animation.easing                = 'easeInOutQuart';
  },

  /* ── Bar chart factory ── */
  bar(ctx, labels, datasets, opts = {}) {
    return new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets: datasets.map((d,i) => ({
        borderRadius: 6, borderSkipped: false,
        backgroundColor: Colors.chartPalette[i % Colors.chartPalette.length],
        ...d,
      }))},
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top' }, ...opts.plugins },
        scales: {
          x: { grid: { display: false } },
          y: { grid: { color: 'rgba(0,0,0,.05)' }, beginAtZero: true },
          ...opts.scales,
        },
        ...opts,
      },
    });
  },

  /* ── Line chart factory ── */
  line(ctx, labels, datasets, opts = {}) {
    return new Chart(ctx, {
      type: 'line',
      data: { labels, datasets: datasets.map((d,i) => ({
        borderWidth: 2.5, tension: 0.4, fill: false, pointRadius: 4, pointHoverRadius: 6,
        borderColor: Colors.chartPalette[i % Colors.chartPalette.length],
        pointBackgroundColor: Colors.chartPalette[i % Colors.chartPalette.length],
        backgroundColor: Colors.chartPalette[i % Colors.chartPalette.length] + '15',
        ...d,
      }))},
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top' }, ...opts.plugins },
        scales: {
          x: { grid: { display: false } },
          y: { grid: { color: 'rgba(0,0,0,.05)' }, beginAtZero: true },
          ...opts.scales,
        },
        ...opts,
      },
    });
  },

  /* ── Doughnut / Pie ── */
  doughnut(ctx, labels, data, opts = {}) {
    return new Chart(ctx, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: Colors.chartPalette, borderWidth: 0, hoverOffset: 8 }] },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '65%',
        plugins: { legend: { position: 'bottom' }, ...opts.plugins },
        ...opts,
      },
    });
  },

  pie(ctx, labels, data, opts = {}) {
    return new Chart(ctx, {
      type: 'pie',
      data: { labels, datasets: [{ data, backgroundColor: Colors.chartPalette, borderWidth: 2, borderColor: '#fff' }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' }, ...opts.plugins },
        ...opts,
      },
    });
  },

  /* ── Area chart ── */
  area(ctx, labels, dataset, opts = {}) {
    return new Chart(ctx, {
      type: 'line',
      data: { labels, datasets: [{
        data: dataset, borderWidth: 2.5, tension: 0.4, fill: true,
        borderColor: '#1a3c5e', backgroundColor: 'rgba(26,60,94,.1)',
        pointBackgroundColor: '#1a3c5e', pointRadius: 4, pointHoverRadius: 6,
        ...opts.dataset,
      }]},
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, ...opts.plugins },
        scales: {
          x: { grid: { display: false } },
          y: { grid: { color: 'rgba(0,0,0,.05)' }, beginAtZero: true },
          ...opts.scales,
        },
        ...opts,
      },
    });
  },

  /* ── Gauge (uses Doughnut) ── */
  gauge(ctx, value, max = 100, opts = {}) {
    const pct   = Math.min(value / max, 1);
    const color = pct < 0.5 ? '#10b981' : pct < 0.75 ? '#f59e0b' : '#ef4444';
    return new Chart(ctx, {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [value, max - value],
          backgroundColor: [color, '#e2e8f0'],
          borderWidth: 0, hoverOffset: 0,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        cutout: '80%', circumference: 180, rotation: -90,
        plugins: { legend: { display: false }, tooltip: { enabled: false }, ...opts.plugins },
        ...opts,
      },
    });
  },
};

document.addEventListener('DOMContentLoaded', () => ChartConfig.apply());
