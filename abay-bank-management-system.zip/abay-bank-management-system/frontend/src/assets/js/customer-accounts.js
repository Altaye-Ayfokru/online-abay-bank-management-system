/* ============================================================
   ABAY BANK — CUSTOMER ACCOUNTS JS
============================================================ */
'use strict';

const CustomerAccounts = {
  accounts: [],

  async init() {
    if (!CustomerAuth.guard()) return;
    await this.loadAccounts();
    this._bindEvents();
  },

  async loadAccounts() {
    const res = await CustomerAuth.api('/customer/accounts');
    this.accounts = res?.success ? res.data : this._demoAccounts();
    this._renderCards();
  },

  _renderCards() {
    const grid = document.getElementById('accounts-grid');
    if (!grid) return;
    grid.innerHTML = this.accounts.map(a => `
      <div class="account-card account-${a.account_type.toLowerCase().replace(' ','-')}">
        <div class="acc-card-header">
          <div class="acc-type-label">${a.account_type}</div>
          <span class="acc-status-dot ${a.status === 'Active' ? 'active' : 'inactive'}"></span>
        </div>
        <div class="acc-number">${a.account_number}</div>
        <div class="acc-balance-label">Available Balance</div>
        <div class="acc-balance">ETB ${Number(a.balance).toLocaleString('en',{minimumFractionDigits:2})}</div>
        <div class="acc-actions">
          <button onclick="CustomerAccounts.viewStatement(${a.id})" class="btn-acc-action">
            <i class="fa-solid fa-file-lines"></i> Statement
          </button>
          <button onclick="CustomerAccounts.quickTransfer(${a.id})" class="btn-acc-action">
            <i class="fa-solid fa-paper-plane"></i> Transfer
          </button>
        </div>
        <div class="acc-branch">${a.branch_name || 'Abay Bank'}</div>
      </div>`).join('');
  },

  async viewStatement(accountId) {
    const from = document.getElementById('stmt-from')?.value || new Date().toISOString().slice(0,7) + '-01';
    const to   = document.getElementById('stmt-to')?.value   || new Date().toISOString().slice(0,10);
    const res  = await CustomerAuth.api(`/customer/accounts/${accountId}/statement?from=${from}&to=${to}`);
    const data = res?.success ? res.data : this._demoStatement(accountId);
    this._renderStatement(data);
  },

  _renderStatement(d) {
    const modal = document.getElementById('stmt-modal');
    if (!modal) { window.location.href = `statement.html?account_id=${d.account?.id}`; return; }
    modal.style.display = 'flex';
    const tbody = document.getElementById('stmt-tbody');
    if (!tbody) return;
    tbody.innerHTML = (d.transactions || []).map(t => {
      const cr = ['Deposit','Transfer In','Loan Disbursement'].includes(t.type);
      return `<tr>
        <td>${t.created_at?.substring(0,10)}</td>
        <td>${t.reference}</td>
        <td>${t.description}</td>
        <td class="${cr?'credit':'debit'}">${cr ? '+ ETB ' + Number(t.amount).toLocaleString('en',{minimumFractionDigits:2}) : ''}</td>
        <td class="${!cr?'debit':''}">${!cr ? '- ETB ' + Number(t.amount).toLocaleString('en',{minimumFractionDigits:2}) : ''}</td>
        <td>ETB ${Number(t.balance_after).toLocaleString('en',{minimumFractionDigits:2})}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="6" class="empty-row">No transactions in this period</td></tr>';
  },

  quickTransfer(accountId) { window.location.href = `transfer.html?from=${accountId}`; },

  _bindEvents() {
    document.getElementById('refresh-accounts')?.addEventListener('click', () => this.loadAccounts());
  },

  _demoAccounts() {
    return [
      { id:1, account_number:'10010000000001', account_type:'Savings',  balance:84500,  status:'Active', branch_name:'Bole Branch' },
      { id:2, account_number:'20010000000001', account_type:'Current',  balance:40000,  status:'Active', branch_name:'Bole Branch' },
    ];
  },

  _demoStatement(id) {
    return { account:{ id }, transactions:[
      { created_at:'2026-08-04', reference:'DEP-001', description:'Salary Credit', type:'Deposit', amount:15000, balance_after:84500 },
      { created_at:'2026-08-02', reference:'WDR-001', description:'ATM Withdrawal', type:'Withdrawal', amount:5000, balance_after:69500 },
    ]};
  },
};

document.addEventListener('DOMContentLoaded', () => CustomerAccounts.init());
