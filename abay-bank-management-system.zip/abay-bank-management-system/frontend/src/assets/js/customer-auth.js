/* ============================================================
   ABAY BANK — CUSTOMER PORTAL AUTH
   Handles customer session, guard, login/logout.
   Completely separate from staff Auth object.
============================================================ */
'use strict';

const CustomerAuth = {
  TOKEN_KEY:   'abay_cust_token',
  USER_KEY:    'abay_cust_user',
  EXPIRY_KEY:  'abay_cust_expiry',
  SESSION_MINS: 120,

  /* ── Save session ── */
  save(token, customer) {
    const expiry = Date.now() + this.SESSION_MINS * 60000;
    localStorage.setItem(this.TOKEN_KEY,  token);
    localStorage.setItem(this.USER_KEY,   JSON.stringify(customer));
    localStorage.setItem(this.EXPIRY_KEY, String(expiry));
  },

  /* ── Clear session ── */
  clear() {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    localStorage.removeItem(this.EXPIRY_KEY);
  },

  /* ── Check logged in ── */
  isLoggedIn() {
    const token  = localStorage.getItem(this.TOKEN_KEY);
    const expiry = parseInt(localStorage.getItem(this.EXPIRY_KEY) || '0', 10);
    return !!token && Date.now() < expiry;
  },

  /* ── Get customer data ── */
  getCustomer() {
    try { return JSON.parse(localStorage.getItem(this.USER_KEY) || 'null'); } catch { return null; }
  },

  getToken() { return localStorage.getItem(this.TOKEN_KEY) || null; },

  /* ── Guard: redirect to login if not authenticated ── */
  guard() {
    if (!this.isLoggedIn()) {
      sessionStorage.setItem('cust_redirect', window.location.href);
      window.location.replace('login.html');
      return false;
    }
    this._renderUser();
    this._extendSession();
    return true;
  },

  /* ── Redirect logged-in user away from login page ── */
  guardPublic() {
    if (this.isLoggedIn()) {
      window.location.replace('dashboard.html');
    }
  },

  /* ── Logout ── */
  logout(msg) {
    this.clear();
    if (msg) sessionStorage.setItem('cust_logout_msg', msg);
    window.location.replace('login.html');
  },

  /* ── Render customer name/avatar in UI ── */
  _renderUser() {
    const c = this.getCustomer();
    if (!c) return;
    document.querySelectorAll('[data-cust-name]').forEach(el => el.textContent = c.name || '');
    document.querySelectorAll('[data-cust-email]').forEach(el => el.textContent = c.email || '');
    document.querySelectorAll('[data-cust-avatar]').forEach(el => el.textContent = (c.name || 'C')[0].toUpperCase());
    const badge = document.getElementById('kyc-badge');
    if (badge) {
      badge.textContent = c.kyc_status || 'Pending';
      badge.className = `kyc-badge kyc-${(c.kyc_status || 'pending').toLowerCase().replace('_','-')}`;
    }
  },

  /* ── Extend session on activity ── */
  _extendSession() {
    const extend = () => localStorage.setItem(this.EXPIRY_KEY, String(Date.now() + this.SESSION_MINS * 60000));
    ['click','keydown','scroll'].forEach(e => document.addEventListener(e, extend, {passive:true, once:true}));
  },

  /* ── API call helper with customer JWT ── */
  async api(endpoint, options = {}) {
    const token = this.getToken();
    const base  = this._apiBase();
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...options,
    };
    try {
      const res = await fetch(base + endpoint, config);
      if (res.status === 401) { this.logout('Session expired. Please login again.'); return null; }
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) return null;
      return await res.json();
    } catch (e) {
      console.warn('CustomerAuth.api error:', e.message);
      return null;
    }
  },

  _apiBase() {
    const path = window.location.pathname;
    const idx  = path.indexOf('/frontend/');
    return idx !== -1
      ? window.location.origin + path.substring(0, idx) + '/api'
      : window.location.origin + '/abay-bank-management-system/api';
  },
};
