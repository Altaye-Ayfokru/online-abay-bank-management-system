/* ============================================================
   ABAY BANK — CUSTOMER DASHBOARD JS
============================================================ */
'use strict';

const CustomerDashboard = {
  data: null,

  async init() {
    if (!CustomerAuth.guard()) return;
    this._renderGreeting();
    await this._loadDashboard();
    this._startClock();
  },

  _renderGreeting() {
    const c    = CustomerAuth.getCustomer();
    const h    = new Date().getHours();
    const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    const el   = document.getElementById('greeting');
    if (el) el.textContent = `${greet}, ${(c?.name || 'Customer').split(' ')[0]}!`;
  },

  async _loadDashboard() {
    const res = await CustomerAuth.api('/customer/dashboard');
    if (!res?.success) { this._loadDemo(); return; }
    const d = res.data;
    this.data = d;

    // Total balance
    this._setText('total-balance', 'ETB ' + this._fmt(d.total_balance));

    // Accounts summary bar
    const accBar = document.getElementById('accounts-bar');
    if (accBar && d.accounts) {
      accBar.innerHTML = d.accounts.map(a =>
        `<div class="acc-pill">
          <span class="acc-type">${a.account_type}</span>
          <span class="acc-num">${a.account_number.slice(-4)}</span>
          <span class="acc-bal">ETB ${this._fmt(a.balance)}</span>
        </div>`
      ).join('');
    }

    // Recent transactions
    this._renderTransactions(d.recent_transactions || []);

    // Loan summary
    if (d.active_loans) {
      this._setText('loan-count',   d.active_loans.count);
      this._setText('loan-outstanding', 'ETB ' + this._fmt(d.active_loans.total));
    }

    // Notifications badge
    const badge = document.getElementById('notif-badge');
    if (badge) badge.textContent = d.unread_notifications > 0 ? d.unread_notifications : '';
  },

  _loadDemo() {
    this._setText('total-balance', 'ETB 84,500.00');
    this._setText('loan-count',    '1');
    this._setText('loan-outstanding', 'ETB 67,000.00');
    this._renderTransactions([
      { type:'Deposit',    amount:15000, description:'Salary Credit',    created_at:'2026-08-04', balance_after:84500 },
      { type:'Withdrawal', amount:5000,  description:'Cash Withdrawal',  created_at:'2026-08-02', balance_after:69500 },
      { type:'Transfer Out',amount:8000, description:'Transfer to Tigist',created_at:'2026-08-03', balance_after:71500 },
    ]);
  },

  _renderTransactions(txns) {
    const tbody = document.getElementById('recent-txns');
    if (!tbody) return;
    if (!txns.length) { tbody.innerHTML = '<tr><td colspan="5" class="empty-row">No transactions yet</td></tr>'; return; }
    tbody.innerHTML = txns.map(t => {
      const isCredit = ['Deposit','Transfer In','Loan Disbursement'].includes(t.type);
      const sign     = isCredit ? '+' : '-';
      const cls      = isCredit ? 'credit' : 'debit';
      const icon     = isCredit ? 'fa-arrow-down' : 'fa-arrow-up';
      return `<tr>
        <td><div class="txn-icon ${cls}"><i class="fa-solid ${icon}"></i></div></td>
        <td><div class="txn-desc">${t.description || t.type}</div><div class="txn-date">${t.created_at?.substring(0,10)}</div></td>
        <td><span class="txn-type-badge">${t.type}</span></td>
        <td class="txn-amount ${cls}">${sign} ETB ${this._fmt(t.amount)}</td>
        <td class="bal-col">ETB ${this._fmt(t.balance_after)}</td>
      </tr>`;
    }).join('');
  },

  _startClock() {
    const update = () => {
      const now = new Date();
      const el  = document.getElementById('live-clock');
      if (el) el.textContent = now.toLocaleTimeString('en-GB');
      const de = document.getElementById('live-date');
      if (de) de.textContent = now.toLocaleDateString('en-GB', {weekday:'long',day:'numeric',month:'long',year:'numeric'});
    };
    update();
    setInterval(update, 1000);
  },

  _setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; },
  _fmt(n) { return Number(n || 0).toLocaleString('en', {minimumFractionDigits:2, maximumFractionDigits:2}); },
};

document.addEventListener('DOMContentLoaded', () => CustomerDashboard.init());
