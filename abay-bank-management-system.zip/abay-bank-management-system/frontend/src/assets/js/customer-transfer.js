/* ============================================================
   ABAY BANK — CUSTOMER TRANSFER JS
============================================================ */
'use strict';

const CustomerTransfer = {
  accounts:     [],
  beneficiaries:[],
  step:         1,

  async init() {
    if (!CustomerAuth.guard()) return;
    await this._loadData();
    this._bindEvents();
    const params = new URLSearchParams(window.location.search);
    if (params.get('from')) {
      const sel = document.getElementById('from-account');
      if (sel) sel.value = params.get('from');
    }
  },

  async _loadData() {
    const [accRes, benRes] = await Promise.all([
      CustomerAuth.api('/customer/accounts'),
      CustomerAuth.api('/customer/beneficiaries'),
    ]);
    this.accounts      = accRes?.success  ? accRes.data  : [];
    this.beneficiaries = benRes?.success  ? benRes.data  : [];
    this._renderFromAccounts();
    this._renderBeneficiaries();
  },

  _renderFromAccounts() {
    const sel = document.getElementById('from-account');
    if (!sel) return;
    sel.innerHTML = this.accounts.filter(a => a.status === 'Active').map(a =>
      `<option value="${a.id}">
        ${a.account_type} — ${a.account_number} (ETB ${Number(a.balance).toLocaleString('en',{minimumFractionDigits:2})})
      </option>`
    ).join('') || '<option disabled>No active accounts</option>';
    this._updateBalance();
  },

  _renderBeneficiaries() {
    const list = document.getElementById('beneficiary-list');
    if (!list) return;
    if (!this.beneficiaries.length) {
      list.innerHTML = '<div class="empty-ben">No saved beneficiaries. Add one below.</div>';
      return;
    }
    list.innerHTML = this.beneficiaries.map(b =>
      `<div class="ben-card ${b.is_favorite?'fav':''}" onclick="CustomerTransfer.selectBeneficiary('${b.account_number}','${b.account_name}','${b.bank_name}')">
        <div class="ben-avatar">${b.nickname[0].toUpperCase()}</div>
        <div class="ben-info">
          <div class="ben-nick">${b.nickname}</div>
          <div class="ben-acct">${b.account_number} · ${b.bank_name}</div>
        </div>
        ${b.is_favorite ? '<i class="fa-solid fa-star ben-star"></i>' : ''}
        <button class="btn-del-ben" onclick="event.stopPropagation();CustomerTransfer.deleteBeneficiary(${b.id})" title="Remove">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>`
    ).join('');
  },

  selectBeneficiary(acctNo, acctName, bank) {
    const f = document.getElementById('to-account-number');
    const n = document.getElementById('to-account-name');
    const b = document.getElementById('to-bank-name');
    if (f) f.value = acctNo;
    if (n) n.value = acctName;
    if (b) b.value = bank;
    this._lookupAccount(acctNo);
  },

  async _lookupAccount(acctNo) {
    // In production: call /api/accounts/lookup?number=...
    // For demo: just show the number
    const el = document.getElementById('receiver-info');
    if (el) el.innerHTML = `<i class="fa-solid fa-circle-check" style="color:#10b981"></i> Account found: <strong>${acctNo}</strong>`;
  },

  _updateBalance() {
    const sel  = document.getElementById('from-account');
    const disp = document.getElementById('available-balance');
    if (!sel || !disp) return;
    const acc = this.accounts.find(a => a.id == sel.value);
    if (acc) disp.textContent = 'Available: ETB ' + Number(acc.balance).toLocaleString('en',{minimumFractionDigits:2});
  },

  async submitTransfer(e) {
    e.preventDefault();
    const type   = document.getElementById('transfer-type')?.value || 'own';
    const fromId = parseInt(document.getElementById('from-account')?.value || '0');
    const amount = parseFloat(document.getElementById('transfer-amount')?.value || '0');
    const desc   = document.getElementById('transfer-desc')?.value || '';
    const btn    = document.getElementById('transfer-btn');

    if (!fromId || amount <= 0) { this._showError('Please fill all required fields.'); return; }

    const payload = { transfer_type: type, from_account_id: fromId, amount, description: desc };

    if (type === 'own') {
      payload.to_account_id = parseInt(document.getElementById('to-own-account')?.value || '0');
    } else {
      payload.to_account_number = document.getElementById('to-account-number')?.value || '';
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="btn-spinner"></span> Processing...';

    const res = await CustomerAuth.api('/customer/transfer', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Money';

    if (res?.success) {
      this._showSuccess(`Transfer successful! Reference: ${res.data.reference}`);
      document.getElementById('transfer-form')?.reset();
      setTimeout(() => window.location.href = 'dashboard.html', 2500);
    } else {
      this._showError(res?.message || 'Transfer failed. Please try again.');
    }
  },

  async deleteBeneficiary(id) {
    if (!confirm('Remove this beneficiary?')) return;
    await CustomerAuth.api(`/customer/beneficiaries/${id}`, { method: 'DELETE' });
    await this._loadData();
  },

  async saveBeneficiary(e) {
    e.preventDefault();
    const data = {
      nickname:       document.getElementById('ben-nickname')?.value,
      account_number: document.getElementById('ben-account')?.value,
      account_name:   document.getElementById('ben-name')?.value,
      bank_name:      document.getElementById('ben-bank')?.value || 'Abay Bank',
    };
    const res = await CustomerAuth.api('/customer/beneficiaries', { method: 'POST', body: JSON.stringify(data) });
    if (res?.success) { this._showSuccess('Beneficiary saved!'); await this._loadData(); }
    else this._showError(res?.message || 'Failed to save beneficiary.');
  },

  _bindEvents() {
    document.getElementById('from-account')?.addEventListener('change', () => this._updateBalance());
    document.getElementById('transfer-form')?.addEventListener('submit', (e) => this.submitTransfer(e));
    document.getElementById('ben-form')?.addEventListener('submit', (e) => this.saveBeneficiary(e));
  },

  _showError(msg) {
    const el = document.getElementById('transfer-error');
    if (el) { el.textContent = msg; el.style.display = 'flex'; }
    else alert(msg);
  },
  _showSuccess(msg) {
    const el = document.getElementById('transfer-success');
    if (el) { el.textContent = msg; el.style.display = 'flex'; }
    else alert(msg);
  },
};

document.addEventListener('DOMContentLoaded', () => CustomerTransfer.init());
