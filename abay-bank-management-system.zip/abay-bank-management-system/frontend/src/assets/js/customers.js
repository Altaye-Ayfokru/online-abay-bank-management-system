/* ============================================================
   ABAY BANK — CUSTOMERS MODULE
   ============================================================ */
'use strict';

const Customers = {
  table: null,
  data: [],

  init() {
    this.data = DemoData.customers(50);
    this.initTable();
    this.bindEvents();
  },

  initTable() {
    this.table = DataTable.init('customers-table', {
      data: this.data,
      perPage: 10,
      columns: [
        { key: 'id',       label: 'Customer ID', class: 'cell-account',
          render: (v, row) => `<a href="${window.BASE_URL || ''}/customers/profile?id=${row.id}" class="text-primary fw-semibold">${v}</a>` },
        { key: 'name',     label: 'Name',
          render: (v, row) => `<div class="cell-user">
            <div class="avatar avatar-sm bg-primary text-white">${Format.initials(v)}</div>
            <div class="user-details"><div class="user-name">${v}</div><div class="user-id">${row.email}</div></div>
          </div>` },
        { key: 'phone',    label: 'Phone' },
        { key: 'branch',   label: 'Branch' },
        { key: 'balance',  label: 'Balance', class: 'amount',
          render: v => Format.currency(v) },
        { key: 'status',   label: 'Status',
          render: v => `<span class="${Colors.badge(v)} badge-dot">${v}</span>` },
        { key: 'joinDate', label: 'Joined', render: v => Format.date(v) },
        { key: 'id',       label: 'Actions', class: 'text-right',
          render: (v, row) => `<div class="table-actions">
            <button class="action-btn view" data-tooltip="View" onclick="Customers.view('${row.id}')"><i class="fa-solid fa-eye"></i></button>
            <button class="action-btn edit" data-tooltip="Edit" onclick="Customers.edit('${row.id}')"><i class="fa-solid fa-pen"></i></button>
            <button class="action-btn delete" data-tooltip="Delete" onclick="Customers.delete('${row.id}')"><i class="fa-solid fa-trash"></i></button>
          </div>` },
      ],
    });
  },

  bindEvents() {
    document.getElementById('add-customer-btn')?.addEventListener('click', () => Modal.open('customer-modal'));
    document.getElementById('export-customers-btn')?.addEventListener('click', () => Exporter.toCSV(this.data, 'customers'));
    document.getElementById('customer-form')?.addEventListener('submit', e => { e.preventDefault(); this.save(e.target); });
    document.getElementById('customer-filter-status')?.addEventListener('change', e => this.filterByStatus(e.target.value));
  },

  view(id) { window.location.href = `${window.BASE_URL || ''}/customers/profile?id=${id}`; },

  edit(id) {
    const customer = this.data.find(c => c.id === id);
    if (!customer) return;
    document.getElementById('modal-title').textContent = 'Edit Customer';
    Object.entries(customer).forEach(([key, val]) => {
      const field = document.getElementById(`customer-${key}`) || document.querySelector(`[name="${key}"]`);
      if (field) field.value = val;
    });
    Modal.open('customer-modal');
  },

  delete(id) {
    Confirm.show(`Are you sure you want to delete customer ${id}? This action cannot be undone.`, () => {
      this.data = this.data.filter(c => c.id !== id);
      this.table?.refresh(this.data);
      Toast.success(`Customer ${id} deleted successfully.`);
    }, { title: 'Delete Customer', confirmText: 'Delete', type: 'danger' });
  },

  save(form) {
    const rules = {
      'customer-name':    { required: true, alpha: true, minLen: 3 },
      'customer-email':   { required: true, email: true },
      'customer-phone':   { required: true, phone: true },
      'customer-national-id': { required: true, nationalId: true },
    };
    if (!Validate.form(form, rules)) return;

    const btn = form.querySelector('[type="submit"]');
    DOM.loading(btn, true, 'Saving...');
    setTimeout(() => {
      DOM.loading(btn, false);
      Modal.close('customer-modal');
      Toast.success('Customer saved successfully.');
      form.reset();
    }, 800);
  },

  filterByStatus(status) {
    const filtered = status ? this.data.filter(c => c.status === status) : this.data;
    this.table?.refresh(filtered);
  },

  updateKYC(id, status) {
    const customer = this.data.find(c => c.id === id);
    if (customer) {
      customer.kycStatus = status;
      Toast.success(`KYC ${status} for customer ${id}`);
    }
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('customers-table') || document.getElementById('customer-form')) {
    Customers.init();
  }
});
