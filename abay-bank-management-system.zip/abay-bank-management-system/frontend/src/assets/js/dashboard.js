/* ============================================================
   ABAY BANK — DASHBOARD
   ============================================================ */
'use strict';

const Dashboard = {
  charts: {},

  init() {
    if (!document.getElementById('dashboard-page')) return;
    /* Auth guard is handled by the inline script in dashboard.html — don't call it again here */
    this.loadStats();
    this.initRevenueChart();
    this.initTransactionChart();
    this.initBranchChart();
    this.loadRecentTransactions();
    this.loadRecentActivities();
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);
    setInterval(() => this.loadStats(), 60000);
  },

  loadStats() {
    const stats = {
      customers:   { value: 12847, change: +5.2,  label: 'Total Customers' },
      accounts:    { value: 18632, change: +3.1,  label: 'Total Accounts' },
      employees:   { value: 342,   change: +2.0,  label: 'Total Employees' },
      transactions:{ value: 2341,  change: +12.4, label: "Today's Transactions" },
      deposits:    { value: 4820000, change: +8.7, label: "Today's Deposits" },
      withdrawals: { value: 2130000, change: -3.2, label: "Today's Withdrawals" },
      loans:       { value: 1247,  change: +6.8,  label: 'Active Loans' },
      revenue:     { value: 890000, change: +9.1, label: 'Monthly Revenue' },
    };

    Object.entries(stats).forEach(([key, data]) => {
      const valEl    = document.getElementById(`stat-${key}`);
      const changeEl = document.getElementById(`stat-${key}-change`);
      if (valEl) {
        const isCurrency = ['deposits','withdrawals','revenue'].includes(key);
        valEl.textContent = isCurrency ? Format.currency(data.value) : Format.number(data.value);
      }
      if (changeEl) {
        const up = data.change >= 0;
        changeEl.className = `stat-change ${up ? 'up' : 'down'}`;
        changeEl.innerHTML = `<i class="fa-solid fa-arrow-${up ? 'up' : 'down'}"></i> ${Math.abs(data.change)}% from last month`;
      }
    });
  },

  initRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx || !window.Chart) return;
    const labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const deposits    = [3.2,3.8,4.1,3.9,4.5,5.0,4.8,5.3,5.7,4.9,5.5,6.1].map(v => v * 1e6);
    const withdrawals = [2.1,2.5,2.8,2.6,3.0,3.4,3.2,3.6,3.9,3.3,3.7,4.1].map(v => v * 1e6);

    this.charts.revenue = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Deposits',    data: deposits,    backgroundColor: 'rgba(26,60,94,.85)',  borderRadius: 6, borderSkipped: false },
          { label: 'Withdrawals', data: withdrawals, backgroundColor: 'rgba(200,168,75,.85)', borderRadius: 6, borderSkipped: false },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 20, font: { family: 'Inter', size: 12 } } },
          tooltip: { callbacks: { label: ctx => ` ${Format.currency(ctx.raw)}` } },
        },
        scales: {
          x: { grid: { display: false }, ticks: { font: { family: 'Inter', size: 11 } } },
          y: { grid: { color: 'rgba(0,0,0,.05)' }, ticks: { callback: v => Format.currency(v/1e6) + 'M', font: { family: 'Inter', size: 11 } } },
        },
      },
    });
  },

  initTransactionChart() {
    const ctx = document.getElementById('transactionChart');
    if (!ctx || !window.Chart) return;
    const labels = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(); d.setDate(d.getDate() - (6 - i));
      return d.toLocaleDateString('en', { weekday: 'short' });
    });

    this.charts.transaction = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Transactions',
          data: [189, 234, 198, 312, 276, 341, 287],
          borderColor: '#1a3c5e', backgroundColor: 'rgba(26,60,94,.08)',
          borderWidth: 2.5, fill: true, tension: 0.4,
          pointBackgroundColor: '#1a3c5e', pointRadius: 5, pointHoverRadius: 7,
        }, {
          label: 'Amount (ETB)',
          data: [820000, 1050000, 930000, 1340000, 1120000, 1480000, 1250000],
          borderColor: '#c8a84b', backgroundColor: 'rgba(200,168,75,.06)',
          borderWidth: 2.5, fill: true, tension: 0.4,
          pointBackgroundColor: '#c8a84b', pointRadius: 5, pointHoverRadius: 7,
          yAxisID: 'y2',
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 20, font: { family: 'Inter', size: 12 } } },
          tooltip: { callbacks: {
            label: ctx => ctx.datasetIndex === 1
              ? ` ${Format.currency(ctx.raw)}`
              : ` ${Format.number(ctx.raw)} txns`,
          }},
        },
        scales: {
          x: { grid: { display: false }, ticks: { font: { family: 'Inter', size: 11 } } },
          y:  { grid: { color: 'rgba(0,0,0,.05)' }, ticks: { font: { family: 'Inter', size: 11 } } },
          y2: { position: 'right', grid: { display: false },
                ticks: { callback: v => Format.currency(v/1000)+'K', font: { family: 'Inter', size: 11 } } },
        },
      },
    });
  },

  initBranchChart() {
    const ctx = document.getElementById('branchChart');
    if (!ctx || !window.Chart) return;
    this.charts.branch = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Bole', 'Kirkos', 'Arada', 'Lideta', 'Yeka', 'Others'],
        datasets: [{ data: [28, 22, 18, 14, 11, 7], backgroundColor: Colors.chartPalette, borderWidth: 0, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '68%',
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Inter', size: 11 } } },
          tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw}%` } },
        },
      },
    });
  },

  loadRecentTransactions() {
    const tbody = document.getElementById('recent-transactions');
    if (!tbody) return;
    const rows = DemoData.transactions(8);
    tbody.innerHTML = rows.map(t => `
      <tr>
        <td class="cell-account">${t.id}</td>
        <td class="cell-date">${Format.date(t.date)}</td>
        <td><span class="badge badge-${t.type === 'Deposit' ? 'success' : t.type === 'Withdrawal' ? 'danger' : 'info'} badge-dot">${t.type}</span></td>
        <td class="amount ${t.type === 'Deposit' ? 'credit' : 'debit'}">${t.type === 'Deposit' ? '+' : '-'}${Format.currency(t.amount)}</td>
        <td><span class="${Colors.badge(t.status)}">${t.status}</span></td>
        <td><div class="table-actions">
          <button class="action-btn view" data-tooltip="View"><i class="fa-solid fa-eye"></i></button>
        </div></td>
      </tr>`).join('');
  },

  loadRecentActivities() {
    const feed = document.getElementById('activity-feed');
    if (!feed) return;
    const activities = [
      { icon:'fa-user-plus', color:'blue',   text:'New customer <strong>Abebe Bekele</strong> registered',       time:'2 min ago' },
      { icon:'fa-money-bill', color:'green',  text:'Deposit of <strong>ETB 25,000</strong> completed',            time:'8 min ago' },
      { icon:'fa-file-invoice', color:'yellow',text:'Loan application <strong>#L-00234</strong> approved',         time:'15 min ago' },
      { icon:'fa-arrow-right-arrow-left', color:'teal', text:'Transfer of <strong>ETB 8,500</strong> processed',   time:'22 min ago' },
      { icon:'fa-id-card', color:'purple',   text:'KYC verified for <strong>Tigist Haile</strong>',              time:'35 min ago' },
      { icon:'fa-circle-xmark', color:'red', text:'Withdrawal request <strong>#W-00891</strong> rejected',        time:'1 hr ago' },
    ];
    feed.innerHTML = activities.map(a => `
      <div class="activity-item">
        <div class="activity-icon stat-icon ${a.color}"><i class="fa-solid ${a.icon}"></i></div>
        <div class="activity-content">
          <div class="activity-text">${a.text}</div>
          <div class="activity-time"><i class="fa-regular fa-clock"></i> ${a.time}</div>
        </div>
      </div>`).join('');
  },

  updateClock() {
    const el = document.getElementById('dashboard-clock');
    if (el) el.textContent = new Date().toLocaleTimeString('en-ET', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  },
};

document.addEventListener('DOMContentLoaded', () => Dashboard.init());
