/* ============================================================
   ABAY BANK — HELPERS & UTILITIES
   ============================================================ */

'use strict';

/* ── Storage Helper ── */
const Store = {
  set(key, value, expireMin = null) {
    const item = { value, ts: Date.now(), exp: expireMin ? Date.now() + expireMin * 60000 : null };
    localStorage.setItem(`abay_${key}`, JSON.stringify(item));
  },
  get(key) {
    try {
      const raw = localStorage.getItem(`abay_${key}`);
      if (!raw) return null;
      const item = JSON.parse(raw);
      if (item.exp && Date.now() > item.exp) { this.remove(key); return null; }
      return item.value;
    } catch { return null; }
  },
  remove(key) { localStorage.removeItem(`abay_${key}`); },
  clear()     { Object.keys(localStorage).filter(k => k.startsWith('abay_')).forEach(k => localStorage.removeItem(k)); },
};

/* ── Pagination Helper ── */
const Paginator = {
  create({ total, page, perPage, onPageChange }) {
    const totalPages = Math.ceil(total / perPage);
    const wrapper = document.createElement('div');
    wrapper.className = 'pagination';

    const mk = (label, pg, disabled = false, active = false) => {
      const btn = document.createElement('button');
      btn.className = `page-btn${active ? ' active' : ''}`;
      btn.innerHTML = label; btn.disabled = disabled;
      if (!disabled && !active) btn.addEventListener('click', () => onPageChange(pg));
      return btn;
    };

    wrapper.appendChild(mk('<i class="fa-solid fa-angles-left"></i>', 1, page === 1));
    wrapper.appendChild(mk('<i class="fa-solid fa-chevron-left"></i>', page - 1, page === 1));

    const range = this._range(page, totalPages);
    range.forEach(p => {
      if (p === '...') {
        const dots = document.createElement('button');
        dots.className = 'page-btn dots'; dots.textContent = '…'; dots.disabled = true;
        wrapper.appendChild(dots);
      } else {
        wrapper.appendChild(mk(p, p, false, p === page));
      }
    });

    wrapper.appendChild(mk('<i class="fa-solid fa-chevron-right"></i>', page + 1, page === totalPages));
    wrapper.appendChild(mk('<i class="fa-solid fa-angles-right"></i>', totalPages, page === totalPages));
    return wrapper;
  },

  _range(current, total) {
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    if (current <= 4) return [1, 2, 3, 4, 5, '...', total];
    if (current >= total - 3) return [1, '...', total-4, total-3, total-2, total-1, total];
    return [1, '...', current-1, current, current+1, '...', total];
  },
};

/* ── DataTable Helper ── */
const DataTable = {
  init(tableId, options = {}) {
    const table = document.getElementById(tableId);
    if (!table) return;

    const { data = [], columns = [], perPage = 10, searchable = true, sortable = true } = options;
    let state = { data: [...data], filtered: [...data], page: 1, perPage, sortCol: null, sortDir: 'asc' };

    const render = () => {
      const start  = (state.page - 1) * state.perPage;
      const slice  = state.filtered.slice(start, start + state.perPage);
      const tbody  = table.querySelector('tbody');
      const info   = table.closest('.card')?.querySelector('.pagination-info');
      const pagDiv = table.closest('.card')?.querySelector('.pagination-wrapper .pagination');

      if (tbody) {
        tbody.innerHTML = slice.length
          ? slice.map(row => `<tr>${columns.map(col => {
              const val = row[col.key] ?? '';
              const cell = col.render ? col.render(val, row) : val;
              return `<td class="${col.class || ''}">${cell}</td>`;
            }).join('')}</tr>`).join('')
          : `<tr><td colspan="${columns.length}" class="text-center py-8"><div class="empty-state" style="padding:var(--space-8) 0"><div class="empty-icon"><i class="fa-solid fa-inbox"></i></div><h3>No Records Found</h3><p>No data matches your search.</p></div></td></tr>`;
      }

      if (info) {
        const from = slice.length ? start + 1 : 0;
        const to   = start + slice.length;
        info.innerHTML = `Showing <strong>${from}–${to}</strong> of <strong>${Format.number(state.filtered.length)}</strong> entries`;
      }

      if (pagDiv) {
        pagDiv.innerHTML = '';
        const pager = Paginator.create({
          total: state.filtered.length, page: state.page, perPage: state.perPage,
          onPageChange: p => { state.page = p; render(); },
        });
        pagDiv.replaceWith(pager);
      }
    };

    /* Search */
    if (searchable) {
      const searchInput = table.closest('.card')?.querySelector('.table-search input');
      searchInput?.addEventListener('input', e => {
        const q = e.target.value.toLowerCase();
        state.filtered = q
          ? state.data.filter(row => columns.some(col => String(row[col.key] ?? '').toLowerCase().includes(q)))
          : [...state.data];
        state.page = 1;
        render();
      });
    }

    /* Sort */
    if (sortable) {
      table.querySelectorAll('thead th.sortable').forEach(th => {
        th.addEventListener('click', () => {
          const col = th.dataset.col;
          if (state.sortCol === col) state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
          else { state.sortCol = col; state.sortDir = 'asc'; }
          table.querySelectorAll('thead th').forEach(t => t.classList.remove('sort-asc','sort-desc'));
          th.classList.add(`sort-${state.sortDir}`);
          state.filtered.sort((a, b) => {
            const va = a[col] ?? ''; const vb = b[col] ?? '';
            return state.sortDir === 'asc' ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
          });
          state.page = 1; render();
        });
      });
    }

    /* Per page */
    const perPageSel = table.closest('.card')?.querySelector('.per-page-select select');
    perPageSel?.addEventListener('change', e => {
      state.perPage = parseInt(e.target.value, 10);
      state.page = 1; render();
    });

    render();
    return { state, render, refresh: newData => { state.data = [...newData]; state.filtered = [...newData]; state.page = 1; render(); } };
  },
};

/* ── Export Helper ── */
const Exporter = {
  toCSV(data, filename = 'export') {
    if (!data?.length) { Toast.warning('No data to export.'); return; }
    const headers = Object.keys(data[0]);
    const rows    = data.map(r => headers.map(h => `"${String(r[h]??'').replace(/"/g,'""')}"`).join(','));
    const csv     = [headers.join(','), ...rows].join('\n');
    this._download(`${filename}.csv`, 'text/csv;charset=utf-8;', '\uFEFF' + csv);
    Toast.success(`Exported ${data.length} records to CSV.`);
  },

  toPrint(title, content) {
    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html><head>
      <title>${title}</title>
      <style>
        body{font-family:Arial,sans-serif;margin:20px;font-size:12px}
        h1{font-size:18px;margin-bottom:10px}
        table{width:100%;border-collapse:collapse;margin-top:10px}
        th,td{border:1px solid #ddd;padding:6px 10px;text-align:left}
        th{background:#1a3c5e;color:white}
        tr:nth-child(even){background:#f8f9fa}
        .header{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #1a3c5e;padding-bottom:10px;margin-bottom:20px}
        .bank-name{font-size:20px;font-weight:bold;color:#1a3c5e}
        .print-date{font-size:11px;color:#666}
      </style>
    </head><body>
      <div class="header">
        <div class="bank-name">🏦 Abay Bank</div>
        <div class="print-date">Printed: ${new Date().toLocaleString()}</div>
      </div>
      <h1>${title}</h1>${content}
    </body></html>`);
    win.document.close(); win.print();
  },

  _download(filename, type, content) {
    const blob = new Blob([content], { type });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  },
};

/* ── Date Helpers ── */
const DateHelper = {
  today()     { return new Date().toISOString().split('T')[0]; },
  todayLabel(){ return new Date().toLocaleDateString('en-ET', { weekday:'long', year:'numeric', month:'long', day:'numeric' }); },
  addDays(d, n){ const dt = new Date(d); dt.setDate(dt.getDate() + n); return dt.toISOString().split('T')[0]; },
  addMonths(d, n){ const dt = new Date(d); dt.setMonth(dt.getMonth() + n); return dt.toISOString().split('T')[0]; },
  diffDays(a, b){ return Math.floor((new Date(b) - new Date(a)) / 86400000); },
  fiscalYear(){ const d = new Date(); return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; },
  quarterRange(q, year) {
    const starts = ['-01-01', '-04-01', '-07-01', '-10-01'];
    const ends   = ['-03-31', '-06-30', '-09-30', '-12-31'];
    return { start: `${year}${starts[q-1]}`, end: `${year}${ends[q-1]}` };
  },
};

/* ── Random Data Generator (Demo) ── */
const DemoData = {
  names: ['Abebe Bekele','Tigist Haile','Kebede Alemu','Almaz Tesfaye','Solomon Girma','Meron Tadesse',
          'Daniel Worku','Hanna Getnet','Yonas Bekele','Sara Mekonnen','Liya Hailu','Abel Desta'],
  branches: ['Addis Ababa Main','Bole','Kirkos','Arada','Lideta','Yeka','Kolfe','Akaki','Nifas Silk'],
  transTypes: ['Deposit','Withdrawal','Transfer','Loan Payment','Interest Credit'],

  customer(id) {
    const n = this.names[id % this.names.length];
    return {
      id: `CUST-${String(id).padStart(5,'0')}`,
      name: n,
      email: n.toLowerCase().replace(' ','.') + '@email.com',
      phone: `091${String(id+10000000).slice(-8)}`,
      account: `1000${String(id).padStart(10,'0')}`,
      branch: this.branches[id % this.branches.length],
      status: ['Active','Active','Active','Inactive','Suspended'][id % 5],
      balance: parseFloat((Math.random() * 500000 + 1000).toFixed(2)),
      joinDate: DateHelper.addDays(DateHelper.today(), -(id * 30 + 60)),
    };
  },

  customers(n = 50) { return Array.from({ length: n }, (_, i) => this.customer(i + 1)); },

  transactions(n = 20) {
    return Array.from({ length: n }, (_, i) => ({
      id: `TXN-${String(100000 + i).padStart(8,'0')}`,
      date: DateHelper.addDays(DateHelper.today(), -i),
      type: this.transTypes[i % this.transTypes.length],
      amount: parseFloat((Math.random() * 50000 + 100).toFixed(2)),
      account: `1000${String(i).padStart(10,'0')}`,
      status: ['Completed','Completed','Completed','Pending','Failed'][i % 5],
      description: `Transaction ${i + 1}`,
    }));
  },
};

/* ── Number Format Helpers ── */
const NumberHelper = {
  emi(principal, ratePercent, months) {
    const r = ratePercent / 100 / 12;
    if (r === 0) return principal / months;
    return principal * r * Math.pow(1 + r, months) / (Math.pow(1 + r, months) - 1);
  },

  compoundInterest(principal, ratePercent, months) {
    const r = ratePercent / 100 / 12;
    return principal * Math.pow(1 + r, months) - principal;
  },

  simpleInterest(principal, ratePercent, months) {
    return principal * (ratePercent / 100) * (months / 12);
  },
};

/* ── Color Helpers ── */
const Colors = {
  chartPalette: ['#1B3A5C','#007A8A','#C8A84B','#10b981','#3b82f6','#ef4444','#f59e0b','#8b5cf6'],
  status: { Active:'success', Inactive:'gray', Pending:'warning', Blocked:'danger', Suspended:'danger', Completed:'success', Failed:'danger' },
  badge(status) { return `badge badge-${this.status[status] || 'gray'}`; },
};
