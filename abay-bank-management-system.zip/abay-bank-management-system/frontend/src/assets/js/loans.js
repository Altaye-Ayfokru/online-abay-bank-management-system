/* ============================================================
   ABAY BANK — LOANS MODULE
   ============================================================ */
'use strict';

const Loans = {
  init() {
    this.loadLoans();
    this.bindEvents();
    this.initEMICalculator();
  },

  loadLoans() {
    const tbody = document.getElementById('loans-table-body');
    if (!tbody) return;
    const types   = ['Personal','Business','Mortgage','Agricultural','Student'];
    const statuses= ['Approved','Pending','Active','Rejected','Completed'];
    const loans   = Array.from({ length: 15 }, (_, i) => ({
      id:         `L-${String(i+1).padStart(5,'0')}`,
      customer:   DemoData.names[i % DemoData.names.length],
      type:       types[i % types.length],
      amount:     parseFloat((Math.random() * 500000 + 10000).toFixed(2)),
      interest:   [12, 14, 9.5, 8, 10.5][i % 5],
      term:       [12, 24, 36, 48, 60][i % 5],
      emi:        0,
      status:     statuses[i % statuses.length],
      applied:    DateHelper.addDays(DateHelper.today(), -(i * 15 + 5)),
      outstanding:parseFloat((Math.random() * 400000 + 5000).toFixed(2)),
    }));
    loans.forEach(l => { l.emi = NumberHelper.emi(l.amount, l.interest, l.term); });

    tbody.innerHTML = loans.map(l => `
      <tr>
        <td class="cell-account fw-semibold text-primary">${l.id}</td>
        <td>
          <div class="cell-user">
            <div class="avatar avatar-sm" style="background:var(--primary);color:white">${Format.initials(l.customer)}</div>
            <div class="user-details"><div class="user-name">${l.customer}</div></div>
          </div>
        </td>
        <td><span class="badge badge-info">${l.type}</span></td>
        <td class="amount fw-semibold">${Format.currency(l.amount)}</td>
        <td>${Format.percent(l.interest)}</td>
        <td>${l.term} months</td>
        <td class="amount">${Format.currency(l.emi)}</td>
        <td class="amount text-warning">${Format.currency(l.outstanding)}</td>
        <td><span class="${Colors.badge(l.status)} badge-dot">${l.status}</span></td>
        <td><div class="table-actions">
          <button class="action-btn view"   data-tooltip="View"    onclick="Loans.view('${l.id}')"><i class="fa-solid fa-eye"></i></button>
          ${l.status === 'Pending' ? `
          <button class="action-btn approve" data-tooltip="Approve" onclick="Loans.approve('${l.id}')"><i class="fa-solid fa-check"></i></button>
          <button class="action-btn delete"  data-tooltip="Reject"  onclick="Loans.reject('${l.id}')"><i class="fa-solid fa-xmark"></i></button>` : ''}
          ${l.status === 'Active'  ? `
          <button class="action-btn edit"   data-tooltip="Payment"  onclick="Loans.payment('${l.id}')"><i class="fa-solid fa-money-bill"></i></button>` : ''}
        </div></td>
      </tr>`).join('');
  },

  bindEvents() {
    document.getElementById('apply-loan-btn')?.addEventListener('click', () => window.location.href = `${window.BASE_URL || ''}/loans/apply`);
    document.getElementById('loan-form')?.addEventListener('submit',     e => { e.preventDefault(); this.submit(e.target); });
    document.getElementById('export-loans-btn')?.addEventListener('click', () => Toast.info('Exporting loans report...'));
  },

  view(id)    { window.location.href = `${window.BASE_URL || ''}/loans/approval?id=${id}`; },
  payment(id) { window.location.href = `${window.BASE_URL || ''}/loans/payment?id=${id}`; },

  approve(id) {
    Confirm.show(`Approve loan ${id}? Funds will be disbursed immediately.`, () => {
      Toast.success(`Loan ${id} approved and disbursement initiated.`);
      this.loadLoans();
    }, { title:'Approve Loan', confirmText:'Approve', type:'success' });
  },

  reject(id) {
    Confirm.show(`Reject loan application ${id}? This cannot be undone.`, () => {
      Toast.warning(`Loan ${id} rejected.`);
      this.loadLoans();
    }, { title:'Reject Loan', confirmText:'Reject', type:'danger' });
  },

  submit(form) {
    const rules = {
      'loan-customer':  { required: true },
      'loan-type':      { required: true },
      'loan-amount':    { required: true, amount: true, min: 1000, max: 5000000 },
      'loan-term':      { required: true, integer: true, min: 3, max: 360 },
      'loan-purpose':   { required: true, minLen: 20 },
    };
    if (!Validate.form(form, rules)) return;
    const btn = form.querySelector('[type="submit"]');
    DOM.loading(btn, true, 'Submitting...');
    setTimeout(() => {
      DOM.loading(btn, false);
      Toast.success('Loan application submitted successfully. Reference: L-' + String(Math.floor(Math.random()*90000)+10000));
      form.reset();
      this.clearEMI();
    }, 1200);
  },

  initEMICalculator() {
    const inputs = ['loan-amount','loan-interest','loan-term'];
    inputs.forEach(id => document.getElementById(id)?.addEventListener('input', () => this.calculateEMI()));
  },

  calculateEMI() {
    const principal = parseFloat(document.getElementById('loan-amount')?.value || 0);
    const rate      = parseFloat(document.getElementById('loan-interest')?.value || 0);
    const months    = parseInt(document.getElementById('loan-term')?.value || 0, 10);
    if (!principal || !rate || !months) return this.clearEMI();

    const emi      = NumberHelper.emi(principal, rate, months);
    const total    = emi * months;
    const interest = total - principal;

    DOM.text('#emi-amount',    Format.currency(emi));
    DOM.text('#emi-total',     Format.currency(total));
    DOM.text('#emi-interest',  Format.currency(interest));
    DOM.text('#emi-principal', Format.currency(principal));

    /* Update pie chart */
    if (window.Chart && document.getElementById('emi-chart')) {
      if (this._emiChart) this._emiChart.destroy();
      this._emiChart = ChartConfig.doughnut(
        document.getElementById('emi-chart'),
        ['Principal','Interest'],
        [parseFloat(principal.toFixed(2)), parseFloat(interest.toFixed(2))],
        { plugins: { tooltip: { callbacks: { label: ctx => ` ${Format.currency(ctx.raw)}` } } } }
      );
    }
  },

  clearEMI() {
    ['emi-amount','emi-total','emi-interest','emi-principal'].forEach(id => DOM.text(`#${id}`, '—'));
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('loans-table-body') || document.getElementById('loan-form')) {
    Loans.init();
  }
});
