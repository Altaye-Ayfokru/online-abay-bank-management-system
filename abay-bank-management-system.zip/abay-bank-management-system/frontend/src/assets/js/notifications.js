/* ============================================================
   ABAY BANK — NOTIFICATIONS
   ============================================================ */
'use strict';

const Notifications = {
  items: [],
  unread: 0,

  init() {
    this.load();
    this.render();
    this.bindEvents();
    setInterval(() => this.poll(), 30000);
  },

  load() {
    this.items = [
      { id:1, type:'transaction', icon:'fa-money-bill-wave',   color:'green',  title:'Deposit Completed',     body:'ETB 15,000 deposited to Acct #100001234',  time: new Date(Date.now()-2*60000),  read:false },
      { id:2, type:'loan',        icon:'fa-file-invoice-dollar',color:'yellow', title:'Loan Application',      body:'Loan #L-00234 is pending your approval',   time: new Date(Date.now()-15*60000), read:false },
      { id:3, type:'alert',       icon:'fa-triangle-exclamation',color:'red',   title:'Security Alert',        body:'Multiple failed login attempts detected',  time: new Date(Date.now()-45*60000), read:false },
      { id:4, type:'system',      icon:'fa-gear',               color:'blue',   title:'System Maintenance',    body:'Scheduled maintenance at 2:00 AM tonight',  time: new Date(Date.now()-2*3600000),read:true  },
      { id:5, type:'transaction', icon:'fa-arrow-right-arrow-left',color:'teal',title:'Transfer Processed',   body:'ETB 8,500 transferred to Acct #200005678',  time: new Date(Date.now()-3*3600000),read:true  },
      { id:6, type:'employee',    icon:'fa-user-check',          color:'purple', title:'Leave Approved',        body:'Your leave request for Dec 25 is approved', time: new Date(Date.now()-5*3600000),read:true  },
    ];
    this.unread = this.items.filter(i => !i.read).length;
  },

  render() {
    const badge   = document.getElementById('notif-badge');
    const list    = document.getElementById('notif-list');
    if (badge) badge.textContent = this.unread > 0 ? this.unread : '';

    if (!list) return;
    list.innerHTML = this.items.length ? this.items.map(n => `
      <div class="notif-item ${n.read ? '' : 'unread'}" data-id="${n.id}" role="button" tabindex="0">
        <div class="notif-icon stat-icon ${n.color}"><i class="fa-solid ${n.icon}"></i></div>
        <div class="notif-content">
          <div class="notif-title">${n.title}</div>
          <div class="notif-body">${n.body}</div>
          <div class="notif-time">${Format.relativeTime(n.time)}</div>
        </div>
        ${!n.read ? '<span class="notif-dot"></span>' : ''}
      </div>`).join('')
    : '<div class="notif-empty"><i class="fa-solid fa-bell-slash"></i><p>No notifications</p></div>';
  },

  bindEvents() {
    /* Bell button */
    const bell   = document.getElementById('notif-bell');
    const panel  = document.getElementById('notif-panel');
    bell?.addEventListener('click', e => { e.stopPropagation(); panel?.classList.toggle('open'); });
    document.addEventListener('click', e => { if (!panel?.contains(e.target) && e.target !== bell) panel?.classList.remove('open'); });

    /* Mark all read */
    document.getElementById('notif-mark-all')?.addEventListener('click', () => {
      this.items.forEach(i => i.read = true); this.unread = 0; this.render();
    });

    /* Click item */
    document.getElementById('notif-list')?.addEventListener('click', e => {
      const item = e.target.closest('.notif-item');
      if (!item) return;
      const id = parseInt(item.dataset.id, 10);
      const notif = this.items.find(i => i.id === id);
      if (notif && !notif.read) { notif.read = true; this.unread = Math.max(0, this.unread - 1); this.render(); }
    });
  },

  poll() {
    /* In production: fetch new notifications from API */
  },

  push(title, body, type = 'info') {
    const n = { id: Date.now(), type, icon: 'fa-bell', color: 'blue', title, body, time: new Date(), read: false };
    this.items.unshift(n); this.unread++; this.render();
    Toast.info(body, title);
  },
};

/* ── Notification Panel CSS (injected) ── */
const notifStyle = document.createElement('style');
notifStyle.textContent = `
.notif-panel {
  position:absolute; top:calc(100% + 8px); right:0;
  width:360px; background:var(--bg-surface);
  border:1px solid var(--border-color); border-radius:var(--radius-xl);
  box-shadow:var(--shadow-xl); z-index:var(--z-dropdown);
  opacity:0; visibility:hidden; transform:translateY(-8px);
  transition:all var(--transition-base); overflow:hidden;
}
.notif-panel.open{opacity:1;visibility:visible;transform:translateY(0)}
.notif-header{display:flex;align-items:center;justify-content:space-between;padding:var(--space-4) var(--space-5);border-bottom:1px solid var(--border-color)}
.notif-header h4{font-size:var(--text-base);font-weight:var(--font-bold);margin:0}
.notif-body{max-height:380px;overflow-y:auto}
.notif-item{display:flex;align-items:flex-start;gap:var(--space-3);padding:var(--space-3) var(--space-5);cursor:pointer;transition:background var(--transition-fast);position:relative;border-bottom:1px solid var(--border-color)}
.notif-item:last-child{border-bottom:none}
.notif-item:hover{background:var(--gray-50)}
.notif-item.unread{background:rgba(26,60,94,.03)}
.notif-icon{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;flex-shrink:0}
.notif-content{flex:1;min-width:0}
.notif-title{font-size:var(--text-sm);font-weight:var(--font-semibold);margin-bottom:2px}
.notif-body{font-size:var(--text-xs);color:var(--text-muted);line-height:1.4}
.notif-time{font-size:10px;color:var(--text-muted);margin-top:4px}
.notif-dot{width:8px;height:8px;border-radius:50%;background:var(--primary);flex-shrink:0;margin-top:6px}
.notif-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:var(--space-10);color:var(--text-muted);gap:var(--space-3);font-size:var(--text-sm)}
.notif-empty i{font-size:2rem}
.notif-footer{padding:var(--space-3) var(--space-5);border-top:1px solid var(--border-color);text-align:center}
.notif-footer a{font-size:var(--text-sm);color:var(--primary);font-weight:var(--font-medium)}
`;
document.head.appendChild(notifStyle);

document.addEventListener('DOMContentLoaded', () => Notifications.init());
