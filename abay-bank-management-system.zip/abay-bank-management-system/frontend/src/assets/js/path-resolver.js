/* ============================================================
   ABAY BANK — PATH RESOLVER
   Automatically calculates correct relative paths from any page
   ============================================================ */

'use strict';

const PathResolver = {
  /* Detect current page depth and return correct relative prefix */
  getPrefix() {
    const path = window.location.pathname;

    // Find how many levels deep we are inside /pages/
    const pagesIdx = path.indexOf('/pages/');
    if (pagesIdx === -1) return '../'; // fallback

    const afterPages = path.substring(pagesIdx + 7); // strip '/pages/'
    // Count folder segments (not counting the filename)
    const segments = afterPages.split('/').filter(s => s && !s.endsWith('.html'));
    const depth = segments.length;

    // depth 0 = pages/index.html           → prefix = ''
    // depth 1 = pages/dashboard/*.html     → prefix = '../'
    // depth 2 = pages/sub/sub/*.html       → prefix = '../../'
    return depth === 0 ? '' : '../'.repeat(depth);
  },

  /* Get absolute path from pages/ folder */
  resolve(relativePath) {
    const prefix = this.getPrefix();
    return prefix + relativePath;
  },

  /* Common paths */
  get paths() {
    const p = this.getPrefix();
    return {
      // Pages
      dashboard: p + 'dashboard/dashboard.html',
      login: p + 'authentication/login.html',
      
      // Customer
      customerList: p + 'customer/customer-list.html',
      customerRegister: p + 'customer/customer-registration.html',
      customerProfile: p + 'customer/customer-profile.html',
      customerKYC: p + 'customer/customer-kyc.html',
      
      // Accounts
      savings: p + 'accounts/savings.html',
      current: p + 'accounts/current.html',
      fixedDeposit: p + 'accounts/fixed-deposit.html',
      accountStatement: p + 'accounts/account-statement.html',
      accountOpening: p + 'accounts/account-opening.html',
      accountClosing: p + 'accounts/account-closing.html',
      atmCards: p + 'accounts/atm-cards.html',
      cheques: p + 'accounts/cheques.html',
      
      // Transactions
      deposit: p + 'transactions/deposit.html',
      withdrawal: p + 'transactions/withdrawal.html',
      transfer: p + 'transactions/transfer.html',
      transactionHistory: p + 'transactions/transaction-history.html',
      transactionApproval: p + 'transactions/transaction-approval.html',
      
      // Loans
      applyLoan: p + 'loans/apply-loan.html',
      loanList: p + 'loans/loan-list.html',
      loanApproval: p + 'loans/loan-approval.html',
      loanPayment: p + 'loans/loan-payment.html',
      
      // Employees
      employees: p + 'employee/employees.html',
      attendance: p + 'employee/attendance.html',
      leave: p + 'employee/leave.html',
      payroll: p + 'employee/payroll.html',
      performance: p + 'employee/performance.html',
      recruitment: p + 'employee/recruitment.html',
      training: p + 'employee/training.html',
      
      // Branch
      branches: p + 'branch/branches.html',
      branchPerformance: p + 'branch/branch-performance.html',
      
      // Reports
      financialReport: p + 'reports/financial-report.html',
      customerReport: p + 'reports/customer-report.html',
      loanReport: p + 'reports/loan-report.html',
      attendanceReport: p + 'reports/attendance-report.html',
      
      // Support
      complaints: p + 'support/complaints.html',
      appointments: p + 'support/appointments.html',
      notifications: p + 'support/notifications.html',
      
      // Administration
      users: p + 'administration/users.html',
      roles: p + 'administration/roles.html',
      auditLog: p + 'administration/audit-log.html',
      security: p + 'administration/security.html',
      documents: p + 'administration/documents.html',
      inventory: p + 'administration/inventory.html',
      backup: p + 'administration/backup.html',
      settings: p + 'administration/settings.html',

      // Customer Portal
      customerPortalLogin: p + 'customer-portal/login.html',
      customerPortalDashboard: p + 'customer-portal/dashboard.html',
      customerPortalAccounts: p + 'customer-portal/my-accounts.html',
      customerPortalTransfer: p + 'customer-portal/transfer.html',
      customerPortalStatement: p + 'customer-portal/statement.html',
      customerPortalLoans: p + 'customer-portal/loans.html',
      customerPortalCards: p + 'customer-portal/cards.html',
      customerPortalCheques: p + 'customer-portal/cheque-book.html',
      customerPortalKYC: p + 'customer-portal/kyc.html',
      customerPortalProfile: p + 'customer-portal/profile.html',
      customerPortalSupport: p + 'customer-portal/support.html',
      accountOpening: p + 'customer-portal/account-opening.html',
      
      // Assets (CSS/JS/Images)
      css: p + '../src/assets/css/',
      js: p + '../src/assets/js/',
      images: p + '../src/assets/images/',
    };
  },

  /* Navigate to a page */
  goto(page) {
    if (this.paths[page]) {
      window.location.href = this.paths[page];
    } else {
      console.error(`PathResolver: Unknown page "${page}"`);
    }
  },
};

// Make it globally available
window.PathResolver = PathResolver;
