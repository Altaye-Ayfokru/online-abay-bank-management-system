/* ============================================================
   ABAY BANK — PAYROLL MODULE
   ============================================================ */
'use strict';

const Payroll = {
  data: [],

  init() {
    this.data = this.generatePayrollData();
    this.loadTable();
    this.bindEvents();
  },

  generatePayrollData() {
    return DemoData.names.map((name, i) => {
      const basic      = parseFloat((Math.random() * 30000 + 8000).toFixed(2));
      const transport  = parseFloat((basic * 0.1).toFixed(2));
      const housing    = parseFloat((basic * 0.15).toFixed(2));
      const other      = parseFloat((basic * 0.05).toFixed(2));
      const gross      = basic + transport + housing + other;
      const pension    = parseFloat((gross * 0.07).toFixed(2));
      const incomeTax  = this.calcTax(gross);
      const totalDeduct= parseFloat((pension + incomeTax).toFixed(2));
      const net        = parseFloat((gross - totalDeduct).toFixed(2));
      return {
        id:        `EMP-${String(i+1).padStart(4,'0')}`,
        name, department: ['Finance','Operations','IT','HR','Loans'][i % 5],
        branch: DemoData.branches[i % DemoData.branches.length],
        basic, transport, housing, other, gross, pension, incomeTax, totalDeduct, net,
        status: i % 7 === 0 ? 'Pending' : 'Processed',
        month: new Date().toLocaleDateString('en',{month:'long',year:'numeric'}),
      };
    });
  },

  calcTax(gross) {
    /* Ethiopian income tax brackets */
    if (gross <= 600)   return 0;
    if (gross <= 1650)  return (gross - 600) * 0.10;
    if (gross <= 3200)  return 105 + (gross - 1650) * 0.15;
    if (gross <= 5250)  return 337.5 + (gross - 3200) * 0.20;
    if (gross <= 7800)  return 747.5 + (gross - 5250) * 0.25;
    if (gross <= 10900) return 1385 + (gross - 7800) * 0.30;
    return 2315 + (gross - 10900) * 0.35;
  },

  loadTable() {
    const tbody = document.getElementById('payroll-table-body');
    if (!tbody) return;
    tbody.innerHTML = this.data.map(p => `
      <tr>
        <td class="cell-account">${p.id}</td>
        <td>
          <div class="cell-user">
            <div class="avatar avatar-sm" style="background:var(--primary);color:white">${Format.initials(p.name)}</div>
            <div class="user-details"><div class="user-name">${p.name}</div><div class="user-id">${p.department}</div></div>
          </div>
        </td>
        <td class="amount">${Format.currency(p.basic)}</td>
        <td class="amount text-success">${Format.currency(p.gross)}</td>
        <td class="amount text-danger">-${Format.currency(p.totalDeduct)}</td>
        <td class="amount fw-bold">${Format.currency(p.net)}</td>
        <td><span class="${Colors.badge(p.status)} badge-dot">${p.status}</span></td>
        <td><div class="table-actions">
          <button class="action-btn view"   data-tooltip="Payslip"   onclick="Payroll.payslip('${p.id}')"><i class="fa-solid fa-file-lines"></i></button>
          <button class="action-btn approve" data-tooltip="Process"   onclick="Payroll.process('${p.id}')"><i class="fa-solid fa-check"></i></button>
        </div></td>
      </tr>`).join('');

    /* Summary */
    const totalGross = this.data.reduce((s, p) => s + p.gross, 0);
    const totalNet   = this.data.reduce((s, p) => s + p.net, 0);
    const totalTax   = this.data.reduce((s, p) => s + p.incomeTax, 0);
    DOM.text('#total-gross',   Format.currency(totalGross));
    DOM.text('#total-net',     Format.currency(totalNet));
    DOM.text('#total-tax',     Format.currency(totalTax));
  },

  payslip(id) {
    const emp = this.data.find(p => p.id === id);
    if (!emp) return;
    Exporter.toPrint(`Payslip — ${emp.name}`, `
      <table>
        <tr><th colspan="2" style="background:#1a3c5e;color:white;text-align:center">Abay Bank — Employee Payslip</th></tr>
        <tr><td>Employee ID</td><td>${emp.id}</td></tr>
        <tr><td>Name</td><td>${emp.name}</td></tr>
        <tr><td>Department</td><td>${emp.department}</td></tr>
        <tr><td>Branch</td><td>${emp.branch}</td></tr>
        <tr><td>Pay Period</td><td>${emp.month}</td></tr>
        <tr><th colspan="2">Earnings</th></tr>
        <tr><td>Basic Salary</td><td>${Format.currency(emp.basic)}</td></tr>
        <tr><td>Transport Allowance</td><td>${Format.currency(emp.transport)}</td></tr>
        <tr><td>Housing Allowance</td><td>${Format.currency(emp.housing)}</td></tr>
        <tr><td>Other Allowances</td><td>${Format.currency(emp.other)}</td></tr>
        <tr style="font-weight:bold"><td>Gross Salary</td><td>${Format.currency(emp.gross)}</td></tr>
        <tr><th colspan="2">Deductions</th></tr>
        <tr><td>Pension (7%)</td><td>-${Format.currency(emp.pension)}</td></tr>
        <tr><td>Income Tax</td><td>-${Format.currency(emp.incomeTax)}</td></tr>
        <tr style="font-weight:bold;color:#10b981"><td>Net Salary</td><td>${Format.currency(emp.net)}</td></tr>
      </table>`);
  },

  process(id) {
    Confirm.show(`Process payroll for employee ${id}?`, () => {
      const emp = this.data.find(p => p.id === id);
      if (emp) { emp.status = 'Processed'; this.loadTable(); }
      Toast.success(`Payroll processed for ${id}.`);
    }, { title:'Process Payroll', confirmText:'Process', type:'success' });
  },

  processAll() {
    Confirm.show('Process payroll for ALL employees this month?', () => {
      this.data.forEach(p => p.status = 'Processed');
      this.loadTable();
      Toast.success('Monthly payroll processed successfully for all employees.');
    }, { title:'Process All Payroll', confirmText:'Process All', type:'success' });
  },

  bindEvents() {
    document.getElementById('process-all-btn')?.addEventListener('click', () => this.processAll());
    document.getElementById('export-payroll-btn')?.addEventListener('click', () => Exporter.toCSV(this.data, 'payroll'));
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('payroll-table-body')) Payroll.init();
});
