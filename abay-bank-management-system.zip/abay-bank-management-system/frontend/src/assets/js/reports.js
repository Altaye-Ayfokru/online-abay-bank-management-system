/* ============================================================
   ABAY BANK — REPORTS MODULE
   ============================================================ */
'use strict';

const Reports = {
  init() {
    this.bindEvents();
    this.initDateFilters();
  },

  bindEvents() {
    document.getElementById('generate-report')?.addEventListener('click', () => this.generate());
    document.getElementById('export-pdf')?.addEventListener('click', () => this.exportPDF());
    document.getElementById('export-excel')?.addEventListener('click', () => this.exportExcel());
    document.getElementById('print-report')?.addEventListener('click', () => window.print());
  },

  initDateFilters() {
    const today = DateHelper.today();
    document.getElementById('report-from')?.setAttribute('value', DateHelper.addDays(today, -30));
    document.getElementById('report-to')?.setAttribute('value', today);
  },

  generate() {
    const type = document.getElementById('report-type')?.value;
    const from = document.getElementById('report-from')?.value;
    const to   = document.getElementById('report-to')?.value;
    if (!type || !from || !to) { Toast.warning('Please select report type and date range.'); return; }
    Toast.info(`Generating ${type} report from ${Format.date(from)} to ${Format.date(to)}...`);
    setTimeout(() => this.renderReport(type, from, to), 1000);
  },

  renderReport(type, from, to) {
    const result = document.getElementById('report-result');
    if (!result) return;
    const reports = {
      financial:   this.financialReport,
      transaction: this.transactionReport,
      customer:    this.customerReport,
      loan:        this.loanReport,
      branch:      this.branchReport,
    };
    const report = reports[type] || reports.financial;
    result.innerHTML = report.call(this, from, to);
    DOM.show(result);
    Toast.success('Report generated successfully.');
  },

  financialReport(from, to) {
    const data = {
      totalDeposits:    4820000,
      totalWithdrawals: 2130000,
      netCashFlow:      2690000,
      loansDisbursed:   8950000,
      loansCollected:   3240000,
      revenue:          890000,
      expenses:         245000,
      netProfit:        645000,
    };
    return `
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-file-invoice-dollar"></i> Financial Report</h3>
        <div class="text-sm text-muted">${Format.date(from)} — ${Format.date(to)}</div></div>
      <div class="card-body">
        <div class="grid-cols-4">
          <div class="stat-card"><div class="stat-content">
            <div class="stat-label">Total Deposits</div><div class="stat-value text-success">${Format.currency(data.totalDeposits)}</div></div></div>
          <div class="stat-card"><div class="stat-content">
            <div class="stat-label">Total Withdrawals</div><div class="stat-value text-danger">${Format.currency(data.totalWithdrawals)}</div></div></div>
          <div class="stat-card"><div class="stat-content">
            <div class="stat-label">Net Cash Flow</div><div class="stat-value text-primary">${Format.currency(data.netCashFlow)}</div></div></div>
          <div class="stat-card"><div class="stat-content">
            <div class="stat-label">Revenue</div><div class="stat-value text-success">${Format.currency(data.revenue)}</div></div></div>
        </div>
        <div class="section-divider"></div>
        <h4 class="mb-4">Cash Flow Breakdown</h4>
        <div style="max-width:800px;height:320px;margin:0 auto"><canvas id="report-chart-1"></canvas></div>
      </div></div>`;
  },

  transactionReport(from, to) {
    const trans = DemoData.transactions(50);
    return `
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-list-check"></i> Transaction Report</h3>
        <div class="text-sm text-muted">${Format.date(from)} — ${Format.date(to)}</div></div>
      <div class="card-body"><div class="table-responsive">
        <table class="data-table"><thead><tr>
          <th>Transaction ID</th><th>Date</th><th>Type</th><th>Amount</th><th>Status</th>
        </tr></thead><tbody>${trans.slice(0,25).map(t => `<tr>
          <td class="cell-account">${t.id}</td><td class="cell-date">${Format.date(t.date)}</td>
          <td><span class="badge badge-info">${t.type}</span></td>
          <td class="amount">${Format.currency(t.amount)}</td>
          <td><span class="${Colors.badge(t.status)}">${t.status}</span></td>
        </tr>`).join('')}</tbody></table></div></div></div>`;
  },

  customerReport(from, to) {
    const custs = DemoData.customers(30);
    return `
      <div class="card"><div class="card-header"><h3><i class="fa-solid fa-users"></i> Customer Report</h3>
        <div class="text-sm text-muted">${Format.date(from)} — ${Format.date(to)}</div></div>
      <div class="card-body"><div class="table-responsive">
        <table class="data-table"><thead><tr>
          <th>Customer ID</th><th>Name</th><th>Branch</th><th>Balance</th><th>Status</th>
        </tr></thead><tbody>${custs.map(c => `<tr>
          <td class="cell-account">${c.id}</td><td>${c.name}</td><td>${c.branch}</td>
          <td class="amount">${Format.currency(c.balance)}</td>
          <td><span class="${Colors.badge(c.status)}">${c.status}</span></td>
        </tr>`).join('')}</tbody></table></div></div></div>`;
  },

  loanReport(from, to) {
    return `<div class="card"><div class="card-body text-center py-8">
      <i class="fa-solid fa-file-invoice-dollar" style="font-size:3rem;color:var(--primary);margin-bottom:var(--space-4)"></i>
      <h3>Loan Report</h3><p class="text-muted">Loans report for ${Format.date(from)} to ${Format.date(to)}</p></div></div>`;
  },

  branchReport(from, to) {
    return `<div class="card"><div class="card-body text-center py-8">
      <i class="fa-solid fa-building" style="font-size:3rem;color:var(--primary);margin-bottom:var(--space-4)"></i>
      <h3>Branch Performance Report</h3><p class="text-muted">Branch performance for ${Format.date(from)} to ${Format.date(to)}</p></div></div>`;
  },

  exportPDF()   { Toast.info('Exporting to PDF...'); },
  exportExcel() { Toast.info('Exporting to Excel...'); },
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('generate-report')) Reports.init();
});
