/* ============================================================
   ABAY BANK — GLOBAL SEARCH
   ============================================================ */
'use strict';

const GlobalSearch = {
  index: [],
  results: [],
  debounceTimer: null,

  init() {
    this.buildIndex();
    this.bindEvents();
  },

  buildIndex() {
    /* In production this would come from an API */
    this.index = [
      ...DemoData.customers(20).map(c => ({ type:'Customer', icon:'fa-user', label: c.name, sub: c.id, url: PathResolver.paths.customerProfile + `?id=${c.id}` })),
      { type:'Page', icon:'fa-gauge',           label:'Dashboard',            sub:'Overview & Statistics',      url: PathResolver.paths.dashboard },
      { type:'Page', icon:'fa-users',            label:'Customer List',         sub:'Manage all customers',       url: PathResolver.paths.customerList },
      { type:'Page', icon:'fa-user-plus',        label:'Register Customer',     sub:'Add new customer',           url: PathResolver.paths.customerRegister },
      { type:'Page', icon:'fa-piggy-bank',       label:'Savings Accounts',      sub:'Manage savings accounts',    url: PathResolver.paths.savings },
      { type:'Page', icon:'fa-building-columns', label:'Current Accounts',      sub:'Manage current accounts',    url: PathResolver.paths.current },
      { type:'Page', icon:'fa-lock',             label:'Fixed Deposits',        sub:'Manage fixed deposits',      url: PathResolver.paths.fixedDeposit },
      { type:'Page', icon:'fa-money-bill-wave',  label:'Deposit',               sub:'Process cash deposit',       url: PathResolver.paths.deposit },
      { type:'Page', icon:'fa-money-bill',       label:'Withdrawal',            sub:'Process cash withdrawal',    url: PathResolver.paths.withdrawal },
      { type:'Page', icon:'fa-right-left',       label:'Fund Transfer',         sub:'Transfer between accounts',  url: PathResolver.paths.transfer },
      { type:'Page', icon:'fa-list',             label:'Transaction History',   sub:'View all transactions',      url: PathResolver.paths.transactionHistory },
      { type:'Page', icon:'fa-file-invoice-dollar', label:'Apply for Loan',     sub:'New loan application',       url: PathResolver.paths.applyLoan },
      { type:'Page', icon:'fa-clipboard-list',   label:'Loan List',             sub:'All loan applications',      url: PathResolver.paths.loanList },
      { type:'Page', icon:'fa-id-card',          label:'ATM Card Management',   sub:'ATM card requests',          url: PathResolver.paths.atmCards },
      { type:'Page', icon:'fa-people-group',     label:'Employees',             sub:'Employee management',        url: PathResolver.paths.employees },
      { type:'Page', icon:'fa-calendar-check',   label:'Attendance',            sub:'Daily attendance tracking',  url: PathResolver.paths.attendance },
      { type:'Page', icon:'fa-wallet',           label:'Payroll',               sub:'Salary processing',          url: PathResolver.paths.payroll },
      { type:'Page', icon:'fa-star',             label:'Performance',           sub:'Employee evaluations',       url: PathResolver.paths.performance },
      { type:'Page', icon:'fa-calendar-days',    label:'Leave Management',      sub:'Leave requests & approvals', url: PathResolver.paths.leave },
      { type:'Page', icon:'fa-building',         label:'Branches',              sub:'Branch management',          url: PathResolver.paths.branches },
      { type:'Page', icon:'fa-chart-line',       label:'Financial Report',      sub:'Revenue & expense reports',  url: PathResolver.paths.financialReport },
      { type:'Page', icon:'fa-file-chart-pie',   label:'Customer Report',       sub:'Customer analytics',         url: PathResolver.paths.customerReport },
      { type:'Page', icon:'fa-users-cog',        label:'User Management',       sub:'Admin user control',         url: PathResolver.paths.users },
      { type:'Page', icon:'fa-shield-halved',    label:'Roles & Permissions',   sub:'Access control',             url: PathResolver.paths.roles },
      { type:'Page', icon:'fa-scroll',           label:'Audit Log',             sub:'System activity logs',       url: PathResolver.paths.auditLog },
      { type:'Page', icon:'fa-gear',             label:'Settings',              sub:'System configuration',       url: PathResolver.paths.settings },
      { type:'Page', icon:'fa-message',          label:'Complaints',            sub:'Customer complaint management', url: PathResolver.paths.complaints },
      { type:'Page', icon:'fa-bell',             label:'Notifications',         sub:'System notifications',       url: PathResolver.paths.notifications },
    ];
  },

  bindEvents() {
    const input   = document.getElementById('global-search-input');
    const results = document.getElementById('search-results-dropdown');
    if (!input) return;

    input.addEventListener('input', e => {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = setTimeout(() => this.search(e.target.value), 200);
    });

    input.addEventListener('focus', () => {
      if (input.value.trim().length >= 1) this.showResults();
    });

    document.addEventListener('click', e => {
      if (!e.target.closest('.navbar-search')) this.hideResults();
    });

    input.addEventListener('keydown', e => {
      if (e.key === 'Escape') { this.hideResults(); input.blur(); }
      if (e.key === 'ArrowDown') this.navigateResults(1);
      if (e.key === 'ArrowUp')   this.navigateResults(-1);
      if (e.key === 'Enter')     this.selectFocused();
    });
  },

  search(query) {
    const q = query.trim().toLowerCase();
    if (q.length < 1) { this.hideResults(); return; }

    this.results = this.index
      .filter(item =>
        item.label.toLowerCase().includes(q) ||
        item.sub.toLowerCase().includes(q) ||
        item.type.toLowerCase().includes(q)
      )
      .slice(0, 8);

    this.renderResults(q);
  },

  renderResults(query) {
    let dropdown = document.getElementById('search-results-dropdown');
    if (!dropdown) {
      dropdown = document.createElement('div');
      dropdown.id = 'search-results-dropdown';
      dropdown.style.cssText = `
        position:absolute;top:calc(100% + 8px);left:0;right:0;
        background:var(--bg-surface);border:1px solid var(--border-color);
        border-radius:var(--radius-lg);box-shadow:var(--shadow-xl);
        z-index:var(--z-dropdown);overflow:hidden;max-height:400px;overflow-y:auto;`;
      document.querySelector('.navbar-search').appendChild(dropdown);
    }

    if (!this.results.length) {
      dropdown.innerHTML = `
        <div style="padding:var(--space-8);text-align:center;color:var(--text-muted)">
          <i class="fa-solid fa-magnifying-glass" style="font-size:1.5rem;margin-bottom:var(--space-3);display:block"></i>
          No results for "<strong>${query}</strong>"
        </div>`;
    } else {
      const byType = this.results.reduce((acc, r) => {
        if (!acc[r.type]) acc[r.type] = [];
        acc[r.type].push(r); return acc;
      }, {});

      dropdown.innerHTML = Object.entries(byType).map(([type, items]) => `
        <div style="padding:var(--space-2) var(--space-4);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text-muted);border-bottom:1px solid var(--border-color)">${type}s</div>
        ${items.map((item, idx) => `
          <a href="${item.url}" class="search-result-item" data-idx="${idx}"
            style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);text-decoration:none;color:var(--text-primary);transition:background var(--transition-fast)"
            onmouseenter="this.style.background='var(--gray-50)'" onmouseleave="this.style.background=''">
            <div style="width:34px;height:34px;background:var(--primary);color:white;border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fa-solid ${item.icon}" style="font-size:.8rem"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:var(--text-sm);font-weight:600">${this.highlight(item.label, query)}</div>
              <div style="font-size:var(--text-xs);color:var(--text-muted)">${item.sub}</div>
            </div>
          </a>`).join('')}
      `).join('');
    }

    dropdown.style.display = 'block';
  },

  highlight(text, query) {
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi');
    return text.replace(regex, '<mark style="background:rgba(200,168,75,.3);border-radius:2px;padding:0 2px">$1</mark>');
  },

  showResults() {
    const d = document.getElementById('search-results-dropdown');
    if (d) d.style.display = 'block';
  },

  hideResults() {
    const d = document.getElementById('search-results-dropdown');
    if (d) d.style.display = 'none';
  },

  navigateResults(dir) {
    const items = document.querySelectorAll('.search-result-item');
    const focused = document.querySelector('.search-result-item.focused');
    let idx = focused ? parseInt(focused.dataset.idx, 10) + dir : 0;
    idx = Math.max(0, Math.min(idx, items.length - 1));
    items.forEach(i => i.classList.remove('focused'));
    items[idx]?.classList.add('focused');
    items[idx]?.scrollIntoView({ block: 'nearest' });
  },

  selectFocused() {
    const focused = document.querySelector('.search-result-item.focused');
    if (focused) focused.click();
  },
};

document.addEventListener('DOMContentLoaded', () => GlobalSearch.init());
