/* ============================================================
   ABAY BANK — FORM VALIDATION
   ============================================================ */

'use strict';

const Validate = {
  /* ── Rules ── */
  email:    v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  phone:    v => /^(\+251|0)[79]\d{8}$/.test(v.replace(/[\s-]/g,'')),
  password: v => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/.test(v),
  numeric:  v => /^\d+(\.\d+)?$/.test(v),
  integer:  v => /^\d+$/.test(v),
  alpha:    v => /^[A-Za-z\s]+$/.test(v),
  alphanum: v => /^[A-Za-z0-9\s]+$/.test(v),
  date:     v => !isNaN(Date.parse(v)),
  minLen:   (v, n) => v.length >= n,
  maxLen:   (v, n) => v.length <= n,
  min:      (v, n) => parseFloat(v) >= n,
  max:      (v, n) => parseFloat(v) <= n,
  required: v => v !== null && v !== undefined && String(v).trim() !== '',
  url:      v => { try { new URL(v); return true; } catch { return false; } },
  nationalId: v => /^[A-Z0-9]{8,20}$/i.test(v),
  accountNo:  v => /^\d{10,18}$/.test(v.replace(/\s/g,'')),
  amount:     v => /^\d+(\.\d{1,2})?$/.test(v) && parseFloat(v) > 0,

  /* ── Form Validator ── */
  form(form, rules) {
    let valid = true;
    this.clearErrors(form);

    for (const [name, constraints] of Object.entries(rules)) {
      const field = form.querySelector(`[name="${name}"]`) || form.querySelector(`#${name}`);
      if (!field) continue;
      const value = field.type === 'checkbox' ? field.checked : field.value.trim();
      const errors = this._checkConstraints(value, constraints, field);

      if (errors.length > 0) {
        valid = false;
        this._showFieldError(field, errors[0]);
      } else {
        this._showFieldSuccess(field);
      }
    }
    return valid;
  },

  _checkConstraints(value, constraints, field) {
    const errors = [];
    for (const [rule, param] of Object.entries(constraints)) {
      let passed = true;
      switch (rule) {
        case 'required':  passed = !param || this.required(value); break;
        case 'email':     if (value) passed = this.email(value); break;
        case 'phone':     if (value) passed = this.phone(value); break;
        case 'password':  if (value) passed = this.password(value); break;
        case 'numeric':   if (value) passed = this.numeric(value); break;
        case 'integer':   if (value) passed = this.integer(value); break;
        case 'alpha':     if (value) passed = this.alpha(value); break;
        case 'amount':    if (value) passed = this.amount(value); break;
        case 'minLen':    if (value) passed = this.minLen(value, param); break;
        case 'maxLen':    if (value) passed = this.maxLen(value, param); break;
        case 'min':       if (value) passed = this.min(value, param); break;
        case 'max':       if (value) passed = this.max(value, param); break;
        case 'match': {
          const other = document.querySelector(`[name="${param}"]`) || document.getElementById(param);
          passed = value === (other?.value?.trim() || '');
          break;
        }
        case 'nationalId': if (value) passed = this.nationalId(value); break;
        case 'accountNo':  if (value) passed = this.accountNo(value); break;
        case 'url':        if (value) passed = this.url(value); break;
      }
      if (!passed) errors.push(this._getMessage(rule, param, field));
    }
    return errors;
  },

  _getMessage(rule, param, field) {
    const label = field.closest('.form-group')?.querySelector('.form-label')?.textContent?.replace('*','').trim() || 'This field';
    const msgs = {
      required:  `${label} is required.`,
      email:     `${label} must be a valid email address.`,
      phone:     `${label} must be a valid Ethiopian phone number.`,
      password:  `Password must be at least 8 characters with uppercase, lowercase, number, and special character.`,
      numeric:   `${label} must be a number.`,
      integer:   `${label} must be a whole number.`,
      alpha:     `${label} must contain letters only.`,
      amount:    `${label} must be a valid positive amount.`,
      minLen:    `${label} must be at least ${param} characters.`,
      maxLen:    `${label} must not exceed ${param} characters.`,
      min:       `${label} must be at least ${Format.number(param)}.`,
      max:       `${label} must not exceed ${Format.number(param)}.`,
      match:     `${label} does not match.`,
      nationalId:`${label} must be a valid National ID.`,
      accountNo: `${label} must be a valid account number (10-18 digits).`,
      url:       `${label} must be a valid URL.`,
    };
    return msgs[rule] || `${label} is invalid.`;
  },

  _showFieldError(field, message) {
    field.classList.remove('is-valid');
    field.classList.add('is-invalid');
    let feedback = field.nextElementSibling;
    if (!feedback || !feedback.classList.contains('invalid-feedback')) {
      feedback = document.createElement('div');
      feedback.className = 'invalid-feedback';
      field.insertAdjacentElement('afterend', feedback);
    }
    feedback.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${message}`;
    DOM.show(feedback);
    field.focus();
  },

  _showFieldSuccess(field) {
    field.classList.remove('is-invalid');
    field.classList.add('is-valid');
    const feedback = field.nextElementSibling;
    if (feedback?.classList.contains('invalid-feedback')) DOM.hide(feedback);
  },

  clearErrors(form) {
    form.querySelectorAll('.is-invalid, .is-valid').forEach(f => {
      f.classList.remove('is-invalid', 'is-valid');
    });
    form.querySelectorAll('.invalid-feedback').forEach(f => f.textContent = '');
  },

  /* ── Real-time validation ── */
  live(form, rules) {
    for (const [name] of Object.entries(rules)) {
      const field = form.querySelector(`[name="${name}"]`) || form.querySelector(`#${name}`);
      if (!field) continue;
      field.addEventListener('blur', () => {
        const singleRule = { [name]: rules[name] };
        this.form(form, singleRule);
      });
      field.addEventListener('input', () => {
        if (field.classList.contains('is-invalid')) {
          const singleRule = { [name]: rules[name] };
          this.form(form, singleRule);
        }
      });
    }
  },
};

/* ── Amount Formatter ── */
document.addEventListener('DOMContentLoaded', () => {
  /* Auto-format amount inputs */
  document.querySelectorAll('input[data-format="amount"]').forEach(input => {
    input.addEventListener('blur', function() {
      const val = parseFloat(this.value.replace(/,/g,''));
      if (!isNaN(val)) this.value = val.toFixed(2);
    });
    input.addEventListener('input', function() {
      this.value = this.value.replace(/[^0-9.]/g,'');
    });
  });

  /* Account number formatting */
  document.querySelectorAll('input[data-format="account"]').forEach(input => {
    input.addEventListener('input', function() {
      let v = this.value.replace(/\D/g,'');
      this.value = v.replace(/(.{4})/g,'$1 ').trim();
    });
  });

  /* Phone formatting */
  document.querySelectorAll('input[data-format="phone"]').forEach(input => {
    input.addEventListener('input', function() {
      this.value = this.value.replace(/[^0-9+]/g,'');
    });
  });
});
