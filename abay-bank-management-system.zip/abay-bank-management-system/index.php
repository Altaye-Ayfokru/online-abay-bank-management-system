<?php
// Fallback: forward to the MVC entry point.
// Normally Apache's DirectoryIndex picks up public/index.php directly
// and this file is never executed. It is kept only as a safety net.
require_once __DIR__ . '/public/index.php';
