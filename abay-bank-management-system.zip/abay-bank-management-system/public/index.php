<?php

/**
 * Abay Bank Management System — PHP Entry Point
 * All web requests are routed through this file.
 */

declare(strict_types=1);

// ── Bootstrap ──────────────────────────────────────────────────
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH',  ROOT_PATH . '/backend/app');

require_once ROOT_PATH . '/vendor/autoload.php';

// Load .env
$dotenv = Dotenv\Dotenv::createImmutable(ROOT_PATH);
$dotenv->safeLoad();

// App config (constants + timezone)
require_once ROOT_PATH . '/app/config/app.php';

// Core classes
require_once ROOT_PATH . '/app/core/Session.php';
require_once ROOT_PATH . '/app/core/View.php';
require_once ROOT_PATH . '/app/core/Auth.php';
require_once ROOT_PATH . '/app/core/Router.php';

// Backend DB + helpers (shared with API)
require_once APP_PATH . '/config/Database.php';
require_once APP_PATH . '/helpers/Response.php';

// ── Web Controllers
require_once ROOT_PATH . '/app/controllers/AuthWebController.php';
require_once ROOT_PATH . '/app/controllers/PageController.php';
require_once ROOT_PATH . '/app/controllers/OnlineApplicationController.php';
require_once ROOT_PATH . '/app/controllers/ApiController.php';

use Web\Core\Session;
use Web\Core\Router;
use Web\Controllers\ApiController;

// Start session
Session::start();

// Error handling
if (APP_ENV === 'development') {
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
} else {
  error_reporting(0);
  ini_set('display_errors', '0');
}

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// ── Load web routes ──────────────────────────────────────────────
require_once ROOT_PATH . '/app/routes/web.php';
